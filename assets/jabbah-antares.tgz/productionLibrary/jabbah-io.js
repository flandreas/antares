(function (factory) {
  if (typeof define === 'function' && define.amd)
    define(['exports', './kotlin-kotlin-stdlib.js', './jabbah-base.js'], factory);
  else if (typeof exports === 'object')
    factory(module.exports, require('./kotlin-kotlin-stdlib.js'), require('./jabbah-base.js'));
  else {
    if (typeof globalThis['kotlin-kotlin-stdlib'] === 'undefined') {
      throw new Error("Error loading module 'jabbah-io'. Its dependency 'kotlin-kotlin-stdlib' was not found. Please, check whether 'kotlin-kotlin-stdlib' is loaded prior to 'jabbah-io'.");
    }
    if (typeof globalThis['jabbah-base'] === 'undefined') {
      throw new Error("Error loading module 'jabbah-io'. Its dependency 'jabbah-base' was not found. Please, check whether 'jabbah-base' is loaded prior to 'jabbah-io'.");
    }
    globalThis['jabbah-io'] = factory(typeof globalThis['jabbah-io'] === 'undefined' ? {} : globalThis['jabbah-io'], globalThis['kotlin-kotlin-stdlib'], globalThis['jabbah-base']);
  }
}(function (_, kotlin_kotlin, kotlin_jabbah_base) {
  'use strict';
  //region block: imports
  var imul = Math.imul;
  var protoOf = kotlin_kotlin.$_$.t7;
  var objectCreate = kotlin_kotlin.$_$.s7;
  var THROW_CCE = kotlin_kotlin.$_$.db;
  var ensureNotNull = kotlin_kotlin.$_$.kb;
  var equals = kotlin_kotlin.$_$.g9;
  var Stack = kotlin_jabbah_base.$_$.e4;
  var Unit_instance = kotlin_kotlin.$_$.i;
  var asList = kotlin_kotlin.$_$.yb;
  var collectionSizeOrDefault = kotlin_kotlin.$_$.s2;
  var ArrayList_init_$Create$ = kotlin_kotlin.$_$.m;
  var toSet = kotlin_kotlin.$_$.w4;
  var initMetadataForClass = kotlin_kotlin.$_$.d7;
  var VOID = kotlin_kotlin.$_$.b;
  var encodeToByteArray = kotlin_kotlin.$_$.d9;
  var decodeToString = kotlin_kotlin.$_$.a9;
  var isInterface = kotlin_kotlin.$_$.m7;
  var initMetadataForObject = kotlin_kotlin.$_$.i7;
  var KProperty1 = kotlin_kotlin.$_$.t8;
  var getPropertyCallableRef = kotlin_kotlin.$_$.a7;
  var getKClass = kotlin_kotlin.$_$.q8;
  var logger = kotlin_jabbah_base.$_$.q7;
  var Exception = kotlin_kotlin.$_$.xa;
  var AbstractModule = kotlin_jabbah_base.$_$.d7;
  var BaseModuleJs_getInstance = kotlin_jabbah_base.$_$.m;
  var initMetadataForCompanion = kotlin_kotlin.$_$.e7;
  var ArrayList_init_$Create$_0 = kotlin_kotlin.$_$.n;
  var getKClassFromExpression = kotlin_kotlin.$_$.p8;
  var IllegalArgumentException_init_$Create$ = kotlin_kotlin.$_$.b1;
  var BaseModule_getInstance = kotlin_jabbah_base.$_$.n;
  var toString = kotlin_kotlin.$_$.rb;
  var getStringHashCode = kotlin_kotlin.$_$.b7;
  var hashCode = kotlin_kotlin.$_$.c7;
  var getBooleanHashCode = kotlin_kotlin.$_$.x6;
  var equals_0 = kotlin_kotlin.$_$.u6;
  var LinkedHashSet_init_$Create$ = kotlin_kotlin.$_$.r;
  var DirectedGraph = kotlin_jabbah_base.$_$.a4;
  var LinkedHashMap_init_$Create$ = kotlin_kotlin.$_$.q;
  var TopologicalSort_instance = kotlin_jabbah_base.$_$.b;
  var System_getInstance = kotlin_jabbah_base.$_$.c1;
  var initMetadataForInterface = kotlin_kotlin.$_$.g7;
  var toInt = kotlin_kotlin.$_$.ia;
  var IllegalArgumentException_init_$Create$_0 = kotlin_kotlin.$_$.z;
  var emptyList = kotlin_kotlin.$_$.c3;
  var toDouble = kotlin_kotlin.$_$.ga;
  var toLong = kotlin_kotlin.$_$.ka;
  var toULong = kotlin_kotlin.$_$.na;
  var charSequenceLength = kotlin_kotlin.$_$.r6;
  var _Char___init__impl__6a9atx = kotlin_kotlin.$_$.n1;
  var indexOf = kotlin_kotlin.$_$.i9;
  var substring = kotlin_kotlin.$_$.ea;
  var substring_0 = kotlin_kotlin.$_$.da;
  var Point2D = kotlin_jabbah_base.$_$.e6;
  var isCharSequence = kotlin_kotlin.$_$.k7;
  var trim = kotlin_kotlin.$_$.qa;
  var toString_0 = kotlin_kotlin.$_$.v7;
  var split = kotlin_kotlin.$_$.x9;
  var UUID = kotlin_jabbah_base.$_$.p7;
  var sorted = kotlin_kotlin.$_$.n4;
  var formatRounded = kotlin_jabbah_base.$_$.q6;
  var StringUtils_getInstance = kotlin_jabbah_base.$_$.b1;
  var ULong__toString_impl_f9au7k = kotlin_kotlin.$_$.b2;
  var StringBuilder_init_$Create$ = kotlin_kotlin.$_$.v;
  var joinToString = kotlin_kotlin.$_$.o3;
  var NoSuchElementException_init_$Create$ = kotlin_kotlin.$_$.h1;
  //endregion
  //region block: pre-declaration
  function descend$default(index, $super) {
    index = index === VOID ? 1 : index;
    var tmp;
    if ($super === VOID) {
      this.i35(index);
      tmp = Unit_instance;
    } else {
      tmp = $super.i35.call(this, index);
    }
    return tmp;
  }
  initMetadataForInterface(XmlReader, 'XmlReader');
  initMetadataForClass(DomXmlReader, 'DomXmlReader', VOID, VOID, [XmlReader]);
  initMetadataForClass(AbstractStorableCloner, 'AbstractStorableCloner');
  initMetadataForObject(StorableCloner, 'StorableCloner', VOID, AbstractStorableCloner);
  initMetadataForClass(DomXmlWriter, 'DomXmlWriter');
  initMetadataForObject(IOModuleJs, 'IOModuleJs', VOID, AbstractModule);
  initMetadataForCompanion(Companion);
  initMetadataForClass(Buffer, 'Buffer');
  initMetadataForClass(GlobalIdentityCreator, 'GlobalIdentityCreator', GlobalIdentityCreator);
  initMetadataForObject(IOModule, 'IOModule', VOID, AbstractModule);
  initMetadataForClass(Reference, 'Reference', Reference);
  initMetadataForCompanion(Companion_0);
  initMetadataForClass(ReferenceResolverImpl, 'ReferenceResolverImpl', ReferenceResolverImpl);
  function get_isReferencable() {
    return true;
  }
  function get_isNotReading() {
    return !this.p37();
  }
  function resolutionDone() {
  }
  function allResolutionDone() {
  }
  function readFromStore(reader) {
    try {
      this.o37(true);
      this.s37(reader);
    }finally {
      this.o37(false);
    }
  }
  initMetadataForInterface(Storable, 'Storable');
  initMetadataForClass(AbstractStorable, 'AbstractStorable', VOID, VOID, [Storable]);
  function readStorables$default(name, afterReadCallback, $super) {
    afterReadCallback = afterReadCallback === VOID ? null : afterReadCallback;
    return $super === VOID ? this.w37(name, afterReadCallback) : $super.w37.call(this, name, afterReadCallback);
  }
  initMetadataForInterface(StoreReader, 'StoreReader');
  initMetadataForCompanion(Companion_1);
  initMetadataForClass(StoreXmlReader, 'StoreXmlReader', VOID, VOID, [StoreReader]);
  initMetadataForCompanion(Companion_2);
  initMetadataForClass(StoreXmlWriter, 'StoreXmlWriter');
  initMetadataForClass(StringStorable, 'StringStorable', StringStorable, AbstractStorable);
  initMetadataForClass(TypeMapImpl, 'TypeMapImpl', TypeMapImpl);
  //endregion
  function DomXmlReader_init_$Init$(str, $this) {
    DomXmlReader.call($this, (new DOMParser()).parseFromString(str, 'application/xml'));
    return $this;
  }
  function DomXmlReader_init_$Create$(str) {
    return DomXmlReader_init_$Init$(str, objectCreate(protoOf(DomXmlReader)));
  }
  function getChildElement($this, name) {
    var children = $this.a35_1.pv().childNodes;
    var inductionVariable = 0;
    var last = children.length;
    if (inductionVariable < last)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        // Inline function 'org.w3c.dom.get' call
        // Inline function 'kotlin.js.asDynamic' call
        var tmp$ret$0 = children[i];
        if (equals(ensureNotNull(tmp$ret$0).nodeName, name, true)) {
          // Inline function 'org.w3c.dom.get' call
          // Inline function 'kotlin.js.asDynamic' call
          var tmp = children[i];
          return (tmp == null ? true : tmp instanceof Element) ? tmp : THROW_CCE();
        }
      }
       while (inductionVariable < last);
    return null;
  }
  function DomXmlReader(document) {
    this.a35_1 = new Stack();
    this.a35_1.wv(ensureNotNull(document.documentElement));
  }
  protoOf(DomXmlReader).b35 = function () {
    return this.a35_1.pv().tagName;
  };
  protoOf(DomXmlReader).c35 = function (name) {
    return ensureNotNull(this.a35_1.pv().getAttribute(name));
  };
  protoOf(DomXmlReader).d35 = function (name) {
    return !(this.a35_1.pv().getAttribute(name) == null);
  };
  protoOf(DomXmlReader).e35 = function (name) {
    return !(getChildElement(this, name) == null);
  };
  protoOf(DomXmlReader).f35 = function () {
    // Inline function 'kotlin.collections.map' call
    var this_0 = asList(this.a35_1.pv().children);
    // Inline function 'kotlin.collections.mapTo' call
    var destination = ArrayList_init_$Create$(collectionSizeOrDefault(this_0, 10));
    var _iterator__ex2g4s = this_0.i();
    while (_iterator__ex2g4s.j()) {
      var item = _iterator__ex2g4s.k();
      var tmp$ret$2 = item.nodeName;
      destination.h(tmp$ret$2);
    }
    return toSet(destination);
  };
  protoOf(DomXmlReader).g35 = function () {
    return this.a35_1.pv().childElementCount;
  };
  protoOf(DomXmlReader).h35 = function (name) {
    this.a35_1.wv(ensureNotNull(getChildElement(this, name)));
  };
  protoOf(DomXmlReader).i35 = function (index) {
    // Inline function 'org.w3c.dom.get' call
    // Inline function 'kotlin.js.asDynamic' call
    var tmp$ret$0 = this.a35_1.pv().children[index - 1 | 0];
    this.a35_1.wv(ensureNotNull(tmp$ret$0));
  };
  protoOf(DomXmlReader).k35 = function () {
    this.a35_1.xv();
  };
  protoOf(DomXmlReader).l35 = function (name) {
    return ensureNotNull(ensureNotNull(getChildElement(this, name)).textContent);
  };
  function StorableCloner$serializeImpl$lambda($s) {
    return function (it) {
      $s._v = it;
      return Unit_instance;
    };
  }
  function StorableCloner() {
    StorableCloner_instance = this;
    AbstractStorableCloner.call(this);
  }
  protoOf(StorableCloner).m35 = function (storable, identityProvider) {
    var s = {_v: ''};
    var xmlWriter = new DomXmlWriter(StorableCloner$serializeImpl$lambda(s));
    var writer = new StoreXmlWriter(xmlWriter, IOModule_getInstance().o35_1, identityProvider);
    writer.u35(storable);
    var byteArray = encodeToByteArray(s._v);
    return new Buffer(byteArray, byteArray.length);
  };
  protoOf(StorableCloner).v35 = function (s, referenceResolver) {
    var xmlReader = DomXmlReader_init_$Create$(decodeToString(s.w35_1));
    var reader = new StoreXmlReader(xmlReader, IOModule_getInstance().o35_1, referenceResolver);
    var tmp = reader.b36();
    return isInterface(tmp, Storable) ? tmp : THROW_CCE();
  };
  var StorableCloner_instance;
  function StorableCloner_getInstance() {
    if (StorableCloner_instance == null)
      new StorableCloner();
    return StorableCloner_instance;
  }
  function _get_LOG__e5r759($this) {
    var tmp0 = $this.g36_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('LOG', 1, tmp, DomXmlWriter$_get_LOG_$ref_sii8kg(), null);
    return tmp0.j2();
  }
  function DomXmlWriter$_get_LOG_$ref_sii8kg() {
    return function (p0) {
      return _get_LOG__e5r759(p0);
    };
  }
  function DomXmlWriter(consumer) {
    this.f36_1 = consumer;
    this.g36_1 = logger(getKClass(DomXmlWriter));
    this.h36_1 = null;
    this.i36_1 = new Stack();
  }
  protoOf(DomXmlWriter).j36 = function () {
    return this.i36_1.uv();
  };
  protoOf(DomXmlWriter).k36 = function (name) {
    try {
      if (this.j36()) {
        this.h36_1 = document.implementation.createDocument(null, name, null);
        this.i36_1.wv(ensureNotNull(ensureNotNull(this.h36_1).documentElement));
      } else {
        var child = ensureNotNull(this.h36_1).createElement(name);
        this.i36_1.pv().appendChild(child);
        this.i36_1.wv(child);
      }
    } catch ($p) {
      if ($p instanceof Error) {
        var e = $p;
        _get_LOG__e5r759(this).kl('DomXmlWriter: Error while descending to ' + name);
      } else {
        throw $p;
      }
    }
  };
  protoOf(DomXmlWriter).k35 = function () {
    this.i36_1.xv();
  };
  protoOf(DomXmlWriter).x7 = function () {
    try {
      this.f36_1((new XMLSerializer()).serializeToString(ensureNotNull(this.h36_1)));
    } catch ($p) {
      if ($p instanceof Exception) {
        var e = $p;
        _get_LOG__e5r759(this).kl('Error in flushing Document to XML string: ' + e.message);
      } else {
        throw $p;
      }
    }
  };
  protoOf(DomXmlWriter).l36 = function (name, value) {
    this.i36_1.pv().setAttribute(name, value);
  };
  protoOf(DomXmlWriter).m36 = function (name, text) {
    this.k36(name);
    this.i36_1.pv().textContent = text;
    this.k35();
  };
  function IOModuleJs() {
    IOModuleJs_instance = this;
    AbstractModule.call(this);
  }
  protoOf(IOModuleJs).ro = function () {
    BaseModuleJs_getInstance().to();
    IOModule_getInstance().to();
  };
  var IOModuleJs_instance;
  function IOModuleJs_getInstance() {
    if (IOModuleJs_instance == null)
      new IOModuleJs();
    return IOModuleJs_instance;
  }
  function _get_LOG__e5r759_0($this) {
    var tmp0 = $this.o36_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('LOG', 1, tmp, AbstractStorableCloner$Companion$_get_LOG_$ref_km03u3(), null);
    return tmp0.j2();
  }
  function AbstractStorableCloner$Companion$_get_LOG_$ref_km03u3() {
    return function (p0) {
      return _get_LOG__e5r759_0(p0);
    };
  }
  function Companion() {
    Companion_instance = this;
    this.o36_1 = logger(getKClass(AbstractStorableCloner));
  }
  var Companion_instance;
  function Companion_getInstance() {
    if (Companion_instance == null)
      new Companion();
    return Companion_instance;
  }
  function Buffer(data, length) {
    this.w35_1 = data;
    this.x35_1 = length;
  }
  function AbstractStorableCloner() {
    Companion_getInstance();
  }
  protoOf(AbstractStorableCloner).c36 = function (storable) {
    return this.e36(storable, new GlobalIdentityCreator());
  };
  protoOf(AbstractStorableCloner).d36 = function (storable) {
    return this.e36(storable, new GlobalIdentityCreator());
  };
  protoOf(AbstractStorableCloner).e36 = function (storable, identityProvider) {
    try {
      var data = this.m35(storable, identityProvider);
      return this.v35(data, new ReferenceResolverImpl(identityProvider));
    } catch ($p) {
      if ($p instanceof Error) {
        var x = $p;
        _get_LOG__e5r759_0(Companion_getInstance()).kl('Error while cloning Storable: ' + x.message);
        throw x;
      } else {
        throw $p;
      }
    }
  };
  function GlobalIdentityCreator() {
    var tmp = this;
    // Inline function 'kotlin.collections.mutableListOf' call
    tmp.p36_1 = ArrayList_init_$Create$_0();
  }
  protoOf(GlobalIdentityCreator).q36 = function (storable) {
    if (!this.p36_1.n(storable)) {
      this.p36_1.h(storable);
    }
    return this.p36_1.p(storable);
  };
  protoOf(GlobalIdentityCreator).r36 = function (storable) {
    if (!this.p36_1.n(storable)) {
      throw IllegalArgumentException_init_$Create$('storable ' + getKClassFromExpression(storable).l9() + ' not available');
    }
    return this.p36_1.p(storable);
  };
  protoOf(GlobalIdentityCreator).s36 = function (globalId) {
    if (0 <= globalId ? globalId < this.p36_1.o() : false) {
      return this.p36_1.l(globalId);
    }
    return null;
  };
  function configureTypeMap($this, typeMap) {
    typeMap.t36('string', getKClass(StringStorable));
  }
  function IOModule() {
    IOModule_instance = this;
    AbstractModule.call(this);
    this.o35_1 = new TypeMapImpl();
  }
  protoOf(IOModule).ro = function () {
    BaseModule_getInstance().to();
    configureTypeMap(this, this.o35_1);
  };
  var IOModule_instance;
  function IOModule_getInstance() {
    if (IOModule_instance == null)
      new IOModule();
    return IOModule_instance;
  }
  function Reference(name, referenceId, additionalInfo, resolveAfter, dummy) {
    name = name === VOID ? null : name;
    referenceId = referenceId === VOID ? 0 : referenceId;
    additionalInfo = additionalInfo === VOID ? null : additionalInfo;
    resolveAfter = resolveAfter === VOID ? null : resolveAfter;
    dummy = dummy === VOID ? false : dummy;
    this.u36_1 = name;
    this.v36_1 = referenceId;
    this.w36_1 = additionalInfo;
    this.x36_1 = resolveAfter;
    this.y36_1 = dummy;
  }
  protoOf(Reference).toString = function () {
    return 'Reference(name=' + this.u36_1 + ', referenceId=' + this.v36_1 + ', additionalInfo=' + toString(this.w36_1) + ', resolveAfter=' + toString(this.x36_1) + ', dummy=' + this.y36_1 + ')';
  };
  protoOf(Reference).hashCode = function () {
    var result = this.u36_1 == null ? 0 : getStringHashCode(this.u36_1);
    result = imul(result, 31) + this.v36_1 | 0;
    result = imul(result, 31) + (this.w36_1 == null ? 0 : hashCode(this.w36_1)) | 0;
    result = imul(result, 31) + (this.x36_1 == null ? 0 : hashCode(this.x36_1)) | 0;
    result = imul(result, 31) + getBooleanHashCode(this.y36_1) | 0;
    return result;
  };
  protoOf(Reference).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof Reference))
      return false;
    if (!(this.u36_1 == other.u36_1))
      return false;
    if (!(this.v36_1 === other.v36_1))
      return false;
    if (!equals_0(this.w36_1, other.w36_1))
      return false;
    if (!equals_0(this.x36_1, other.x36_1))
      return false;
    if (!(this.y36_1 === other.y36_1))
      return false;
    return true;
  };
  function _get_LOG__e5r759_1($this) {
    var tmp0 = $this.z36_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('LOG', 1, tmp, ReferenceResolverImpl$Companion$_get_LOG_$ref_qmt5ox(), null);
    return tmp0.j2();
  }
  function ReferenceResolverImpl$Companion$_get_LOG_$ref_qmt5ox() {
    return function (p0) {
      return _get_LOG__e5r759_1(p0);
    };
  }
  function Companion_0() {
    Companion_instance_0 = this;
    this.z36_1 = logger(getKClass(ReferenceResolverImpl));
  }
  var Companion_instance_0;
  function Companion_getInstance_0() {
    if (Companion_instance_0 == null)
      new Companion_0();
    return Companion_instance_0;
  }
  function addDummyReferences($this) {
    // Inline function 'kotlin.collections.mutableSetOf' call
    var set = LinkedHashSet_init_$Create$();
    var _iterator__ex2g4s = $this.d37_1.c2().i();
    while (_iterator__ex2g4s.j()) {
      var references = _iterator__ex2g4s.k();
      var _iterator__ex2g4s_0 = references.i();
      while (_iterator__ex2g4s_0.j()) {
        var reference = _iterator__ex2g4s_0.k();
        var tmp0_safe_receiver = reference.x36_1;
        if (tmp0_safe_receiver == null)
          null;
        else {
          // Inline function 'kotlin.collections.forEach' call
          var _iterator__ex2g4s_1 = tmp0_safe_receiver.i();
          while (_iterator__ex2g4s_1.j()) {
            var element = _iterator__ex2g4s_1.k();
            var storable = $this.e37(element);
            if (!(storable == null) && !$this.c37_1.n(storable)) {
              set.h(storable);
            }
          }
        }
      }
    }
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s_2 = set.i();
    while (_iterator__ex2g4s_2.j()) {
      var element_0 = _iterator__ex2g4s_2.k();
      $this.f37(element_0, new Reference('dummy', VOID, VOID, VOID, true));
    }
  }
  function buildGraph($this) {
    var graph = new DirectedGraph();
    addDummyReferences($this);
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = $this.c37_1.i();
    while (_iterator__ex2g4s.j()) {
      var element = _iterator__ex2g4s.k();
      graph.hv(element);
    }
    var _iterator__ex2g4s_0 = $this.d37_1.b2().i();
    while (_iterator__ex2g4s_0.j()) {
      var storable = _iterator__ex2g4s_0.k();
      var _iterator__ex2g4s_1 = ensureNotNull($this.d37_1.g2(storable)).i();
      while (_iterator__ex2g4s_1.j()) {
        var reference = _iterator__ex2g4s_1.k();
        var tmp0_safe_receiver = reference.x36_1;
        if (tmp0_safe_receiver == null)
          null;
        else {
          // Inline function 'kotlin.collections.forEach' call
          var _iterator__ex2g4s_2 = tmp0_safe_receiver.i();
          while (_iterator__ex2g4s_2.j()) {
            var element_0 = _iterator__ex2g4s_2.k();
            var predecessor = $this.e37(element_0);
            if (!(predecessor == null)) {
              graph.iv(predecessor, storable);
            }
          }
        }
      }
    }
    return graph;
  }
  function ReferenceResolverImpl(identityProvider) {
    Companion_getInstance_0();
    identityProvider = identityProvider === VOID ? null : identityProvider;
    this.a37_1 = identityProvider;
    var tmp = this;
    // Inline function 'kotlin.collections.mutableMapOf' call
    tmp.b37_1 = LinkedHashMap_init_$Create$();
    var tmp_0 = this;
    // Inline function 'kotlin.collections.mutableListOf' call
    tmp_0.c37_1 = ArrayList_init_$Create$_0();
    var tmp_1 = this;
    // Inline function 'kotlin.collections.mutableMapOf' call
    tmp_1.d37_1 = LinkedHashMap_init_$Create$();
  }
  protoOf(ReferenceResolverImpl).g37 = function (globalId, storable) {
    _get_LOG__e5r759_1(Companion_getInstance_0()).ol('add storable ' + globalId);
    // Inline function 'kotlin.collections.set' call
    this.b37_1.y1(globalId, storable);
  };
  protoOf(ReferenceResolverImpl).e37 = function (globalId) {
    _get_LOG__e5r759_1(Companion_getInstance_0()).ol('getStorable for id ' + globalId);
    var tmp = this.b37_1.g2(globalId);
    var tmp0_elvis_lhs = (tmp == null ? true : isInterface(tmp, Storable)) ? tmp : THROW_CCE();
    var tmp_0;
    if (tmp0_elvis_lhs == null) {
      var tmp1_safe_receiver = this.a37_1;
      var tmp_1 = tmp1_safe_receiver == null ? null : tmp1_safe_receiver.s36(globalId);
      tmp_0 = (tmp_1 == null ? true : isInterface(tmp_1, Storable)) ? tmp_1 : THROW_CCE();
    } else {
      tmp_0 = tmp0_elvis_lhs;
    }
    return tmp_0;
  };
  protoOf(ReferenceResolverImpl).h37 = function (storable) {
    var tmp0 = this.b37_1.d2();
    var tmp$ret$0;
    $l$block: {
      // Inline function 'kotlin.collections.firstOrNull' call
      var _iterator__ex2g4s = tmp0.i();
      while (_iterator__ex2g4s.j()) {
        var element = _iterator__ex2g4s.k();
        if (element.j2() === storable) {
          tmp$ret$0 = element;
          break $l$block;
        }
      }
      tmp$ret$0 = null;
    }
    var tmp0_safe_receiver = tmp$ret$0;
    var tmp1_elvis_lhs = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.i2();
    var tmp;
    if (tmp1_elvis_lhs == null) {
      var tmp2_safe_receiver = this.a37_1;
      tmp = tmp2_safe_receiver == null ? null : tmp2_safe_receiver.r36(storable);
    } else {
      tmp = tmp1_elvis_lhs;
    }
    var tmp3_elvis_lhs = tmp;
    var tmp_0;
    if (tmp3_elvis_lhs == null) {
      throw IllegalArgumentException_init_$Create$('storable ' + getKClassFromExpression(storable).l9() + ' not available');
    } else {
      tmp_0 = tmp3_elvis_lhs;
    }
    return tmp_0;
  };
  protoOf(ReferenceResolverImpl).f37 = function (requester, reference) {
    var list = this.d37_1.g2(requester);
    if (list == null) {
      // Inline function 'kotlin.collections.mutableListOf' call
      list = ArrayList_init_$Create$_0();
      var tmp0 = this.d37_1;
      // Inline function 'kotlin.collections.set' call
      var value = list;
      tmp0.y1(requester, value);
    }
    if (!this.c37_1.n(requester)) {
      this.c37_1.h(requester);
    }
    if (!list.n(reference)) {
      list.h(reference);
    }
  };
  protoOf(ReferenceResolverImpl).i37 = function () {
    this.j37(this);
  };
  protoOf(ReferenceResolverImpl).j37 = function (referenceResolver) {
    var graph = buildGraph(this);
    var list = TopologicalSort_instance.zv(graph);
    var _iterator__ex2g4s = list.i();
    while (_iterator__ex2g4s.j()) {
      var storable = _iterator__ex2g4s.k();
      var _iterator__ex2g4s_0 = ensureNotNull(this.d37_1.g2(storable)).i();
      while (_iterator__ex2g4s_0.j()) {
        var reference = _iterator__ex2g4s_0.k();
        if (!reference.y36_1) {
          try {
            storable.k37(reference, referenceResolver);
          } catch ($p) {
            if ($p instanceof Error) {
              var e = $p;
              _get_LOG__e5r759_1(Companion_getInstance_0()).kl("error while resolving class '" + System_getInstance().wl(storable) + "': " + e.message);
              throw e;
            } else {
              throw $p;
            }
          }
        }
      }
    }
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s_1 = list.i();
    while (_iterator__ex2g4s_1.j()) {
      var element = _iterator__ex2g4s_1.k();
      element.l37();
    }
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s_2 = list.i();
    while (_iterator__ex2g4s_2.j()) {
      var element_0 = _iterator__ex2g4s_2.k();
      element_0.m37();
    }
  };
  function Storable() {
  }
  function AbstractStorable() {
    this.u37_1 = false;
  }
  protoOf(AbstractStorable).o37 = function (_set____db54di) {
    this.u37_1 = _set____db54di;
  };
  protoOf(AbstractStorable).p37 = function () {
    return this.u37_1;
  };
  function StoreReader() {
  }
  function _get_LOG__e5r759_2($this) {
    var tmp0 = $this.m38_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('LOG', 1, tmp, StoreXmlReader$Companion$_get_LOG_$ref_jqqigp(), null);
    return tmp0.j2();
  }
  function StoreXmlReader$Companion$_get_LOG_$ref_jqqigp() {
    return function (p0) {
      return _get_LOG__e5r759_2(p0);
    };
  }
  function Companion_1() {
    Companion_instance_1 = this;
    this.m38_1 = logger(getKClass(StoreXmlReader));
  }
  var Companion_instance_1;
  function Companion_getInstance_1() {
    if (Companion_instance_1 == null)
      new Companion_1();
    return Companion_instance_1;
  }
  function StoreXmlReader_init_$Init$(xmlReader, $this) {
    StoreXmlReader.call($this, xmlReader, IOModule_getInstance().o35_1, new ReferenceResolverImpl());
    return $this;
  }
  function StoreXmlReader_init_$Create$(xmlReader) {
    return StoreXmlReader_init_$Init$(xmlReader, objectCreate(protoOf(StoreXmlReader)));
  }
  function readStorableImpl($this) {
    var storable = $this.z35_1.n38($this.y35_1.b35());
    var tmp0_safe_receiver = readGlobalId($this);
    if (tmp0_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      $this.a36_1.g37(tmp0_safe_receiver, storable);
    }
    storable.t37($this);
    return isInterface(storable, Storable) ? storable : THROW_CCE();
  }
  function readGlobalId($this) {
    if (!$this.y35_1.d35('_id')) {
      return null;
    }
    return toInt($this.y35_1.c35('_id'));
  }
  function StoreXmlReader(xmlReader, typeMap, referenceResolver) {
    Companion_getInstance_1();
    this.y35_1 = xmlReader;
    this.z35_1 = typeMap;
    this.a36_1 = referenceResolver;
  }
  protoOf(StoreXmlReader).f37 = function (requester, reference) {
    this.a36_1.f37(requester, reference);
  };
  protoOf(StoreXmlReader).d35 = function (name) {
    return this.y35_1.d35(name);
  };
  protoOf(StoreXmlReader).e35 = function (name) {
    return this.y35_1.e35(name);
  };
  protoOf(StoreXmlReader).f35 = function () {
    return this.y35_1.f35();
  };
  protoOf(StoreXmlReader).h37 = function (storable) {
    return this.a36_1.h37(storable);
  };
  protoOf(StoreXmlReader).b36 = function () {
    var storable = readStorableImpl(this);
    this.a36_1.i37();
    return storable;
  };
  protoOf(StoreXmlReader).v37 = function (name) {
    if (!this.y35_1.e35(name)) {
      _get_LOG__e5r759_2(Companion_getInstance_1()).kl("no element in '" + this.y35_1.b35() + "' with name '" + name + "'");
      throw IllegalArgumentException_init_$Create$_0();
    }
    this.y35_1.h35(name);
    this.y35_1.j35();
    var storable = readStorableImpl(this);
    this.y35_1.k35();
    this.y35_1.k35();
    return storable;
  };
  protoOf(StoreXmlReader).w37 = function (name, afterReadCallback) {
    if (!this.y35_1.e35(name)) {
      // Inline function 'kotlin.collections.listOf' call
      return emptyList();
    }
    // Inline function 'kotlin.collections.mutableListOf' call
    var storables = ArrayList_init_$Create$_0();
    this.y35_1.h35(name);
    var inductionVariable = 1;
    var last = this.y35_1.g35();
    if (inductionVariable <= last)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        this.y35_1.i35(i);
        var tmp = readStorableImpl(this);
        var s = isInterface(tmp, Storable) ? tmp : THROW_CCE();
        storables.h(s);
        if (afterReadCallback == null)
          null;
        else
          afterReadCallback(s);
        this.y35_1.k35();
      }
       while (!(i === last));
    this.y35_1.k35();
    return storables;
  };
  protoOf(StoreXmlReader).y37 = function (name) {
    // Inline function 'kotlin.collections.mutableMapOf' call
    var map = LinkedHashMap_init_$Create$();
    this.y35_1.h35(name);
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = this.f35().i();
    while (_iterator__ex2g4s.j()) {
      var element = _iterator__ex2g4s.k();
      // Inline function 'kotlin.collections.set' call
      var value = this.v37(element);
      map.y1(element, value);
    }
    this.y35_1.k35();
    return map;
  };
  protoOf(StoreXmlReader).z37 = function (name) {
    return toInt(this.y35_1.c35(name));
  };
  protoOf(StoreXmlReader).a38 = function (name) {
    return toDouble(this.y35_1.c35(name));
  };
  protoOf(StoreXmlReader).b38 = function (name) {
    return this.y35_1.c35(name);
  };
  protoOf(StoreXmlReader).c38 = function (name) {
    if (this.d35(name)) {
      return this.b38(name);
    }
    return null;
  };
  protoOf(StoreXmlReader).d38 = function (name) {
    var b = this.y35_1.c35(name);
    var tmp;
    if (b === '1') {
      tmp = true;
    } else {
      // Inline function 'kotlin.text.lowercase' call
      // Inline function 'kotlin.js.asDynamic' call
      tmp = b.toLowerCase() === 'true';
    }
    return tmp;
  };
  protoOf(StoreXmlReader).e38 = function (name) {
    return toLong(this.y35_1.c35(name));
  };
  protoOf(StoreXmlReader).f38 = function (name) {
    return toULong(this.y35_1.c35(name));
  };
  protoOf(StoreXmlReader).g38 = function (name) {
    // Inline function 'kotlin.collections.mutableListOf' call
    var points = ArrayList_init_$Create$_0();
    var list = this.b38(name);
    try {
      $l$loop: while (true) {
        // Inline function 'kotlin.text.isNotEmpty' call
        var this_0 = list;
        if (!(charSequenceLength(this_0) > 0)) {
          break $l$loop;
        }
        var i = indexOf(list, _Char___init__impl__6a9atx(44));
        var j = indexOf(list, _Char___init__impl__6a9atx(32));
        var x = toDouble(substring(list, 0, i));
        var y = toDouble(!(j === -1) ? substring(list, i + 1 | 0, j) : substring_0(list, i + 1 | 0));
        points.h(new Point2D(x, y));
        var tmp;
        if (!(j === -1)) {
          // Inline function 'kotlin.text.trim' call
          var this_1 = substring_0(list, j);
          tmp = toString_0(trim(isCharSequence(this_1) ? this_1 : THROW_CCE()));
        } else {
          tmp = '';
        }
        list = tmp;
      }
      return points;
    } catch ($p) {
      if ($p instanceof Error) {
        var e = $p;
        _get_LOG__e5r759_2(Companion_getInstance_1()).kl("Parsing of point list '" + name + "' failed with '" + e.message + "'");
        throw e;
      } else {
        throw $p;
      }
    }
  };
  protoOf(StoreXmlReader).h38 = function (outerElem, innerElem, attribute) {
    this.y35_1.h35(outerElem);
    this.y35_1.h35(innerElem);
    var list = this.g38(attribute);
    this.y35_1.k35();
    this.y35_1.k35();
    return list;
  };
  protoOf(StoreXmlReader).i38 = function (name) {
    this.y35_1.h35(name);
    this.y35_1.h35('point');
    var p = new Point2D(this.a38('x'), this.a38('y'));
    this.y35_1.k35();
    this.y35_1.k35();
    return p;
  };
  protoOf(StoreXmlReader).j38 = function (name) {
    // Inline function 'kotlin.collections.map' call
    var this_0 = split(this.y35_1.c35(name), [',']);
    // Inline function 'kotlin.collections.mapTo' call
    var destination = ArrayList_init_$Create$(collectionSizeOrDefault(this_0, 10));
    var _iterator__ex2g4s = this_0.i();
    while (_iterator__ex2g4s.j()) {
      var item = _iterator__ex2g4s.k();
      var tmp$ret$2 = toInt(item);
      destination.h(tmp$ret$2);
    }
    return destination;
  };
  protoOf(StoreXmlReader).k38 = function (name) {
    // Inline function 'kotlin.collections.map' call
    var this_0 = split(this.y35_1.c35(name), [',']);
    // Inline function 'kotlin.collections.mapTo' call
    var destination = ArrayList_init_$Create$(collectionSizeOrDefault(this_0, 10));
    var _iterator__ex2g4s = this_0.i();
    while (_iterator__ex2g4s.j()) {
      var item = _iterator__ex2g4s.k();
      var tmp$ret$2 = new UUID(item);
      destination.h(tmp$ret$2);
    }
    return toSet(destination);
  };
  protoOf(StoreXmlReader).l38 = function (name) {
    return this.y35_1.l35(name);
  };
  function Companion_2() {
    this.o38_1 = 1.0E7;
  }
  var Companion_instance_2;
  function Companion_getInstance_2() {
    return Companion_instance_2;
  }
  function StoreXmlWriter$_init_$lambda_gzhh8e(_unused_var__etf5q3, _unused_var__etf5q3_0) {
    return true;
  }
  function StoreXmlWriter(xmlWriter, typeMap, identityProvider, filter) {
    var tmp;
    if (filter === VOID) {
      tmp = StoreXmlWriter$_init_$lambda_gzhh8e;
    } else {
      tmp = filter;
    }
    filter = tmp;
    this.p35_1 = xmlWriter;
    this.q35_1 = typeMap;
    this.r35_1 = identityProvider;
    this.s35_1 = filter;
    this.t35_1 = 0;
  }
  protoOf(StoreXmlWriter).q36 = function (storable) {
    return this.r35_1.q36(storable);
  };
  protoOf(StoreXmlWriter).r36 = function (storable) {
    return this.r35_1.r36(storable);
  };
  protoOf(StoreXmlWriter).s36 = function (globalId) {
    return this.r35_1.s36(globalId);
  };
  protoOf(StoreXmlWriter).u35 = function (storable) {
    var type = this.q35_1.p38(storable);
    this.p35_1.k36(type);
    if (storable.n37()) {
      this.p35_1.l36('_id', this.q36(storable).toString());
    }
    storable.r37(this);
    this.p35_1.k35();
    if (this.p35_1.j36()) {
      this.p35_1.x7();
    }
  };
  protoOf(StoreXmlWriter).q38 = function (name, storable) {
    this.p35_1.k36(name);
    this.u35(storable);
    this.p35_1.k35();
  };
  protoOf(StoreXmlWriter).r38 = function (name, iterator) {
    try {
      this.p35_1.k36(name);
      this.t35_1 = this.t35_1 + 1 | 0;
      // Inline function 'kotlin.collections.iterator' call
      var _iterator__ex2g4s = iterator;
      while (_iterator__ex2g4s.j()) {
        var storable = _iterator__ex2g4s.k();
        if (this.s35_1(storable, this.t35_1 <= 1)) {
          this.u35(storable);
        }
      }
      this.p35_1.k35();
    }finally {
      this.t35_1 = this.t35_1 - 1 | 0;
    }
  };
  protoOf(StoreXmlWriter).s38 = function (name, map) {
    this.p35_1.k36(name);
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = sorted(map.b2()).i();
    while (_iterator__ex2g4s.j()) {
      var element = _iterator__ex2g4s.k();
      this.q38(element, ensureNotNull(map.g2(element)));
    }
    this.p35_1.k35();
  };
  protoOf(StoreXmlWriter).t38 = function (name, value) {
    this.p35_1.l36(name, value.toString());
  };
  protoOf(StoreXmlWriter).u38 = function (name, value) {
    this.p35_1.l36(name, formatRounded(value));
  };
  protoOf(StoreXmlWriter).v38 = function (name, value) {
    this.p35_1.l36(name, formatRounded(value, 1.0E7));
  };
  protoOf(StoreXmlWriter).w38 = function (name, value) {
    this.p35_1.l36(name, value);
  };
  protoOf(StoreXmlWriter).x38 = function (name, value) {
    if (StringUtils_getInstance().ju(value)) {
      this.w38(name, ensureNotNull(value));
    }
  };
  protoOf(StoreXmlWriter).y38 = function (name, value) {
    this.p35_1.l36(name, value ? 'true' : 'false');
  };
  protoOf(StoreXmlWriter).z38 = function (name, value) {
    this.p35_1.l36(name, value.toString());
  };
  protoOf(StoreXmlWriter).a39 = function (name, value) {
    this.p35_1.l36(name, ULong__toString_impl_f9au7k(value));
  };
  protoOf(StoreXmlWriter).b39 = function (name, points) {
    var list = StringBuilder_init_$Create$();
    var inductionVariable = 0;
    var last = points.o() - 1 | 0;
    if (inductionVariable <= last)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        list.h7(formatRounded(points.l(i).in_1) + ',' + formatRounded(points.l(i).jn_1) + ' ');
      }
       while (inductionVariable <= last);
    // Inline function 'kotlin.text.trim' call
    var this_0 = list.toString();
    var tmp$ret$0 = toString_0(trim(isCharSequence(this_0) ? this_0 : THROW_CCE()));
    this.w38(name, tmp$ret$0);
  };
  protoOf(StoreXmlWriter).c39 = function (outerElem, innerElem, attribute, points) {
    this.p35_1.k36(outerElem);
    this.p35_1.k36(innerElem);
    this.b39(attribute, points);
    this.p35_1.k35();
    this.p35_1.k35();
  };
  protoOf(StoreXmlWriter).d39 = function (name, point) {
    this.p35_1.k36(name);
    this.p35_1.k36('point');
    this.u38('x', point.in_1);
    this.u38('y', point.jn_1);
    this.p35_1.k35();
    this.p35_1.k35();
  };
  protoOf(StoreXmlWriter).e39 = function (name, integers) {
    // Inline function 'kotlin.collections.isNotEmpty' call
    if (!integers.m()) {
      this.w38(name, joinToString(integers, ','));
    }
  };
  protoOf(StoreXmlWriter).f39 = function (name, uuids) {
    // Inline function 'kotlin.collections.isNotEmpty' call
    if (!uuids.m()) {
      this.w38(name, joinToString(uuids, ','));
    }
  };
  protoOf(StoreXmlWriter).g39 = function (name, text) {
    this.p35_1.m36(name, '\n' + text + '\n');
  };
  function StringStorable(content) {
    content = content === VOID ? '' : content;
    AbstractStorable.call(this);
    this.i39_1 = content;
  }
  protoOf(StringStorable).n37 = function () {
    return false;
  };
  protoOf(StringStorable).k37 = function (reference, referenceResolver) {
  };
  protoOf(StringStorable).r37 = function (writer) {
    writer.w38('content', this.i39_1);
  };
  protoOf(StringStorable).s37 = function (reader) {
    this.i39_1 = reader.b38('content');
  };
  function TypeMapImpl$register$lambda($clazz) {
    return function () {
      return System_getInstance().yl($clazz);
    };
  }
  function TypeMapImpl() {
    var tmp = this;
    // Inline function 'kotlin.collections.mutableMapOf' call
    tmp.j39_1 = LinkedHashMap_init_$Create$();
    var tmp_0 = this;
    // Inline function 'kotlin.collections.mutableMapOf' call
    tmp_0.k39_1 = LinkedHashMap_init_$Create$();
    var tmp_1 = this;
    // Inline function 'kotlin.collections.mutableMapOf' call
    tmp_1.l39_1 = LinkedHashMap_init_$Create$();
  }
  protoOf(TypeMapImpl).t36 = function (type, clazz) {
    var tmp0 = this.j39_1;
    // Inline function 'kotlin.collections.set' call
    var value = TypeMapImpl$register$lambda(clazz);
    tmp0.y1(type, value);
    // Inline function 'kotlin.collections.set' call
    this.k39_1.y1(clazz, type);
  };
  protoOf(TypeMapImpl).m39 = function (type, condition, factory) {
    // Inline function 'kotlin.collections.set' call
    this.j39_1.y1(type, factory);
    // Inline function 'kotlin.collections.set' call
    this.l39_1.y1(condition, type);
  };
  protoOf(TypeMapImpl).n38 = function (type) {
    var tmp0_safe_receiver = this.j39_1.g2(type);
    var tmp1_elvis_lhs = tmp0_safe_receiver == null ? null : tmp0_safe_receiver();
    var tmp;
    if (tmp1_elvis_lhs == null) {
      throw NoSuchElementException_init_$Create$("TypeMapImpl: type '" + type + "' not found");
    } else {
      tmp = tmp1_elvis_lhs;
    }
    var obj = tmp;
    return !(obj == null) ? obj : THROW_CCE();
  };
  protoOf(TypeMapImpl).p38 = function (storable) {
    var tmp0_elvis_lhs = this.k39_1.g2(getKClassFromExpression(storable));
    var tmp;
    if (tmp0_elvis_lhs == null) {
      var tmp0 = this.l39_1.b2();
      var tmp$ret$0;
      $l$block: {
        // Inline function 'kotlin.collections.firstOrNull' call
        var _iterator__ex2g4s = tmp0.i();
        while (_iterator__ex2g4s.j()) {
          var element = _iterator__ex2g4s.k();
          if (element(storable)) {
            tmp$ret$0 = element;
            break $l$block;
          }
        }
        tmp$ret$0 = null;
      }
      var tmp1_safe_receiver = tmp$ret$0;
      var tmp_0;
      if (tmp1_safe_receiver == null) {
        tmp_0 = null;
      } else {
        // Inline function 'kotlin.let' call
        tmp_0 = this.l39_1.g2(tmp1_safe_receiver);
      }
      tmp = tmp_0;
    } else {
      tmp = tmp0_elvis_lhs;
    }
    var tmp2_elvis_lhs = tmp;
    var tmp_1;
    if (tmp2_elvis_lhs == null) {
      throw NoSuchElementException_init_$Create$("TypeMapImpl: class '" + getKClassFromExpression(storable).l9() + "' not found");
    } else {
      tmp_1 = tmp2_elvis_lhs;
    }
    return tmp_1;
  };
  function XmlReader() {
  }
  //region block: post-declaration
  protoOf(DomXmlReader).j35 = descend$default;
  protoOf(AbstractStorable).n37 = get_isReferencable;
  protoOf(AbstractStorable).q37 = get_isNotReading;
  protoOf(AbstractStorable).l37 = resolutionDone;
  protoOf(AbstractStorable).m37 = allResolutionDone;
  protoOf(AbstractStorable).t37 = readFromStore;
  protoOf(StoreXmlReader).x37 = readStorables$default;
  //endregion
  //region block: init
  Companion_instance_2 = new Companion_2();
  //endregion
  //region block: exports
  _.$_$ = _.$_$ || {};
  _.$_$.a = IOModuleJs_getInstance;
  _.$_$.b = IOModule_getInstance;
  _.$_$.c = StorableCloner_getInstance;
  _.$_$.d = DomXmlReader_init_$Create$;
  _.$_$.e = StoreXmlReader_init_$Create$;
  _.$_$.f = AbstractStorable;
  _.$_$.g = DomXmlReader;
  _.$_$.h = GlobalIdentityCreator;
  _.$_$.i = Reference;
  _.$_$.j = allResolutionDone;
  _.$_$.k = get_isNotReading;
  _.$_$.l = get_isReferencable;
  _.$_$.m = readFromStore;
  _.$_$.n = resolutionDone;
  _.$_$.o = Storable;
  _.$_$.p = StringStorable;
  //endregion
  return _;
}));

//# sourceMappingURL=jabbah-io.js.map
