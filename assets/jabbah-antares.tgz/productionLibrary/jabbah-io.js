(function (factory) {
  if (typeof define === 'function' && define.amd)
    define(['exports', './kotlin-kotlin-stdlib.js', './jabbah-base.js'], factory);
  else if (typeof exports === 'object')
    factory(module.exports, require('./kotlin-kotlin-stdlib.js'), require('./jabbah-base.js'));
  else {
    if (typeof globalThis['kotlin-kotlin-stdlib'] === 'undefined') {
      throw new Error("Error loading module 'jabbah-io'. Its dependency 'kotlin-kotlin-stdlib' was not found. Please, check whether 'kotlin-kotlin-stdlib' is loaded prior to 'jabbah-io'.");
    }
    if (typeof globalThis['jabbah-base'] === 'undefined') {
      throw new Error("Error loading module 'jabbah-io'. Its dependency 'jabbah-base' was not found. Please, check whether 'jabbah-base' is loaded prior to 'jabbah-io'.");
    }
    globalThis['jabbah-io'] = factory(typeof globalThis['jabbah-io'] === 'undefined' ? {} : globalThis['jabbah-io'], globalThis['kotlin-kotlin-stdlib'], globalThis['jabbah-base']);
  }
}(function (_, kotlin_kotlin, kotlin_jabbah_base) {
  'use strict';
  //region block: imports
  var imul = Math.imul;
  var protoOf = kotlin_kotlin.$_$.t7;
  var objectCreate = kotlin_kotlin.$_$.s7;
  var THROW_CCE = kotlin_kotlin.$_$.fb;
  var ensureNotNull = kotlin_kotlin.$_$.mb;
  var equals = kotlin_kotlin.$_$.i9;
  var Stack = kotlin_jabbah_base.$_$.e4;
  var Unit_instance = kotlin_kotlin.$_$.i;
  var asList = kotlin_kotlin.$_$.ac;
  var collectionSizeOrDefault = kotlin_kotlin.$_$.s2;
  var ArrayList_init_$Create$ = kotlin_kotlin.$_$.m;
  var toSet = kotlin_kotlin.$_$.w4;
  var initMetadataForClass = kotlin_kotlin.$_$.d7;
  var VOID = kotlin_kotlin.$_$.b;
  var encodeToByteArray = kotlin_kotlin.$_$.f9;
  var decodeToString = kotlin_kotlin.$_$.c9;
  var isInterface = kotlin_kotlin.$_$.m7;
  var initMetadataForObject = kotlin_kotlin.$_$.i7;
  var KProperty1 = kotlin_kotlin.$_$.v8;
  var getPropertyCallableRef = kotlin_kotlin.$_$.a7;
  var getKClass = kotlin_kotlin.$_$.s8;
  var logger = kotlin_jabbah_base.$_$.q7;
  var Exception = kotlin_kotlin.$_$.za;
  var AbstractModule = kotlin_jabbah_base.$_$.d7;
  var BaseModuleJs_getInstance = kotlin_jabbah_base.$_$.m;
  var initMetadataForCompanion = kotlin_kotlin.$_$.e7;
  var ArrayList_init_$Create$_0 = kotlin_kotlin.$_$.n;
  var getKClassFromExpression = kotlin_kotlin.$_$.r8;
  var IllegalArgumentException_init_$Create$ = kotlin_kotlin.$_$.b1;
  var BaseModule_getInstance = kotlin_jabbah_base.$_$.n;
  var toString = kotlin_kotlin.$_$.tb;
  var getStringHashCode = kotlin_kotlin.$_$.b7;
  var hashCode = kotlin_kotlin.$_$.c7;
  var getBooleanHashCode = kotlin_kotlin.$_$.x6;
  var equals_0 = kotlin_kotlin.$_$.u6;
  var LinkedHashSet_init_$Create$ = kotlin_kotlin.$_$.r;
  var DirectedGraph = kotlin_jabbah_base.$_$.a4;
  var LinkedHashMap_init_$Create$ = kotlin_kotlin.$_$.q;
  var TopologicalSort_instance = kotlin_jabbah_base.$_$.b;
  var System_getInstance = kotlin_jabbah_base.$_$.c1;
  var initMetadataForInterface = kotlin_kotlin.$_$.g7;
  var toInt = kotlin_kotlin.$_$.ka;
  var IllegalArgumentException_init_$Create$_0 = kotlin_kotlin.$_$.z;
  var emptyList = kotlin_kotlin.$_$.c3;
  var toDouble = kotlin_kotlin.$_$.ia;
  var toLong = kotlin_kotlin.$_$.ma;
  var toULong = kotlin_kotlin.$_$.pa;
  var charSequenceLength = kotlin_kotlin.$_$.r6;
  var _Char___init__impl__6a9atx = kotlin_kotlin.$_$.n1;
  var indexOf = kotlin_kotlin.$_$.k9;
  var substring = kotlin_kotlin.$_$.ga;
  var substring_0 = kotlin_kotlin.$_$.fa;
  var Point2D = kotlin_jabbah_base.$_$.e6;
  var isCharSequence = kotlin_kotlin.$_$.k7;
  var trim = kotlin_kotlin.$_$.sa;
  var toString_0 = kotlin_kotlin.$_$.v7;
  var split = kotlin_kotlin.$_$.z9;
  var UUID = kotlin_jabbah_base.$_$.p7;
  var sorted = kotlin_kotlin.$_$.n4;
  var formatRounded = kotlin_jabbah_base.$_$.q6;
  var StringUtils_getInstance = kotlin_jabbah_base.$_$.b1;
  var ULong__toString_impl_f9au7k = kotlin_kotlin.$_$.b2;
  var StringBuilder_init_$Create$ = kotlin_kotlin.$_$.v;
  var joinToString = kotlin_kotlin.$_$.o3;
  var NoSuchElementException_init_$Create$ = kotlin_kotlin.$_$.h1;
  //endregion
  //region block: pre-declaration
  function descend$default(index, $super) {
    index = index === VOID ? 1 : index;
    var tmp;
    if ($super === VOID) {
      this.y35(index);
      tmp = Unit_instance;
    } else {
      tmp = $super.y35.call(this, index);
    }
    return tmp;
  }
  initMetadataForInterface(XmlReader, 'XmlReader');
  initMetadataForClass(DomXmlReader, 'DomXmlReader', VOID, VOID, [XmlReader]);
  initMetadataForClass(AbstractStorableCloner, 'AbstractStorableCloner');
  initMetadataForObject(StorableCloner, 'StorableCloner', VOID, AbstractStorableCloner);
  initMetadataForClass(DomXmlWriter, 'DomXmlWriter');
  initMetadataForObject(IOModuleJs, 'IOModuleJs', VOID, AbstractModule);
  initMetadataForCompanion(Companion);
  initMetadataForClass(Buffer, 'Buffer');
  initMetadataForClass(GlobalIdentityCreator, 'GlobalIdentityCreator', GlobalIdentityCreator);
  initMetadataForObject(IOModule, 'IOModule', VOID, AbstractModule);
  initMetadataForClass(Reference, 'Reference', Reference);
  initMetadataForCompanion(Companion_0);
  initMetadataForClass(ReferenceResolverImpl, 'ReferenceResolverImpl', ReferenceResolverImpl);
  function get_isReferencable() {
    return true;
  }
  function get_isNotReading() {
    return !this.f38();
  }
  function resolutionDone() {
  }
  function allResolutionDone() {
  }
  function readFromStore(reader) {
    try {
      this.e38(true);
      this.i38(reader);
    }finally {
      this.e38(false);
    }
  }
  initMetadataForInterface(Storable, 'Storable');
  initMetadataForClass(AbstractStorable, 'AbstractStorable', VOID, VOID, [Storable]);
  function readStorables$default(name, afterReadCallback, $super) {
    afterReadCallback = afterReadCallback === VOID ? null : afterReadCallback;
    return $super === VOID ? this.m38(name, afterReadCallback) : $super.m38.call(this, name, afterReadCallback);
  }
  initMetadataForInterface(StoreReader, 'StoreReader');
  initMetadataForCompanion(Companion_1);
  initMetadataForClass(StoreXmlReader, 'StoreXmlReader', VOID, VOID, [StoreReader]);
  initMetadataForCompanion(Companion_2);
  initMetadataForClass(StoreXmlWriter, 'StoreXmlWriter');
  initMetadataForClass(StringStorable, 'StringStorable', StringStorable, AbstractStorable);
  initMetadataForClass(TypeMapImpl, 'TypeMapImpl', TypeMapImpl);
  //endregion
  function DomXmlReader_init_$Init$(str, $this) {
    DomXmlReader.call($this, (new DOMParser()).parseFromString(str, 'application/xml'));
    return $this;
  }
  function DomXmlReader_init_$Create$(str) {
    return DomXmlReader_init_$Init$(str, objectCreate(protoOf(DomXmlReader)));
  }
  function getChildElement($this, name) {
    var children = $this.q35_1.rv().childNodes;
    var inductionVariable = 0;
    var last = children.length;
    if (inductionVariable < last)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        // Inline function 'org.w3c.dom.get' call
        // Inline function 'kotlin.js.asDynamic' call
        var tmp$ret$0 = children[i];
        if (equals(ensureNotNull(tmp$ret$0).nodeName, name, true)) {
          // Inline function 'org.w3c.dom.get' call
          // Inline function 'kotlin.js.asDynamic' call
          var tmp = children[i];
          return (tmp == null ? true : tmp instanceof Element) ? tmp : THROW_CCE();
        }
      }
       while (inductionVariable < last);
    return null;
  }
  function DomXmlReader(document) {
    this.q35_1 = new Stack();
    this.q35_1.yv(ensureNotNull(document.documentElement));
  }
  protoOf(DomXmlReader).r35 = function () {
    return this.q35_1.rv().tagName;
  };
  protoOf(DomXmlReader).s35 = function (name) {
    return ensureNotNull(this.q35_1.rv().getAttribute(name));
  };
  protoOf(DomXmlReader).t35 = function (name) {
    return !(this.q35_1.rv().getAttribute(name) == null);
  };
  protoOf(DomXmlReader).u35 = function (name) {
    return !(getChildElement(this, name) == null);
  };
  protoOf(DomXmlReader).v35 = function () {
    // Inline function 'kotlin.collections.map' call
    var this_0 = asList(this.q35_1.rv().children);
    // Inline function 'kotlin.collections.mapTo' call
    var destination = ArrayList_init_$Create$(collectionSizeOrDefault(this_0, 10));
    var _iterator__ex2g4s = this_0.i();
    while (_iterator__ex2g4s.j()) {
      var item = _iterator__ex2g4s.k();
      var tmp$ret$2 = item.nodeName;
      destination.h(tmp$ret$2);
    }
    return toSet(destination);
  };
  protoOf(DomXmlReader).w35 = function () {
    return this.q35_1.rv().childElementCount;
  };
  protoOf(DomXmlReader).x35 = function (name) {
    this.q35_1.yv(ensureNotNull(getChildElement(this, name)));
  };
  protoOf(DomXmlReader).y35 = function (index) {
    // Inline function 'org.w3c.dom.get' call
    // Inline function 'kotlin.js.asDynamic' call
    var tmp$ret$0 = this.q35_1.rv().children[index - 1 | 0];
    this.q35_1.yv(ensureNotNull(tmp$ret$0));
  };
  protoOf(DomXmlReader).a36 = function () {
    this.q35_1.zv();
  };
  protoOf(DomXmlReader).b36 = function (name) {
    return ensureNotNull(ensureNotNull(getChildElement(this, name)).textContent);
  };
  function StorableCloner$serializeImpl$lambda($s) {
    return function (it) {
      $s._v = it;
      return Unit_instance;
    };
  }
  function StorableCloner() {
    StorableCloner_instance = this;
    AbstractStorableCloner.call(this);
  }
  protoOf(StorableCloner).c36 = function (storable, identityProvider) {
    var s = {_v: ''};
    var xmlWriter = new DomXmlWriter(StorableCloner$serializeImpl$lambda(s));
    var writer = new StoreXmlWriter(xmlWriter, IOModule_getInstance().e36_1, identityProvider);
    writer.k36(storable);
    var byteArray = encodeToByteArray(s._v);
    return new Buffer(byteArray, byteArray.length);
  };
  protoOf(StorableCloner).l36 = function (s, referenceResolver) {
    var xmlReader = DomXmlReader_init_$Create$(decodeToString(s.m36_1));
    var reader = new StoreXmlReader(xmlReader, IOModule_getInstance().e36_1, referenceResolver);
    var tmp = reader.r36();
    return isInterface(tmp, Storable) ? tmp : THROW_CCE();
  };
  var StorableCloner_instance;
  function StorableCloner_getInstance() {
    if (StorableCloner_instance == null)
      new StorableCloner();
    return StorableCloner_instance;
  }
  function _get_LOG__e5r759($this) {
    var tmp0 = $this.w36_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('LOG', 1, tmp, DomXmlWriter$_get_LOG_$ref_sii8kg(), null);
    return tmp0.j2();
  }
  function DomXmlWriter$_get_LOG_$ref_sii8kg() {
    return function (p0) {
      return _get_LOG__e5r759(p0);
    };
  }
  function DomXmlWriter(consumer) {
    this.v36_1 = consumer;
    this.w36_1 = logger(getKClass(DomXmlWriter));
    this.x36_1 = null;
    this.y36_1 = new Stack();
  }
  protoOf(DomXmlWriter).z36 = function () {
    return this.y36_1.wv();
  };
  protoOf(DomXmlWriter).a37 = function (name) {
    try {
      if (this.z36()) {
        this.x36_1 = document.implementation.createDocument(null, name, null);
        this.y36_1.yv(ensureNotNull(ensureNotNull(this.x36_1).documentElement));
      } else {
        var child = ensureNotNull(this.x36_1).createElement(name);
        this.y36_1.rv().appendChild(child);
        this.y36_1.yv(child);
      }
    } catch ($p) {
      if ($p instanceof Error) {
        var e = $p;
        _get_LOG__e5r759(this).ml('DomXmlWriter: Error while descending to ' + name);
      } else {
        throw $p;
      }
    }
  };
  protoOf(DomXmlWriter).a36 = function () {
    this.y36_1.zv();
  };
  protoOf(DomXmlWriter).y7 = function () {
    try {
      this.v36_1((new XMLSerializer()).serializeToString(ensureNotNull(this.x36_1)));
    } catch ($p) {
      if ($p instanceof Exception) {
        var e = $p;
        _get_LOG__e5r759(this).ml('Error in flushing Document to XML string: ' + e.message);
      } else {
        throw $p;
      }
    }
  };
  protoOf(DomXmlWriter).b37 = function (name, value) {
    this.y36_1.rv().setAttribute(name, value);
  };
  protoOf(DomXmlWriter).c37 = function (name, text) {
    this.a37(name);
    this.y36_1.rv().textContent = text;
    this.a36();
  };
  function IOModuleJs() {
    IOModuleJs_instance = this;
    AbstractModule.call(this);
  }
  protoOf(IOModuleJs).to = function () {
    BaseModuleJs_getInstance().vo();
    IOModule_getInstance().vo();
  };
  var IOModuleJs_instance;
  function IOModuleJs_getInstance() {
    if (IOModuleJs_instance == null)
      new IOModuleJs();
    return IOModuleJs_instance;
  }
  function _get_LOG__e5r759_0($this) {
    var tmp0 = $this.e37_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('LOG', 1, tmp, AbstractStorableCloner$Companion$_get_LOG_$ref_km03u3(), null);
    return tmp0.j2();
  }
  function AbstractStorableCloner$Companion$_get_LOG_$ref_km03u3() {
    return function (p0) {
      return _get_LOG__e5r759_0(p0);
    };
  }
  function Companion() {
    Companion_instance = this;
    this.e37_1 = logger(getKClass(AbstractStorableCloner));
  }
  var Companion_instance;
  function Companion_getInstance() {
    if (Companion_instance == null)
      new Companion();
    return Companion_instance;
  }
  function Buffer(data, length) {
    this.m36_1 = data;
    this.n36_1 = length;
  }
  function AbstractStorableCloner() {
    Companion_getInstance();
  }
  protoOf(AbstractStorableCloner).s36 = function (storable) {
    return this.u36(storable, new GlobalIdentityCreator());
  };
  protoOf(AbstractStorableCloner).t36 = function (storable) {
    return this.u36(storable, new GlobalIdentityCreator());
  };
  protoOf(AbstractStorableCloner).u36 = function (storable, identityProvider) {
    try {
      var data = this.c36(storable, identityProvider);
      return this.l36(data, new ReferenceResolverImpl(identityProvider));
    } catch ($p) {
      if ($p instanceof Error) {
        var x = $p;
        _get_LOG__e5r759_0(Companion_getInstance()).ml('Error while cloning Storable: ' + x.message);
        throw x;
      } else {
        throw $p;
      }
    }
  };
  function GlobalIdentityCreator() {
    var tmp = this;
    // Inline function 'kotlin.collections.mutableListOf' call
    tmp.f37_1 = ArrayList_init_$Create$_0();
  }
  protoOf(GlobalIdentityCreator).g37 = function (storable) {
    if (!this.f37_1.n(storable)) {
      this.f37_1.h(storable);
    }
    return this.f37_1.p(storable);
  };
  protoOf(GlobalIdentityCreator).h37 = function (storable) {
    if (!this.f37_1.n(storable)) {
      throw IllegalArgumentException_init_$Create$('storable ' + getKClassFromExpression(storable).m9() + ' not available');
    }
    return this.f37_1.p(storable);
  };
  protoOf(GlobalIdentityCreator).i37 = function (globalId) {
    if (0 <= globalId ? globalId < this.f37_1.o() : false) {
      return this.f37_1.l(globalId);
    }
    return null;
  };
  function configureTypeMap($this, typeMap) {
    typeMap.j37('string', getKClass(StringStorable));
  }
  function IOModule() {
    IOModule_instance = this;
    AbstractModule.call(this);
    this.e36_1 = new TypeMapImpl();
  }
  protoOf(IOModule).to = function () {
    BaseModule_getInstance().vo();
    configureTypeMap(this, this.e36_1);
  };
  var IOModule_instance;
  function IOModule_getInstance() {
    if (IOModule_instance == null)
      new IOModule();
    return IOModule_instance;
  }
  function Reference(name, referenceId, additionalInfo, resolveAfter, dummy) {
    name = name === VOID ? null : name;
    referenceId = referenceId === VOID ? 0 : referenceId;
    additionalInfo = additionalInfo === VOID ? null : additionalInfo;
    resolveAfter = resolveAfter === VOID ? null : resolveAfter;
    dummy = dummy === VOID ? false : dummy;
    this.k37_1 = name;
    this.l37_1 = referenceId;
    this.m37_1 = additionalInfo;
    this.n37_1 = resolveAfter;
    this.o37_1 = dummy;
  }
  protoOf(Reference).toString = function () {
    return 'Reference(name=' + this.k37_1 + ', referenceId=' + this.l37_1 + ', additionalInfo=' + toString(this.m37_1) + ', resolveAfter=' + toString(this.n37_1) + ', dummy=' + this.o37_1 + ')';
  };
  protoOf(Reference).hashCode = function () {
    var result = this.k37_1 == null ? 0 : getStringHashCode(this.k37_1);
    result = imul(result, 31) + this.l37_1 | 0;
    result = imul(result, 31) + (this.m37_1 == null ? 0 : hashCode(this.m37_1)) | 0;
    result = imul(result, 31) + (this.n37_1 == null ? 0 : hashCode(this.n37_1)) | 0;
    result = imul(result, 31) + getBooleanHashCode(this.o37_1) | 0;
    return result;
  };
  protoOf(Reference).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof Reference))
      return false;
    if (!(this.k37_1 == other.k37_1))
      return false;
    if (!(this.l37_1 === other.l37_1))
      return false;
    if (!equals_0(this.m37_1, other.m37_1))
      return false;
    if (!equals_0(this.n37_1, other.n37_1))
      return false;
    if (!(this.o37_1 === other.o37_1))
      return false;
    return true;
  };
  function _get_LOG__e5r759_1($this) {
    var tmp0 = $this.p37_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('LOG', 1, tmp, ReferenceResolverImpl$Companion$_get_LOG_$ref_qmt5ox(), null);
    return tmp0.j2();
  }
  function ReferenceResolverImpl$Companion$_get_LOG_$ref_qmt5ox() {
    return function (p0) {
      return _get_LOG__e5r759_1(p0);
    };
  }
  function Companion_0() {
    Companion_instance_0 = this;
    this.p37_1 = logger(getKClass(ReferenceResolverImpl));
  }
  var Companion_instance_0;
  function Companion_getInstance_0() {
    if (Companion_instance_0 == null)
      new Companion_0();
    return Companion_instance_0;
  }
  function addDummyReferences($this) {
    // Inline function 'kotlin.collections.mutableSetOf' call
    var set = LinkedHashSet_init_$Create$();
    var _iterator__ex2g4s = $this.t37_1.c2().i();
    while (_iterator__ex2g4s.j()) {
      var references = _iterator__ex2g4s.k();
      var _iterator__ex2g4s_0 = references.i();
      while (_iterator__ex2g4s_0.j()) {
        var reference = _iterator__ex2g4s_0.k();
        var tmp0_safe_receiver = reference.n37_1;
        if (tmp0_safe_receiver == null)
          null;
        else {
          // Inline function 'kotlin.collections.forEach' call
          var _iterator__ex2g4s_1 = tmp0_safe_receiver.i();
          while (_iterator__ex2g4s_1.j()) {
            var element = _iterator__ex2g4s_1.k();
            var storable = $this.u37(element);
            if (!(storable == null) && !$this.s37_1.n(storable)) {
              set.h(storable);
            }
          }
        }
      }
    }
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s_2 = set.i();
    while (_iterator__ex2g4s_2.j()) {
      var element_0 = _iterator__ex2g4s_2.k();
      $this.v37(element_0, new Reference('dummy', VOID, VOID, VOID, true));
    }
  }
  function buildGraph($this) {
    var graph = new DirectedGraph();
    addDummyReferences($this);
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = $this.s37_1.i();
    while (_iterator__ex2g4s.j()) {
      var element = _iterator__ex2g4s.k();
      graph.jv(element);
    }
    var _iterator__ex2g4s_0 = $this.t37_1.b2().i();
    while (_iterator__ex2g4s_0.j()) {
      var storable = _iterator__ex2g4s_0.k();
      var _iterator__ex2g4s_1 = ensureNotNull($this.t37_1.g2(storable)).i();
      while (_iterator__ex2g4s_1.j()) {
        var reference = _iterator__ex2g4s_1.k();
        var tmp0_safe_receiver = reference.n37_1;
        if (tmp0_safe_receiver == null)
          null;
        else {
          // Inline function 'kotlin.collections.forEach' call
          var _iterator__ex2g4s_2 = tmp0_safe_receiver.i();
          while (_iterator__ex2g4s_2.j()) {
            var element_0 = _iterator__ex2g4s_2.k();
            var predecessor = $this.u37(element_0);
            if (!(predecessor == null)) {
              graph.kv(predecessor, storable);
            }
          }
        }
      }
    }
    return graph;
  }
  function ReferenceResolverImpl(identityProvider) {
    Companion_getInstance_0();
    identityProvider = identityProvider === VOID ? null : identityProvider;
    this.q37_1 = identityProvider;
    var tmp = this;
    // Inline function 'kotlin.collections.mutableMapOf' call
    tmp.r37_1 = LinkedHashMap_init_$Create$();
    var tmp_0 = this;
    // Inline function 'kotlin.collections.mutableListOf' call
    tmp_0.s37_1 = ArrayList_init_$Create$_0();
    var tmp_1 = this;
    // Inline function 'kotlin.collections.mutableMapOf' call
    tmp_1.t37_1 = LinkedHashMap_init_$Create$();
  }
  protoOf(ReferenceResolverImpl).w37 = function (globalId, storable) {
    _get_LOG__e5r759_1(Companion_getInstance_0()).ql('add storable ' + globalId);
    // Inline function 'kotlin.collections.set' call
    this.r37_1.y1(globalId, storable);
  };
  protoOf(ReferenceResolverImpl).u37 = function (globalId) {
    _get_LOG__e5r759_1(Companion_getInstance_0()).ql('getStorable for id ' + globalId);
    var tmp = this.r37_1.g2(globalId);
    var tmp0_elvis_lhs = (tmp == null ? true : isInterface(tmp, Storable)) ? tmp : THROW_CCE();
    var tmp_0;
    if (tmp0_elvis_lhs == null) {
      var tmp1_safe_receiver = this.q37_1;
      var tmp_1 = tmp1_safe_receiver == null ? null : tmp1_safe_receiver.i37(globalId);
      tmp_0 = (tmp_1 == null ? true : isInterface(tmp_1, Storable)) ? tmp_1 : THROW_CCE();
    } else {
      tmp_0 = tmp0_elvis_lhs;
    }
    return tmp_0;
  };
  protoOf(ReferenceResolverImpl).x37 = function (storable) {
    var tmp0 = this.r37_1.d2();
    var tmp$ret$0;
    $l$block: {
      // Inline function 'kotlin.collections.firstOrNull' call
      var _iterator__ex2g4s = tmp0.i();
      while (_iterator__ex2g4s.j()) {
        var element = _iterator__ex2g4s.k();
        if (element.j2() === storable) {
          tmp$ret$0 = element;
          break $l$block;
        }
      }
      tmp$ret$0 = null;
    }
    var tmp0_safe_receiver = tmp$ret$0;
    var tmp1_elvis_lhs = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.i2();
    var tmp;
    if (tmp1_elvis_lhs == null) {
      var tmp2_safe_receiver = this.q37_1;
      tmp = tmp2_safe_receiver == null ? null : tmp2_safe_receiver.h37(storable);
    } else {
      tmp = tmp1_elvis_lhs;
    }
    var tmp3_elvis_lhs = tmp;
    var tmp_0;
    if (tmp3_elvis_lhs == null) {
      throw IllegalArgumentException_init_$Create$('storable ' + getKClassFromExpression(storable).m9() + ' not available');
    } else {
      tmp_0 = tmp3_elvis_lhs;
    }
    return tmp_0;
  };
  protoOf(ReferenceResolverImpl).v37 = function (requester, reference) {
    var list = this.t37_1.g2(requester);
    if (list == null) {
      // Inline function 'kotlin.collections.mutableListOf' call
      list = ArrayList_init_$Create$_0();
      var tmp0 = this.t37_1;
      // Inline function 'kotlin.collections.set' call
      var value = list;
      tmp0.y1(requester, value);
    }
    if (!this.s37_1.n(requester)) {
      this.s37_1.h(requester);
    }
    if (!list.n(reference)) {
      list.h(reference);
    }
  };
  protoOf(ReferenceResolverImpl).y37 = function () {
    this.z37(this);
  };
  protoOf(ReferenceResolverImpl).z37 = function (referenceResolver) {
    var graph = buildGraph(this);
    var list = TopologicalSort_instance.bw(graph);
    var _iterator__ex2g4s = list.i();
    while (_iterator__ex2g4s.j()) {
      var storable = _iterator__ex2g4s.k();
      var _iterator__ex2g4s_0 = ensureNotNull(this.t37_1.g2(storable)).i();
      while (_iterator__ex2g4s_0.j()) {
        var reference = _iterator__ex2g4s_0.k();
        if (!reference.o37_1) {
          try {
            storable.a38(reference, referenceResolver);
          } catch ($p) {
            if ($p instanceof Error) {
              var e = $p;
              _get_LOG__e5r759_1(Companion_getInstance_0()).ml("error while resolving class '" + System_getInstance().yl(storable) + "': " + e.message);
              throw e;
            } else {
              throw $p;
            }
          }
        }
      }
    }
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s_1 = list.i();
    while (_iterator__ex2g4s_1.j()) {
      var element = _iterator__ex2g4s_1.k();
      element.b38();
    }
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s_2 = list.i();
    while (_iterator__ex2g4s_2.j()) {
      var element_0 = _iterator__ex2g4s_2.k();
      element_0.c38();
    }
  };
  function Storable() {
  }
  function AbstractStorable() {
    this.k38_1 = false;
  }
  protoOf(AbstractStorable).e38 = function (_set____db54di) {
    this.k38_1 = _set____db54di;
  };
  protoOf(AbstractStorable).f38 = function () {
    return this.k38_1;
  };
  function StoreReader() {
  }
  function _get_LOG__e5r759_2($this) {
    var tmp0 = $this.c39_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('LOG', 1, tmp, StoreXmlReader$Companion$_get_LOG_$ref_jqqigp(), null);
    return tmp0.j2();
  }
  function StoreXmlReader$Companion$_get_LOG_$ref_jqqigp() {
    return function (p0) {
      return _get_LOG__e5r759_2(p0);
    };
  }
  function Companion_1() {
    Companion_instance_1 = this;
    this.c39_1 = logger(getKClass(StoreXmlReader));
  }
  var Companion_instance_1;
  function Companion_getInstance_1() {
    if (Companion_instance_1 == null)
      new Companion_1();
    return Companion_instance_1;
  }
  function StoreXmlReader_init_$Init$(xmlReader, $this) {
    StoreXmlReader.call($this, xmlReader, IOModule_getInstance().e36_1, new ReferenceResolverImpl());
    return $this;
  }
  function StoreXmlReader_init_$Create$(xmlReader) {
    return StoreXmlReader_init_$Init$(xmlReader, objectCreate(protoOf(StoreXmlReader)));
  }
  function readStorableImpl($this) {
    var storable = $this.p36_1.d39($this.o36_1.r35());
    var tmp0_safe_receiver = readGlobalId($this);
    if (tmp0_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      $this.q36_1.w37(tmp0_safe_receiver, storable);
    }
    storable.j38($this);
    return isInterface(storable, Storable) ? storable : THROW_CCE();
  }
  function readGlobalId($this) {
    if (!$this.o36_1.t35('_id')) {
      return null;
    }
    return toInt($this.o36_1.s35('_id'));
  }
  function StoreXmlReader(xmlReader, typeMap, referenceResolver) {
    Companion_getInstance_1();
    this.o36_1 = xmlReader;
    this.p36_1 = typeMap;
    this.q36_1 = referenceResolver;
  }
  protoOf(StoreXmlReader).v37 = function (requester, reference) {
    this.q36_1.v37(requester, reference);
  };
  protoOf(StoreXmlReader).t35 = function (name) {
    return this.o36_1.t35(name);
  };
  protoOf(StoreXmlReader).u35 = function (name) {
    return this.o36_1.u35(name);
  };
  protoOf(StoreXmlReader).v35 = function () {
    return this.o36_1.v35();
  };
  protoOf(StoreXmlReader).x37 = function (storable) {
    return this.q36_1.x37(storable);
  };
  protoOf(StoreXmlReader).r36 = function () {
    var storable = readStorableImpl(this);
    this.q36_1.y37();
    return storable;
  };
  protoOf(StoreXmlReader).l38 = function (name) {
    if (!this.o36_1.u35(name)) {
      _get_LOG__e5r759_2(Companion_getInstance_1()).ml("no element in '" + this.o36_1.r35() + "' with name '" + name + "'");
      throw IllegalArgumentException_init_$Create$_0();
    }
    this.o36_1.x35(name);
    this.o36_1.z35();
    var storable = readStorableImpl(this);
    this.o36_1.a36();
    this.o36_1.a36();
    return storable;
  };
  protoOf(StoreXmlReader).m38 = function (name, afterReadCallback) {
    if (!this.o36_1.u35(name)) {
      // Inline function 'kotlin.collections.listOf' call
      return emptyList();
    }
    // Inline function 'kotlin.collections.mutableListOf' call
    var storables = ArrayList_init_$Create$_0();
    this.o36_1.x35(name);
    var inductionVariable = 1;
    var last = this.o36_1.w35();
    if (inductionVariable <= last)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        this.o36_1.y35(i);
        var tmp = readStorableImpl(this);
        var s = isInterface(tmp, Storable) ? tmp : THROW_CCE();
        storables.h(s);
        if (afterReadCallback == null)
          null;
        else
          afterReadCallback(s);
        this.o36_1.a36();
      }
       while (!(i === last));
    this.o36_1.a36();
    return storables;
  };
  protoOf(StoreXmlReader).o38 = function (name) {
    // Inline function 'kotlin.collections.mutableMapOf' call
    var map = LinkedHashMap_init_$Create$();
    this.o36_1.x35(name);
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = this.v35().i();
    while (_iterator__ex2g4s.j()) {
      var element = _iterator__ex2g4s.k();
      // Inline function 'kotlin.collections.set' call
      var value = this.l38(element);
      map.y1(element, value);
    }
    this.o36_1.a36();
    return map;
  };
  protoOf(StoreXmlReader).p38 = function (name) {
    return toInt(this.o36_1.s35(name));
  };
  protoOf(StoreXmlReader).q38 = function (name) {
    return toDouble(this.o36_1.s35(name));
  };
  protoOf(StoreXmlReader).r38 = function (name) {
    return this.o36_1.s35(name);
  };
  protoOf(StoreXmlReader).s38 = function (name) {
    if (this.t35(name)) {
      return this.r38(name);
    }
    return null;
  };
  protoOf(StoreXmlReader).t38 = function (name) {
    var b = this.o36_1.s35(name);
    var tmp;
    if (b === '1') {
      tmp = true;
    } else {
      // Inline function 'kotlin.text.lowercase' call
      // Inline function 'kotlin.js.asDynamic' call
      tmp = b.toLowerCase() === 'true';
    }
    return tmp;
  };
  protoOf(StoreXmlReader).u38 = function (name) {
    return toLong(this.o36_1.s35(name));
  };
  protoOf(StoreXmlReader).v38 = function (name) {
    return toULong(this.o36_1.s35(name));
  };
  protoOf(StoreXmlReader).w38 = function (name) {
    // Inline function 'kotlin.collections.mutableListOf' call
    var points = ArrayList_init_$Create$_0();
    var list = this.r38(name);
    try {
      $l$loop: while (true) {
        // Inline function 'kotlin.text.isNotEmpty' call
        var this_0 = list;
        if (!(charSequenceLength(this_0) > 0)) {
          break $l$loop;
        }
        var i = indexOf(list, _Char___init__impl__6a9atx(44));
        var j = indexOf(list, _Char___init__impl__6a9atx(32));
        var x = toDouble(substring(list, 0, i));
        var y = toDouble(!(j === -1) ? substring(list, i + 1 | 0, j) : substring_0(list, i + 1 | 0));
        points.h(new Point2D(x, y));
        var tmp;
        if (!(j === -1)) {
          // Inline function 'kotlin.text.trim' call
          var this_1 = substring_0(list, j);
          tmp = toString_0(trim(isCharSequence(this_1) ? this_1 : THROW_CCE()));
        } else {
          tmp = '';
        }
        list = tmp;
      }
      return points;
    } catch ($p) {
      if ($p instanceof Error) {
        var e = $p;
        _get_LOG__e5r759_2(Companion_getInstance_1()).ml("Parsing of point list '" + name + "' failed with '" + e.message + "'");
        throw e;
      } else {
        throw $p;
      }
    }
  };
  protoOf(StoreXmlReader).x38 = function (outerElem, innerElem, attribute) {
    this.o36_1.x35(outerElem);
    this.o36_1.x35(innerElem);
    var list = this.w38(attribute);
    this.o36_1.a36();
    this.o36_1.a36();
    return list;
  };
  protoOf(StoreXmlReader).y38 = function (name) {
    this.o36_1.x35(name);
    this.o36_1.x35('point');
    var p = new Point2D(this.q38('x'), this.q38('y'));
    this.o36_1.a36();
    this.o36_1.a36();
    return p;
  };
  protoOf(StoreXmlReader).z38 = function (name) {
    // Inline function 'kotlin.collections.map' call
    var this_0 = split(this.o36_1.s35(name), [',']);
    // Inline function 'kotlin.collections.mapTo' call
    var destination = ArrayList_init_$Create$(collectionSizeOrDefault(this_0, 10));
    var _iterator__ex2g4s = this_0.i();
    while (_iterator__ex2g4s.j()) {
      var item = _iterator__ex2g4s.k();
      var tmp$ret$2 = toInt(item);
      destination.h(tmp$ret$2);
    }
    return destination;
  };
  protoOf(StoreXmlReader).a39 = function (name) {
    // Inline function 'kotlin.collections.map' call
    var this_0 = split(this.o36_1.s35(name), [',']);
    // Inline function 'kotlin.collections.mapTo' call
    var destination = ArrayList_init_$Create$(collectionSizeOrDefault(this_0, 10));
    var _iterator__ex2g4s = this_0.i();
    while (_iterator__ex2g4s.j()) {
      var item = _iterator__ex2g4s.k();
      var tmp$ret$2 = new UUID(item);
      destination.h(tmp$ret$2);
    }
    return toSet(destination);
  };
  protoOf(StoreXmlReader).b39 = function (name) {
    return this.o36_1.b36(name);
  };
  function Companion_2() {
    this.e39_1 = 1.0E7;
  }
  var Companion_instance_2;
  function Companion_getInstance_2() {
    return Companion_instance_2;
  }
  function StoreXmlWriter$_init_$lambda_gzhh8e(_unused_var__etf5q3, _unused_var__etf5q3_0) {
    return true;
  }
  function StoreXmlWriter(xmlWriter, typeMap, identityProvider, filter) {
    var tmp;
    if (filter === VOID) {
      tmp = StoreXmlWriter$_init_$lambda_gzhh8e;
    } else {
      tmp = filter;
    }
    filter = tmp;
    this.f36_1 = xmlWriter;
    this.g36_1 = typeMap;
    this.h36_1 = identityProvider;
    this.i36_1 = filter;
    this.j36_1 = 0;
  }
  protoOf(StoreXmlWriter).g37 = function (storable) {
    return this.h36_1.g37(storable);
  };
  protoOf(StoreXmlWriter).h37 = function (storable) {
    return this.h36_1.h37(storable);
  };
  protoOf(StoreXmlWriter).i37 = function (globalId) {
    return this.h36_1.i37(globalId);
  };
  protoOf(StoreXmlWriter).k36 = function (storable) {
    var type = this.g36_1.f39(storable);
    this.f36_1.a37(type);
    if (storable.d38()) {
      this.f36_1.b37('_id', this.g37(storable).toString());
    }
    storable.h38(this);
    this.f36_1.a36();
    if (this.f36_1.z36()) {
      this.f36_1.y7();
    }
  };
  protoOf(StoreXmlWriter).g39 = function (name, storable) {
    this.f36_1.a37(name);
    this.k36(storable);
    this.f36_1.a36();
  };
  protoOf(StoreXmlWriter).h39 = function (name, iterator) {
    try {
      this.f36_1.a37(name);
      this.j36_1 = this.j36_1 + 1 | 0;
      // Inline function 'kotlin.collections.iterator' call
      var _iterator__ex2g4s = iterator;
      while (_iterator__ex2g4s.j()) {
        var storable = _iterator__ex2g4s.k();
        if (this.i36_1(storable, this.j36_1 <= 1)) {
          this.k36(storable);
        }
      }
      this.f36_1.a36();
    }finally {
      this.j36_1 = this.j36_1 - 1 | 0;
    }
  };
  protoOf(StoreXmlWriter).i39 = function (name, map) {
    this.f36_1.a37(name);
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = sorted(map.b2()).i();
    while (_iterator__ex2g4s.j()) {
      var element = _iterator__ex2g4s.k();
      this.g39(element, ensureNotNull(map.g2(element)));
    }
    this.f36_1.a36();
  };
  protoOf(StoreXmlWriter).j39 = function (name, value) {
    this.f36_1.b37(name, value.toString());
  };
  protoOf(StoreXmlWriter).k39 = function (name, value) {
    this.f36_1.b37(name, formatRounded(value));
  };
  protoOf(StoreXmlWriter).l39 = function (name, value) {
    this.f36_1.b37(name, formatRounded(value, 1.0E7));
  };
  protoOf(StoreXmlWriter).m39 = function (name, value) {
    this.f36_1.b37(name, value);
  };
  protoOf(StoreXmlWriter).n39 = function (name, value) {
    if (StringUtils_getInstance().lu(value)) {
      this.m39(name, ensureNotNull(value));
    }
  };
  protoOf(StoreXmlWriter).o39 = function (name, value) {
    this.f36_1.b37(name, value ? 'true' : 'false');
  };
  protoOf(StoreXmlWriter).p39 = function (name, value) {
    this.f36_1.b37(name, value.toString());
  };
  protoOf(StoreXmlWriter).q39 = function (name, value) {
    this.f36_1.b37(name, ULong__toString_impl_f9au7k(value));
  };
  protoOf(StoreXmlWriter).r39 = function (name, points) {
    var list = StringBuilder_init_$Create$();
    var inductionVariable = 0;
    var last = points.o() - 1 | 0;
    if (inductionVariable <= last)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        list.i7(formatRounded(points.l(i).kn_1) + ',' + formatRounded(points.l(i).ln_1) + ' ');
      }
       while (inductionVariable <= last);
    // Inline function 'kotlin.text.trim' call
    var this_0 = list.toString();
    var tmp$ret$0 = toString_0(trim(isCharSequence(this_0) ? this_0 : THROW_CCE()));
    this.m39(name, tmp$ret$0);
  };
  protoOf(StoreXmlWriter).s39 = function (outerElem, innerElem, attribute, points) {
    this.f36_1.a37(outerElem);
    this.f36_1.a37(innerElem);
    this.r39(attribute, points);
    this.f36_1.a36();
    this.f36_1.a36();
  };
  protoOf(StoreXmlWriter).t39 = function (name, point) {
    this.f36_1.a37(name);
    this.f36_1.a37('point');
    this.k39('x', point.kn_1);
    this.k39('y', point.ln_1);
    this.f36_1.a36();
    this.f36_1.a36();
  };
  protoOf(StoreXmlWriter).u39 = function (name, integers) {
    // Inline function 'kotlin.collections.isNotEmpty' call
    if (!integers.m()) {
      this.m39(name, joinToString(integers, ','));
    }
  };
  protoOf(StoreXmlWriter).v39 = function (name, uuids) {
    // Inline function 'kotlin.collections.isNotEmpty' call
    if (!uuids.m()) {
      this.m39(name, joinToString(uuids, ','));
    }
  };
  protoOf(StoreXmlWriter).w39 = function (name, text) {
    this.f36_1.c37(name, '\n' + text + '\n');
  };
  function StringStorable(content) {
    content = content === VOID ? '' : content;
    AbstractStorable.call(this);
    this.y39_1 = content;
  }
  protoOf(StringStorable).d38 = function () {
    return false;
  };
  protoOf(StringStorable).a38 = function (reference, referenceResolver) {
  };
  protoOf(StringStorable).h38 = function (writer) {
    writer.m39('content', this.y39_1);
  };
  protoOf(StringStorable).i38 = function (reader) {
    this.y39_1 = reader.r38('content');
  };
  function TypeMapImpl$register$lambda($clazz) {
    return function () {
      return System_getInstance().am($clazz);
    };
  }
  function TypeMapImpl() {
    var tmp = this;
    // Inline function 'kotlin.collections.mutableMapOf' call
    tmp.z39_1 = LinkedHashMap_init_$Create$();
    var tmp_0 = this;
    // Inline function 'kotlin.collections.mutableMapOf' call
    tmp_0.a3a_1 = LinkedHashMap_init_$Create$();
    var tmp_1 = this;
    // Inline function 'kotlin.collections.mutableMapOf' call
    tmp_1.b3a_1 = LinkedHashMap_init_$Create$();
  }
  protoOf(TypeMapImpl).j37 = function (type, clazz) {
    var tmp0 = this.z39_1;
    // Inline function 'kotlin.collections.set' call
    var value = TypeMapImpl$register$lambda(clazz);
    tmp0.y1(type, value);
    // Inline function 'kotlin.collections.set' call
    this.a3a_1.y1(clazz, type);
  };
  protoOf(TypeMapImpl).c3a = function (type, condition, factory) {
    // Inline function 'kotlin.collections.set' call
    this.z39_1.y1(type, factory);
    // Inline function 'kotlin.collections.set' call
    this.b3a_1.y1(condition, type);
  };
  protoOf(TypeMapImpl).d39 = function (type) {
    var tmp0_safe_receiver = this.z39_1.g2(type);
    var tmp1_elvis_lhs = tmp0_safe_receiver == null ? null : tmp0_safe_receiver();
    var tmp;
    if (tmp1_elvis_lhs == null) {
      throw NoSuchElementException_init_$Create$("TypeMapImpl: type '" + type + "' not found");
    } else {
      tmp = tmp1_elvis_lhs;
    }
    var obj = tmp;
    return !(obj == null) ? obj : THROW_CCE();
  };
  protoOf(TypeMapImpl).f39 = function (storable) {
    var tmp0_elvis_lhs = this.a3a_1.g2(getKClassFromExpression(storable));
    var tmp;
    if (tmp0_elvis_lhs == null) {
      var tmp0 = this.b3a_1.b2();
      var tmp$ret$0;
      $l$block: {
        // Inline function 'kotlin.collections.firstOrNull' call
        var _iterator__ex2g4s = tmp0.i();
        while (_iterator__ex2g4s.j()) {
          var element = _iterator__ex2g4s.k();
          if (element(storable)) {
            tmp$ret$0 = element;
            break $l$block;
          }
        }
        tmp$ret$0 = null;
      }
      var tmp1_safe_receiver = tmp$ret$0;
      var tmp_0;
      if (tmp1_safe_receiver == null) {
        tmp_0 = null;
      } else {
        // Inline function 'kotlin.let' call
        tmp_0 = this.b3a_1.g2(tmp1_safe_receiver);
      }
      tmp = tmp_0;
    } else {
      tmp = tmp0_elvis_lhs;
    }
    var tmp2_elvis_lhs = tmp;
    var tmp_1;
    if (tmp2_elvis_lhs == null) {
      throw NoSuchElementException_init_$Create$("TypeMapImpl: class '" + getKClassFromExpression(storable).m9() + "' not found");
    } else {
      tmp_1 = tmp2_elvis_lhs;
    }
    return tmp_1;
  };
  function XmlReader() {
  }
  //region block: post-declaration
  protoOf(DomXmlReader).z35 = descend$default;
  protoOf(AbstractStorable).d38 = get_isReferencable;
  protoOf(AbstractStorable).g38 = get_isNotReading;
  protoOf(AbstractStorable).b38 = resolutionDone;
  protoOf(AbstractStorable).c38 = allResolutionDone;
  protoOf(AbstractStorable).j38 = readFromStore;
  protoOf(StoreXmlReader).n38 = readStorables$default;
  //endregion
  //region block: init
  Companion_instance_2 = new Companion_2();
  //endregion
  //region block: exports
  _.$_$ = _.$_$ || {};
  _.$_$.a = IOModuleJs_getInstance;
  _.$_$.b = IOModule_getInstance;
  _.$_$.c = StorableCloner_getInstance;
  _.$_$.d = DomXmlReader_init_$Create$;
  _.$_$.e = StoreXmlReader_init_$Create$;
  _.$_$.f = AbstractStorable;
  _.$_$.g = DomXmlReader;
  _.$_$.h = GlobalIdentityCreator;
  _.$_$.i = Reference;
  _.$_$.j = allResolutionDone;
  _.$_$.k = get_isNotReading;
  _.$_$.l = get_isReferencable;
  _.$_$.m = readFromStore;
  _.$_$.n = resolutionDone;
  _.$_$.o = Storable;
  _.$_$.p = StringStorable;
  //endregion
  return _;
}));

//# sourceMappingURL=jabbah-io.js.map
