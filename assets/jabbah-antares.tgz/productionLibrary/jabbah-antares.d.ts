type Nullable<T> = T | null | undefined
declare function KtSingleton<T>(): T & (abstract new() => any);
export declare namespace io.antarescircuit.jabbah.base {
    abstract class TranslationsOutlet extends KtSingleton<TranslationsOutlet.$metadata$.constructor>() {
        private constructor();
    }
    namespace TranslationsOutlet {
        /** @deprecated $metadata$ is used for internal purposes, please don't use it in your code, because it can be removed at any moment */
        namespace $metadata$ {
            abstract class constructor {
                getString(key: string): string;
                getOptionalString(key: string): Nullable<string>;
                private constructor();
            }
        }
    }
}
export declare namespace io.antarescircuit.jabbah.base.event {
    interface PropertyChangeListenerJs<T extends any> {
        propertyChanged(e: io.antarescircuit.jabbah.base.event.PropertyChangeEvent<T>): void;
    }
}
export declare namespace io.antarescircuit.jabbah.base.event {
    function mpListener<T extends any>(l: io.antarescircuit.jabbah.base.event.PropertyChangeListenerJs<T>): io.antarescircuit.jabbah.base.event.PropertyChangeListener<T>;
}
export declare namespace io.antarescircuit.jabbah.base {
    abstract class ActionProperty extends KtSingleton<ActionProperty.$metadata$.constructor>() {
        private constructor();
    }
    namespace ActionProperty {
        /** @deprecated $metadata$ is used for internal purposes, please don't use it in your code, because it can be removed at any moment */
        namespace $metadata$ {
            abstract class constructor {
                get PROP_NAME(): string;
                get PROP_DESCRIPTION(): string;
                get PROP_ACCELERATOR(): string;
                get PROP_ENABLED(): string;
                get PROP_SELECTED(): string;
                get PROP_IMAGE_PATH(): string;
                private constructor();
            }
        }
    }
    interface Action {
        name: string;
        description: Nullable<string>;
        accelerator: Nullable<string>;
        enabled: boolean;
        selected: boolean;
        imagePath: Nullable<string>;
        readonly opensDialog: boolean;
        readonly requestFocusOnClick: boolean;
        dispose(): void;
        updateEnabled(): void;
        execute(event: io.antarescircuit.jabbah.base.event.ActionEvent): void;
        addPropertyChangeListener(l: io.antarescircuit.jabbah.base.event.PropertyChangeListener<any>): void;
        removePropertyChangeListener(l: io.antarescircuit.jabbah.base.event.PropertyChangeListener<any>): void;
        readonly __doNotUseOrImplementIt: {
            readonly "io.antarescircuit.jabbah.base.Action": unique symbol;
        };
    }
}
export declare namespace io.antarescircuit.jabbah.base {
    class UUID {
        constructor(id: string);
        get id(): string;
        toString(): string;
        copy(id?: string): io.antarescircuit.jabbah.base.UUID;
        hashCode(): number;
        equals(other: Nullable<any>): boolean;
    }
    namespace UUID {
        /** @deprecated $metadata$ is used for internal purposes, please don't use it in your code, because it can be removed at any moment */
        namespace $metadata$ {
            const constructor: abstract new () => UUID;
        }
    }
}
export declare namespace io.antarescircuit.jabbah.base.event {
    class ActionEvent implements io.antarescircuit.jabbah.base.event.InputEvent {
        constructor(event: Nullable<any>, source: any, modifiers: number, action: string, time: bigint);
        get event(): Nullable<any>;
        get source(): any;
        get modifiers(): number;
        get action(): string;
        get time(): bigint;
        consumeEvent(): void;
        isEventConsumed(): boolean;
        get isAltDown(): boolean;
        get isControlDown(): boolean;
        get isShiftDown(): boolean;
        get isCtrlDown(): boolean;
        get isAltGraphDown(): boolean;
        get isMetaDown(): boolean;
        hasModifier(modifier: io.antarescircuit.jabbah.base.event.Modifier): boolean;
        readonly __doNotUseOrImplementIt: io.antarescircuit.jabbah.base.event.InputEvent["__doNotUseOrImplementIt"];
    }
    namespace ActionEvent {
        /** @deprecated $metadata$ is used for internal purposes, please don't use it in your code, because it can be removed at any moment */
        namespace $metadata$ {
            const constructor: abstract new () => ActionEvent;
        }
    }
    interface ActionListener {
        actionPerformed(event: io.antarescircuit.jabbah.base.event.ActionEvent): void;
        readonly __doNotUseOrImplementIt: {
            readonly "io.antarescircuit.jabbah.base.event.ActionListener": unique symbol;
        };
    }
}
export declare namespace io.antarescircuit.jabbah.base.event {
    abstract class Modifier {
        private constructor();
        static get Shift(): io.antarescircuit.jabbah.base.event.Modifier & {
            get name(): "Shift";
            get ordinal(): 0;
        };
        static get Ctrl(): io.antarescircuit.jabbah.base.event.Modifier & {
            get name(): "Ctrl";
            get ordinal(): 1;
        };
        static get Meta(): io.antarescircuit.jabbah.base.event.Modifier & {
            get name(): "Meta";
            get ordinal(): 2;
        };
        static get Alt(): io.antarescircuit.jabbah.base.event.Modifier & {
            get name(): "Alt";
            get ordinal(): 3;
        };
        static get AltGraph(): io.antarescircuit.jabbah.base.event.Modifier & {
            get name(): "AltGraph";
            get ordinal(): 4;
        };
        static values(): [typeof io.antarescircuit.jabbah.base.event.Modifier.Shift, typeof io.antarescircuit.jabbah.base.event.Modifier.Ctrl, typeof io.antarescircuit.jabbah.base.event.Modifier.Meta, typeof io.antarescircuit.jabbah.base.event.Modifier.Alt, typeof io.antarescircuit.jabbah.base.event.Modifier.AltGraph];
        static valueOf(value: string): io.antarescircuit.jabbah.base.event.Modifier;
        get name(): "Shift" | "Ctrl" | "Meta" | "Alt" | "AltGraph";
        get ordinal(): 0 | 1 | 2 | 3 | 4;
        get label(): string;
        get mask(): number;
        set mask(value: number);
    }
    namespace Modifier {
        /** @deprecated $metadata$ is used for internal purposes, please don't use it in your code, because it can be removed at any moment */
        namespace $metadata$ {
            const constructor: abstract new () => Modifier;
        }
    }
    interface InputEvent {
        readonly event: Nullable<any>;
        readonly source: any;
        readonly modifiers: number;
        readonly isAltDown: boolean;
        readonly isControlDown: boolean;
        readonly isShiftDown: boolean;
        readonly isCtrlDown: boolean;
        readonly isAltGraphDown: boolean;
        readonly isMetaDown: boolean;
        hasModifier(modifier: io.antarescircuit.jabbah.base.event.Modifier): boolean;
        consumeEvent(): void;
        isEventConsumed(): boolean;
        readonly __doNotUseOrImplementIt: {
            readonly "io.antarescircuit.jabbah.base.event.InputEvent": unique symbol;
        };
    }
}
export declare namespace io.antarescircuit.jabbah.base.event {
    class PropertyChangeEvent<T> {
        constructor(source: any, name: string, oldValue: Nullable<T>, newValue: Nullable<T>);
        get source(): any;
        get name(): string;
        get oldValue(): Nullable<T>;
        get newValue(): Nullable<T>;
        copy(source?: any, name?: string, oldValue?: Nullable<T>, newValue?: Nullable<T>): io.antarescircuit.jabbah.base.event.PropertyChangeEvent<T>;
        toString(): string;
        hashCode(): number;
        equals(other: Nullable<any>): boolean;
    }
    namespace PropertyChangeEvent {
        /** @deprecated $metadata$ is used for internal purposes, please don't use it in your code, because it can be removed at any moment */
        namespace $metadata$ {
            const constructor: abstract new <T>() => PropertyChangeEvent<T>;
        }
    }
    interface PropertyChangeListener<T extends any> {
        propertyChanged(e: io.antarescircuit.jabbah.base.event.PropertyChangeEvent<T>): void;
        readonly __doNotUseOrImplementIt: {
            readonly "io.antarescircuit.jabbah.base.event.PropertyChangeListener": unique symbol;
        };
    }
}
export declare namespace io.antarescircuit.jabbah.draw.view {
    abstract class ZoomPanActions extends KtSingleton<ZoomPanActions.$metadata$.constructor>() {
        private constructor();
    }
    namespace ZoomPanActions {
        /** @deprecated $metadata$ is used for internal purposes, please don't use it in your code, because it can be removed at any moment */
        namespace $metadata$ {
            abstract class constructor {
                get zoomNormalAction(): io.antarescircuit.jabbah.base.Action;
                get zoomInAction(): io.antarescircuit.jabbah.base.Action;
                get zoomOutAction(): io.antarescircuit.jabbah.base.Action;
                get zoomFitAction(): io.antarescircuit.jabbah.base.Action;
                get zoomFitMaxNormalAction(): io.antarescircuit.jabbah.base.Action;
                get zoomCenterAction(): io.antarescircuit.jabbah.base.Action;
                private constructor();
            }
        }
    }
}
export declare namespace io.antarescircuit.jabbah.edit.auth {
    class UserIdentity {
        constructor(id: string);
        get id(): string;
        toString(): string;
        copy(id?: string): io.antarescircuit.jabbah.edit.auth.UserIdentity;
        hashCode(): number;
        equals(other: Nullable<any>): boolean;
    }
    namespace UserIdentity {
        /** @deprecated $metadata$ is used for internal purposes, please don't use it in your code, because it can be removed at any moment */
        namespace $metadata$ {
            const constructor: abstract new () => UserIdentity;
        }
        abstract class Companion extends KtSingleton<Companion.$metadata$.constructor>() {
            private constructor();
        }
        namespace Companion {
            /** @deprecated $metadata$ is used for internal purposes, please don't use it in your code, because it can be removed at any moment */
            namespace $metadata$ {
                abstract class constructor {
                    get DEVELOPER(): io.antarescircuit.jabbah.edit.auth.UserIdentity;
                    get ANYBODY(): io.antarescircuit.jabbah.edit.auth.UserIdentity;
                    random(): io.antarescircuit.jabbah.edit.auth.UserIdentity;
                    private constructor();
                }
            }
        }
    }
}
export declare namespace io.antarescircuit.jabbah.app {
    abstract class Environment {
        private constructor();
        static get Development(): io.antarescircuit.jabbah.app.Environment & {
            get name(): "Development";
            get ordinal(): 0;
        };
        static get Production(): io.antarescircuit.jabbah.app.Environment & {
            get name(): "Production";
            get ordinal(): 1;
        };
        static values(): [typeof io.antarescircuit.jabbah.app.Environment.Development, typeof io.antarescircuit.jabbah.app.Environment.Production];
        static valueOf(value: string): io.antarescircuit.jabbah.app.Environment;
        get name(): "Development" | "Production";
        get ordinal(): 0 | 1;
    }
    namespace Environment {
        /** @deprecated $metadata$ is used for internal purposes, please don't use it in your code, because it can be removed at any moment */
        namespace $metadata$ {
            const constructor: abstract new () => Environment;
        }
        abstract class Companion extends KtSingleton<Companion.$metadata$.constructor>() {
            private constructor();
        }
        namespace Companion {
            /** @deprecated $metadata$ is used for internal purposes, please don't use it in your code, because it can be removed at any moment */
            namespace $metadata$ {
                abstract class constructor {
                    withName(name: string): io.antarescircuit.jabbah.app.Environment;
                    private constructor();
                }
            }
        }
    }
}
export declare namespace io.antarescircuit.jabbah.execution {
    interface ExecutionControlOutlet {
        readonly systemSpeedCategoryName: string;
        currentSystemSpeed: number;
        readonly toggleApplicationModeAction: io.antarescircuit.jabbah.base.Action;
        readonly singleStepModeAction: io.antarescircuit.jabbah.base.Action;
        readonly pauseOrResumeAction: io.antarescircuit.jabbah.execution.PauseOrResumeAction;
        readonly __doNotUseOrImplementIt: {
            readonly "io.antarescircuit.jabbah.execution.ExecutionControlOutlet": unique symbol;
        };
    }
}
export declare namespace io.antarescircuit.jabbah.execution {
    interface PauseOrResumeAction extends io.antarescircuit.jabbah.base.Action {
        readonly inBreakpoint: boolean;
        readonly __doNotUseOrImplementIt: {
            readonly "io.antarescircuit.jabbah.execution.PauseOrResumeAction": unique symbol;
        } & io.antarescircuit.jabbah.base.Action["__doNotUseOrImplementIt"];
    }
    const PROP_PAUSE_OR_RESUME_ACTION_IN_BREAKPOINT: string;
}
export declare namespace io.antarescircuit.jabbah.execution {
    interface SchedulerActions {
        readonly executionDepthAction: io.antarescircuit.jabbah.base.Action;
        readonly __doNotUseOrImplementIt: {
            readonly "io.antarescircuit.jabbah.execution.SchedulerActions": unique symbol;
        };
    }
}
export declare namespace io.antarescircuit.jabbah.graph.project {
    class AkrabApiError {
        constructor(type: string, msg?: Nullable<string>);
        get type(): string;
        get msg(): Nullable<string>;
        copy(type?: string, msg?: Nullable<string>): io.antarescircuit.jabbah.graph.project.AkrabApiError;
        toString(): string;
        hashCode(): number;
        equals(other: Nullable<any>): boolean;
    }
    namespace AkrabApiError {
        /** @deprecated $metadata$ is used for internal purposes, please don't use it in your code, because it can be removed at any moment */
        namespace $metadata$ {
            const constructor: abstract new () => AkrabApiError;
        }
        abstract class Companion extends KtSingleton<Companion.$metadata$.constructor>() {
            private constructor();
        }
        namespace Companion {
            /** @deprecated $metadata$ is used for internal purposes, please don't use it in your code, because it can be removed at any moment */
            namespace $metadata$ {
                abstract class constructor {
                    get TYPE_QUOTA(): string;
                    get TYPE_ERROR(): string;
                    error(msg: string): io.antarescircuit.jabbah.graph.project.AkrabApiError;
                    quota(msg: string): io.antarescircuit.jabbah.graph.project.AkrabApiError;
                    private constructor();
                }
            }
        }
    }
    class AkrabApiException extends /* kotlin.Exception */ Error {
        constructor(error: io.antarescircuit.jabbah.graph.project.AkrabApiError);
        get error(): io.antarescircuit.jabbah.graph.project.AkrabApiError;
    }
    namespace AkrabApiException {
        /** @deprecated $metadata$ is used for internal purposes, please don't use it in your code, because it can be removed at any moment */
        namespace $metadata$ {
            const constructor: abstract new () => AkrabApiException;
        }
    }
}
export declare namespace io.antarescircuit.antares {
    class AntaresEditorContent {
        constructor(library: any, libraryTree: io.antarescircuit.antares.LibraryTreeNodeJS, metaGraph: Nullable<any>);
        get library(): any;
        get libraryTree(): io.antarescircuit.antares.LibraryTreeNodeJS;
        get metaGraph(): Nullable<any>;
        copy(library?: any, libraryTree?: io.antarescircuit.antares.LibraryTreeNodeJS, metaGraph?: Nullable<any>): io.antarescircuit.antares.AntaresEditorContent;
        toString(): string;
        hashCode(): number;
        equals(other: Nullable<any>): boolean;
    }
    namespace AntaresEditorContent {
        /** @deprecated $metadata$ is used for internal purposes, please don't use it in your code, because it can be removed at any moment */
        namespace $metadata$ {
            const constructor: abstract new () => AntaresEditorContent;
        }
    }
    class AntaresEditorAppJs /* extends io.antarescircuit.antares.AbstractAntaresAppJs */ {
        constructor(environment: io.antarescircuit.jabbah.app.Environment, akrabURL: string);
        start(libraryUuid: string, userIdentity: io.antarescircuit.jabbah.edit.auth.UserIdentity, themeName?: Nullable<string>): Promise<io.antarescircuit.antares.AntaresEditorContent>;
    }
    namespace AntaresEditorAppJs {
        /** @deprecated $metadata$ is used for internal purposes, please don't use it in your code, because it can be removed at any moment */
        namespace $metadata$ {
            const constructor: abstract new () => AntaresEditorAppJs;
        }
        abstract class Companion extends KtSingleton<Companion.$metadata$.constructor>() {
            private constructor();
        }
        namespace Companion {
            /** @deprecated $metadata$ is used for internal purposes, please don't use it in your code, because it can be removed at any moment */
            namespace $metadata$ {
                abstract class constructor {
                    private constructor();
                }
            }
        }
    }
}
export declare namespace io.antarescircuit.antares {
    class AntaresEditorViewerJs implements io.antarescircuit.jabbah.execution.SchedulerActions {
        constructor(content: io.antarescircuit.antares.AntaresEditorContent);
        get libraryTree(): io.antarescircuit.antares.LibraryTreeNodeJS;
        set libraryTree(value: io.antarescircuit.antares.LibraryTreeNodeJS);
        get metaGraphId(): Nullable<string>;
        get metaGraphName(): string;
        get executionControlOutlet(): io.antarescircuit.jabbah.execution.ExecutionControlOutlet;
        get executionDepthAction(): io.antarescircuit.jabbah.base.Action;
        bindCanvas(canvas: HTMLCanvasElement): void;
        loadMetaGraphAsync(uuid: string): Promise<any>;
        setMetaGraph(metaGraph: any): void;
        readonly __doNotUseOrImplementIt: io.antarescircuit.jabbah.execution.SchedulerActions["__doNotUseOrImplementIt"];
    }
    namespace AntaresEditorViewerJs {
        /** @deprecated $metadata$ is used for internal purposes, please don't use it in your code, because it can be removed at any moment */
        namespace $metadata$ {
            const constructor: abstract new () => AntaresEditorViewerJs;
        }
        abstract class Companion extends KtSingleton<Companion.$metadata$.constructor>() {
            private constructor();
        }
        namespace Companion {
            /** @deprecated $metadata$ is used for internal purposes, please don't use it in your code, because it can be removed at any moment */
            namespace $metadata$ {
                abstract class constructor {
                    private constructor();
                }
            }
        }
    }
}
export declare namespace io.antarescircuit.antares {
    class AntaresSingleCircuitAppJs /* extends io.antarescircuit.antares.AbstractAntaresAppJs */ {
        constructor(environment: io.antarescircuit.jabbah.app.Environment, akrabURL: string);
        start(libraryUuid: string, metaGraphUuid: string, themeName?: Nullable<string>): Promise<any>;
    }
    namespace AntaresSingleCircuitAppJs {
        /** @deprecated $metadata$ is used for internal purposes, please don't use it in your code, because it can be removed at any moment */
        namespace $metadata$ {
            const constructor: abstract new () => AntaresSingleCircuitAppJs;
        }
        abstract class Companion extends KtSingleton<Companion.$metadata$.constructor>() {
            private constructor();
        }
        namespace Companion {
            /** @deprecated $metadata$ is used for internal purposes, please don't use it in your code, because it can be removed at any moment */
            namespace $metadata$ {
                abstract class constructor {
                    private constructor();
                }
            }
        }
    }
}
export declare namespace io.antarescircuit.antares {
    class AntaresSingleCircuitViewerJs {
        constructor(data: any);
        get executionControlOutlet(): io.antarescircuit.jabbah.execution.ExecutionControlOutlet;
        bindCanvas(canvas: HTMLCanvasElement): void;
        get circuitName(): string;
    }
    namespace AntaresSingleCircuitViewerJs {
        /** @deprecated $metadata$ is used for internal purposes, please don't use it in your code, because it can be removed at any moment */
        namespace $metadata$ {
            const constructor: abstract new () => AntaresSingleCircuitViewerJs;
        }
        abstract class Companion extends KtSingleton<Companion.$metadata$.constructor>() {
            private constructor();
        }
        namespace Companion {
            /** @deprecated $metadata$ is used for internal purposes, please don't use it in your code, because it can be removed at any moment */
            namespace $metadata$ {
                abstract class constructor {
                    private constructor();
                }
            }
        }
    }
}
export declare namespace io.antarescircuit.antares {
    abstract class LibraryTreeNodeType {
        private constructor();
        static get Desktop(): io.antarescircuit.antares.LibraryTreeNodeType & {
            get name(): "Desktop";
            get ordinal(): 0;
        };
        static get Project(): io.antarescircuit.antares.LibraryTreeNodeType & {
            get name(): "Project";
            get ordinal(): 1;
        };
        static get Library(): io.antarescircuit.antares.LibraryTreeNodeType & {
            get name(): "Library";
            get ordinal(): 2;
        };
        static get Folder(): io.antarescircuit.antares.LibraryTreeNodeType & {
            get name(): "Folder";
            get ordinal(): 3;
        };
        static get MetaGraph(): io.antarescircuit.antares.LibraryTreeNodeType & {
            get name(): "MetaGraph";
            get ordinal(): 4;
        };
        static values(): [typeof io.antarescircuit.antares.LibraryTreeNodeType.Desktop, typeof io.antarescircuit.antares.LibraryTreeNodeType.Project, typeof io.antarescircuit.antares.LibraryTreeNodeType.Library, typeof io.antarescircuit.antares.LibraryTreeNodeType.Folder, typeof io.antarescircuit.antares.LibraryTreeNodeType.MetaGraph];
        static valueOf(value: string): io.antarescircuit.antares.LibraryTreeNodeType;
        get name(): "Desktop" | "Project" | "Library" | "Folder" | "MetaGraph";
        get ordinal(): 0 | 1 | 2 | 3 | 4;
    }
    namespace LibraryTreeNodeType {
        /** @deprecated $metadata$ is used for internal purposes, please don't use it in your code, because it can be removed at any moment */
        namespace $metadata$ {
            const constructor: abstract new () => LibraryTreeNodeType;
        }
    }
    class LibraryTreeNodeJS {
        constructor(name: string, type: io.antarescircuit.antares.LibraryTreeNodeType, children: Array<io.antarescircuit.antares.LibraryTreeNodeJS>, id: Nullable<string>);
        get name(): string;
        get type(): io.antarescircuit.antares.LibraryTreeNodeType;
        get children(): Array<io.antarescircuit.antares.LibraryTreeNodeJS>;
        get id(): Nullable<string>;
        copy(name?: string, type?: io.antarescircuit.antares.LibraryTreeNodeType, children?: Array<io.antarescircuit.antares.LibraryTreeNodeJS>, id?: Nullable<string>): io.antarescircuit.antares.LibraryTreeNodeJS;
        toString(): string;
        hashCode(): number;
        equals(other: Nullable<any>): boolean;
    }
    namespace LibraryTreeNodeJS {
        /** @deprecated $metadata$ is used for internal purposes, please don't use it in your code, because it can be removed at any moment */
        namespace $metadata$ {
            const constructor: abstract new () => LibraryTreeNodeJS;
        }
    }
}
export as namespace jabbah_antares;