(function (factory) {
  if (typeof define === 'function' && define.amd)
    define(['exports', './kotlin-kotlin-stdlib.js', './jabbah-base.js', './jabbah-io.js', './jabbah-draw.js', './kotlinx-serialization-kotlinx-serialization-core-js-ir.js', './jabbah-animation.js'], factory);
  else if (typeof exports === 'object')
    factory(module.exports, require('./kotlin-kotlin-stdlib.js'), require('./jabbah-base.js'), require('./jabbah-io.js'), require('./jabbah-draw.js'), require('./kotlinx-serialization-kotlinx-serialization-core-js-ir.js'), require('./jabbah-animation.js'));
  else {
    if (typeof globalThis['kotlin-kotlin-stdlib'] === 'undefined') {
      throw new Error("Error loading module 'jabbah-edit'. Its dependency 'kotlin-kotlin-stdlib' was not found. Please, check whether 'kotlin-kotlin-stdlib' is loaded prior to 'jabbah-edit'.");
    }
    if (typeof globalThis['jabbah-base'] === 'undefined') {
      throw new Error("Error loading module 'jabbah-edit'. Its dependency 'jabbah-base' was not found. Please, check whether 'jabbah-base' is loaded prior to 'jabbah-edit'.");
    }
    if (typeof globalThis['jabbah-io'] === 'undefined') {
      throw new Error("Error loading module 'jabbah-edit'. Its dependency 'jabbah-io' was not found. Please, check whether 'jabbah-io' is loaded prior to 'jabbah-edit'.");
    }
    if (typeof globalThis['jabbah-draw'] === 'undefined') {
      throw new Error("Error loading module 'jabbah-edit'. Its dependency 'jabbah-draw' was not found. Please, check whether 'jabbah-draw' is loaded prior to 'jabbah-edit'.");
    }
    if (typeof globalThis['kotlinx-serialization-kotlinx-serialization-core-js-ir'] === 'undefined') {
      throw new Error("Error loading module 'jabbah-edit'. Its dependency 'kotlinx-serialization-kotlinx-serialization-core-js-ir' was not found. Please, check whether 'kotlinx-serialization-kotlinx-serialization-core-js-ir' is loaded prior to 'jabbah-edit'.");
    }
    if (typeof globalThis['jabbah-animation'] === 'undefined') {
      throw new Error("Error loading module 'jabbah-edit'. Its dependency 'jabbah-animation' was not found. Please, check whether 'jabbah-animation' is loaded prior to 'jabbah-edit'.");
    }
    globalThis['jabbah-edit'] = factory(typeof globalThis['jabbah-edit'] === 'undefined' ? {} : globalThis['jabbah-edit'], globalThis['kotlin-kotlin-stdlib'], globalThis['jabbah-base'], globalThis['jabbah-io'], globalThis['jabbah-draw'], globalThis['kotlinx-serialization-kotlinx-serialization-core-js-ir'], globalThis['jabbah-animation']);
  }
}(function (_, kotlin_kotlin, kotlin_jabbah_base, kotlin_jabbah_io, kotlin_jabbah_draw, kotlin_org_jetbrains_kotlinx_kotlinx_serialization_core, kotlin_jabbah_animation) {
  'use strict';
  //region block: imports
  var imul = Math.imul;
  var log10 = Math.log10;
  var protoOf = kotlin_kotlin.$_$.t7;
  var initMetadataForClass = kotlin_kotlin.$_$.d7;
  var AbstractModule = kotlin_jabbah_base.$_$.d7;
  var IOModuleJs_getInstance = kotlin_jabbah_io.$_$.a;
  var DrawModuleJs_getInstance = kotlin_jabbah_draw.$_$.c1;
  var initMetadataForObject = kotlin_kotlin.$_$.i7;
  var VOID = kotlin_kotlin.$_$.b;
  var initMetadataForInterface = kotlin_kotlin.$_$.g7;
  var Unit_instance = kotlin_kotlin.$_$.i;
  var toString = kotlin_kotlin.$_$.v7;
  var hashCode = kotlin_kotlin.$_$.c7;
  var equals = kotlin_kotlin.$_$.u6;
  var Enum = kotlin_kotlin.$_$.xa;
  var Movable = kotlin_jabbah_draw.$_$.s3;
  var Locatable = kotlin_jabbah_draw.$_$.n3;
  var Storable = kotlin_jabbah_io.$_$.o;
  var Stylable = kotlin_jabbah_draw.$_$.i5;
  var Focusable = kotlin_jabbah_draw.$_$.d6;
  var DrawableContainer = kotlin_jabbah_draw.$_$.w5;
  var View = kotlin_jabbah_draw.$_$.k6;
  var InputEventContext = kotlin_jabbah_draw.$_$.e6;
  var LinkedHashMap_init_$Create$ = kotlin_kotlin.$_$.q;
  var ensureNotNull = kotlin_kotlin.$_$.mb;
  var BaseModule_getInstance = kotlin_jabbah_base.$_$.n;
  var LogicalFontFamily_DIALOG_getInstance = kotlin_jabbah_draw.$_$.w1;
  var FontStyle_PLAIN_getInstance = kotlin_jabbah_draw.$_$.p1;
  var FontImpl = kotlin_jabbah_draw.$_$.s4;
  var LogicalFontFamily_SANS_SERIF_getInstance = kotlin_jabbah_draw.$_$.y1;
  var numberToInt = kotlin_kotlin.$_$.r7;
  var LogicalFontFamily_MONOSPACED_getInstance = kotlin_jabbah_draw.$_$.x1;
  var PreferencesChangedEvent = kotlin_jabbah_base.$_$.k7;
  var getKClass = kotlin_kotlin.$_$.s8;
  var Themes_getInstance = kotlin_jabbah_draw.$_$.w;
  var objectCreate = kotlin_kotlin.$_$.s7;
  var initMetadataForCompanion = kotlin_kotlin.$_$.e7;
  var getNumberHashCode = kotlin_kotlin.$_$.y6;
  var emptyList = kotlin_kotlin.$_$.c3;
  var logger = kotlin_jabbah_base.$_$.q7;
  var collectionSizeOrDefault = kotlin_kotlin.$_$.s2;
  var ArrayList_init_$Create$ = kotlin_kotlin.$_$.m;
  var toList = kotlin_kotlin.$_$.s4;
  var throwUninitializedPropertyAccessException = kotlin_kotlin.$_$.t5;
  var ArrayList_init_$Create$_0 = kotlin_kotlin.$_$.n;
  var getStringHashCode = kotlin_kotlin.$_$.b7;
  var getBooleanHashCode = kotlin_kotlin.$_$.x6;
  var System_getInstance = kotlin_jabbah_base.$_$.c1;
  var PluginGeneratedSerialDescriptor = kotlin_org_jetbrains_kotlinx_kotlinx_serialization_core.$_$.e;
  var StringSerializer_getInstance = kotlin_org_jetbrains_kotlinx_kotlinx_serialization_core.$_$.a;
  var typeParametersSerializers = kotlin_org_jetbrains_kotlinx_kotlinx_serialization_core.$_$.c;
  var GeneratedSerializer = kotlin_org_jetbrains_kotlinx_kotlinx_serialization_core.$_$.d;
  var defineProp = kotlin_kotlin.$_$.t6;
  var KProperty1 = kotlin_kotlin.$_$.v8;
  var getPropertyCallableRef = kotlin_kotlin.$_$.a7;
  var LinkedHashSet_init_$Create$ = kotlin_kotlin.$_$.r;
  var Translations_getInstance = kotlin_jabbah_base.$_$.d1;
  var lazy = kotlin_kotlin.$_$.qb;
  var addAll = kotlin_kotlin.$_$.m2;
  var StorableCloner_getInstance = kotlin_jabbah_io.$_$.c;
  var Stack = kotlin_jabbah_base.$_$.e4;
  var Disposable = kotlin_jabbah_base.$_$.f7;
  var isInterface = kotlin_kotlin.$_$.m7;
  var AbstractIterator = kotlin_kotlin.$_$.e2;
  var copyToArray = kotlin_kotlin.$_$.a3;
  var IllegalStateException_init_$Create$ = kotlin_kotlin.$_$.d1;
  var first = kotlin_kotlin.$_$.h3;
  var Collection = kotlin_kotlin.$_$.g2;
  var reversed = kotlin_kotlin.$_$.h4;
  var THROW_CCE = kotlin_kotlin.$_$.fb;
  var _Char___init__impl__6a9atx = kotlin_kotlin.$_$.n1;
  var StringBuilder_init_$Create$ = kotlin_kotlin.$_$.v;
  var emptySet = kotlin_kotlin.$_$.e3;
  var Point2D = kotlin_jabbah_base.$_$.e6;
  var Companion_getInstance = kotlin_jabbah_base.$_$.h;
  var first_0 = kotlin_kotlin.$_$.i3;
  var Companion_instance = kotlin_jabbah_draw.$_$.b;
  var IllegalArgumentException_init_$Create$ = kotlin_kotlin.$_$.b1;
  var Direction_SOUTH_getInstance = kotlin_jabbah_base.$_$.v2;
  var Companion_instance_0 = kotlin_jabbah_base.$_$.e;
  var Direction_NORTH_getInstance = kotlin_jabbah_base.$_$.u2;
  var Direction_WEST_getInstance = kotlin_jabbah_base.$_$.w2;
  var Direction_EAST_getInstance = kotlin_jabbah_base.$_$.t2;
  var InputEventHandlerAdapter = kotlin_jabbah_draw.$_$.f6;
  var Point2D_init_$Create$ = kotlin_jabbah_base.$_$.q3;
  var InputEventHandler = kotlin_jabbah_draw.$_$.g6;
  var getKClassFromExpression = kotlin_kotlin.$_$.r8;
  var MouseAdapter = kotlin_jabbah_base.$_$.q5;
  var KeyAdapter = kotlin_jabbah_base.$_$.o5;
  var PropertyChangeListener = kotlin_jabbah_base.$_$.t5;
  var DrawableContainerAdapter = kotlin_jabbah_draw.$_$.s2;
  var PropertyChangeSupport = kotlin_jabbah_base.$_$.u5;
  var Rectangle2D_init_$Create$ = kotlin_jabbah_base.$_$.t3;
  var DropShadow_instance = kotlin_jabbah_draw.$_$.j;
  var DrawStyleModule_getInstance = kotlin_jabbah_draw.$_$.s;
  var Companion_getInstance_0 = kotlin_jabbah_draw.$_$.v;
  var get_canMirror = kotlin_jabbah_draw.$_$.o3;
  var Mirrorable = kotlin_jabbah_draw.$_$.p3;
  var FunctionAdapter = kotlin_kotlin.$_$.k6;
  var Rectangle2D_init_$Create$_0 = kotlin_jabbah_base.$_$.u3;
  var Ellipse2D_init_$Create$ = kotlin_jabbah_base.$_$.p3;
  var Colorable = kotlin_jabbah_draw.$_$.g3;
  var contains = kotlin_kotlin.$_$.u2;
  var to = kotlin_kotlin.$_$.vb;
  var mapOf = kotlin_kotlin.$_$.u3;
  var StylableImpl = kotlin_jabbah_draw.$_$.h5;
  var AbstractStyledDrawable = kotlin_jabbah_draw.$_$.e3;
  var Rotation_R0_getInstance = kotlin_jabbah_base.$_$.x2;
  var Companion_instance_1 = kotlin_jabbah_base.$_$.j;
  var DrawModule_getInstance = kotlin_jabbah_draw.$_$.n;
  var prepareMoveBy = kotlin_jabbah_draw.$_$.r3;
  var completeMoveBy = kotlin_jabbah_draw.$_$.q3;
  var get_isReferencable = kotlin_jabbah_io.$_$.l;
  var get_isNotReading = kotlin_jabbah_io.$_$.k;
  var resolutionDone = kotlin_jabbah_io.$_$.n;
  var allResolutionDone = kotlin_jabbah_io.$_$.j;
  var readFromStore = kotlin_jabbah_io.$_$.m;
  var get_isFocusOwner = kotlin_jabbah_draw.$_$.b6;
  var requestFocus = kotlin_jabbah_draw.$_$.c6;
  var compareTo = kotlin_kotlin.$_$.s6;
  var DrawableContainerImpl = kotlin_jabbah_draw.$_$.u2;
  var listOf = kotlin_kotlin.$_$.s3;
  var Reference = kotlin_jabbah_io.$_$.i;
  var toString_0 = kotlin_kotlin.$_$.tb;
  var enumEntries = kotlin_kotlin.$_$.s5;
  var noWhenBranchMatchedException = kotlin_kotlin.$_$.rb;
  var checkIndexOverflow = kotlin_kotlin.$_$.r2;
  var TransparentImpl = kotlin_jabbah_draw.$_$.i4;
  var applyTo = kotlin_jabbah_draw.$_$.h4;
  var Transparent = kotlin_jabbah_draw.$_$.j4;
  var Stroke = kotlin_jabbah_draw.$_$.b5;
  var Cursor_CROSSHAIR_getInstance = kotlin_jabbah_draw.$_$.e1;
  var Point2D_init_$Create$_0 = kotlin_jabbah_base.$_$.r3;
  var listOf_0 = kotlin_kotlin.$_$.t3;
  var AbstractRectangularUnzoomable = kotlin_jabbah_draw.$_$.d3;
  var Rectangle2D = kotlin_jabbah_base.$_$.f6;
  var asReversed = kotlin_kotlin.$_$.p2;
  var resettableLazy = kotlin_jabbah_base.$_$.r7;
  var UUID = kotlin_jabbah_base.$_$.p7;
  var AbstractStorable = kotlin_jabbah_io.$_$.f;
  var ImageType_SVG_getInstance = kotlin_jabbah_draw.$_$.q1;
  var KMutableProperty1 = kotlin_kotlin.$_$.t8;
  var Companion_instance_2 = kotlin_jabbah_draw.$_$.k;
  var Geometry_instance = kotlin_jabbah_base.$_$.g;
  var until = kotlin_kotlin.$_$.q8;
  var Companion_getInstance_1 = kotlin_jabbah_base.$_$.f;
  var Companion_getInstance_2 = kotlin_jabbah_draw.$_$.o;
  var PolylineDrawable = kotlin_jabbah_draw.$_$.d5;
  var DrawableOwner = kotlin_jabbah_draw.$_$.y2;
  var MutableRectangularShape = kotlin_jabbah_base.$_$.c6;
  var findSegment$default = kotlin_jabbah_draw.$_$.k2;
  var Polyline = kotlin_jabbah_draw.$_$.e5;
  var Tooltip = kotlin_jabbah_base.$_$.n7;
  var Ellipse2D = kotlin_jabbah_base.$_$.b6;
  var RoundRectangle2D = kotlin_jabbah_base.$_$.i6;
  var Status_getInstance = kotlin_jabbah_base.$_$.a1;
  var StatusType_Small_getInstance = kotlin_jabbah_base.$_$.h3;
  var Cursor_NW_RESIZE_getInstance = kotlin_jabbah_draw.$_$.j1;
  var Cursor_N_RESIZE_getInstance = kotlin_jabbah_draw.$_$.k1;
  var Cursor_NE_RESIZE_getInstance = kotlin_jabbah_draw.$_$.i1;
  var Cursor_E_RESIZE_getInstance = kotlin_jabbah_draw.$_$.g1;
  var Cursor_SE_RESIZE_getInstance = kotlin_jabbah_draw.$_$.l1;
  var Cursor_S_RESIZE_getInstance = kotlin_jabbah_draw.$_$.n1;
  var Cursor_SW_RESIZE_getInstance = kotlin_jabbah_draw.$_$.m1;
  var Cursor_W_RESIZE_getInstance = kotlin_jabbah_draw.$_$.o1;
  var Companion_getInstance_3 = kotlin_jabbah_draw.$_$.g;
  var AbstractDrawable = kotlin_jabbah_draw.$_$.b3;
  var Companion_getInstance_4 = kotlin_jabbah_draw.$_$.c;
  var moveBy = kotlin_jabbah_draw.$_$.m3;
  var Companion_instance_3 = kotlin_jabbah_base.$_$.i;
  var Rotation_R180_getInstance = kotlin_jabbah_base.$_$.y2;
  var Dimension2D = kotlin_jabbah_base.$_$.z5;
  var UnsupportedOperationException_init_$Create$ = kotlin_kotlin.$_$.m1;
  var RectangularShape = kotlin_jabbah_base.$_$.g6;
  var AbstractDrawableButtonRenderer = kotlin_jabbah_draw.$_$.z2;
  var StringUtils_getInstance = kotlin_jabbah_base.$_$.b1;
  var charSequenceLength = kotlin_kotlin.$_$.r6;
  var toMutableMap = kotlin_kotlin.$_$.v4;
  var Companion_getInstance_5 = kotlin_jabbah_base.$_$.x;
  var firstOrNull = kotlin_kotlin.$_$.g3;
  var asSequence = kotlin_kotlin.$_$.w8;
  var joinToString = kotlin_kotlin.$_$.x8;
  var ObservableProperty = kotlin_kotlin.$_$.a8;
  var IOModule_getInstance = kotlin_jabbah_io.$_$.b;
  var IllegalArgumentException = kotlin_kotlin.$_$.ab;
  var IllegalArgumentException_init_$Init$ = kotlin_kotlin.$_$.a1;
  var captureStack = kotlin_kotlin.$_$.n6;
  var toNumber = kotlin_kotlin.$_$.j6;
  var IllegalArgumentException_init_$Create$_0 = kotlin_kotlin.$_$.z;
  var numberToLong = kotlin_kotlin.$_$.e6;
  var round = kotlin_kotlin.$_$.z7;
  var multiply = kotlin_kotlin.$_$.c6;
  var Cursor_MOVE_getInstance = kotlin_jabbah_draw.$_$.h1;
  var DrawableAdapter = kotlin_jabbah_draw.$_$.u5;
  var Drawable = kotlin_jabbah_draw.$_$.y5;
  var Color = kotlin_jabbah_draw.$_$.n4;
  var LineCap_SQUARE_getInstance = kotlin_jabbah_draw.$_$.t1;
  var LineJoin_MITER_getInstance = kotlin_jabbah_draw.$_$.u1;
  var Unzoomable = kotlin_jabbah_draw.$_$.k4;
  var AbstractRectangle = kotlin_jabbah_draw.$_$.c3;
  var emptyMap = kotlin_kotlin.$_$.d3;
  var StatusType_Tool_getInstance = kotlin_jabbah_base.$_$.i3;
  var CurrentPanMethod_getInstance = kotlin_jabbah_draw.$_$.x;
  var mutableListOf = kotlin_kotlin.$_$.y3;
  var TooltipHandler = kotlin_jabbah_draw.$_$.m5;
  var Cursor_DEFAULT_getInstance = kotlin_jabbah_draw.$_$.f1;
  var Button_BUTTON1_getInstance = kotlin_jabbah_base.$_$.z1;
  var Companion_getInstance_6 = kotlin_jabbah_draw.$_$.u;
  var StyleType = kotlin_jabbah_draw.$_$.j5;
  var Color_init_$Create$ = kotlin_jabbah_draw.$_$.p2;
  var CompositeColor = kotlin_jabbah_draw.$_$.p4;
  var BasicStyle = kotlin_jabbah_draw.$_$.f5;
  var DrawTheme = kotlin_jabbah_draw.$_$.g5;
  var ReferenceColorSequenceProvider_getInstance = kotlin_jabbah_draw.$_$.l;
  var Companion_getInstance_7 = kotlin_jabbah_draw.$_$.t;
  var AbstractAction = kotlin_jabbah_base.$_$.c7;
  var AbstractAction_init_$Init$ = kotlin_jabbah_base.$_$.y3;
  var Ring2D = kotlin_jabbah_base.$_$.h6;
  var AnimationTaskAdapter = kotlin_jabbah_animation.$_$.c;
  var DoubleRange = kotlin_jabbah_animation.$_$.f;
  var FlexibleTextView = kotlin_jabbah_draw.$_$.k3;
  var Companion_getInstance_8 = kotlin_jabbah_draw.$_$.f;
  var DisplayDuration_instance = kotlin_jabbah_base.$_$.v;
  var AnimationModule_getInstance = kotlin_jabbah_animation.$_$.a;
  var UnzoomableContainer = kotlin_jabbah_draw.$_$.x2;
  var ViewImpl = kotlin_jabbah_draw.$_$.n5;
  var DrawableContainerDrawer = kotlin_jabbah_draw.$_$.t2;
  var InvalidatableViewPainter = kotlin_jabbah_draw.$_$.l5;
  var ViewContentBounds = kotlin_jabbah_draw.$_$.i6;
  //endregion
  //region block: pre-declaration
  initMetadataForClass(TextComponentFactoryJs, 'TextComponentFactoryJs', TextComponentFactoryJs);
  initMetadataForObject(EditModuleJs, 'EditModuleJs', VOID, AbstractModule);
  function getDetailedDescription() {
    return this.g3a();
  }
  function notifyUndo() {
  }
  initMetadataForInterface(Command, 'Command');
  initMetadataForClass(AbstractCommand, 'AbstractCommand', VOID, VOID, [Command]);
  function get_canUndo() {
    return true;
  }
  initMetadataForInterface(Undoable, 'Undoable');
  initMetadataForClass(AbstractPropertyCommand, 'AbstractPropertyCommand', VOID, AbstractCommand, [Undoable]);
  function beginTransaction$default(command, register, $super) {
    register = register === VOID ? false : register;
    var tmp;
    if ($super === VOID) {
      this.q3a(command, register);
      tmp = Unit_instance;
    } else {
      tmp = $super.q3a.call(this, command, register);
    }
    return tmp;
  }
  initMetadataForInterface(CommandManager, 'CommandManager');
  initMetadataForClass(CommandEvent, 'CommandEvent');
  initMetadataForClass(CommandEventType, 'CommandEventType', VOID, Enum);
  initMetadataForClass(CommandManagerActiveEvent, 'CommandManagerActiveEvent');
  function getSnapHighlightX(x, y) {
    return null;
  }
  function getSnapHighlightY(x, y) {
    return null;
  }
  initMetadataForInterface(Snappable, 'Snappable');
  function get_isDragManager() {
    return false;
  }
  function collectSelectBuddies(drawing, buddies) {
  }
  function notifyEditable(editable) {
  }
  initMetadataForInterface(Component, 'Component', VOID, VOID, [Movable, Locatable, Snappable, Storable, Stylable, Focusable]);
  initMetadataForInterface(ComponentContainer, 'ComponentContainer', VOID, VOID, [DrawableContainer, Storable]);
  initMetadataForInterface(DragManagerDestinationPlugin, 'DragManagerDestinationPlugin');
  initMetadataForInterface(Namable, 'Namable');
  function notifyEditable_0(editable) {
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = this.u20().i();
    while (_iterator__ex2g4s.j()) {
      var element = _iterator__ex2g4s.k();
      element.i3b(editable);
    }
  }
  initMetadataForInterface(Drawing, 'Drawing', VOID, VOID, [ComponentContainer, Namable]);
  function setDrawing$default(drawing, applyDefaultZoomStrategy, $super) {
    applyDefaultZoomStrategy = applyDefaultZoomStrategy === VOID ? true : applyDefaultZoomStrategy;
    var tmp;
    if ($super === VOID) {
      this.b3c(drawing, applyDefaultZoomStrategy);
      tmp = Unit_instance;
    } else {
      tmp = $super.b3c.call(this, drawing, applyDefaultZoomStrategy);
    }
    return tmp;
  }
  initMetadataForInterface(DrawingView, 'DrawingView', VOID, VOID, [View]);
  initMetadataForInterface(DrawingViewContent, 'DrawingViewContent');
  initMetadataForClass(EditInputEventContext, 'EditInputEventContext', VOID, InputEventContext);
  function get_drawing() {
    return this.v1o().u3b();
  }
  initMetadataForInterface(Editor, 'Editor');
  initMetadataForObject(GridPainterRegistry, 'GridPainterRegistry');
  initMetadataForObject(Look, 'Look');
  initMetadataForClass(Type, 'Type', VOID, Enum);
  initMetadataForClass(SelectionChangeEvent, 'SelectionChangeEvent');
  initMetadataForClass(SelectionDrawingStrategy, 'SelectionDrawingStrategy', VOID, Enum);
  function get_selectionCount() {
    // Inline function 'kotlin.collections.count' call
    return this.x3d().o();
  }
  initMetadataForInterface(SelectionManager, 'SelectionManager');
  initMetadataForClass(SnapResult, 'SnapResult', SnapResult);
  initMetadataForCompanion(Companion);
  initMetadataForClass(SnappableXCoordinate, 'SnappableXCoordinate');
  initMetadataForClass(SnappableYCoordinate, 'SnappableYCoordinate');
  function getSnapHighlightX_0(x, y, snappable) {
    return null;
  }
  function getSnapHighlightY_0(x, y, snappable) {
    return null;
  }
  initMetadataForInterface(Snapper, 'Snapper');
  function mouseClicked(e, p) {
    return this.f3f(e, p.kn_1, p.ln_1);
  }
  function mousePressed(e, p) {
    return this.h3f(e, p.kn_1, p.ln_1);
  }
  function mouseReleased(e, p) {
    return this.j3f(e, p.kn_1, p.ln_1);
  }
  function mouseMoved(e, p) {
    return this.l3f(e, p.kn_1, p.ln_1);
  }
  function mouseDragged(e, p) {
    return this.n3f(e, p.kn_1, p.ln_1);
  }
  initMetadataForInterface(Tool, 'Tool');
  initMetadataForClass(DeleteQuestion, 'DeleteQuestion');
  function move$default(movables, offset, editor, register, additionalCommands, $super) {
    additionalCommands = additionalCommands === VOID ? emptyList() : additionalCommands;
    var tmp;
    if ($super === VOID) {
      this.r3f(movables, offset, editor, register, additionalCommands);
      tmp = Unit_instance;
    } else {
      tmp = $super.r3f.call(this, movables, offset, editor, register, additionalCommands);
    }
    return tmp;
  }
  initMetadataForInterface(DrawingAppService, 'DrawingAppService');
  initMetadataForCompanion(Companion_0);
  initMetadataForClass(DrawingAppServiceImpl, 'DrawingAppServiceImpl', DrawingAppServiceImpl, VOID, [DrawingAppService]);
  initMetadataForClass(AuthorizationBuilder, 'AuthorizationBuilder', AuthorizationBuilder);
  initMetadataForClass(Authorization, 'Authorization');
  initMetadataForObject(Authorizer, 'Authorizer');
  initMetadataForClass(DesktopUserHolder, 'DesktopUserHolder');
  initMetadataForCompanion(Companion_1);
  initMetadataForClass(DesktopUser, 'DesktopUser');
  initMetadataForObject(EditAuthModule, 'EditAuthModule', VOID, AbstractModule);
  initMetadataForClass(Operation, 'Operation', VOID, Enum);
  initMetadataForCompanion(Companion_2);
  initMetadataForObject($serializer, '$serializer', VOID, VOID, [GeneratedSerializer]);
  initMetadataForClass(UserIdentity, 'UserIdentity', VOID, VOID, VOID, VOID, VOID, {0: $serializer_getInstance});
  initMetadataForClass(AbstractDrawingViewCommand, 'AbstractDrawingViewCommand', VOID, AbstractCommand);
  initMetadataForCompanion(Companion_3);
  initMetadataForClass(Snapshot, 'Snapshot', VOID, VOID, [Disposable]);
  initMetadataForCompanion(Companion_4);
  initMetadataForClass(CommandIterator, 'CommandIterator', VOID, AbstractIterator);
  initMetadataForClass(SourcingCommandManager, 'SourcingCommandManager', SourcingCommandManager, VOID, [CommandManager]);
  initMetadataForCompanion(Companion_5);
  initMetadataForClass(Transaction, 'Transaction', Transaction);
  initMetadataForClass(TransactionCommand, 'TransactionCommand', VOID, AbstractCommand, [Undoable]);
  initMetadataForClass(TransactionStackWriter, 'TransactionStackWriter');
  initMetadataForClass(DropEvent, 'DropEvent');
  initMetadataForInterface(DragDestination, 'DragDestination', VOID, VOID, [Component]);
  initMetadataForClass(DragDestinationHighlightFactoryRegistry, 'DragDestinationHighlightFactoryRegistry', DragDestinationHighlightFactoryRegistry);
  initMetadataForInterface(DragDestinationHighlightFactory, 'DragDestinationHighlightFactory');
  initMetadataForObject(DragDestinationHighlighter, 'DragDestinationHighlighter', VOID, VOID, [DragManagerDestinationPlugin]);
  initMetadataForCompanion(Companion_6);
  initMetadataForClass(DragManagerImpl, 'DragManagerImpl', VOID, InputEventHandlerAdapter, [InputEventHandler]);
  initMetadataForObject(EditDragModule, 'EditDragModule', VOID, AbstractModule);
  initMetadataForClass(AddCommand, 'AddCommand', VOID, AbstractDrawingViewCommand, [Undoable]);
  initMetadataForObject(EditEditorModule, 'EditEditorModule', VOID, AbstractModule);
  initMetadataForClass(MouseEventDelegator, 'MouseEventDelegator', VOID, MouseAdapter);
  initMetadataForClass(KeyEventDelegator, 'KeyEventDelegator', VOID, KeyAdapter);
  initMetadataForClass(DrawingViewListener, 'DrawingViewListener', VOID, VOID, [PropertyChangeListener]);
  initMetadataForClass(DrawingListener, 'DrawingListener', VOID, DrawableContainerAdapter);
  initMetadataForClass(EditorImpl, 'EditorImpl', VOID, VOID, [Editor]);
  initMetadataForClass(AbstractComponent, 'AbstractComponent', VOID, AbstractStyledDrawable, [Component]);
  initMetadataForClass(AbstractPathFigure, 'AbstractPathFigure', VOID, AbstractComponent, [Component, Mirrorable]);
  initMetadataForInterface(FigureFactory, 'FigureFactory');
  initMetadataForClass(sam$io_antarescircuit_jabbah_edit_figure_FigureFactory$0, 'sam$io_antarescircuit_jabbah_edit_figure_FigureFactory$0', VOID, VOID, [FigureFactory, FunctionAdapter]);
  initMetadataForObject(FigureRegistry, 'FigureRegistry');
  initMetadataForClass(FigureGroup, 'FigureGroup');
  initMetadataForClass(FigureProvider, 'FigureProvider');
  initMetadataForClass(DrawingViewSearch, 'DrawingViewSearch', DrawingViewSearch);
  initMetadataForCompanion(Companion_7);
  initMetadataForClass(BelowSmHighlighter, 'BelowSmHighlighter');
  initMetadataForClass(EditHighlightModule$highlighterFactory$1);
  initMetadataForObject(EditHighlightModule, 'EditHighlightModule', VOID, AbstractModule);
  initMetadataForClass(Type_0, 'Type', VOID, Enum);
  initMetadataForClass(HighlightChangeEvent, 'HighlightChangeEvent');
  initMetadataForClass(ComponentContainerImpl, 'ComponentContainerImpl', ComponentContainerImpl, DrawableContainerImpl, [ComponentContainer]);
  initMetadataForClass(ComponentMessage, 'ComponentMessage');
  initMetadataForClass(ComponentMessageType, 'ComponentMessageType', VOID, Enum);
  initMetadataForClass(CopyPasteService, 'CopyPasteService', CopyPasteService);
  initMetadataForClass(DrawingImpl, 'DrawingImpl', DrawingImpl, ComponentContainerImpl, [Drawing]);
  initMetadataForClass(DrawingServiceImpl, 'DrawingServiceImpl', DrawingServiceImpl);
  initMetadataForCompanion(Companion_8);
  initMetadataForClass(Size, 'Size', VOID, Enum);
  initMetadataForCompanion(Companion_9);
  initMetadataForClass(AbstractCurveComponent, 'AbstractCurveComponent', VOID, AbstractComponent, [Transparent, Mirrorable]);
  initMetadataForCompanion(Companion_10);
  initMetadataForClass(EventHandler, 'EventHandler', VOID, InputEventHandlerAdapter);
  initMetadataForClass(CurveEventHandler, 'CurveEventHandler', VOID, EventHandler);
  initMetadataForClass(QuadCurveInputEventHandler, 'QuadCurveInputEventHandler', VOID, InputEventHandlerAdapter);
  initMetadataForClass(AbstractSelectionModel, 'AbstractSelectionModel', VOID, AbstractDrawable, [Drawable]);
  initMetadataForInterface(UnzoomableSelectionModel, 'UnzoomableSelectionModel', VOID, VOID, [Drawable, Unzoomable]);
  initMetadataForClass(AbstractHandleSelectionModel, 'AbstractHandleSelectionModel', VOID, AbstractSelectionModel, [UnzoomableSelectionModel]);
  initMetadataForClass(AbstractCurveHandleSelectionModel, 'AbstractCurveHandleSelectionModel', VOID, AbstractHandleSelectionModel);
  initMetadataForCompanion(Companion_11);
  initMetadataForClass(CubicCurveComponent, 'CubicCurveComponent', CubicCurveComponent, AbstractCurveComponent);
  initMetadataForClass(CubicCurveHandleSelectionModel, 'CubicCurveHandleSelectionModel', VOID, AbstractCurveHandleSelectionModel);
  initMetadataForClass(SelectedColorSelectionModel, 'SelectedColorSelectionModel', VOID, AbstractSelectionModel);
  initMetadataForClass(AbstractSelectedColorWrappingSelectionModel, 'AbstractSelectedColorWrappingSelectionModel', VOID, SelectedColorSelectionModel);
  initMetadataForClass(CubicCurveReplaceSelectionModel, 'CubicCurveReplaceSelectionModel', VOID, AbstractSelectedColorWrappingSelectionModel);
  initMetadataForObject(EditModuleCurveModule, 'EditModuleCurveModule', VOID, AbstractModule);
  initMetadataForClass(MoveCurvePointCommand, 'MoveCurvePointCommand', VOID, AbstractDrawingViewCommand, [Undoable]);
  initMetadataForCompanion(Companion_12);
  initMetadataForClass(QuadCurveComponent, 'QuadCurveComponent', QuadCurveComponent, AbstractCurveComponent);
  initMetadataForClass(QuadCurveHandleSelectionModel, 'QuadCurveHandleSelectionModel', VOID, AbstractCurveHandleSelectionModel);
  initMetadataForClass(QuadCurveReplaceSelectionModel, 'QuadCurveReplaceSelectionModel', VOID, AbstractSelectedColorWrappingSelectionModel);
  initMetadataForObject(EditModelGroupModule, 'EditModelGroupModule', VOID, AbstractModule);
  initMetadataForCompanion(Companion_13);
  initMetadataForClass(GroupComponent, 'GroupComponent', GroupComponent, AbstractComponent);
  initMetadataForClass(GroupComponentSelectionModel, 'GroupComponentSelectionModel', VOID, AbstractSelectionModel);
  initMetadataForCompanion(Companion_14);
  initMetadataForClass(AbstractRectangularComponent, 'AbstractRectangularComponent', VOID, AbstractComponent, [MutableRectangularShape, Mirrorable]);
  initMetadataForInterface(Describable, 'Describable');
  initMetadataForInterface(Labeled, 'Labeled');
  initMetadataForClass(RectangularComponent, 'RectangularComponent', VOID, AbstractRectangularComponent, [Transparent, Describable, Labeled, Component, Mirrorable]);
  initMetadataForClass(RectangleComponent, 'RectangleComponent', RectangleComponent, RectangularComponent);
  initMetadataForClass(ImageComponent, 'ImageComponent', ImageComponent, RectangleComponent);
  initMetadataForClass(ImageIdentification, 'ImageIdentification', ImageIdentification, AbstractStorable, [Namable]);
  initMetadataForClass(ImageData, 'ImageData');
  initMetadataForClass(AddPolylinePointCommand, 'AddPolylinePointCommand', VOID, AbstractCommand, [Undoable]);
  initMetadataForCompanion(Companion_15);
  initMetadataForClass(CompactablePolyline, 'CompactablePolyline', CompactablePolyline_init_$Create$);
  initMetadataForObject(EditModelPolylineModule, 'EditModelPolylineModule', VOID, AbstractModule);
  initMetadataForClass(JoinPolylinePointsCommand, 'JoinPolylinePointsCommand', VOID, AbstractCommand, [Undoable]);
  initMetadataForCompanion(Companion_16);
  initMetadataForClass(MovePolylinePointCommand, 'MovePolylinePointCommand', VOID, AbstractCommand, [Undoable]);
  initMetadataForCompanion(Companion_17);
  initMetadataForClass(PolylineComponent, 'PolylineComponent', PolylineComponent, AbstractComponent, [Polyline, Transparent, Component, Mirrorable]);
  initMetadataForCompanion(Companion_18);
  initMetadataForClass(PolylineEventHandler, 'PolylineEventHandler', VOID, EventHandler);
  initMetadataForClass(PolylinePointInputEventHandler, 'PolylinePointInputEventHandler', VOID, InputEventHandlerAdapter);
  initMetadataForClass(PolylineHandleSelectionModel, 'PolylineHandleSelectionModel', VOID, AbstractHandleSelectionModel);
  initMetadataForClass(PolylineReplaceSelectionModel, 'PolylineReplaceSelectionModel', VOID, AbstractSelectedColorWrappingSelectionModel);
  initMetadataForCompanion(Companion_19);
  initMetadataForObject(EditModelRectangleModule, 'EditModelRectangleModule', VOID, AbstractModule);
  initMetadataForCompanion(Companion_20);
  initMetadataForClass(RectangularBelowSelectionModel, 'RectangularBelowSelectionModel', VOID, AbstractSelectionModel);
  initMetadataForCompanion(Companion_21);
  initMetadataForCompanion(Companion_22);
  initMetadataForCompanion(Companion_23);
  initMetadataForClass(EllipseComponent, 'EllipseComponent', EllipseComponent, RectangularComponent);
  initMetadataForCompanion(Companion_24);
  initMetadataForClass(RoundRectangleComponent, 'RoundRectangleComponent', RoundRectangleComponent, RectangularComponent);
  initMetadataForCompanion(Companion_25);
  initMetadataForClass(RectangleEventHandler, 'RectangleEventHandler', VOID, EventHandler);
  initMetadataForClass(NorthWestHandler, 'NorthWestHandler', VOID, InputEventHandlerAdapter);
  initMetadataForClass(NorthHandler, 'NorthHandler', VOID, InputEventHandlerAdapter);
  initMetadataForClass(NorthEastHandler, 'NorthEastHandler', VOID, InputEventHandlerAdapter);
  initMetadataForClass(EastHandler, 'EastHandler', VOID, InputEventHandlerAdapter);
  initMetadataForClass(SouthEastHandler, 'SouthEastHandler', VOID, InputEventHandlerAdapter);
  initMetadataForClass(SouthHandler, 'SouthHandler', VOID, InputEventHandlerAdapter);
  initMetadataForClass(SouthWestHandler, 'SouthWestHandler', VOID, InputEventHandlerAdapter);
  initMetadataForClass(WestHandler, 'WestHandler', VOID, InputEventHandlerAdapter);
  initMetadataForClass(RectangularHandleSelectionModel, 'RectangularHandleSelectionModel', VOID, AbstractHandleSelectionModel);
  initMetadataForClass(DrawStrategy, 'DrawStrategy', VOID, Enum);
  initMetadataForClass(RectangularReplaceSelectionModel$DrawStrategy$SHAPE, 'SHAPE', VOID, DrawStrategy);
  initMetadataForClass(RectangularReplaceSelectionModel$DrawStrategy$COMPONENT, 'COMPONENT', VOID, DrawStrategy);
  initMetadataForClass(RectangularReplaceSelectionModel, 'RectangularReplaceSelectionModel', VOID, AbstractSelectedColorWrappingSelectionModel);
  initMetadataForClass(ResizeRectangleCommand, 'ResizeRectangleCommand', VOID, AbstractCommand, [Undoable]);
  initMetadataForCompanion(Companion_26);
  function contains_0(x, y) {
    throw UnsupportedOperationException_init_$Create$('not implemented');
  }
  function contains_1(p) {
    throw UnsupportedOperationException_init_$Create$('not implemented');
  }
  function intersects(rect) {
    throw UnsupportedOperationException_init_$Create$('not implemented');
  }
  initMetadataForInterface(TextComponent, 'TextComponent', VOID, VOID, [Component, RectangularShape]);
  initMetadataForClass(AbstractTextComponent, 'AbstractTextComponent', VOID, AbstractRectangularComponent, [TextComponent, Transparent]);
  initMetadataForClass(HorizontalAlignment, 'HorizontalAlignment', VOID, Enum);
  initMetadataForClass(HorizontalAlignment$LEFT, 'LEFT', VOID, HorizontalAlignment);
  initMetadataForClass(HorizontalAlignment$CENTER, 'CENTER', VOID, HorizontalAlignment);
  initMetadataForClass(HorizontalAlignment$RIGHT, 'RIGHT', VOID, HorizontalAlignment);
  initMetadataForCompanion(Companion_27);
  initMetadataForClass(VerticalAlignment, 'VerticalAlignment', VOID, Enum);
  initMetadataForClass(VerticalAlignment$TOP, 'TOP', VOID, VerticalAlignment);
  initMetadataForClass(VerticalAlignment$CENTER, 'CENTER', VOID, VerticalAlignment);
  initMetadataForClass(VerticalAlignment$BOTTOM, 'BOTTOM', VOID, VerticalAlignment);
  initMetadataForCompanion(Companion_28);
  initMetadataForCompanion(Companion_29);
  initMetadataForClass(Alignment, 'Alignment');
  initMetadataForObject(EditModelTextModule, 'EditModelTextModule', VOID, AbstractModule);
  initMetadataForClass(HorizontalLabel, 'HorizontalLabel');
  initMetadataForCompanion(Companion_30);
  initMetadataForClass(Label, 'Label', VOID, AbstractDrawable, [Mirrorable, Locatable]);
  initMetadataForCompanion(Companion_31);
  initMetadataForClass(LabelComponent, 'LabelComponent', LabelComponent, AbstractRectangularComponent, [TextComponent, Transparent, Labeled]);
  initMetadataForClass(RotationDisplayStrategy, 'RotationDisplayStrategy', VOID, Enum);
  initMetadataForClass(RotationDisplayStrategy$IGNORE, 'IGNORE', VOID, RotationDisplayStrategy);
  initMetadataForClass(RotationDisplayStrategy$ROTATE_HALF, 'ROTATE_HALF', VOID, RotationDisplayStrategy);
  initMetadataForClass(RotationDisplayStrategy$KEEP_HORIZONTAL, 'KEEP_HORIZONTAL', VOID, RotationDisplayStrategy);
  initMetadataForCompanion(Companion_32);
  initMetadataForClass(SimpleTextComponent, 'SimpleTextComponent', SimpleTextComponent, AbstractTextComponent, [TextComponent, Transparent]);
  initMetadataForClass(UndefinedTextComponentFactory, 'UndefinedTextComponentFactory', UndefinedTextComponentFactory);
  initMetadataForClass(RectangularShapeTextComponentDecorator, 'RectangularShapeTextComponentDecorator');
  initMetadataForClass(TextDrawableButtonRenderer, 'TextDrawableButtonRenderer', VOID, AbstractDrawableButtonRenderer);
  initMetadataForClass(ScriptProperty, 'ScriptProperty', ScriptProperty);
  function get_isNotEmpty() {
    return !this.qv();
  }
  function getTranslation() {
    return this.m4e(System_getInstance().hm());
  }
  function withTranslation(text) {
    return this.o4e(System_getInstance().hm(), text);
  }
  function getOptionalTranslation() {
    return this.q4e(System_getInstance().hm());
  }
  initMetadataForInterface(Translatable, 'Translatable');
  initMetadataForClass(TranslatableText, 'TranslatableText', TranslatableText, VOID, [Translatable]);
  initMetadataForCompanion(Companion_33);
  initMetadataForClass(Translation, 'Translation', Translation, VOID, [Storable]);
  initMetadataForCompanion(Companion_34);
  initMetadataForClass(Description, 'Description', VOID, VOID, [Translatable]);
  initMetadataForClass(DescriptionChangedEvent, 'DescriptionChangedEvent');
  initMetadataForClass(observableDescription$3, VOID, VOID, ObservableProperty);
  initMetadataForCompanion(Companion_35);
  initMetadataForClass(Name, 'Name', VOID, VOID, [Translatable]);
  initMetadataForClass(NameChangedEvent, 'NameChangedEvent');
  initMetadataForClass(observableName$3, VOID, VOID, ObservableProperty);
  initMetadataForClass(EditModule$drawingViewFactory$1);
  initMetadataForClass(EditModule$imageRepository$1);
  initMetadataForObject(EditModule, 'EditModule', VOID, AbstractModule);
  initMetadataForClass(PropertyValueException, 'PropertyValueException', VOID, IllegalArgumentException);
  initMetadataForCompanion(Companion_36);
  initMetadataForClass(Magnitude, 'Magnitude', VOID, Enum);
  initMetadataForCompanion(Companion_37);
  initMetadataForClass(MagnitudeValue, 'MagnitudeValue');
  initMetadataForCompanion(Companion_38);
  initMetadataForClass(SIUnit, 'SIUnit', VOID, Enum);
  initMetadataForCompanion(Companion_39);
  initMetadataForClass(AbstractBelowSelectionModel, 'AbstractBelowSelectionModel', VOID, AbstractSelectionModel, [Colorable]);
  initMetadataForClass(EventHandler_0, 'EventHandler', VOID, InputEventHandlerAdapter);
  initMetadataForClass(AbstractSelectionModel$geometryUpdateListener$1, VOID, VOID, DrawableAdapter);
  initMetadataForClass(BoundingBoxBelowSelectionModel, 'BoundingBoxBelowSelectionModel', VOID, AbstractBelowSelectionModel);
  initMetadataForObject(EditSelectModule, 'EditSelectModule', VOID, AbstractModule);
  function setLocation(x, y) {
    this.v20(new Point2D(x, y));
  }
  initMetadataForInterface(Handle, 'Handle', VOID, VOID, [Drawable, Unzoomable]);
  initMetadataForClass(MoveCommand, 'MoveCommand', VOID, AbstractCommand);
  initMetadataForClass(RectangularHandle, 'RectangularHandle', VOID, AbstractRectangularUnzoomable, [Handle]);
  initMetadataForCompanion(Companion_40);
  initMetadataForClass(EventHandler_1, 'EventHandler', VOID, InputEventHandlerAdapter);
  function contains_2(rect) {
    return this.ho(rect.p1a(), rect.q1a(), rect.f1c(), rect.h1c());
  }
  initMetadataForInterface(RubberBand, 'RubberBand', VOID, VOID, [Unzoomable]);
  initMetadataForClass(RectangularRubberBand, 'RectangularRubberBand', RectangularRubberBand, AbstractRectangle, [RubberBand]);
  initMetadataForClass(SelectionTargetStrategy, 'SelectionTargetStrategy', VOID, Enum);
  initMetadataForClass(RubberBandHandler$SelectionTargetStrategy$CONTAINS, 'CONTAINS', VOID, SelectionTargetStrategy);
  initMetadataForClass(RubberBandHandler$SelectionTargetStrategy$INTERSECTS, 'INTERSECTS', VOID, SelectionTargetStrategy);
  initMetadataForCompanion(Companion_41);
  initMetadataForCompanion(Companion_42);
  initMetadataForClass(RubberBandHandler, 'RubberBandHandler', VOID, InputEventHandlerAdapter);
  initMetadataForCompanion(Companion_43);
  initMetadataForClass(SelectionManagerImpl, 'SelectionManagerImpl', VOID, VOID, [SelectionManager]);
  initMetadataForClass(Entry, 'Entry');
  initMetadataForClass(SelectionModelFactoryImpl, 'SelectionModelFactoryImpl', SelectionModelFactoryImpl);
  initMetadataForCompanion(Companion_44);
  initMetadataForClass(AbstractTool, 'AbstractTool', VOID, VOID, [Tool]);
  initMetadataForClass(ToolAdapter, 'ToolAdapter', VOID, AbstractTool);
  initMetadataForClass(SelectionToolImpl, 'SelectionToolImpl', VOID, ToolAdapter, [Tool]);
  initMetadataForClass(SimpleSelectionModelProvider, 'SimpleSelectionModelProvider');
  initMetadataForObject(SemanticRegistry, 'SemanticRegistry');
  initMetadataForClass(DoSnapResult, 'DoSnapResult');
  initMetadataForClass(AbstractSnapper, 'AbstractSnapper', VOID, AbstractDrawable, [Snapper]);
  initMetadataForCompanion(Companion_45);
  initMetadataForClass(SnapHighlightX, 'SnapHighlightX', VOID, AbstractDrawable, [Unzoomable]);
  initMetadataForClass(SnapHighlightY, 'SnapHighlightY', VOID, AbstractDrawable, [Unzoomable]);
  initMetadataForClass(ComponentSnapper, 'ComponentSnapper', VOID, AbstractSnapper);
  initMetadataForCompanion(Companion_46);
  initMetadataForClass(DottedGridPainter, 'DottedGridPainter');
  initMetadataForObject(EditSnapModule, 'EditSnapModule', VOID, AbstractModule);
  initMetadataForCompanion(Companion_47);
  initMetadataForClass(GridImpl, 'GridImpl', GridImpl, AbstractSnapper, [Unzoomable, Snapper]);
  initMetadataForCompanion(Companion_48);
  initMetadataForClass(LineGridPainter, 'LineGridPainter');
  initMetadataForClass(MultiComponentSnappable, 'MultiComponentSnappable', VOID, VOID, [Snappable]);
  initMetadataForCompanion(Companion_49);
  initMetadataForClass(SnapManagerImpl$mouseListener$1, VOID, VOID, MouseAdapter);
  initMetadataForClass(SnapManagerImpl$viewCanvasListener$1, VOID, VOID, VOID, [PropertyChangeListener]);
  initMetadataForClass(SnapManagerImpl, 'SnapManagerImpl');
  initMetadataForCompanion(Companion_50);
  initMetadataForClass(EditStyleType, 'EditStyleType', VOID, StyleType);
  initMetadataForCompanion(Companion_51);
  initMetadataForClass(EditTheme, 'EditTheme', EditTheme, DrawTheme);
  initMetadataForClass(ToolLockAction, 'ToolLockAction', VOID, AbstractAction);
  initMetadataForCompanion(Companion_52);
  initMetadataForClass(GrowingRing, 'GrowingRing', VOID, AbstractRectangularUnzoomable);
  initMetadataForClass(AttentionDrawerImpl$drawAttentionTo$1, VOID, VOID, AnimationTaskAdapter);
  initMetadataForClass(AttentionDrawerImpl, 'AttentionDrawerImpl', AttentionDrawerImpl);
  initMetadataForCompanion(Companion_53);
  initMetadataForClass(ComponentMessageDisplayer, 'ComponentMessageDisplayer');
  initMetadataForClass(ComponentRemoveListener, 'ComponentRemoveListener', VOID, DrawableContainerAdapter);
  initMetadataForClass(BackdropDrawer, 'BackdropDrawer', VOID, AbstractDrawable);
  initMetadataForClass(DrawingViewContentImpl, 'DrawingViewContentImpl', VOID, VOID, [DrawingViewContent]);
  initMetadataForCompanion(Companion_54);
  initMetadataForClass(DrawingViewDrawer, 'DrawingViewDrawer', VOID, DrawableContainerDrawer);
  initMetadataForClass(DrawingViewImpl, 'DrawingViewImpl', VOID, ViewImpl, [DrawingView]);
  //endregion
  function TextComponentFactoryJs() {
  }
  function EditModuleJs() {
    EditModuleJs_instance = this;
    AbstractModule.call(this);
  }
  protoOf(EditModuleJs).to = function () {
    IOModuleJs_getInstance().vo();
    DrawModuleJs_getInstance().vo();
    EditModule_getInstance().vo();
    EditModelTextModule_getInstance().f3a_1 = new TextComponentFactoryJs();
  };
  var EditModuleJs_instance;
  function EditModuleJs_getInstance() {
    if (EditModuleJs_instance == null)
      new EditModuleJs();
    return EditModuleJs_instance;
  }
  function AbstractPropertyCommand() {
  }
  function Command() {
  }
  function Undoable() {
  }
  function CommandManager() {
  }
  function CommandEvent(commandManager, type) {
    this.x3a_1 = commandManager;
    this.y3a_1 = type;
  }
  protoOf(CommandEvent).toString = function () {
    return 'CommandEvent(commandManager=' + toString(this.x3a_1) + ', type=' + this.y3a_1.toString() + ')';
  };
  protoOf(CommandEvent).hashCode = function () {
    var result = hashCode(this.x3a_1);
    result = imul(result, 31) + this.y3a_1.hashCode() | 0;
    return result;
  };
  protoOf(CommandEvent).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof CommandEvent))
      return false;
    if (!equals(this.x3a_1, other.x3a_1))
      return false;
    if (!this.y3a_1.equals(other.y3a_1))
      return false;
    return true;
  };
  var CommandEventType_OPEN_CHECKPOINT_instance;
  var CommandEventType_CLOSE_CHECKPOINT_instance;
  var CommandEventType_COMMIT_TRANSACTION_instance;
  var CommandEventType_UNDO_instance;
  var CommandEventType_REDO_instance;
  var CommandEventType_RESET_instance;
  var CommandEventType_entriesInitialized;
  function CommandEventType_initEntries() {
    if (CommandEventType_entriesInitialized)
      return Unit_instance;
    CommandEventType_entriesInitialized = true;
    CommandEventType_OPEN_CHECKPOINT_instance = new CommandEventType('OPEN_CHECKPOINT', 0);
    CommandEventType_CLOSE_CHECKPOINT_instance = new CommandEventType('CLOSE_CHECKPOINT', 1);
    CommandEventType_COMMIT_TRANSACTION_instance = new CommandEventType('COMMIT_TRANSACTION', 2);
    CommandEventType_UNDO_instance = new CommandEventType('UNDO', 3);
    CommandEventType_REDO_instance = new CommandEventType('REDO', 4);
    CommandEventType_RESET_instance = new CommandEventType('RESET', 5);
  }
  function CommandEventType(name, ordinal) {
    Enum.call(this, name, ordinal);
  }
  function CommandManagerActiveEvent(commandManager) {
    this.z3a_1 = commandManager;
  }
  protoOf(CommandManagerActiveEvent).toString = function () {
    return 'CommandManagerActiveEvent(commandManager=' + toString(this.z3a_1) + ')';
  };
  protoOf(CommandManagerActiveEvent).hashCode = function () {
    return hashCode(this.z3a_1);
  };
  protoOf(CommandManagerActiveEvent).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof CommandManagerActiveEvent))
      return false;
    if (!equals(this.z3a_1, other.z3a_1))
      return false;
    return true;
  };
  function CommandEventType_COMMIT_TRANSACTION_getInstance() {
    CommandEventType_initEntries();
    return CommandEventType_COMMIT_TRANSACTION_instance;
  }
  function Component() {
  }
  function ComponentContainer() {
  }
  function DragManagerDestinationPlugin() {
  }
  function Drawing() {
  }
  function DrawingView() {
  }
  function DrawingViewContent() {
  }
  function EditInputEventContext(editor, mouseEvent, keyEvent, x, y, readonly) {
    mouseEvent = mouseEvent === VOID ? null : mouseEvent;
    keyEvent = keyEvent === VOID ? null : keyEvent;
    x = x === VOID ? 0.0 : x;
    y = y === VOID ? 0.0 : y;
    readonly = readonly === VOID ? false : readonly;
    InputEventContext.call(this, editor.v1o(), mouseEvent, keyEvent, x, y, readonly);
    this.w3c_1 = editor;
  }
  protoOf(EditInputEventContext).v22 = function (x, y) {
    return new EditInputEventContext(this.w3c_1, this.o22_1, this.p22_1, x, y);
  };
  protoOf(EditInputEventContext).f3c = function () {
    return this.w3c_1.v1o();
  };
  protoOf(EditInputEventContext).x3c = function () {
    return this.w3c_1.v1o();
  };
  function Editor() {
  }
  function GridPainterRegistry() {
    GridPainterRegistry_instance = this;
    var tmp = this;
    // Inline function 'kotlin.collections.mutableMapOf' call
    tmp.e3d_1 = LinkedHashMap_init_$Create$();
  }
  protoOf(GridPainterRegistry).f3d = function (name, factory) {
    // Inline function 'kotlin.collections.set' call
    this.e3d_1.y1(name, factory);
  };
  protoOf(GridPainterRegistry).ob = function (name) {
    return ensureNotNull(this.e3d_1.g2(name));
  };
  var GridPainterRegistry_instance;
  function GridPainterRegistry_getInstance() {
    if (GridPainterRegistry_instance == null)
      new GridPainterRegistry();
    return GridPainterRegistry_instance;
  }
  function updateFillBasicComponents($this) {
    $this.h3d_1 = BaseModule_getInstance().zo_1.ht('antares.view.fillBasicComponents');
  }
  function Look$initialize$lambda(it) {
    updateFillBasicComponents(Look_getInstance());
    return Unit_instance;
  }
  function Look() {
    Look_instance = this;
    this.g3d_1 = 'antares.view.fillBasicComponents';
    this.h3d_1 = true;
    this.i3d_1 = 7;
    this.j3d_1 = 7;
    this.k3d_1 = new FontImpl(LogicalFontFamily_DIALOG_getInstance(), FontStyle_PLAIN_getInstance().p2n_1, 11);
    this.l3d_1 = new FontImpl(LogicalFontFamily_SANS_SERIF_getInstance(), FontStyle_PLAIN_getInstance().p2n_1, numberToInt(1.5 * 7));
    this.m3d_1 = new FontImpl(LogicalFontFamily_SANS_SERIF_getInstance(), FontStyle_PLAIN_getInstance().p2n_1, numberToInt(1.5 * 7));
    this.n3d_1 = new FontImpl(LogicalFontFamily_SANS_SERIF_getInstance(), FontStyle_PLAIN_getInstance().p2n_1, numberToInt(1.4 * 7));
    this.o3d_1 = new FontImpl(LogicalFontFamily_MONOSPACED_getInstance(), FontStyle_PLAIN_getInstance().p2n_1, numberToInt(1.8 * 7));
  }
  protoOf(Look).k1j = function (eventBus) {
    var tmp = getKClass(PreferencesChangedEvent);
    eventBus.z17(tmp, Look$initialize$lambda);
    updateFillBasicComponents(this);
  };
  protoOf(Look).p3d = function (value) {
    // Inline function 'kotlin.math.ceil' call
    var x = value / 2 / 7;
    var tmp$ret$0 = Math.ceil(x);
    return imul(14, numberToInt(tmp$ret$0));
  };
  protoOf(Look).q3d = function () {
    return Themes_getInstance().h2g().x2f_1.c1u().y1x_1.r2f(192);
  };
  protoOf(Look).r3d = function () {
    return this.q3d();
  };
  var Look_instance;
  function Look_getInstance() {
    if (Look_instance == null)
      new Look();
    return Look_instance;
  }
  var Type_SELECTED_instance;
  var Type_DESELECTED_instance;
  var Type_entriesInitialized;
  function Type_initEntries() {
    if (Type_entriesInitialized)
      return Unit_instance;
    Type_entriesInitialized = true;
    Type_SELECTED_instance = new Type('SELECTED', 0);
    Type_DESELECTED_instance = new Type('DESELECTED', 1);
  }
  function SelectionChangeEvent_init_$Init$(view, components, selected, $this) {
    SelectionChangeEvent.call($this, view, selected ? Type_SELECTED_getInstance() : Type_DESELECTED_getInstance(), components);
    return $this;
  }
  function SelectionChangeEvent_init_$Create$(view, components, selected) {
    return SelectionChangeEvent_init_$Init$(view, components, selected, objectCreate(protoOf(SelectionChangeEvent)));
  }
  function Type(name, ordinal) {
    Enum.call(this, name, ordinal);
  }
  function Type_SELECTED_getInstance() {
    Type_initEntries();
    return Type_SELECTED_instance;
  }
  function Type_DESELECTED_getInstance() {
    Type_initEntries();
    return Type_DESELECTED_instance;
  }
  function SelectionChangeEvent(view, type, components) {
    this.s3d_1 = view;
    this.t3d_1 = type;
    this.u3d_1 = components;
    this.v3d_1 = this.t3d_1.equals(Type_SELECTED_getInstance());
  }
  protoOf(SelectionChangeEvent).toString = function () {
    return 'SelectionChangeEvent(view=' + toString(this.s3d_1) + ', type=' + this.t3d_1.toString() + ', components=' + toString(this.u3d_1) + ')';
  };
  protoOf(SelectionChangeEvent).hashCode = function () {
    var result = hashCode(this.s3d_1);
    result = imul(result, 31) + this.t3d_1.hashCode() | 0;
    result = imul(result, 31) + hashCode(this.u3d_1) | 0;
    return result;
  };
  protoOf(SelectionChangeEvent).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof SelectionChangeEvent))
      return false;
    if (!equals(this.s3d_1, other.s3d_1))
      return false;
    if (!this.t3d_1.equals(other.t3d_1))
      return false;
    if (!equals(this.u3d_1, other.u3d_1))
      return false;
    return true;
  };
  var SelectionDrawingStrategy_ABOVE_instance;
  var SelectionDrawingStrategy_REPLACE_instance;
  var SelectionDrawingStrategy_BELOW_instance;
  var SelectionDrawingStrategy_entriesInitialized;
  function SelectionDrawingStrategy_initEntries() {
    if (SelectionDrawingStrategy_entriesInitialized)
      return Unit_instance;
    SelectionDrawingStrategy_entriesInitialized = true;
    SelectionDrawingStrategy_ABOVE_instance = new SelectionDrawingStrategy('ABOVE', 0);
    SelectionDrawingStrategy_REPLACE_instance = new SelectionDrawingStrategy('REPLACE', 1);
    SelectionDrawingStrategy_BELOW_instance = new SelectionDrawingStrategy('BELOW', 2);
  }
  function SelectionDrawingStrategy(name, ordinal) {
    Enum.call(this, name, ordinal);
  }
  function SelectionDrawingStrategy_ABOVE_getInstance() {
    SelectionDrawingStrategy_initEntries();
    return SelectionDrawingStrategy_ABOVE_instance;
  }
  function SelectionDrawingStrategy_REPLACE_getInstance() {
    SelectionDrawingStrategy_initEntries();
    return SelectionDrawingStrategy_REPLACE_instance;
  }
  function SelectionDrawingStrategy_BELOW_getInstance() {
    SelectionDrawingStrategy_initEntries();
    return SelectionDrawingStrategy_BELOW_instance;
  }
  function SelectionManager() {
  }
  function SnapResult(x, y) {
    x = x === VOID ? 0.0 : x;
    y = y === VOID ? 0.0 : y;
    this.f3e_1 = x;
    this.g3e_1 = y;
    this.h3e_1 = 0.0;
    this.i3e_1 = 0.0;
    this.j3e_1 = false;
    this.k3e_1 = false;
    this.l3e_1 = null;
    this.m3e_1 = null;
    this.n3e_1 = null;
    this.o3e_1 = null;
  }
  protoOf(SnapResult).du = function () {
    this.f3e_1 = 0.0;
    this.g3e_1 = 0.0;
    this.h3e_1 = 0.0;
    this.i3e_1 = 0.0;
    this.j3e_1 = false;
    this.k3e_1 = false;
    this.l3e_1 = null;
    this.m3e_1 = null;
    this.n3e_1 = null;
    this.o3e_1 = null;
  };
  protoOf(SnapResult).p3e = function (dx, x, snapper) {
    this.h3e_1 = this.h3e_1 + dx;
    this.f3e_1 = x;
    this.l3e_1 = snapper;
    this.j3e_1 = true;
  };
  protoOf(SnapResult).q3e = function (dy, y, snapper) {
    this.i3e_1 = this.i3e_1 + dy;
    this.g3e_1 = y;
    this.m3e_1 = snapper;
    this.k3e_1 = true;
  };
  function Companion() {
    Companion_instance_4 = this;
    var tmp = this;
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    tmp.r3e_1 = [];
    var tmp_0 = this;
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    tmp_0.s3e_1 = [];
  }
  var Companion_instance_4;
  function Companion_getInstance_9() {
    if (Companion_instance_4 == null)
      new Companion();
    return Companion_instance_4;
  }
  function Snappable() {
  }
  function SnappableXCoordinate(x) {
    this.t3e_1 = x;
  }
  protoOf(SnappableXCoordinate).p1a = function () {
    return this.t3e_1;
  };
  protoOf(SnappableXCoordinate).u3e = function (other) {
    return true;
  };
  protoOf(SnappableXCoordinate).toString = function () {
    return 'SnappableXCoordinate(x=' + this.t3e_1 + ')';
  };
  protoOf(SnappableXCoordinate).hashCode = function () {
    return getNumberHashCode(this.t3e_1);
  };
  protoOf(SnappableXCoordinate).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof SnappableXCoordinate))
      return false;
    if (!equals(this.t3e_1, other.t3e_1))
      return false;
    return true;
  };
  function SnappableYCoordinate(y) {
    this.v3e_1 = y;
  }
  protoOf(SnappableYCoordinate).q1a = function () {
    return this.v3e_1;
  };
  protoOf(SnappableYCoordinate).w3e = function (other) {
    return true;
  };
  protoOf(SnappableYCoordinate).toString = function () {
    return 'SnappableYCoordinate(y=' + this.v3e_1 + ')';
  };
  protoOf(SnappableYCoordinate).hashCode = function () {
    return getNumberHashCode(this.v3e_1);
  };
  protoOf(SnappableYCoordinate).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof SnappableYCoordinate))
      return false;
    if (!equals(this.v3e_1, other.v3e_1))
      return false;
    return true;
  };
  function Snapper() {
  }
  function Tool() {
  }
  function DeleteQuestion(components, drawingView) {
    this.p3f_1 = components;
    this.q3f_1 = drawingView;
  }
  protoOf(DeleteQuestion).toString = function () {
    return 'DeleteQuestion(components=' + toString(this.p3f_1) + ', drawingView=' + toString(this.q3f_1) + ')';
  };
  protoOf(DeleteQuestion).hashCode = function () {
    var result = hashCode(this.p3f_1);
    result = imul(result, 31) + hashCode(this.q3f_1) | 0;
    return result;
  };
  protoOf(DeleteQuestion).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof DeleteQuestion))
      return false;
    if (!equals(this.p3f_1, other.p3f_1))
      return false;
    if (!equals(this.q3f_1, other.q3f_1))
      return false;
    return true;
  };
  function DrawingAppService() {
  }
  function Companion_0() {
    Companion_instance_5 = this;
    this.t3f_1 = logger(getKClass(DrawingAppServiceImpl));
  }
  var Companion_instance_5;
  function Companion_getInstance_10() {
    if (Companion_instance_5 == null)
      new Companion_0();
    return Companion_instance_5;
  }
  function DrawingAppServiceImpl(copyPasteService, commandManager, eventBus) {
    Companion_getInstance_10();
    copyPasteService = copyPasteService === VOID ? EditModule_getInstance().z3f_1 : copyPasteService;
    commandManager = commandManager === VOID ? EditModule_getInstance().v3f_1 : commandManager;
    eventBus = eventBus === VOID ? BaseModule_getInstance().bp_1 : eventBus;
    this.d3g_1 = copyPasteService;
    this.e3g_1 = commandManager;
    this.f3g_1 = eventBus;
  }
  protoOf(DrawingAppServiceImpl).g3g = function (component, drawing) {
  };
  protoOf(DrawingAppServiceImpl).r3f = function (movables, offset, editor, register, additionalCommands) {
    // Inline function 'kotlin.collections.map' call
    // Inline function 'kotlin.collections.mapTo' call
    var destination = ArrayList_init_$Create$(collectionSizeOrDefault(movables, 10));
    var _iterator__ex2g4s = movables.i();
    while (_iterator__ex2g4s.j()) {
      var item = _iterator__ex2g4s.k();
      var tmp$ret$2 = item.cv();
      destination.h(tmp$ret$2);
    }
    var command = new MoveCommand(editor, toList(destination), offset, additionalCommands);
    if (register) {
      // Inline function 'kotlin.collections.forEach' call
      var _iterator__ex2g4s_0 = additionalCommands.i();
      while (_iterator__ex2g4s_0.j()) {
        var element = _iterator__ex2g4s_0.k();
        element.i3a();
      }
      this.e3g_1.u3a(command);
    } else {
      this.e3g_1.t3a(command);
    }
  };
  function _get_userCondition__5rrdq9($this) {
    var tmp = $this.h3g_1;
    if (!(tmp == null))
      return tmp;
    else {
      throwUninitializedPropertyAccessException('userCondition');
    }
  }
  function _get_operation__lk4gty($this) {
    var tmp = $this.i3g_1;
    if (!(tmp == null))
      return tmp;
    else {
      throwUninitializedPropertyAccessException('operation');
    }
  }
  function _get_dataCondition__8uu00w($this) {
    var tmp = $this.j3g_1;
    if (!(tmp == null))
      return tmp;
    else {
      throwUninitializedPropertyAccessException('dataCondition');
    }
  }
  function currentUserCondition$ref() {
    var l = function (p0) {
      return currentUserCondition(p0);
    };
    l.callableName = 'currentUserCondition';
    return l;
  }
  function addAuthorization($this, authorization) {
    $this.k3g_1.h(authorization);
  }
  function AuthorizationBuilder() {
  }
  protoOf(AuthorizationBuilder).l3g = function () {
    var tmp = this;
    tmp.h3g_1 = currentUserCondition$ref();
    return this;
  };
  protoOf(AuthorizationBuilder).m3g = function (operation) {
    this.i3g_1 = operation;
    return this;
  };
  protoOf(AuthorizationBuilder).n3g = function (data) {
    this.j3g_1 = data;
    addAuthorization(Authorizer_getInstance(), new Authorization(_get_userCondition__5rrdq9(this), _get_operation__lk4gty(this), _get_dataCondition__8uu00w(this)));
  };
  function Authorization(userCondition, operation, dataCondition) {
    this.o3g_1 = userCondition;
    this.p3g_1 = operation;
    this.q3g_1 = dataCondition;
  }
  protoOf(Authorization).toString = function () {
    return 'Authorization(userCondition=' + toString(this.o3g_1) + ', operation=' + this.p3g_1.toString() + ', dataCondition=' + toString(this.q3g_1) + ')';
  };
  protoOf(Authorization).hashCode = function () {
    var result = hashCode(this.o3g_1);
    result = imul(result, 31) + this.p3g_1.hashCode() | 0;
    result = imul(result, 31) + hashCode(this.q3g_1) | 0;
    return result;
  };
  protoOf(Authorization).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof Authorization))
      return false;
    if (!equals(this.o3g_1, other.o3g_1))
      return false;
    if (!this.p3g_1.equals(other.p3g_1))
      return false;
    if (!equals(this.q3g_1, other.q3g_1))
      return false;
    return true;
  };
  function Authorizer() {
    Authorizer_instance = this;
    var tmp = this;
    // Inline function 'kotlin.collections.mutableListOf' call
    tmp.k3g_1 = ArrayList_init_$Create$_0();
  }
  protoOf(Authorizer).r3g = function () {
    return new AuthorizationBuilder();
  };
  var Authorizer_instance;
  function Authorizer_getInstance() {
    if (Authorizer_instance == null)
      new Authorizer();
    return Authorizer_instance;
  }
  function currentUserCondition(user) {
    return user.s3g().equals(EditAuthModule_getInstance().v3g().w3g().s3g());
  }
  function DesktopUserHolder(user) {
    this.x3g_1 = user;
  }
  protoOf(DesktopUserHolder).w3g = function () {
    return this.x3g_1;
  };
  function Companion_1() {
    Companion_instance_6 = this;
    this.y3g_1 = new DesktopUser(Companion_getInstance_12().DEVELOPER, 'developer', true);
    this.z3g_1 = new DesktopUser(Companion_getInstance_12().ANYBODY, 'anybody', false);
  }
  var Companion_instance_6;
  function Companion_getInstance_11() {
    if (Companion_instance_6 == null)
      new Companion_1();
    return Companion_instance_6;
  }
  function DesktopUser(identity, name, isDeveloper) {
    Companion_getInstance_11();
    this.a3h_1 = identity;
    this.b3h_1 = name;
    this.c3h_1 = isDeveloper;
  }
  protoOf(DesktopUser).s3g = function () {
    return this.a3h_1;
  };
  protoOf(DesktopUser).toString = function () {
    return 'DesktopUser(identity=' + this.a3h_1.toString() + ', name=' + this.b3h_1 + ', isDeveloper=' + this.c3h_1 + ')';
  };
  protoOf(DesktopUser).hashCode = function () {
    var result = this.a3h_1.hashCode();
    result = imul(result, 31) + getStringHashCode(this.b3h_1) | 0;
    result = imul(result, 31) + getBooleanHashCode(this.c3h_1) | 0;
    return result;
  };
  protoOf(DesktopUser).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof DesktopUser))
      return false;
    if (!this.a3h_1.equals(other.a3h_1))
      return false;
    if (!(this.b3h_1 === other.b3h_1))
      return false;
    if (!(this.c3h_1 === other.c3h_1))
      return false;
    return true;
  };
  function EditAuthModule() {
    EditAuthModule_instance = this;
    AbstractModule.call(this);
  }
  protoOf(EditAuthModule).v3g = function () {
    var tmp = this.u3g_1;
    if (!(tmp == null))
      return tmp;
    else {
      throwUninitializedPropertyAccessException('userHolder');
    }
  };
  protoOf(EditAuthModule).to = function () {
  };
  var EditAuthModule_instance;
  function EditAuthModule_getInstance() {
    if (EditAuthModule_instance == null)
      new EditAuthModule();
    return EditAuthModule_instance;
  }
  var Operation_View_instance;
  var Operation_Change_instance;
  var Operation_Execute_instance;
  var Operation_entriesInitialized;
  function Operation_initEntries() {
    if (Operation_entriesInitialized)
      return Unit_instance;
    Operation_entriesInitialized = true;
    Operation_View_instance = new Operation('View', 0);
    Operation_Change_instance = new Operation('Change', 1);
    Operation_Execute_instance = new Operation('Execute', 2);
  }
  function Operation(name, ordinal) {
    Enum.call(this, name, ordinal);
  }
  function Operation_View_getInstance() {
    Operation_initEntries();
    return Operation_View_instance;
  }
  function Operation_Change_getInstance() {
    Operation_initEntries();
    return Operation_Change_instance;
  }
  function Companion_2() {
    Companion_instance_7 = this;
    this.DEVELOPER = new UserIdentity('5ecf330b-e395-4e17-88b0-0883834b384a');
    this.ANYBODY = new UserIdentity('7e840175-f9c4-4886-a221-ef91e3493e27');
  }
  protoOf(Companion_2).d3h = function () {
    return this.DEVELOPER;
  };
  protoOf(Companion_2).e3h = function () {
    return this.ANYBODY;
  };
  protoOf(Companion_2).random = function () {
    return new UserIdentity(System_getInstance().dm(null).toString());
  };
  protoOf(Companion_2).f3h = function () {
    return $serializer_getInstance();
  };
  var Companion_instance_7;
  function Companion_getInstance_12() {
    if (Companion_instance_7 == null)
      new Companion_2();
    return Companion_instance_7;
  }
  function $serializer() {
    $serializer_instance = this;
    var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('io.antarescircuit.jabbah.edit.auth.UserIdentity', this, 1);
    tmp0_serialDesc.cl('id', false);
    this.g3h_1 = tmp0_serialDesc;
  }
  protoOf($serializer).xj = function () {
    return this.g3h_1;
  };
  protoOf($serializer).zk = function () {
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [StringSerializer_getInstance()];
  };
  var $serializer_instance;
  function $serializer_getInstance() {
    if ($serializer_instance == null)
      new $serializer();
    return $serializer_instance;
  }
  function UserIdentity(id) {
    Companion_getInstance_12();
    this.id = id;
  }
  protoOf(UserIdentity).cv = function () {
    return this.id;
  };
  protoOf(UserIdentity).toString = function () {
    return this.id;
  };
  protoOf(UserIdentity).yd = function () {
    return this.id;
  };
  protoOf(UserIdentity).dv = function (id) {
    return new UserIdentity(id);
  };
  protoOf(UserIdentity).copy = function (id, $super) {
    id = id === VOID ? this.id : id;
    return $super === VOID ? this.dv(id) : $super.dv.call(this, id);
  };
  protoOf(UserIdentity).hashCode = function () {
    return getStringHashCode(this.id);
  };
  protoOf(UserIdentity).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof UserIdentity))
      return false;
    if (!(this.id === other.id))
      return false;
    return true;
  };
  function _get_tags__de2s7m($this) {
    var tmp0 = $this.j3h_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('tags', 1, tmp, AbstractCommand$_get_tags_$ref_c6j3vo(), null);
    return tmp0.j2();
  }
  function AbstractCommand$tags$delegate$lambda() {
    // Inline function 'kotlin.collections.mutableSetOf' call
    return LinkedHashSet_init_$Create$();
  }
  function AbstractCommand$_get_tags_$ref_c6j3vo() {
    return function (p0) {
      return _get_tags__de2s7m(p0);
    };
  }
  function AbstractCommand(descriptionKey, editor) {
    editor = editor === VOID ? null : editor;
    this.h3h_1 = editor;
    this.i3h_1 = Translations_getInstance().bn(descriptionKey, []);
    var tmp = this;
    tmp.j3h_1 = lazy(AbstractCommand$tags$delegate$lambda);
  }
  protoOf(AbstractCommand).g3a = function () {
    return this.i3h_1;
  };
  protoOf(AbstractCommand).k20 = function () {
    var tmp0_safe_receiver = this.h3h_1;
    var tmp1_safe_receiver = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.u3b();
    if (tmp1_safe_receiver == null)
      null;
    else {
      tmp1_safe_receiver.k20();
    }
  };
  protoOf(AbstractCommand).j3a = function (names) {
    addAll(_get_tags__de2s7m(this), names);
  };
  function AbstractDrawingViewCommand(descriptionKey, view) {
    AbstractCommand.call(this, descriptionKey);
    this.n3h_1 = view;
  }
  protoOf(AbstractDrawingViewCommand).k20 = function () {
    this.n3h_1.u3b().k20();
  };
  function _get_LOG__e5r759($this) {
    var tmp0 = $this.o3h_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('LOG', 1, tmp, Snapshot$Companion$_get_LOG_$ref_mr21gk(), null);
    return tmp0.j2();
  }
  function Snapshot$Companion$_get_LOG_$ref_mr21gk() {
    return function (p0) {
      return _get_LOG__e5r759(p0);
    };
  }
  function Companion_3() {
    Companion_instance_8 = this;
    this.o3h_1 = logger(getKClass(Snapshot));
  }
  var Companion_instance_8;
  function Companion_getInstance_13() {
    if (Companion_instance_8 == null)
      new Companion_3();
    return Companion_instance_8;
  }
  function replayFromSnapshot($this) {
    var undoStackWriter = new TransactionStackWriter('Undo stack');
    try {
      var clonedData = StorableCloner_getInstance().s36($this.p3h_1);
      _get_LOG__e5r759(Companion_getInstance_13()).ql('Clone snapshot and set as new undoable data ' + toString(clonedData));
      $this.q3h_1.t3h(clonedData);
      _get_LOG__e5r759(Companion_getInstance_13()).ql('Replaying');
      // Inline function 'kotlin.collections.forEach' call
      var _iterator__ex2g4s = $this.r3h_1.vv_1.i();
      while (_iterator__ex2g4s.j()) {
        var element = _iterator__ex2g4s.k();
        _get_LOG__e5r759(Companion_getInstance_13()).ql('.. replaying transaction ' + element.v3h().g3a());
        element.i3a();
        undoStackWriter.x3h(element);
      }
      $this.q3h_1.y3h(clonedData);
    } catch ($p) {
      if ($p instanceof Error) {
        var e = $p;
        _get_LOG__e5r759(Companion_getInstance_13()).ll('Error in replaying snapshot for undo', e);
        _get_LOG__e5r759(Companion_getInstance_13()).ml(undoStackWriter.toString());
        _get_LOG__e5r759(Companion_getInstance_13()).kl(undoStackWriter.toString());
        throw e;
      } else {
        throw $p;
      }
    }
  }
  function Snapshot(data, undoableDataHolder) {
    Companion_getInstance_13();
    this.p3h_1 = data;
    this.q3h_1 = undoableDataHolder;
    this.r3h_1 = new Stack();
    this.s3h_1 = new Stack();
  }
  protoOf(Snapshot).z3h = function () {
    return this.r3h_1.o();
  };
  protoOf(Snapshot).gs = function () {
    var tmp = this.p3h_1;
    if (isInterface(tmp, Disposable)) {
      this.p3h_1.gs();
    }
  };
  protoOf(Snapshot).a3i = function (transaction) {
    this.r3h_1.yv(transaction);
  };
  protoOf(Snapshot).b3i = function (forRedo) {
    var transaction = this.r3h_1.zv();
    transaction.k3a();
    if (forRedo) {
      this.s3h_1.yv(transaction);
    }
    if (transaction.l3a()) {
      transaction.m3a();
    } else {
      replayFromSnapshot(this);
    }
  };
  protoOf(Snapshot).c3i = function () {
    this.s3h_1.a2();
  };
  function _get_LOG__e5r759_0($this) {
    var tmp0 = $this.d3i_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('LOG', 1, tmp, SourcingCommandManager$Companion$_get_LOG_$ref_ehtvpi(), null);
    return tmp0.j2();
  }
  function SourcingCommandManager$Companion$_get_LOG_$ref_ehtvpi() {
    return function (p0) {
      return _get_LOG__e5r759_0(p0);
    };
  }
  function nextFromCommandIterator($this) {
    var tmp0_safe_receiver = $this.k3i_1;
    if ((tmp0_safe_receiver == null ? null : tmp0_safe_receiver.j()) === true) {
      $this.nc(ensureNotNull($this.k3i_1).k());
      return true;
    }
    return false;
  }
  function nextFromTransactionIterator($this) {
    var tmp0_safe_receiver = $this.j3i_1;
    if ((tmp0_safe_receiver == null ? null : tmp0_safe_receiver.j()) === true) {
      $this.k3i_1 = ensureNotNull($this.j3i_1).k().u3h_1.i();
      if (nextFromCommandIterator($this)) {
        return true;
      }
    }
    return false;
  }
  function nextFromSnapshotIterator($this) {
    if ($this.i3i_1.j()) {
      $this.j3i_1 = $this.i3i_1.k().r3h_1.vv_1.i();
      if (nextFromTransactionIterator($this)) {
        return true;
      }
    }
    return false;
  }
  function Companion_4() {
    Companion_instance_9 = this;
    this.d3i_1 = logger(getKClass(SourcingCommandManager));
    this.e3i_1 = 'edit.commandManager.cmdPerSnapshot';
    this.f3i_1 = 'default';
  }
  var Companion_instance_9;
  function Companion_getInstance_14() {
    if (Companion_instance_9 == null)
      new Companion_4();
    return Companion_instance_9;
  }
  function _get_maxCommandCountPerSnapshot__1yc9wu($this) {
    return $this.n3i_1.kt('edit.commandManager.cmdPerSnapshot');
  }
  function _get_maxSnapshotSizeReached__jf518i($this) {
    return !_get_state__b8zcm8($this).s3i_1.wv() && _get_state__b8zcm8($this).s3i_1.rv().z3h() >= _get_maxCommandCountPerSnapshot__1yc9wu($this);
  }
  function _get_state__b8zcm8($this) {
    return $this.o3i_1.rv();
  }
  function CommandIterator($outer) {
    this.l3i_1 = $outer;
    AbstractIterator.call(this);
    this.i3i_1 = _get_state__b8zcm8(this.l3i_1).s3i_1.vv_1.i();
    var tmp = this;
    var tmp_0;
    if (this.i3i_1.j()) {
      tmp_0 = this.i3i_1.k().r3h_1.vv_1.i();
    } else {
      tmp_0 = null;
    }
    tmp.j3i_1 = tmp_0;
    var tmp_1 = this;
    var tmp_2;
    var tmp0_safe_receiver = this.j3i_1;
    if ((tmp0_safe_receiver == null ? null : tmp0_safe_receiver.j()) === true) {
      tmp_2 = ensureNotNull(this.j3i_1).k().u3h_1.i();
    } else {
      tmp_2 = null;
    }
    tmp_1.k3i_1 = tmp_2;
  }
  protoOf(CommandIterator).mc = function () {
    if (nextFromCommandIterator(this)) {
      return Unit_instance;
    }
    if (nextFromTransactionIterator(this)) {
      return Unit_instance;
    }
    if (nextFromSnapshotIterator(this)) {
      return Unit_instance;
    }
    this.oc();
  };
  function tryCommandExecution($this, command) {
    try {
      command.i3a();
    } catch ($p) {
      if ($p instanceof Error) {
        var e = $p;
        if (!(command instanceof AbstractPropertyCommand)) {
          _get_LOG__e5r759_0(Companion_getInstance_14()).ml('Exception in command execution: ' + e.message);
        }
        $this.w3a();
        throw e;
      } else {
        throw $p;
      }
    }
  }
  function transferUndoneSnapshotIfNecessary($this, storeForRedo) {
    var snapshot = _get_state__b8zcm8($this).s3i_1.rv();
    if (snapshot.r3h_1.wv() && _get_state__b8zcm8($this).s3i_1.o() > 1) {
      _get_state__b8zcm8($this).s3i_1.zv();
      if (storeForRedo) {
        _get_state__b8zcm8($this).t3i_1.yv(snapshot);
      }
    }
    if (_get_state__b8zcm8($this).s3i_1.wv()) {
      $this.x3i();
    }
  }
  function beginTransactionImpl($this, command, register, allowNewSnapshot) {
    _get_LOG__e5r759_0(Companion_getInstance_14()).ql("Begin transaction for '" + command.g3a() + "'");
    if (_get_state__b8zcm8($this).u3i_1 == null) {
      _get_state__b8zcm8($this).u3i_1 = new Transaction();
      if (allowNewSnapshot && !register) {
        addableSnapshot($this).a3i(ensureNotNull(_get_state__b8zcm8($this).u3i_1));
      } else {
        _get_state__b8zcm8($this).s3i_1.rv().a3i(ensureNotNull(_get_state__b8zcm8($this).u3i_1));
      }
    }
    var _receiver__tnumb7 = _get_state__b8zcm8($this);
    _receiver__tnumb7.v3i_1 = _receiver__tnumb7.v3i_1 + 1 | 0;
    var tmp0_safe_receiver = _get_state__b8zcm8($this).u3i_1;
    if (tmp0_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      // Inline function 'kotlin.collections.toTypedArray' call
      var this_0 = _get_state__b8zcm8($this).w3i_1;
      var tmp$ret$2 = copyToArray(this_0);
      command.j3a(tmp$ret$2.slice());
      tmp0_safe_receiver.y3i(command);
      if (!register) {
        tryCommandExecution($this, command);
        command.k20();
      }
    }
  }
  function resetRedo($this) {
    if (!_get_state__b8zcm8($this).s3i_1.wv()) {
      _get_state__b8zcm8($this).s3i_1.rv().c3i();
    }
    _get_state__b8zcm8($this).t3i_1.a2();
  }
  function addableSnapshot($this) {
    if (_get_state__b8zcm8($this).s3i_1.wv() || _get_maxSnapshotSizeReached__jf518i($this)) {
      if (_get_maxSnapshotSizeReached__jf518i($this)) {
        _get_LOG__e5r759_0(Companion_getInstance_14()).kl('Max snapshot size ' + _get_maxCommandCountPerSnapshot__1yc9wu($this) + ' reached. Create new snapshot.');
      }
      $this.x3i();
    }
    return _get_state__b8zcm8($this).s3i_1.rv();
  }
  function createSnapshotData($this) {
    _get_LOG__e5r759_0(Companion_getInstance_14()).ql('Create new snapshot');
    return StorableCloner_getInstance().s36(ensureNotNull(_get_state__b8zcm8($this).r3i_1.z3i()));
  }
  function SourcingCommandManager(eventBus, properties) {
    Companion_getInstance_14();
    eventBus = eventBus === VOID ? BaseModule_getInstance().bp_1 : eventBus;
    properties = properties === VOID ? BaseModule_getInstance().zo_1 : properties;
    this.m3i_1 = eventBus;
    this.n3i_1 = properties;
    this.o3i_1 = new Stack();
    this.p3i_1 = true;
  }
  protoOf(SourcingCommandManager).i = function () {
    return new CommandIterator(this);
  };
  protoOf(SourcingCommandManager).n3a = function (value) {
    if (!(value === this.p3i_1)) {
      this.p3i_1 = value;
      this.m3i_1.gu(new CommandManagerActiveEvent(this));
    }
  };
  protoOf(SourcingCommandManager).o3a = function () {
    return this.p3i_1;
  };
  protoOf(SourcingCommandManager).p3a = function () {
    return !(_get_state__b8zcm8(this).u3i_1 == null);
  };
  protoOf(SourcingCommandManager).u3a = function (command) {
    _get_LOG__e5r759_0(Companion_getInstance_14()).ql("Register command '" + command.g3a() + "'");
    resetRedo(this);
    if (_get_state__b8zcm8(this).u3i_1 == null) {
      beginTransactionImpl(this, command, true, true);
      this.v3a();
    } else {
      // Inline function 'kotlin.collections.toTypedArray' call
      var this_0 = _get_state__b8zcm8(this).w3i_1;
      var tmp$ret$0 = copyToArray(this_0);
      command.j3a(tmp$ret$0.slice());
      ensureNotNull(_get_state__b8zcm8(this).u3i_1).y3i(command);
      command.k20();
    }
  };
  protoOf(SourcingCommandManager).t3a = function (command) {
    _get_LOG__e5r759_0(Companion_getInstance_14()).ql("Execute command '" + command.g3a() + "'");
    resetRedo(this);
    if (_get_state__b8zcm8(this).u3i_1 == null) {
      beginTransactionImpl(this, command, false, true);
      this.v3a();
    } else {
      // Inline function 'kotlin.collections.toTypedArray' call
      var this_0 = _get_state__b8zcm8(this).w3i_1;
      var tmp$ret$0 = copyToArray(this_0);
      command.j3a(tmp$ret$0.slice());
      ensureNotNull(_get_state__b8zcm8(this).u3i_1).y3i(command);
      tryCommandExecution(this, command);
      command.k20();
    }
  };
  protoOf(SourcingCommandManager).q3a = function (command, register) {
    beginTransactionImpl(this, command, register, false);
  };
  protoOf(SourcingCommandManager).s3a = function (descriptionKey, drawingView) {
    this.q3a(new TransactionCommand(descriptionKey, drawingView), true);
  };
  protoOf(SourcingCommandManager).v3a = function () {
    if (_get_state__b8zcm8(this).u3i_1 == null) {
      throw IllegalStateException_init_$Create$('no transaction to commit');
    }
    var _receiver__tnumb7 = _get_state__b8zcm8(this);
    _receiver__tnumb7.v3i_1 = _receiver__tnumb7.v3i_1 - 1 | 0;
    if (_get_state__b8zcm8(this).v3i_1 === 0) {
      _get_LOG__e5r759_0(Companion_getInstance_14()).ql('Commit transaction');
      resetRedo(this);
      this.m3i_1.gu(new CommandEvent(this, CommandEventType_COMMIT_TRANSACTION_getInstance()));
      _get_state__b8zcm8(this).u3i_1 = null;
    }
  };
  protoOf(SourcingCommandManager).w3a = function () {
    if (_get_state__b8zcm8(this).u3i_1 == null) {
      throw IllegalStateException_init_$Create$('no transaction to rollback');
    }
    _get_LOG__e5r759_0(Companion_getInstance_14()).pl('Rollback transaction');
    try {
      _get_state__b8zcm8(this).s3i_1.rv().b3i(false);
    } catch ($p) {
      if ($p instanceof Error) {
        var e = $p;
        _get_LOG__e5r759_0(Companion_getInstance_14()).ll('Error in undo during rollbackTransaction', e);
        throw e;
      } else {
        throw $p;
      }
    }
    finally {
      transferUndoneSnapshotIfNecessary(this, false);
      _get_state__b8zcm8(this).v3i_1 = 0;
      _get_state__b8zcm8(this).u3i_1 = null;
    }
  };
  protoOf(SourcingCommandManager).x3i = function () {
    _get_state__b8zcm8(this).s3i_1.yv(new Snapshot(createSnapshotData(this), _get_state__b8zcm8(this).r3i_1));
  };
  function _get_LOG__e5r759_1($this) {
    var tmp0 = $this.a3j_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('LOG', 1, tmp, Transaction$Companion$_get_LOG_$ref_knacsi(), null);
    return tmp0.j2();
  }
  function Transaction$Companion$_get_LOG_$ref_knacsi() {
    return function (p0) {
      return _get_LOG__e5r759_1(p0);
    };
  }
  function Companion_5() {
    Companion_instance_10 = this;
    this.a3j_1 = logger(getKClass(Transaction));
  }
  var Companion_instance_10;
  function Companion_getInstance_15() {
    if (Companion_instance_10 == null)
      new Companion_5();
    return Companion_instance_10;
  }
  function Transaction() {
    Companion_getInstance_15();
    var tmp = this;
    // Inline function 'kotlin.collections.mutableListOf' call
    tmp.u3h_1 = ArrayList_init_$Create$_0();
  }
  protoOf(Transaction).v3h = function () {
    return first(this.u3h_1);
  };
  protoOf(Transaction).l3a = function () {
    var tmp0 = this.u3h_1;
    var tmp$ret$0;
    $l$block_0: {
      // Inline function 'kotlin.collections.all' call
      var tmp;
      if (isInterface(tmp0, Collection)) {
        tmp = tmp0.m();
      } else {
        tmp = false;
      }
      if (tmp) {
        tmp$ret$0 = true;
        break $l$block_0;
      }
      var _iterator__ex2g4s = tmp0.i();
      while (_iterator__ex2g4s.j()) {
        var element = _iterator__ex2g4s.k();
        var tmp_0;
        if (isInterface(element, Undoable)) {
          tmp_0 = element.l3a();
        } else {
          tmp_0 = false;
        }
        if (!tmp_0) {
          tmp$ret$0 = false;
          break $l$block_0;
        }
      }
      tmp$ret$0 = true;
    }
    return tmp$ret$0;
  };
  protoOf(Transaction).y3i = function (command) {
    this.u3h_1.h(command);
  };
  protoOf(Transaction).i3a = function () {
    var _iterator__ex2g4s = this.u3h_1.i();
    while (_iterator__ex2g4s.j()) {
      var c = _iterator__ex2g4s.k();
      c.i3a();
      c.k20();
    }
  };
  protoOf(Transaction).m3a = function () {
    // Inline function 'kotlin.check' call
    if (!this.l3a()) {
      var message = 'Cannot undo Transaction';
      throw IllegalStateException_init_$Create$(toString(message));
    }
    try {
      // Inline function 'kotlin.collections.forEach' call
      var _iterator__ex2g4s = reversed(this.u3h_1).i();
      while (_iterator__ex2g4s.j()) {
        var element = _iterator__ex2g4s.k();
        (isInterface(element, Undoable) ? element : THROW_CCE()).m3a();
        element.k20();
      }
    } catch ($p) {
      if ($p instanceof Error) {
        var e = $p;
        _get_LOG__e5r759_1(Companion_getInstance_15()).ll('Error in undoing Transaction', e);
        throw e;
      } else {
        throw $p;
      }
    }
  };
  protoOf(Transaction).k3a = function () {
    // Inline function 'kotlin.collections.filter' call
    var tmp0 = this.u3h_1;
    // Inline function 'kotlin.collections.filterTo' call
    var destination = ArrayList_init_$Create$_0();
    var _iterator__ex2g4s = tmp0.i();
    while (_iterator__ex2g4s.j()) {
      var element = _iterator__ex2g4s.k();
      if (!isInterface(element, Undoable)) {
        destination.h(element);
      }
    }
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s_0 = reversed(destination).i();
    while (_iterator__ex2g4s_0.j()) {
      var element_0 = _iterator__ex2g4s_0.k();
      element_0.k3a();
    }
  };
  function TransactionCommand(descriptionKey, drawingView) {
    drawingView = drawingView === VOID ? null : drawingView;
    AbstractCommand.call(this, descriptionKey, null);
    this.e3j_1 = drawingView;
  }
  protoOf(TransactionCommand).i3a = function () {
  };
  protoOf(TransactionCommand).m3a = function () {
  };
  protoOf(TransactionCommand).k20 = function () {
    var tmp0_safe_receiver = this.e3j_1;
    var tmp1_safe_receiver = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.u3b();
    if (tmp1_safe_receiver == null)
      null;
    else {
      tmp1_safe_receiver.k20();
    }
  };
  function writeTransaction($this, transaction, out) {
    // Inline function 'kotlin.text.appendLine' call
    var value = '# Transaction';
    // Inline function 'kotlin.text.appendLine' call
    out.i7(value).j7(_Char___init__impl__6a9atx(10));
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = transaction.u3h_1.i();
    while (_iterator__ex2g4s.j()) {
      var element = _iterator__ex2g4s.k();
      writeCommand($this, element, out);
    }
  }
  function writeCommand($this, command, out) {
    out.i7('-- ');
    // Inline function 'kotlin.text.appendLine' call
    var value = command.h3a();
    // Inline function 'kotlin.text.appendLine' call
    out.i7(value).j7(_Char___init__impl__6a9atx(10));
  }
  function TransactionStackWriter(title) {
    this.w3h_1 = StringBuilder_init_$Create$();
    // Inline function 'kotlin.text.appendLine' call
    // Inline function 'kotlin.text.appendLine' call
    this.w3h_1.i7(title).j7(_Char___init__impl__6a9atx(10));
  }
  protoOf(TransactionStackWriter).x3h = function (transaction) {
    writeTransaction(this, transaction, this.w3h_1);
  };
  protoOf(TransactionStackWriter).toString = function () {
    return this.w3h_1.toString();
  };
  function DropEvent(editor, component) {
    this.f3j_1 = editor;
    this.g3j_1 = component;
  }
  protoOf(DropEvent).toString = function () {
    return 'DropEvent(editor=' + toString(this.f3j_1) + ', component=' + toString(this.g3j_1) + ')';
  };
  protoOf(DropEvent).hashCode = function () {
    var result = hashCode(this.f3j_1);
    result = imul(result, 31) + hashCode(this.g3j_1) | 0;
    return result;
  };
  protoOf(DropEvent).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof DropEvent))
      return false;
    if (!equals(this.f3j_1, other.f3j_1))
      return false;
    if (!equals(this.g3j_1, other.g3j_1))
      return false;
    return true;
  };
  function DragDestination() {
  }
  function DragDestinationHighlightFactoryRegistry() {
    var tmp = this;
    // Inline function 'kotlin.collections.mutableMapOf' call
    tmp.i3j_1 = LinkedHashMap_init_$Create$();
  }
  protoOf(DragDestinationHighlightFactoryRegistry).j3j = function (destinationClass, factory) {
    var tmp0 = this.i3j_1;
    // Inline function 'kotlin.collections.set' call
    var key = System_getInstance().xl(destinationClass);
    tmp0.y1(key, factory);
  };
  protoOf(DragDestinationHighlightFactoryRegistry).k3j = function (destination) {
    var tmp = this.i3j_1.g2(System_getInstance().yl(destination));
    var tmp0_safe_receiver = (tmp == null ? true : isInterface(tmp, DragDestinationHighlightFactory)) ? tmp : THROW_CCE();
    return tmp0_safe_receiver == null ? null : tmp0_safe_receiver.l3j(destination);
  };
  function DragDestinationHighlightFactory() {
  }
  function addHighlightIfAny($this, drawingView, destination) {
    var tmp0_safe_receiver = createHighlight($this, destination);
    if (tmp0_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      DragDestinationHighlighter_instance.n3j_1 = tmp0_safe_receiver;
      DragDestinationHighlighter_instance.m3j_1 = destination;
      drawingView.a3c().b21(tmp0_safe_receiver);
      tmp0_safe_receiver.k20();
    }
  }
  function removeHighlight($this, drawingView) {
    if (!($this.n3j_1 == null)) {
      drawingView.a3c().c21(ensureNotNull($this.n3j_1));
      drawingView.u3b().k20();
      $this.n3j_1 = null;
    }
  }
  function createHighlight($this, destination) {
    return EditDragModule_getInstance().p3j_1.k3j(destination);
  }
  function DragDestinationHighlighter() {
    this.m3j_1 = null;
    this.n3j_1 = null;
  }
  protoOf(DragDestinationHighlighter).p3b = function (editor, component, destination) {
    var tmp;
    var tmp_0;
    if (!(destination == null)) {
      tmp_0 = isInterface(destination, DragDestination);
    } else {
      tmp_0 = false;
    }
    if (tmp_0) {
      tmp = destination.h3j(component);
    } else {
      tmp = false;
    }
    if (tmp) {
      if (this.n3j_1 == null) {
        addHighlightIfAny(this, editor.v1o(), destination);
      } else {
        if (!equals(this.m3j_1, destination)) {
          removeHighlight(this, editor.v1o());
          addHighlightIfAny(this, editor.v1o(), destination);
        }
      }
      var tmp0_safe_receiver = this.n3j_1;
      if (tmp0_safe_receiver == null)
        null;
      else {
        tmp0_safe_receiver.q3j(component, destination);
      }
    } else {
      removeHighlight(this, editor.v1o());
    }
  };
  protoOf(DragDestinationHighlighter).r3j = function (editor, component) {
    this.p3b(editor, component, null);
  };
  protoOf(DragDestinationHighlighter).s3j = function (editor, component) {
    return emptySet();
  };
  protoOf(DragDestinationHighlighter).t3j = function (editor) {
    removeHighlight(this, editor.v1o());
  };
  var DragDestinationHighlighter_instance;
  function DragDestinationHighlighter_getInstance() {
    return DragDestinationHighlighter_instance;
  }
  function _get_LOG__e5r759_2($this) {
    var tmp0 = $this.u3j_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('LOG', 1, tmp, DragManagerImpl$Companion$_get_LOG_$ref_9hucft(), null);
    return tmp0.j2();
  }
  function DragManagerImpl$Companion$_get_LOG_$ref_9hucft() {
    return function (p0) {
      return _get_LOG__e5r759_2(p0);
    };
  }
  function Companion_6() {
    Companion_instance_11 = this;
    this.u3j_1 = logger(getKClass(DragManagerImpl));
  }
  var Companion_instance_11;
  function Companion_getInstance_16() {
    if (Companion_instance_11 == null)
      new Companion_6();
    return Companion_instance_11;
  }
  function drag($this, components, x, y, orthogonal, doSnap) {
    if (components.m() || $this.a3k_1 == null) {
      return Unit_instance;
    }
    var dx = x - $this.c3k_1.kn_1;
    var dy = y - $this.c3k_1.ln_1;
    if (orthogonal) {
      // Inline function 'kotlin.math.abs' call
      var x_0 = dx;
      var tmp = Math.abs(x_0);
      // Inline function 'kotlin.math.abs' call
      var x_1 = dy;
      if (tmp >= Math.abs(x_1)) {
        dy = 0.0;
      } else {
        dx = 0.0;
      }
    }
    var tmp_0 = $this;
    var tmp0 = $this.f3k_1;
    // Inline function 'kotlin.math.max' call
    var b = numberToInt($this.c3k_1.e1h($this.b3k_1.kn_1 + dx, $this.b3k_1.ln_1 + dy));
    tmp_0.f3k_1 = Math.max(tmp0, b);
    var delta = (new Point2D($this.b3k_1.kn_1 + dx, $this.b3k_1.ln_1 + dy)).j1h(ensureNotNull($this.a3k_1).jw());
    var snap = Companion_getInstance().w1a_1;
    if (doSnap && $this.w3j_1.b3d().i3k()) {
      if (components.o() > 1) {
        if ($this.e3k_1 == null) {
          $this.e3k_1 = new MultiComponentSnappable(components);
        }
        snap = $this.w3j_1.b3d().h3k(ensureNotNull($this.e3k_1), delta.kn_1, delta.ln_1);
      } else if (components.o() === 1) {
        snap = $this.w3j_1.b3d().h3k(first_0(components), delta.kn_1, delta.ln_1);
      }
    }
    Companion_instance.i2i(components, delta.kn_1 + snap.kn_1, delta.ln_1 + snap.ln_1);
    $this.d3k_1 = new Point2D(x + snap.kn_1, y + snap.ln_1);
  }
  function involvePluginsDragged($this, component) {
    var destination = null;
    if ($this.z3j_1) {
      var tmp = $this.w3j_1.u3b();
      var tmp_0 = component.fo();
      destination = tmp.g21(tmp_0, DragManagerImpl$involvePluginsDragged$lambda(component));
    }
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = $this.y3j_1.i();
    while (_iterator__ex2g4s.j()) {
      var element = _iterator__ex2g4s.k();
      if (isInterface(element, DragManagerDestinationPlugin)) {
        element.p3b($this.w3j_1, component, destination);
      } else {
        element.r3j($this.w3j_1, component);
      }
    }
  }
  function involvePluginsDragFinished($this, component) {
    // Inline function 'kotlin.collections.mutableListOf' call
    var commands = ArrayList_init_$Create$_0();
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = $this.y3j_1.i();
    while (_iterator__ex2g4s.j()) {
      var element = _iterator__ex2g4s.k();
      commands.f1(element.s3j($this.w3j_1, component));
    }
    return commands;
  }
  function involvePluginsDragTerminated($this) {
    $this.e3k_1 = null;
    $this.a3k_1 = null;
    $this.g3k_1 = null;
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = $this.y3j_1.i();
    while (_iterator__ex2g4s.j()) {
      var element = _iterator__ex2g4s.k();
      element.t3j($this.w3j_1);
    }
  }
  function logMove($this, action, offset, additionalCommandsCount) {
    var selection = $this.w3j_1.v1o().v3b().x3d();
    if (selection.o() === 1) {
      _get_LOG__e5r759_2(Companion_getInstance_16()).kl("Move component '" + first_0(selection).k1a() + "' with ID " + first_0(selection).cv() + ' with ' + action + ' by ' + offset.toString() + ', ' + additionalCommandsCount + ' additional commands');
    } else {
      _get_LOG__e5r759_2(Companion_getInstance_16()).kl('Move ' + selection.o() + ' components by ' + action);
    }
  }
  function getKeyMoveDirection($this, event) {
    var tmp0_subject = event.i2();
    var tmp;
    if (tmp0_subject === Companion_instance_0.p18_1) {
      tmp = Direction_EAST_getInstance();
    } else if (tmp0_subject === Companion_instance_0.o18_1) {
      tmp = Direction_WEST_getInstance();
    } else if (tmp0_subject === Companion_instance_0.q18_1) {
      tmp = Direction_NORTH_getInstance();
    } else if (tmp0_subject === Companion_instance_0.r18_1) {
      tmp = Direction_SOUTH_getInstance();
    } else {
      throw IllegalArgumentException_init_$Create$("KeyEvent doesn't represent a move direction");
    }
    return tmp;
  }
  function DragManagerImpl$involvePluginsDragged$lambda($component) {
    return function (it) {
      return !(it === $component);
    };
  }
  function DragManagerImpl(editor, drawingAppService, plugins) {
    Companion_getInstance_16();
    drawingAppService = drawingAppService === VOID ? EditModule_getInstance().b3g_1 : drawingAppService;
    plugins = plugins === VOID ? emptySet() : plugins;
    InputEventHandlerAdapter.call(this);
    this.w3j_1 = editor;
    this.x3j_1 = drawingAppService;
    var tmp = this;
    // Inline function 'kotlin.collections.mutableSetOf' call
    tmp.y3j_1 = LinkedHashSet_init_$Create$();
    this.z3j_1 = false;
    this.a3k_1 = null;
    this.b3k_1 = Companion_getInstance().w1a_1;
    this.c3k_1 = Companion_getInstance().w1a_1;
    this.d3k_1 = Companion_getInstance().w1a_1;
    this.e3k_1 = null;
    this.f3k_1 = 0;
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = plugins.i();
    while (_iterator__ex2g4s.j()) {
      var element = _iterator__ex2g4s.k();
      this.j3k(element);
    }
    this.g3k_1 = null;
  }
  protoOf(DragManagerImpl).j3k = function (plugin) {
    this.y3j_1.h(plugin);
    this.z3j_1 = true;
  };
  protoOf(DragManagerImpl).k3k = function (component, x, y) {
    if (!component.g3b()) {
      this.a3k_1 = component;
      this.b3k_1 = Point2D_init_$Create$(ensureNotNull(this.a3k_1).jw());
      this.d3k_1 = new Point2D(x, y);
      this.c3k_1 = new Point2D(x, y);
      this.f3k_1 = 0;
    }
  };
  protoOf(DragManagerImpl).l3k = function (context) {
    var selection = this.w3j_1.v1o().v3b().x3d();
    if (selection.o() === 1 && first_0(selection).g3b()) {
      return null;
    }
    var tmp0_safe_receiver = context.o22_1;
    var tmp = (tmp0_safe_receiver == null ? null : tmp0_safe_receiver.isShiftDown) === true;
    var tmp1_safe_receiver = context.o22_1;
    drag(this, selection, context.q22_1, context.r22_1, tmp, !((tmp1_safe_receiver == null ? null : tmp1_safe_receiver.isAltDown) === true));
    if (selection.o() === 1) {
      involvePluginsDragged(this, first_0(selection));
    }
    this.w3j_1.u3b().k20();
    return null;
  };
  protoOf(DragManagerImpl).b23 = function (context) {
    return this.l3k(context instanceof InputEventContext ? context : THROW_CCE());
  };
  protoOf(DragManagerImpl).m3k = function (context) {
    if (!(this.a3k_1 == null)) {
      var selection = this.w3j_1.v1o().v3b().x3d();
      if (selection.o() === 1 && first_0(selection).g3b()) {
        return null;
      }
      var tmp;
      if (selection.o() === 1 && this.f3k_1 > 0) {
        tmp = involvePluginsDragFinished(this, first_0(selection));
      } else {
        tmp = emptyList();
      }
      var additionalCommands = tmp;
      var tmp_0;
      // Inline function 'kotlin.collections.isNotEmpty' call
      if (!additionalCommands.m()) {
        tmp_0 = true;
      } else {
        var tmp_1 = this.b3k_1;
        var tmp0_safe_receiver = this.a3k_1;
        tmp_0 = !tmp_1.equals(tmp0_safe_receiver == null ? null : tmp0_safe_receiver.jw());
      }
      if (tmp_0) {
        try {
          var offset = ensureNotNull(this.a3k_1).jw().j1h(this.b3k_1);
          logMove(this, 'mouse', offset, additionalCommands.o());
          this.x3j_1.r3f(selection, offset, this.w3j_1, true, additionalCommands);
        } catch ($p) {
          if ($p instanceof Error) {
            var e = $p;
            _get_LOG__e5r759_2(Companion_getInstance_16()).ml("mouseReleased: error '" + e.message + "'");
            throw e;
          } else {
            throw $p;
          }
        }
      }
    }
    involvePluginsDragTerminated(this);
    return null;
  };
  protoOf(DragManagerImpl).c23 = function (context) {
    return this.m3k(context instanceof InputEventContext ? context : THROW_CCE());
  };
  protoOf(DragManagerImpl).n3k = function (context) {
    var tmp0_safe_receiver = context.p22_1;
    if ((tmp0_safe_receiver == null ? null : tmp0_safe_receiver.i2()) === Companion_instance_0.u18_1) {
      return this;
    }
    var tmp;
    if (!(this.a3k_1 == null)) {
      var tmp1_safe_receiver = context.p22_1;
      tmp = (tmp1_safe_receiver == null ? null : tmp1_safe_receiver.i2()) === Companion_instance_0.x18_1;
    } else {
      tmp = false;
    }
    if (tmp) {
      var selection = this.w3j_1.v1o().v3b().x3d();
      if (selection.o() === 1 && first_0(selection).g3b()) {
        return null;
      }
      drag(this, selection, this.d3k_1.kn_1, this.d3k_1.ln_1, true, true);
    }
    return null;
  };
  protoOf(DragManagerImpl).d23 = function (context) {
    return this.n3k(context instanceof InputEventContext ? context : THROW_CCE());
  };
  protoOf(DragManagerImpl).o3k = function (context) {
    var tmp;
    if (!(this.a3k_1 == null)) {
      var tmp0_safe_receiver = context.p22_1;
      tmp = (tmp0_safe_receiver == null ? null : tmp0_safe_receiver.i2()) === Companion_instance_0.x18_1;
    } else {
      tmp = false;
    }
    if (tmp) {
      var selection = this.w3j_1.v1o().v3b().x3d();
      if (selection.o() === 1 && first_0(selection).g3b()) {
        return null;
      }
      drag(this, selection, this.d3k_1.kn_1, this.d3k_1.ln_1, false, true);
    }
    return null;
  };
  protoOf(DragManagerImpl).e23 = function (context) {
    return this.o3k(context instanceof InputEventContext ? context : THROW_CCE());
  };
  protoOf(DragManagerImpl).p3k = function (event) {
    var tmp0_subject = event.i2();
    return tmp0_subject === Companion_instance_0.p18_1 || tmp0_subject === Companion_instance_0.o18_1 || (tmp0_subject === Companion_instance_0.q18_1 || tmp0_subject === Companion_instance_0.r18_1) ? event.modifiers === 0 || event.isAltDown : false;
  };
  protoOf(DragManagerImpl).q3k = function (event) {
    var tmp;
    if (event.isAltDown) {
      tmp = getKeyMoveDirection(this, event).c1g();
    } else {
      tmp = getKeyMoveDirection(this, event).c1g().y1f(this.w3j_1.v1o().y3b().r3k());
    }
    var offset = tmp;
    logMove(this, 'key', offset, 0);
    this.x3j_1.s3f(this.w3j_1.v1o().v3b().x3d(), offset, this.w3j_1, false);
  };
  function EditDragModule() {
    EditDragModule_instance = this;
    AbstractModule.call(this);
    this.p3j_1 = new DragDestinationHighlightFactoryRegistry();
  }
  protoOf(EditDragModule).to = function () {
  };
  var EditDragModule_instance;
  function EditDragModule_getInstance() {
    if (EditDragModule_instance == null)
      new EditDragModule();
    return EditDragModule_instance;
  }
  function AddCommand_init_$Init$(editor, component, $this) {
    AddCommand.call($this, editor.v1o(), component);
    return $this;
  }
  function AddCommand_init_$Create$(editor, component) {
    return AddCommand_init_$Init$(editor, component, objectCreate(protoOf(AddCommand)));
  }
  function AddCommand(drawingView, component, componentCustomizer) {
    componentCustomizer = componentCustomizer === VOID ? null : componentCustomizer;
    AbstractDrawingViewCommand.call(this, 'edit.command.add', drawingView);
    this.w3k_1 = component;
    this.x3k_1 = componentCustomizer;
    this.y3k_1 = 0;
  }
  protoOf(AddCommand).h3a = function () {
    return protoOf(AbstractDrawingViewCommand).h3a.call(this) + ' ' + getKClassFromExpression(this.w3k_1).m9() + ' ' + this.y3k_1;
  };
  protoOf(AddCommand).i3a = function () {
    var clone = this.w3k_1.n3b();
    var tmp = this.n3h_1;
    (isInterface(tmp, DrawingView) ? tmp : THROW_CCE()).u3b().b21(clone);
    var tmp0_safe_receiver = this.x3k_1;
    if (tmp0_safe_receiver == null)
      null;
    else {
      tmp0_safe_receiver.g3g(clone, this.n3h_1.u3b());
    }
    this.y3k_1 = clone.cv();
  };
  protoOf(AddCommand).m3a = function () {
    var tmp = this.n3h_1.u3b();
    var tmp_0 = this.n3h_1.u3b().o3b(this.y3k_1);
    tmp.c21((!(tmp_0 == null) ? isInterface(tmp_0, Component) : false) ? tmp_0 : THROW_CCE());
  };
  function EditEditorModule$dragManagerFactory$lambda(editor) {
    return new DragManagerImpl(editor);
  }
  function EditEditorModule() {
    EditEditorModule_instance = this;
    AbstractModule.call(this);
    var tmp = this;
    tmp.a3l_1 = EditEditorModule$dragManagerFactory$lambda;
  }
  protoOf(EditEditorModule).to = function () {
  };
  var EditEditorModule_instance;
  function EditEditorModule_getInstance() {
    if (EditEditorModule_instance == null)
      new EditEditorModule();
    return EditEditorModule_instance;
  }
  function EditorImpl$DrawingViewListener$propertyChanged$lambda(this$0) {
    return function () {
      this$0.r3l(this$0.k3l_1);
      return Unit_instance;
    };
  }
  function EditorImpl_init_$Init$(view, name, $this) {
    name = name === VOID ? '' : name;
    EditorImpl.call($this, view, EditModule_getInstance().v3f_1, EditSelectModule_getInstance().w3l_1, name);
    return $this;
  }
  function MouseEventDelegator($outer) {
    this.z3l_1 = $outer;
    MouseAdapter.call(this);
    this.x3l_1 = false;
    this.y3l_1 = Companion_getInstance().w1a_1;
  }
  protoOf(MouseEventDelegator).l1b = function (e) {
    this.z3l_1.l3l_1.m3f(e, this.z3l_1.b3l_1.d25(e.jw()));
  };
  protoOf(MouseEventDelegator).h1b = function (e) {
    this.z3l_1.l3l_1.g3f(e, this.z3l_1.b3l_1.d25(e.jw()));
  };
  protoOf(MouseEventDelegator).i1b = function (e) {
    this.y3l_1 = e.jw();
    this.z3l_1.l3l_1.i3f(e, this.z3l_1.b3l_1.d25(e.jw()));
  };
  protoOf(MouseEventDelegator).k1b = function (e) {
    if (!this.x3l_1 && this.y3l_1.e1h(e.p1a(), e.q1a()) > 15) {
      this.x3l_1 = true;
    }
    if (this.x3l_1) {
      this.z3l_1.l3l_1.o3f(e, this.z3l_1.b3l_1.d25(e.jw()));
    }
  };
  protoOf(MouseEventDelegator).j1b = function (e) {
    this.z3l_1.l3l_1.k3f(e, this.z3l_1.b3l_1.d25(e.jw()));
    this.x3l_1 = false;
  };
  function KeyEventDelegator($outer) {
    this.a3m_1 = $outer;
    KeyAdapter.call(this);
  }
  protoOf(KeyEventDelegator).n1a = function (e) {
    this.a3m_1.l3l_1.n1a(e);
  };
  protoOf(KeyEventDelegator).o1a = function (e) {
    this.a3m_1.l3l_1.o1a(e);
  };
  function DrawingViewListener($outer) {
    this.b3m_1 = $outer;
  }
  protoOf(DrawingViewListener).propertyChanged = function (e) {
    var tmp0_subject = e.name;
    if (tmp0_subject === 'PROP_DRAWING') {
      var tmp = e.oldValue;
      ((!(tmp == null) ? isInterface(tmp, Drawing) : false) ? tmp : THROW_CCE()).q21(this.b3m_1.q3l_1);
      var tmp_0 = e.newValue;
      ((!(tmp_0 == null) ? isInterface(tmp_0, Drawing) : false) ? tmp_0 : THROW_CCE()).q21(this.b3m_1.q3l_1);
    } else if (tmp0_subject === 'PROP_CANVAS') {
      this.b3m_1.n3a(true);
      var tmp_1 = System_getInstance();
      tmp_1.fm(EditorImpl$DrawingViewListener$propertyChanged$lambda(this.b3m_1));
    }
    if (e.name === 'PROP_DRAWING') {
      var tmp_2 = e.oldValue;
      ((!(tmp_2 == null) ? isInterface(tmp_2, Drawing) : false) ? tmp_2 : THROW_CCE()).q21(this.b3m_1.q3l_1);
      var tmp_3 = e.newValue;
      ((!(tmp_3 == null) ? isInterface(tmp_3, Drawing) : false) ? tmp_3 : THROW_CCE()).q21(this.b3m_1.q3l_1);
    }
  };
  function DrawingListener($outer) {
    this.c3m_1 = $outer;
    DrawableContainerAdapter.call(this);
  }
  protoOf(DrawingListener).d3m = function (event) {
    var tmp = event.x21_1;
    if (isInterface(tmp, Component)) {
      var tmp_0 = event.x21_1;
      this.c3m_1.e3m(isInterface(tmp_0, Component) ? tmp_0 : THROW_CCE());
    }
  };
  protoOf(DrawingListener).y21 = function (event) {
    return this.d3m(event);
  };
  protoOf(DrawingListener).f3m = function (event) {
    var tmp = event.x21_1;
    if (isInterface(tmp, Component)) {
      var tmp_0 = event.x21_1;
      this.c3m_1.g3m(isInterface(tmp_0, Component) ? tmp_0 : THROW_CCE());
    }
  };
  protoOf(DrawingListener).z21 = function (event) {
    return this.f3m(event);
  };
  function EditorImpl(view, commandManager, selectionToolFactory, name, dragManagerFactory) {
    name = name === VOID ? '' : name;
    dragManagerFactory = dragManagerFactory === VOID ? EditEditorModule_getInstance().a3l_1 : dragManagerFactory;
    this.b3l_1 = view;
    this.c3l_1 = commandManager;
    this.d3l_1 = name;
    this.e3l_1 = new PropertyChangeSupport(this);
    this.f3l_1 = new ComponentSnapper(this);
    this.g3l_1 = SnapManagerImpl_init_$Create$(this);
    this.h3l_1 = dragManagerFactory(this);
    this.i3l_1 = false;
    this.j3l_1 = false;
    this.k3l_1 = selectionToolFactory(this);
    this.l3l_1 = this.k3l_1;
    this.m3l_1 = new ToolLockAction(this);
    this.n3l_1 = new MouseEventDelegator(this);
    this.o3l_1 = new KeyEventDelegator(this);
    this.p3l_1 = new DrawingViewListener(this);
    this.q3l_1 = new DrawingListener(this);
    this.g3l_1.h3m(this.f3l_1);
    this.g3l_1.h3m(this.b3l_1.y3b());
    this.b3l_1.u3b().q21(this.q3l_1);
    this.b3l_1.b1z(this.p3l_1);
  }
  protoOf(EditorImpl).v1o = function () {
    return this.b3l_1;
  };
  protoOf(EditorImpl).d3d = function () {
    return this.c3l_1;
  };
  protoOf(EditorImpl).b3d = function () {
    return this.g3l_1;
  };
  protoOf(EditorImpl).c3d = function () {
    return this.h3l_1;
  };
  protoOf(EditorImpl).n3a = function (value) {
    if (value === this.i3l_1) {
      return Unit_instance;
    }
    var oldValue = this.i3l_1;
    this.i3l_1 = value;
    if (this.i3l_1) {
      this.b3l_1.r1y(this.n3l_1);
      this.b3l_1.t1y(this.n3l_1);
      this.b3l_1.x1y(this.o3l_1);
      this.l3l_1.m2v();
    } else {
      this.b3l_1.s1y(this.n3l_1);
      this.b3l_1.u1y(this.n3l_1);
      this.b3l_1.y1y(this.o3l_1);
      this.l3l_1.n2v();
      this.b3l_1.v3b().c3e();
    }
    this.b3l_1.u24(this.i3l_1);
    this.e3l_1.nr('active', oldValue, this.i3l_1);
  };
  protoOf(EditorImpl).y3c = function (value) {
    if (value === this.j3l_1) {
      return Unit_instance;
    }
    var oldValue = this.j3l_1;
    this.j3l_1 = value;
    this.e3l_1.nr('lockTool', oldValue, this.j3l_1);
  };
  protoOf(EditorImpl).z3c = function () {
    return this.j3l_1;
  };
  protoOf(EditorImpl).r3l = function (value) {
    var oldValue = this.l3l_1;
    this.l3l_1 = value;
    oldValue.n2v();
    this.l3l_1.m2v();
    this.e3l_1.nr('currentTool', oldValue, this.l3l_1);
  };
  protoOf(EditorImpl).a3d = function () {
    return this.l3l_1;
  };
  protoOf(EditorImpl).e3m = function (component) {
  };
  protoOf(EditorImpl).g3m = function (component) {
  };
  function AbstractPathFigure$draw$lambda($context, this$0) {
    return function (it) {
      $context.j1z_1.k1v(this$0.r3m_1);
      return Unit_instance;
    };
  }
  function AbstractPathFigure(path, type) {
    AbstractComponent_init_$Init$(VOID, VOID, this);
    this.r3m_1 = path;
    this.s3m_1 = type;
    this.t3m_1 = Companion_getInstance().w1a_1;
  }
  protoOf(AbstractPathFigure).k1a = function () {
    return this.s3m_1;
  };
  protoOf(AbstractPathFigure).fo = function () {
    // Inline function 'kotlin.also' call
    var this_0 = Rectangle2D_init_$Create$(this.r3m_1.fo());
    this_0.i1c(this.jw().kn_1 + this_0.u1h_1, this.jw().ln_1 + this_0.v1h_1, this_0.w1h_1, this_0.x1h_1);
    this_0.p1c(this.l1u().f1u_1);
    return this_0;
  };
  protoOf(AbstractPathFigure).go = function (x, y) {
    return this.fo().go(x, y);
  };
  protoOf(AbstractPathFigure).h20 = function (context) {
    context.j1z_1.l1d(this.jw().kn_1, this.jw().ln_1);
    if (this.i2d()) {
      var tmp = DropShadow_instance;
      tmp.l2n(context, 255, AbstractPathFigure$draw$lambda(context, this));
    }
    var tmp_0;
    if (context.m1z_1) {
      tmp_0 = ensureNotNull(context.n1z_1).y1x_1;
    } else {
      tmp_0 = Look_getInstance().h3d_1 ? this.z2c() : DrawStyleModule_getInstance().w1x_1.f1y(Companion_getInstance_0().d1y_1).c1u().y1x_1;
    }
    context.j1z_1.b1u(tmp_0);
    context.j1z_1.k1v(this.r3m_1);
    context.j1z_1.b1u(context.r1z(this.y2c()));
    context.j1z_1.e1u(this.l1u());
    context.j1z_1.j1v(this.r3m_1);
    context.j1z_1.l1d(-this.jw().kn_1, -this.jw().ln_1);
  };
  protoOf(AbstractPathFigure).v20 = function (value) {
    this.i20();
    this.t3m_1 = value;
    this.i20();
    this.l20();
  };
  protoOf(AbstractPathFigure).jw = function () {
    return this.t3m_1;
  };
  protoOf(AbstractPathFigure).h38 = function (writer) {
    protoOf(AbstractComponent).h38.call(this, writer);
    writer.t39('location', this.jw());
  };
  protoOf(AbstractPathFigure).i38 = function (reader) {
    protoOf(AbstractComponent).i38.call(this, reader);
    this.v20(reader.y38('location'));
  };
  protoOf(AbstractPathFigure).f2i = function (x) {
    var transform = System_getInstance().bm();
    transform.n1d(-1.0, 1.0);
    transform.l1d(-x, 0.0);
    this.r3m_1.mn(transform);
    this.v20(this.jw().g1h(x));
  };
  protoOf(AbstractPathFigure).g2i = function (y) {
    var transform = System_getInstance().bm();
    transform.n1d(1.0, -1.0);
    transform.l1d(0.0, -y);
    this.r3m_1.mn(transform);
    this.v20(this.jw().h1h(y));
  };
  function sam$io_antarescircuit_jabbah_edit_figure_FigureFactory$0(function_0) {
    this.e3n_1 = function_0;
  }
  protoOf(sam$io_antarescircuit_jabbah_edit_figure_FigureFactory$0).p2 = function () {
    return this.e3n_1;
  };
  protoOf(sam$io_antarescircuit_jabbah_edit_figure_FigureFactory$0).equals = function (other) {
    var tmp;
    if (!(other == null) ? isInterface(other, FigureFactory) : false) {
      var tmp_0;
      if (!(other == null) ? isInterface(other, FunctionAdapter) : false) {
        tmp_0 = equals(this.p2(), other.p2());
      } else {
        tmp_0 = false;
      }
      tmp = tmp_0;
    } else {
      tmp = false;
    }
    return tmp;
  };
  protoOf(sam$io_antarescircuit_jabbah_edit_figure_FigureFactory$0).hashCode = function () {
    return hashCode(this.p2());
  };
  function FigureRegistry$registerDefaultGeometricalFigures$lambda() {
    return new RectangleComponent(VOID, VOID, Rectangle2D_init_$Create$_0(0, 0, 60, 30));
  }
  function FigureRegistry$registerDefaultGeometricalFigures$lambda_0() {
    return new EllipseComponent(VOID, VOID, Ellipse2D_init_$Create$(0, 0, 60, 30));
  }
  function FigureRegistry() {
    FigureRegistry_instance = this;
    this.f3n_1 = 'edit.figure.geometrical';
    var tmp = this;
    // Inline function 'kotlin.collections.mutableListOf' call
    tmp.g3n_1 = ArrayList_init_$Create$_0();
  }
  protoOf(FigureRegistry).h3n = function (name) {
    var tmp0 = this.g3n_1;
    var tmp$ret$0;
    $l$block_0: {
      // Inline function 'kotlin.collections.any' call
      var tmp;
      if (isInterface(tmp0, Collection)) {
        tmp = tmp0.m();
      } else {
        tmp = false;
      }
      if (tmp) {
        tmp$ret$0 = false;
        break $l$block_0;
      }
      var _iterator__ex2g4s = tmp0.i();
      while (_iterator__ex2g4s.j()) {
        var element = _iterator__ex2g4s.k();
        if (element.i3n_1 === name) {
          tmp$ret$0 = true;
          break $l$block_0;
        }
      }
      tmp$ret$0 = false;
    }
    if (tmp$ret$0) {
      throw IllegalArgumentException_init_$Create$('FigureGroup ' + name + ' already registered');
    }
    // Inline function 'kotlin.also' call
    var this_0 = new FigureGroup(name);
    FigureRegistry_getInstance().g3n_1.h(this_0);
    return this_0;
  };
  protoOf(FigureRegistry).k3n = function () {
    // Inline function 'kotlin.apply' call
    var this_0 = this.h3n(Translations_getInstance().bn('edit.figure.geometrical', []));
    var tmp = Companion_getInstance_32().l3n_1;
    var tmp_0 = FigureRegistry$registerDefaultGeometricalFigures$lambda;
    this_0.m3n(new FigureProvider(tmp, new sam$io_antarescircuit_jabbah_edit_figure_FigureFactory$0(tmp_0)));
    var tmp_1 = Companion_getInstance_33().n3n_1;
    var tmp_2 = FigureRegistry$registerDefaultGeometricalFigures$lambda_0;
    this_0.m3n(new FigureProvider(tmp_1, new sam$io_antarescircuit_jabbah_edit_figure_FigureFactory$0(tmp_2)));
  };
  var FigureRegistry_instance;
  function FigureRegistry_getInstance() {
    if (FigureRegistry_instance == null)
      new FigureRegistry();
    return FigureRegistry_instance;
  }
  function FigureGroup(name) {
    this.i3n_1 = name;
    var tmp = this;
    // Inline function 'kotlin.collections.mutableListOf' call
    tmp.j3n_1 = ArrayList_init_$Create$_0();
  }
  protoOf(FigureGroup).m3n = function (provider) {
    this.j3n_1.h(provider);
  };
  function FigureProvider(name, factory) {
    this.o3n_1 = name;
    this.p3n_1 = factory;
  }
  protoOf(FigureProvider).toString = function () {
    return 'FigureProvider(name=' + this.o3n_1 + ', factory=' + toString(this.p3n_1) + ')';
  };
  protoOf(FigureProvider).hashCode = function () {
    var result = getStringHashCode(this.o3n_1);
    result = imul(result, 31) + hashCode(this.p3n_1) | 0;
    return result;
  };
  protoOf(FigureProvider).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof FigureProvider))
      return false;
    if (!(this.o3n_1 === other.o3n_1))
      return false;
    if (!equals(this.p3n_1, other.p3n_1))
      return false;
    return true;
  };
  function FigureFactory() {
  }
  function DrawingViewSearch() {
  }
  function _get_LOG__e5r759_3($this) {
    var tmp0 = $this.q3n_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('LOG', 1, tmp, BelowSmHighlighter$Companion$_get_LOG_$ref_biufiu(), null);
    return tmp0.j2();
  }
  function BelowSmHighlighter$Companion$_get_LOG_$ref_biufiu() {
    return function (p0) {
      return _get_LOG__e5r759_3(p0);
    };
  }
  function Companion_7() {
    Companion_instance_12 = this;
    this.q3n_1 = logger(getKClass(BelowSmHighlighter));
  }
  var Companion_instance_12;
  function Companion_getInstance_17() {
    if (Companion_instance_12 == null)
      new Companion_7();
    return Companion_instance_12;
  }
  function _get_highlights__9xcox8($this) {
    var tmp0 = $this.u3n_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('highlights', 1, tmp, BelowSmHighlighter$_get_highlights_$ref_r7n561(), null);
    return tmp0.j2();
  }
  function highlightImpl($this, c, color) {
    color = color === VOID ? null : color;
    _get_LOG__e5r759_3(Companion_getInstance_17()).ql("Highlight component '" + c.cv() + "'");
    var highlight = $this.r3n_1.v3n(c, SelectionDrawingStrategy_BELOW_getInstance());
    if (highlight == null) {
      _get_LOG__e5r759_3(Companion_getInstance_17()).ml('No suitable highlight SelectionMo`del found for ' + System_getInstance().yl(c));
      return Unit_instance;
    }
    if (!(color == null)) {
      if (isInterface(highlight, Colorable)) {
        highlight.l2e(color);
      } else {
        _get_LOG__e5r759_3(Companion_getInstance_17()).nl('requested highlight color for non-colorable SelectionModel ' + getKClassFromExpression(highlight).m9());
      }
    }
    // Inline function 'kotlin.collections.set' call
    _get_highlights__9xcox8($this).y1(c, highlight);
    $this.t3n_1.g3c().b21(highlight);
  }
  function unhighlightImpl($this, c) {
    _get_LOG__e5r759_3(Companion_getInstance_17()).ql("Unhighlight component '" + c.cv() + "'");
    var highlight = _get_highlights__9xcox8($this).g2(c);
    _get_highlights__9xcox8($this).z1(c);
    $this.t3n_1.g3c().c21(ensureNotNull(highlight));
  }
  function postHighlightChangedEvent($this, c, highlighted) {
    var tmp0_content = $this.t3n_1;
    $this.s3n_1.gu(HighlightChangeEvent_init_$Create$(tmp0_content, $this, c, highlighted));
  }
  function BelowSmHighlighter$highlights$delegate$lambda() {
    // Inline function 'kotlin.collections.mutableMapOf' call
    return LinkedHashMap_init_$Create$();
  }
  function BelowSmHighlighter$_get_highlights_$ref_r7n561() {
    return function (p0) {
      return _get_highlights__9xcox8(p0);
    };
  }
  function BelowSmHighlighter$highlight$lambda($ids) {
    return function (it) {
      return contains($ids, it.cv());
    };
  }
  function BelowSmHighlighter$unhighlight$lambda($ids) {
    return function (it) {
      return contains($ids, it.cv());
    };
  }
  function BelowSmHighlighter(highlightModelProvider, eventBus, content) {
    Companion_getInstance_17();
    highlightModelProvider = highlightModelProvider === VOID ? EditHighlightModule_getInstance().y3n_1 : highlightModelProvider;
    eventBus = eventBus === VOID ? BaseModule_getInstance().bp_1 : eventBus;
    this.r3n_1 = highlightModelProvider;
    this.s3n_1 = eventBus;
    this.t3n_1 = content;
    var tmp = this;
    tmp.u3n_1 = lazy(BelowSmHighlighter$highlights$delegate$lambda);
  }
  protoOf(BelowSmHighlighter).a3o = function (components) {
    // Inline function 'kotlin.collections.mutableListOf' call
    var newHighlights = ArrayList_init_$Create$_0();
    // Inline function 'kotlin.collections.filter' call
    // Inline function 'kotlin.collections.filterTo' call
    var destination = ArrayList_init_$Create$_0();
    var _iterator__ex2g4s = components.i();
    while (_iterator__ex2g4s.j()) {
      var element = _iterator__ex2g4s.k();
      if (!this.b3o(element)) {
        destination.h(element);
      }
    }
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s_0 = destination.i();
    while (_iterator__ex2g4s_0.j()) {
      var element_0 = _iterator__ex2g4s_0.k();
      highlightImpl(this, element_0);
      newHighlights.h(element_0);
    }
    if (newHighlights.o() > 0) {
      this.t3n_1.g3c().k20();
      postHighlightChangedEvent(this, newHighlights, true);
    }
  };
  protoOf(BelowSmHighlighter).c3o = function (ids) {
    var tmp = this.t3n_1.u3b();
    this.a3o(tmp.k21(BelowSmHighlighter$highlight$lambda(ids)));
  };
  protoOf(BelowSmHighlighter).d3o = function (components) {
    // Inline function 'kotlin.collections.mutableListOf' call
    var oldHighlights = ArrayList_init_$Create$_0();
    // Inline function 'kotlin.collections.filter' call
    // Inline function 'kotlin.collections.filterTo' call
    var destination = ArrayList_init_$Create$_0();
    var _iterator__ex2g4s = components.i();
    while (_iterator__ex2g4s.j()) {
      var element = _iterator__ex2g4s.k();
      if (this.b3o(element)) {
        destination.h(element);
      }
    }
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s_0 = destination.i();
    while (_iterator__ex2g4s_0.j()) {
      var element_0 = _iterator__ex2g4s_0.k();
      unhighlightImpl(this, element_0);
      oldHighlights.h(element_0);
    }
    if (oldHighlights.o() > 0) {
      this.t3n_1.g3c().k20();
      postHighlightChangedEvent(this, oldHighlights, false);
    }
  };
  protoOf(BelowSmHighlighter).e3o = function (ids) {
    var tmp = this.t3n_1.u3b();
    this.d3o(tmp.k21(BelowSmHighlighter$unhighlight$lambda(ids)));
  };
  protoOf(BelowSmHighlighter).b3o = function (component) {
    return _get_highlights__9xcox8(this).e2(component);
  };
  function EditHighlightModule$highlightModelFactory$lambda(component) {
    return new BoundingBoxBelowSelectionModel(component, VOID, Companion_getInstance_60().g3o_1);
  }
  function EditHighlightModule$highlighterFactory$1() {
  }
  protoOf(EditHighlightModule$highlighterFactory$1).j3o = function (content) {
    return new BelowSmHighlighter(VOID, VOID, content);
  };
  function EditHighlightModule() {
    EditHighlightModule_instance = this;
    AbstractModule.call(this);
    var tmp = this;
    var tmp_0 = SelectionDrawingStrategy_BELOW_getInstance();
    tmp.x3n_1 = new SelectionModelFactoryImpl(mapOf(to(tmp_0, EditHighlightModule$highlightModelFactory$lambda)));
    this.y3n_1 = new SimpleSelectionModelProvider(this.x3n_1);
    var tmp_1 = this;
    tmp_1.z3n_1 = new EditHighlightModule$highlighterFactory$1();
  }
  protoOf(EditHighlightModule).to = function () {
  };
  var EditHighlightModule_instance;
  function EditHighlightModule_getInstance() {
    if (EditHighlightModule_instance == null)
      new EditHighlightModule();
    return EditHighlightModule_instance;
  }
  var Type_HIGHLIGHTED_instance;
  var Type_UNHIGHLIGHTED_instance;
  var Type_entriesInitialized_0;
  function Type_initEntries_0() {
    if (Type_entriesInitialized_0)
      return Unit_instance;
    Type_entriesInitialized_0 = true;
    Type_HIGHLIGHTED_instance = new Type_0('HIGHLIGHTED', 0);
    Type_UNHIGHLIGHTED_instance = new Type_0('UNHIGHLIGHTED', 1);
  }
  function HighlightChangeEvent_init_$Init$(content, highlighter, components, highlighted, $this) {
    HighlightChangeEvent.call($this, content, highlighter, highlighted ? Type_HIGHLIGHTED_getInstance() : Type_UNHIGHLIGHTED_getInstance(), components);
    return $this;
  }
  function HighlightChangeEvent_init_$Create$(content, highlighter, components, highlighted) {
    return HighlightChangeEvent_init_$Init$(content, highlighter, components, highlighted, objectCreate(protoOf(HighlightChangeEvent)));
  }
  function Type_0(name, ordinal) {
    Enum.call(this, name, ordinal);
  }
  function Type_HIGHLIGHTED_getInstance() {
    Type_initEntries_0();
    return Type_HIGHLIGHTED_instance;
  }
  function Type_UNHIGHLIGHTED_getInstance() {
    Type_initEntries_0();
    return Type_UNHIGHLIGHTED_instance;
  }
  function HighlightChangeEvent(content, highlighter, type, components) {
    this.k3o_1 = content;
    this.l3o_1 = highlighter;
    this.m3o_1 = type;
    this.n3o_1 = components;
    this.o3o_1 = this.m3o_1.equals(Type_HIGHLIGHTED_getInstance());
    this.p3o_1 = this.m3o_1.equals(Type_UNHIGHLIGHTED_getInstance());
  }
  protoOf(HighlightChangeEvent).toString = function () {
    return 'HighlightChangeEvent(content=' + toString(this.k3o_1) + ', highlighter=' + toString(this.l3o_1) + ', type=' + this.m3o_1.toString() + ', components=' + toString(this.n3o_1) + ')';
  };
  protoOf(HighlightChangeEvent).hashCode = function () {
    var result = hashCode(this.k3o_1);
    result = imul(result, 31) + hashCode(this.l3o_1) | 0;
    result = imul(result, 31) + this.m3o_1.hashCode() | 0;
    result = imul(result, 31) + hashCode(this.n3o_1) | 0;
    return result;
  };
  protoOf(HighlightChangeEvent).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof HighlightChangeEvent))
      return false;
    if (!equals(this.k3o_1, other.k3o_1))
      return false;
    if (!equals(this.l3o_1, other.l3o_1))
      return false;
    if (!this.m3o_1.equals(other.m3o_1))
      return false;
    if (!equals(this.n3o_1, other.n3o_1))
      return false;
    return true;
  };
  function AbstractComponent_init_$Init$(styleProvider, styleType, $this) {
    styleProvider = styleProvider === VOID ? DrawStyleModule_getInstance().w1x_1 : styleProvider;
    styleType = styleType === VOID ? Companion_getInstance_0().b1y_1 : styleType;
    AbstractComponent.call($this, new StylableImpl(VOID, styleType, styleProvider));
    return $this;
  }
  function AbstractComponent(stylable) {
    AbstractStyledDrawable.call(this, stylable);
    this.y3m_1 = 0;
    this.z3m_1 = null;
    this.a3n_1 = false;
    this.b3n_1 = false;
    this.c3n_1 = Rotation_R0_getInstance();
  }
  protoOf(AbstractComponent).n3b = function () {
    return StorableCloner_getInstance().s36(this);
  };
  protoOf(AbstractComponent).a3b = function (_set____db54di) {
    this.y3m_1 = _set____db54di;
  };
  protoOf(AbstractComponent).cv = function () {
    return this.y3m_1;
  };
  protoOf(AbstractComponent).b3b = function () {
    return null;
  };
  protoOf(AbstractComponent).e3b = function (_set____db54di) {
    this.z3m_1 = _set____db54di;
  };
  protoOf(AbstractComponent).f3b = function () {
    return this.z3m_1;
  };
  protoOf(AbstractComponent).c3b = function () {
    return false;
  };
  protoOf(AbstractComponent).d3b = function () {
    return this;
  };
  protoOf(AbstractComponent).j3b = function () {
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [new SnappableXCoordinate(this.jw().kn_1)];
  };
  protoOf(AbstractComponent).k3b = function () {
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [new SnappableYCoordinate(this.jw().ln_1)];
  };
  protoOf(AbstractComponent).v21 = function (dx, dy) {
    this.v20(new Point2D(this.jw().kn_1 + dx, this.jw().ln_1 + dy));
  };
  protoOf(AbstractComponent).e38 = function (_set____db54di) {
    this.a3n_1 = _set____db54di;
  };
  protoOf(AbstractComponent).f38 = function () {
    return this.a3n_1;
  };
  protoOf(AbstractComponent).h38 = function (writer) {
    writer.j39('id', this.cv());
    if (!this.c3b()) {
      writer.m39('style', this.h29().d29_1);
    }
    if (!(this.k2d() == null)) {
      writer.m39('color', ensureNotNull(this.k2d()).m2());
    }
    if (!(this.m2d() == null)) {
      writer.m39('stroke', ensureNotNull(this.m2d()).i2o_1.o2o_1);
    }
    if (this.n2i()) {
      writer.m39('rot', this.w20().h1i_1);
    }
    writer.o39('filled', this.f2d());
    writer.o39('stroked', this.h2d());
    if (!(this.p2d() == null)) {
      writer.o39('shadow', ensureNotNull(this.p2d()));
    }
  };
  protoOf(AbstractComponent).i38 = function (reader) {
    if (reader.t35('id')) {
      this.a3b(reader.p38('id'));
    }
    if (this.n2i() && reader.t35('rot')) {
      this.m28(Companion_instance_1.h1f(reader.r38('rot')));
    }
    if (!this.c3b() && reader.t35('style')) {
      var storedStyle = reader.r38('style');
      if (storedStyle === 'explanation') {
        storedStyle = Companion_getInstance_0().a1y_1.d29_1;
      }
      this.c2d(this.x2c().s2t(storedStyle));
    }
    if (reader.t35('color')) {
      this.j2d(this.x2c().q2t().g2o(reader.r38('color')));
    }
    if (reader.t35('stroke')) {
      this.l2d(this.x2c().r2t().k2o(reader.r38('stroke')));
    }
    if (reader.t35('filled')) {
      this.e2d(reader.t38('filled'));
    }
    if (reader.t35('stroked')) {
      this.g2d(reader.t38('stroked'));
    }
    if (reader.t35('shadow')) {
      this.o2d(reader.t38('shadow'));
    }
  };
  protoOf(AbstractComponent).a38 = function (reference, referenceResolver) {
  };
  protoOf(AbstractComponent).q3o = function (_set____db54di) {
    this.b3n_1 = _set____db54di;
  };
  protoOf(AbstractComponent).f22 = function () {
    return this.b3n_1;
  };
  protoOf(AbstractComponent).k22 = function () {
    this.i20();
    this.k20();
  };
  protoOf(AbstractComponent).l22 = function () {
    this.i20();
    this.k20();
  };
  protoOf(AbstractComponent).m28 = function (value) {
    if (!this.n2i()) {
      throw IllegalArgumentException_init_$Create$('rotation not supported');
    }
    if (!value.equals(this.c3n_1)) {
      this.i20();
      this.c3n_1 = value;
      this.d3n(this.c3n_1);
      this.i20();
      this.l20();
    }
  };
  protoOf(AbstractComponent).w20 = function () {
    return this.c3n_1;
  };
  protoOf(AbstractComponent).n2i = function () {
    return false;
  };
  protoOf(AbstractComponent).d3n = function (newRotation) {
  };
  protoOf(AbstractComponent).r3o = function (context, drawer) {
    var tmp2 = this.jw();
    // Inline function 'io.antarescircuit.jabbah.draw.DrawContext.translatedAndRotated' call
    var angle = this.w20().i1i_1;
    context.j1z_1.l1d(tmp2.kn_1, tmp2.ln_1);
    context.j1z_1.o1d(angle);
    drawer(context);
    context.j1z_1.o1d(-angle);
    context.j1z_1.l1d(-tmp2.kn_1, -tmp2.ln_1);
    DrawModule_getInstance().z2p(this, context);
  };
  function fixMissingComponentIds($this) {
    // Inline function 'kotlin.collections.filter' call
    var tmp0 = $this.u20();
    // Inline function 'kotlin.collections.filterTo' call
    var destination = ArrayList_init_$Create$_0();
    var _iterator__ex2g4s = tmp0.i();
    while (_iterator__ex2g4s.j()) {
      var element = _iterator__ex2g4s.k();
      if (element.cv() === 0) {
        destination.h(element);
      }
    }
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s_0 = destination.i();
    while (_iterator__ex2g4s_0.j()) {
      var element_0 = _iterator__ex2g4s_0.k();
      element_0.a3b(getMaxId($this) + 1 | 0);
    }
  }
  function getMaxId($this) {
    if ($this.u20().m()) {
      return 0;
    }
    var tmp0 = $this.u20();
    var tmp$ret$0;
    $l$block_0: {
      // Inline function 'kotlin.collections.maxByOrNull' call
      var iterator = tmp0.i();
      if (!iterator.j()) {
        tmp$ret$0 = null;
        break $l$block_0;
      }
      var maxElem = iterator.k();
      if (!iterator.j()) {
        tmp$ret$0 = maxElem;
        break $l$block_0;
      }
      var maxValue = maxElem.cv();
      do {
        var e = iterator.k();
        var v = e.cv();
        if (compareTo(maxValue, v) < 0) {
          maxElem = e;
          maxValue = v;
        }
      }
       while (iterator.j());
      tmp$ret$0 = maxElem;
    }
    return ensureNotNull(tmp$ret$0).cv();
  }
  function ComponentContainerImpl() {
    DrawableContainerImpl.call(this);
    this.f3p_1 = false;
    this.g3p_1 = false;
  }
  protoOf(ComponentContainerImpl).h3p = function (drawable, index) {
    if (!this.x20(drawable)) {
      if (!this.f3p_1) {
        drawable.a3b(getMaxId(this) + 1 | 0);
      }
      return protoOf(DrawableContainerImpl).a21.call(this, drawable, index);
    }
    return this;
  };
  protoOf(ComponentContainerImpl).a21 = function (drawable, index) {
    return this.h3p(isInterface(drawable, Component) ? drawable : THROW_CCE(), index);
  };
  protoOf(ComponentContainerImpl).o3b = function (id) {
    var tmp0 = this.u20();
    var tmp$ret$0;
    $l$block: {
      // Inline function 'kotlin.collections.firstOrNull' call
      var _iterator__ex2g4s = tmp0.i();
      while (_iterator__ex2g4s.j()) {
        var element = _iterator__ex2g4s.k();
        if (element.cv() === id) {
          tmp$ret$0 = element;
          break $l$block;
        }
      }
      tmp$ret$0 = null;
    }
    return tmp$ret$0;
  };
  protoOf(ComponentContainerImpl).e38 = function (_set____db54di) {
    this.g3p_1 = _set____db54di;
  };
  protoOf(ComponentContainerImpl).f38 = function () {
    return this.g3p_1;
  };
  protoOf(ComponentContainerImpl).h38 = function (writer) {
    writer.h39('components', this.e21());
  };
  protoOf(ComponentContainerImpl).i38 = function (reader) {
    this.z20();
    var _iterator__ex2g4s = reader.n38('components').i();
    while (_iterator__ex2g4s.j()) {
      var storable = _iterator__ex2g4s.k();
      reader.v37(this, new Reference('component', VOID, storable, listOf(reader.x37(storable))));
    }
  };
  protoOf(ComponentContainerImpl).a38 = function (reference, referenceResolver) {
    if (reference.k37_1 === 'component') {
      try {
        this.f3p_1 = true;
        var tmp = reference.m37_1;
        this.b21((!(tmp == null) ? isInterface(tmp, Component) : false) ? tmp : THROW_CCE());
      }finally {
        this.f3p_1 = false;
      }
    }
  };
  protoOf(ComponentContainerImpl).c38 = function () {
    allResolutionDone.call(this);
    fixMissingComponentIds(this);
    this.y29();
  };
  function ComponentMessage(type, source, messageKey, messageParam) {
    type = type === VOID ? ComponentMessageType_Info_getInstance() : type;
    messageParam = messageParam === VOID ? null : messageParam;
    this.i3p_1 = type;
    this.j3p_1 = source;
    this.k3p_1 = messageKey;
    this.l3p_1 = messageParam;
  }
  protoOf(ComponentMessage).toString = function () {
    return 'ComponentMessage(type=' + this.i3p_1.toString() + ', source=' + toString_0(this.j3p_1) + ', messageKey=' + this.k3p_1 + ', messageParam=' + toString_0(this.l3p_1) + ')';
  };
  protoOf(ComponentMessage).hashCode = function () {
    var result = this.i3p_1.hashCode();
    result = imul(result, 31) + (this.j3p_1 == null ? 0 : hashCode(this.j3p_1)) | 0;
    result = imul(result, 31) + getStringHashCode(this.k3p_1) | 0;
    result = imul(result, 31) + (this.l3p_1 == null ? 0 : hashCode(this.l3p_1)) | 0;
    return result;
  };
  protoOf(ComponentMessage).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof ComponentMessage))
      return false;
    if (!this.i3p_1.equals(other.i3p_1))
      return false;
    if (!equals(this.j3p_1, other.j3p_1))
      return false;
    if (!(this.k3p_1 === other.k3p_1))
      return false;
    if (!equals(this.l3p_1, other.l3p_1))
      return false;
    return true;
  };
  var ComponentMessageType_Info_instance;
  var ComponentMessageType_Error_instance;
  var ComponentMessageType_entriesInitialized;
  function ComponentMessageType_initEntries() {
    if (ComponentMessageType_entriesInitialized)
      return Unit_instance;
    ComponentMessageType_entriesInitialized = true;
    ComponentMessageType_Info_instance = new ComponentMessageType('Info', 0);
    ComponentMessageType_Error_instance = new ComponentMessageType('Error', 1);
  }
  function ComponentMessageType(name, ordinal) {
    Enum.call(this, name, ordinal);
  }
  function ComponentMessageType_Info_getInstance() {
    ComponentMessageType_initEntries();
    return ComponentMessageType_Info_instance;
  }
  function ComponentMessageType_Error_getInstance() {
    ComponentMessageType_initEntries();
    return ComponentMessageType_Error_instance;
  }
  function CopyPasteService() {
  }
  function DrawingImpl(name) {
    name = name === VOID ? Name_init_$Create$('Drawing') : name;
    ComponentContainerImpl.call(this);
    this.b3q_1 = name;
  }
  protoOf(DrawingImpl).c3q = function (_set____db54di) {
    this.b3q_1 = _set____db54di;
  };
  protoOf(DrawingImpl).m2 = function () {
    return this.b3q_1;
  };
  protoOf(DrawingImpl).gs = function () {
  };
  function DrawingServiceImpl() {
  }
  var Size_SMALL_instance;
  var Size_MEDIUM_instance;
  var Size_LARGE_instance;
  function Companion_8() {
    this.d3q_1 = 'edit.property.size';
  }
  protoOf(Companion_8).h1f = function (name) {
    var tmp0 = get_entries();
    var tmp$ret$0;
    $l$block: {
      // Inline function 'kotlin.collections.firstOrNull' call
      var _iterator__ex2g4s = tmp0.i();
      while (_iterator__ex2g4s.j()) {
        var element = _iterator__ex2g4s.k();
        if (element.g3q_1 === name) {
          tmp$ret$0 = element;
          break $l$block;
        }
      }
      tmp$ret$0 = null;
    }
    var tmp0_elvis_lhs = tmp$ret$0;
    var tmp;
    if (tmp0_elvis_lhs == null) {
      throw IllegalArgumentException_init_$Create$("unknown Size '" + name + "'");
    } else {
      tmp = tmp0_elvis_lhs;
    }
    return tmp;
  };
  var Companion_instance_13;
  function Companion_getInstance_18() {
    return Companion_instance_13;
  }
  function values() {
    return [Size_SMALL_getInstance(), Size_MEDIUM_getInstance(), Size_LARGE_getInstance()];
  }
  function get_entries() {
    if ($ENTRIES == null)
      $ENTRIES = enumEntries(values());
    return $ENTRIES;
  }
  var Size_entriesInitialized;
  function Size_initEntries() {
    if (Size_entriesInitialized)
      return Unit_instance;
    Size_entriesInitialized = true;
    Size_SMALL_instance = new Size('SMALL', 0, 'small', 0.5);
    Size_MEDIUM_instance = new Size('MEDIUM', 1, 'medium', 0.75);
    Size_LARGE_instance = new Size('LARGE', 2, 'large', 1.0);
  }
  var $ENTRIES;
  function Size(name, ordinal, customName, factor) {
    Enum.call(this, name, ordinal);
    this.g3q_1 = customName;
    this.h3q_1 = factor;
  }
  protoOf(Size).toString = function () {
    var tmp;
    switch (this.l2_1) {
      case 0:
        tmp = Translations_getInstance().bn('edit.property.size.small.name', []);
        break;
      case 1:
        tmp = Translations_getInstance().bn('edit.property.size.medium.name', []);
        break;
      case 2:
        tmp = Translations_getInstance().bn('edit.property.size.large.name', []);
        break;
      default:
        noWhenBranchMatchedException();
        break;
    }
    return tmp;
  };
  function Size_SMALL_getInstance() {
    Size_initEntries();
    return Size_SMALL_instance;
  }
  function Size_MEDIUM_getInstance() {
    Size_initEntries();
    return Size_MEDIUM_instance;
  }
  function Size_LARGE_getInstance() {
    Size_initEntries();
    return Size_LARGE_instance;
  }
  function Companion_9() {
    this.i3q_1 = 2.0;
  }
  var Companion_instance_14;
  function Companion_getInstance_19() {
    return Companion_instance_14;
  }
  function _set__points__m4els3($this, value) {
    if ($this.s3q_1.o() > 0) {
      $this.i20();
    }
    $this.s3q_1 = value;
    $this.x3q();
    $this.i20();
    $this.l20();
  }
  function drawImpl($this, context, lineColor, fillColor) {
    var oldColor = context.j1z_1.c1u();
    if ($this.i2d() && !(fillColor == null)) {
      var tmp = DropShadow_instance;
      var tmp_0 = $this.d2i();
      tmp.l2n(context, tmp_0, AbstractCurveComponent$drawImpl$lambda(context, $this));
    }
    if (!(fillColor == null)) {
      context.j1z_1.b1u(fillColor);
      context.j1z_1.k1v($this.y3q());
    }
    context.j1z_1.b1u(lineColor);
    context.j1z_1.e1u($this.l1u());
    context.j1z_1.j1v($this.y3q());
    context.j1z_1.b1u(oldColor);
  }
  function doInvalidating($this, logic) {
    if ($this.z3q().o() === $this.t2k()) {
      $this.i20();
    }
    logic();
    $this.x3q();
    $this.i20();
    $this.l20();
  }
  function setPointsImpl($this, newPoints) {
    // Inline function 'kotlin.collections.mutableListOf' call
    var p = ArrayList_init_$Create$_0();
    p.f1(newPoints);
    _set__points__m4els3($this, p);
  }
  function AbstractCurveComponent$_set_location_$lambda_joojqt($value, this$0) {
    return function () {
      var dx = $value.kn_1 - this$0.z3q().l(0).kn_1;
      var dy = $value.ln_1 - this$0.z3q().l(0).ln_1;
      // Inline function 'kotlin.collections.forEachIndexed' call
      var index = 0;
      var _iterator__ex2g4s = toList(this$0.s3q_1).i();
      while (_iterator__ex2g4s.j()) {
        var item = _iterator__ex2g4s.k();
        var _unary__edvuaz = index;
        index = _unary__edvuaz + 1 | 0;
        var index_0 = checkIndexOverflow(_unary__edvuaz);
        this$0.s3q_1.u2(index_0, item.vn(dx, dy));
      }
      return Unit_instance;
    };
  }
  function AbstractCurveComponent$drawImpl$lambda($context, this$0) {
    return function (it) {
      $context.j1z_1.k1v(this$0.y3q());
      return Unit_instance;
    };
  }
  function AbstractCurveComponent$setPointAt$lambda(this$0, $index, $location) {
    return function () {
      this$0.s3q_1.u2($index, $location);
      return Unit_instance;
    };
  }
  function AbstractCurveComponent(points) {
    AbstractComponent_init_$Init$(VOID, VOID, this);
    var tmp = this;
    // Inline function 'kotlin.collections.mutableListOf' call
    tmp.s3q_1 = ArrayList_init_$Create$_0();
    // Inline function 'kotlin.require' call
    if (!(points.o() === this.t2k())) {
      var message = 'Points count must be ' + this.t2k() + ', but is ' + points.o();
      throw IllegalArgumentException_init_$Create$(toString(message));
    }
    setPointsImpl(this, points);
    this.u3q_1 = false;
    this.v3q_1 = false;
    this.w3q_1 = new TransparentImpl(this);
  }
  protoOf(AbstractCurveComponent).y3q = function () {
    var tmp = this.t3q_1;
    if (!(tmp == null))
      return tmp;
    else {
      throwUninitializedPropertyAccessException('path');
    }
  };
  protoOf(AbstractCurveComponent).a3r = function (value) {
    // Inline function 'kotlin.check' call
    if (!(value.o() === this.t2k())) {
      throw IllegalStateException_init_$Create$('Check failed.');
    }
    setPointsImpl(this, value);
  };
  protoOf(AbstractCurveComponent).z3q = function () {
    return this.s3q_1;
  };
  protoOf(AbstractCurveComponent).b3r = function (value) {
    if (!(this.u3q_1 === value)) {
      this.u3q_1 = value;
      if (!this.f38()) {
        this.f2i(this.jw().kn_1);
      }
    }
  };
  protoOf(AbstractCurveComponent).c3r = function (value) {
    if (!(this.v3q_1 === value)) {
      this.v3q_1 = value;
      if (!this.f38()) {
        this.g2i(this.jw().ln_1);
      }
    }
  };
  protoOf(AbstractCurveComponent).v20 = function (value) {
    if (!this.jw().equals(value)) {
      doInvalidating(this, AbstractCurveComponent$_set_location_$lambda_joojqt(value, this));
    }
  };
  protoOf(AbstractCurveComponent).jw = function () {
    return this.s3q_1.l(0);
  };
  protoOf(AbstractCurveComponent).a2i = function (value) {
    this.w3q_1.a2i(value);
  };
  protoOf(AbstractCurveComponent).d2i = function () {
    return this.w3q_1.c2i_1;
  };
  protoOf(AbstractCurveComponent).n2i = function () {
    return false;
  };
  protoOf(AbstractCurveComponent).f2i = function (x) {
    // Inline function 'kotlin.collections.map' call
    var this_0 = this.z3q();
    // Inline function 'kotlin.collections.mapTo' call
    var destination = ArrayList_init_$Create$(collectionSizeOrDefault(this_0, 10));
    var _iterator__ex2g4s = this_0.i();
    while (_iterator__ex2g4s.j()) {
      var item = _iterator__ex2g4s.k();
      var tmp$ret$2 = item.g1h(x);
      destination.h(tmp$ret$2);
    }
    this.a3r(destination);
  };
  protoOf(AbstractCurveComponent).g2i = function (y) {
    // Inline function 'kotlin.collections.map' call
    var this_0 = this.z3q();
    // Inline function 'kotlin.collections.mapTo' call
    var destination = ArrayList_init_$Create$(collectionSizeOrDefault(this_0, 10));
    var _iterator__ex2g4s = this_0.i();
    while (_iterator__ex2g4s.j()) {
      var item = _iterator__ex2g4s.k();
      var tmp$ret$2 = item.h1h(y);
      destination.h(tmp$ret$2);
    }
    this.a3r(destination);
  };
  protoOf(AbstractCurveComponent).j3b = function () {
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [new SnappableXCoordinate(this.z3q().l(0).kn_1), new SnappableXCoordinate(this.z3q().l(2).kn_1)];
  };
  protoOf(AbstractCurveComponent).k3b = function () {
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [new SnappableYCoordinate(this.z3q().l(0).ln_1), new SnappableYCoordinate(this.z3q().l(2).ln_1)];
  };
  protoOf(AbstractCurveComponent).i38 = function (reader) {
    protoOf(AbstractComponent).i38.call(this, reader);
    // Inline function 'kotlin.collections.mutableListOf' call
    var p = ArrayList_init_$Create$_0();
    p.f1(reader.w38('points'));
    _set__points__m4els3(this, p);
    if (reader.t35('mirrorH')) {
      this.b3r(reader.t38('mirrorH'));
    }
    if (reader.t35('mirrorV')) {
      this.c3r(reader.t38('mirrorV'));
    }
  };
  protoOf(AbstractCurveComponent).h38 = function (writer) {
    protoOf(AbstractComponent).h38.call(this, writer);
    writer.r39('points', this.z3q());
    if (this.u3q_1) {
      writer.o39('mirrorH', this.u3q_1);
    }
    if (this.v3q_1) {
      writer.o39('mirrorV', this.v3q_1);
    }
  };
  protoOf(AbstractCurveComponent).fo = function () {
    return this.y3q().fo();
  };
  protoOf(AbstractCurveComponent).go = function (x, y) {
    return this.y3q().io(x - 2.0, y - 2.0, 2 * 2.0, 2 * 2.0);
  };
  protoOf(AbstractCurveComponent).h20 = function (context) {
    if (context.m1z_1) {
      drawImpl(this, context, ensureNotNull(context.n1z_1).x1x_1, this.f2d() ? ensureNotNull(context.n1z_1).y1x_1 : null);
    } else {
      drawImpl(this, context, this.w3q_1.l2h(this.y2c()), this.f2d() ? this.w3q_1.l2h(this.z2c()) : null);
    }
  };
  protoOf(AbstractCurveComponent).f3b = function () {
    return SelectionDrawingStrategy_ABOVE_getInstance();
  };
  protoOf(AbstractCurveComponent).u2k = function (index) {
    return this.z3q().l(index);
  };
  protoOf(AbstractCurveComponent).d3r = function (index, location) {
    // Inline function 'kotlin.require' call
    if (!(0 <= index ? index < this.t2k() : false)) {
      var message = 'index ' + index + ' not in range 0..' + this.t2k();
      throw IllegalArgumentException_init_$Create$(toString(message));
    }
    doInvalidating(this, AbstractCurveComponent$setPointAt$lambda(this, index, location));
  };
  function _get_LOG__e5r759_4($this) {
    var tmp0 = $this.e3r_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('LOG', 1, tmp, AbstractCurveHandleSelectionModel$Companion$_get_LOG_$ref_whlqcy(), null);
    return tmp0.j2();
  }
  function AbstractCurveHandleSelectionModel$Companion$_get_LOG_$ref_whlqcy() {
    return function (p0) {
      return _get_LOG__e5r759_4(p0);
    };
  }
  function Companion_10() {
    Companion_instance_15 = this;
    this.e3r_1 = logger(getKClass(AbstractCurveHandleSelectionModel));
    var tmp = this;
    // Inline function 'kotlin.floatArrayOf' call
    var tmp$ret$0 = new Float32Array([2.0, 4.0]);
    tmp.f3r_1 = new Stroke(0.5, VOID, VOID, VOID, tmp$ret$0);
  }
  var Companion_instance_15;
  function Companion_getInstance_20() {
    if (Companion_instance_15 == null)
      new Companion_10();
    return Companion_instance_15;
  }
  function createHandles($this) {
    $this.q3r();
    var inductionVariable = 0;
    var last = $this.r3r();
    if (inductionVariable < last)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        $this.d3s(new RectangularHandle($this.c3s_1));
      }
       while (inductionVariable < last);
    $this.n3r_1 = $this.r3r();
  }
  function CurveEventHandler($outer) {
    this.i3s_1 = $outer;
    EventHandler.call(this, $outer);
    this.h3s_1 = Companion_getInstance().w1a_1;
  }
  protoOf(CurveEventHandler).j3s = function (view) {
    var index = this.i3s_1.n3s(ensureNotNull(this.l3s_1));
    this.h3s_1 = Point2D_init_$Create$(this.i3s_1.t3s().u2k(index));
  };
  protoOf(CurveEventHandler).u3s = function (context) {
    var index = this.i3s_1.n3s(ensureNotNull(this.l3s_1));
    var newLocation = this.i3s_1.t3s().u2k(index);
    _get_LOG__e5r759_4(Companion_getInstance_20()).kl('Move point ' + index + " of '" + this.i3s_1.t3s().k1a() + "' " + this.i3s_1.t3s().cv() + ' to ' + newLocation.toString());
    context.w3c_1.d3d().u3a(new MoveCurvePointCommand(context.w3c_1.v1o(), this.i3s_1.t3s().cv(), index, this.h3s_1, newLocation));
  };
  function QuadCurveInputEventHandler($outer) {
    this.c3t_1 = $outer;
    InputEventHandlerAdapter.call(this);
  }
  protoOf(QuadCurveInputEventHandler).x3s = function (context) {
    context.n22_1.l1y(Cursor_CROSSHAIR_getInstance());
    return this;
  };
  protoOf(QuadCurveInputEventHandler).z22 = function (context) {
    return this.x3s(context instanceof EditInputEventContext ? context : THROW_CCE());
  };
  protoOf(QuadCurveInputEventHandler).z3s = function (context) {
    var tmp = this.c3t_1.t3s();
    var tmp_0 = this.c3t_1.d3t();
    tmp.d3r(this.c3t_1.n3s(ensureNotNull((tmp_0 instanceof CurveEventHandler ? tmp_0 : THROW_CCE()).l3s_1)), new Point2D(context.q22_1, context.r22_1));
    return this;
  };
  protoOf(QuadCurveInputEventHandler).b23 = function (context) {
    return this.z3s(context instanceof EditInputEventContext ? context : THROW_CCE());
  };
  function AbstractCurveHandleSelectionModel(c) {
    Companion_getInstance_20();
    AbstractHandleSelectionModel.call(this, c);
    this.c3s_1 = new QuadCurveInputEventHandler(this);
  }
  protoOf(AbstractCurveHandleSelectionModel).e3t = function () {
    return new CurveEventHandler(this);
  };
  protoOf(AbstractCurveHandleSelectionModel).f3t = function () {
    if (!(this.n3r_1 === this.r3r())) {
      createHandles(this);
    }
    var inductionVariable = 0;
    var last = this.r3r();
    if (inductionVariable < last)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        this.g3t(i).v20(this.t3s().u2k(i));
      }
       while (inductionVariable < last);
  };
  function Companion_11() {
    Companion_instance_16 = this;
    this.p3t_1 = Translations_getInstance().bn('edit.component.cubicCurve', []);
    this.q3t_1 = listOf_0([Point2D_init_$Create$_0(0, 0), Point2D_init_$Create$_0(100, 100), Point2D_init_$Create$_0(200, 100), Point2D_init_$Create$_0(200, 0)]);
  }
  var Companion_instance_16;
  function Companion_getInstance_21() {
    if (Companion_instance_16 == null)
      new Companion_11();
    return Companion_instance_16;
  }
  function CubicCurveComponent(points) {
    Companion_getInstance_21();
    points = points === VOID ? Companion_getInstance_21().q3t_1 : points;
    AbstractCurveComponent.call(this, points);
  }
  protoOf(CubicCurveComponent).k1a = function () {
    return Companion_getInstance_21().p3t_1;
  };
  protoOf(CubicCurveComponent).t2k = function () {
    return 4;
  };
  protoOf(CubicCurveComponent).x3q = function () {
    // Inline function 'kotlin.check' call
    if (!(this.z3q().o() === this.t2k())) {
      throw IllegalStateException_init_$Create$('Check failed.');
    }
    this.t3q_1 = System_getInstance().cm();
    this.y3q().un(this.z3q().l(0).kn_1, this.z3q().l(0).ln_1);
    this.y3q().co(this.z3q().l(1).kn_1, this.z3q().l(1).ln_1, this.z3q().l(2).kn_1, this.z3q().l(2).ln_1, this.z3q().l(3).kn_1, this.z3q().l(3).ln_1);
  };
  function drawTangents($this, context) {
    context.j1z_1.e1u(Companion_getInstance_20().f3r_1);
    context.j1z_1.b1u(DrawModule_getInstance().l2a_1.z1z('select.handle.color.border'));
    var tmp = $this.g3t(0);
    var tmp_0 = (tmp instanceof AbstractRectangularUnzoomable ? tmp : THROW_CCE()).q2c();
    var tmp_1 = $this.g3t(1);
    context.j1z_1.b1w(tmp_0, (tmp_1 instanceof AbstractRectangularUnzoomable ? tmp_1 : THROW_CCE()).q2c());
    var tmp_2 = $this.g3t(3);
    var tmp_3 = (tmp_2 instanceof AbstractRectangularUnzoomable ? tmp_2 : THROW_CCE()).q2c();
    var tmp_4 = $this.g3t(2);
    context.j1z_1.b1w(tmp_3, (tmp_4 instanceof AbstractRectangularUnzoomable ? tmp_4 : THROW_CCE()).q2c());
  }
  function CubicCurveHandleSelectionModel(c) {
    AbstractCurveHandleSelectionModel.call(this, c);
  }
  protoOf(CubicCurveHandleSelectionModel).r3r = function () {
    return 4;
  };
  protoOf(CubicCurveHandleSelectionModel).h20 = function (context) {
    drawTangents(this, context);
    protoOf(AbstractCurveHandleSelectionModel).h20.call(this, context);
  };
  function CubicCurveReplaceSelectionModel(component) {
    AbstractSelectedColorWrappingSelectionModel.call(this, component);
  }
  protoOf(CubicCurveReplaceSelectionModel).y3u = function (component) {
    return new CubicCurveHandleSelectionModel(component);
  };
  protoOf(CubicCurveReplaceSelectionModel).z3u = function (component) {
    return this.y3u(component instanceof CubicCurveComponent ? component : THROW_CCE());
  };
  function EditModuleCurveModule$initialize$lambda(it) {
    return new QuadCurveReplaceSelectionModel(it instanceof QuadCurveComponent ? it : THROW_CCE());
  }
  function EditModuleCurveModule$initialize$lambda_0(it) {
    return new CubicCurveReplaceSelectionModel(it instanceof CubicCurveComponent ? it : THROW_CCE());
  }
  function EditModuleCurveModule() {
    EditModuleCurveModule_instance = this;
    AbstractModule.call(this);
  }
  protoOf(EditModuleCurveModule).to = function () {
    var tmp = EditSelectModule_getInstance().t3l_1;
    var tmp_0 = SelectionDrawingStrategy_ABOVE_getInstance();
    var tmp_1 = getKClass(QuadCurveComponent);
    tmp.o3v(tmp_0, tmp_1, EditModuleCurveModule$initialize$lambda);
    var tmp_2 = EditSelectModule_getInstance().t3l_1;
    var tmp_3 = SelectionDrawingStrategy_ABOVE_getInstance();
    var tmp_4 = getKClass(CubicCurveComponent);
    tmp_2.o3v(tmp_3, tmp_4, EditModuleCurveModule$initialize$lambda_0);
  };
  var EditModuleCurveModule_instance;
  function EditModuleCurveModule_getInstance() {
    if (EditModuleCurveModule_instance == null)
      new EditModuleCurveModule();
    return EditModuleCurveModule_instance;
  }
  function _get_curve__isum2m($this) {
    var tmp = ensureNotNull($this.t3v_1.u3b().o3b($this.u3v_1)).d3b();
    return tmp instanceof AbstractCurveComponent ? tmp : THROW_CCE();
  }
  function MoveCurvePointCommand(drawingView, curveId, index, oldLocation, newLocation) {
    AbstractDrawingViewCommand.call(this, 'edit.model.polyline.movePoint', drawingView);
    this.t3v_1 = drawingView;
    this.u3v_1 = curveId;
    this.v3v_1 = index;
    this.w3v_1 = oldLocation;
    this.x3v_1 = newLocation;
  }
  protoOf(MoveCurvePointCommand).i3a = function () {
    _get_curve__isum2m(this).d3r(this.v3v_1, this.x3v_1);
  };
  protoOf(MoveCurvePointCommand).m3a = function () {
    _get_curve__isum2m(this).d3r(this.v3v_1, this.w3v_1);
  };
  function Companion_12() {
    Companion_instance_17 = this;
    this.y3v_1 = Translations_getInstance().bn('edit.component.quadraticCurve', []);
    this.z3v_1 = listOf_0([Point2D_init_$Create$_0(0, 0), Point2D_init_$Create$_0(100, 100), Point2D_init_$Create$_0(200, 0)]);
  }
  var Companion_instance_17;
  function Companion_getInstance_22() {
    if (Companion_instance_17 == null)
      new Companion_12();
    return Companion_instance_17;
  }
  function QuadCurveComponent(points) {
    Companion_getInstance_22();
    points = points === VOID ? Companion_getInstance_22().z3v_1 : points;
    AbstractCurveComponent.call(this, points);
  }
  protoOf(QuadCurveComponent).k1a = function () {
    return Companion_getInstance_22().y3v_1;
  };
  protoOf(QuadCurveComponent).t2k = function () {
    return 3;
  };
  protoOf(QuadCurveComponent).x3q = function () {
    // Inline function 'kotlin.check' call
    if (!(this.z3q().o() === this.t2k())) {
      throw IllegalStateException_init_$Create$('Check failed.');
    }
    this.t3q_1 = System_getInstance().cm();
    this.y3q().un(this.z3q().l(0).kn_1, this.z3q().l(0).ln_1);
    this.y3q().bo(this.z3q().l(1).kn_1, this.z3q().l(1).ln_1, this.z3q().l(2).kn_1, this.z3q().l(2).ln_1);
  };
  function drawTangents_0($this, context) {
    context.j1z_1.e1u(Companion_getInstance_20().f3r_1);
    context.j1z_1.b1u(DrawModule_getInstance().l2a_1.z1z('select.handle.color.border'));
    var tmp = $this.g3t(0);
    var tmp_0 = (tmp instanceof AbstractRectangularUnzoomable ? tmp : THROW_CCE()).q2c();
    var tmp_1 = $this.g3t(1);
    context.j1z_1.b1w(tmp_0, (tmp_1 instanceof AbstractRectangularUnzoomable ? tmp_1 : THROW_CCE()).q2c());
    var tmp_2 = $this.g3t(1);
    var tmp_3 = (tmp_2 instanceof AbstractRectangularUnzoomable ? tmp_2 : THROW_CCE()).q2c();
    var tmp_4 = $this.g3t(2);
    context.j1z_1.b1w(tmp_3, (tmp_4 instanceof AbstractRectangularUnzoomable ? tmp_4 : THROW_CCE()).q2c());
  }
  function QuadCurveHandleSelectionModel(c) {
    AbstractCurveHandleSelectionModel.call(this, c);
  }
  protoOf(QuadCurveHandleSelectionModel).r3r = function () {
    return 3;
  };
  protoOf(QuadCurveHandleSelectionModel).h20 = function (context) {
    drawTangents_0(this, context);
    protoOf(AbstractCurveHandleSelectionModel).h20.call(this, context);
  };
  function QuadCurveReplaceSelectionModel(component) {
    AbstractSelectedColorWrappingSelectionModel.call(this, component);
  }
  protoOf(QuadCurveReplaceSelectionModel).h3x = function (component) {
    return new QuadCurveHandleSelectionModel(component);
  };
  protoOf(QuadCurveReplaceSelectionModel).z3u = function (component) {
    return this.h3x(component instanceof QuadCurveComponent ? component : THROW_CCE());
  };
  function EditModelGroupModule$initialize$lambda(it) {
    return new GroupComponentSelectionModel(it instanceof GroupComponent ? it : THROW_CCE());
  }
  function EditModelGroupModule() {
    EditModelGroupModule_instance = this;
    AbstractModule.call(this);
  }
  protoOf(EditModelGroupModule).to = function () {
    var tmp = EditSelectModule_getInstance().t3l_1;
    var tmp_0 = SelectionDrawingStrategy_REPLACE_getInstance();
    var tmp_1 = getKClass(GroupComponent);
    tmp.o3v(tmp_0, tmp_1, EditModelGroupModule$initialize$lambda);
  };
  var EditModelGroupModule_instance;
  function EditModelGroupModule_getInstance() {
    if (EditModelGroupModule_instance == null)
      new EditModelGroupModule();
    return EditModelGroupModule_instance;
  }
  function Companion_13() {
    Companion_instance_18 = this;
    this.j3x_1 = Translations_getInstance().bn('edit.component.group', []);
  }
  var Companion_instance_18;
  function Companion_getInstance_23() {
    if (Companion_instance_18 == null)
      new Companion_13();
    return Companion_instance_18;
  }
  function updateBoundingBox($this) {
    // Inline function 'kotlin.collections.isNotEmpty' call
    if (!$this.v3x().m()) {
      $this.u3x_1.m1c($this.v3x().l(0).fo());
      var inductionVariable = 1;
      var last = $this.v3x().o();
      if (inductionVariable < last)
        do {
          var i = inductionVariable;
          inductionVariable = inductionVariable + 1 | 0;
          $this.u3x_1.n1c($this.v3x().l(i).fo());
        }
         while (inductionVariable < last);
    }
  }
  function GroupComponent(components) {
    Companion_getInstance_23();
    var tmp;
    if (components === VOID) {
      // Inline function 'kotlin.collections.listOf' call
      tmp = emptyList();
    } else {
      tmp = components;
    }
    components = tmp;
    AbstractComponent_init_$Init$(VOID, VOID, this);
    var tmp_0 = this;
    // Inline function 'kotlin.collections.mutableListOf' call
    tmp_0.t3x_1 = ArrayList_init_$Create$_0();
    this.u3x_1 = new Rectangle2D();
    this.t3x_1.f1(components);
    updateBoundingBox(this);
  }
  protoOf(GroupComponent).v3x = function () {
    return this.t3x_1;
  };
  protoOf(GroupComponent).k1a = function () {
    return Companion_getInstance_23().j3x_1;
  };
  protoOf(GroupComponent).v20 = function (value) {
    this.i20();
    var offsetX = value.kn_1 - this.u3x_1.u1h_1;
    var offsetY = value.ln_1 - this.u3x_1.v1h_1;
    this.u3x_1.i1c(value.kn_1, value.ln_1, this.u3x_1.w1h_1, this.u3x_1.x1h_1);
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = this.v3x().i();
    while (_iterator__ex2g4s.j()) {
      var element = _iterator__ex2g4s.k();
      element.v20(element.jw().vn(offsetX, offsetY));
    }
    this.i20();
    this.l20();
  };
  protoOf(GroupComponent).jw = function () {
    return new Point2D(this.u3x_1.u1h_1, this.u3x_1.v1h_1);
  };
  protoOf(GroupComponent).fo = function () {
    return Rectangle2D_init_$Create$(this.u3x_1);
  };
  protoOf(GroupComponent).h20 = function (context) {
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = asReversed(this.v3x()).i();
    while (_iterator__ex2g4s.j()) {
      var element = _iterator__ex2g4s.k();
      element.h20(context);
    }
  };
  protoOf(GroupComponent).go = function (x, y) {
    var tmp0 = this.v3x();
    var tmp$ret$0;
    $l$block_0: {
      // Inline function 'kotlin.collections.any' call
      var tmp;
      if (isInterface(tmp0, Collection)) {
        tmp = tmp0.m();
      } else {
        tmp = false;
      }
      if (tmp) {
        tmp$ret$0 = false;
        break $l$block_0;
      }
      var _iterator__ex2g4s = tmp0.i();
      while (_iterator__ex2g4s.j()) {
        var element = _iterator__ex2g4s.k();
        if (element.go(x, y)) {
          tmp$ret$0 = true;
          break $l$block_0;
        }
      }
      tmp$ret$0 = false;
    }
    return tmp$ret$0;
  };
  protoOf(GroupComponent).h38 = function (writer) {
    protoOf(AbstractComponent).h38.call(this, writer);
    writer.h39('component', this.v3x().i());
  };
  protoOf(GroupComponent).i38 = function (reader) {
    protoOf(AbstractComponent).i38.call(this, reader);
    this.t3x_1.a2();
    this.t3x_1.f1(reader.n38('component'));
    updateBoundingBox(this);
  };
  function GroupComponentSelectionModel(model, provider) {
    provider = provider === VOID ? EditSelectModule_getInstance().u3l_1 : provider;
    AbstractSelectionModel.call(this, model);
    this.b3y_1 = provider;
    var tmp = this;
    // Inline function 'kotlin.collections.mutableMapOf' call
    tmp.c3y_1 = LinkedHashMap_init_$Create$();
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = this.t3s().v3x().i();
    while (_iterator__ex2g4s.j()) {
      var element = _iterator__ex2g4s.k();
      var tmp0 = this.c3y_1;
      var tmp0_elvis_lhs = this.b3y_1.v3n(element, SelectionDrawingStrategy_REPLACE_getInstance());
      // Inline function 'kotlin.collections.set' call
      var value = tmp0_elvis_lhs == null ? new SelectedColorSelectionModel(element) : tmp0_elvis_lhs;
      tmp0.y1(element, value);
    }
  }
  protoOf(GroupComponentSelectionModel).fo = function () {
    return this.t3s().fo();
  };
  protoOf(GroupComponentSelectionModel).h20 = function (context) {
    var oldUseContextColors = context.m1z_1;
    context.m1z_1 = true;
    context.p1z_1 = Themes_getInstance().h2g().p3y_1.c1u();
    context.j1z_1.b1u(ensureNotNull(context.p1z_1).x1x_1);
    context.n1z_1 = context.p1z_1;
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = asReversed(this.t3s().v3x()).i();
    while (_iterator__ex2g4s.j()) {
      var element = _iterator__ex2g4s.k();
      ensureNotNull(this.c3y_1.g2(element)).h20(context);
    }
    context.m1z_1 = oldUseContextColors;
  };
  protoOf(GroupComponentSelectionModel).go = function (x, y) {
    return this.t3s().go(x, y);
  };
  protoOf(GroupComponentSelectionModel).j3t = function () {
  };
  function Companion_14() {
    this.u3y_1 = 100.0;
    this.v3y_1 = 50.0;
  }
  var Companion_instance_19;
  function Companion_getInstance_24() {
    return Companion_instance_19;
  }
  function drawImage($this, context) {
    var scaleX = $this.f1c() / ensureNotNull($this.x3z_1.j2()).g3z_1.f1c();
    var scaleY = $this.h1c() / ensureNotNull($this.x3z_1.j2()).g3z_1.h1c();
    // Inline function 'io.antarescircuit.jabbah.draw.DrawContext.translated' call
    var d = $this.jw();
    context.j1z_1.l1d(d.kn_1, d.ln_1);
    context.j1z_1.n1d(scaleX, scaleY);
    context.j1z_1.o1v(ensureNotNull($this.x3z_1.j2()).g3z_1, 0, 0);
    context.j1z_1.n1d(1 / scaleX, 1 / scaleY);
    context.j1z_1.l1d(-d.kn_1, -d.ln_1);
  }
  function initializeGeometry($this) {
    if (!($this.x3z_1.j2() == null)) {
      $this.i1c($this.p1a(), $this.q1a(), ensureNotNull($this.x3z_1.j2()).g3z_1.f1c(), ensureNotNull($this.x3z_1.j2()).g3z_1.h1c());
    } else {
      $this.i1c($this.p1a(), $this.q1a(), 100.0, 50.0);
    }
  }
  function updateGeometry($this) {
    if (!($this.x3z_1.j2() == null)) {
      $this.i1c($this.p1a(), $this.q1a(), $this.f1c(), $this.h1c());
    } else {
      $this.i1c($this.p1a(), $this.q1a(), 100.0, 50.0);
    }
  }
  function ImageComponent$imageData$lambda(this$0) {
    return function () {
      var tmp0_safe_receiver = this$0.w3z_1;
      var tmp;
      if (tmp0_safe_receiver == null) {
        tmp = null;
      } else {
        // Inline function 'kotlin.let' call
        tmp = EditModule_getInstance().c3g_1.n40(tmp0_safe_receiver);
      }
      return tmp;
    };
  }
  function ImageComponent$type$delegate$lambda() {
    return Translations_getInstance().bn('edit.component.image', []);
  }
  function ImageComponent$_get_type_$ref_bx7542() {
    return function (p0) {
      return p0.k1a();
    };
  }
  function ImageComponent(uuid) {
    uuid = uuid === VOID ? null : uuid;
    RectangleComponent.call(this);
    this.w3z_1 = uuid;
    var tmp = this;
    tmp.x3z_1 = resettableLazy(ImageComponent$imageData$lambda(this));
    initializeGeometry(this);
    var tmp_0 = this;
    tmp_0.y3z_1 = lazy(ImageComponent$type$delegate$lambda);
  }
  protoOf(ImageComponent).o40 = function (value) {
    if (!equals(this.w3z_1, value)) {
      this.i20();
      this.w3z_1 = value;
      this.x3z_1.du();
      updateGeometry(this);
      this.i20();
      this.l20();
    }
  };
  protoOf(ImageComponent).n2i = function () {
    return true;
  };
  protoOf(ImageComponent).k1a = function () {
    var tmp0 = this.y3z_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('type', 1, tmp, ImageComponent$_get_type_$ref_bx7542(), null);
    return tmp0.j2();
  };
  protoOf(ImageComponent).i38 = function (reader) {
    protoOf(RectangleComponent).i38.call(this, reader);
    this.o40(new UUID(reader.r38('uuid')));
  };
  protoOf(ImageComponent).h38 = function (writer) {
    protoOf(RectangleComponent).h38.call(this, writer);
    writer.m39('uuid', toString_0(this.w3z_1));
  };
  protoOf(ImageComponent).p40 = function () {
    return true;
  };
  protoOf(ImageComponent).q40 = function (context, strokeColor, fillColor) {
    if (!(this.x3z_1.j2() == null)) {
      drawImage(this, context);
    } else {
      protoOf(RectangleComponent).q40.call(this, context, strokeColor, fillColor);
      if (!(strokeColor == null)) {
        context.j1z_1.b1u(strokeColor);
        context.j1z_1.e1u(this.l1u());
        context.j1z_1.t1u(this.p1a(), this.q1a(), this.p1a() + this.f1c(), this.q1a() + this.h1c());
        context.j1z_1.t1u(this.p1a(), this.q1a() + this.h1c(), this.p1a() + this.f1c(), this.q1a());
      }
    }
  };
  protoOf(ImageComponent).r40 = function (context, strokeColor, fillColor) {
  };
  protoOf(ImageComponent).s40 = function (context) {
    context.j1z_1.b1u(ensureNotNull(context.n1z_1).x1x_1);
    protoOf(RectangleComponent).q40.call(this, context, ensureNotNull(context.n1z_1).x1x_1, null);
  };
  function ImageIdentification$_get_name_$ref_birc7e() {
    return function (p0) {
      return p0.m2();
    };
  }
  function ImageIdentification$_set_name_$ref_obnno6() {
    return function (p0, p1) {
      p0.c3q(p1);
      return Unit_instance;
    };
  }
  function ImageIdentification$_get_name_$ref_birc7e_0() {
    return function (p0) {
      return p0.m2();
    };
  }
  function ImageIdentification$_set_name_$ref_obnno6_0() {
    return function (p0, p1) {
      p0.c3q(p1);
      return Unit_instance;
    };
  }
  function ImageIdentification(uuid, imageType, name) {
    uuid = uuid === VOID ? new UUID('undefined') : uuid;
    imageType = imageType === VOID ? ImageType_SVG_getInstance() : imageType;
    name = name === VOID ? new Name(new TranslatableText()) : name;
    AbstractStorable.call(this);
    this.d41_1 = uuid;
    this.e41_1 = imageType;
    this.f41_1 = observableName(name);
  }
  protoOf(ImageIdentification).c3q = function (_set____db54di) {
    var tmp = KMutableProperty1;
    var tmp_0 = ImageIdentification$_get_name_$ref_birc7e_0();
    return this.f41_1.yf(this, getPropertyCallableRef('name', 1, tmp, tmp_0, ImageIdentification$_set_name_$ref_obnno6_0()), _set____db54di);
  };
  protoOf(ImageIdentification).m2 = function () {
    var tmp = KMutableProperty1;
    var tmp_0 = ImageIdentification$_get_name_$ref_birc7e();
    return this.f41_1.wf(this, getPropertyCallableRef('name', 1, tmp, tmp_0, ImageIdentification$_set_name_$ref_obnno6()));
  };
  protoOf(ImageIdentification).i38 = function (reader) {
    this.d41_1 = new UUID(reader.r38('uuid'));
    this.e41_1 = Companion_instance_2.h1f(reader.r38('type'));
    this.c3q(Companion_instance_40.g41('name', reader));
  };
  protoOf(ImageIdentification).h38 = function (writer) {
    writer.m39('uuid', this.d41_1.toString());
    writer.m39('type', this.e41_1.w1r_1);
    this.m2().i41('name', writer);
  };
  protoOf(ImageIdentification).a38 = function (reference, referenceResolver) {
  };
  protoOf(ImageIdentification).toString = function () {
    return this.m2().j2();
  };
  protoOf(ImageIdentification).equals = function (other) {
    if (this === other)
      return true;
    if (other == null || !getKClassFromExpression(this).equals(getKClassFromExpression(other)))
      return false;
    if (!(other instanceof ImageIdentification))
      THROW_CCE();
    if (!this.d41_1.equals(other.d41_1))
      return false;
    if (!this.e41_1.equals(other.e41_1))
      return false;
    if (!this.m2().equals(other.m2()))
      return false;
    return true;
  };
  protoOf(ImageIdentification).hashCode = function () {
    var result = this.d41_1.hashCode();
    result = imul(31, result) + this.e41_1.hashCode() | 0;
    result = imul(31, result) + this.m2().hashCode() | 0;
    return result;
  };
  function ImageData(image, name) {
    this.g3z_1 = image;
    this.h3z_1 = name;
  }
  protoOf(ImageData).toString = function () {
    return 'ImageData(image=' + toString(this.g3z_1) + ', name=' + this.h3z_1.toString() + ')';
  };
  protoOf(ImageData).hashCode = function () {
    var result = hashCode(this.g3z_1);
    result = imul(result, 31) + this.h3z_1.hashCode() | 0;
    return result;
  };
  protoOf(ImageData).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof ImageData))
      return false;
    if (!equals(this.g3z_1, other.g3z_1))
      return false;
    if (!this.h3z_1.equals(other.h3z_1))
      return false;
    return true;
  };
  function _get_polyline__sh9y4r($this) {
    var tmp = ensureNotNull(ensureNotNull($this.h3h_1).u3b().o3b($this.m41_1)).d3b();
    return tmp instanceof PolylineComponent ? tmp : THROW_CCE();
  }
  function AddPolylinePointCommand(editor, polylineId, index, location) {
    AbstractCommand.call(this, 'edit.model.polyline.addPoint', editor);
    this.m41_1 = polylineId;
    this.n41_1 = index;
    this.o41_1 = location;
  }
  protoOf(AddPolylinePointCommand).i3a = function () {
    _get_polyline__sh9y4r(this).z2q(this.n41_1, this.o41_1.kn_1, this.o41_1.ln_1);
  };
  protoOf(AddPolylinePointCommand).m3a = function () {
    _get_polyline__sh9y4r(this).a2r(this.n41_1);
  };
  function CompactablePolyline_init_$Init$($this) {
    // Inline function 'kotlin.collections.listOf' call
    var tmp$ret$0 = emptyList();
    CompactablePolyline.call($this, tmp$ret$0);
    return $this;
  }
  function CompactablePolyline_init_$Create$() {
    return CompactablePolyline_init_$Init$(objectCreate(protoOf(CompactablePolyline)));
  }
  function Companion_15() {
    this.c42_1 = 0.1;
  }
  var Companion_instance_20;
  function Companion_getInstance_25() {
    return Companion_instance_20;
  }
  function updateBoundingBox_0($this) {
    if ($this.d42_1.o() > 0) {
      $this.e42_1.i1c($this.d42_1.l(0).kn_1, $this.d42_1.l(0).ln_1, 1.0, 1.0);
    }
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = $this.d42_1.i();
    while (_iterator__ex2g4s.j()) {
      var element = _iterator__ex2g4s.k();
      $this.e42_1.eo(element);
    }
    $this.e42_1.i1c($this.e42_1.u1h_1, $this.e42_1.v1h_1, $this.e42_1.w1h_1, $this.e42_1.x1h_1);
  }
  function canCompactPoint($this, i) {
    if ($this.d42_1.l(i).equals($this.d42_1.l(i - 1 | 0))) {
      return true;
    }
    if (i > ($this.d42_1.o() - 2 | 0)) {
      return false;
    }
    var angle1 = Geometry_instance.q1g(Companion_getInstance().w1a_1, Geometry_instance.s1g($this.d42_1.l(i - 1 | 0).kn_1, $this.d42_1.l(i - 1 | 0).ln_1, $this.d42_1.l(i).kn_1, $this.d42_1.l(i).ln_1));
    var angle2 = Geometry_instance.q1g(Companion_getInstance().w1a_1, Geometry_instance.s1g($this.d42_1.l(i).kn_1, $this.z3q().l(i).ln_1, $this.d42_1.l(i + 1 | 0).kn_1, $this.d42_1.l(i + 1 | 0).ln_1));
    var tmp;
    // Inline function 'kotlin.math.abs' call
    var x = angle1 - angle2;
    if (Math.abs(x) <= 0.1) {
      tmp = true;
    } else {
      // Inline function 'kotlin.math.abs' call
      var x_0 = angle1 - angle2;
      // Inline function 'kotlin.math.abs' call
      var x_1 = Math.abs(x_0) - 3.141592653589793;
      tmp = Math.abs(x_1) < 0.1;
    }
    return tmp;
  }
  function isSegmentHorizontal($this, index) {
    return Geometry_instance.n1g($this.d42_1.l(index).ln_1, $this.d42_1.l(index + 1 | 0).ln_1);
  }
  function isSegmentVertical($this, index) {
    return Geometry_instance.n1g($this.d42_1.l(index).kn_1, $this.d42_1.l(index + 1 | 0).kn_1);
  }
  function isSegmentOrthogonal($this, index) {
    return isSegmentHorizontal($this, index) || isSegmentVertical($this, index);
  }
  function CompactablePolyline(points) {
    var tmp = this;
    // Inline function 'kotlin.collections.mutableListOf' call
    tmp.d42_1 = ArrayList_init_$Create$_0();
    this.e42_1 = new Rectangle2D();
    this.f42(points);
  }
  protoOf(CompactablePolyline).z3q = function () {
    return this.d42_1;
  };
  protoOf(CompactablePolyline).o = function () {
    return this.d42_1.o();
  };
  protoOf(CompactablePolyline).fo = function () {
    return Rectangle2D_init_$Create$(this.e42_1);
  };
  protoOf(CompactablePolyline).g42 = function () {
    return this.o() < 2 || this.d42_1.l(0).equals(this.d42_1.l(1));
  };
  protoOf(CompactablePolyline).h42 = function () {
    var tmp;
    if (!this.g42()) {
      var tmp0 = until(0, this.o() - 1 | 0);
      var tmp$ret$0;
      $l$block_0: {
        // Inline function 'kotlin.collections.all' call
        var tmp_0;
        if (isInterface(tmp0, Collection)) {
          tmp_0 = tmp0.m();
        } else {
          tmp_0 = false;
        }
        if (tmp_0) {
          tmp$ret$0 = true;
          break $l$block_0;
        }
        var inductionVariable = tmp0.y_1;
        var last = tmp0.z_1;
        if (inductionVariable <= last)
          do {
            var element = inductionVariable;
            inductionVariable = inductionVariable + 1 | 0;
            var it = element;
            if (!isSegmentOrthogonal(this, it)) {
              tmp$ret$0 = false;
              break $l$block_0;
            }
          }
           while (!(element === last));
        tmp$ret$0 = true;
      }
      tmp = tmp$ret$0;
    } else {
      tmp = false;
    }
    return tmp;
  };
  protoOf(CompactablePolyline).toString = function () {
    var s = StringBuilder_init_$Create$();
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = this.d42_1.i();
    while (_iterator__ex2g4s.j()) {
      var element = _iterator__ex2g4s.k();
      s.i7('(' + element.kn_1 + ',' + element.ln_1 + ')');
    }
    return s.toString();
  };
  protoOf(CompactablePolyline).eo = function (point) {
    this.f42(listOf(point));
    return this;
  };
  protoOf(CompactablePolyline).f42 = function (points) {
    // Inline function 'kotlin.collections.isNotEmpty' call
    if (!points.m()) {
      this.d42_1.f1(points);
      this.i42();
      updateBoundingBox_0(this);
    }
    return this;
  };
  protoOf(CompactablePolyline).l = function (index) {
    return this.d42_1.l(index);
  };
  protoOf(CompactablePolyline).j42 = function (segmentIndex) {
    if (this.g42()) {
      return null;
    }
    return Companion_getInstance_1().q1f(this.d42_1.l(segmentIndex), this.d42_1.l(segmentIndex + 1 | 0));
  };
  protoOf(CompactablePolyline).i42 = function () {
    if (this.d42_1.o() <= 2) {
      return Unit_instance;
    }
    var i = 1;
    while (i < this.d42_1.o()) {
      if (canCompactPoint(this, i)) {
        this.d42_1.h3(i);
      } else {
        i = i + 1 | 0;
      }
    }
  };
  function EditModelPolylineModule$initialize$lambda(it) {
    return new PolylineReplaceSelectionModel(it instanceof PolylineComponent ? it : THROW_CCE());
  }
  function EditModelPolylineModule() {
    EditModelPolylineModule_instance = this;
    AbstractModule.call(this);
  }
  protoOf(EditModelPolylineModule).to = function () {
    var tmp = EditSelectModule_getInstance().t3l_1;
    var tmp_0 = SelectionDrawingStrategy_ABOVE_getInstance();
    var tmp_1 = getKClass(PolylineComponent);
    tmp.o3v(tmp_0, tmp_1, EditModelPolylineModule$initialize$lambda);
  };
  var EditModelPolylineModule_instance;
  function EditModelPolylineModule_getInstance() {
    if (EditModelPolylineModule_instance == null)
      new EditModelPolylineModule();
    return EditModelPolylineModule_instance;
  }
  function _get_polyline__sh9y4r_0($this) {
    var tmp = ensureNotNull(ensureNotNull($this.h3h_1).u3b().o3b($this.o42_1)).d3b();
    return tmp instanceof PolylineComponent ? tmp : THROW_CCE();
  }
  function JoinPolylinePointsCommand(editor, polylineId, index, oldLocation) {
    AbstractCommand.call(this, 'edit.model.polyline.joinPoints', editor);
    this.o42_1 = polylineId;
    this.p42_1 = index;
    this.q42_1 = oldLocation;
  }
  protoOf(JoinPolylinePointsCommand).i3a = function () {
    _get_polyline__sh9y4r_0(this).a2r(this.p42_1);
  };
  protoOf(JoinPolylinePointsCommand).m3a = function () {
    _get_polyline__sh9y4r_0(this).z2q(this.p42_1, this.q42_1.kn_1, this.q42_1.ln_1);
  };
  function Companion_16() {
  }
  protoOf(Companion_16).r42 = function (editor, polyline, index, oldLocation) {
    return new MovePolylinePointCommand(editor, polyline.cv(), index, oldLocation, polyline.u2k(index));
  };
  var Companion_instance_21;
  function Companion_getInstance_26() {
    return Companion_instance_21;
  }
  function _get_polyline__sh9y4r_1($this) {
    var tmp = ensureNotNull(ensureNotNull($this.h3h_1).u3b().o3b($this.v42_1)).d3b();
    return tmp instanceof PolylineComponent ? tmp : THROW_CCE();
  }
  function MovePolylinePointCommand(editor, polylineId, index, oldLocation, newLocation) {
    AbstractCommand.call(this, 'edit.model.polyline.movePoint', editor);
    this.v42_1 = polylineId;
    this.w42_1 = index;
    this.x42_1 = oldLocation;
    this.y42_1 = newLocation;
  }
  protoOf(MovePolylinePointCommand).i3a = function () {
    _get_polyline__sh9y4r_1(this).d2r(this.w42_1, this.y42_1.kn_1, this.y42_1.ln_1);
  };
  protoOf(MovePolylinePointCommand).m3a = function () {
    _get_polyline__sh9y4r_1(this).d2r(this.w42_1, this.x42_1.kn_1, this.x42_1.ln_1);
  };
  function Companion_17() {
    Companion_instance_22 = this;
    this.z42_1 = 'draw.property.polyline.arrow';
    this.a43_1 = Translations_getInstance().bn('edit.component.polyline', []);
  }
  var Companion_instance_22;
  function Companion_getInstance_27() {
    if (Companion_instance_22 == null)
      new Companion_17();
    return Companion_instance_22;
  }
  function updateEndLineTerminator($this) {
    if ($this.b42_1) {
      $this.y41_1.w2q(Companion_getInstance_2().i2q());
    } else {
      $this.y41_1.w2q(null);
    }
  }
  function PolylineComponent(polyline) {
    Companion_getInstance_27();
    polyline = polyline === VOID ? new PolylineDrawable() : polyline;
    AbstractComponent.call(this, polyline);
    this.y41_1 = polyline;
    this.z41_1 = false;
    this.a42_1 = false;
    this.b42_1 = false;
    new DrawableOwner(this, this.y41_1);
  }
  protoOf(PolylineComponent).b3r = function (value) {
    if (!(this.z41_1 === value)) {
      this.z41_1 = value;
      if (!this.f38()) {
        this.f2i(this.jw().kn_1);
      }
    }
  };
  protoOf(PolylineComponent).c3r = function (value) {
    if (!(this.a42_1 === value)) {
      this.a42_1 = value;
      if (!this.f38()) {
        this.g2i(this.jw().ln_1);
      }
    }
  };
  protoOf(PolylineComponent).b43 = function (value) {
    if (!(this.b42_1 === value)) {
      this.i20();
      this.b42_1 = value;
      updateEndLineTerminator(this);
      this.i20();
      this.l20();
    }
  };
  protoOf(PolylineComponent).v20 = function (value) {
    this.y41_1.v20(value);
  };
  protoOf(PolylineComponent).jw = function () {
    return this.y41_1.jw();
  };
  protoOf(PolylineComponent).a2i = function (value) {
    this.y41_1.a2i(value);
  };
  protoOf(PolylineComponent).d2i = function () {
    return this.y41_1.d2i();
  };
  protoOf(PolylineComponent).fo = function () {
    var bb = this.y41_1.fo();
    var tmp;
    if (this.i2d()) {
      tmp = isInterface(bb, MutableRectangularShape);
    } else {
      tmp = false;
    }
    if (tmp) {
      DropShadow_instance.m2n(bb, this.w20());
    }
    return bb;
  };
  protoOf(PolylineComponent).h20 = function (context) {
    this.y41_1.h20(context);
  };
  protoOf(PolylineComponent).go = function (x, y) {
    return this.y41_1.go(x, y);
  };
  protoOf(PolylineComponent).f2i = function (x) {
    this.y41_1.f2i(x);
  };
  protoOf(PolylineComponent).g2i = function (y) {
    this.y41_1.g2i(y);
  };
  protoOf(PolylineComponent).k1a = function () {
    return Companion_getInstance_27().a43_1;
  };
  protoOf(PolylineComponent).f3b = function () {
    return SelectionDrawingStrategy_ABOVE_getInstance();
  };
  protoOf(PolylineComponent).j3b = function () {
    if (this.t2k() > 0) {
      // Inline function 'kotlin.arrayOf' call
      // Inline function 'kotlin.js.unsafeCast' call
      // Inline function 'kotlin.js.asDynamic' call
      return [new SnappableXCoordinate(this.y41_1.b2r().kn_1)];
    }
    return protoOf(AbstractComponent).j3b.call(this);
  };
  protoOf(PolylineComponent).k3b = function () {
    if (this.t2k() > 0) {
      // Inline function 'kotlin.arrayOf' call
      // Inline function 'kotlin.js.unsafeCast' call
      // Inline function 'kotlin.js.asDynamic' call
      return [new SnappableYCoordinate(this.y41_1.b2r().ln_1)];
    }
    return protoOf(AbstractComponent).k3b.call(this);
  };
  protoOf(PolylineComponent).h38 = function (writer) {
    protoOf(AbstractComponent).h38.call(this, writer);
    writer.r39('points', this.y41_1.m2r(0, this.y41_1.t2k()));
    if (this.b42_1) {
      writer.o39('arrow', this.b42_1);
    }
    if (this.z41_1) {
      writer.o39('mirrorH', this.z41_1);
    }
    if (this.a42_1) {
      writer.o39('mirrorV', this.a42_1);
    }
  };
  protoOf(PolylineComponent).i38 = function (reader) {
    protoOf(AbstractComponent).i38.call(this, reader);
    this.y41_1.e2r(reader.w38('points'));
    if (reader.t35('arrow')) {
      this.b43(reader.t38('arrow'));
    }
    if (reader.t35('mirrorH')) {
      this.b3r(reader.t38('mirrorH'));
    }
    if (reader.t35('mirrorV')) {
      this.c3r(reader.t38('mirrorV'));
    }
  };
  protoOf(PolylineComponent).y2q = function () {
    return this.y41_1.y2q();
  };
  protoOf(PolylineComponent).a2 = function () {
    this.y41_1.a2();
  };
  protoOf(PolylineComponent).z2q = function (index, x, y) {
    return this.y41_1.z2q(index, x, y);
  };
  protoOf(PolylineComponent).a2r = function (index) {
    return this.y41_1.a2r(index);
  };
  protoOf(PolylineComponent).u2k = function (index) {
    return this.y41_1.u2k(index);
  };
  protoOf(PolylineComponent).b2r = function () {
    return this.y41_1.b2r();
  };
  protoOf(PolylineComponent).c2r = function () {
    return this.y41_1.c2r();
  };
  protoOf(PolylineComponent).d2r = function (index, x, y) {
    return this.y41_1.d2r(index, x, y);
  };
  protoOf(PolylineComponent).e2r = function (points) {
    return this.y41_1.e2r(points);
  };
  protoOf(PolylineComponent).f2r = function (x, y) {
    return this.y41_1.f2r(x, y);
  };
  protoOf(PolylineComponent).g2r = function (x, y, area) {
    return this.y41_1.g2r(x, y, area);
  };
  protoOf(PolylineComponent).i2r = function (x, y, area) {
    return this.y41_1.i2r(x, y, area);
  };
  protoOf(PolylineComponent).j2r = function (index) {
    return this.y41_1.j2r(index);
  };
  protoOf(PolylineComponent).k2r = function () {
    return this.y41_1.k2r();
  };
  protoOf(PolylineComponent).l2r = function (index) {
    return this.y41_1.l2r(index);
  };
  protoOf(PolylineComponent).m2r = function (startIndex, endIndex) {
    return this.y41_1.m2r(startIndex, endIndex);
  };
  protoOf(PolylineComponent).n2r = function (index) {
    return this.y41_1.n2r(index);
  };
  protoOf(PolylineComponent).o2r = function (index) {
    return this.y41_1.o2r(index);
  };
  protoOf(PolylineComponent).p2r = function (index) {
    return this.y41_1.p2r(index);
  };
  protoOf(PolylineComponent).q2r = function (index, otherIndex, other) {
    return this.y41_1.q2r(index, otherIndex, other);
  };
  protoOf(PolylineComponent).r2r = function (otherIndex, other) {
    return this.y41_1.r2r(otherIndex, other);
  };
  protoOf(PolylineComponent).t2k = function () {
    return this.y41_1.t2k();
  };
  protoOf(PolylineComponent).u2q = function (_set____db54di) {
    this.y41_1.u2q(_set____db54di);
  };
  protoOf(PolylineComponent).v2q = function () {
    return this.y41_1.v2q();
  };
  protoOf(PolylineComponent).w2q = function (_set____db54di) {
    this.y41_1.w2q(_set____db54di);
  };
  protoOf(PolylineComponent).x2q = function () {
    return this.y41_1.x2q();
  };
  protoOf(PolylineComponent).a = function () {
    return this.y41_1.a();
  };
  function _get_LOG__e5r759_5($this) {
    var tmp0 = $this.c43_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('LOG', 1, tmp, PolylineHandleSelectionModel$Companion$_get_LOG_$ref_mrpayj(), null);
    return tmp0.j2();
  }
  function PolylineHandleSelectionModel$Companion$_get_LOG_$ref_mrpayj() {
    return function (p0) {
      return _get_LOG__e5r759_5(p0);
    };
  }
  function Companion_18() {
    Companion_instance_23 = this;
    this.c43_1 = logger(getKClass(PolylineHandleSelectionModel));
  }
  var Companion_instance_23;
  function Companion_getInstance_28() {
    if (Companion_instance_23 == null)
      new Companion_18();
    return Companion_instance_23;
  }
  function createHandles_0($this) {
    $this.q3r();
    var inductionVariable = 0;
    var last = $this.t3s().t2k();
    if (inductionVariable < last)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        $this.d3s(new RectangularHandle($this.n43_1));
      }
       while (inductionVariable < last);
    $this.n3r_1 = $this.t3s().t2k();
  }
  function PolylineEventHandler($outer) {
    this.t43_1 = $outer;
    EventHandler.call(this, $outer);
    this.r43_1 = Companion_getInstance().w1a_1;
    this.s43_1 = 0;
  }
  protoOf(PolylineEventHandler).j3s = function (view) {
    var index = this.t43_1.n3s(ensureNotNull(this.l3s_1));
    this.r43_1 = Point2D_init_$Create$(this.t43_1.t3s().u2k(index));
    this.s43_1 = this.t43_1.t3s().t2k();
  };
  protoOf(PolylineEventHandler).u3s = function (context) {
    var index = this.t43_1.n3s(ensureNotNull(this.l3s_1));
    this.t43_1.t3s().k2r();
    var tmp;
    if (!(this.t43_1.t3s().t2k() === this.s43_1)) {
      _get_LOG__e5r759_5(Companion_getInstance_28()).kl('Join point ' + index + ' of polyline ' + this.t43_1.t3s().cv() + ' at ' + this.r43_1.toString());
      tmp = new JoinPolylinePointsCommand(context.w3c_1, this.t43_1.t3s().cv(), index, this.r43_1);
    } else {
      _get_LOG__e5r759_5(Companion_getInstance_28()).kl('Move point ' + index + ' of polyline ' + this.t43_1.t3s().cv() + ' to ' + this.r43_1.toString());
      tmp = Companion_instance_21.r42(context.w3c_1, this.t43_1.t3s(), index, this.r43_1);
    }
    var command = tmp;
    context.w3c_1.d3d().u3a(command);
  };
  protoOf(PolylineEventHandler).u43 = function (context) {
    var tmp1_safe_receiver = context.o22_1;
    if ((tmp1_safe_receiver == null ? null : tmp1_safe_receiver.s1a()) === 2) {
      var tmp0_safe_receiver = this.t43_1.t3s().g2r(context.q22_1, context.r22_1, 10);
      if (tmp0_safe_receiver == null)
        null;
      else {
        // Inline function 'kotlin.let' call
        _get_LOG__e5r759_5(Companion_getInstance_28()).ql('Add handle ' + tmp0_safe_receiver);
        var snap = context.w3c_1.b3d().v43(context.q22_1, context.r22_1);
        var location = snap.eo(context.t22_1);
        _get_LOG__e5r759_5(Companion_getInstance_28()).kl('Add point ' + (tmp0_safe_receiver + 1 | 0) + ' to polyline ' + this.t43_1.t3s().cv() + ' at ' + location.toString());
        context.w3c_1.d3d().t3a(new AddPolylinePointCommand(context.w3c_1, this.t43_1.t3s().cv(), tmp0_safe_receiver + 1 | 0, location));
      }
    }
    return null;
  };
  protoOf(PolylineEventHandler).y22 = function (context) {
    return this.u43(context instanceof EditInputEventContext ? context : THROW_CCE());
  };
  function PolylinePointInputEventHandler($outer) {
    this.x43_1 = $outer;
    InputEventHandlerAdapter.call(this);
  }
  protoOf(PolylinePointInputEventHandler).x3s = function (context) {
    context.n22_1.l1y(Cursor_CROSSHAIR_getInstance());
    return this;
  };
  protoOf(PolylinePointInputEventHandler).z22 = function (context) {
    return this.x3s(context instanceof EditInputEventContext ? context : THROW_CCE());
  };
  protoOf(PolylinePointInputEventHandler).z3s = function (context) {
    var tmp = this.x43_1.t3s();
    var tmp_0 = this.x43_1.d3t();
    tmp.d2r(this.x43_1.n3s(ensureNotNull((tmp_0 instanceof PolylineEventHandler ? tmp_0 : THROW_CCE()).l3s_1)), context.q22_1, context.r22_1);
    return this;
  };
  protoOf(PolylinePointInputEventHandler).b23 = function (context) {
    return this.z3s(context instanceof EditInputEventContext ? context : THROW_CCE());
  };
  function PolylineHandleSelectionModel(c) {
    Companion_getInstance_28();
    AbstractHandleSelectionModel.call(this, c);
    this.n43_1 = new PolylinePointInputEventHandler(this);
  }
  protoOf(PolylineHandleSelectionModel).e3t = function () {
    return new PolylineEventHandler(this);
  };
  protoOf(PolylineHandleSelectionModel).r3r = function () {
    return this.t3s().t2k();
  };
  protoOf(PolylineHandleSelectionModel).f3t = function () {
    if (!(this.n3r_1 === this.r3r())) {
      createHandles_0(this);
    }
    var inductionVariable = 0;
    var last = this.t3s().t2k();
    if (inductionVariable < last)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        this.g3t(i).y43(this.t3s().u2k(i).kn_1, this.t3s().u2k(i).ln_1);
      }
       while (inductionVariable < last);
  };
  function PolylineReplaceSelectionModel(component) {
    AbstractSelectedColorWrappingSelectionModel.call(this, component);
  }
  protoOf(PolylineReplaceSelectionModel).h44 = function (component) {
    return new PolylineHandleSelectionModel(component);
  };
  protoOf(PolylineReplaceSelectionModel).z3u = function (component) {
    return this.h44(component instanceof PolylineComponent ? component : THROW_CCE());
  };
  function Companion_19() {
  }
  protoOf(Companion_19).i44 = function (c, shape) {
    var bb = Rectangle2D_init_$Create$(shape.fo());
    var lw = c.l1u().f1u_1;
    bb.i1c(bb.u1h_1 - lw, bb.v1h_1 - lw, bb.w1h_1 + 2 * lw, bb.x1h_1 + 2 * lw);
    if (c.i2d()) {
      DropShadow_instance.m2n(bb, c.w20());
    }
    return bb;
  };
  var Companion_instance_24;
  function Companion_getInstance_29() {
    return Companion_instance_24;
  }
  function AbstractRectangularComponent(styleType, styleProvider, shape) {
    styleType = styleType === VOID ? Companion_getInstance_0().b1y_1 : styleType;
    styleProvider = styleProvider === VOID ? DrawStyleModule_getInstance().w1x_1 : styleProvider;
    shape = shape === VOID ? new Rectangle2D() : shape;
    AbstractComponent_init_$Init$(styleProvider, styleType, this);
    this.f3z_1 = shape;
  }
  protoOf(AbstractRectangularComponent).b41 = function () {
    return this.f3z_1;
  };
  protoOf(AbstractRectangularComponent).p40 = function () {
    return false;
  };
  protoOf(AbstractRectangularComponent).a41 = function (context) {
  };
  protoOf(AbstractRectangularComponent).i1c = function (x, y, width, height) {
    this.i20();
    this.f3z_1.i1c(x, y, width, height);
    this.i20();
    this.l20();
  };
  protoOf(AbstractRectangularComponent).m1c = function (rect) {
    this.i1c(rect.p1a(), rect.q1a(), rect.f1c(), rect.h1c());
  };
  protoOf(AbstractRectangularComponent).v20 = function (value) {
    this.i1c(value.kn_1, value.ln_1, this.f1c(), this.h1c());
  };
  protoOf(AbstractRectangularComponent).jw = function () {
    return new Point2D(this.p1a(), this.q1a());
  };
  protoOf(AbstractRectangularComponent).fo = function () {
    return Companion_instance_24.i44(this, this.f3z_1);
  };
  protoOf(AbstractRectangularComponent).go = function (x, y) {
    return this.f3z_1.go(x, y);
  };
  protoOf(AbstractRectangularComponent).po = function (p) {
    return this.f3z_1.po(p);
  };
  protoOf(AbstractRectangularComponent).ro = function (rect) {
    return this.f3z_1.ro(rect);
  };
  protoOf(AbstractRectangularComponent).f2i = function (x) {
    this.i1c((new Point2D(this.p1a() + this.f1c(), this.q1a())).g1h(x).kn_1, this.q1a(), this.f1c(), this.h1c());
  };
  protoOf(AbstractRectangularComponent).g2i = function (y) {
    this.i1c(this.p1a(), (new Point2D(this.p1a(), this.q1a() + this.h1c())).h1h(y).ln_1, this.f1c(), this.h1c());
  };
  protoOf(AbstractRectangularComponent).j3b = function () {
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [new SnappableXCoordinate(this.z1c()), new SnappableXCoordinate(this.x1c()), new SnappableXCoordinate(this.b1d())];
  };
  protoOf(AbstractRectangularComponent).k3b = function () {
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [new SnappableYCoordinate(this.a1d()), new SnappableYCoordinate(this.y1c()), new SnappableYCoordinate(this.c1d())];
  };
  protoOf(AbstractRectangularComponent).h38 = function (writer) {
    protoOf(AbstractComponent).h38.call(this, writer);
    writer.k39('x', this.p1a());
    writer.k39('y', this.q1a());
    writer.k39('w', this.f1c());
    writer.k39('h', this.h1c());
  };
  protoOf(AbstractRectangularComponent).i38 = function (reader) {
    protoOf(AbstractComponent).i38.call(this, reader);
    this.i1c(reader.q38('x'), reader.q38('y'), reader.q38('w'), reader.q38('h'));
  };
  protoOf(AbstractRectangularComponent).l1c = function (v) {
    return this.f3z_1.l1c(v);
  };
  protoOf(AbstractRectangularComponent).ho = function (x, y, width, height) {
    return this.f3z_1.ho(x, y, width, height);
  };
  protoOf(AbstractRectangularComponent).qo = function (rect) {
    return this.f3z_1.qo(rect);
  };
  protoOf(AbstractRectangularComponent).io = function (x, y, w, h) {
    return this.f3z_1.io(x, y, w, h);
  };
  protoOf(AbstractRectangularComponent).vn = function (x, y) {
    return this.f3z_1.vn(x, y);
  };
  protoOf(AbstractRectangularComponent).n1c = function (rect) {
    return this.f3z_1.n1c(rect);
  };
  protoOf(AbstractRectangularComponent).o1c = function (deltaX, deltaY) {
    return this.f3z_1.o1c(deltaX, deltaY);
  };
  protoOf(AbstractRectangularComponent).p1c = function (delta) {
    return this.f3z_1.p1c(delta);
  };
  protoOf(AbstractRectangularComponent).q1c = function (topY, leftX, bottomY, rightX) {
    return this.f3z_1.q1c(topY, leftX, bottomY, rightX);
  };
  protoOf(AbstractRectangularComponent).p1a = function () {
    return this.f3z_1.p1a();
  };
  protoOf(AbstractRectangularComponent).q1a = function () {
    return this.f3z_1.q1a();
  };
  protoOf(AbstractRectangularComponent).f1c = function () {
    return this.f3z_1.f1c();
  };
  protoOf(AbstractRectangularComponent).h1c = function () {
    return this.f3z_1.h1c();
  };
  protoOf(AbstractRectangularComponent).s1c = function () {
    return this.f3z_1.s1c();
  };
  protoOf(AbstractRectangularComponent).t1c = function () {
    return this.f3z_1.t1c();
  };
  protoOf(AbstractRectangularComponent).u1c = function () {
    return this.f3z_1.u1c();
  };
  protoOf(AbstractRectangularComponent).v1c = function () {
    return this.f3z_1.v1c();
  };
  protoOf(AbstractRectangularComponent).w1c = function () {
    return this.f3z_1.w1c();
  };
  protoOf(AbstractRectangularComponent).qv = function () {
    return this.f3z_1.qv();
  };
  protoOf(AbstractRectangularComponent).x1c = function () {
    return this.f3z_1.x1c();
  };
  protoOf(AbstractRectangularComponent).y1c = function () {
    return this.f3z_1.y1c();
  };
  protoOf(AbstractRectangularComponent).z1c = function () {
    return this.f3z_1.z1c();
  };
  protoOf(AbstractRectangularComponent).a1d = function () {
    return this.f3z_1.a1d();
  };
  protoOf(AbstractRectangularComponent).b1d = function () {
    return this.f3z_1.b1d();
  };
  protoOf(AbstractRectangularComponent).c1d = function () {
    return this.f3z_1.c1d();
  };
  protoOf(AbstractRectangularComponent).d1d = function () {
    return this.f3z_1.d1d();
  };
  protoOf(AbstractRectangularComponent).e1d = function () {
    return this.f3z_1.e1d();
  };
  protoOf(AbstractRectangularComponent).f1d = function () {
    return this.f3z_1.f1d();
  };
  protoOf(AbstractRectangularComponent).g1d = function () {
    return this.f3z_1.g1d();
  };
  protoOf(AbstractRectangularComponent).h1d = function () {
    return this.f3z_1.h1d();
  };
  function EditModelRectangleModule$initialize$lambda(it) {
    return new RectangularBelowSelectionModel(it instanceof AbstractRectangularComponent ? it : THROW_CCE());
  }
  function EditModelRectangleModule$initialize$lambda_0(it) {
    return new RectangularHandleSelectionModel(it instanceof AbstractRectangularComponent ? it : THROW_CCE());
  }
  function EditModelRectangleModule$initialize$lambda_1(it) {
    return new RectangularReplaceSelectionModel(it instanceof AbstractRectangularComponent ? it : THROW_CCE());
  }
  function EditModelRectangleModule$initialize$lambda_2(it) {
    return new RectangularBelowSelectionModel(it instanceof AbstractRectangularComponent ? it : THROW_CCE());
  }
  function EditModelRectangleModule$initialize$lambda_3(it) {
    return new RectangularHandleSelectionModel(it instanceof AbstractRectangularComponent ? it : THROW_CCE());
  }
  function EditModelRectangleModule$initialize$lambda_4(it) {
    return new RectangularReplaceSelectionModel(it instanceof AbstractRectangularComponent ? it : THROW_CCE());
  }
  function EditModelRectangleModule$initialize$lambda_5(it) {
    return new RectangularBelowSelectionModel(it instanceof AbstractRectangularComponent ? it : THROW_CCE());
  }
  function EditModelRectangleModule$initialize$lambda_6(it) {
    return new RectangularHandleSelectionModel(it instanceof AbstractRectangularComponent ? it : THROW_CCE());
  }
  function EditModelRectangleModule$initialize$lambda_7(it) {
    return new RectangularReplaceSelectionModel(it instanceof AbstractRectangularComponent ? it : THROW_CCE());
  }
  function EditModelRectangleModule$initialize$lambda_8(it) {
    return new RectangularBelowSelectionModel(it instanceof AbstractRectangularComponent ? it : THROW_CCE());
  }
  function EditModelRectangleModule$initialize$lambda_9(it) {
    return new RectangularReplaceSelectionModel(it instanceof AbstractRectangularComponent ? it : THROW_CCE());
  }
  function EditModelRectangleModule$initialize$lambda_10(it) {
    return new RectangularHandleSelectionModel(it instanceof AbstractRectangularComponent ? it : THROW_CCE());
  }
  function EditModelRectangleModule() {
    EditModelRectangleModule_instance = this;
    AbstractModule.call(this);
  }
  protoOf(EditModelRectangleModule).to = function () {
    var tmp = EditSelectModule_getInstance().t3l_1;
    var tmp_0 = SelectionDrawingStrategy_BELOW_getInstance();
    var tmp_1 = getKClass(RectangleComponent);
    tmp.o3v(tmp_0, tmp_1, EditModelRectangleModule$initialize$lambda);
    var tmp_2 = EditSelectModule_getInstance().t3l_1;
    var tmp_3 = SelectionDrawingStrategy_ABOVE_getInstance();
    var tmp_4 = getKClass(RectangleComponent);
    tmp_2.o3v(tmp_3, tmp_4, EditModelRectangleModule$initialize$lambda_0);
    var tmp_5 = EditSelectModule_getInstance().t3l_1;
    var tmp_6 = SelectionDrawingStrategy_REPLACE_getInstance();
    var tmp_7 = getKClass(RectangleComponent);
    tmp_5.o3v(tmp_6, tmp_7, EditModelRectangleModule$initialize$lambda_1);
    var tmp_8 = EditSelectModule_getInstance().t3l_1;
    var tmp_9 = SelectionDrawingStrategy_BELOW_getInstance();
    var tmp_10 = getKClass(EllipseComponent);
    tmp_8.o3v(tmp_9, tmp_10, EditModelRectangleModule$initialize$lambda_2);
    var tmp_11 = EditSelectModule_getInstance().t3l_1;
    var tmp_12 = SelectionDrawingStrategy_ABOVE_getInstance();
    var tmp_13 = getKClass(EllipseComponent);
    tmp_11.o3v(tmp_12, tmp_13, EditModelRectangleModule$initialize$lambda_3);
    var tmp_14 = EditSelectModule_getInstance().t3l_1;
    var tmp_15 = SelectionDrawingStrategy_REPLACE_getInstance();
    var tmp_16 = getKClass(EllipseComponent);
    tmp_14.o3v(tmp_15, tmp_16, EditModelRectangleModule$initialize$lambda_4);
    var tmp_17 = EditSelectModule_getInstance().t3l_1;
    var tmp_18 = SelectionDrawingStrategy_BELOW_getInstance();
    var tmp_19 = getKClass(RoundRectangleComponent);
    tmp_17.o3v(tmp_18, tmp_19, EditModelRectangleModule$initialize$lambda_5);
    var tmp_20 = EditSelectModule_getInstance().t3l_1;
    var tmp_21 = SelectionDrawingStrategy_ABOVE_getInstance();
    var tmp_22 = getKClass(RoundRectangleComponent);
    tmp_20.o3v(tmp_21, tmp_22, EditModelRectangleModule$initialize$lambda_6);
    var tmp_23 = EditSelectModule_getInstance().t3l_1;
    var tmp_24 = SelectionDrawingStrategy_REPLACE_getInstance();
    var tmp_25 = getKClass(RoundRectangleComponent);
    tmp_23.o3v(tmp_24, tmp_25, EditModelRectangleModule$initialize$lambda_7);
    var tmp_26 = EditSelectModule_getInstance().t3l_1;
    var tmp_27 = SelectionDrawingStrategy_BELOW_getInstance();
    var tmp_28 = getKClass(ImageComponent);
    tmp_26.o3v(tmp_27, tmp_28, EditModelRectangleModule$initialize$lambda_8);
    var tmp_29 = EditSelectModule_getInstance().t3l_1;
    var tmp_30 = SelectionDrawingStrategy_REPLACE_getInstance();
    var tmp_31 = getKClass(ImageComponent);
    tmp_29.o3v(tmp_30, tmp_31, EditModelRectangleModule$initialize$lambda_9);
    var tmp_32 = EditSelectModule_getInstance().t3l_1;
    var tmp_33 = SelectionDrawingStrategy_ABOVE_getInstance();
    var tmp_34 = getKClass(ImageComponent);
    tmp_32.o3v(tmp_33, tmp_34, EditModelRectangleModule$initialize$lambda_10);
  };
  var EditModelRectangleModule_instance;
  function EditModelRectangleModule_getInstance() {
    if (EditModelRectangleModule_instance == null)
      new EditModelRectangleModule();
    return EditModelRectangleModule_instance;
  }
  function Companion_20() {
    Companion_instance_25 = this;
    this.k44_1 = 5;
    this.l44_1 = 10;
    this.m44_1 = new Stroke(10);
  }
  var Companion_instance_25;
  function Companion_getInstance_30() {
    if (Companion_instance_25 == null)
      new Companion_20();
    return Companion_instance_25;
  }
  function RectangularBelowSelectionModel(component) {
    Companion_getInstance_30();
    AbstractSelectionModel.call(this, component);
    this.s44_1 = new Rectangle2D();
  }
  protoOf(RectangularBelowSelectionModel).fo = function () {
    return new Rectangle2D(this.s44_1.u1h_1 - 5 - 1, this.s44_1.v1h_1 - 5 - 1, this.s44_1.w1h_1 + 10 + 1, this.s44_1.x1h_1 + 10 + 1);
  };
  protoOf(RectangularBelowSelectionModel).h20 = function (context) {
    context.j1z_1.e1u(Companion_getInstance_30().m44_1);
    context.j1z_1.b1u(Themes_getInstance().h2g().p3y_1.c1u().x1x_1);
    context.j1z_1.j1v(this.s44_1);
  };
  protoOf(RectangularBelowSelectionModel).go = function (x, y) {
    return this.s44_1.go(x, y);
  };
  protoOf(RectangularBelowSelectionModel).j3t = function () {
    this.i20();
    this.s44_1.i1c(this.t3s().f3z_1.p1a(), this.t3s().f3z_1.q1a(), this.t3s().f3z_1.f1c(), this.t3s().f3z_1.h1c());
    this.i20();
    this.k20();
  };
  function Companion_21() {
    this.t44_1 = 10;
  }
  var Companion_instance_26;
  function Companion_getInstance_31() {
    return Companion_instance_26;
  }
  function updateLabelLocation($this) {
    var tmp;
    switch ($this.w40().l2_1) {
      case 2:
        tmp = $this.h1c() - 10;
        break;
      case 1:
        tmp = $this.h1c() / 2;
        break;
      case 0:
        tmp = 10;
        break;
      default:
        noWhenBranchMatchedException();
        break;
    }
    var y = tmp;
    var tmp_0;
    switch ($this.y40().l2_1) {
      case 0:
        tmp_0 = 10;
        break;
      case 1:
        tmp_0 = $this.f1c() / 2;
        break;
      case 2:
        tmp_0 = $this.f1c() - 10;
        break;
      default:
        noWhenBranchMatchedException();
        break;
    }
    var x = tmp_0;
    $this.l18().v20(new Point2D(x, y));
  }
  function RectangularComponent$_get_description_$ref_d7mo81() {
    return function (p0) {
      return p0.mq();
    };
  }
  function RectangularComponent$_set_description_$ref_nbcvql() {
    return function (p0, p1) {
      p0.t40(p1);
      return Unit_instance;
    };
  }
  function RectangularComponent$_get_description_$ref_d7mo81_0() {
    return function (p0) {
      return p0.mq();
    };
  }
  function RectangularComponent$_set_description_$ref_nbcvql_0() {
    return function (p0, p1) {
      p0.t40(p1);
      return Unit_instance;
    };
  }
  function RectangularComponent$drawShadow$lambda($fillColor, this$0, $context, $strokeColor) {
    return function (it) {
      var tmp;
      if (!($fillColor == null)) {
        this$0.s2b($context, this$0.b41(), $context.q1z(Themes_getInstance().h2g().c2g_1).x1x_1);
        tmp = Unit_instance;
      }
      var tmp_0;
      if (!($strokeColor == null)) {
        this$0.t2b($context, this$0.b41(), $context.q1z(Themes_getInstance().h2g().c2g_1).x1x_1, this$0.l1u());
        tmp_0 = Unit_instance;
      }
      return Unit_instance;
    };
  }
  function RectangularComponent(styleType, styleProvider, shape, labelRotation, labelRotationDisplayStrategy) {
    styleType = styleType === VOID ? Companion_getInstance_0().b1y_1 : styleType;
    styleProvider = styleProvider === VOID ? DrawStyleModule_getInstance().w1x_1 : styleProvider;
    labelRotation = labelRotation === VOID ? Rotation_R0_getInstance() : labelRotation;
    labelRotationDisplayStrategy = labelRotationDisplayStrategy === VOID ? RotationDisplayStrategy_IGNORE_getInstance() : labelRotationDisplayStrategy;
    AbstractRectangularComponent.call(this, styleType, styleProvider, shape);
    var tmp = this;
    var tmp0_font = this.b2d();
    tmp.j40_1 = new Label('', tmp0_font, VOID, VOID, VOID, VOID, labelRotationDisplayStrategy, labelRotation);
    this.k40_1 = observableDescription(Description_init_$Create$(''));
    this.l40_1 = new TranslatableText();
    updateLabelLocation(this);
    this.m40_1 = new TransparentImpl(this);
  }
  protoOf(RectangularComponent).l18 = function () {
    return this.j40_1;
  };
  protoOf(RectangularComponent).t40 = function (_set____db54di) {
    var tmp = KMutableProperty1;
    var tmp_0 = RectangularComponent$_get_description_$ref_d7mo81_0();
    return this.k40_1.yf(this, getPropertyCallableRef('description', 1, tmp, tmp_0, RectangularComponent$_set_description_$ref_nbcvql_0()), _set____db54di);
  };
  protoOf(RectangularComponent).mq = function () {
    var tmp = KMutableProperty1;
    var tmp_0 = RectangularComponent$_get_description_$ref_d7mo81();
    return this.k40_1.wf(this, getPropertyCallableRef('description', 1, tmp, tmp_0, RectangularComponent$_set_description_$ref_nbcvql()));
  };
  protoOf(RectangularComponent).u40 = function (value) {
    if (!this.l40_1.equals(value)) {
      this.i20();
      this.l40_1 = value;
      this.l18().o45(this.l40_1.qv() ? '' : this.l40_1.m45());
      this.i20();
      this.l20();
    }
  };
  protoOf(RectangularComponent).v40 = function (value) {
    if (!this.l18().w40().equals(value)) {
      this.i20();
      this.l18().v40(value);
      updateLabelLocation(this);
      this.i20();
    }
  };
  protoOf(RectangularComponent).w40 = function () {
    return this.l18().w40();
  };
  protoOf(RectangularComponent).x40 = function (value) {
    if (!this.l18().y40().equals(value)) {
      this.i20();
      this.l18().x40(value);
      updateLabelLocation(this);
      this.i20();
    }
  };
  protoOf(RectangularComponent).y40 = function () {
    return this.l18().y40();
  };
  protoOf(RectangularComponent).d3n = function (newRotation) {
    protoOf(AbstractRectangularComponent).d3n.call(this, newRotation);
    this.l18().h45_1 = this.w20();
  };
  protoOf(RectangularComponent).a2i = function (value) {
    this.m40_1.a2i(value);
  };
  protoOf(RectangularComponent).d2i = function () {
    return this.m40_1.c2i_1;
  };
  protoOf(RectangularComponent).i1c = function (x, y, width, height) {
    protoOf(AbstractRectangularComponent).i1c.call(this, x, y, width, height);
    updateLabelLocation(this);
  };
  protoOf(RectangularComponent).h38 = function (writer) {
    protoOf(AbstractRectangularComponent).h38.call(this, writer);
    if (!this.l40_1.qv()) {
      writer.h39('text', this.l40_1.p45());
    }
    if (!this.w40().equals(VerticalAlignment_CENTER_getInstance())) {
      writer.m39('vAlign', this.w40().s45_1);
    }
    if (!this.y40().equals(HorizontalAlignment_CENTER_getInstance())) {
      writer.m39('hAlign', this.y40().v45_1);
    }
    this.mq().i41('desc', writer);
  };
  protoOf(RectangularComponent).i38 = function (reader) {
    protoOf(AbstractRectangularComponent).i38.call(this, reader);
    if (reader.t35('text')) {
      this.u40(TranslatableText_init_$Create$(reader.r38('text')));
    }
    if (reader.u35('text')) {
      this.u40(new TranslatableText(reader.n38('text')));
    }
    if (reader.t35('vAlign')) {
      this.v40(Companion_instance_33.h1f(reader.r38('vAlign')));
    }
    if (reader.t35('hAlign')) {
      this.x40(Companion_instance_32.h1f(reader.r38('hAlign')));
    }
    this.t40(Companion_instance_39.x45('desc', reader));
  };
  protoOf(RectangularComponent).fo = function () {
    var tmp = Rectangle2D_init_$Create$(protoOf(AbstractRectangularComponent).fo.call(this)).n1c(Rectangle2D_init_$Create$(this.l18().l45_1).l1c(this.jw()));
    return tmp instanceof Rectangle2D ? tmp : THROW_CCE();
  };
  protoOf(RectangularComponent).h20 = function (context) {
    if (context.m1z_1) {
      this.z40(context, ensureNotNull(context.n1z_1).x1x_1, ensureNotNull(context.n1z_1).y1x_1);
    } else {
      this.z40(context, this.h2d() ? this.m40_1.l2h(this.y2c()) : null, this.f2d() ? this.m40_1.l2h(this.z2c()) : null);
    }
  };
  protoOf(RectangularComponent).z40 = function (context, strokeColor, fillColor) {
    var oldColor = context.j1z_1.c1u();
    this.r40(context, strokeColor, fillColor);
    this.q40(context, strokeColor, fillColor);
    context.j1z_1.b1u(this.m40_1.l2h(this.a2d()));
    this.a41(context);
    DrawModule_getInstance().z2p(this, context);
    context.j1z_1.b1u(oldColor);
  };
  protoOf(RectangularComponent).q40 = function (context, strokeColor, fillColor) {
    this.s2b(context, this.b41(), fillColor);
    this.t2b(context, this.b41(), strokeColor, this.l1u());
  };
  protoOf(RectangularComponent).r40 = function (context, strokeColor, fillColor) {
    if (this.i2d()) {
      var tmp = DropShadow_instance;
      var tmp_0 = this.d2i();
      tmp.l2n(context, tmp_0, RectangularComponent$drawShadow$lambda(fillColor, this, context, strokeColor));
    }
  };
  protoOf(RectangularComponent).a41 = function (context) {
    this.l18().m1u(this.b2d());
    // Inline function 'io.antarescircuit.jabbah.draw.DrawContext.translated' call
    var d = this.jw();
    context.j1z_1.l1d(d.kn_1, d.ln_1);
    this.l18().h20(context);
    context.j1z_1.l1d(-d.kn_1, -d.ln_1);
  };
  protoOf(RectangularComponent).o20 = function (context) {
    if (this.l40_1.y45() && this.l18().po(context.t22_1.j1h(this.jw()))) {
      var tmp0_safe_receiver = this.u2b(null, this.mq().j2(), null);
      var tmp;
      if (tmp0_safe_receiver == null) {
        tmp = null;
      } else {
        // Inline function 'kotlin.let' call
        tmp = new Tooltip(tmp0_safe_receiver, Rectangle2D_init_$Create$(this.l18().l45_1).l1c(this.jw()));
      }
      return tmp;
    }
    return null;
  };
  function Companion_22() {
    Companion_instance_27 = this;
    this.l3n_1 = Translations_getInstance().bn('edit.component.rectangle', []);
  }
  var Companion_instance_27;
  function Companion_getInstance_32() {
    if (Companion_instance_27 == null)
      new Companion_22();
    return Companion_instance_27;
  }
  function RectangleComponent_init_$Init$(x, y, w, h, $this) {
    RectangleComponent.call($this, VOID, VOID, new Rectangle2D(x, y, w, h));
    return $this;
  }
  function RectangleComponent_init_$Create$(x, y, w, h) {
    return RectangleComponent_init_$Init$(x, y, w, h, objectCreate(protoOf(RectangleComponent)));
  }
  function RectangleComponent(styleType, styleProvider, shape) {
    Companion_getInstance_32();
    styleType = styleType === VOID ? Companion_getInstance_0().b1y_1 : styleType;
    styleProvider = styleProvider === VOID ? DrawStyleModule_getInstance().w1x_1 : styleProvider;
    shape = shape === VOID ? new Rectangle2D(0.0, 0.0, 0.0, 0.0) : shape;
    RectangularComponent.call(this, styleType, styleProvider, shape);
  }
  protoOf(RectangleComponent).k1a = function () {
    return Companion_getInstance_32().l3n_1;
  };
  function Companion_23() {
    Companion_instance_28 = this;
    this.n3n_1 = Translations_getInstance().bn('edit.component.ellipse', []);
  }
  var Companion_instance_28;
  function Companion_getInstance_33() {
    if (Companion_instance_28 == null)
      new Companion_23();
    return Companion_instance_28;
  }
  function EllipseComponent(styleType, styleProvider, shape) {
    Companion_getInstance_33();
    styleType = styleType === VOID ? Companion_getInstance_0().b1y_1 : styleType;
    styleProvider = styleProvider === VOID ? DrawStyleModule_getInstance().w1x_1 : styleProvider;
    shape = shape === VOID ? new Ellipse2D(0.0, 0.0, 0.0, 0.0) : shape;
    RectangularComponent.call(this, styleType, styleProvider, shape);
    this.b47_1 = Companion_getInstance_33().n3n_1;
  }
  protoOf(EllipseComponent).k1a = function () {
    return this.b47_1;
  };
  function Companion_24() {
    Companion_instance_29 = this;
    this.c47_1 = Translations_getInstance().bn('edit.component.roundrect', []);
  }
  var Companion_instance_29;
  function Companion_getInstance_34() {
    if (Companion_instance_29 == null)
      new Companion_24();
    return Companion_instance_29;
  }
  function RoundRectangleComponent(styleType, styleProvider, shape) {
    Companion_getInstance_34();
    styleType = styleType === VOID ? Companion_getInstance_0().b1y_1 : styleType;
    styleProvider = styleProvider === VOID ? DrawStyleModule_getInstance().w1x_1 : styleProvider;
    shape = shape === VOID ? new RoundRectangle2D(0.0, 0.0, 0.0, 0.0, 10.0, 10.0) : shape;
    RectangularComponent.call(this, styleType, styleProvider, shape);
  }
  protoOf(RoundRectangleComponent).k1a = function () {
    return Companion_getInstance_34().c47_1;
  };
  function _get_LOG__e5r759_6($this) {
    var tmp0 = $this.r47_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('LOG', 1, tmp, RectangularHandleSelectionModel$Companion$_get_LOG_$ref_ovfwlf(), null);
    return tmp0.j2();
  }
  function RectangularHandleSelectionModel$Companion$_get_LOG_$ref_ovfwlf() {
    return function (p0) {
      return _get_LOG__e5r759_6(p0);
    };
  }
  function Companion_25() {
    Companion_instance_30 = this;
    this.r47_1 = logger(getKClass(RectangularHandleSelectionModel));
  }
  var Companion_instance_30;
  function Companion_getInstance_35() {
    if (Companion_instance_30 == null)
      new Companion_25();
    return Companion_instance_30;
  }
  function reportSize($this) {
    Status_getInstance().fu(StatusType_Small_getInstance(), 'w=' + numberToInt($this.t3s().f1c()) + ', h=' + numberToInt($this.t3s().h1c()));
  }
  function RectangleEventHandler($outer) {
    this.w47_1 = $outer;
    EventHandler.call(this, $outer);
    this.v47_1 = null;
  }
  protoOf(RectangleEventHandler).j3s = function (view) {
    this.v47_1 = Rectangle2D_init_$Create$(this.w47_1.t3s().f3z_1);
    var tmp = this.w47_1;
    var tmp0_safe_receiver = this.v47_1;
    var tmp_0;
    if (tmp0_safe_receiver == null) {
      tmp_0 = null;
    } else {
      // Inline function 'kotlin.let' call
      var tmp_1;
      if (tmp0_safe_receiver.x1h_1 < 1.0E-7) {
        tmp_1 = 1.7976931348623157E308;
      } else {
        tmp_1 = tmp0_safe_receiver.w1h_1 / tmp0_safe_receiver.x1h_1;
      }
      tmp_0 = tmp_1;
    }
    var tmp1_elvis_lhs = tmp_0;
    tmp.p48_1 = tmp1_elvis_lhs == null ? 0.0 : tmp1_elvis_lhs;
  };
  protoOf(RectangleEventHandler).u3s = function (context) {
    if (!ensureNotNull(this.v47_1).equals(this.w47_1.t3s().f3z_1)) {
      _get_LOG__e5r759_6(Companion_getInstance_35()).kl("Resize '" + this.w47_1.t3s().k1a() + "' " + this.w47_1.t3s().cv() + ' to ' + toString(this.w47_1.t3s().f3z_1));
      context.w3c_1.d3d().u3a(new ResizeRectangleCommand(context.w3c_1, this.w47_1.t3s().cv(), Rectangle2D_init_$Create$(ensureNotNull(this.v47_1)), Rectangle2D_init_$Create$(this.w47_1.t3s().f3z_1)));
    }
  };
  function NorthWestHandler($outer) {
    this.r48_1 = $outer;
    InputEventHandlerAdapter.call(this);
  }
  protoOf(NorthWestHandler).x3s = function (context) {
    context.n22_1.l1y(Cursor_NW_RESIZE_getInstance());
    return this;
  };
  protoOf(NorthWestHandler).z22 = function (context) {
    return this.x3s(context instanceof EditInputEventContext ? context : THROW_CCE());
  };
  protoOf(NorthWestHandler).z3s = function (context) {
    var bounds = this.r48_1.t3s().f3z_1;
    var tmp0 = context.q22_1;
    // Inline function 'kotlin.math.min' call
    var b = bounds.b1d();
    var x = Math.min(tmp0, b);
    var tmp0_0 = context.r22_1;
    // Inline function 'kotlin.math.min' call
    var b_0 = bounds.c1d();
    var y = Math.min(tmp0_0, b_0);
    if (this.r48_1.t3s().p40()) {
      var prefWidth = bounds.b1d() - x;
      var height = prefWidth / this.r48_1.p48_1;
      this.r48_1.t3s().i1c(bounds.b1d() - prefWidth, bounds.c1d() - height, prefWidth, height);
    } else {
      this.r48_1.t3s().i1c(x, y, bounds.f1c() + (bounds.p1a() - x), bounds.h1c() + (bounds.q1a() - y));
    }
    reportSize(this.r48_1);
    return this;
  };
  protoOf(NorthWestHandler).b23 = function (context) {
    return this.z3s(context instanceof EditInputEventContext ? context : THROW_CCE());
  };
  function NorthHandler($outer) {
    this.t48_1 = $outer;
    InputEventHandlerAdapter.call(this);
  }
  protoOf(NorthHandler).x3s = function (context) {
    context.n22_1.l1y(Cursor_N_RESIZE_getInstance());
    return this;
  };
  protoOf(NorthHandler).z22 = function (context) {
    return this.x3s(context instanceof EditInputEventContext ? context : THROW_CCE());
  };
  protoOf(NorthHandler).z3s = function (context) {
    var bounds = this.t48_1.t3s().f3z_1;
    var tmp0 = context.r22_1;
    // Inline function 'kotlin.math.min' call
    var b = bounds.c1d();
    var y = Math.min(tmp0, b);
    this.t48_1.t3s().i1c(bounds.p1a(), y, bounds.f1c(), bounds.h1c() + (bounds.q1a() - y));
    reportSize(this.t48_1);
    return this;
  };
  protoOf(NorthHandler).b23 = function (context) {
    return this.z3s(context instanceof EditInputEventContext ? context : THROW_CCE());
  };
  function NorthEastHandler($outer) {
    this.v48_1 = $outer;
    InputEventHandlerAdapter.call(this);
  }
  protoOf(NorthEastHandler).x3s = function (context) {
    context.n22_1.l1y(Cursor_NE_RESIZE_getInstance());
    return this;
  };
  protoOf(NorthEastHandler).z22 = function (context) {
    return this.x3s(context instanceof EditInputEventContext ? context : THROW_CCE());
  };
  protoOf(NorthEastHandler).z3s = function (context) {
    var bounds = this.v48_1.t3s().f3z_1;
    var tmp0 = context.q22_1;
    // Inline function 'kotlin.math.max' call
    var b = bounds.p1a();
    var x = Math.max(tmp0, b);
    var tmp0_0 = context.r22_1;
    // Inline function 'kotlin.math.min' call
    var b_0 = bounds.c1d();
    var y = Math.min(tmp0_0, b_0);
    if (this.v48_1.t3s().p40()) {
      var prefWidth = x - bounds.p1a();
      var height = prefWidth / this.v48_1.p48_1;
      this.v48_1.t3s().i1c(bounds.z1c(), bounds.c1d() - height, prefWidth, height);
    } else {
      this.v48_1.t3s().i1c(bounds.p1a(), y, x - bounds.p1a(), bounds.h1c() + (bounds.q1a() - y));
    }
    reportSize(this.v48_1);
    return this;
  };
  protoOf(NorthEastHandler).b23 = function (context) {
    return this.z3s(context instanceof EditInputEventContext ? context : THROW_CCE());
  };
  function EastHandler($outer) {
    this.x48_1 = $outer;
    InputEventHandlerAdapter.call(this);
  }
  protoOf(EastHandler).x3s = function (context) {
    context.n22_1.l1y(Cursor_E_RESIZE_getInstance());
    return this;
  };
  protoOf(EastHandler).z22 = function (context) {
    return this.x3s(context instanceof EditInputEventContext ? context : THROW_CCE());
  };
  protoOf(EastHandler).z3s = function (context) {
    var bounds = this.x48_1.t3s().f3z_1;
    var tmp0 = context.q22_1;
    // Inline function 'kotlin.math.max' call
    var b = bounds.p1a();
    var x = Math.max(tmp0, b);
    this.x48_1.t3s().i1c(bounds.p1a(), bounds.q1a(), x - bounds.p1a(), bounds.h1c());
    reportSize(this.x48_1);
    return this;
  };
  protoOf(EastHandler).b23 = function (context) {
    return this.z3s(context instanceof EditInputEventContext ? context : THROW_CCE());
  };
  function SouthEastHandler($outer) {
    this.z48_1 = $outer;
    InputEventHandlerAdapter.call(this);
  }
  protoOf(SouthEastHandler).x3s = function (context) {
    context.n22_1.l1y(Cursor_SE_RESIZE_getInstance());
    return this;
  };
  protoOf(SouthEastHandler).z22 = function (context) {
    return this.x3s(context instanceof EditInputEventContext ? context : THROW_CCE());
  };
  protoOf(SouthEastHandler).z3s = function (context) {
    var bounds = this.z48_1.t3s().f3z_1;
    var tmp0 = context.q22_1;
    // Inline function 'kotlin.math.max' call
    var b = bounds.p1a();
    var x = Math.max(tmp0, b);
    var tmp0_0 = context.r22_1;
    // Inline function 'kotlin.math.max' call
    var b_0 = bounds.q1a();
    var y = Math.max(tmp0_0, b_0);
    if (this.z48_1.t3s().p40()) {
      var prefHeight = y - bounds.q1a();
      this.z48_1.t3s().i1c(bounds.p1a(), bounds.q1a(), this.z48_1.p48_1 * prefHeight, prefHeight);
    } else {
      this.z48_1.t3s().i1c(bounds.p1a(), bounds.q1a(), x - bounds.p1a(), y - bounds.q1a());
    }
    reportSize(this.z48_1);
    return this;
  };
  protoOf(SouthEastHandler).b23 = function (context) {
    return this.z3s(context instanceof EditInputEventContext ? context : THROW_CCE());
  };
  function SouthHandler($outer) {
    this.b49_1 = $outer;
    InputEventHandlerAdapter.call(this);
  }
  protoOf(SouthHandler).x3s = function (context) {
    context.n22_1.l1y(Cursor_S_RESIZE_getInstance());
    return this;
  };
  protoOf(SouthHandler).z22 = function (context) {
    return this.x3s(context instanceof EditInputEventContext ? context : THROW_CCE());
  };
  protoOf(SouthHandler).z3s = function (context) {
    var bounds = this.b49_1.t3s().f3z_1;
    var tmp0 = context.r22_1;
    // Inline function 'kotlin.math.max' call
    var b = bounds.q1a();
    var y = Math.max(tmp0, b);
    this.b49_1.t3s().i1c(bounds.p1a(), bounds.q1a(), bounds.f1c(), y - bounds.q1a());
    reportSize(this.b49_1);
    return this;
  };
  protoOf(SouthHandler).b23 = function (context) {
    return this.z3s(context instanceof EditInputEventContext ? context : THROW_CCE());
  };
  function SouthWestHandler($outer) {
    this.d49_1 = $outer;
    InputEventHandlerAdapter.call(this);
  }
  protoOf(SouthWestHandler).x3s = function (context) {
    context.n22_1.l1y(Cursor_SW_RESIZE_getInstance());
    return this;
  };
  protoOf(SouthWestHandler).z22 = function (context) {
    return this.x3s(context instanceof EditInputEventContext ? context : THROW_CCE());
  };
  protoOf(SouthWestHandler).z3s = function (context) {
    var bounds = this.d49_1.t3s().f3z_1;
    var tmp0 = context.q22_1;
    // Inline function 'kotlin.math.min' call
    var b = bounds.b1d();
    var x = Math.min(tmp0, b);
    var tmp0_0 = context.r22_1;
    // Inline function 'kotlin.math.max' call
    var b_0 = bounds.q1a();
    var y = Math.max(tmp0_0, b_0);
    if (this.d49_1.t3s().p40()) {
      var prefHeight = y - bounds.q1a();
      var width = this.d49_1.p48_1 * prefHeight;
      this.d49_1.t3s().i1c(bounds.b1d() - width, bounds.q1a(), width, prefHeight);
    } else {
      this.d49_1.t3s().i1c(x, bounds.q1a(), bounds.b1d() - x, y - bounds.q1a());
    }
    reportSize(this.d49_1);
    return this;
  };
  protoOf(SouthWestHandler).b23 = function (context) {
    return this.z3s(context instanceof EditInputEventContext ? context : THROW_CCE());
  };
  function WestHandler($outer) {
    this.f49_1 = $outer;
    InputEventHandlerAdapter.call(this);
  }
  protoOf(WestHandler).x3s = function (context) {
    context.n22_1.l1y(Cursor_W_RESIZE_getInstance());
    return this;
  };
  protoOf(WestHandler).z22 = function (context) {
    return this.x3s(context instanceof EditInputEventContext ? context : THROW_CCE());
  };
  protoOf(WestHandler).z3s = function (context) {
    var bounds = this.f49_1.t3s().f3z_1;
    var tmp0 = context.q22_1;
    // Inline function 'kotlin.math.min' call
    var b = bounds.b1d();
    var x = Math.min(tmp0, b);
    this.f49_1.t3s().i1c(x, bounds.q1a(), bounds.f1c() + (bounds.p1a() - x), bounds.h1c());
    reportSize(this.f49_1);
    return this;
  };
  protoOf(WestHandler).b23 = function (context) {
    return this.z3s(context instanceof EditInputEventContext ? context : THROW_CCE());
  };
  function RectangularHandleSelectionModel(component) {
    Companion_getInstance_35();
    AbstractHandleSelectionModel.call(this, component);
    this.h48_1 = this.d3s(new RectangularHandle(new NorthWestHandler(this)));
    this.i48_1 = this.d3s(new RectangularHandle(new NorthEastHandler(this)));
    this.j48_1 = this.d3s(new RectangularHandle(new SouthEastHandler(this)));
    this.k48_1 = this.d3s(new RectangularHandle(new SouthWestHandler(this)));
    var tmp = this;
    var tmp_0;
    if (!component.p40()) {
      tmp_0 = this.d3s(new RectangularHandle(new NorthHandler(this)));
    } else {
      tmp_0 = null;
    }
    tmp.l48_1 = tmp_0;
    var tmp_1 = this;
    var tmp_2;
    if (!component.p40()) {
      tmp_2 = this.d3s(new RectangularHandle(new EastHandler(this)));
    } else {
      tmp_2 = null;
    }
    tmp_1.m48_1 = tmp_2;
    var tmp_3 = this;
    var tmp_4;
    if (!component.p40()) {
      tmp_4 = this.d3s(new RectangularHandle(new SouthHandler(this)));
    } else {
      tmp_4 = null;
    }
    tmp_3.n48_1 = tmp_4;
    var tmp_5 = this;
    var tmp_6;
    if (!component.p40()) {
      tmp_6 = this.d3s(new RectangularHandle(new WestHandler(this)));
    } else {
      tmp_6 = null;
    }
    tmp_5.o48_1 = tmp_6;
    this.p48_1 = 0.0;
  }
  protoOf(RectangularHandleSelectionModel).r3r = function () {
    return 8;
  };
  protoOf(RectangularHandleSelectionModel).f3t = function () {
    var r = this.t3s().f3z_1;
    this.h48_1.y43(r.p1a(), r.q1a());
    this.i48_1.y43(r.p1a() + r.f1c(), r.q1a());
    this.k48_1.y43(r.p1a(), r.q1a() + r.h1c());
    this.j48_1.y43(r.p1a() + r.f1c(), r.q1a() + r.h1c());
    var tmp0_safe_receiver = this.l48_1;
    if (tmp0_safe_receiver == null)
      null;
    else {
      tmp0_safe_receiver.y43(r.p1a() + r.f1c() / 2, r.q1a());
    }
    var tmp1_safe_receiver = this.m48_1;
    if (tmp1_safe_receiver == null)
      null;
    else {
      tmp1_safe_receiver.y43(r.p1a() + r.f1c(), r.q1a() + r.h1c() / 2);
    }
    var tmp2_safe_receiver = this.n48_1;
    if (tmp2_safe_receiver == null)
      null;
    else {
      tmp2_safe_receiver.y43(r.p1a() + r.f1c() / 2, r.q1a() + r.h1c());
    }
    var tmp3_safe_receiver = this.o48_1;
    if (tmp3_safe_receiver == null)
      null;
    else {
      tmp3_safe_receiver.y43(r.p1a(), r.q1a() + r.h1c() / 2);
    }
  };
  protoOf(RectangularHandleSelectionModel).e3t = function () {
    return new RectangleEventHandler(this);
  };
  function RectangularReplaceSelectionModel$DrawStrategy$SHAPE() {
    DrawStrategy.call(this, 'SHAPE', 0);
    DrawStrategy_SHAPE_instance = this;
  }
  protoOf(RectangularReplaceSelectionModel$DrawStrategy$SHAPE).i49 = function (component, context) {
    var oldStroke = context.j1z_1.l1u();
    context.j1z_1.b1u(Themes_getInstance().h2g().p3y_1.c1u().x1x_1);
    context.j1z_1.e1u(component.l1u());
    context.j1z_1.j1v(component.b41());
    component.a41(context);
    context.j1z_1.e1u(oldStroke);
  };
  var DrawStrategy_SHAPE_instance;
  function RectangularReplaceSelectionModel$DrawStrategy$COMPONENT() {
    DrawStrategy.call(this, 'COMPONENT', 1);
    DrawStrategy_COMPONENT_instance = this;
  }
  protoOf(RectangularReplaceSelectionModel$DrawStrategy$COMPONENT).i49 = function (component, context) {
    var oldUseContextColor = context.m1z_1;
    var oldContextColor = context.n1z_1;
    context.m1z_1 = true;
    context.n1z_1 = Themes_getInstance().h2g().p3y_1.c1u();
    component.h20(context);
    context.m1z_1 = oldUseContextColor;
    context.n1z_1 = oldContextColor;
  };
  var DrawStrategy_COMPONENT_instance;
  var DrawStrategy_entriesInitialized;
  function DrawStrategy_initEntries() {
    if (DrawStrategy_entriesInitialized)
      return Unit_instance;
    DrawStrategy_entriesInitialized = true;
    DrawStrategy_SHAPE_instance = new RectangularReplaceSelectionModel$DrawStrategy$SHAPE();
    DrawStrategy_COMPONENT_instance = new RectangularReplaceSelectionModel$DrawStrategy$COMPONENT();
  }
  function DrawStrategy(name, ordinal) {
    Enum.call(this, name, ordinal);
  }
  function DrawStrategy_SHAPE_getInstance() {
    DrawStrategy_initEntries();
    return DrawStrategy_SHAPE_instance;
  }
  function DrawStrategy_COMPONENT_getInstance() {
    DrawStrategy_initEntries();
    return DrawStrategy_COMPONENT_instance;
  }
  function RectangularReplaceSelectionModel(component, drawStrategy) {
    drawStrategy = drawStrategy === VOID ? DrawStrategy_SHAPE_getInstance() : drawStrategy;
    AbstractSelectedColorWrappingSelectionModel.call(this, component);
    this.v49_1 = drawStrategy;
  }
  protoOf(RectangularReplaceSelectionModel).fo = function () {
    return Rectangle2D_init_$Create$(this.t3s().fo()).p1c(this.t3s().l1u().f1u_1);
  };
  protoOf(RectangularReplaceSelectionModel).h20 = function (context) {
    this.v49_1.i49(this.t3s(), context);
  };
  protoOf(RectangularReplaceSelectionModel).go = function (x, y) {
    return this.f3v_1.go(x, y);
  };
  protoOf(RectangularReplaceSelectionModel).w49 = function (component) {
    return new RectangularHandleSelectionModel(component);
  };
  protoOf(RectangularReplaceSelectionModel).z3u = function (component) {
    return this.w49(component instanceof AbstractRectangularComponent ? component : THROW_CCE());
  };
  function _get_rectangle__f04u2m($this) {
    var tmp = ensureNotNull(ensureNotNull($this.h3h_1).u3b().o3b($this.a4a_1)).d3b();
    return tmp instanceof AbstractRectangularComponent ? tmp : THROW_CCE();
  }
  function ResizeRectangleCommand(editor, rectangleId, oldBounds, newBounds) {
    AbstractCommand.call(this, 'edit.model.rectangle.resize', editor);
    this.a4a_1 = rectangleId;
    this.b4a_1 = oldBounds;
    this.c4a_1 = newBounds;
  }
  protoOf(ResizeRectangleCommand).i3a = function () {
    _get_rectangle__f04u2m(this).m1c(this.c4a_1);
  };
  protoOf(ResizeRectangleCommand).m3a = function () {
    _get_rectangle__f04u2m(this).m1c(this.b4a_1);
  };
  function Companion_26() {
    Companion_instance_31 = this;
    this.d4a_1 = Translations_getInstance().bn('edit.component.text', []);
    this.e4a_1 = 10;
    this.f4a_1 = 10;
  }
  var Companion_instance_31;
  function Companion_getInstance_36() {
    if (Companion_instance_31 == null)
      new Companion_26();
    return Companion_instance_31;
  }
  function AbstractTextComponent(location, shape, styleType, styleProvider) {
    Companion_getInstance_36();
    location = location === VOID ? Companion_getInstance().w1a_1 : location;
    shape = shape === VOID ? new Rectangle2D(location.kn_1, location.ln_1, 0.0, 0.0) : shape;
    styleType = styleType === VOID ? Companion_getInstance_0().a1y_1 : styleType;
    styleProvider = styleProvider === VOID ? DrawStyleModule_getInstance().w1x_1 : styleProvider;
    AbstractRectangularComponent.call(this, styleType, styleProvider, shape);
    this.q4a_1 = false;
    this.r4a_1 = new TransparentImpl(this);
    this.s4a_1 = HorizontalAlignment_LEFT_getInstance();
    this.t4a_1 = new RectangularShapeTextComponentDecorator(new RoundRectangle2D(0.0, 0.0, 0.0, 0.0, 20.0, 20.0), this, this.r4a_1);
  }
  protoOf(AbstractTextComponent).go = function (x, y) {
    return protoOf(AbstractRectangularComponent).go.call(this, x, y);
  };
  protoOf(AbstractTextComponent).po = function (p) {
    return protoOf(AbstractRectangularComponent).po.call(this, p);
  };
  protoOf(AbstractTextComponent).ro = function (rect) {
    return protoOf(AbstractRectangularComponent).ro.call(this, rect);
  };
  protoOf(AbstractTextComponent).a2i = function (value) {
    this.r4a_1.a2i(value);
  };
  protoOf(AbstractTextComponent).d2i = function () {
    return this.r4a_1.c2i_1;
  };
  protoOf(AbstractTextComponent).h38 = function (writer) {
    protoOf(AbstractRectangularComponent).h38.call(this, writer);
    if (!this.u4a().qv()) {
      writer.h39('text', this.u4a().p45());
    }
    if (this.q4a_1) {
      writer.o39('richText', this.q4a_1);
    }
  };
  protoOf(AbstractTextComponent).i38 = function (reader) {
    protoOf(AbstractRectangularComponent).i38.call(this, reader);
    if (reader.t35('text')) {
      this.v4a(TranslatableText_init_$Create$(reader.r38('text')));
    }
    if (reader.u35('text')) {
      this.v4a(new TranslatableText(reader.n38('text')));
    }
    if (reader.t35('richText')) {
      this.q4a_1 = reader.t38('richText');
    }
  };
  protoOf(AbstractTextComponent).k1a = function () {
    return Companion_getInstance_36().d4a_1;
  };
  function HorizontalAlignment$LEFT() {
    HorizontalAlignment.call(this, 'LEFT', 0, 'left');
    HorizontalAlignment_LEFT_instance = this;
  }
  protoOf(HorizontalAlignment$LEFT).u1f = function () {
    return HorizontalAlignment_RIGHT_getInstance();
  };
  protoOf(HorizontalAlignment$LEFT).z4a = function (baselineRect) {
    return baselineRect.p1a();
  };
  var HorizontalAlignment_LEFT_instance;
  function HorizontalAlignment$CENTER() {
    HorizontalAlignment.call(this, 'CENTER', 1, 'center');
    HorizontalAlignment_CENTER_instance = this;
  }
  protoOf(HorizontalAlignment$CENTER).u1f = function () {
    return HorizontalAlignment_CENTER_getInstance();
  };
  protoOf(HorizontalAlignment$CENTER).z4a = function (baselineRect) {
    return baselineRect.p1a() - baselineRect.f1c() / 2 + 1;
  };
  var HorizontalAlignment_CENTER_instance;
  function HorizontalAlignment$RIGHT() {
    HorizontalAlignment.call(this, 'RIGHT', 2, 'right');
    HorizontalAlignment_RIGHT_instance = this;
  }
  protoOf(HorizontalAlignment$RIGHT).u1f = function () {
    return HorizontalAlignment_LEFT_getInstance();
  };
  protoOf(HorizontalAlignment$RIGHT).z4a = function (baselineRect) {
    return baselineRect.p1a() - baselineRect.f1c();
  };
  var HorizontalAlignment_RIGHT_instance;
  function Companion_27() {
  }
  protoOf(Companion_27).h1f = function (name) {
    var indexedObject = values_0();
    var inductionVariable = 0;
    var last = indexedObject.length;
    while (inductionVariable < last) {
      var alignment = indexedObject[inductionVariable];
      inductionVariable = inductionVariable + 1 | 0;
      if (alignment.v45_1 === name) {
        return alignment;
      }
    }
    throw IllegalArgumentException_init_$Create$("Cannot determine HorizontalAlignment for '" + name + "'");
  };
  var Companion_instance_32;
  function Companion_getInstance_37() {
    return Companion_instance_32;
  }
  function values_0() {
    return [HorizontalAlignment_LEFT_getInstance(), HorizontalAlignment_CENTER_getInstance(), HorizontalAlignment_RIGHT_getInstance()];
  }
  var HorizontalAlignment_entriesInitialized;
  function HorizontalAlignment_initEntries() {
    if (HorizontalAlignment_entriesInitialized)
      return Unit_instance;
    HorizontalAlignment_entriesInitialized = true;
    HorizontalAlignment_LEFT_instance = new HorizontalAlignment$LEFT();
    HorizontalAlignment_CENTER_instance = new HorizontalAlignment$CENTER();
    HorizontalAlignment_RIGHT_instance = new HorizontalAlignment$RIGHT();
  }
  function HorizontalAlignment(name, ordinal, customName) {
    Enum.call(this, name, ordinal);
    this.v45_1 = customName;
  }
  protoOf(HorizontalAlignment).toString = function () {
    var tmp;
    switch (this.l2_1) {
      case 0:
        tmp = Translations_getInstance().bn('edit.property.horizontalAlignment.left.name', []);
        break;
      case 1:
        tmp = Translations_getInstance().bn('edit.property.horizontalAlignment.center.name', []);
        break;
      case 2:
        tmp = Translations_getInstance().bn('edit.property.horizontalAlignment.right.name', []);
        break;
      default:
        noWhenBranchMatchedException();
        break;
    }
    return tmp;
  };
  function VerticalAlignment$TOP() {
    VerticalAlignment.call(this, 'TOP', 0, 'top');
    VerticalAlignment_TOP_instance = this;
  }
  protoOf(VerticalAlignment$TOP).j4b = function () {
    return VerticalAlignment_BOTTOM_getInstance();
  };
  protoOf(VerticalAlignment$TOP).k4b = function (baselineRect) {
    return 0.0;
  };
  var VerticalAlignment_TOP_instance;
  function VerticalAlignment$CENTER() {
    VerticalAlignment.call(this, 'CENTER', 1, 'center');
    VerticalAlignment_CENTER_instance = this;
  }
  protoOf(VerticalAlignment$CENTER).j4b = function () {
    return VerticalAlignment_CENTER_getInstance();
  };
  protoOf(VerticalAlignment$CENTER).k4b = function (baselineRect) {
    return baselineRect.h1c() / 2 + 1;
  };
  var VerticalAlignment_CENTER_instance;
  function VerticalAlignment$BOTTOM() {
    VerticalAlignment.call(this, 'BOTTOM', 2, 'bottom');
    VerticalAlignment_BOTTOM_instance = this;
  }
  protoOf(VerticalAlignment$BOTTOM).j4b = function () {
    return VerticalAlignment_TOP_getInstance();
  };
  protoOf(VerticalAlignment$BOTTOM).k4b = function (baselineRect) {
    return baselineRect.h1c();
  };
  var VerticalAlignment_BOTTOM_instance;
  function Companion_28() {
  }
  protoOf(Companion_28).h1f = function (name) {
    var indexedObject = values_1();
    var inductionVariable = 0;
    var last = indexedObject.length;
    while (inductionVariable < last) {
      var alignment = indexedObject[inductionVariable];
      inductionVariable = inductionVariable + 1 | 0;
      if (alignment.s45_1 === name) {
        return alignment;
      }
    }
    throw IllegalArgumentException_init_$Create$("Cannot determine HorizontalAlignment for '" + name + "'");
  };
  var Companion_instance_33;
  function Companion_getInstance_38() {
    return Companion_instance_33;
  }
  function values_1() {
    return [VerticalAlignment_TOP_getInstance(), VerticalAlignment_CENTER_getInstance(), VerticalAlignment_BOTTOM_getInstance()];
  }
  var VerticalAlignment_entriesInitialized;
  function VerticalAlignment_initEntries() {
    if (VerticalAlignment_entriesInitialized)
      return Unit_instance;
    VerticalAlignment_entriesInitialized = true;
    VerticalAlignment_TOP_instance = new VerticalAlignment$TOP();
    VerticalAlignment_CENTER_instance = new VerticalAlignment$CENTER();
    VerticalAlignment_BOTTOM_instance = new VerticalAlignment$BOTTOM();
  }
  function VerticalAlignment(name, ordinal, customName) {
    Enum.call(this, name, ordinal);
    this.s45_1 = customName;
  }
  protoOf(VerticalAlignment).toString = function () {
    var tmp;
    switch (this.l2_1) {
      case 0:
        tmp = Translations_getInstance().bn('edit.property.verticalAlignment.top.name', []);
        break;
      case 1:
        tmp = Translations_getInstance().bn('edit.property.verticalAlignment.center.name', []);
        break;
      case 2:
        tmp = Translations_getInstance().bn('edit.property.verticalAlignment.bottom.name', []);
        break;
      default:
        noWhenBranchMatchedException();
        break;
    }
    return tmp;
  };
  function Companion_29() {
  }
  protoOf(Companion_29).r4b = function (orientation) {
    var tmp;
    switch (orientation.l2_1) {
      case 0:
        tmp = new Alignment(HorizontalAlignment_RIGHT_getInstance(), VerticalAlignment_CENTER_getInstance());
        break;
      case 1:
        tmp = new Alignment(HorizontalAlignment_CENTER_getInstance(), VerticalAlignment_TOP_getInstance());
        break;
      case 2:
        tmp = new Alignment(HorizontalAlignment_LEFT_getInstance(), VerticalAlignment_CENTER_getInstance());
        break;
      case 3:
        tmp = new Alignment(HorizontalAlignment_CENTER_getInstance(), VerticalAlignment_BOTTOM_getInstance());
        break;
      default:
        noWhenBranchMatchedException();
        break;
    }
    return tmp;
  };
  var Companion_instance_34;
  function Companion_getInstance_39() {
    return Companion_instance_34;
  }
  function Alignment(horizontal, vertical) {
    this.s4b_1 = horizontal;
    this.t4b_1 = vertical;
  }
  protoOf(Alignment).toString = function () {
    return 'Alignment(horizontal=' + this.s4b_1.toString() + ', vertical=' + this.t4b_1.toString() + ')';
  };
  protoOf(Alignment).hashCode = function () {
    var result = this.s4b_1.hashCode();
    result = imul(result, 31) + this.t4b_1.hashCode() | 0;
    return result;
  };
  protoOf(Alignment).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof Alignment))
      return false;
    if (!this.s4b_1.equals(other.s4b_1))
      return false;
    if (!this.t4b_1.equals(other.t4b_1))
      return false;
    return true;
  };
  function HorizontalAlignment_LEFT_getInstance() {
    HorizontalAlignment_initEntries();
    return HorizontalAlignment_LEFT_instance;
  }
  function HorizontalAlignment_CENTER_getInstance() {
    HorizontalAlignment_initEntries();
    return HorizontalAlignment_CENTER_instance;
  }
  function HorizontalAlignment_RIGHT_getInstance() {
    HorizontalAlignment_initEntries();
    return HorizontalAlignment_RIGHT_instance;
  }
  function VerticalAlignment_TOP_getInstance() {
    VerticalAlignment_initEntries();
    return VerticalAlignment_TOP_instance;
  }
  function VerticalAlignment_CENTER_getInstance() {
    VerticalAlignment_initEntries();
    return VerticalAlignment_CENTER_instance;
  }
  function VerticalAlignment_BOTTOM_getInstance() {
    VerticalAlignment_initEntries();
    return VerticalAlignment_BOTTOM_instance;
  }
  function fillProperties($this, properties) {
    properties.et('edit.grid.painter', 'line');
  }
  function EditModelTextModule$initialize$lambda(s) {
    return new DottedGridPainter(s);
  }
  function EditModelTextModule$initialize$lambda_0(s) {
    return new LineGridPainter(s);
  }
  function EditModelTextModule$initialize$lambda_1(it) {
    return new RectangularHandleSelectionModel(it instanceof AbstractRectangularComponent ? it : THROW_CCE());
  }
  function EditModelTextModule$initialize$lambda_2(it) {
    return new RectangularHandleSelectionModel(it instanceof AbstractRectangularComponent ? it : THROW_CCE());
  }
  function EditModelTextModule$initialize$lambda_3(it) {
    return new RectangularReplaceSelectionModel(it instanceof AbstractRectangularComponent ? it : THROW_CCE());
  }
  function EditModelTextModule() {
    EditModelTextModule_instance = this;
    AbstractModule.call(this);
    this.f3a_1 = new UndefinedTextComponentFactory();
  }
  protoOf(EditModelTextModule).to = function () {
    var tmp = GridPainterRegistry_getInstance();
    tmp.f3d('dot', EditModelTextModule$initialize$lambda);
    var tmp_0 = GridPainterRegistry_getInstance();
    tmp_0.f3d('line', EditModelTextModule$initialize$lambda_0);
    var tmp_1 = EditSelectModule_getInstance().t3l_1;
    var tmp_2 = SelectionDrawingStrategy_ABOVE_getInstance();
    var tmp_3 = getKClass(TextComponent);
    tmp_1.o3v(tmp_2, tmp_3, EditModelTextModule$initialize$lambda_1);
    var tmp_4 = EditSelectModule_getInstance().t3l_1;
    var tmp_5 = SelectionDrawingStrategy_ABOVE_getInstance();
    var tmp_6 = getKClass(SimpleTextComponent);
    tmp_4.o3v(tmp_5, tmp_6, EditModelTextModule$initialize$lambda_2);
    var tmp_7 = EditSelectModule_getInstance().t3l_1;
    var tmp_8 = SelectionDrawingStrategy_REPLACE_getInstance();
    var tmp_9 = getKClass(SimpleTextComponent);
    tmp_7.o3v(tmp_8, tmp_9, EditModelTextModule$initialize$lambda_3);
    fillProperties(this, DrawModule_getInstance().l2a_1);
  };
  var EditModelTextModule_instance;
  function EditModelTextModule_getInstance() {
    if (EditModelTextModule_instance == null)
      new EditModelTextModule();
    return EditModelTextModule_instance;
  }
  function updateLocation($this) {
    $this.v4b_1.v20($this.u4b_1.w20().m1i($this.x4b_1.kn_1, $this.x4b_1.ln_1));
  }
  function updateAlignment($this) {
    if ($this.w4b_1 == null) {
      $this.v4b_1.y4b(new Alignment(HorizontalAlignment_CENTER_getInstance(), VerticalAlignment_CENTER_getInstance()));
    } else {
      switch ($this.u4b_1.w20().q1i(ensureNotNull($this.w4b_1)).l2_1) {
        case 0:
          $this.v4b_1.y4b(new Alignment(HorizontalAlignment_LEFT_getInstance(), VerticalAlignment_CENTER_getInstance()));
          break;
        case 2:
          $this.v4b_1.y4b(new Alignment(HorizontalAlignment_RIGHT_getInstance(), VerticalAlignment_CENTER_getInstance()));
          break;
        case 1:
          $this.v4b_1.y4b(new Alignment(HorizontalAlignment_CENTER_getInstance(), VerticalAlignment_BOTTOM_getInstance()));
          break;
        case 3:
          $this.v4b_1.y4b(new Alignment(HorizontalAlignment_CENTER_getInstance(), VerticalAlignment_TOP_getInstance()));
          break;
        default:
          noWhenBranchMatchedException();
          break;
      }
    }
  }
  function HorizontalLabel(owner, relLocation, orientation, text, font, color) {
    orientation = orientation === VOID ? Direction_EAST_getInstance() : orientation;
    text = text === VOID ? null : text;
    color = color === VOID ? null : color;
    this.u4b_1 = owner;
    this.v4b_1 = new Label(text, font, color, VOID, VOID, relLocation);
    this.w4b_1 = orientation;
    this.x4b_1 = relLocation;
    this.l20();
  }
  protoOf(HorizontalLabel).o45 = function (value) {
    this.v4b_1.o45(value);
  };
  protoOf(HorizontalLabel).u4a = function () {
    return this.v4b_1.b45_1;
  };
  protoOf(HorizontalLabel).fo = function () {
    return this.v4b_1.l45_1;
  };
  protoOf(HorizontalLabel).z4b = function (value) {
    if (!equals(this.w4b_1, value)) {
      this.w4b_1 = value;
      updateAlignment(this);
    }
  };
  protoOf(HorizontalLabel).a4c = function (value) {
    if (!this.x4b_1.equals(value)) {
      this.x4b_1 = value;
      updateLocation(this);
    }
  };
  protoOf(HorizontalLabel).l20 = function () {
    updateLocation(this);
    updateAlignment(this);
  };
  protoOf(HorizontalLabel).h20 = function (context) {
    // Inline function 'io.antarescircuit.jabbah.draw.DrawContext.translated' call
    var d = this.u4b_1.jw();
    context.j1z_1.l1d(d.kn_1, d.ln_1);
    this.v4b_1.h20(context);
    context.j1z_1.l1d(-d.kn_1, -d.ln_1);
  };
  function Companion_30() {
    Companion_instance_35 = this;
    this.b4c_1 = HorizontalAlignment_CENTER_getInstance();
    this.c4c_1 = VerticalAlignment_CENTER_getInstance();
    this.d4c_1 = 1;
  }
  var Companion_instance_35;
  function Companion_getInstance_40() {
    if (Companion_instance_35 == null)
      new Companion_30();
    return Companion_instance_35;
  }
  function updateBoundingBox_1($this) {
    $this.l45_1 = $this.y44_1.p1i($this.d45_1, $this.j45_1);
  }
  function drawImpl_0($this, richText, context) {
    var oldColor = context.j1z_1.c1u();
    DrawModule_getInstance().w2p($this, context.j1z_1, Companion_getInstance_3().i1t_1);
    DrawModule_getInstance().y2p($this.d45_1, context, Companion_getInstance_3().m1t_1);
    var tmp;
    if (context.m1z_1) {
      var tmp_0;
      if ($this.k45_1) {
        tmp_0 = ensureNotNull(context.n1z_1).y1x_1;
      } else {
        tmp_0 = ensureNotNull(context.n1z_1).z1x_1;
      }
      tmp = tmp_0;
    } else {
      var tmp0_elvis_lhs = $this.x44_1;
      tmp = tmp0_elvis_lhs == null ? context.j1z_1.c1u() : tmp0_elvis_lhs;
    }
    var foregroundColor = tmp;
    context.j1z_1.m1u($this.c45_1);
    drawTextRotated($this, richText, context, foregroundColor);
    context.j1z_1.b1u(oldColor);
  }
  function drawTextRotated($this, richText, context, foregroundColor) {
    $this.g45_1.g4c(context, $this);
    context.j1z_1.l1d($this.d45_1.kn_1, $this.d45_1.ln_1);
    context.j1z_1.o1d($this.y44_1.i1i_1);
    context.j1z_1.l1d(-$this.d45_1.kn_1, -$this.d45_1.ln_1);
    if ($this.a45_1) {
      context.j1z_1.b1u(DrawStyleModule_getInstance().w1x_1.f1y(Companion_getInstance_0().d1y_1).c1u().y1x_1);
      context.j1z_1.k1v($this.j45_1);
    }
    context.j1z_1.b1u(foregroundColor);
    richText.h20(context);
    context.j1z_1.l1d($this.d45_1.kn_1, $this.d45_1.ln_1);
    context.j1z_1.o1d(-$this.y44_1.i1i_1);
    context.j1z_1.l1d(-$this.d45_1.kn_1, -$this.d45_1.ln_1);
    $this.g45_1.h4c(context, $this);
  }
  function updateGeometry_0($this) {
    $this.i20();
    positionDisplayableText($this, $this.i45_1);
    $this.j45_1.m1c($this.i45_1.a2c());
    updateBoundingBox_1($this);
    $this.l20();
    $this.k20();
  }
  function positionDisplayableText($this, text) {
    text.v20(new Point2D($this.d45_1.kn_1 + $this.y40().z4a(text.x2h_1) - 1, $this.d45_1.ln_1 - $this.w40().k4b(text.x2h_1) + 1 - 1));
  }
  function Label(text, font, color, horizontalAlignment, verticalAlignment, location, rotationDisplayStrategy, rotation, ownerRotation, richText, displayableText, fillBackground) {
    Companion_getInstance_40();
    color = color === VOID ? null : color;
    horizontalAlignment = horizontalAlignment === VOID ? Companion_getInstance_40().b4c_1 : horizontalAlignment;
    verticalAlignment = verticalAlignment === VOID ? Companion_getInstance_40().c4c_1 : verticalAlignment;
    location = location === VOID ? Companion_getInstance().w1a_1 : location;
    rotationDisplayStrategy = rotationDisplayStrategy === VOID ? RotationDisplayStrategy_IGNORE_getInstance() : rotationDisplayStrategy;
    rotation = rotation === VOID ? Rotation_R0_getInstance() : rotation;
    ownerRotation = ownerRotation === VOID ? Rotation_R0_getInstance() : ownerRotation;
    richText = richText === VOID ? true : richText;
    var tmp;
    if (displayableText === VOID) {
      var tmp_0;
      if (richText) {
        var tmp_1 = Companion_getInstance_4();
        tmp_0 = tmp_1.c2j(text == null ? '' : text, font);
      } else {
        var tmp_2 = Companion_getInstance_4();
        tmp_0 = tmp_2.e2j(text == null ? '' : text, font);
      }
      tmp = tmp_0;
    } else {
      tmp = displayableText;
    }
    displayableText = tmp;
    fillBackground = fillBackground === VOID ? false : fillBackground;
    AbstractDrawable.call(this);
    this.x44_1 = color;
    this.y44_1 = rotation;
    this.z44_1 = richText;
    this.a45_1 = fillBackground;
    var tmp_3 = this;
    tmp_3.b45_1 = text == null ? '' : text;
    this.c45_1 = font;
    this.d45_1 = location;
    this.e45_1 = horizontalAlignment;
    this.f45_1 = verticalAlignment;
    this.g45_1 = rotationDisplayStrategy;
    this.h45_1 = ownerRotation;
    this.i45_1 = displayableText;
    this.j45_1 = new Rectangle2D();
    this.k45_1 = false;
    this.l45_1 = new Rectangle2D();
    updateGeometry_0(this);
  }
  protoOf(Label).o45 = function (value) {
    if (!(this.b45_1 === value)) {
      this.i20();
      this.b45_1 = value;
      if (this.z44_1) {
        this.i45_1 = Companion_getInstance_4().c2j(value, this.c45_1);
      } else {
        this.i45_1 = Companion_getInstance_4().e2j(value, this.c45_1);
      }
      updateGeometry_0(this);
    }
  };
  protoOf(Label).m1u = function (value) {
    if (!equals(this.c45_1, value)) {
      this.i20();
      this.c45_1 = value;
      this.i45_1 = Companion_getInstance_4().c2j(this.b45_1, this.c45_1);
      updateGeometry_0(this);
    }
  };
  protoOf(Label).v20 = function (value) {
    if (!this.d45_1.equals(value)) {
      this.i20();
      this.d45_1 = value;
      updateGeometry_0(this);
    }
  };
  protoOf(Label).jw = function () {
    return this.d45_1;
  };
  protoOf(Label).x40 = function (value) {
    if (!this.e45_1.equals(value)) {
      this.i20();
      this.e45_1 = value;
      updateGeometry_0(this);
    }
  };
  protoOf(Label).y40 = function () {
    return this.e45_1;
  };
  protoOf(Label).v40 = function (value) {
    if (!this.w40().equals(value)) {
      this.i20();
      this.f45_1 = value;
      updateGeometry_0(this);
    }
  };
  protoOf(Label).w40 = function () {
    return this.f45_1;
  };
  protoOf(Label).y4b = function (value) {
    if (!this.i4c().equals(value)) {
      this.i20();
      this.e45_1 = value.s4b_1;
      this.f45_1 = value.t4b_1;
      updateGeometry_0(this);
    }
  };
  protoOf(Label).i4c = function () {
    return new Alignment(this.y40(), this.w40());
  };
  protoOf(Label).j4c = function (value) {
    if (!this.g45_1.equals(value)) {
      this.g45_1 = value;
      this.i20();
    }
  };
  protoOf(Label).fo = function () {
    return this.l45_1;
  };
  protoOf(Label).go = function (x, y) {
    return this.j45_1.go(x, y);
  };
  protoOf(Label).h20 = function (context) {
    drawImpl_0(this, this.i45_1, context);
  };
  protoOf(Label).k4c = function (text, context) {
    positionDisplayableText(this, text);
    drawImpl_0(this, text, context);
  };
  protoOf(Label).f2i = function (x) {
    this.v20(this.d45_1.g1h(x));
    this.x40(this.y40().u1f());
    updateGeometry_0(this);
  };
  protoOf(Label).g2i = function (y) {
    this.v20(this.d45_1.h1h(y));
    this.v40(this.w40().j4b());
    updateGeometry_0(this);
  };
  function Labeled() {
  }
  function createLabel($this, text, styleProvider) {
    return new Label(text, styleProvider.f1y(Companion_getInstance_0().a1y_1).b2d(), VOID, HorizontalAlignment_CENTER_getInstance(), VerticalAlignment_CENTER_getInstance(), Companion_getInstance().w1a_1, RotationDisplayStrategy_IGNORE_getInstance());
  }
  function Companion_31() {
    Companion_instance_36 = this;
    this.l4c_1 = Translations_getInstance().bn('edit.component.label', []);
    this.m4c_1 = 'text';
  }
  var Companion_instance_36;
  function Companion_getInstance_41() {
    if (Companion_instance_36 == null)
      new Companion_31();
    return Companion_instance_36;
  }
  function LabelComponent(styleProvider, label, inverse) {
    Companion_getInstance_41();
    styleProvider = styleProvider === VOID ? DrawStyleModule_getInstance().w1x_1 : styleProvider;
    label = label === VOID ? createLabel(Companion_getInstance_41(), 'text', styleProvider) : label;
    inverse = inverse === VOID ? false : inverse;
    AbstractRectangularComponent.call(this, Companion_getInstance_0().b1y_1, styleProvider);
    this.x4c_1 = label;
    this.y4c_1 = inverse;
    this.z4c_1 = null;
    new DrawableOwner(this, this.x4c_1);
    this.a4d_1 = TranslatableText_init_$Create$(this.x4c_1.b45_1);
    this.b4d_1 = HorizontalAlignment_CENTER_getInstance();
    this.c4d_1 = new TransparentImpl(this);
    this.d4d_1 = Companion_getInstance_41().l4c_1;
  }
  protoOf(LabelComponent).l18 = function () {
    return this.x4c_1;
  };
  protoOf(LabelComponent).e4d = function (value) {
    this.y4c_1 = value;
    this.x4c_1.k45_1 = this.y4c_1;
  };
  protoOf(LabelComponent).v4a = function (value) {
    if (!equals(this.a4d_1, value)) {
      this.i20();
      this.a4d_1 = value;
      this.x4c_1.o45(this.a4d_1.qv() ? '' : this.a4d_1.m45());
      this.m1c(this.x4c_1.l45_1);
      this.i20();
      this.l20();
    }
  };
  protoOf(LabelComponent).a2i = function (value) {
    this.c4d_1.a2i(value);
  };
  protoOf(LabelComponent).d2i = function () {
    return this.c4d_1.c2i_1;
  };
  protoOf(LabelComponent).j3b = function () {
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [new SnappableXCoordinate(this.jw().kn_1)];
  };
  protoOf(LabelComponent).k3b = function () {
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [new SnappableYCoordinate(this.jw().ln_1)];
  };
  protoOf(LabelComponent).fo = function () {
    var tmp;
    if (this.z4c_1 == null) {
      tmp = this.x4c_1.l45_1;
    } else {
      var tmp_0 = Companion_instance_3.p1h(this.jw(), ensureNotNull(this.z4c_1).u1e_1, ensureNotNull(this.z4c_1).v1e_1).p1c(this.l1u().f1u_1 / 2.0);
      tmp = tmp_0 instanceof Rectangle2D ? tmp_0 : THROW_CCE();
    }
    var bbox = tmp;
    var tmp_1;
    if (this.w20().equals(Rotation_R0_getInstance()) || this.w20().equals(Rotation_R180_getInstance())) {
      tmp_1 = bbox;
    } else {
      tmp_1 = this.w20().p1i(bbox.d1d(), bbox);
    }
    return tmp_1;
  };
  protoOf(LabelComponent).go = function (x, y) {
    return this.x4c_1.go(x, y);
  };
  protoOf(LabelComponent).po = function (p) {
    return this.x4c_1.po(p);
  };
  protoOf(LabelComponent).ro = function (rect) {
    return this.x4c_1.ro(rect);
  };
  protoOf(LabelComponent).h20 = function (context) {
    context.j1z_1.l1d(this.jw().kn_1, this.jw().ln_1);
    context.j1z_1.o1d(this.w20().i1i_1);
    context.j1z_1.l1d(-this.jw().kn_1, -this.jw().ln_1);
    if (this.y4c_1 && !(this.z4c_1 == null)) {
      var tmp;
      if (context.m1z_1) {
        tmp = ensureNotNull(context.n1z_1).x1x_1;
      } else {
        tmp = this.c4d_1.l2h(this.y2c());
      }
      context.j1z_1.b1u(tmp);
      var rect = Companion_instance_3.p1h(this.jw(), ensureNotNull(this.z4c_1).u1e_1, ensureNotNull(this.z4c_1).v1e_1);
      context.j1z_1.k1v(rect);
      context.j1z_1.e1u(this.l1u());
      context.j1z_1.j1v(rect);
    }
    if (!context.m1z_1) {
      var tmp_0;
      if (this.y4c_1 && !(this.z4c_1 == null)) {
        tmp_0 = this.c4d_1.l2h(this.z2c());
      } else {
        tmp_0 = this.c4d_1.l2h(this.y2c());
      }
      context.j1z_1.b1u(tmp_0);
    }
    this.x4c_1.h20(context);
    context.j1z_1.l1d(this.jw().kn_1, this.jw().ln_1);
    context.j1z_1.o1d(-this.w20().i1i_1);
    context.j1z_1.l1d(-this.jw().kn_1, -this.jw().ln_1);
  };
  protoOf(LabelComponent).f2i = function (x) {
    protoOf(AbstractRectangularComponent).f2i.call(this, x);
    this.x4c_1.f2i(x);
  };
  protoOf(LabelComponent).g2i = function (y) {
    protoOf(AbstractRectangularComponent).g2i.call(this, y);
    this.x4c_1.g2i(y);
  };
  protoOf(LabelComponent).v20 = function (value) {
    this.x4c_1.v20(value);
  };
  protoOf(LabelComponent).jw = function () {
    return this.x4c_1.d45_1;
  };
  protoOf(LabelComponent).h38 = function (writer) {
    writer.j39('id', this.cv());
    if (!this.a4d_1.qv()) {
      writer.h39('text', this.a4d_1.p45());
    }
    writer.t39('location', this.x4c_1.d45_1);
    writer.m39('rot', this.w20().h1i_1);
    if (this.y4c_1) {
      writer.o39('inverse', this.y4c_1);
    }
    var tmp0_safe_receiver = this.z4c_1;
    if (tmp0_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      writer.k39('w', tmp0_safe_receiver.u1e_1);
      writer.k39('h', tmp0_safe_receiver.v1e_1);
    }
    if (!(this.k2d() == null)) {
      writer.m39('color', ensureNotNull(this.k2d()).m2());
    }
  };
  protoOf(LabelComponent).i38 = function (reader) {
    if (reader.t35('id')) {
      this.a3b(reader.p38('id'));
    }
    if (reader.t35('text')) {
      this.v4a(TranslatableText_init_$Create$(reader.r38('text')));
    }
    if (reader.u35('text')) {
      this.v4a(new TranslatableText(reader.n38('text')));
    }
    this.v20(reader.y38('location'));
    if (reader.t35('rot')) {
      this.m28(Companion_instance_1.h1f(reader.r38('rot')));
    }
    if (reader.t35('inverse')) {
      this.e4d(reader.t38('inverse'));
    }
    if (reader.t35('w') && reader.t35('h')) {
      this.z4c_1 = new Dimension2D(reader.q38('w'), reader.q38('h'));
    }
    if (reader.t35('color')) {
      this.j2d(this.x2c().q2t().g2o(reader.r38('color')));
    }
  };
  protoOf(LabelComponent).k1a = function () {
    return this.d4d_1;
  };
  protoOf(LabelComponent).f3b = function () {
    return SelectionDrawingStrategy_REPLACE_getInstance();
  };
  protoOf(LabelComponent).n2i = function () {
    return true;
  };
  protoOf(LabelComponent).d3n = function (newRotation) {
    this.x4c_1.h45_1 = this.w20();
  };
  function calculateRotation($this, label) {
    var tmp;
    switch (label.h45_1.l1i(label.y44_1).l2_1) {
      case 0:
        tmp = Rotation_R0_getInstance();
        break;
      case 2:
        tmp = Rotation_R180_getInstance();
        break;
      case 1:
        tmp = Rotation_R0_getInstance();
        break;
      case 3:
        tmp = Rotation_R180_getInstance();
        break;
      default:
        noWhenBranchMatchedException();
        break;
    }
    return tmp;
  }
  function RotationDisplayStrategy$IGNORE() {
    RotationDisplayStrategy.call(this, 'IGNORE', 0);
    RotationDisplayStrategy_IGNORE_instance = this;
  }
  protoOf(RotationDisplayStrategy$IGNORE).g4c = function (context, label) {
  };
  protoOf(RotationDisplayStrategy$IGNORE).h4c = function (context, label) {
  };
  var RotationDisplayStrategy_IGNORE_instance;
  function RotationDisplayStrategy$ROTATE_HALF() {
    RotationDisplayStrategy.call(this, 'ROTATE_HALF', 1);
    RotationDisplayStrategy_ROTATE_HALF_instance = this;
  }
  protoOf(RotationDisplayStrategy$ROTATE_HALF).g4c = function (context, label) {
    var pivot = label.y44_1.o1i(label.d45_1, label.j45_1.d1d());
    context.j1z_1.m1d(pivot);
    context.j1z_1.o1d(calculateRotation(this, label).i1i_1);
    context.j1z_1.m1d(pivot.c1h());
  };
  protoOf(RotationDisplayStrategy$ROTATE_HALF).h4c = function (context, label) {
    var pivot = label.y44_1.o1i(label.d45_1, label.j45_1.d1d());
    context.j1z_1.m1d(pivot);
    context.j1z_1.o1d(calculateRotation(this, label).i1i_1);
    context.j1z_1.m1d(pivot.c1h());
  };
  var RotationDisplayStrategy_ROTATE_HALF_instance;
  function RotationDisplayStrategy$KEEP_HORIZONTAL() {
    RotationDisplayStrategy.call(this, 'KEEP_HORIZONTAL', 2);
    RotationDisplayStrategy_KEEP_HORIZONTAL_instance = this;
  }
  protoOf(RotationDisplayStrategy$KEEP_HORIZONTAL).g4c = function (context, label) {
    var pivot = label.y44_1.o1i(label.d45_1, label.j45_1.d1d());
    context.j1z_1.m1d(pivot);
    context.j1z_1.o1d(-label.h45_1.i1i_1);
    context.j1z_1.m1d(pivot.c1h());
  };
  protoOf(RotationDisplayStrategy$KEEP_HORIZONTAL).h4c = function (context, label) {
    var pivot = label.y44_1.o1i(label.d45_1, label.j45_1.d1d());
    context.j1z_1.m1d(pivot);
    context.j1z_1.o1d(label.h45_1.i1i_1);
    context.j1z_1.m1d(pivot.c1h());
  };
  var RotationDisplayStrategy_KEEP_HORIZONTAL_instance;
  var RotationDisplayStrategy_entriesInitialized;
  function RotationDisplayStrategy_initEntries() {
    if (RotationDisplayStrategy_entriesInitialized)
      return Unit_instance;
    RotationDisplayStrategy_entriesInitialized = true;
    RotationDisplayStrategy_IGNORE_instance = new RotationDisplayStrategy$IGNORE();
    RotationDisplayStrategy_ROTATE_HALF_instance = new RotationDisplayStrategy$ROTATE_HALF();
    RotationDisplayStrategy_KEEP_HORIZONTAL_instance = new RotationDisplayStrategy$KEEP_HORIZONTAL();
  }
  function RotationDisplayStrategy(name, ordinal) {
    Enum.call(this, name, ordinal);
  }
  function RotationDisplayStrategy_IGNORE_getInstance() {
    RotationDisplayStrategy_initEntries();
    return RotationDisplayStrategy_IGNORE_instance;
  }
  function RotationDisplayStrategy_ROTATE_HALF_getInstance() {
    RotationDisplayStrategy_initEntries();
    return RotationDisplayStrategy_ROTATE_HALF_instance;
  }
  function RotationDisplayStrategy_KEEP_HORIZONTAL_getInstance() {
    RotationDisplayStrategy_initEntries();
    return RotationDisplayStrategy_KEEP_HORIZONTAL_instance;
  }
  function Companion_32() {
    this.l4d_1 = 16;
  }
  var Companion_instance_37;
  function Companion_getInstance_42() {
    return Companion_instance_37;
  }
  function _get_displayedText__nja87x($this) {
    return $this.a4e_1.qv() ? '' : $this.a4e_1.m45();
  }
  function updateMultilineText($this) {
    $this.b4e_1 = createMultilineText($this);
  }
  function createMultilineText($this) {
    return Companion_getInstance_4().j2h(_get_displayedText__nja87x($this), $this.b2d(), numberToInt($this.f1c()) - imul(2, Companion_getInstance_36().e4a_1) | 0);
  }
  function SimpleTextComponent(text, location, styleType, styleProvider) {
    text = text === VOID ? new TranslatableText() : text;
    location = location === VOID ? Companion_getInstance().w1a_1 : location;
    styleType = styleType === VOID ? Companion_getInstance_0().b1y_1 : styleType;
    styleProvider = styleProvider === VOID ? DrawStyleModule_getInstance().w1x_1 : styleProvider;
    var tmp0_shape = new Rectangle2D(location.kn_1, location.ln_1, 100.0, 50.0);
    AbstractTextComponent.call(this, VOID, tmp0_shape, styleType, styleProvider);
    this.a4e_1 = text;
    this.b4e_1 = createMultilineText(this);
    updateMultilineText(this);
  }
  protoOf(SimpleTextComponent).v4a = function (value) {
    if (!equals(this.a4e_1, value)) {
      this.i20();
      this.a4e_1 = value;
      updateMultilineText(this);
      this.i20();
      this.l20();
      this.k20();
    }
  };
  protoOf(SimpleTextComponent).u4a = function () {
    return this.a4e_1;
  };
  protoOf(SimpleTextComponent).h20 = function (context) {
    if (this.f2d()) {
      this.t4a_1.c4e(this, context);
    }
    context.j1z_1.m1u(this.b2d());
    context.j1z_1.b1u(this.a2d());
    var tmp2 = this.p1a() + Companion_getInstance_36().e4a_1;
    // Inline function 'io.antarescircuit.jabbah.draw.DrawContext.translated' call
    var dy = this.q1a() + Companion_getInstance_36().f4a_1 + 16;
    context.j1z_1.l1d(tmp2, dy);
    this.b4e_1.h20(context);
    context.j1z_1.l1d(-tmp2, -dy);
    if (this.h2d()) {
      this.t4a_1.d4e(this, context);
    }
  };
  protoOf(SimpleTextComponent).l20 = function () {
    updateMultilineText(this);
    protoOf(AbstractTextComponent).l20.call(this);
  };
  function TextComponent() {
  }
  function UndefinedTextComponentFactory() {
  }
  function adjustShape($this, c) {
    $this.e4e_1.i1c(c.p1a(), c.q1a(), c.f1c(), c.h1c());
  }
  function RectangularShapeTextComponentDecorator(shape, stylable, transparent) {
    this.e4e_1 = shape;
    this.f4e_1 = stylable;
    this.g4e_1 = transparent;
  }
  protoOf(RectangularShapeTextComponentDecorator).c4e = function (component, context) {
    if (this.f4e_1.f2d()) {
      adjustShape(this, component);
      context.j1z_1.b1u(context.m1z_1 ? ensureNotNull(context.n1z_1).y1x_1 : this.g4e_1.l2h(this.f4e_1.z2c()));
      context.j1z_1.k1v(this.e4e_1);
    }
  };
  protoOf(RectangularShapeTextComponentDecorator).d4e = function (component, context) {
    adjustShape(this, component);
    context.j1z_1.b1u(context.m1z_1 ? ensureNotNull(context.n1z_1).x1x_1 : this.g4e_1.l2h(this.f4e_1.y2c()));
    context.j1z_1.e1u(this.f4e_1.l1u());
    context.j1z_1.j1v(this.e4e_1);
  };
  function TextDrawableButtonRenderer(text, dimension, style) {
    AbstractDrawableButtonRenderer.call(this);
    this.h4e_1 = dimension;
    this.i4e_1 = style;
    this.j4e_1 = new Label(text, this.i4e_1.b2d(), null);
  }
  protoOf(TextDrawableButtonRenderer).s1x = function () {
    return this.h4e_1;
  };
  protoOf(TextDrawableButtonRenderer).m2f = function (button, context) {
    var tmp;
    if (context.m1z_1) {
      tmp = ensureNotNull(context.n1z_1);
    } else {
      tmp = this.p2f(button);
    }
    var color = tmp;
    context.j1z_1.b1u(color.x1x_1);
    context.j1z_1.e1u(this.i4e_1.l1u());
    context.j1z_1.j1v(button.a2c());
    context.j1z_1.m1d(button.a2c().d1d());
    this.j4e_1.x44_1 = color.z1x_1;
    this.j4e_1.h20(context);
    context.j1z_1.m1d(button.a2c().d1d().c1h());
  };
  function ScriptProperty(script) {
    script = script === VOID ? null : script;
    this.k4e_1 = script;
  }
  protoOf(ScriptProperty).l4e = function () {
    return StringUtils_getInstance().lu(this.k4e_1);
  };
  protoOf(ScriptProperty).toString = function () {
    return 'ScriptProperty(script=' + this.k4e_1 + ')';
  };
  protoOf(ScriptProperty).hashCode = function () {
    return this.k4e_1 == null ? 0 : getStringHashCode(this.k4e_1);
  };
  protoOf(ScriptProperty).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof ScriptProperty))
      return false;
    if (!(this.k4e_1 == other.k4e_1))
      return false;
    return true;
  };
  function Translatable() {
  }
  function TranslatableText_init_$Init$(text, $this) {
    TranslatableText_init_$Init$_1(System_getInstance().hm(), text, $this);
    return $this;
  }
  function TranslatableText_init_$Create$(text) {
    return TranslatableText_init_$Init$(text, objectCreate(protoOf(TranslatableText)));
  }
  function TranslatableText_init_$Init$_0(translation, $this) {
    TranslatableText.call($this, listOf(translation));
    return $this;
  }
  function TranslatableText_init_$Create$_0(translation) {
    return TranslatableText_init_$Init$_0(translation, objectCreate(protoOf(TranslatableText)));
  }
  function TranslatableText_init_$Init$_1(language, text, $this) {
    TranslatableText.call($this, listOf(new Translation(language, text)));
    return $this;
  }
  function TranslatableText(translations) {
    translations = translations === VOID ? null : translations;
    var tmp = this;
    // Inline function 'kotlin.collections.mutableMapOf' call
    tmp.n45_1 = LinkedHashMap_init_$Create$();
    if (translations == null)
      null;
    else {
      // Inline function 'kotlin.collections.forEach' call
      var _iterator__ex2g4s = translations.i();
      while (_iterator__ex2g4s.j()) {
        var element = _iterator__ex2g4s.k();
        var tmp0 = this.n45_1;
        // Inline function 'kotlin.collections.set' call
        var key = element.r4e_1;
        tmp0.y1(key, element);
      }
    }
  }
  protoOf(TranslatableText).toString = function () {
    var tmp0_elvis_lhs = this.p4e();
    return tmp0_elvis_lhs == null ? '' : tmp0_elvis_lhs;
  };
  protoOf(TranslatableText).equals = function (other) {
    if (this === other)
      return true;
    if (other == null)
      return false;
    if (!getKClassFromExpression(this).equals(getKClassFromExpression(other)))
      return false;
    if (!(other instanceof TranslatableText))
      THROW_CCE();
    if (!equals(this.n45_1, other.n45_1))
      return false;
    return true;
  };
  protoOf(TranslatableText).hashCode = function () {
    return hashCode(this.n45_1);
  };
  protoOf(TranslatableText).qv = function () {
    var tmp0 = this.n45_1.c2();
    var tmp$ret$0;
    $l$block_0: {
      // Inline function 'kotlin.collections.all' call
      var tmp;
      if (isInterface(tmp0, Collection)) {
        tmp = tmp0.m();
      } else {
        tmp = false;
      }
      if (tmp) {
        tmp$ret$0 = true;
        break $l$block_0;
      }
      var _iterator__ex2g4s = tmp0.i();
      while (_iterator__ex2g4s.j()) {
        var element = _iterator__ex2g4s.k();
        // Inline function 'kotlin.text.isEmpty' call
        var this_0 = element.s4e_1;
        if (!(charSequenceLength(this_0) === 0)) {
          tmp$ret$0 = false;
          break $l$block_0;
        }
      }
      tmp$ret$0 = true;
    }
    return tmp$ret$0;
  };
  protoOf(TranslatableText).m4e = function (language) {
    var tmp0_elvis_lhs = this.q4e(language);
    var tmp;
    if (tmp0_elvis_lhs == null) {
      throw IllegalArgumentException_init_$Create$('no translation available');
    } else {
      tmp = tmp0_elvis_lhs;
    }
    return tmp;
  };
  protoOf(TranslatableText).o4e = function (language, text) {
    // Inline function 'kotlin.require' call
    if (!StringUtils_getInstance().lu(text)) {
      var message = 'text must not be empty';
      throw IllegalArgumentException_init_$Create$(toString(message));
    }
    var values = toMutableMap(this.n45_1);
    // Inline function 'kotlin.collections.set' call
    var value = new Translation(language, text);
    values.y1(language, value);
    return new TranslatableText(values.c2());
  };
  protoOf(TranslatableText).q4e = function (language) {
    var tmp0_safe_receiver = this.n45_1.g2(language);
    var tmp1_elvis_lhs = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.s4e_1;
    var tmp;
    if (tmp1_elvis_lhs == null) {
      var tmp2_safe_receiver = this.n45_1.g2(Companion_getInstance_5().zu_1);
      tmp = tmp2_safe_receiver == null ? null : tmp2_safe_receiver.s4e_1;
    } else {
      tmp = tmp1_elvis_lhs;
    }
    var tmp3_elvis_lhs = tmp;
    var tmp_0;
    if (tmp3_elvis_lhs == null) {
      var tmp4_safe_receiver = firstOrNull(this.n45_1.c2());
      tmp_0 = tmp4_safe_receiver == null ? null : tmp4_safe_receiver.s4e_1;
    } else {
      tmp_0 = tmp3_elvis_lhs;
    }
    return tmp_0;
  };
  protoOf(TranslatableText).p45 = function () {
    return this.n45_1.c2().i();
  };
  function Companion_33() {
  }
  protoOf(Companion_33).u4e = function (key) {
    return new Translation(System_getInstance().hm(), Translations_getInstance().bn(key, []));
  };
  var Companion_instance_38;
  function Companion_getInstance_43() {
    return Companion_instance_38;
  }
  function Translation(language, text) {
    language = language === VOID ? Companion_getInstance_5().zu_1 : language;
    text = text === VOID ? '' : text;
    this.r4e_1 = language;
    this.s4e_1 = text;
    this.t4e_1 = false;
  }
  protoOf(Translation).e38 = function (_set____db54di) {
    this.t4e_1 = _set____db54di;
  };
  protoOf(Translation).f38 = function () {
    return this.t4e_1;
  };
  protoOf(Translation).d38 = function () {
    return false;
  };
  protoOf(Translation).h38 = function (writer) {
    writer.m39('lang', this.r4e_1.qm_1);
    writer.m39('text', this.s4e_1);
  };
  protoOf(Translation).i38 = function (reader) {
    this.r4e_1 = Companion_getInstance_5().bv(reader.r38('lang'));
    this.s4e_1 = reader.r38('text');
  };
  protoOf(Translation).a38 = function (reference, referenceResolver) {
  };
  protoOf(Translation).equals = function (other) {
    if (this === other)
      return true;
    if (other == null)
      return false;
    if (!getKClassFromExpression(this).equals(getKClassFromExpression(other)))
      return false;
    if (!(other instanceof Translation))
      THROW_CCE();
    if (!this.r4e_1.equals(other.r4e_1))
      return false;
    if (!(this.s4e_1 === other.s4e_1))
      return false;
    return true;
  };
  protoOf(Translation).hashCode = function () {
    var result = this.r4e_1.hashCode();
    result = imul(31, result) + getStringHashCode(this.s4e_1) | 0;
    return result;
  };
  protoOf(Translation).toString = function () {
    return '[' + this.r4e_1.qm_1 + "]='" + this.s4e_1 + "'";
  };
  function Companion_34() {
  }
  protoOf(Companion_34).v4e = function (externalName, reader, orElse) {
    if (reader.u35(externalName)) {
      return new Description(new TranslatableText(reader.n38(externalName)));
    }
    return orElse;
  };
  protoOf(Companion_34).x45 = function (externalName, reader, orElse, $super) {
    orElse = orElse === VOID ? Description_init_$Create$('') : orElse;
    return $super === VOID ? this.v4e(externalName, reader, orElse) : $super.v4e.call(this, externalName, reader, orElse);
  };
  var Companion_instance_39;
  function Companion_getInstance_44() {
    return Companion_instance_39;
  }
  function Description_init_$Init$(value, $this) {
    value = value === VOID ? '' : value;
    Description.call($this, TranslatableText_init_$Create$(value));
    return $this;
  }
  function Description_init_$Create$(value) {
    return Description_init_$Init$(value, objectCreate(protoOf(Description)));
  }
  function Description$toString$lambda(it) {
    return it.toString();
  }
  function Description(text) {
    text = text === VOID ? new TranslatableText() : text;
    this.w45_1 = text;
  }
  protoOf(Description).j2 = function () {
    return this.w45_1.p4e();
  };
  protoOf(Description).i41 = function (externalName, writer) {
    if (this.w45_1.y45()) {
      writer.h39(externalName, this.w45_1.p45());
    }
  };
  protoOf(Description).equals = function (other) {
    if (this === other)
      return true;
    if (other == null || !getKClassFromExpression(this).equals(getKClassFromExpression(other)))
      return false;
    if (!(other instanceof Description))
      THROW_CCE();
    if (!this.w45_1.equals(other.w45_1))
      return false;
    return true;
  };
  protoOf(Description).hashCode = function () {
    return this.w45_1.hashCode();
  };
  protoOf(Description).toString = function () {
    var tmp = asSequence(this.p45());
    return joinToString(tmp, VOID, VOID, VOID, VOID, VOID, Description$toString$lambda);
  };
  protoOf(Description).qv = function () {
    return this.w45_1.qv();
  };
  protoOf(Description).m4e = function (language) {
    return this.w45_1.m4e(language);
  };
  protoOf(Description).o4e = function (language, text) {
    return new Description(this.w45_1.o4e(language, text));
  };
  protoOf(Description).q4e = function (language) {
    return this.w45_1.q4e(language);
  };
  protoOf(Description).p45 = function () {
    return this.w45_1.p45();
  };
  function Describable() {
  }
  function observableDescription(initialValue, changeHandler) {
    initialValue = initialValue === VOID ? Description_init_$Create$('') : initialValue;
    var tmp;
    if (changeHandler === VOID) {
      tmp = observableDescription$lambda;
    } else {
      tmp = changeHandler;
    }
    changeHandler = tmp;
    return new observableDescription$3(initialValue, changeHandler);
  }
  function DescriptionChangedEvent(owner, description, oldValue) {
    this.w4e_1 = owner;
    this.x4e_1 = description;
    this.y4e_1 = oldValue;
  }
  protoOf(DescriptionChangedEvent).toString = function () {
    return 'DescriptionChangedEvent(owner=' + toString(this.w4e_1) + ', description=' + this.x4e_1.toString() + ', oldValue=' + this.y4e_1.toString() + ')';
  };
  protoOf(DescriptionChangedEvent).hashCode = function () {
    var result = hashCode(this.w4e_1);
    result = imul(result, 31) + this.x4e_1.hashCode() | 0;
    result = imul(result, 31) + this.y4e_1.hashCode() | 0;
    return result;
  };
  protoOf(DescriptionChangedEvent).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof DescriptionChangedEvent))
      return false;
    if (!equals(this.w4e_1, other.w4e_1))
      return false;
    if (!this.x4e_1.equals(other.x4e_1))
      return false;
    if (!this.y4e_1.equals(other.y4e_1))
      return false;
    return true;
  };
  function observableDescription$lambda(it) {
    return Unit_instance;
  }
  function observableDescription$3($initialValue, $changeHandler) {
    this.a4f_1 = $changeHandler;
    ObservableProperty.call(this, $initialValue);
  }
  protoOf(observableDescription$3).b4f = function (thisRef, property, value) {
    var oldValue = this.vf(thisRef, property);
    protoOf(ObservableProperty).xf.call(this, thisRef, property, value);
    var tmp;
    if (!(!(thisRef == null) ? isInterface(thisRef, Storable) : false)) {
      tmp = true;
    } else {
      tmp = !thisRef.f38();
    }
    if (tmp) {
      var tmp_0 = BaseModule_getInstance().bp_1;
      tmp_0.gu(new DescriptionChangedEvent((!(thisRef == null) ? isInterface(thisRef, Describable) : false) ? thisRef : THROW_CCE(), value, oldValue));
    }
    this.a4f_1(value);
  };
  protoOf(observableDescription$3).yf = function (thisRef, property, value) {
    return this.b4f(thisRef, property, value instanceof Description ? value : THROW_CCE());
  };
  protoOf(observableDescription$3).xf = function (thisRef, property, value) {
    return this.b4f(thisRef, property, value instanceof Description ? value : THROW_CCE());
  };
  function Namable() {
  }
  function Companion_35() {
  }
  protoOf(Companion_35).c4f = function (externalName, reader, orElse) {
    if (reader.u35(externalName)) {
      return new Name(new TranslatableText(reader.n38(externalName)));
    }
    return orElse;
  };
  protoOf(Companion_35).g41 = function (externalName, reader, orElse, $super) {
    orElse = orElse === VOID ? Name_init_$Create$('') : orElse;
    return $super === VOID ? this.c4f(externalName, reader, orElse) : $super.c4f.call(this, externalName, reader, orElse);
  };
  var Companion_instance_40;
  function Companion_getInstance_45() {
    return Companion_instance_40;
  }
  function Name_init_$Init$(value, $this) {
    value = value === VOID ? '' : value;
    Name.call($this, TranslatableText_init_$Create$(value));
    return $this;
  }
  function Name_init_$Create$(value) {
    return Name_init_$Init$(value, objectCreate(protoOf(Name)));
  }
  function Name(text) {
    text = text === VOID ? new TranslatableText() : text;
    this.h41_1 = text;
  }
  protoOf(Name).j2 = function () {
    return this.h41_1.m45();
  };
  protoOf(Name).i41 = function (externalName, writer) {
    if (!this.h41_1.qv()) {
      writer.h39(externalName, this.h41_1.p45());
    }
  };
  protoOf(Name).toString = function () {
    return this.j2();
  };
  protoOf(Name).equals = function (other) {
    if (this === other)
      return true;
    if (other == null || !getKClassFromExpression(this).equals(getKClassFromExpression(other)))
      return false;
    if (!(other instanceof Name))
      THROW_CCE();
    if (!this.h41_1.equals(other.h41_1))
      return false;
    return true;
  };
  protoOf(Name).hashCode = function () {
    return this.h41_1.hashCode();
  };
  protoOf(Name).qv = function () {
    return this.h41_1.qv();
  };
  protoOf(Name).m4e = function (language) {
    return this.h41_1.m4e(language);
  };
  protoOf(Name).o4e = function (language, text) {
    return new Name(this.h41_1.o4e(language, text));
  };
  protoOf(Name).q4e = function (language) {
    return this.h41_1.q4e(language);
  };
  protoOf(Name).p45 = function () {
    return this.h41_1.p45();
  };
  function observableName(initialValue, handler) {
    var tmp;
    if (handler === VOID) {
      tmp = observableName$lambda;
    } else {
      tmp = handler;
    }
    handler = tmp;
    return new observableName$3(initialValue, handler);
  }
  function NameChangedEvent(owner, name, oldValue) {
    this.d4f_1 = owner;
    this.e4f_1 = name;
    this.f4f_1 = oldValue;
  }
  protoOf(NameChangedEvent).toString = function () {
    return 'NameChangedEvent(owner=' + toString(this.d4f_1) + ', name=' + this.e4f_1.toString() + ', oldValue=' + this.f4f_1.toString() + ')';
  };
  protoOf(NameChangedEvent).hashCode = function () {
    var result = hashCode(this.d4f_1);
    result = imul(result, 31) + this.e4f_1.hashCode() | 0;
    result = imul(result, 31) + this.f4f_1.hashCode() | 0;
    return result;
  };
  protoOf(NameChangedEvent).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof NameChangedEvent))
      return false;
    if (!equals(this.d4f_1, other.d4f_1))
      return false;
    if (!this.e4f_1.equals(other.e4f_1))
      return false;
    if (!this.f4f_1.equals(other.f4f_1))
      return false;
    return true;
  };
  function observableName$lambda(it) {
    return Unit_instance;
  }
  function observableName$3($initialValue, $handler) {
    this.h4f_1 = $handler;
    ObservableProperty.call(this, $initialValue);
  }
  protoOf(observableName$3).i4f = function (thisRef, property, value) {
    var oldValue = this.vf(thisRef, property);
    protoOf(ObservableProperty).xf.call(this, thisRef, property, value);
    this.h4f_1(value);
    var tmp;
    if (!(!(thisRef == null) ? isInterface(thisRef, Storable) : false)) {
      tmp = true;
    } else {
      tmp = !thisRef.f38();
    }
    if (tmp) {
      var tmp_0 = BaseModule_getInstance().bp_1;
      tmp_0.gu(new NameChangedEvent((!(thisRef == null) ? isInterface(thisRef, Namable) : false) ? thisRef : THROW_CCE(), value, oldValue));
    }
  };
  protoOf(observableName$3).yf = function (thisRef, property, value) {
    return this.i4f(thisRef, property, value instanceof Name ? value : THROW_CCE());
  };
  protoOf(observableName$3).xf = function (thisRef, property, value) {
    return this.i4f(thisRef, property, value instanceof Name ? value : THROW_CCE());
  };
  function configureTypeMap($this, typeMap) {
    typeMap.j37('drawing', getKClass(DrawingImpl));
    typeMap.j37('rectangle', getKClass(RectangleComponent));
    typeMap.j37('ellipse', getKClass(EllipseComponent));
    typeMap.j37('roundrect', getKClass(RoundRectangleComponent));
    typeMap.j37('polyline', getKClass(PolylineComponent));
    typeMap.j37('label', getKClass(LabelComponent));
    typeMap.j37('text', getKClass(SimpleTextComponent));
    typeMap.j37('group', getKClass(GroupComponent));
    typeMap.j37('quadCurve', getKClass(QuadCurveComponent));
    typeMap.j37('cubicCurve', getKClass(CubicCurveComponent));
    typeMap.j37('translation', getKClass(Translation));
    typeMap.j37('image', getKClass(ImageComponent));
  }
  function fillProperties_0($this, properties) {
    properties.et('edit.view.AttentionDrawer.color', Companion_getInstance_3().g1t_1);
    properties.et('edit.view.AttentionDrawer.duration', 500.0);
    properties.et('edit.view.AttentionDrawer.maxRadius', 30.0);
    properties.et('edit.commandManager.cmdPerSnapshot', 10);
    properties.et('ComponentPropertyPanelController.maxMultiSelectCount', 8);
  }
  function EditModule$drawingViewFactory$1() {
  }
  protoOf(EditModule$drawingViewFactory$1).j4f = function (drawing, contextHolder, displayGlobalMessages, name) {
    return new DrawingViewImpl(drawing, VOID, contextHolder, displayGlobalMessages, VOID, VOID, VOID, VOID, VOID, name);
  };
  function EditModule$drawingViewSearchFactory$lambda() {
    return new DrawingViewSearch();
  }
  function EditModule$attentionDrawerFactory$lambda(it) {
    return new AttentionDrawerImpl();
  }
  function EditModule$imageRepository$1() {
  }
  protoOf(EditModule$imageRepository$1).n40 = function (uuid) {
    return null;
  };
  function EditModule() {
    EditModule_instance = this;
    AbstractModule.call(this);
    this.v3f_1 = new SourcingCommandManager();
    var tmp = this;
    tmp.w3f_1 = new EditModule$drawingViewFactory$1();
    var tmp_0 = this;
    tmp_0.x3f_1 = EditModule$drawingViewSearchFactory$lambda;
    var tmp_1 = this;
    tmp_1.y3f_1 = EditModule$attentionDrawerFactory$lambda;
    this.z3f_1 = new CopyPasteService();
    this.a3g_1 = new DrawingServiceImpl();
    this.b3g_1 = new DrawingAppServiceImpl();
    var tmp_2 = this;
    tmp_2.c3g_1 = new EditModule$imageRepository$1();
  }
  protoOf(EditModule).to = function () {
    DrawModule_getInstance().vo();
    EditModelRectangleModule_getInstance().vo();
    EditModelPolylineModule_getInstance().vo();
    EditModelTextModule_getInstance().vo();
    EditModelGroupModule_getInstance().vo();
    EditModuleCurveModule_getInstance().vo();
    EditSnapModule_getInstance().vo();
    EditDragModule_getInstance().vo();
    EditSelectModule_getInstance().vo();
    EditEditorModule_getInstance().vo();
    EditAuthModule_getInstance().vo();
    Translations_getInstance().wm('jabbah-edit');
    Themes_getInstance().u2t([new EditTheme()]);
    configureTypeMap(this, IOModule_getInstance().e36_1);
    fillProperties_0(this, BaseModule_getInstance().zo_1);
  };
  var EditModule_instance;
  function EditModule_getInstance() {
    if (EditModule_instance == null)
      new EditModule();
    return EditModule_instance;
  }
  function PropertyValueException(msg, event) {
    IllegalArgumentException_init_$Init$(msg, this);
    captureStack(this, PropertyValueException);
    this.k4f_1 = event;
  }
  var Magnitude_Pico_instance;
  var Magnitude_Nano_instance;
  var Magnitude_Micro_instance;
  var Magnitude_Milli_instance;
  var Magnitude_One_instance;
  var Magnitude_Kilo_instance;
  var Magnitude_Mega_instance;
  var Magnitude_Giga_instance;
  var Magnitude_Tera_instance;
  function Companion_36() {
  }
  protoOf(Companion_36).l4f = function (name) {
    var tmp0 = get_entries_0();
    var tmp$ret$0;
    $l$block: {
      // Inline function 'kotlin.collections.firstOrNull' call
      var _iterator__ex2g4s = tmp0.i();
      while (_iterator__ex2g4s.j()) {
        var element = _iterator__ex2g4s.k();
        if (element.o4f_1 === name) {
          tmp$ret$0 = element;
          break $l$block;
        }
      }
      tmp$ret$0 = null;
    }
    var tmp0_elvis_lhs = tmp$ret$0;
    var tmp;
    if (tmp0_elvis_lhs == null) {
      throw IllegalArgumentException_init_$Create$(Translations_getInstance().bn('edit.magnitude.unknown.text', [name]));
    } else {
      tmp = tmp0_elvis_lhs;
    }
    return tmp;
  };
  protoOf(Companion_36).t4f = function (name, reader) {
    var tmp;
    if (reader.t35(name)) {
      tmp = this.l4f(reader.r38(name));
    } else {
      tmp = Magnitude_One_getInstance();
    }
    return tmp;
  };
  var Companion_instance_41;
  function Companion_getInstance_46() {
    return Companion_instance_41;
  }
  function values_2() {
    return [Magnitude_Pico_getInstance(), Magnitude_Nano_getInstance(), Magnitude_Micro_getInstance(), Magnitude_Milli_getInstance(), Magnitude_One_getInstance(), Magnitude_Kilo_getInstance(), Magnitude_Mega_getInstance(), Magnitude_Giga_getInstance(), Magnitude_Tera_getInstance()];
  }
  function get_entries_0() {
    if ($ENTRIES_0 == null)
      $ENTRIES_0 = enumEntries(values_2());
    return $ENTRIES_0;
  }
  var Magnitude_entriesInitialized;
  function Magnitude_initEntries() {
    if (Magnitude_entriesInitialized)
      return Unit_instance;
    Magnitude_entriesInitialized = true;
    Magnitude_Pico_instance = new Magnitude('Pico', 0, 'p', 1000000000000n, true);
    Magnitude_Nano_instance = new Magnitude('Nano', 1, 'n', 1000000000n, true, VOID, 'n');
    Magnitude_Micro_instance = new Magnitude('Micro', 2, 'u', 1000000n, true, VOID, '\xB5');
    Magnitude_Milli_instance = new Magnitude('Milli', 3, 'm', 1000n, true, true);
    Magnitude_One_instance = new Magnitude('One', 4, '', 1n);
    Magnitude_Kilo_instance = new Magnitude('Kilo', 5, 'K', 1000n);
    Magnitude_Mega_instance = new Magnitude('Mega', 6, 'M', 1000000n, VOID, true);
    Magnitude_Giga_instance = new Magnitude('Giga', 7, 'G', 1000000000n);
    Magnitude_Tera_instance = new Magnitude('Tera', 8, 'T', 1000000000000n);
  }
  var $ENTRIES_0;
  function Magnitude(name, ordinal, customName, factor, inverse, caseSensitive, denotation) {
    inverse = inverse === VOID ? false : inverse;
    caseSensitive = caseSensitive === VOID ? false : caseSensitive;
    denotation = denotation === VOID ? customName : denotation;
    Enum.call(this, name, ordinal);
    this.o4f_1 = customName;
    this.p4f_1 = factor;
    this.q4f_1 = inverse;
    this.r4f_1 = caseSensitive;
    this.s4f_1 = denotation;
  }
  protoOf(Magnitude).i41 = function (name, writer) {
    if (!this.equals(Magnitude_One_getInstance())) {
      writer.m39(name, this.o4f_1);
    }
  };
  function Magnitude_Pico_getInstance() {
    Magnitude_initEntries();
    return Magnitude_Pico_instance;
  }
  function Magnitude_Nano_getInstance() {
    Magnitude_initEntries();
    return Magnitude_Nano_instance;
  }
  function Magnitude_Micro_getInstance() {
    Magnitude_initEntries();
    return Magnitude_Micro_instance;
  }
  function Magnitude_Milli_getInstance() {
    Magnitude_initEntries();
    return Magnitude_Milli_instance;
  }
  function Magnitude_One_getInstance() {
    Magnitude_initEntries();
    return Magnitude_One_instance;
  }
  function Magnitude_Kilo_getInstance() {
    Magnitude_initEntries();
    return Magnitude_Kilo_instance;
  }
  function Magnitude_Mega_getInstance() {
    Magnitude_initEntries();
    return Magnitude_Mega_instance;
  }
  function Magnitude_Giga_getInstance() {
    Magnitude_initEntries();
    return Magnitude_Giga_instance;
  }
  function Magnitude_Tera_getInstance() {
    Magnitude_initEntries();
    return Magnitude_Tera_instance;
  }
  function Companion_37() {
    this.u4f_1 = 'Value';
    this.v4f_1 = 'Magnitude';
    this.w4f_1 = 'Unit';
    this.x4f_1 = 3;
  }
  protoOf(Companion_37).y4f = function (name, reader) {
    return new MagnitudeValue(reader.q38(name + 'Value'), Companion_instance_41.t4f(name + 'Magnitude', reader), Companion_instance_43.l4f(reader.r38(name + 'Unit')));
  };
  protoOf(Companion_37).z4f = function (name, reader, unit) {
    return new MagnitudeValue(reader.q38(name + 'Value'), Companion_instance_41.t4f(name + 'Magnitude', reader), unit);
  };
  var Companion_instance_42;
  function Companion_getInstance_47() {
    return Companion_instance_42;
  }
  function MagnitudeValue_init_$Init$(value, magnitude, unit, $this) {
    MagnitudeValue.call($this, toNumber(value), magnitude, unit);
    return $this;
  }
  function MagnitudeValue_init_$Create$(value, magnitude, unit) {
    return MagnitudeValue_init_$Init$(value, magnitude, unit, objectCreate(protoOf(MagnitudeValue)));
  }
  function ensureMinimumMagnitude($this, value, magnitude, unit) {
    var tmp;
    if (magnitude.l2_1 >= unit.e4g_1.l2_1) {
      tmp = new MagnitudeValue(value, magnitude, unit);
    } else {
      throw IllegalArgumentException_init_$Create$_0();
    }
    return tmp;
  }
  function truncate($this, value, snap) {
    if (value === 0.0) {
      return 0.0;
    }
    // Inline function 'kotlin.math.log10' call
    var x = value < 0 ? -value : value;
    // Inline function 'kotlin.math.ceil' call
    var x_0 = log10(x);
    var d = Math.ceil(x_0);
    // Inline function 'kotlin.math.pow' call
    var n = 3 - numberToInt(d) | 0;
    var factor = Math.pow(10.0, n);
    // Inline function 'kotlin.math.floor' call
    var x_1 = value * factor;
    var tmp$ret$3 = Math.floor(x_1);
    var shifted = numberToLong(tmp$ret$3);
    // Inline function 'kotlin.Long.div' call
    var truncated = toNumber(shifted) / factor;
    var tmp;
    if (snap) {
      var tmp_0;
      if (truncated < 10) {
        var tmp_1;
        if (truncated >= 9) {
          // Inline function 'kotlin.math.floor' call
          tmp_1 = Math.floor(value);
        } else {
          tmp_1 = round(value);
        }
        tmp_0 = tmp_1;
      } else if (truncated < 100) {
        var tmp_2;
        if (truncated >= 90) {
          // Inline function 'kotlin.math.floor' call
          var x_2 = truncated / 10;
          tmp_2 = Math.floor(x_2) * 10;
        } else {
          tmp_2 = round(truncated / 10) * 10;
        }
        tmp_0 = tmp_2;
      } else if (truncated < 1000) {
        var tmp_3;
        if (truncated >= 900) {
          // Inline function 'kotlin.math.floor' call
          var x_3 = truncated / 100;
          tmp_3 = Math.floor(x_3) * 100;
        } else {
          tmp_3 = round(truncated / 100) * 100;
        }
        tmp_0 = tmp_3;
      } else {
        tmp_0 = truncated;
      }
      tmp = tmp_0;
    } else {
      tmp = truncated;
    }
    return tmp;
  }
  function MagnitudeValue$baseValue$delegate$lambda(this$0) {
    return function () {
      var tmp;
      if (this$0.i4g_1.q4f_1) {
        tmp = this$0.h4g_1 / toNumber(this$0.i4g_1.p4f_1);
      } else {
        var tmp0 = this$0.i4g_1.p4f_1;
        // Inline function 'kotlin.Long.times' call
        var other = this$0.h4g_1;
        tmp = toNumber(tmp0) * other;
      }
      return tmp;
    };
  }
  function MagnitudeValue$_get_baseValue_$ref_nn3yzh() {
    return function (p0) {
      return p0.m4g();
    };
  }
  function MagnitudeValue$northBaseValue$delegate$lambda(this$0) {
    return function () {
      var tmp;
      if (this$0.i4g_1.q4f_1) {
        var tmp_0;
        if (this$0.m4g() < 10.0 / toNumber(this$0.i4g_1.p4f_1)) {
          tmp_0 = 1.0 / toNumber(this$0.i4g_1.p4f_1);
        } else if (this$0.m4g() < 100.0 / toNumber(this$0.i4g_1.p4f_1)) {
          tmp_0 = 10.0 / toNumber(this$0.i4g_1.p4f_1);
        } else {
          tmp_0 = 100.0 / toNumber(this$0.i4g_1.p4f_1);
        }
        tmp = tmp_0;
      } else {
        var tmp_1;
        if (this$0.m4g() < toNumber(multiply(numberToLong(10), this$0.i4g_1.p4f_1))) {
          tmp_1 = toNumber(this$0.i4g_1.p4f_1);
        } else if (this$0.m4g() < toNumber(multiply(numberToLong(100), this$0.i4g_1.p4f_1))) {
          tmp_1 = 10.0 * toNumber(this$0.i4g_1.p4f_1);
        } else {
          tmp_1 = 100.0 * toNumber(this$0.i4g_1.p4f_1);
        }
        tmp = tmp_1;
      }
      return tmp;
    };
  }
  function MagnitudeValue$_get_northBaseValue_$ref_tas6ua() {
    return function (p0) {
      return p0.n4g();
    };
  }
  function MagnitudeValue(value, magnitude, unit) {
    this.h4g_1 = value;
    this.i4g_1 = magnitude;
    this.j4g_1 = unit;
    if (this.i4g_1.l2_1 < this.j4g_1.e4g_1.l2_1) {
      throw IllegalArgumentException_init_$Create$(Translations_getInstance().bn('edit.magnitude.tooSmall.text', [this.i4g_1.o4f_1, this.j4g_1.c4g_1]));
    }
    var tmp = this;
    tmp.k4g_1 = lazy(MagnitudeValue$baseValue$delegate$lambda(this));
    var tmp_0 = this;
    tmp_0.l4g_1 = lazy(MagnitudeValue$northBaseValue$delegate$lambda(this));
  }
  protoOf(MagnitudeValue).o4g = function (value, snap) {
    return (new MagnitudeValue(value, Magnitude_One_getInstance(), this.j4g_1)).p4g(snap);
  };
  protoOf(MagnitudeValue).q4g = function (name, writer, writeUnit) {
    writer.k39(name + 'Value', this.h4g_1);
    this.i4g_1.i41(name + 'Magnitude', writer);
    if (writeUnit) {
      writer.m39(name + 'Unit', this.j4g_1.c4g_1);
    }
  };
  protoOf(MagnitudeValue).r4g = function (name, writer, writeUnit, $super) {
    writeUnit = writeUnit === VOID ? false : writeUnit;
    var tmp;
    if ($super === VOID) {
      this.q4g(name, writer, writeUnit);
      tmp = Unit_instance;
    } else {
      tmp = $super.q4g.call(this, name, writer, writeUnit);
    }
    return tmp;
  };
  protoOf(MagnitudeValue).toString = function () {
    var tmp;
    // Inline function 'kotlin.math.floor' call
    var x = this.h4g_1;
    if (Math.floor(x) === this.h4g_1) {
      tmp = numberToLong(this.h4g_1).toString() + ' ' + this.i4g_1.s4f_1 + this.j4g_1.d4g_1;
    } else {
      tmp = '' + this.h4g_1 + ' ' + this.i4g_1.s4f_1 + this.j4g_1.d4g_1;
    }
    return tmp;
  };
  protoOf(MagnitudeValue).m4g = function () {
    var tmp0 = this.k4g_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('baseValue', 1, tmp, MagnitudeValue$_get_baseValue_$ref_nn3yzh(), null);
    return tmp0.j2();
  };
  protoOf(MagnitudeValue).n4g = function () {
    var tmp0 = this.l4g_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('northBaseValue', 1, tmp, MagnitudeValue$_get_northBaseValue_$ref_tas6ua(), null);
    return tmp0.j2();
  };
  protoOf(MagnitudeValue).s4g = function (magnitude) {
    var tmp;
    if (magnitude.q4f_1) {
      tmp = this.m4g() * toNumber(magnitude.p4f_1);
    } else {
      tmp = this.m4g() / toNumber(magnitude.p4f_1);
    }
    return tmp;
  };
  protoOf(MagnitudeValue).p4g = function (snap) {
    if (this.m4g() >= 1) {
      return this.m4g() < toNumber(Magnitude_Kilo_getInstance().p4f_1) ? ensureMinimumMagnitude(this, truncate(this, this.m4g(), snap), Magnitude_One_getInstance(), this.j4g_1) : this.m4g() < toNumber(Magnitude_Mega_getInstance().p4f_1) ? ensureMinimumMagnitude(this, truncate(this, this.m4g() / toNumber(Magnitude_Kilo_getInstance().p4f_1), snap), Magnitude_Kilo_getInstance(), this.j4g_1) : this.m4g() < toNumber(Magnitude_Giga_getInstance().p4f_1) ? ensureMinimumMagnitude(this, truncate(this, this.m4g() / toNumber(Magnitude_Mega_getInstance().p4f_1), snap), Magnitude_Mega_getInstance(), this.j4g_1) : new MagnitudeValue(truncate(this, this.m4g() / toNumber(Magnitude_Giga_getInstance().p4f_1), snap), Magnitude_Giga_getInstance(), this.j4g_1);
    } else {
      return this.m4g() >= 1.0 / toNumber(Magnitude_Kilo_getInstance().p4f_1) ? ensureMinimumMagnitude(this, truncate(this, this.m4g() * toNumber(Magnitude_Kilo_getInstance().p4f_1), snap), Magnitude_Milli_getInstance(), this.j4g_1) : this.m4g() >= 1.0 / toNumber(Magnitude_Mega_getInstance().p4f_1) ? ensureMinimumMagnitude(this, truncate(this, this.m4g() * toNumber(Magnitude_Mega_getInstance().p4f_1), snap), Magnitude_Micro_getInstance(), this.j4g_1) : this.m4g() >= 1.0 / toNumber(Magnitude_Giga_getInstance().p4f_1) ? ensureMinimumMagnitude(this, truncate(this, this.m4g() * toNumber(Magnitude_Giga_getInstance().p4f_1), snap), Magnitude_Nano_getInstance(), this.j4g_1) : this.m4g() >= 1.0 / toNumber(Magnitude_Tera_getInstance().p4f_1) ? ensureMinimumMagnitude(this, truncate(this, this.m4g() * toNumber(Magnitude_Tera_getInstance().p4f_1), snap), Magnitude_Pico_getInstance(), this.j4g_1) : this;
    }
  };
  protoOf(MagnitudeValue).t4g = function (snap, $super) {
    snap = snap === VOID ? false : snap;
    return $super === VOID ? this.p4g(snap) : $super.p4g.call(this, snap);
  };
  protoOf(MagnitudeValue).u4g = function (value, magnitude, unit) {
    return new MagnitudeValue(value, magnitude, unit);
  };
  protoOf(MagnitudeValue).v4g = function (value, magnitude, unit, $super) {
    value = value === VOID ? this.h4g_1 : value;
    magnitude = magnitude === VOID ? this.i4g_1 : magnitude;
    unit = unit === VOID ? this.j4g_1 : unit;
    return $super === VOID ? this.u4g(value, magnitude, unit) : $super.u4g.call(this, value, magnitude, unit);
  };
  protoOf(MagnitudeValue).hashCode = function () {
    var result = getNumberHashCode(this.h4g_1);
    result = imul(result, 31) + this.i4g_1.hashCode() | 0;
    result = imul(result, 31) + this.j4g_1.hashCode() | 0;
    return result;
  };
  protoOf(MagnitudeValue).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof MagnitudeValue))
      return false;
    if (!equals(this.h4g_1, other.h4g_1))
      return false;
    if (!this.i4g_1.equals(other.i4g_1))
      return false;
    if (!this.j4g_1.equals(other.j4g_1))
      return false;
    return true;
  };
  var SIUnit_Factor_instance;
  var SIUnit_Ohm_instance;
  var SIUnit_Farad_instance;
  var SIUnit_Henry_instance;
  var SIUnit_Volt_instance;
  var SIUnit_Ampere_instance;
  var SIUnit_Second_instance;
  var SIUnit_Hertz_instance;
  function Companion_38() {
  }
  protoOf(Companion_38).l4f = function (name) {
    var tmp0 = get_entries_1();
    var tmp$ret$0;
    $l$block: {
      // Inline function 'kotlin.collections.firstOrNull' call
      var _iterator__ex2g4s = tmp0.i();
      while (_iterator__ex2g4s.j()) {
        var element = _iterator__ex2g4s.k();
        if (element.c4g_1 === name) {
          tmp$ret$0 = element;
          break $l$block;
        }
      }
      tmp$ret$0 = null;
    }
    var tmp0_elvis_lhs = tmp$ret$0;
    var tmp;
    if (tmp0_elvis_lhs == null) {
      throw IllegalArgumentException_init_$Create$(Translations_getInstance().bn('edit.magnitude.invalidUnit.text', [name]));
    } else {
      tmp = tmp0_elvis_lhs;
    }
    return tmp;
  };
  var Companion_instance_43;
  function Companion_getInstance_48() {
    return Companion_instance_43;
  }
  function values_3() {
    return [SIUnit_Factor_getInstance(), SIUnit_Ohm_getInstance(), SIUnit_Farad_getInstance(), SIUnit_Henry_getInstance(), SIUnit_Volt_getInstance(), SIUnit_Ampere_getInstance(), SIUnit_Second_getInstance(), SIUnit_Hertz_getInstance()];
  }
  function get_entries_1() {
    if ($ENTRIES_1 == null)
      $ENTRIES_1 = enumEntries(values_3());
    return $ENTRIES_1;
  }
  var SIUnit_entriesInitialized;
  function SIUnit_initEntries() {
    if (SIUnit_entriesInitialized)
      return Unit_instance;
    SIUnit_entriesInitialized = true;
    SIUnit_Factor_instance = new SIUnit('Factor', 0, 'Factor', 'x', Magnitude_One_getInstance(), Magnitude_One_getInstance());
    SIUnit_Ohm_instance = new SIUnit('Ohm', 1, 'Ohm', '\u03A9', Magnitude_One_getInstance(), Magnitude_One_getInstance());
    SIUnit_Farad_instance = new SIUnit('Farad', 2, 'Farad', 'F', Magnitude_Pico_getInstance(), Magnitude_Micro_getInstance());
    SIUnit_Henry_instance = new SIUnit('Henry', 3, 'Henry', 'H', Magnitude_Nano_getInstance(), Magnitude_One_getInstance());
    SIUnit_Volt_instance = new SIUnit('Volt', 4, 'Volt', 'V', Magnitude_Micro_getInstance(), Magnitude_One_getInstance(), true);
    SIUnit_Ampere_instance = new SIUnit('Ampere', 5, 'Amp\xE8re', 'A', Magnitude_Micro_getInstance(), Magnitude_Milli_getInstance(), true);
    SIUnit_Second_instance = new SIUnit('Second', 6, 'Second', 's', Magnitude_Nano_getInstance(), Magnitude_Nano_getInstance());
    SIUnit_Hertz_instance = new SIUnit('Hertz', 7, 'Hertz', 'Hz', Magnitude_One_getInstance(), Magnitude_One_getInstance());
  }
  var $ENTRIES_1;
  function SIUnit(name, ordinal, customName, symbol, minimumMagnitude, defaultMagnitude, allowNegative) {
    allowNegative = allowNegative === VOID ? false : allowNegative;
    Enum.call(this, name, ordinal);
    this.c4g_1 = customName;
    this.d4g_1 = symbol;
    this.e4g_1 = minimumMagnitude;
    this.f4g_1 = defaultMagnitude;
    this.g4g_1 = allowNegative;
  }
  function SIUnit_Factor_getInstance() {
    SIUnit_initEntries();
    return SIUnit_Factor_instance;
  }
  function SIUnit_Ohm_getInstance() {
    SIUnit_initEntries();
    return SIUnit_Ohm_instance;
  }
  function SIUnit_Farad_getInstance() {
    SIUnit_initEntries();
    return SIUnit_Farad_instance;
  }
  function SIUnit_Henry_getInstance() {
    SIUnit_initEntries();
    return SIUnit_Henry_instance;
  }
  function SIUnit_Volt_getInstance() {
    SIUnit_initEntries();
    return SIUnit_Volt_instance;
  }
  function SIUnit_Ampere_getInstance() {
    SIUnit_initEntries();
    return SIUnit_Ampere_instance;
  }
  function SIUnit_Second_getInstance() {
    SIUnit_initEntries();
    return SIUnit_Second_instance;
  }
  function SIUnit_Hertz_getInstance() {
    SIUnit_initEntries();
    return SIUnit_Hertz_instance;
  }
  function Companion_39() {
    this.w4g_1 = 5;
    this.x4g_1 = 15;
  }
  var Companion_instance_44;
  function Companion_getInstance_49() {
    return Companion_instance_44;
  }
  function AbstractBelowSelectionModel(component, styleProvider, styleType, outset) {
    styleProvider = styleProvider === VOID ? DrawStyleModule_getInstance().w1x_1 : styleProvider;
    styleType = styleType === VOID ? Companion_getInstance_60().f3o_1 : styleType;
    outset = outset === VOID ? 5 : outset;
    AbstractSelectionModel.call(this, component);
    this.d4h_1 = outset;
    this.e4h_1 = styleProvider.f1y(styleType).c1u();
  }
  protoOf(AbstractBelowSelectionModel).l2e = function (value) {
    this.e4h_1 = value;
    this.i20();
  };
  protoOf(AbstractBelowSelectionModel).c1u = function () {
    return this.e4h_1;
  };
  function EventHandler($outer) {
    this.m3s_1 = $outer;
    InputEventHandlerAdapter.call(this);
    this.l3s_1 = null;
  }
  protoOf(EventHandler).j3s = function (view) {
  };
  protoOf(EventHandler).u3s = function (context) {
  };
  protoOf(EventHandler).v3s = function (context) {
    return !(this.l3s_1 == null) ? this : null;
  };
  protoOf(EventHandler).d23 = function (context) {
    return this.v3s(context instanceof EditInputEventContext ? context : THROW_CCE());
  };
  protoOf(EventHandler).w3s = function (context) {
    return !(this.l3s_1 == null) ? this : null;
  };
  protoOf(EventHandler).e23 = function (context) {
    return this.w3s(context instanceof EditInputEventContext ? context : THROW_CCE());
  };
  protoOf(EventHandler).x3s = function (context) {
    var tmp0_elvis_lhs = this.m3s_1.l3t(context.q22_1, context.r22_1);
    var tmp;
    if (tmp0_elvis_lhs == null) {
      return null;
    } else {
      tmp = tmp0_elvis_lhs;
    }
    var handle = tmp;
    handle.e20(context).z22(context);
    return this;
  };
  protoOf(EventHandler).z22 = function (context) {
    return this.x3s(context instanceof EditInputEventContext ? context : THROW_CCE());
  };
  protoOf(EventHandler).y3s = function (context) {
    var handle = this.m3s_1.l3t(context.q22_1, context.r22_1);
    if (handle == null) {
      this.l3s_1 = null;
      return null;
    }
    this.l3s_1 = handle;
    this.j3s(context.n22_1);
    return this;
  };
  protoOf(EventHandler).a23 = function (context) {
    return this.y3s(context instanceof EditInputEventContext ? context : THROW_CCE());
  };
  protoOf(EventHandler).z3s = function (context) {
    if (this.l3s_1 == null) {
      return null;
    }
    var snap = Companion_getInstance().w1a_1;
    var tmp0_safe_receiver = context.o22_1;
    if (!((tmp0_safe_receiver == null ? null : tmp0_safe_receiver.isAltDown) === true)) {
      snap = context.w3c_1.b3d().v43(context.q22_1, context.r22_1);
    }
    var tmp1_safe_receiver = this.l3s_1;
    var tmp2_safe_receiver = tmp1_safe_receiver == null ? null : tmp1_safe_receiver.e20(context);
    if (tmp2_safe_receiver == null)
      null;
    else
      tmp2_safe_receiver.b23(context.v22(context.q22_1 + snap.kn_1, context.r22_1 + snap.ln_1));
    return this;
  };
  protoOf(EventHandler).b23 = function (context) {
    return this.z3s(context instanceof EditInputEventContext ? context : THROW_CCE());
  };
  protoOf(EventHandler).a3t = function (context) {
    if (this.l3s_1 == null) {
      return null;
    }
    this.u3s(context);
    var tmp0_safe_receiver = this.l3s_1;
    var tmp1_safe_receiver = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.e20(context);
    if (tmp1_safe_receiver == null)
      null;
    else
      tmp1_safe_receiver.c23(context);
    return this;
  };
  protoOf(EventHandler).c23 = function (context) {
    return this.a3t(context instanceof EditInputEventContext ? context : THROW_CCE());
  };
  function AbstractHandleSelectionModel$inputEventHandler$delegate$lambda(this$0) {
    return function () {
      return this$0.e3t();
    };
  }
  function AbstractHandleSelectionModel$_get_inputEventHandler_$ref_59ceo9() {
    return function (p0) {
      return p0.d3t();
    };
  }
  function AbstractHandleSelectionModel(component) {
    AbstractSelectionModel.call(this, component);
    var tmp = this;
    // Inline function 'kotlin.collections.mutableListOf' call
    tmp.l3r_1 = ArrayList_init_$Create$_0();
    var tmp_0 = this;
    tmp_0.m3r_1 = lazy(AbstractHandleSelectionModel$inputEventHandler$delegate$lambda(this));
    this.n3r_1 = 0;
    this.o3r_1 = null;
    this.p3r_1 = new Rectangle2D();
  }
  protoOf(AbstractHandleSelectionModel).d3t = function () {
    var tmp0 = this.m3r_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('inputEventHandler', 1, tmp, AbstractHandleSelectionModel$_get_inputEventHandler_$ref_59ceo9(), null);
    return tmp0.j2();
  };
  protoOf(AbstractHandleSelectionModel).o2b = function (value) {
    this.i20();
    this.o3r_1 = value;
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = this.l3r_1.i();
    while (_iterator__ex2g4s.j()) {
      var element = _iterator__ex2g4s.k();
      element.o2b(this.o3r_1);
    }
    this.m3t();
  };
  protoOf(AbstractHandleSelectionModel).h24 = function () {
    return this.o3r_1;
  };
  protoOf(AbstractHandleSelectionModel).fo = function () {
    return this.p3r_1;
  };
  protoOf(AbstractHandleSelectionModel).h3t = function (context) {
    var tmp = this.d3t();
    return isInterface(tmp, InputEventHandler) ? tmp : THROW_CCE();
  };
  protoOf(AbstractHandleSelectionModel).e20 = function (context) {
    return this.h3t(context instanceof InputEventContext ? context : THROW_CCE());
  };
  protoOf(AbstractHandleSelectionModel).h20 = function (context) {
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = this.l3r_1.i();
    while (_iterator__ex2g4s.j()) {
      var element = _iterator__ex2g4s.k();
      element.h20(context);
    }
  };
  protoOf(AbstractHandleSelectionModel).go = function (x, y) {
    return this.p3r_1.go(x, y);
  };
  protoOf(AbstractHandleSelectionModel).i3t = function (view) {
    this.j3t();
    this.n3r_1 = this.r3r();
  };
  protoOf(AbstractHandleSelectionModel).j3t = function () {
    this.m3t();
  };
  protoOf(AbstractHandleSelectionModel).d3s = function (handle) {
    return this.k3t(this.l3r_1.o(), handle);
  };
  protoOf(AbstractHandleSelectionModel).k3t = function (index, handle) {
    this.l3r_1.t3(index, handle);
    if (!(this.h24() == null)) {
      handle.o2b(this.h24());
    }
    return handle;
  };
  protoOf(AbstractHandleSelectionModel).g3t = function (index) {
    return this.l3r_1.l(index);
  };
  protoOf(AbstractHandleSelectionModel).n3s = function (handle) {
    return this.l3r_1.p(handle);
  };
  protoOf(AbstractHandleSelectionModel).l3t = function (x, y) {
    var tmp0 = this.l3r_1;
    var tmp$ret$0;
    $l$block: {
      // Inline function 'kotlin.collections.firstOrNull' call
      var _iterator__ex2g4s = tmp0.i();
      while (_iterator__ex2g4s.j()) {
        var element = _iterator__ex2g4s.k();
        if (element.go(x, y)) {
          tmp$ret$0 = element;
          break $l$block;
        }
      }
      tmp$ret$0 = null;
    }
    return tmp$ret$0;
  };
  protoOf(AbstractHandleSelectionModel).q3r = function () {
    this.l3r_1.a2();
  };
  protoOf(AbstractHandleSelectionModel).y29 = function () {
    if (this.l3r_1.m()) {
      this.p3r_1.i1c(0.0, 0.0, 0.0, 0.0);
      return Unit_instance;
    }
    this.p3r_1.m1c(this.l3r_1.l(0).fo());
    var inductionVariable = 1;
    var last = this.l3r_1.o();
    if (inductionVariable < last)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        this.p3r_1.n1c(this.l3r_1.l(i).fo());
      }
       while (inductionVariable < last);
  };
  protoOf(AbstractHandleSelectionModel).m3t = function () {
    this.i20();
    this.f3t();
    this.y29();
    this.i20();
    this.k20();
  };
  function displayHandles($this, view) {
    if (view.r3b() && !$this.g3v_1) {
      view.z3b().b21($this.f3v_1);
      $this.g3v_1 = true;
    }
  }
  function hideHandles($this, view) {
    if ($this.g3v_1) {
      view.z3b().c21($this.f3v_1);
      view.z3b().k20();
      $this.g3v_1 = false;
    }
  }
  function EventHandler_0($outer) {
    this.g4h_1 = $outer;
    InputEventHandlerAdapter.call(this);
  }
  protoOf(EventHandler_0).v3s = function (context) {
    return this.g4h_1.f3v_1.h3t(context).d23(context);
  };
  protoOf(EventHandler_0).d23 = function (context) {
    return this.v3s(context instanceof EditInputEventContext ? context : THROW_CCE());
  };
  protoOf(EventHandler_0).w3s = function (context) {
    return this.g4h_1.f3v_1.h3t(context).e23(context);
  };
  protoOf(EventHandler_0).e23 = function (context) {
    return this.w3s(context instanceof EditInputEventContext ? context : THROW_CCE());
  };
  protoOf(EventHandler_0).x3s = function (context) {
    if (this.g4h_1.g3v_1 && this.g4h_1.f3v_1.go(context.q22_1, context.r22_1)) {
      var handler = this.g4h_1.f3v_1.h3t(context).z22(context);
      if (handler == null) {
        context.n22_1.l1y(Cursor_MOVE_getInstance());
      }
      return this;
    }
    if (this.g4h_1.t3s().go(context.q22_1, context.r22_1)) {
      displayHandles(this.g4h_1, context.f3c());
      context.n22_1.l1y(Cursor_MOVE_getInstance());
      return this;
    }
    hideHandles(this.g4h_1, context.f3c());
    return null;
  };
  protoOf(EventHandler_0).z22 = function (context) {
    return this.x3s(context instanceof EditInputEventContext ? context : THROW_CCE());
  };
  protoOf(EventHandler_0).y3s = function (context) {
    var mousePressed = this.g4h_1.f3v_1.h3t(context).a23(context);
    return !(mousePressed == null) ? this : null;
  };
  protoOf(EventHandler_0).a23 = function (context) {
    return this.y3s(context instanceof EditInputEventContext ? context : THROW_CCE());
  };
  protoOf(EventHandler_0).z3s = function (context) {
    this.g4h_1.f3v_1.h3t(context).b23(context);
    return this;
  };
  protoOf(EventHandler_0).b23 = function (context) {
    return this.z3s(context instanceof EditInputEventContext ? context : THROW_CCE());
  };
  protoOf(EventHandler_0).a3t = function (context) {
    this.g4h_1.f3v_1.h3t(context).c23(context);
    return this;
  };
  protoOf(EventHandler_0).c23 = function (context) {
    return this.a3t(context instanceof EditInputEventContext ? context : THROW_CCE());
  };
  function AbstractSelectedColorWrappingSelectionModel(component) {
    SelectedColorSelectionModel.call(this, component);
    this.f3v_1 = this.z3u(component);
    this.g3v_1 = false;
    this.h3v_1 = new EventHandler_0(this);
  }
  protoOf(AbstractSelectedColorWrappingSelectionModel).e20 = function (context) {
    var tmp = this.h3v_1;
    return isInterface(tmp, InputEventHandler) ? tmp : THROW_CCE();
  };
  protoOf(AbstractSelectedColorWrappingSelectionModel).j3t = function () {
    this.f3v_1.j3t();
    this.i20();
    this.k20();
  };
  protoOf(AbstractSelectedColorWrappingSelectionModel).i3t = function (view) {
    if (this.po(view.d25(view.s23().h1y()))) {
      displayHandles(this, view);
    }
  };
  protoOf(AbstractSelectedColorWrappingSelectionModel).o3t = function (view) {
    view.z3b().c21(this.f3v_1);
  };
  function AbstractSelectionModel$geometryUpdateListener$1(this$0) {
    this.h4h_1 = this$0;
    DrawableAdapter.call(this);
  }
  protoOf(AbstractSelectionModel$geometryUpdateListener$1).e22 = function (event) {
    this.h4h_1.j3t();
  };
  function AbstractSelectionModel(component) {
    AbstractDrawable.call(this);
    this.r3s_1 = component;
    var tmp = this;
    tmp.s3s_1 = new AbstractSelectionModel$geometryUpdateListener$1(this);
  }
  protoOf(AbstractSelectionModel).t3s = function () {
    return this.r3s_1;
  };
  protoOf(AbstractSelectionModel).n3t = function () {
    this.t3s().f20(this.s3s_1);
    this.j3t();
  };
  protoOf(AbstractSelectionModel).gs = function () {
    this.t3s().g20(this.s3s_1);
  };
  protoOf(AbstractSelectionModel).i3t = function (view) {
  };
  protoOf(AbstractSelectionModel).o3t = function (view) {
  };
  function BoundingBoxBelowSelectionModel(component, styleProvider, styleType, outset) {
    styleProvider = styleProvider === VOID ? DrawStyleModule_getInstance().w1x_1 : styleProvider;
    styleType = styleType === VOID ? Companion_getInstance_60().f3o_1 : styleType;
    outset = outset === VOID ? 5 : outset;
    AbstractBelowSelectionModel.call(this, component, styleProvider, styleType, outset);
    this.p4h_1 = new Rectangle2D();
  }
  protoOf(BoundingBoxBelowSelectionModel).fo = function () {
    return this.p4h_1;
  };
  protoOf(BoundingBoxBelowSelectionModel).go = function (x, y) {
    return this.p4h_1.go(x, y);
  };
  protoOf(BoundingBoxBelowSelectionModel).h20 = function (context) {
    var oldColor = context.j1z_1.c1u();
    context.j1z_1.b1u(this.c1u().x1x_1);
    context.j1z_1.a1v(numberToInt(this.p4h_1.u1h_1), numberToInt(this.p4h_1.v1h_1), numberToInt(this.p4h_1.w1h_1), numberToInt(this.p4h_1.x1h_1), 15, 15);
    context.j1z_1.b1u(oldColor);
  };
  protoOf(BoundingBoxBelowSelectionModel).j3t = function () {
    this.i20();
    var bbox = this.t3s().fo();
    this.p4h_1 = new Rectangle2D(bbox.p1a() - this.d4h_1, bbox.q1a() - this.d4h_1, bbox.f1c() + imul(2, this.d4h_1), bbox.h1c() + imul(2, this.d4h_1));
    this.i20();
    this.k20();
  };
  function createRubberBand($this) {
    return new RectangularRubberBand();
  }
  function createRubberBandHandler($this) {
    return new RubberBandHandler(createRubberBand($this));
  }
  function fillProperties_1($this, properties) {
    properties.et('edit.select.rubberband.stroke.paint', Companion_getInstance_3().d1t_1);
    properties.et('edit.select.rubberband.fill.paint', new Color(255, 200, 0, 32));
    var tmp = LineCap_SQUARE_getInstance();
    var tmp_0 = LineJoin_MITER_getInstance();
    // Inline function 'kotlin.floatArrayOf' call
    var tmp$ret$0 = new Float32Array([5.0, 5.0]);
    properties.et('edit.select.rubberband.stroke', new Stroke(0.1, tmp, tmp_0, 10.0, tmp$ret$0, 0.0));
    properties.et('edit.select.rubberBandHandler.selectionTargetStrategy', SelectionTargetStrategy_CONTAINS_getInstance().u2p());
    properties.et('edit.select.rubberBandHandler.selectDelayMs', 200);
    properties.et('select.handle.size_half', 4);
    properties.et('select.handle.color.border', Companion_getInstance_3().d1t_1);
    properties.et('select.handle.color.content', Companion_getInstance_3().e1t_1);
    properties.et('select.handle.stroke', new Stroke(1.0));
  }
  function EditSelectModule$selectionManagerFactory$lambda(content) {
    return new SelectionManagerImpl(content);
  }
  function EditSelectModule$selectionToolFactory$lambda(editor) {
    return new SelectionToolImpl(editor, createRubberBandHandler(EditSelectModule_getInstance()), BaseModule_getInstance().bp_1);
  }
  function EditSelectModule() {
    EditSelectModule_instance = this;
    AbstractModule.call(this);
    this.t3l_1 = new SelectionModelFactoryImpl();
    this.u3l_1 = new SimpleSelectionModelProvider(this.t3l_1);
    var tmp = this;
    tmp.v3l_1 = EditSelectModule$selectionManagerFactory$lambda;
    var tmp_0 = this;
    tmp_0.w3l_1 = EditSelectModule$selectionToolFactory$lambda;
  }
  protoOf(EditSelectModule).to = function () {
    fillProperties_1(this, BaseModule_getInstance().zo_1);
  };
  var EditSelectModule_instance;
  function EditSelectModule_getInstance() {
    if (EditSelectModule_instance == null)
      new EditSelectModule();
    return EditSelectModule_instance;
  }
  function Handle() {
  }
  function MoveCommand(editor, componentIds, offset, children) {
    children = children === VOID ? emptyList() : children;
    AbstractCommand.call(this, 'edit.command.move', editor);
    this.x4h_1 = componentIds;
    this.y4h_1 = offset;
    this.z4h_1 = children;
  }
  protoOf(MoveCommand).h3a = function () {
    var tmp;
    if (this.x4h_1.o() === 1) {
      var out = StringBuilder_init_$Create$();
      var id = first_0(this.x4h_1);
      var component = ensureNotNull(ensureNotNull(this.h3h_1).u3b().o3b(id));
      // Inline function 'kotlin.text.appendLine' call
      var value = protoOf(AbstractCommand).h3a.call(this) + ' ' + getKClassFromExpression(component).m9() + ' ' + id + ' childrenSize:' + this.z4h_1.o();
      // Inline function 'kotlin.text.appendLine' call
      out.i7(value).j7(_Char___init__impl__6a9atx(10));
      // Inline function 'kotlin.collections.forEach' call
      var _iterator__ex2g4s = this.z4h_1.i();
      while (_iterator__ex2g4s.j()) {
        var element = _iterator__ex2g4s.k();
        // Inline function 'kotlin.text.appendLine' call
        var value_0 = '- child: ' + element.h3a();
        // Inline function 'kotlin.text.appendLine' call
        out.i7(value_0).j7(_Char___init__impl__6a9atx(10));
      }
      tmp = out.toString();
    } else {
      tmp = protoOf(AbstractCommand).h3a.call(this);
    }
    return tmp;
  };
  protoOf(MoveCommand).i3a = function () {
    var tmp = Companion_instance;
    // Inline function 'kotlin.collections.map' call
    var this_0 = this.x4h_1;
    // Inline function 'kotlin.collections.mapTo' call
    var destination = ArrayList_init_$Create$(collectionSizeOrDefault(this_0, 10));
    var _iterator__ex2g4s = this_0.i();
    while (_iterator__ex2g4s.j()) {
      var item = _iterator__ex2g4s.k();
      var tmp$ret$2 = ensureNotNull(ensureNotNull(this.h3h_1).u3b().o3b(item));
      destination.h(tmp$ret$2);
    }
    tmp.h2i(toList(destination), this.y4h_1);
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s_0 = this.z4h_1.i();
    while (_iterator__ex2g4s_0.j()) {
      var element = _iterator__ex2g4s_0.k();
      element.i3a();
    }
  };
  function RectangularHandle(handler) {
    AbstractRectangularUnzoomable.call(this, DrawModule_getInstance().l2a_1.kt('select.handle.size_half'));
    this.h4i_1 = handler;
    this.i4i_1 = DrawModule_getInstance().l2a_1.a20('select.handle.stroke').f1u_1;
  }
  protoOf(RectangularHandle).b2c = function () {
    return this.i4i_1;
  };
  protoOf(RectangularHandle).h20 = function (context) {
    var rect = this.r2c();
    context.j1z_1.b1u(DrawModule_getInstance().l2a_1.z1z('select.handle.color.content'));
    context.j1z_1.k1v(rect);
    context.j1z_1.b1u(DrawModule_getInstance().l2a_1.z1z('select.handle.color.border'));
    context.j1z_1.e1u(DrawModule_getInstance().l2a_1.a20('select.handle.stroke'));
    context.j1z_1.j1v(rect);
  };
  protoOf(RectangularHandle).e20 = function (context) {
    var tmp = this.h4i_1;
    return isInterface(tmp, InputEventHandler) ? tmp : THROW_CCE();
  };
  function Companion_40() {
    this.j4i_1 = 2;
  }
  var Companion_instance_45;
  function Companion_getInstance_50() {
    return Companion_instance_45;
  }
  function EventHandler_1($outer) {
    this.n4i_1 = $outer;
    InputEventHandlerAdapter.call(this);
    this.l4i_1 = Companion_getInstance().w1a_1;
    this.m4i_1 = false;
  }
  protoOf(EventHandler_1).y3s = function (context) {
    protoOf(InputEventHandlerAdapter).a23.call(this, context);
    this.n4i_1.s4i_1 = context.n22_1.h24();
    this.l4i_1 = context.t22_1;
    this.n4i_1.z2b(this.l4i_1.kn_1, this.l4i_1.ln_1, 0.0, 0.0);
    return this;
  };
  protoOf(EventHandler_1).a23 = function (context) {
    return this.y3s(context instanceof EditInputEventContext ? context : THROW_CCE());
  };
  protoOf(EventHandler_1).z3s = function (context) {
    protoOf(InputEventHandlerAdapter).b23.call(this, context);
    if (!this.m4i_1 && this.l4i_1.e1h(context.q22_1, context.r22_1) >= 2) {
      this.m4i_1 = true;
      context.f3c().z3b().b21(this.n4i_1);
    }
    if (this.m4i_1) {
      var tmp0 = this.l4i_1.kn_1;
      // Inline function 'kotlin.math.min' call
      var b = context.q22_1;
      var tmp = Math.min(tmp0, b);
      var tmp0_0 = this.l4i_1.ln_1;
      // Inline function 'kotlin.math.min' call
      var b_0 = context.r22_1;
      var tmp_0 = Math.min(tmp0_0, b_0);
      // Inline function 'kotlin.math.abs' call
      var x = this.l4i_1.kn_1 - context.q22_1;
      var tmp_1 = Math.abs(x);
      // Inline function 'kotlin.math.abs' call
      var x_0 = this.l4i_1.ln_1 - context.r22_1;
      var tmp$ret$3 = Math.abs(x_0);
      this.n4i_1.z2b(tmp, tmp_0, tmp_1, tmp$ret$3);
      this.n4i_1.k20();
    }
    return this;
  };
  protoOf(EventHandler_1).b23 = function (context) {
    return this.z3s(context instanceof EditInputEventContext ? context : THROW_CCE());
  };
  protoOf(EventHandler_1).a3t = function (context) {
    protoOf(InputEventHandlerAdapter).c23.call(this, context);
    if (this.m4i_1) {
      context.f3c().z3b().c21(this.n4i_1);
      context.f3c().z3b().k20();
    }
    this.m4i_1 = false;
    return this;
  };
  protoOf(EventHandler_1).c23 = function (context) {
    return this.a3t(context instanceof EditInputEventContext ? context : THROW_CCE());
  };
  function RectangularRubberBand() {
    AbstractRectangle.call(this, new Rectangle2D());
    this.s4i_1 = null;
    this.t4i_1 = new EventHandler_1(this);
  }
  protoOf(RectangularRubberBand).o2b = function (_set____db54di) {
    this.s4i_1 = _set____db54di;
  };
  protoOf(RectangularRubberBand).d3t = function () {
    return this.t4i_1;
  };
  protoOf(RectangularRubberBand).h20 = function (context) {
    if (!(this.s4i_1 == null)) {
      var p1 = ensureNotNull(this.s4i_1).j24_1.g25(new Point2D(this.p1a(), this.q1a()));
      var p2 = ensureNotNull(this.s4i_1).j24_1.g25(new Point2D(this.p1a() + this.f1c(), this.q1a() + this.h1c()));
      this.e2c(context, p1.kn_1, p1.ln_1, p2.kn_1 - p1.kn_1, p2.ln_1 - p1.ln_1, DrawModule_getInstance().l2a_1.z1z('edit.select.rubberband.stroke.paint'), DrawModule_getInstance().l2a_1.z1z('edit.select.rubberband.fill.paint'), DrawModule_getInstance().l2a_1.a20('edit.select.rubberband.stroke'));
    }
  };
  protoOf(RectangularRubberBand).b2c = function () {
    return DrawModule_getInstance().l2a_1.a20('edit.select.rubberband.stroke').f1u_1;
  };
  function RubberBand() {
  }
  function _get_LOG__e5r759_7($this) {
    var tmp0 = $this.u4i_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('LOG', 1, tmp, RubberBandHandler$Companion$_get_LOG_$ref_3kggbf(), null);
    return tmp0.j2();
  }
  function RubberBandHandler$Companion$_get_LOG_$ref_3kggbf() {
    return function (p0) {
      return _get_LOG__e5r759_7(p0);
    };
  }
  function RubberBandHandler$SelectionTargetStrategy$CONTAINS$select$lambda($currentSelection, $rubberBand) {
    return function (it) {
      return $currentSelection.n(it) || (it.d20() && $rubberBand.qo(it.fo()));
    };
  }
  function RubberBandHandler$SelectionTargetStrategy$INTERSECTS$select$lambda($currentSelection, $rubberBand) {
    return function (it) {
      return $currentSelection.n(it) || (it.d20() && $rubberBand.ro(it.fo()));
    };
  }
  function RubberBandHandler$SelectionTargetStrategy$CONTAINS() {
    SelectionTargetStrategy.call(this, 'CONTAINS', 0, 'contains', 'edit.preferences.RubberBand.targetStrategy.contains');
    SelectionTargetStrategy_CONTAINS_instance = this;
  }
  protoOf(RubberBandHandler$SelectionTargetStrategy$CONTAINS).b4j = function (context, currentSelection, rubberBand) {
    var tmp = context.f3c().v3b();
    tmp.e3e(RubberBandHandler$SelectionTargetStrategy$CONTAINS$select$lambda(currentSelection, rubberBand));
  };
  var SelectionTargetStrategy_CONTAINS_instance;
  function RubberBandHandler$SelectionTargetStrategy$INTERSECTS() {
    SelectionTargetStrategy.call(this, 'INTERSECTS', 1, 'intersects', 'edit.preferences.RubberBand.targetStrategy.intersects');
    SelectionTargetStrategy_INTERSECTS_instance = this;
  }
  protoOf(RubberBandHandler$SelectionTargetStrategy$INTERSECTS).b4j = function (context, currentSelection, rubberBand) {
    var tmp = context.f3c().v3b();
    tmp.e3e(RubberBandHandler$SelectionTargetStrategy$INTERSECTS$select$lambda(currentSelection, rubberBand));
  };
  var SelectionTargetStrategy_INTERSECTS_instance;
  function Companion_41() {
  }
  protoOf(Companion_41).h1f = function (name) {
    var tmp0 = values_4();
    var tmp$ret$0;
    $l$block: {
      // Inline function 'kotlin.collections.firstOrNull' call
      var inductionVariable = 0;
      var last = tmp0.length;
      while (inductionVariable < last) {
        var element = tmp0[inductionVariable];
        inductionVariable = inductionVariable + 1 | 0;
        if (element.u2p() === name) {
          tmp$ret$0 = element;
          break $l$block;
        }
      }
      tmp$ret$0 = null;
    }
    var tmp0_elvis_lhs = tmp$ret$0;
    var tmp;
    if (tmp0_elvis_lhs == null) {
      throw IllegalArgumentException_init_$Create$("unknown SelectionTargetStrategy '" + name + "'");
    } else {
      tmp = tmp0_elvis_lhs;
    }
    return tmp;
  };
  var Companion_instance_46;
  function Companion_getInstance_51() {
    return Companion_instance_46;
  }
  function values_4() {
    return [SelectionTargetStrategy_CONTAINS_getInstance(), SelectionTargetStrategy_INTERSECTS_getInstance()];
  }
  var SelectionTargetStrategy_entriesInitialized;
  function SelectionTargetStrategy_initEntries() {
    if (SelectionTargetStrategy_entriesInitialized)
      return Unit_instance;
    SelectionTargetStrategy_entriesInitialized = true;
    SelectionTargetStrategy_CONTAINS_instance = new RubberBandHandler$SelectionTargetStrategy$CONTAINS();
    SelectionTargetStrategy_INTERSECTS_instance = new RubberBandHandler$SelectionTargetStrategy$INTERSECTS();
  }
  function Companion_42() {
    Companion_instance_47 = this;
    this.u4i_1 = logger(getKClass(RubberBandHandler));
    this.v4i_1 = 'edit.select.rubberBandHandler.selectionTargetStrategy';
    this.w4i_1 = 'edit.select.rubberBandHandler.selectDelayMs';
  }
  var Companion_instance_47;
  function Companion_getInstance_52() {
    if (Companion_instance_47 == null)
      new Companion_42();
    return Companion_instance_47;
  }
  function _get_context__ps0bpe($this) {
    var tmp = $this.l4j_1;
    if (!(tmp == null))
      return tmp;
    else {
      throwUninitializedPropertyAccessException('context');
    }
  }
  function _get_selectionTargetStrategy__4q6g8v($this) {
    var tmp0 = $this.m4j_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('selectionTargetStrategy', 1, tmp, RubberBandHandler$_get_selectionTargetStrategy_$ref_3g6n1t(), null);
    return tmp0.j2();
  }
  function captureCurrentSelection($this, selectionManager) {
    $this.k4j_1.a2();
    $this.k4j_1.f1(selectionManager.x3d());
  }
  function initializeTimer($this, timer) {
    if (timer == null) {
      return null;
    }
    var delay = BaseModule_getInstance().zo_1.ot('edit.select.rubberBandHandler.selectDelayMs');
    var tmp;
    if (!(delay == null)) {
      timer.vp(delay, false, RubberBandHandler$initializeTimer$lambda($this));
      tmp = timer;
    } else {
      tmp = null;
    }
    return tmp;
  }
  function performSelection($this, isOther) {
    effectiveTargetStrategy($this, isOther).b4j(_get_context__ps0bpe($this), $this.k4j_1, $this.i4j_1);
  }
  function requestExpandSelection($this, context) {
    if (!($this.j4j_1 == null)) {
      if (!ensureNotNull($this.j4j_1).zp()) {
        $this.l4j_1 = context;
        ensureNotNull($this.j4j_1).xp();
      }
    } else {
      $this.l4j_1 = context;
      var tmp0_safe_receiver = context.o22_1;
      effectiveTargetStrategy($this, (tmp0_safe_receiver == null ? null : tmp0_safe_receiver.isAltDown) === true).b4j(_get_context__ps0bpe($this), $this.k4j_1, $this.i4j_1);
    }
  }
  function effectiveTargetStrategy($this, isOther) {
    var tmp;
    if (isOther) {
      tmp = _get_selectionTargetStrategy__4q6g8v($this).c4j();
    } else {
      tmp = _get_selectionTargetStrategy__4q6g8v($this);
    }
    return tmp;
  }
  function SelectionTargetStrategy(name, ordinal, customName, nameKey) {
    Enum.call(this, name, ordinal);
    this.s4h_1 = customName;
    this.t4h_1 = nameKey;
  }
  protoOf(SelectionTargetStrategy).u2p = function () {
    return this.s4h_1;
  };
  protoOf(SelectionTargetStrategy).toString = function () {
    return Translations_getInstance().bn(this.t4h_1, []);
  };
  protoOf(SelectionTargetStrategy).c4j = function () {
    var tmp;
    switch (this.l2_1) {
      case 0:
        tmp = SelectionTargetStrategy_INTERSECTS_getInstance();
        break;
      case 1:
        tmp = SelectionTargetStrategy_CONTAINS_getInstance();
        break;
      default:
        noWhenBranchMatchedException();
        break;
    }
    return tmp;
  };
  function RubberBandHandler$selectionTargetStrategy$delegate$lambda() {
    return Companion_instance_46.h1f(BaseModule_getInstance().zo_1.jt('edit.select.rubberBandHandler.selectionTargetStrategy'));
  }
  function RubberBandHandler$_get_selectionTargetStrategy_$ref_3g6n1t() {
    return function (p0) {
      return _get_selectionTargetStrategy__4q6g8v(p0);
    };
  }
  function RubberBandHandler$initializeTimer$lambda(this$0) {
    return function (it) {
      var tmp0_safe_receiver = _get_context__ps0bpe(this$0).o22_1;
      performSelection(this$0, (tmp0_safe_receiver == null ? null : tmp0_safe_receiver.isAltDown) === true);
      return Unit_instance;
    };
  }
  function SelectionTargetStrategy_CONTAINS_getInstance() {
    SelectionTargetStrategy_initEntries();
    return SelectionTargetStrategy_CONTAINS_instance;
  }
  function SelectionTargetStrategy_INTERSECTS_getInstance() {
    SelectionTargetStrategy_initEntries();
    return SelectionTargetStrategy_INTERSECTS_instance;
  }
  function RubberBandHandler(rubberBand) {
    Companion_getInstance_52();
    InputEventHandlerAdapter.call(this);
    this.i4j_1 = rubberBand;
    this.j4j_1 = System_getInstance().wl();
    var tmp = this;
    // Inline function 'kotlin.collections.mutableListOf' call
    tmp.k4j_1 = ArrayList_init_$Create$_0();
    var tmp_0 = this;
    tmp_0.m4j_1 = lazy(RubberBandHandler$selectionTargetStrategy$delegate$lambda);
    initializeTimer(this, this.j4j_1);
  }
  protoOf(RubberBandHandler).v3s = function (context) {
    var tmp0_safe_receiver = context.p22_1;
    if ((tmp0_safe_receiver == null ? null : tmp0_safe_receiver.i2()) === Companion_instance_0.u18_1) {
      this.l4j_1 = context;
      performSelection(this, true);
    }
    return this;
  };
  protoOf(RubberBandHandler).d23 = function (context) {
    return this.v3s(context instanceof EditInputEventContext ? context : THROW_CCE());
  };
  protoOf(RubberBandHandler).w3s = function (context) {
    var tmp0_safe_receiver = context.p22_1;
    if ((tmp0_safe_receiver == null ? null : tmp0_safe_receiver.i2()) === Companion_instance_0.u18_1) {
      this.l4j_1 = context;
      performSelection(this, false);
    }
    return this;
  };
  protoOf(RubberBandHandler).e23 = function (context) {
    return this.w3s(context instanceof EditInputEventContext ? context : THROW_CCE());
  };
  protoOf(RubberBandHandler).y3s = function (context) {
    protoOf(InputEventHandlerAdapter).a23.call(this, context);
    captureCurrentSelection(this, context.f3c().v3b());
    return this.i4j_1.d3t().a23(context);
  };
  protoOf(RubberBandHandler).a23 = function (context) {
    return this.y3s(context instanceof EditInputEventContext ? context : THROW_CCE());
  };
  protoOf(RubberBandHandler).z3s = function (context) {
    protoOf(InputEventHandlerAdapter).b23.call(this, context);
    this.i4j_1.d3t().b23(context);
    requestExpandSelection(this, context);
    return this;
  };
  protoOf(RubberBandHandler).b23 = function (context) {
    return this.z3s(context instanceof EditInputEventContext ? context : THROW_CCE());
  };
  protoOf(RubberBandHandler).a3t = function (context) {
    protoOf(InputEventHandlerAdapter).c23.call(this, context);
    this.i4j_1.d3t().c23(context);
    var tmp;
    if (_get_LOG__e5r759_7(Companion_getInstance_52()).rl()) {
      var tmp_0 = this.i4j_1;
      tmp = tmp_0 instanceof RectangularRubberBand;
    } else {
      tmp = false;
    }
    if (tmp) {
      if (this.i4j_1.u1c() > 0 || this.i4j_1.v1c() > 0) {
        _get_LOG__e5r759_7(Companion_getInstance_52()).pl('Rectangular selection from ' + this.i4j_1.s1c() + '/' + this.i4j_1.t1c() + ' to ' + (this.i4j_1.s1c() + this.i4j_1.u1c() | 0) + '/' + (this.i4j_1.t1c() + this.i4j_1.v1c() | 0));
      }
    }
    return null;
  };
  protoOf(RubberBandHandler).c23 = function (context) {
    return this.a3t(context instanceof EditInputEventContext ? context : THROW_CCE());
  };
  function get_selectedColorSelectionModelFactory() {
    _init_properties_SelectedColorSelectionModel_kt__z8798t();
    return selectedColorSelectionModelFactory;
  }
  var selectedColorSelectionModelFactory;
  function SelectedColorSelectionModel(component) {
    AbstractSelectionModel.call(this, component);
  }
  protoOf(SelectedColorSelectionModel).h20 = function (context) {
    var oldColor = context.j1z_1.c1u();
    var oldUseContextColors = context.m1z_1;
    context.j1z_1.b1u(Themes_getInstance().h2g().p3y_1.c1u().x1x_1);
    context.m1z_1 = true;
    context.n1z_1 = Themes_getInstance().h2g().p3y_1.c1u();
    this.t3s().h20(context);
    context.j1z_1.b1u(oldColor);
    context.m1z_1 = oldUseContextColors;
  };
  protoOf(SelectedColorSelectionModel).fo = function () {
    return this.t3s().fo();
  };
  protoOf(SelectedColorSelectionModel).go = function (x, y) {
    return this.t3s().go(x, y);
  };
  protoOf(SelectedColorSelectionModel).j3t = function () {
    this.k20();
  };
  function selectedColorSelectionModelFactory$lambda(it) {
    _init_properties_SelectedColorSelectionModel_kt__z8798t();
    return new SelectedColorSelectionModel(it);
  }
  var properties_initialized_SelectedColorSelectionModel_kt_3rj7ez;
  function _init_properties_SelectedColorSelectionModel_kt__z8798t() {
    if (!properties_initialized_SelectedColorSelectionModel_kt_3rj7ez) {
      properties_initialized_SelectedColorSelectionModel_kt_3rj7ez = true;
      selectedColorSelectionModelFactory = selectedColorSelectionModelFactory$lambda;
    }
  }
  function _get_LOG__e5r759_8($this) {
    var tmp0 = $this.n4j_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('LOG', 1, tmp, SelectionManagerImpl$Companion$_get_LOG_$ref_t1fzq7(), null);
    return tmp0.j2();
  }
  function SelectionManagerImpl$Companion$_get_LOG_$ref_t1fzq7() {
    return function (p0) {
      return _get_LOG__e5r759_8(p0);
    };
  }
  function Companion_43() {
    Companion_instance_48 = this;
    this.n4j_1 = logger(getKClass(SelectionManagerImpl));
  }
  var Companion_instance_48;
  function Companion_getInstance_53() {
    if (Companion_instance_48 == null)
      new Companion_43();
    return Companion_instance_48;
  }
  function canSelect($this, component) {
    return component.d20() && !$this.d3e(component);
  }
  function postSelectionChanged($this, components, selected) {
    $this.q4j_1.gu(SelectionChangeEvent_init_$Create$($this.o4j_1.f3c(), components, selected));
  }
  function selectImpl($this, component) {
    var strategy = $this.o4j_1.f3c().e3c(component);
    var selectionModel = $this.p4j_1.v3n(component, strategy);
    if (selectionModel == null && !(component.f3b() == null)) {
      strategy = ensureNotNull(component.f3b());
      selectionModel = $this.p4j_1.v3n(component, strategy);
    }
    if (selectionModel == null) {
      _get_LOG__e5r759_8(Companion_getInstance_53()).ml('SelectionManagerImpl: No suitable SelectionModel found for ' + (System_getInstance().yl(component.d3b()) + ' and strategy ' + strategy.toString()));
      return Unit_instance;
    }
    $this.o4j_1.j3c(selectionModel, strategy);
    var tmp0 = $this.r4j_1;
    // Inline function 'kotlin.collections.set' call
    var value = selectionModel;
    tmp0.y1(component, value);
    selectionModel.i3t($this.o4j_1.f3c());
  }
  function deselectImpl($this, component) {
    var selectionModel = $this.r4j_1.g2(component);
    if (!(selectionModel == null)) {
      $this.r4j_1.z1(component);
      $this.o4j_1.k3c(selectionModel);
      $this.p4j_1.s4j(selectionModel);
      selectionModel.o3t($this.o4j_1.f3c());
    }
  }
  function SelectionManagerImpl$replace$lambda($condition) {
    return function (it) {
      return $condition(it);
    };
  }
  function SelectionManagerImpl(content, selectionModelProvider, eventBus) {
    Companion_getInstance_53();
    selectionModelProvider = selectionModelProvider === VOID ? EditSelectModule_getInstance().u3l_1 : selectionModelProvider;
    eventBus = eventBus === VOID ? BaseModule_getInstance().bp_1 : eventBus;
    this.o4j_1 = content;
    this.p4j_1 = selectionModelProvider;
    this.q4j_1 = eventBus;
    var tmp = this;
    // Inline function 'kotlin.collections.mutableMapOf' call
    tmp.r4j_1 = LinkedHashMap_init_$Create$();
  }
  protoOf(SelectionManagerImpl).x3d = function () {
    return toList(this.r4j_1.b2());
  };
  protoOf(SelectionManagerImpl).m2v = function () {
    // Inline function 'kotlin.with' call
    var $this$with = this.x3d();
    if ($this$with.m()) {
      postSelectionChanged(this, emptyList(), false);
    } else {
      postSelectionChanged(this, $this$with, true);
    }
  };
  protoOf(SelectionManagerImpl).y3d = function (component) {
    if (canSelect(this, component)) {
      selectImpl(this, component);
      this.o4j_1.u3b().k20();
      postSelectionChanged(this, listOf(component), true);
    }
  };
  protoOf(SelectionManagerImpl).z3d = function (components) {
    // Inline function 'kotlin.collections.mutableListOf' call
    var newSelections = ArrayList_init_$Create$_0();
    var _iterator__ex2g4s = components.i();
    while (_iterator__ex2g4s.j()) {
      var c = _iterator__ex2g4s.k();
      if (canSelect(this, c)) {
        selectImpl(this, c);
        newSelections.h(c);
      }
    }
    // Inline function 'kotlin.collections.isNotEmpty' call
    if (!newSelections.m()) {
      postSelectionChanged(this, newSelections, true);
      this.o4j_1.u3b().k20();
    }
  };
  protoOf(SelectionManagerImpl).a3e = function (component) {
    if (this.d3e(component)) {
      deselectImpl(this, component);
      this.o4j_1.u3b().k20();
      postSelectionChanged(this, listOf(component), false);
    }
  };
  protoOf(SelectionManagerImpl).b3e = function (components) {
    // Inline function 'kotlin.collections.mutableListOf' call
    var list = ArrayList_init_$Create$_0();
    var _iterator__ex2g4s = components.i();
    while (_iterator__ex2g4s.j()) {
      var c = _iterator__ex2g4s.k();
      if (this.d3e(c)) {
        deselectImpl(this, c);
        list.h(c);
      }
    }
    // Inline function 'kotlin.collections.isNotEmpty' call
    if (!list.m()) {
      postSelectionChanged(this, list, false);
      this.o4j_1.u3b().k20();
    }
  };
  protoOf(SelectionManagerImpl).c3e = function () {
    // Inline function 'kotlin.collections.mutableListOf' call
    var list = ArrayList_init_$Create$_0();
    var _iterator__ex2g4s = toList(this.r4j_1.b2()).i();
    while (_iterator__ex2g4s.j()) {
      var c = _iterator__ex2g4s.k();
      deselectImpl(this, c);
      list.h(c);
    }
    // Inline function 'kotlin.collections.isNotEmpty' call
    if (!list.m()) {
      postSelectionChanged(this, list, false);
      this.o4j_1.u3b().k20();
    }
  };
  protoOf(SelectionManagerImpl).d3e = function (component) {
    return this.r4j_1.e2(component);
  };
  protoOf(SelectionManagerImpl).e3e = function (condition) {
    var currentSelection = this.x3d();
    // Inline function 'kotlin.collections.mutableListOf' call
    var toDeselect = ArrayList_init_$Create$_0();
    // Inline function 'kotlin.collections.mutableListOf' call
    var toSelect = ArrayList_init_$Create$_0();
    // Inline function 'kotlin.collections.filter' call
    // Inline function 'kotlin.collections.filterTo' call
    var destination = ArrayList_init_$Create$_0();
    var _iterator__ex2g4s = currentSelection.i();
    while (_iterator__ex2g4s.j()) {
      var element = _iterator__ex2g4s.k();
      if (!condition(element)) {
        destination.h(element);
      }
    }
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s_0 = destination.i();
    while (_iterator__ex2g4s_0.j()) {
      var element_0 = _iterator__ex2g4s_0.k();
      toDeselect.h(element_0);
    }
    var tmp = this.o4j_1.u3b();
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s_1 = tmp.k21(SelectionManagerImpl$replace$lambda(condition)).i();
    while (_iterator__ex2g4s_1.j()) {
      var element_1 = _iterator__ex2g4s_1.k();
      toSelect.h(element_1);
    }
    // Inline function 'kotlin.collections.isNotEmpty' call
    if (!toDeselect.m()) {
      this.b3e(toDeselect);
    }
    // Inline function 'kotlin.collections.isNotEmpty' call
    if (!toSelect.m()) {
      this.z3d(toSelect);
    }
  };
  function Entry(componentClassName, factory) {
    this.t4j_1 = componentClassName;
    this.u4j_1 = factory;
  }
  protoOf(Entry).toString = function () {
    return 'Entry(componentClassName=' + this.t4j_1 + ', factory=' + toString(this.u4j_1) + ')';
  };
  protoOf(Entry).hashCode = function () {
    var result = getStringHashCode(this.t4j_1);
    result = imul(result, 31) + hashCode(this.u4j_1) | 0;
    return result;
  };
  protoOf(Entry).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof Entry))
      return false;
    if (!(this.t4j_1 === other.t4j_1))
      return false;
    if (!equals(this.u4j_1, other.u4j_1))
      return false;
    return true;
  };
  function SelectionModelFactoryImpl(defaultFactories) {
    defaultFactories = defaultFactories === VOID ? emptyMap() : defaultFactories;
    this.v4j_1 = defaultFactories;
    var tmp = this;
    // Inline function 'kotlin.collections.mutableMapOf' call
    tmp.w4j_1 = LinkedHashMap_init_$Create$();
  }
  protoOf(SelectionModelFactoryImpl).x4j = function (component, strategy) {
    var entries = this.w4j_1.g2(strategy);
    if (!(entries == null)) {
      var tmp$ret$0;
      $l$block: {
        // Inline function 'kotlin.collections.firstOrNull' call
        var _iterator__ex2g4s = entries.i();
        while (_iterator__ex2g4s.j()) {
          var element = _iterator__ex2g4s.k();
          if (element.t4j_1 === System_getInstance().yl(component.d3b())) {
            tmp$ret$0 = element;
            break $l$block;
          }
        }
        tmp$ret$0 = null;
      }
      var entry = tmp$ret$0;
      if (!(entry == null)) {
        return entry.u4j_1(component.d3b());
      }
    }
    var tmp0_safe_receiver = this.v4j_1.g2(strategy);
    var tmp;
    if (tmp0_safe_receiver == null) {
      tmp = null;
    } else {
      // Inline function 'kotlin.let' call
      tmp = tmp0_safe_receiver(component.d3b());
    }
    return tmp;
  };
  protoOf(SelectionModelFactoryImpl).o3v = function (strategy, componentClass, factory) {
    // Inline function 'kotlin.collections.getOrPut' call
    var this_0 = this.w4j_1;
    var value = this_0.g2(strategy);
    var tmp;
    if (value == null) {
      // Inline function 'kotlin.collections.mutableListOf' call
      var answer = ArrayList_init_$Create$_0();
      this_0.y1(strategy, answer);
      tmp = answer;
    } else {
      tmp = value;
    }
    tmp.h(new Entry(System_getInstance().xl(componentClass), factory));
  };
  function _get_LOG__e5r759_9($this) {
    var tmp0 = $this.y4j_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('LOG', 1, tmp, SelectionToolImpl$Companion$_get_LOG_$ref_ftap0(), null);
    return tmp0.j2();
  }
  function SelectionToolImpl$Companion$_get_LOG_$ref_ftap0() {
    return function (p0) {
      return _get_LOG__e5r759_9(p0);
    };
  }
  function Companion_44() {
    Companion_instance_49 = this;
    this.y4j_1 = logger(getKClass(SelectionToolImpl));
  }
  var Companion_instance_49;
  function Companion_getInstance_54() {
    if (Companion_instance_49 == null)
      new Companion_44();
    return Companion_instance_49;
  }
  function updateStatus($this) {
    if ($this.z4j_1.a3d() === $this) {
      Status_getInstance().fu(StatusType_Tool_getInstance(), Translations_getInstance().bn('edit.tool.select.zoom.text', []) + '. ' + CurrentPanMethod_getInstance().p2x_1.mq());
    }
  }
  function selectionLogic($this, e, x, y, allowRubberband) {
    if (CurrentPanMethod_getInstance().p2x_1.g2x(e)) {
      return Unit_instance;
    }
    var component = $this.z4j_1.u3b().i21(x, y);
    if (!(component == null)) {
      var scope = mutableListOf([component]);
      if (e.isMetaDown) {
        // Inline function 'kotlin.collections.mutableSetOf' call
        var buddies = LinkedHashSet_init_$Create$();
        component.h3b($this.z4j_1.u3b(), buddies);
        scope.f1(buddies);
      }
      if (e.isShiftDown) {
        if ($this.z4j_1.v1o().v3b().d3e(component)) {
          _get_LOG__e5r759_9(Companion_getInstance_54()).ql('Removing component from selection');
          $this.z4j_1.v1o().v3b().b3e(scope);
        } else {
          _get_LOG__e5r759_9(Companion_getInstance_54()).ql('Adding component to selection');
          $this.z4j_1.v1o().v3b().z3d(scope);
        }
      } else {
        if (!$this.z4j_1.v1o().v3b().d3e(component)) {
          _get_LOG__e5r759_9(Companion_getInstance_54()).pl('Select single component at ' + numberToInt(x) + '/' + numberToInt(y));
          $this.z4j_1.v1o().v3b().c3e();
          $this.z4j_1.v1o().v3b().z3d(scope);
        }
      }
      $this.z4j_1.c3d().k3k(component, x, y);
      $this.c4k_1 = $this.z4j_1.v1o().d24(e).a23($this.f4k(e, x, y));
    } else {
      if (!e.isShiftDown) {
        $this.z4j_1.v1o().v3b().c3e();
      }
      if (allowRubberband) {
        _get_LOG__e5r759_9(Companion_getInstance_54()).ql('delegating to rubberband');
        $this.c4k_1 = $this.b4k_1;
        var tmp0_safe_receiver = $this.c4k_1;
        if (tmp0_safe_receiver == null)
          null;
        else
          tmp0_safe_receiver.a23($this.f4k(e, x, y));
      }
    }
  }
  function SelectionToolImpl$lambda$lambda(this$0) {
    return function () {
      updateStatus(this$0);
      return Unit_instance;
    };
  }
  function SelectionToolImpl$lambda(this$0) {
    return function (it) {
      var tmp = System_getInstance();
      tmp.fm(SelectionToolImpl$lambda$lambda(this$0));
      return Unit_instance;
    };
  }
  function SelectionToolImpl(editor, rubberBandHandler, eventBus) {
    Companion_getInstance_54();
    ToolAdapter.call(this, editor);
    this.b4k_1 = rubberBandHandler;
    this.c4k_1 = null;
    this.d4k_1 = new TooltipHandler(eventBus);
    this.e4k_1 = false;
    var tmp = getKClass(PreferencesChangedEvent);
    eventBus.z17(tmp, SelectionToolImpl$lambda(this));
  }
  protoOf(SelectionToolImpl).m2v = function () {
    this.z4j_1.v1o().l1y(Cursor_DEFAULT_getInstance());
    updateStatus(this);
  };
  protoOf(SelectionToolImpl).n1a = function (e) {
    if (!this.z4j_1.v1o().r3b()) {
      return Unit_instance;
    }
    _get_LOG__e5r759_9(Companion_getInstance_54()).ql('keyPressed');
    var context = this.g4k(e);
    if (!(this.c4k_1 == null)) {
      var tmp = this;
      var tmp0_safe_receiver = this.c4k_1;
      tmp.c4k_1 = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.d23(context);
      return Unit_instance;
    }
    if (this.z4j_1.c3d().p3k(e) && this.z4j_1.v1o().v3b().w3d() > 0) {
      this.z4j_1.c3d().q3k(e);
    } else {
      this.z4j_1.c3d().d23(context);
    }
  };
  protoOf(SelectionToolImpl).o1a = function (e) {
    if (!this.z4j_1.v1o().r3b()) {
      return Unit_instance;
    }
    _get_LOG__e5r759_9(Companion_getInstance_54()).ql('keyReleased');
    var context = this.g4k(e);
    this.z4j_1.c3d().e23(context);
    var tmp = this;
    var tmp0_safe_receiver = this.c4k_1;
    tmp.c4k_1 = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.e23(context);
  };
  protoOf(SelectionToolImpl).f3f = function (e, x, y) {
    if (!this.z4j_1.v1o().r3b()) {
      return Unit_instance;
    }
    _get_LOG__e5r759_9(Companion_getInstance_54()).ql('mouseClicked at ' + x + ',' + y);
    if (!(this.c4k_1 == null)) {
      var tmp = this;
      var tmp0_safe_receiver = this.c4k_1;
      tmp.c4k_1 = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.y22(this.f4k(e, x, y));
      if (!(this.c4k_1 == null)) {
        return Unit_instance;
      }
    }
    this.c4k_1 = this.z4j_1.v1o().d24(e).y22(this.f4k(e, x, y));
  };
  protoOf(SelectionToolImpl).l3f = function (e, x, y) {
    protoOf(ToolAdapter).l3f.call(this, e, x, y);
    if (!this.z4j_1.v1o().r3b()) {
      return Unit_instance;
    }
    var context = this.f4k(e, x, y);
    if (!(this.c4k_1 == null)) {
      var tmp = this;
      var tmp0_safe_receiver = this.c4k_1;
      tmp.c4k_1 = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.z22(context);
      if (!(this.c4k_1 == null)) {
        return Unit_instance;
      }
    }
    this.c4k_1 = this.z4j_1.v1o().d24(e).z22(context);
    if (this.c4k_1 == null) {
      this.i4k(this.z4j_1.u3b().i21(x, y));
    }
    this.d4k_1.n2y(this.z4j_1.v1o(), this.z4j_1.u3b(), context);
  };
  protoOf(SelectionToolImpl).h3f = function (e, x, y) {
    if (!this.z4j_1.v1o().r3b()) {
      selectionLogic(this, e, x, y, false);
      return Unit_instance;
    }
    this.d4k_1.m2y(this.z4j_1.v1o());
    if (!e.r1a().equals(Button_BUTTON1_getInstance())) {
      return Unit_instance;
    }
    _get_LOG__e5r759_9(Companion_getInstance_54()).ql('mousePressed at ' + x + ',' + y);
    this.e4k_1 = this.z4j_1.d3d().o3a();
    this.z4j_1.d3d().n3a(false);
    if (!(this.c4k_1 == null)) {
      var tmp = this;
      var tmp0_safe_receiver = this.c4k_1;
      tmp.c4k_1 = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.a23(this.f4k(e, x, y));
      if (!(this.c4k_1 == null)) {
        return Unit_instance;
      }
    }
    this.e4k_1 = true;
    this.c4k_1 = this.z4j_1.v1o().d24(e).a23(this.f4k(e, x, y));
    selectionLogic(this, e, x, y, true);
  };
  protoOf(SelectionToolImpl).n3f = function (e, x, y) {
    if (!this.z4j_1.v1o().r3b()) {
      return Unit_instance;
    }
    if (!e.u1a()) {
      _get_LOG__e5r759_9(Companion_getInstance_54()).ql('Drag with other than button 1: ' + e.r1a().k2_1);
      return Unit_instance;
    }
    if (_get_LOG__e5r759_9(Companion_getInstance_54()).sl()) {
      _get_LOG__e5r759_9(Companion_getInstance_54()).ql('drag to ' + x + ',' + y + ', target is ' + toString_0(this.c4k_1));
    }
    var context = this.f4k(e, x, y);
    if (!(this.c4k_1 == null)) {
      var tmp = this;
      var tmp0_safe_receiver = this.c4k_1;
      tmp.c4k_1 = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.b23(context);
      if (!(this.c4k_1 == null)) {
        return Unit_instance;
      }
    }
    this.z4j_1.c3d().b23(context);
  };
  protoOf(SelectionToolImpl).j3f = function (e, x, y) {
    if (!this.z4j_1.v1o().r3b()) {
      return Unit_instance;
    }
    if (!e.r1a().equals(Button_BUTTON1_getInstance())) {
      return Unit_instance;
    }
    _get_LOG__e5r759_9(Companion_getInstance_54()).ql('mouseReleased at ' + x + ',' + y);
    this.z4j_1.d3d().n3a(this.e4k_1);
    var context = this.f4k(e, x, y);
    if (!(this.c4k_1 == null)) {
      var tmp = this;
      var tmp0_safe_receiver = this.c4k_1;
      tmp.c4k_1 = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.c23(context);
    }
    this.z4j_1.c3d().c23(context);
    if (this.c4k_1 == null) {
      this.i4k(this.z4j_1.u3b().i21(x, y));
    }
  };
  function SimpleSelectionModelProvider(factory) {
    this.k4k_1 = factory;
  }
  protoOf(SimpleSelectionModelProvider).v3n = function (component, strategy) {
    var selectionModel = this.k4k_1.x4j(component, strategy);
    if (selectionModel == null)
      null;
    else {
      selectionModel.n3t();
    }
    return selectionModel;
  };
  protoOf(SimpleSelectionModelProvider).s4j = function (selectionModel) {
    selectionModel.gs();
  };
  function UnzoomableSelectionModel() {
  }
  function SemanticRegistry() {
    SemanticRegistry_instance = this;
    var tmp = this;
    // Inline function 'kotlin.collections.mutableSetOf' call
    tmp.l4k_1 = LinkedHashSet_init_$Create$();
  }
  protoOf(SemanticRegistry).m4k = function (semantic) {
    if (this.l4k_1.n(semantic)) {
      throw IllegalArgumentException_init_$Create$('Semantic ' + semantic.u2p() + ' already registered');
    }
    this.l4k_1.h(semantic);
  };
  protoOf(SemanticRegistry).l4f = function (customName) {
    var tmp0 = this.l4k_1;
    var tmp$ret$0;
    $l$block: {
      // Inline function 'kotlin.collections.firstOrNull' call
      var _iterator__ex2g4s = tmp0.i();
      while (_iterator__ex2g4s.j()) {
        var element = _iterator__ex2g4s.k();
        if (element.u2p() === customName) {
          tmp$ret$0 = element;
          break $l$block;
        }
      }
      tmp$ret$0 = null;
    }
    var tmp0_elvis_lhs = tmp$ret$0;
    var tmp;
    if (tmp0_elvis_lhs == null) {
      throw IllegalArgumentException_init_$Create$('Semantic ' + customName + ' not registered');
    } else {
      tmp = tmp0_elvis_lhs;
    }
    return tmp;
  };
  var SemanticRegistry_instance;
  function SemanticRegistry_getInstance() {
    if (SemanticRegistry_instance == null)
      new SemanticRegistry();
    return SemanticRegistry_instance;
  }
  function DoSnapResult(value, snappable) {
    this.n4k_1 = value;
    this.o4k_1 = snappable;
  }
  protoOf(DoSnapResult).toString = function () {
    return 'DoSnapResult(value=' + this.n4k_1 + ', snappable=' + toString_0(this.o4k_1) + ')';
  };
  protoOf(DoSnapResult).hashCode = function () {
    var result = getNumberHashCode(this.n4k_1);
    result = imul(result, 31) + (this.o4k_1 == null ? 0 : hashCode(this.o4k_1)) | 0;
    return result;
  };
  protoOf(DoSnapResult).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof DoSnapResult))
      return false;
    if (!equals(this.n4k_1, other.n4k_1))
      return false;
    if (!equals(this.o4k_1, other.o4k_1))
      return false;
    return true;
  };
  function AbstractSnapper$snappableXFilter$lambda(_unused_var__etf5q3, _unused_var__etf5q3_0) {
    return true;
  }
  function AbstractSnapper$snappableYFilter$lambda(_unused_var__etf5q3, _unused_var__etf5q3_0) {
    return true;
  }
  function AbstractSnapper(snapEnabled) {
    snapEnabled = snapEnabled === VOID ? true : snapEnabled;
    AbstractDrawable.call(this);
    this.s4k_1 = snapEnabled;
    var tmp = this;
    tmp.t4k_1 = AbstractSnapper$snappableXFilter$lambda;
    var tmp_0 = this;
    tmp_0.u4k_1 = AbstractSnapper$snappableYFilter$lambda;
  }
  protoOf(AbstractSnapper).i3k = function () {
    return this.s4k_1;
  };
  protoOf(AbstractSnapper).x3e = function (x, y, result) {
    if (this.i3k()) {
      this.y3e(x, result);
      this.z3e(y, result);
    }
  };
  protoOf(AbstractSnapper).y3e = function (x, result) {
    if (this.i3k()) {
      var tmp0_safe_receiver = this.v4k(new SnappableXCoordinate(x), 0.0);
      if (tmp0_safe_receiver == null)
        null;
      else {
        // Inline function 'kotlin.let' call
        result.p3e(tmp0_safe_receiver.n4k_1 - x, tmp0_safe_receiver.n4k_1, this);
        result.n3e_1 = tmp0_safe_receiver.o4k_1;
      }
    }
  };
  protoOf(AbstractSnapper).z3e = function (y, result) {
    if (this.i3k()) {
      var tmp0_safe_receiver = this.w4k(new SnappableYCoordinate(y), 0.0);
      if (tmp0_safe_receiver == null)
        null;
      else {
        // Inline function 'kotlin.let' call
        result.q3e(tmp0_safe_receiver.n4k_1 - y, tmp0_safe_receiver.n4k_1, this);
        result.o3e_1 = tmp0_safe_receiver.o4k_1;
      }
    }
  };
  protoOf(AbstractSnapper).a3f = function (snappable, dx, dy, result) {
    if (this.i3k()) {
      this.b3f(snappable, dx, result);
      this.c3f(snappable, dy, result);
    }
  };
  protoOf(AbstractSnapper).b3f = function (snappable, dx, result) {
    if (!this.i3k()) {
      return Unit_instance;
    }
    var snappableX = snappable.j3b();
    var minSnapDX = 1.7976931348623157E308;
    var minSnapX = 0.0;
    var minSnappable = null;
    var inductionVariable = 0;
    // Inline function 'kotlin.collections.filterIndexed' call
    var predicate = this.x4k();
    // Inline function 'kotlin.collections.filterIndexedTo' call
    var destination = ArrayList_init_$Create$_0();
    // Inline function 'kotlin.collections.forEachIndexed' call
    var index = 0;
    var inductionVariable_0 = 0;
    var last = snappableX.length;
    while (inductionVariable_0 < last) {
      var item = snappableX[inductionVariable_0];
      inductionVariable_0 = inductionVariable_0 + 1 | 0;
      var _unary__edvuaz = index;
      index = _unary__edvuaz + 1 | 0;
      if (predicate(_unary__edvuaz, item)) {
        destination.h(item);
      }
    }
    var last_0 = destination.o() - 1 | 0;
    if (inductionVariable <= last_0)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        var tmp0_safe_receiver = this.v4k(snappableX[i], dx);
        if (tmp0_safe_receiver == null)
          null;
        else {
          // Inline function 'kotlin.let' call
          var dX = tmp0_safe_receiver.n4k_1 - (snappableX[i].p1a() + dx);
          // Inline function 'kotlin.math.abs' call
          var tmp = Math.abs(dX);
          // Inline function 'kotlin.math.abs' call
          var x = minSnapDX;
          if (tmp < Math.abs(x)) {
            minSnapX = tmp0_safe_receiver.n4k_1;
            minSnapDX = dX;
            minSnappable = tmp0_safe_receiver.o4k_1;
          }
        }
      }
       while (inductionVariable <= last_0);
    if (!(minSnapDX === 1.7976931348623157E308)) {
      result.p3e(minSnapDX, minSnapX, this);
      result.n3e_1 = minSnappable;
    }
  };
  protoOf(AbstractSnapper).c3f = function (snappable, dy, result) {
    if (!this.i3k()) {
      return Unit_instance;
    }
    var snappableY = snappable.k3b();
    var minSnapDY = 1.7976931348623157E308;
    var minSnapY = 0.0;
    var minSnappable = null;
    var inductionVariable = 0;
    // Inline function 'kotlin.collections.filterIndexed' call
    var predicate = this.y4k();
    // Inline function 'kotlin.collections.filterIndexedTo' call
    var destination = ArrayList_init_$Create$_0();
    // Inline function 'kotlin.collections.forEachIndexed' call
    var index = 0;
    var inductionVariable_0 = 0;
    var last = snappableY.length;
    while (inductionVariable_0 < last) {
      var item = snappableY[inductionVariable_0];
      inductionVariable_0 = inductionVariable_0 + 1 | 0;
      var _unary__edvuaz = index;
      index = _unary__edvuaz + 1 | 0;
      if (predicate(_unary__edvuaz, item)) {
        destination.h(item);
      }
    }
    var last_0 = destination.o() - 1 | 0;
    if (inductionVariable <= last_0)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        var tmp0_safe_receiver = this.w4k(snappableY[i], dy);
        if (tmp0_safe_receiver == null)
          null;
        else {
          // Inline function 'kotlin.let' call
          var dY = tmp0_safe_receiver.n4k_1 - (snappableY[i].q1a() + dy);
          // Inline function 'kotlin.math.abs' call
          var tmp = Math.abs(dY);
          // Inline function 'kotlin.math.abs' call
          var x = minSnapDY;
          if (tmp < Math.abs(x)) {
            minSnapY = tmp0_safe_receiver.n4k_1;
            minSnapDY = dY;
            minSnappable = tmp0_safe_receiver.o4k_1;
          }
        }
      }
       while (inductionVariable <= last_0);
    if (!(minSnapDY === 1.7976931348623157E308)) {
      result.q3e(minSnapDY, minSnapY, this);
      result.o3e_1 = minSnappable;
    }
  };
  protoOf(AbstractSnapper).x4k = function () {
    return this.t4k_1;
  };
  protoOf(AbstractSnapper).y4k = function () {
    return this.u4k_1;
  };
  function _get_LOG__e5r759_10($this) {
    var tmp0 = $this.z4k_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('LOG', 1, tmp, ComponentSnapper$Companion$_get_LOG_$ref_5drjbe(), null);
    return tmp0.j2();
  }
  function ComponentSnapper$Companion$_get_LOG_$ref_5drjbe() {
    return function (p0) {
      return _get_LOG__e5r759_10(p0);
    };
  }
  function Companion_45() {
    Companion_instance_50 = this;
    this.z4k_1 = logger(getKClass(ComponentSnapper));
    this.a4l_1 = 'edit.snap.highlight.color';
    this.b4l_1 = 'edit.snap.highlight.stroke';
    this.c4l_1 = 'edit.componentSnap.enabled';
    this.d4l_1 = 15.0;
    this.e4l_1 = new Rectangle2D();
  }
  var Companion_instance_50;
  function Companion_getInstance_55() {
    if (Companion_instance_50 == null)
      new Companion_45();
    return Companion_instance_50;
  }
  function SnapHighlightX($outer) {
    this.l4l_1 = $outer;
    AbstractDrawable.call(this);
    this.i4l_1 = 0;
    this.j4l_1 = null;
    this.k4l_1 = new Rectangle2D();
  }
  protoOf(SnapHighlightX).o2b = function (_set____db54di) {
    this.j4l_1 = _set____db54di;
  };
  protoOf(SnapHighlightX).fo = function () {
    return this.k4l_1;
  };
  protoOf(SnapHighlightX).h20 = function (context) {
    var oldColor = context.j1z_1.c1u();
    var oldStroke = context.j1z_1.l1u();
    context.j1z_1.b1u(DrawModule_getInstance().l2a_1.z1z('edit.snap.highlight.color'));
    context.j1z_1.e1u(DrawModule_getInstance().l2a_1.a20('edit.snap.highlight.stroke'));
    var begin = this.l4l_1.s4l_1.v1o().g25(new Point2D(this.i4l_1, 0.0));
    context.j1z_1.s1u(numberToInt(begin.kn_1), 0, numberToInt(begin.kn_1), this.l4l_1.s4l_1.v1o().h1c());
    context.j1z_1.b1u(oldColor);
    context.j1z_1.e1u(oldStroke);
  };
  protoOf(SnapHighlightX).go = function (x, y) {
    return false;
  };
  protoOf(SnapHighlightX).w4l = function (x) {
    var lineWidth = DrawModule_getInstance().l2a_1.a20('edit.snap.highlight.stroke').f1u_1;
    this.i20();
    this.i4l_1 = x;
    this.k4l_1.i1c(this.i4l_1 - lineWidth / 2, this.l4l_1.s4l_1.v1o().c25(0.0), lineWidth, this.l4l_1.s4l_1.v1o().c25(this.l4l_1.s4l_1.v1o().h1c()) - this.l4l_1.s4l_1.v1o().c25(0.0));
    this.i20();
  };
  function SnapHighlightY($outer) {
    this.d4m_1 = $outer;
    AbstractDrawable.call(this);
    this.a4m_1 = 0;
    this.b4m_1 = null;
    this.c4m_1 = new Rectangle2D();
  }
  protoOf(SnapHighlightY).o2b = function (_set____db54di) {
    this.b4m_1 = _set____db54di;
  };
  protoOf(SnapHighlightY).fo = function () {
    return this.c4m_1;
  };
  protoOf(SnapHighlightY).h20 = function (context) {
    var oldColor = context.j1z_1.c1u();
    var oldStroke = context.j1z_1.l1u();
    context.j1z_1.b1u(DrawModule_getInstance().l2a_1.z1z('edit.snap.highlight.color'));
    context.j1z_1.e1u(DrawModule_getInstance().l2a_1.a20('edit.snap.highlight.stroke'));
    var begin = this.d4m_1.s4l_1.v1o().g25(new Point2D(0.0, this.a4m_1));
    context.j1z_1.s1u(0, numberToInt(begin.ln_1), this.d4m_1.s4l_1.v1o().f1c(), numberToInt(begin.ln_1));
    context.j1z_1.b1u(oldColor);
    context.j1z_1.e1u(oldStroke);
  };
  protoOf(SnapHighlightY).go = function (x, y) {
    return false;
  };
  protoOf(SnapHighlightY).e4m = function (y) {
    var lineWidth = DrawModule_getInstance().l2a_1.a20('edit.snap.highlight.stroke').f1u_1;
    this.i20();
    this.a4m_1 = y;
    this.c4m_1.i1c(this.d4m_1.s4l_1.v1o().b25(0.0), this.a4m_1 - lineWidth / 2, this.d4m_1.s4l_1.v1o().b25(this.d4m_1.s4l_1.v1o().f1c()) - this.d4m_1.s4l_1.v1o().b25(0.0), lineWidth);
    this.i20();
  };
  function ComponentSnapper(editor) {
    Companion_getInstance_55();
    AbstractSnapper.call(this, BaseModule_getInstance().ap_1.ut('edit.componentSnap.enabled', false));
    this.s4l_1 = editor;
    this.t4l_1 = null;
    this.u4l_1 = null;
    this.v4l_1 = Companion_getInstance_55().e4l_1;
  }
  protoOf(ComponentSnapper).fo = function () {
    return this.v4l_1;
  };
  protoOf(ComponentSnapper).h20 = function (context) {
  };
  protoOf(ComponentSnapper).go = function (x, y) {
    return false;
  };
  protoOf(ComponentSnapper).i3k = function () {
    return protoOf(AbstractSnapper).i3k.call(this);
  };
  protoOf(ComponentSnapper).v4k = function (initSnappableX, initDx) {
    var minSnapDX = 1.7976931348623157E308;
    var minSnapX = 1.7976931348623157E308;
    var otherSnappableX;
    var dx;
    var minSnappable = null;
    var iter = this.s4l_1.u3b().d21();
    $l$loop: while (iter.j()) {
      var comp = iter.k();
      if (this.s4l_1.v1o().v3b().d3e(comp)) {
        continue $l$loop;
      }
      otherSnappableX = comp.j3b();
      var inductionVariable = 0;
      var last = otherSnappableX.length - 1 | 0;
      if (inductionVariable <= last)
        $l$loop_1: do {
          var i = inductionVariable;
          inductionVariable = inductionVariable + 1 | 0;
          if (!initSnappableX.u3e(otherSnappableX[i]) || !otherSnappableX[i].u3e(initSnappableX)) {
            continue $l$loop_1;
          }
          if (otherSnappableX[i].p1a() < initDx + initSnappableX.p1a() - 15.0 || otherSnappableX[i].p1a() > initDx + initSnappableX.p1a() + 15.0) {
            continue $l$loop_1;
          }
          dx = otherSnappableX[i].p1a() - (initDx + initSnappableX.p1a());
          // Inline function 'kotlin.math.abs' call
          var tmp = Math.abs(dx);
          // Inline function 'kotlin.math.abs' call
          var x = minSnapDX;
          if (tmp < Math.abs(x)) {
            minSnapDX = dx;
            minSnapX = otherSnappableX[i].p1a();
            minSnappable = comp;
          }
        }
         while (inductionVariable <= last);
    }
    var tmp0_safe_receiver = minSnappable;
    var tmp_0;
    if (tmp0_safe_receiver == null) {
      tmp_0 = null;
    } else {
      // Inline function 'kotlin.let' call
      tmp_0 = new DoSnapResult(minSnapX, tmp0_safe_receiver);
    }
    return tmp_0;
  };
  protoOf(ComponentSnapper).w4k = function (initSnappableY, initDy) {
    var minSnapDY = 1.7976931348623157E308;
    var minSnapY = 1.7976931348623157E308;
    var otherSnappableY;
    var dy;
    var minSnappable = null;
    var iter = this.s4l_1.u3b().d21();
    $l$loop: while (iter.j()) {
      var comp = iter.k();
      if (this.s4l_1.v1o().v3b().d3e(comp)) {
        continue $l$loop;
      }
      otherSnappableY = comp.k3b();
      var inductionVariable = 0;
      var last = otherSnappableY.length - 1 | 0;
      if (inductionVariable <= last)
        $l$loop_1: do {
          var i = inductionVariable;
          inductionVariable = inductionVariable + 1 | 0;
          if (!initSnappableY.w3e(otherSnappableY[i]) && !otherSnappableY[i].w3e(initSnappableY)) {
            continue $l$loop_1;
          }
          if (otherSnappableY[i].q1a() < initDy + initSnappableY.q1a() - 15.0 || otherSnappableY[i].q1a() > initDy + initSnappableY.q1a() + 15.0) {
            continue $l$loop_1;
          }
          dy = otherSnappableY[i].q1a() - (initDy + initSnappableY.q1a());
          // Inline function 'kotlin.math.abs' call
          var tmp = Math.abs(dy);
          // Inline function 'kotlin.math.abs' call
          var x = minSnapDY;
          if (tmp < Math.abs(x)) {
            minSnapDY = dy;
            minSnapY = otherSnappableY[i].q1a();
            minSnappable = comp;
          }
        }
         while (inductionVariable <= last);
    }
    var tmp0_safe_receiver = minSnappable;
    var tmp_0;
    if (tmp0_safe_receiver == null) {
      tmp_0 = null;
    } else {
      // Inline function 'kotlin.let' call
      tmp_0 = new DoSnapResult(minSnapY, tmp0_safe_receiver);
    }
    return tmp_0;
  };
  protoOf(ComponentSnapper).d3f = function (x, y, snappable) {
    _get_LOG__e5r759_10(Companion_getInstance_55()).ql('getSnapHighlightX for ' + x);
    if (!(snappable == null)) {
      var snappableHighlight = snappable.l3b(x, y);
      if (!(snappableHighlight == null)) {
        return snappableHighlight;
      }
    }
    if (this.t4l_1 == null) {
      this.t4l_1 = new SnapHighlightX(this);
    }
    ensureNotNull(this.t4l_1).w4l(x);
    return this.t4l_1;
  };
  protoOf(ComponentSnapper).e3f = function (x, y, snappable) {
    _get_LOG__e5r759_10(Companion_getInstance_55()).ql('getSnapHighlightX for ' + y);
    if (!(snappable == null)) {
      var snappableHighlight = snappable.m3b(x, y);
      if (!(snappableHighlight == null)) {
        return snappableHighlight;
      }
    }
    if (this.u4l_1 == null) {
      this.u4l_1 = new SnapHighlightY(this);
    }
    ensureNotNull(this.u4l_1).e4m(y);
    return this.u4l_1;
  };
  function Companion_46() {
    Companion_instance_51 = this;
    this.f4m_1 = 'dot';
    this.g4m_1 = logger(getKClass(DottedGridPainter));
  }
  var Companion_instance_51;
  function Companion_getInstance_56() {
    if (Companion_instance_51 == null)
      new Companion_46();
    return Companion_instance_51;
  }
  function DottedGridPainter(styleProvider) {
    Companion_getInstance_56();
    this.h4m_1 = styleProvider;
    this.i4m_1 = 10.0;
    this.j4m_1 = 10.0;
    this.k4m_1 = null;
  }
  protoOf(DottedGridPainter).l4m = function (_set____db54di) {
    this.i4m_1 = _set____db54di;
  };
  protoOf(DottedGridPainter).m4m = function (_set____db54di) {
    this.j4m_1 = _set____db54di;
  };
  protoOf(DottedGridPainter).o2b = function (_set____db54di) {
    this.k4m_1 = _set____db54di;
  };
  protoOf(DottedGridPainter).n4m = function (context, rect) {
    var oldColor = context.j1z_1.c1u();
    context.j1z_1.b1u(this.h4m_1.f1y(Companion_getInstance_0().d1y_1).c1u().x1x_1);
    var dx = this.i4m_1 * ensureNotNull(this.k4m_1).k24_1;
    var dy = this.j4m_1 * ensureNotNull(this.k4m_1).k24_1;
    var tmp = ensureNotNull(this.k4m_1).j24_1;
    var tmp_0 = this.i4m_1;
    // Inline function 'kotlin.math.floor' call
    var x = ensureNotNull(this.k4m_1).j24_1.b25(rect.u1h_1) / this.i4m_1;
    var tmp_1 = tmp_0 * Math.floor(x);
    var tmp_2 = this.j4m_1;
    // Inline function 'kotlin.math.floor' call
    var x_0 = ensureNotNull(this.k4m_1).j24_1.c25(rect.v1h_1) / this.j4m_1;
    var tmp$ret$1 = Math.floor(x_0);
    var low = tmp.g25(new Point2D(tmp_1, tmp_2 * tmp$ret$1));
    var tmp_3 = ensureNotNull(this.k4m_1).j24_1;
    var tmp_4 = this.i4m_1;
    // Inline function 'kotlin.math.ceil' call
    var x_1 = ensureNotNull(this.k4m_1).j24_1.b25(rect.b1d()) / this.i4m_1;
    var tmp_5 = tmp_4 * Math.ceil(x_1);
    var tmp_6 = this.j4m_1;
    // Inline function 'kotlin.math.ceil' call
    var x_2 = ensureNotNull(this.k4m_1).j24_1.c25(rect.c1d()) / this.j4m_1;
    var tmp$ret$3 = Math.ceil(x_2);
    var high = tmp_3.g25(new Point2D(tmp_5, tmp_6 * tmp$ret$3));
    var x_3 = low.kn_1;
    while (x_3 <= high.kn_1) {
      var y = low.ln_1;
      while (y <= high.ln_1) {
        context.j1z_1.i1v(numberToInt(x_3), numberToInt(y));
        y = y + dy;
      }
      x_3 = x_3 + dx;
    }
    context.j1z_1.b1u(oldColor);
  };
  function fillProperties_2($this, properties) {
    properties.et('edit.grid.distance.default', 10);
    properties.et('edit.grid.distance.min', 8);
    properties.et('edit.grid.paintFactor.default', 2);
    properties.et('edit.snap.highlight.color', Companion_getInstance_3().k1t_1);
    properties.et('edit.snap.highlight.stroke', new Stroke(0.5));
  }
  function EditSnapModule() {
    EditSnapModule_instance = this;
    AbstractModule.call(this);
  }
  protoOf(EditSnapModule).to = function () {
    fillProperties_2(this, BaseModule_getInstance().zo_1);
  };
  var EditSnapModule_instance;
  function EditSnapModule_getInstance() {
    if (EditSnapModule_instance == null)
      new EditSnapModule();
    return EditSnapModule_instance;
  }
  function _get_LOG__e5r759_11($this) {
    var tmp0 = $this.p4m_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('LOG', 1, tmp, GridImpl$Companion$_get_LOG_$ref_bqzgwq(), null);
    return tmp0.j2();
  }
  function GridImpl$Companion$_get_LOG_$ref_bqzgwq() {
    return function (p0) {
      return _get_LOG__e5r759_11(p0);
    };
  }
  function Companion_47() {
    Companion_instance_52 = this;
    this.p4m_1 = logger(getKClass(GridImpl));
  }
  var Companion_instance_52;
  function Companion_getInstance_57() {
    if (Companion_instance_52 == null)
      new Companion_47();
    return Companion_instance_52;
  }
  function _get_configuredGridPainter__gh08eu($this) {
    return GridPainterRegistry_getInstance().ob(BaseModule_getInstance().zo_1.jt('edit.grid.painter'))($this.w4m_1);
  }
  function snapValue($this, d) {
    var q = d / $this.r3k();
    // Inline function 'kotlin.math.floor' call
    var floor = Math.floor(q);
    var ceil = floor + 1;
    if (q - floor < ceil - q) {
      return floor * $this.r3k();
    }
    return ceil * $this.r3k();
  }
  function updateGridPainterProperties($this) {
    $this.z4m_1.l4m($this.r3k() * $this.h4n());
    $this.z4m_1.m4m($this.r3k() * $this.h4n());
    $this.z4m_1.o2b($this.e4n_1);
  }
  function GridImpl$preferencesHandler$lambda(this$0) {
    return function (it) {
      this$0.i4n(_get_configuredGridPainter__gh08eu(this$0));
      updateGridPainterProperties(this$0);
      this$0.i20();
      this$0.s2a();
      return Unit_instance;
    };
  }
  function GridImpl$snappableXFilter$lambda(i, _unused_var__etf5q3) {
    return i === 0;
  }
  function GridImpl$snappableYFilter$lambda(i, _unused_var__etf5q3) {
    return i === 0;
  }
  function GridImpl(styleProvider, chosenDistance, chosenPaintFactor, eventBus) {
    Companion_getInstance_57();
    styleProvider = styleProvider === VOID ? Companion_getInstance_6().n2s_1 : styleProvider;
    chosenDistance = chosenDistance === VOID ? null : chosenDistance;
    chosenPaintFactor = chosenPaintFactor === VOID ? null : chosenPaintFactor;
    eventBus = eventBus === VOID ? BaseModule_getInstance().bp_1 : eventBus;
    AbstractSnapper.call(this, BaseModule_getInstance().ap_1.ut('edit.grid.snapEnabled', true));
    this.w4m_1 = styleProvider;
    this.x4m_1 = eventBus;
    this.y4m_1 = new Rectangle2D();
    this.z4m_1 = _get_configuredGridPainter__gh08eu(this);
    this.a4n_1 = chosenPaintFactor;
    this.b4n_1 = chosenDistance;
    var tmp = this;
    tmp.c4n_1 = GridImpl$preferencesHandler$lambda(this);
    _get_LOG__e5r759_11(Companion_getInstance_57()).kl('Snap to grid enabled=' + BaseModule_getInstance().ap_1.ut('edit.grid.snapEnabled', true));
    this.x4m_1.z17(getKClass(PreferencesChangedEvent), this.c4n_1);
    updateGridPainterProperties(this);
    this.d4n_1 = null;
    this.e4n_1 = null;
    var tmp_0 = this;
    tmp_0.f4n_1 = GridImpl$snappableXFilter$lambda;
    var tmp_1 = this;
    tmp_1.g4n_1 = GridImpl$snappableYFilter$lambda;
  }
  protoOf(GridImpl).i4n = function (value) {
    if (!equals(this.z4m_1, value)) {
      this.i20();
      this.z4m_1 = value;
      updateGridPainterProperties(this);
      this.i20();
      this.k20();
    }
  };
  protoOf(GridImpl).h4n = function () {
    var tmp0_elvis_lhs = this.a4n_1;
    return tmp0_elvis_lhs == null ? BaseModule_getInstance().zo_1.kt('edit.grid.paintFactor.default') : tmp0_elvis_lhs;
  };
  protoOf(GridImpl).r3k = function () {
    var tmp0_elvis_lhs = this.b4n_1;
    return tmp0_elvis_lhs == null ? BaseModule_getInstance().zo_1.kt('edit.grid.distance.default') : tmp0_elvis_lhs;
  };
  protoOf(GridImpl).gs = function () {
    protoOf(AbstractSnapper).gs.call(this);
    this.x4m_1.a18(getKClass(PreferencesChangedEvent), this.c4n_1);
  };
  protoOf(GridImpl).j4n = function (value) {
    if (value == null) {
      throw IllegalArgumentException_init_$Create$('view must not be null');
    }
    this.d4n_1 = value;
    this.o2b(ensureNotNull(this.d4n_1).h24());
  };
  protoOf(GridImpl).o2b = function (value) {
    this.e4n_1 = value;
    this.i20();
    updateGridPainterProperties(this);
    this.i20();
  };
  protoOf(GridImpl).fo = function () {
    if (this.d4n_1 == null) {
      return new Rectangle2D();
    }
    return new Rectangle2D(0.0, 0.0, ensureNotNull(this.d4n_1).f1c(), ensureNotNull(this.d4n_1).h1c());
  };
  protoOf(GridImpl).go = function (x, y) {
    return true;
  };
  protoOf(GridImpl).h20 = function (context) {
    if (ensureNotNull(this.e4n_1).k24_1 * this.r3k() * this.h4n() < BaseModule_getInstance().zo_1.kt('edit.grid.distance.min')) {
      return Unit_instance;
    }
    if (context.j1z_1.w1t()) {
      context.j1z_1.m1v(this.y4m_1);
      this.z4m_1.n4m(context, this.y4m_1);
    } else {
      if (!(this.d4n_1 == null)) {
        this.z4m_1.n4m(context, Rectangle2D_init_$Create$_0(0, 0, ensureNotNull(this.d4n_1).f1c(), ensureNotNull(this.d4n_1).h1c()));
      }
    }
  };
  protoOf(GridImpl).i3k = function () {
    return protoOf(AbstractSnapper).i3k.call(this);
  };
  protoOf(GridImpl).v4k = function (initSnappableX, initDx) {
    return new DoSnapResult(snapValue(this, initSnappableX.p1a() + initDx), null);
  };
  protoOf(GridImpl).w4k = function (initSnappableY, initDy) {
    return new DoSnapResult(snapValue(this, initSnappableY.q1a() + initDy), null);
  };
  protoOf(GridImpl).x4k = function () {
    return this.f4n_1;
  };
  protoOf(GridImpl).y4k = function () {
    return this.g4n_1;
  };
  function Companion_48() {
    this.k4n_1 = 'line';
  }
  var Companion_instance_53;
  function Companion_getInstance_58() {
    return Companion_instance_53;
  }
  function LineGridPainter(styleProvider) {
    this.l4n_1 = styleProvider;
    this.m4n_1 = 10.0;
    this.n4n_1 = 10.0;
    this.o4n_1 = null;
  }
  protoOf(LineGridPainter).l4m = function (_set____db54di) {
    this.m4n_1 = _set____db54di;
  };
  protoOf(LineGridPainter).m4m = function (_set____db54di) {
    this.n4n_1 = _set____db54di;
  };
  protoOf(LineGridPainter).o2b = function (_set____db54di) {
    this.o4n_1 = _set____db54di;
  };
  protoOf(LineGridPainter).n4m = function (context, rect) {
    var oldColor = context.j1z_1.c1u();
    context.j1z_1.b1u(this.l4n_1.f1y(Companion_getInstance_0().d1y_1).c1u().x1x_1);
    var dx = this.m4n_1 * ensureNotNull(this.o4n_1).k24_1;
    var dy = this.n4n_1 * ensureNotNull(this.o4n_1).k24_1;
    var tmp = ensureNotNull(this.o4n_1).j24_1;
    var tmp_0 = this.m4n_1;
    // Inline function 'kotlin.math.floor' call
    var x = ensureNotNull(this.o4n_1).j24_1.b25(rect.u1h_1) / this.m4n_1;
    var tmp_1 = tmp_0 * Math.floor(x);
    var tmp_2 = this.n4n_1;
    // Inline function 'kotlin.math.floor' call
    var x_0 = ensureNotNull(this.o4n_1).j24_1.c25(rect.v1h_1) / this.n4n_1;
    var tmp$ret$1 = Math.floor(x_0);
    var low = tmp.g25(new Point2D(tmp_1, tmp_2 * tmp$ret$1));
    var tmp_3 = ensureNotNull(this.o4n_1).j24_1;
    var tmp_4 = this.m4n_1;
    // Inline function 'kotlin.math.ceil' call
    var x_1 = ensureNotNull(this.o4n_1).j24_1.b25(rect.b1d()) / this.m4n_1;
    var tmp_5 = tmp_4 * Math.ceil(x_1);
    var tmp_6 = this.n4n_1;
    // Inline function 'kotlin.math.ceil' call
    var x_2 = ensureNotNull(this.o4n_1).j24_1.c25(rect.c1d()) / this.n4n_1;
    var tmp$ret$3 = Math.ceil(x_2);
    var high = tmp_3.g25(new Point2D(tmp_5, tmp_6 * tmp$ret$3));
    var x_3 = low.kn_1;
    while (x_3 <= high.kn_1) {
      context.j1z_1.t1u(x_3, low.ln_1, x_3, high.ln_1);
      x_3 = x_3 + dx;
    }
    var y = low.ln_1;
    while (y <= high.ln_1) {
      context.j1z_1.t1u(low.kn_1, y, high.kn_1, y);
      y = y + dy;
    }
    context.j1z_1.b1u(oldColor);
  };
  function MultiComponentSnappable(components) {
    this.p4n_1 = toList(components);
  }
  protoOf(MultiComponentSnappable).j3b = function () {
    // Inline function 'kotlin.collections.mutableListOf' call
    var result = ArrayList_init_$Create$_0();
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = this.p4n_1.i();
    while (_iterator__ex2g4s.j()) {
      var element = _iterator__ex2g4s.k();
      addAll(result, element.j3b());
    }
    // Inline function 'kotlin.collections.toTypedArray' call
    return copyToArray(result);
  };
  protoOf(MultiComponentSnappable).k3b = function () {
    // Inline function 'kotlin.collections.mutableListOf' call
    var result = ArrayList_init_$Create$_0();
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = this.p4n_1.i();
    while (_iterator__ex2g4s.j()) {
      var element = _iterator__ex2g4s.k();
      addAll(result, element.k3b());
    }
    // Inline function 'kotlin.collections.toTypedArray' call
    return copyToArray(result);
  };
  function _get_LOG__e5r759_12($this) {
    var tmp0 = $this.q4n_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('LOG', 1, tmp, SnapManagerImpl$Companion$_get_LOG_$ref_xwqfj7(), null);
    return tmp0.j2();
  }
  function SnapManagerImpl$Companion$_get_LOG_$ref_xwqfj7() {
    return function (p0) {
      return _get_LOG__e5r759_12(p0);
    };
  }
  function SnapManagerImpl_init_$Init$(editor, $this) {
    SnapManagerImpl.call($this, editor, BaseModule_getInstance().bp_1);
    return $this;
  }
  function SnapManagerImpl_init_$Create$(editor) {
    return SnapManagerImpl_init_$Init$(editor, objectCreate(protoOf(SnapManagerImpl)));
  }
  function Companion_49() {
    Companion_instance_54 = this;
    this.q4n_1 = logger(getKClass(SnapManagerImpl));
    this.r4n_1 = Companion_getInstance().w1a_1;
  }
  var Companion_instance_54;
  function Companion_getInstance_59() {
    if (Companion_instance_54 == null)
      new Companion_49();
    return Companion_instance_54;
  }
  function highlightSnapX($this, y) {
    var newHighlightX = null;
    if ($this.u4n_1.j3e_1) {
      newHighlightX = ensureNotNull($this.u4n_1.l3e_1).d3f($this.u4n_1.f3e_1, $this.u4n_1.k3e_1 ? $this.u4n_1.g3e_1 : y, $this.u4n_1.n3e_1);
    }
    if (!($this.v4n_1 == null) && (newHighlightX == null || !(newHighlightX === $this.v4n_1))) {
      $this.s4n_1.v1o().z3b().c21(ensureNotNull($this.v4n_1));
    }
    if (!(newHighlightX == null) && $this.u4n_1.j3e_1) {
      _get_LOG__e5r759_12(Companion_getInstance_59()).ql('Highlight x coordinate at ' + $this.u4n_1.f3e_1);
      $this.s4n_1.v1o().z3b().b21(newHighlightX);
    }
    $this.v4n_1 = newHighlightX;
  }
  function highlightSnapY($this, x) {
    var newHighlightY = null;
    if ($this.u4n_1.k3e_1) {
      newHighlightY = ensureNotNull($this.u4n_1.m3e_1).e3f($this.u4n_1.j3e_1 ? $this.u4n_1.f3e_1 : x, $this.u4n_1.g3e_1, $this.u4n_1.o3e_1);
    }
    if (!($this.w4n_1 == null) && (newHighlightY == null || !(newHighlightY === $this.w4n_1))) {
      $this.s4n_1.v1o().z3b().c21(ensureNotNull($this.w4n_1));
    }
    if (!(newHighlightY == null) && $this.u4n_1.k3e_1) {
      _get_LOG__e5r759_12(Companion_getInstance_59()).ql('Highlight y coordinate at ' + $this.u4n_1.g3e_1);
      $this.s4n_1.v1o().z3b().b21(newHighlightY);
    }
    $this.w4n_1 = newHighlightY;
  }
  function removeAllHighlights($this) {
    var removed = false;
    if ($this.v4n_1 == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      _get_LOG__e5r759_12(Companion_getInstance_59()).ql('removing highlightX from view');
      $this.s4n_1.v1o().z3b().c21(ensureNotNull($this.v4n_1));
      removed = true;
      $this.v4n_1 = null;
    }
    if ($this.w4n_1 == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      _get_LOG__e5r759_12(Companion_getInstance_59()).ql('removing highlightY from view');
      $this.s4n_1.v1o().z3b().c21(ensureNotNull($this.w4n_1));
      removed = true;
      $this.w4n_1 = null;
    }
    if (removed) {
      $this.s4n_1.v1o().z3b().k20();
    }
  }
  function SnapManagerImpl$mouseListener$1(this$0) {
    this.b4o_1 = this$0;
    MouseAdapter.call(this);
  }
  protoOf(SnapManagerImpl$mouseListener$1).j1b = function (e) {
    removeAllHighlights(this.b4o_1);
  };
  function SnapManagerImpl$viewCanvasListener$1(this$0) {
    this.c4o_1 = this$0;
  }
  protoOf(SnapManagerImpl$viewCanvasListener$1).propertyChanged = function (e) {
    if (e.name === 'PROP_CANVAS') {
      this.c4o_1.s4n_1.v1o().r1y(this.c4o_1.x4n_1);
    }
  };
  function SnapManagerImpl$lambda(this$0) {
    return function (it) {
      removeAllHighlights(this$0);
      return Unit_instance;
    };
  }
  function SnapManagerImpl(editor, eventBus) {
    Companion_getInstance_59();
    this.s4n_1 = editor;
    var tmp = this;
    // Inline function 'kotlin.collections.mutableListOf' call
    tmp.t4n_1 = ArrayList_init_$Create$_0();
    this.u4n_1 = new SnapResult();
    this.v4n_1 = null;
    this.w4n_1 = null;
    var tmp_0 = this;
    tmp_0.x4n_1 = new SnapManagerImpl$mouseListener$1(this);
    var tmp_1 = this;
    tmp_1.y4n_1 = new SnapManagerImpl$viewCanvasListener$1(this);
    this.s4n_1.v1o().b1z(this.y4n_1);
    var tmp_2 = getKClass(DropEvent);
    eventBus.z17(tmp_2, SnapManagerImpl$lambda(this));
    this.z4n_1 = true;
    this.a4o_1 = true;
  }
  protoOf(SnapManagerImpl).i3k = function () {
    return this.z4n_1;
  };
  protoOf(SnapManagerImpl).h3m = function (snapper) {
    if (!this.t4n_1.n(snapper)) {
      _get_LOG__e5r759_12(Companion_getInstance_59()).ql("adding snapper '" + System_getInstance().yl(snapper) + "'");
      this.t4n_1.h(snapper);
    }
  };
  protoOf(SnapManagerImpl).v43 = function (x, y) {
    if (!this.z4n_1) {
      return Companion_getInstance_59().r4n_1;
    }
    var snapX = x;
    var snapY = y;
    var index = 0;
    var done = false;
    this.u4n_1.du();
    while (!done && index < this.t4n_1.o()) {
      if (this.u4n_1.j3e_1 && this.u4n_1.k3e_1) {
        done = true;
      } else if (!this.u4n_1.j3e_1 && !this.u4n_1.k3e_1) {
        snapX = snapX + this.u4n_1.h3e_1;
        snapY = snapY + this.u4n_1.i3e_1;
        this.t4n_1.l(index).x3e(snapX, snapY, this.u4n_1);
      } else if (!this.u4n_1.j3e_1) {
        snapX = snapX + this.u4n_1.h3e_1;
        this.t4n_1.l(index).y3e(snapX, this.u4n_1);
      } else if (!this.u4n_1.k3e_1) {
        snapY = snapY + this.u4n_1.i3e_1;
        this.t4n_1.l(index).z3e(snapY, this.u4n_1);
      }
      index = index + 1 | 0;
    }
    index = index - 2 | 0;
    while (index >= 0) {
      snapX = x + this.u4n_1.h3e_1;
      snapY = y + this.u4n_1.i3e_1;
      this.t4n_1.l(index).x3e(snapX, snapY, this.u4n_1);
      index = index - 1 | 0;
    }
    if (this.a4o_1) {
      highlightSnapX(this, y);
      highlightSnapY(this, x);
      this.s4n_1.v1o().z3b().k20();
    }
    return new Point2D(this.u4n_1.h3e_1, this.u4n_1.i3e_1);
  };
  protoOf(SnapManagerImpl).d4o = function (x, y) {
    if (!this.z4n_1) {
      return 0.0;
    }
    var snapX = x;
    var index = 0;
    var done = false;
    this.u4n_1.du();
    while (!done && index < this.t4n_1.o()) {
      var snapper = this.t4n_1.l(index);
      if (this.u4n_1.j3e_1) {
        done = true;
      } else {
        snapX = snapX + this.u4n_1.h3e_1;
        snapper.y3e(snapX, this.u4n_1);
      }
      index = index + 1 | 0;
    }
    snapX = x;
    index = index - 2 | 0;
    while (index >= 0) {
      var snapper_0 = this.t4n_1.l(index);
      snapX = snapX + this.u4n_1.h3e_1;
      snapper_0.y3e(snapX, this.u4n_1);
      index = index - 1 | 0;
    }
    if (this.a4o_1) {
      highlightSnapX(this, y);
      this.s4n_1.v1o().z3b().k20();
    }
    return this.u4n_1.h3e_1;
  };
  protoOf(SnapManagerImpl).e4o = function (x, y) {
    if (!this.z4n_1) {
      return 0.0;
    }
    var snapY = y;
    var index = 0;
    var done = false;
    this.u4n_1.du();
    while (!done && index < this.t4n_1.o()) {
      var snapper = this.t4n_1.l(index);
      if (this.u4n_1.k3e_1) {
        done = true;
      } else {
        snapY = snapY + this.u4n_1.i3e_1;
        snapper.z3e(snapY, this.u4n_1);
      }
      index = index + 1 | 0;
    }
    snapY = y;
    index = index - 2 | 0;
    while (index >= 0) {
      var snapper_0 = this.t4n_1.l(index);
      snapY = snapY + this.u4n_1.i3e_1;
      snapper_0.z3e(snapY, this.u4n_1);
      index = index - 1 | 0;
    }
    if (this.a4o_1) {
      highlightSnapY(this, x);
      this.s4n_1.v1o().z3b().k20();
    }
    return this.u4n_1.i3e_1;
  };
  protoOf(SnapManagerImpl).h3k = function (snappable, dx, dy) {
    if (!this.z4n_1) {
      return Companion_getInstance().w1a_1;
    }
    var snapDX = dx;
    var snapDY = dy;
    var index = 0;
    var done = false;
    this.u4n_1.du();
    while (!done && index < this.t4n_1.o()) {
      var snapper = this.t4n_1.l(index);
      if (this.u4n_1.j3e_1 && this.u4n_1.k3e_1) {
        done = true;
      } else if (!this.u4n_1.j3e_1 && !this.u4n_1.k3e_1) {
        snapDX = snapDX + this.u4n_1.h3e_1;
        snapDY = snapDY + this.u4n_1.i3e_1;
        snapper.a3f(snappable, snapDX, snapDY, this.u4n_1);
      } else if (!this.u4n_1.j3e_1) {
        snapDX = snapDX + this.u4n_1.h3e_1;
        snapper.b3f(snappable, snapDX, this.u4n_1);
      } else if (!this.u4n_1.k3e_1) {
        snapDY = snapDY + this.u4n_1.i3e_1;
        snapper.c3f(snappable, snapDY, this.u4n_1);
      }
      index = index + 1 | 0;
    }
    index = index - 2 | 0;
    while (index >= 0) {
      var snapper_0 = this.t4n_1.l(index);
      snapDX = dx + this.u4n_1.h3e_1;
      snapDY = dy + this.u4n_1.i3e_1;
      snapper_0.a3f(snappable, snapDX, snapDY, this.u4n_1);
      index = index - 1 | 0;
    }
    if (this.a4o_1) {
      highlightSnapX(this, 0.0);
      highlightSnapY(this, 0.0);
      this.s4n_1.v1o().z3b().k20();
    }
    return new Point2D(this.u4n_1.h3e_1, this.u4n_1.i3e_1);
  };
  protoOf(SnapManagerImpl).oc = function () {
    removeAllHighlights(this);
  };
  function Companion_50() {
    Companion_instance_55 = this;
    this.f3o_1 = new EditStyleType('selection', 'edit.styleType.selection.name', true);
    this.g3o_1 = new EditStyleType('highlight', 'edit.styleType.highlight.name', true);
    this.h3o_1 = new EditStyleType('message-info', 'edit.styleType.message-info.name', true);
    this.i3o_1 = new EditStyleType('message-error', 'edit.styleType.message-error.name', true);
  }
  var Companion_instance_55;
  function Companion_getInstance_60() {
    if (Companion_instance_55 == null)
      new Companion_50();
    return Companion_instance_55;
  }
  function EditStyleType(name, descriptionKey, isSystem, isBackdrop) {
    Companion_getInstance_60();
    isSystem = isSystem === VOID ? false : isSystem;
    isBackdrop = isBackdrop === VOID ? false : isBackdrop;
    StyleType.call(this, name, descriptionKey, isSystem, isBackdrop);
  }
  function Companion_51() {
    Companion_instance_56 = this;
    this.f4o_1 = new CompositeColor(Color_init_$Create$(237, 76, 48), Color_init_$Create$(251, 225, 216), Companion_getInstance_3().d1t_1);
    var tmp = this;
    var tmp0_backgroundColor = Color_init_$Create$(198, 226, 184);
    var tmp1_foregroundColor = Color_init_$Create$(115, 191, 91);
    var tmp2_textColor = Companion_getInstance_3().d1t_1;
    tmp.g4o_1 = new CompositeColor(tmp1_foregroundColor, tmp0_backgroundColor, tmp2_textColor);
    this.h4o_1 = new BasicStyle(new CompositeColor(Companion_getInstance_3().g1t_1, Companion_getInstance_3().e1t_1, Companion_getInstance_3().g1t_1));
    this.i4o_1 = new BasicStyle(new CompositeColor(Companion_getInstance_3().l1t_1, Companion_getInstance_3().l1t_1, Companion_getInstance_3().d1t_1));
    this.j4o_1 = new BasicStyle(new CompositeColor(Companion_getInstance_3().m1t_1, Companion_getInstance_3().m1t_1, Companion_getInstance_3().m1t_1), new Stroke(0.5));
    this.k4o_1 = new BasicStyle(this.f4o_1);
    this.l4o_1 = new BasicStyle(this.g4o_1);
  }
  var Companion_instance_56;
  function Companion_getInstance_61() {
    if (Companion_instance_56 == null)
      new Companion_51();
    return Companion_instance_56;
  }
  function EditTheme(name, dark, referenceColorSequenceProvider, referenceColors, predefinedColors, background, text, figure, annotation, tooltip, shadow, hover, selection, highlight, snap, messageInfo, messageError) {
    Companion_getInstance_61();
    name = name === VOID ? 'default' : name;
    dark = dark === VOID ? false : dark;
    referenceColorSequenceProvider = referenceColorSequenceProvider === VOID ? ReferenceColorSequenceProvider_getInstance() : referenceColorSequenceProvider;
    referenceColors = referenceColors === VOID ? Companion_getInstance_7().y2s_1 : referenceColors;
    predefinedColors = predefinedColors === VOID ? Companion_getInstance_7().z2s_1 : predefinedColors;
    background = background === VOID ? Companion_getInstance_7().r2s_1 : background;
    text = text === VOID ? Companion_getInstance_7().s2s_1 : text;
    figure = figure === VOID ? Companion_getInstance_7().t2s_1 : figure;
    annotation = annotation === VOID ? Companion_getInstance_7().u2s_1 : annotation;
    tooltip = tooltip === VOID ? Companion_getInstance_7().v2s_1 : tooltip;
    shadow = shadow === VOID ? Companion_getInstance_7().w2s_1 : shadow;
    hover = hover === VOID ? Companion_getInstance_7().x2s_1 : hover;
    selection = selection === VOID ? Companion_getInstance_61().h4o_1 : selection;
    highlight = highlight === VOID ? Companion_getInstance_61().i4o_1 : highlight;
    snap = snap === VOID ? Companion_getInstance_61().j4o_1 : snap;
    messageInfo = messageInfo === VOID ? Companion_getInstance_61().l4o_1 : messageInfo;
    messageError = messageError === VOID ? Companion_getInstance_61().k4o_1 : messageError;
    DrawTheme.call(this, name, dark, referenceColorSequenceProvider, referenceColors, predefinedColors, background, text, figure, annotation, tooltip, shadow, hover);
    this.p3y_1 = selection;
    this.q3y_1 = highlight;
    this.r3y_1 = snap;
    this.s3y_1 = messageInfo;
    this.t3y_1 = messageError;
  }
  protoOf(EditTheme).f2t = function (styleRepository, styleOnly) {
    protoOf(DrawTheme).f2t.call(this, styleRepository, styleOnly);
    styleRepository.m2s(Companion_getInstance_60().f3o_1, this.p3y_1);
    styleRepository.m2s(Companion_getInstance_60().g3o_1, this.q3y_1);
    styleRepository.m2s(Companion_getInstance_60().h3o_1, this.s3y_1);
    styleRepository.m2s(Companion_getInstance_60().i3o_1, this.t3y_1);
    if (!styleOnly) {
      BaseModule_getInstance().zo_1.et('edit.select.rubberband.fill.paint', this.p3y_1.c1u().x1x_1.r2f(32));
      BaseModule_getInstance().zo_1.et('edit.select.rubberband.stroke.paint', this.p3y_1.c1u().x1x_1);
    }
  };
  function AbstractTool(editor) {
    this.z4j_1 = editor;
  }
  protoOf(AbstractTool).g4k = function (e) {
    return new EditInputEventContext(this.z4j_1, VOID, e);
  };
  protoOf(AbstractTool).f4k = function (e, x, y) {
    return new EditInputEventContext(this.z4j_1, e, VOID, x, y, !this.z4j_1.v1o().r3b());
  };
  protoOf(AbstractTool).i4k = function (component) {
    if (component == null) {
      this.z4j_1.v1o().l1y(Cursor_DEFAULT_getInstance());
    } else {
      this.z4j_1.v1o().l1y(Cursor_MOVE_getInstance());
    }
  };
  function clearPointStatus($this) {
    Status_getInstance().fu(StatusType_Small_getInstance(), null);
  }
  function ToolAdapter(editor) {
    AbstractTool.call(this, editor);
  }
  protoOf(ToolAdapter).m2v = function () {
  };
  protoOf(ToolAdapter).n2v = function () {
    clearPointStatus(this);
    Status_getInstance().fu(StatusType_Tool_getInstance(), null);
  };
  protoOf(ToolAdapter).f3f = function (e, x, y) {
  };
  protoOf(ToolAdapter).h3f = function (e, x, y) {
  };
  protoOf(ToolAdapter).j3f = function (e, x, y) {
  };
  protoOf(ToolAdapter).l3f = function (e, x, y) {
    this.j4k(x, y);
  };
  protoOf(ToolAdapter).n3f = function (e, x, y) {
  };
  protoOf(ToolAdapter).m1a = function (e) {
  };
  protoOf(ToolAdapter).n1a = function (e) {
  };
  protoOf(ToolAdapter).o1a = function (e) {
  };
  protoOf(ToolAdapter).j4k = function (x, y) {
    Status_getInstance().fu(StatusType_Small_getInstance(), '' + numberToInt(x) + ',' + numberToInt(y));
  };
  function ToolLockAction(editor) {
    AbstractAction_init_$Init$('edit.action.toolLock', '/img/lock-24.png', VOID, this);
    this.u4o_1 = editor;
    this.rq(this.u4o_1.z3c());
  }
  protoOf(ToolLockAction).execute = function (event) {
    this.u4o_1.y3c(!this.u4o_1.z3c());
  };
  function Companion_52() {
    Companion_instance_57 = this;
    this.v4o_1 = 'edit.view.AttentionDrawer.duration';
    this.w4o_1 = 'edit.view.AttentionDrawer.maxRadius';
    this.x4o_1 = new Stroke();
  }
  var Companion_instance_57;
  function Companion_getInstance_62() {
    if (Companion_instance_57 == null)
      new Companion_52();
    return Companion_instance_57;
  }
  function container($this, view) {
    return view.a3c();
  }
  function GrowingRing($outer, center, maxRadius, color) {
    this.i4p_1 = $outer;
    AbstractRectangularUnzoomable.call(this, maxRadius, center);
    this.f4p_1 = maxRadius;
    this.g4p_1 = color;
    this.h4p_1 = 0.0;
  }
  protoOf(GrowingRing).b2c = function () {
    return Companion_getInstance_62().x4o_1.f1u_1;
  };
  protoOf(GrowingRing).j4p = function (value) {
    this.h4p_1 = value;
    protoOf(AbstractRectangularUnzoomable).p2c.call(this, this.h4p_1);
    this.k20();
  };
  protoOf(GrowingRing).h20 = function (context) {
    context.j1z_1.e1u(Companion_getInstance_62().x4o_1);
    context.j1z_1.b1u(this.g4p_1);
    var rect = this.r2c();
    var tmp;
    if (this.h4p_1 < this.f4p_1 * 0.75) {
      tmp = this.h4p_1;
    } else {
      tmp = this.f4p_1 - this.h4p_1;
    }
    var thickness = tmp;
    context.j1z_1.j1v(new Ring2D(rect.u1h_1, rect.v1h_1, rect.w1h_1, rect.x1h_1, thickness));
  };
  function AttentionDrawerImpl$drawAttentionTo$lambda($ring) {
    return function (it) {
      $ring.j4p(it);
      return Unit_instance;
    };
  }
  function AttentionDrawerImpl$drawAttentionTo$1(this$0, $view, $ring) {
    this.k4p_1 = this$0;
    this.l4p_1 = $view;
    this.m4p_1 = $ring;
    AnimationTaskAdapter.call(this);
  }
  protoOf(AttentionDrawerImpl$drawAttentionTo$1).s1p = function (task, canceled) {
    container(this.k4p_1, this.l4p_1).c21(this.m4p_1);
    container(this.k4p_1, this.l4p_1).k20();
  };
  function AttentionDrawerImpl(properties, color) {
    Companion_getInstance_62();
    properties = properties === VOID ? BaseModule_getInstance().zo_1 : properties;
    color = color === VOID ? properties.nt('edit.view.AttentionDrawer.color') : color;
    this.n4p_1 = properties;
    this.o4p_1 = color;
  }
  protoOf(AttentionDrawerImpl).p4p = function (location, view, animator) {
    var maxRadius = this.n4p_1.lt('edit.view.AttentionDrawer.maxRadius');
    var ring = new GrowingRing(this, location, maxRadius, this.o4p_1);
    var animation = animator.k1q(ring, AttentionDrawerImpl$drawAttentionTo$lambda(ring), new DoubleRange(0.0, maxRadius), this.n4p_1.lt('edit.view.AttentionDrawer.duration'));
    animation.j1p(new AttentionDrawerImpl$drawAttentionTo$1(this, view, ring));
    container(this, view).b21(ring);
    animation.xp();
  };
  function Companion_53() {
    this.q4p_1 = 10.0;
    this.r4p_1 = 10.0;
    this.s4p_1 = 300;
    this.t4p_1 = 600;
  }
  var Companion_instance_58;
  function Companion_getInstance_63() {
    return Companion_instance_58;
  }
  function handle($this, msg) {
    if (!(msg.j3p_1 == null) && !$this.u4p_1.u3b().x20(msg.j3p_1)) {
      return Unit_instance;
    }
    if (msg.j3p_1 == null && !$this.v4p_1) {
      return Unit_instance;
    }
    var tmp;
    if (msg.l3p_1 == null) {
      tmp = Translations_getInstance().bn(msg.k3p_1, []);
    } else {
      tmp = Translations_getInstance().bn(msg.k3p_1, [msg.l3p_1]);
    }
    var text = tmp;
    var messageView = new FlexibleTextView(text, calculateAnchorPoint($this, msg), Direction_SOUTH_getInstance(), VOID, VOID, VOID, determineStyleType($this, msg.i3p_1));
    if (!(msg.j3p_1 == null)) {
      var makeVisibleOffset = getMakeVisibleOffset($this, messageView);
      messageView.v21(makeVisibleOffset.kn_1, makeVisibleOffset.ln_1);
    }
    var tmp_0;
    if (msg.j3p_1 == null) {
      tmp_0 = $this.u4p_1.b24();
    } else {
      var tmp_1 = $this.u4p_1.z3b();
      tmp_0 = isInterface(tmp_1, DrawableContainer) ? tmp_1 : THROW_CCE();
    }
    var container = tmp_0;
    container.b21(messageView);
    container.k20();
    Companion_getInstance_8().s2k(messageView, container, 300, DisplayDuration_instance.r1o(text), 600, $this.x4p_1);
  }
  function calculateAnchorPoint($this, msg) {
    var tmp;
    if (msg.j3p_1 == null) {
      tmp = Point2D_init_$Create$_0($this.u4p_1.f1c() / 2 | 0, $this.u4p_1.h1c() / 2 | 0);
    } else {
      var bbox = msg.j3p_1.fo();
      tmp = new Point2D(bbox.x1c(), bbox.c1d() + 10.0);
    }
    return tmp;
  }
  function getMakeVisibleOffset($this, messageView) {
    var bbox = messageView.fo();
    var locationView = $this.u4p_1.g25(messageView.v2g_1);
    var minXView = locationView.kn_1 - bbox.f1c() / 2;
    var maxXView = locationView.kn_1 + bbox.f1c() / 2;
    var minYView = locationView.ln_1;
    var maxYView = locationView.ln_1 + bbox.h1c();
    var tmp;
    if (minXView - 10.0 < 0) {
      // Inline function 'kotlin.math.abs' call
      var x = minXView - 10.0;
      tmp = Math.abs(x);
    } else if (maxXView + 10.0 > $this.u4p_1.f1c()) {
      tmp = -(maxXView + 10.0 - $this.u4p_1.f1c());
    } else {
      tmp = 0.0;
    }
    var dx = tmp;
    var tmp_0;
    if (minYView - 10.0 < 0) {
      // Inline function 'kotlin.math.abs' call
      var x_0 = minYView - 10.0;
      tmp_0 = Math.abs(x_0);
    } else if (maxYView + 10.0 > $this.u4p_1.h1c()) {
      tmp_0 = -(maxYView + 10.0 - $this.u4p_1.h1c());
    } else {
      tmp_0 = 0.0;
    }
    var dy = tmp_0;
    return new Point2D(dx / $this.u4p_1.i24(), dy / $this.u4p_1.i24());
  }
  function determineStyleType($this, msgType) {
    var tmp;
    switch (msgType.l2_1) {
      case 0:
        tmp = Companion_getInstance_60().h3o_1;
        break;
      case 1:
        tmp = Companion_getInstance_60().i3o_1;
        break;
      default:
        noWhenBranchMatchedException();
        break;
    }
    return tmp;
  }
  function ComponentMessageDisplayer$handle$ref(p0) {
    var l = function (_this__u8e3s4) {
      var tmp0 = p0;
      handle(tmp0, _this__u8e3s4);
      return Unit_instance;
    };
    l.callableName = 'handle';
    return l;
  }
  function ComponentMessageDisplayer$handle$ref_0(p0) {
    var l = function (_this__u8e3s4) {
      var tmp0 = p0;
      handle(tmp0, _this__u8e3s4);
      return Unit_instance;
    };
    l.callableName = 'handle';
    return l;
  }
  function ComponentMessageDisplayer(drawingView, displayGlobalMessages, eventBus, animator) {
    eventBus = eventBus === VOID ? BaseModule_getInstance().bp_1 : eventBus;
    animator = animator === VOID ? AnimationModule_getInstance().h1q_1 : animator;
    this.u4p_1 = drawingView;
    this.v4p_1 = displayGlobalMessages;
    this.w4p_1 = eventBus;
    this.x4p_1 = animator;
    var tmp = getKClass(ComponentMessage);
    this.w4p_1.z17(tmp, ComponentMessageDisplayer$handle$ref(this));
  }
  protoOf(ComponentMessageDisplayer).gs = function () {
    var tmp = getKClass(ComponentMessage);
    this.w4p_1.a18(tmp, ComponentMessageDisplayer$handle$ref_0(this));
  };
  function DrawingViewContentImpl$BackdropDrawer$draw$lambda(it) {
    return it.h29().g29_1;
  }
  function ComponentRemoveListener($outer) {
    this.y4p_1 = $outer;
    DrawableContainerAdapter.call(this);
  }
  protoOf(ComponentRemoveListener).z4p = function (event) {
    var tmp;
    var tmp_0 = event.x21_1;
    if (isInterface(tmp_0, Component)) {
      var tmp_1 = event.x21_1;
      tmp = this.y4p_1.g4q_1.d3e(isInterface(tmp_1, Component) ? tmp_1 : THROW_CCE());
    } else {
      tmp = false;
    }
    if (tmp) {
      var tmp_2 = event.x21_1;
      this.y4p_1.g4q_1.a3e(isInterface(tmp_2, Component) ? tmp_2 : THROW_CCE());
    }
  };
  protoOf(ComponentRemoveListener).z21 = function (event) {
    return this.z4p(event);
  };
  function BackdropDrawer($outer) {
    this.q4q_1 = $outer;
    AbstractDrawable.call(this);
  }
  protoOf(BackdropDrawer).fo = function () {
    return this.q4q_1.b4q_1.fo();
  };
  protoOf(BackdropDrawer).h20 = function (context) {
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = this.q4q_1.b4q_1.k21(DrawingViewContentImpl$BackdropDrawer$draw$lambda).i();
    while (_iterator__ex2g4s.j()) {
      var element = _iterator__ex2g4s.k();
      element.h20(context);
    }
  };
  protoOf(BackdropDrawer).go = function (x, y) {
    return this.fo().go(x, y);
  };
  function DrawingViewContentImpl(drawingView, drawing, selectionManagerFactory, highlighterFactory) {
    this.a4q_1 = drawingView;
    this.b4q_1 = drawing;
    var tmp = this;
    // Inline function 'kotlin.collections.mutableMapOf' call
    tmp.c4q_1 = LinkedHashMap_init_$Create$();
    var tmp_0 = this;
    // Inline function 'kotlin.collections.mutableMapOf' call
    tmp_0.d4q_1 = LinkedHashMap_init_$Create$();
    this.e4q_1 = new ComponentRemoveListener(this);
    var tmp0 = this.c4q_1;
    var tmp2 = SelectionDrawingStrategy_ABOVE_getInstance();
    // Inline function 'kotlin.collections.set' call
    var value = new DrawableContainerImpl();
    tmp0.y1(tmp2, value);
    var tmp0_0 = this.c4q_1;
    var tmp2_0 = SelectionDrawingStrategy_REPLACE_getInstance();
    // Inline function 'kotlin.collections.set' call
    var value_0 = new DrawableContainerImpl();
    tmp0_0.y1(tmp2_0, value_0);
    var tmp0_1 = this.c4q_1;
    var tmp2_1 = SelectionDrawingStrategy_BELOW_getInstance();
    // Inline function 'kotlin.collections.set' call
    var value_1 = new DrawableContainerImpl();
    tmp0_1.y1(tmp2_1, value_1);
    var tmp0_2 = this.d4q_1;
    var tmp2_2 = SelectionDrawingStrategy_ABOVE_getInstance();
    // Inline function 'kotlin.collections.set' call
    var value_2 = new UnzoomableContainer();
    tmp0_2.y1(tmp2_2, value_2);
    this.b4q_1.q21(this.e4q_1);
    this.f4q_1 = this.a4q_1.g24().q25();
    this.g4q_1 = selectionManagerFactory(this);
    this.h4q_1 = highlighterFactory.j3o(this);
    this.i4q_1 = new DrawableContainerImpl();
    this.j4q_1 = new UnzoomableContainer();
    this.k4q_1 = new DrawableContainerImpl();
    this.l4q_1 = new BackdropDrawer(this);
    this.m4q_1 = new DrawableContainerImpl(VOID, VOID, false);
  }
  protoOf(DrawingViewContentImpl).f3c = function () {
    return this.a4q_1;
  };
  protoOf(DrawingViewContentImpl).u3b = function () {
    return this.b4q_1;
  };
  protoOf(DrawingViewContentImpl).f24 = function (_set____db54di) {
    this.f4q_1 = _set____db54di;
  };
  protoOf(DrawingViewContentImpl).g24 = function () {
    return this.f4q_1;
  };
  protoOf(DrawingViewContentImpl).v3b = function () {
    return this.g4q_1;
  };
  protoOf(DrawingViewContentImpl).w3b = function () {
    return this.h4q_1;
  };
  protoOf(DrawingViewContentImpl).a3c = function () {
    return this.i4q_1;
  };
  protoOf(DrawingViewContentImpl).z3b = function () {
    return this.j4q_1;
  };
  protoOf(DrawingViewContentImpl).g3c = function () {
    return this.k4q_1;
  };
  protoOf(DrawingViewContentImpl).h3c = function () {
    return this.l4q_1;
  };
  protoOf(DrawingViewContentImpl).i3c = function () {
    return this.m4q_1;
  };
  protoOf(DrawingViewContentImpl).j3c = function (selectionModel, strategy) {
    if (isInterface(selectionModel, Unzoomable)) {
      var tmp0_safe_receiver = this.d4q_1.g2(strategy);
      var tmp;
      if (tmp0_safe_receiver == null) {
        tmp = null;
      } else {
        tmp = tmp0_safe_receiver.b21(isInterface(selectionModel, UnzoomableSelectionModel) ? selectionModel : THROW_CCE());
      }
      if (tmp == null)
        throw IllegalArgumentException_init_$Create$('no suitable selection container found');
    } else {
      var tmp2_safe_receiver = this.c4q_1.g2(strategy);
      if ((tmp2_safe_receiver == null ? null : tmp2_safe_receiver.b21(selectionModel)) == null)
        throw IllegalArgumentException_init_$Create$('no suitable selection container found');
    }
  };
  protoOf(DrawingViewContentImpl).k3c = function (selectionModel) {
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = this.c4q_1.c2().i();
    while (_iterator__ex2g4s.j()) {
      var element = _iterator__ex2g4s.k();
      element.c21(selectionModel);
    }
    if (isInterface(selectionModel, UnzoomableSelectionModel)) {
      // Inline function 'kotlin.collections.forEach' call
      var _iterator__ex2g4s_0 = this.d4q_1.c2().i();
      while (_iterator__ex2g4s_0.j()) {
        var element_0 = _iterator__ex2g4s_0.k();
        element_0.c21(selectionModel);
      }
    }
  };
  protoOf(DrawingViewContentImpl).l3c = function () {
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = this.c4q_1.c2().i();
    while (_iterator__ex2g4s.j()) {
      var element = _iterator__ex2g4s.k();
      element.z20();
    }
  };
  protoOf(DrawingViewContentImpl).m3c = function (component) {
    var tmp0 = ensureNotNull(this.c4q_1.g2(SelectionDrawingStrategy_REPLACE_getInstance())).u20();
    var tmp$ret$0;
    $l$block: {
      // Inline function 'kotlin.collections.firstOrNull' call
      var _iterator__ex2g4s = tmp0.i();
      while (_iterator__ex2g4s.j()) {
        var element = _iterator__ex2g4s.k();
        if (element.t3s() === component.d3b()) {
          tmp$ret$0 = element;
          break $l$block;
        }
      }
      tmp$ret$0 = null;
    }
    return tmp$ret$0;
  };
  protoOf(DrawingViewContentImpl).n3c = function (strategy) {
    return this.c4q_1.g2(strategy);
  };
  protoOf(DrawingViewContentImpl).o3c = function (strategy) {
    return this.d4q_1.g2(strategy);
  };
  function _get_LOG__e5r759_13($this) {
    var tmp0 = $this.r4q_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('LOG', 1, tmp, DrawingViewImpl$Companion$_get_LOG_$ref_uhrqmb(), null);
    return tmp0.j2();
  }
  function DrawingViewImpl$Companion$_get_LOG_$ref_uhrqmb() {
    return function (p0) {
      return _get_LOG__e5r759_13(p0);
    };
  }
  function Companion_54() {
    Companion_instance_59 = this;
    this.r4q_1 = logger(getKClass(DrawingViewImpl));
  }
  var Companion_instance_59;
  function Companion_getInstance_64() {
    if (Companion_instance_59 == null)
      new Companion_54();
    return Companion_instance_59;
  }
  function setupContent($this) {
    protoOf(ViewImpl).q30.call($this, $this.z3b());
    protoOf(ViewImpl).q30.call($this, $this.a3c());
    protoOf(ViewImpl).q30.call($this, ensureNotNull($this.z4r_1.n3c(SelectionDrawingStrategy_ABOVE_getInstance())));
    protoOf(ViewImpl).q30.call($this, ensureNotNull($this.z4r_1.o3c(SelectionDrawingStrategy_ABOVE_getInstance())));
    protoOf(ViewImpl).q30.call($this, ensureNotNull($this.z4r_1.n3c(SelectionDrawingStrategy_REPLACE_getInstance())));
    protoOf(ViewImpl).q30.call($this, $this.u3b());
    protoOf(ViewImpl).q30.call($this, ensureNotNull($this.z4r_1.n3c(SelectionDrawingStrategy_BELOW_getInstance())));
    protoOf(ViewImpl).q30.call($this, $this.g3c());
    protoOf(ViewImpl).q30.call($this, $this.z4r_1.h3c());
    protoOf(ViewImpl).q30.call($this, $this.z4r_1.i3c());
  }
  function replaceContent($this, newContent) {
    $this.z24($this.z4r_1.z3b(), newContent.z3b());
    $this.z24($this.z4r_1.a3c(), newContent.a3c());
    $this.z24(ensureNotNull($this.z4r_1.n3c(SelectionDrawingStrategy_ABOVE_getInstance())), ensureNotNull(newContent.n3c(SelectionDrawingStrategy_ABOVE_getInstance())));
    $this.z24(ensureNotNull($this.z4r_1.o3c(SelectionDrawingStrategy_ABOVE_getInstance())), ensureNotNull(newContent.o3c(SelectionDrawingStrategy_ABOVE_getInstance())));
    $this.z24(ensureNotNull($this.z4r_1.n3c(SelectionDrawingStrategy_REPLACE_getInstance())), ensureNotNull(newContent.n3c(SelectionDrawingStrategy_REPLACE_getInstance())));
    $this.z24($this.z4r_1.u3b(), newContent.u3b());
    $this.z24(ensureNotNull($this.z4r_1.n3c(SelectionDrawingStrategy_BELOW_getInstance())), ensureNotNull(newContent.n3c(SelectionDrawingStrategy_BELOW_getInstance())));
    $this.z24($this.z4r_1.g3c(), newContent.g3c());
    $this.z24($this.z4r_1.h3c(), newContent.h3c());
    $this.z24($this.z4r_1.i3c(), newContent.i3c());
    $this.f24(newContent.g24());
    $this.t1x();
  }
  function showGridIfNeeded($this) {
    var gridNeeded = $this.b4s_1 && $this.a4s_1;
    if (gridNeeded) {
      if (!$this.y24($this.c4s_1)) {
        protoOf(ViewImpl).q30.call($this, $this.c4s_1);
      }
    } else {
      protoOf(ViewImpl).r30.call($this, $this.c4s_1);
    }
    $this.t1x();
  }
  function DrawingViewDrawer($outer) {
    this.g4s_1 = $outer;
    DrawableContainerDrawer.call(this);
  }
  protoOf(DrawingViewDrawer).h4s = function (context, drawable) {
    if (this.g4s_1.v3b().d3e(drawable)) {
      var replacingSelectionModel = this.g4s_1.z4r_1.m3c(drawable);
      if (replacingSelectionModel == null) {
        this.a29(drawable, context);
      }
    } else {
      this.a29(drawable, context);
    }
    this.c29(context, drawable);
  };
  protoOf(DrawingViewDrawer).z28 = function (context, drawable) {
    return this.h4s(context, isInterface(drawable, Component) ? drawable : THROW_CCE());
  };
  function DrawingViewImpl$_init_$lambda_5y0iw() {
    return System_getInstance().bm();
  }
  function DrawingViewImpl$_init_$lambda_5y0iw_0(it) {
    return new InvalidatableViewPainter(it);
  }
  function DrawingViewImpl$preferenceChangeHandler$lambda(this$0) {
    return function (it) {
      this$0.y2z();
      this$0.t1x();
      return Unit_instance;
    };
  }
  function DrawingViewImpl$commandEventHandler$lambda(this$0) {
    return function (it) {
      this$0.y2z();
      this$0.t1x();
      return Unit_instance;
    };
  }
  function DrawingViewImpl$createViewContentBounds$lambda(this$0) {
    return function () {
      this$0.e4s_1.m1c(this$0.u3b().fo());
      var tmp;
      if (this$0.i3c().d20()) {
        this$0.e4s_1.n1c(this$0.i3c().fo());
        tmp = Unit_instance;
      }
      return this$0.e4s_1;
    };
  }
  function DrawingViewImpl(drawing, transformFactory, applicationContextHolder, displayGlobalMessages, selectionManagerFactory, highlighterFactory, eventBus, viewPainterFactory, editable, name) {
    Companion_getInstance_64();
    var tmp;
    if (transformFactory === VOID) {
      tmp = DrawingViewImpl$_init_$lambda_5y0iw;
    } else {
      tmp = transformFactory;
    }
    transformFactory = tmp;
    applicationContextHolder = applicationContextHolder === VOID ? null : applicationContextHolder;
    displayGlobalMessages = displayGlobalMessages === VOID ? false : displayGlobalMessages;
    selectionManagerFactory = selectionManagerFactory === VOID ? EditSelectModule_getInstance().v3l_1 : selectionManagerFactory;
    highlighterFactory = highlighterFactory === VOID ? EditHighlightModule_getInstance().z3n_1 : highlighterFactory;
    eventBus = eventBus === VOID ? BaseModule_getInstance().bp_1 : eventBus;
    var tmp_0;
    if (viewPainterFactory === VOID) {
      tmp_0 = DrawingViewImpl$_init_$lambda_5y0iw_0;
    } else {
      tmp_0 = viewPainterFactory;
    }
    viewPainterFactory = tmp_0;
    editable = editable === VOID ? true : editable;
    name = name === VOID ? '' : name;
    ViewImpl.call(this, transformFactory, applicationContextHolder, eventBus, name, viewPainterFactory);
    this.t4r_1 = selectionManagerFactory;
    this.u4r_1 = highlighterFactory;
    this.v4r_1 = new DrawingViewDrawer(this);
    this.w4r_1 = new ComponentMessageDisplayer(this, displayGlobalMessages, eventBus);
    var tmp_1 = this;
    tmp_1.x4r_1 = DrawingViewImpl$preferenceChangeHandler$lambda(this);
    var tmp_2 = this;
    tmp_2.y4r_1 = DrawingViewImpl$commandEventHandler$lambda(this);
    this.z4r_1 = this.d3c(drawing);
    this.a4s_1 = editable;
    this.b4s_1 = false;
    this.c4s_1 = new GridImpl();
    this.d4s_1 = SelectionDrawingStrategy_REPLACE_getInstance();
    eventBus.z17(getKClass(PreferencesChangedEvent), this.x4r_1);
    eventBus.z17(getKClass(CommandEvent), this.y4r_1);
    this.e4s_1 = new Rectangle2D();
  }
  protoOf(DrawingViewImpl).g1y = function (value) {
    var firstTime = this.y2y_1 == null;
    protoOf(ViewImpl).g1y.call(this, value);
    if (firstTime) {
      setupContent(this);
      this.c4s_1.j4n(this);
      this.x3b(true);
    }
  };
  protoOf(DrawingViewImpl).s23 = function () {
    return protoOf(ViewImpl).s23.call(this);
  };
  protoOf(DrawingViewImpl).s3b = function (value) {
    if (this.z4r_1 === value) {
      return Unit_instance;
    }
    var oldDrawing = this.z4r_1.u3b();
    replaceContent(this, value);
    this.z4r_1 = value;
    this.z4r_1.u3b().p21(this.v4r_1);
    this.f30('PROP_DRAWING', oldDrawing, this.z4r_1.u3b());
    this.z4r_1.u3b().i3b(this.a4s_1);
    this.z4r_1.v3b().m2v();
  };
  protoOf(DrawingViewImpl).t3b = function () {
    return this.z4r_1;
  };
  protoOf(DrawingViewImpl).q3b = function (value) {
    if (!(value === this.a4s_1)) {
      _get_LOG__e5r759_13(Companion_getInstance_64()).pl("Setting DrawingView with '" + toString(this.u3b()) + "' to editable=" + value);
      this.a4s_1 = value;
      showGridIfNeeded(this);
      this.f30('PROP_EDITABLE', !this.a4s_1, this.a4s_1);
      this.z4r_1.u3b().i3b(this.a4s_1);
    }
  };
  protoOf(DrawingViewImpl).r3b = function () {
    return this.a4s_1;
  };
  protoOf(DrawingViewImpl).v3b = function () {
    return this.z4r_1.v3b();
  };
  protoOf(DrawingViewImpl).w3b = function () {
    return this.z4r_1.w3b();
  };
  protoOf(DrawingViewImpl).z3b = function () {
    return this.z4r_1.z3b();
  };
  protoOf(DrawingViewImpl).a3c = function () {
    return this.z4r_1.a3c();
  };
  protoOf(DrawingViewImpl).g3c = function () {
    return this.z4r_1.g3c();
  };
  protoOf(DrawingViewImpl).i3c = function () {
    return this.z4r_1.i3c();
  };
  protoOf(DrawingViewImpl).u3b = function () {
    return this.z4r_1.u3b();
  };
  protoOf(DrawingViewImpl).x3b = function (value) {
    if (!(value === this.b4s_1)) {
      this.b4s_1 = value;
      showGridIfNeeded(this);
      this.t1x();
      this.f30('PROP_SHOW_GRID', !this.b4s_1, this.b4s_1);
    }
  };
  protoOf(DrawingViewImpl).y3b = function () {
    return this.c4s_1;
  };
  protoOf(DrawingViewImpl).gs = function () {
    protoOf(ViewImpl).gs.call(this);
    this.p2y_1.a18(getKClass(PreferencesChangedEvent), this.x4r_1);
    this.p2y_1.a18(getKClass(CommandEvent), this.y4r_1);
    this.w4r_1.gs();
    this.c4s_1.gs();
  };
  protoOf(DrawingViewImpl).b3c = function (drawing, applyDefaultZoomStrategy) {
    if (!(drawing === this.z4r_1.u3b())) {
      this.s3b(this.d3c(drawing));
      if (applyDefaultZoomStrategy) {
        this.v24();
      }
    }
  };
  protoOf(DrawingViewImpl).d3c = function (drawing) {
    return new DrawingViewContentImpl(this, drawing, this.t4r_1, this.u4r_1);
  };
  protoOf(DrawingViewImpl).i4s = function (drawableDrawer) {
    drawableDrawer.i29(this.v4r_1);
    this.v4r_1 = drawableDrawer;
    this.u3b().p21(this.v4r_1);
  };
  protoOf(DrawingViewImpl).e3c = function (component) {
    var tmp0_elvis_lhs = component.f3b();
    return tmp0_elvis_lhs == null ? this.d4s_1 : tmp0_elvis_lhs;
  };
  protoOf(DrawingViewImpl).c30 = function () {
    return new ViewContentBounds(VOID, DrawingViewImpl$createViewContentBounds$lambda(this));
  };
  protoOf(DrawingViewImpl).r30 = function (drawable) {
    throw UnsupportedOperationException_init_$Create$('Clients cannot remove Drawable from DrawingViewImpl');
  };
  protoOf(DrawingViewImpl).q30 = function (drawable) {
    throw UnsupportedOperationException_init_$Create$('Clients cannot add Drawable to DrawingViewImpl');
  };
  //region block: post-declaration
  protoOf(AbstractCommand).h3a = getDetailedDescription;
  protoOf(AbstractCommand).k3a = notifyUndo;
  protoOf(DrawingAppServiceImpl).s3f = move$default;
  protoOf($serializer).al = typeParametersSerializers;
  protoOf(SourcingCommandManager).r3a = beginTransaction$default;
  protoOf(TransactionCommand).l3a = get_canUndo;
  protoOf(AddCommand).l3a = get_canUndo;
  protoOf(EditorImpl).u3b = get_drawing;
  protoOf(AbstractComponent).g3b = get_isDragManager;
  protoOf(AbstractComponent).h3b = collectSelectBuddies;
  protoOf(AbstractComponent).i3b = notifyEditable;
  protoOf(AbstractComponent).j2i = prepareMoveBy;
  protoOf(AbstractComponent).k2i = completeMoveBy;
  protoOf(AbstractComponent).l3b = getSnapHighlightX;
  protoOf(AbstractComponent).m3b = getSnapHighlightY;
  protoOf(AbstractComponent).d38 = get_isReferencable;
  protoOf(AbstractComponent).g38 = get_isNotReading;
  protoOf(AbstractComponent).b38 = resolutionDone;
  protoOf(AbstractComponent).c38 = allResolutionDone;
  protoOf(AbstractComponent).j38 = readFromStore;
  protoOf(AbstractComponent).g22 = get_isFocusOwner;
  protoOf(AbstractComponent).i22 = requestFocus;
  protoOf(AbstractPathFigure).e2i = get_canMirror;
  protoOf(ComponentContainerImpl).d38 = get_isReferencable;
  protoOf(ComponentContainerImpl).g38 = get_isNotReading;
  protoOf(ComponentContainerImpl).b38 = resolutionDone;
  protoOf(ComponentContainerImpl).j38 = readFromStore;
  protoOf(DrawingImpl).i3b = notifyEditable_0;
  protoOf(AbstractCurveComponent).l2h = applyTo;
  protoOf(AbstractCurveComponent).e2i = get_canMirror;
  protoOf(MoveCurvePointCommand).l3a = get_canUndo;
  protoOf(AbstractRectangularComponent).e2i = get_canMirror;
  protoOf(RectangularComponent).l2h = applyTo;
  protoOf(AddPolylinePointCommand).l3a = get_canUndo;
  protoOf(JoinPolylinePointsCommand).l3a = get_canUndo;
  protoOf(MovePolylinePointCommand).l3a = get_canUndo;
  protoOf(PolylineComponent).h2r = findSegment$default;
  protoOf(PolylineComponent).l2h = applyTo;
  protoOf(PolylineComponent).e2i = get_canMirror;
  protoOf(ResizeRectangleCommand).l3a = get_canUndo;
  protoOf(AbstractTextComponent).l2h = applyTo;
  protoOf(Label).e2i = get_canMirror;
  protoOf(Label).v21 = moveBy;
  protoOf(LabelComponent).l2h = applyTo;
  protoOf(TranslatableText).y45 = get_isNotEmpty;
  protoOf(TranslatableText).m45 = getTranslation;
  protoOf(TranslatableText).n4e = withTranslation;
  protoOf(TranslatableText).p4e = getOptionalTranslation;
  protoOf(Translation).g38 = get_isNotReading;
  protoOf(Translation).b38 = resolutionDone;
  protoOf(Translation).c38 = allResolutionDone;
  protoOf(Translation).j38 = readFromStore;
  protoOf(Description).y45 = get_isNotEmpty;
  protoOf(Description).m45 = getTranslation;
  protoOf(Name).y45 = get_isNotEmpty;
  protoOf(Name).m45 = getTranslation;
  protoOf(RectangularHandle).y43 = setLocation;
  protoOf(RectangularRubberBand).qo = contains_2;
  protoOf(SelectionManagerImpl).w3d = get_selectionCount;
  protoOf(AbstractTool).g3f = mouseClicked;
  protoOf(AbstractTool).i3f = mousePressed;
  protoOf(AbstractTool).k3f = mouseReleased;
  protoOf(AbstractTool).m3f = mouseMoved;
  protoOf(AbstractTool).o3f = mouseDragged;
  protoOf(AbstractSnapper).d3f = getSnapHighlightX_0;
  protoOf(AbstractSnapper).e3f = getSnapHighlightY_0;
  protoOf(MultiComponentSnappable).l3b = getSnapHighlightX;
  protoOf(MultiComponentSnappable).m3b = getSnapHighlightY;
  defineProp(protoOf(ToolLockAction), 'requestFocusOnClick', function () {
    return this.wq();
  });
  protoOf(DrawingViewImpl).c3c = setDrawing$default;
  //endregion
  //region block: init
  DragDestinationHighlighter_instance = new DragDestinationHighlighter();
  Companion_instance_13 = new Companion_8();
  Companion_instance_14 = new Companion_9();
  Companion_instance_19 = new Companion_14();
  Companion_instance_20 = new Companion_15();
  Companion_instance_21 = new Companion_16();
  Companion_instance_24 = new Companion_19();
  Companion_instance_26 = new Companion_21();
  Companion_instance_32 = new Companion_27();
  Companion_instance_33 = new Companion_28();
  Companion_instance_34 = new Companion_29();
  Companion_instance_37 = new Companion_32();
  Companion_instance_38 = new Companion_33();
  Companion_instance_39 = new Companion_34();
  Companion_instance_40 = new Companion_35();
  Companion_instance_41 = new Companion_36();
  Companion_instance_42 = new Companion_37();
  Companion_instance_43 = new Companion_38();
  Companion_instance_44 = new Companion_39();
  Companion_instance_45 = new Companion_40();
  Companion_instance_46 = new Companion_41();
  Companion_instance_53 = new Companion_48();
  Companion_instance_58 = new Companion_53();
  //endregion
  //region block: exports
  function $jsExportAll$(_) {
    var io = _.io || (_.io = {});
    var antarescircuit = io.antarescircuit || (io.antarescircuit = {});
    var jabbah = antarescircuit.jabbah || (antarescircuit.jabbah = {});
    var edit = jabbah.edit || (jabbah.edit = {});
    var auth = edit.auth || (edit.auth = {});
    auth.UserIdentity = UserIdentity;
    defineProp(auth.UserIdentity, 'Companion', Companion_getInstance_12, VOID, true);
  }
  $jsExportAll$(_);
  _.$jsExportAll$ = $jsExportAll$;
  _.$_$ = _.$_$ || {};
  _.$_$.a = Authorizer_getInstance;
  _.$_$.b = EditAuthModule_getInstance;
  _.$_$.c = Companion_getInstance_12;
  _.$_$.d = DragDestinationHighlighter_instance;
  _.$_$.e = EditDragModule_getInstance;
  _.$_$.f = EditEditorModule_getInstance;
  _.$_$.g = FigureRegistry_getInstance;
  _.$_$.h = EditHighlightModule_getInstance;
  _.$_$.i = Companion_instance_24;
  _.$_$.j = Companion_instance_39;
  _.$_$.k = Companion_instance_40;
  _.$_$.l = Companion_instance_34;
  _.$_$.m = Companion_instance_38;
  _.$_$.n = Companion_instance_13;
  _.$_$.o = EditModuleJs_getInstance;
  _.$_$.p = EditModule_getInstance;
  _.$_$.q = Companion_instance_42;
  _.$_$.r = EditSelectModule_getInstance;
  _.$_$.s = SemanticRegistry_getInstance;
  _.$_$.t = Companion_getInstance_60;
  _.$_$.u = Companion_getInstance_61;
  _.$_$.v = Look_getInstance;
  _.$_$.w = Companion_getInstance_9;
  _.$_$.x = Operation_Change_getInstance;
  _.$_$.y = Operation_View_getInstance;
  _.$_$.z = DrawStrategy_COMPONENT_getInstance;
  _.$_$.a1 = HorizontalAlignment_CENTER_getInstance;
  _.$_$.b1 = HorizontalAlignment_LEFT_getInstance;
  _.$_$.c1 = HorizontalAlignment_RIGHT_getInstance;
  _.$_$.d1 = RotationDisplayStrategy_KEEP_HORIZONTAL_getInstance;
  _.$_$.e1 = RotationDisplayStrategy_ROTATE_HALF_getInstance;
  _.$_$.f1 = VerticalAlignment_BOTTOM_getInstance;
  _.$_$.g1 = VerticalAlignment_CENTER_getInstance;
  _.$_$.h1 = VerticalAlignment_TOP_getInstance;
  _.$_$.i1 = ComponentMessageType_Error_getInstance;
  _.$_$.j1 = ComponentMessageType_Info_getInstance;
  _.$_$.k1 = Size_LARGE_getInstance;
  _.$_$.l1 = Size_MEDIUM_getInstance;
  _.$_$.m1 = Size_SMALL_getInstance;
  _.$_$.n1 = Magnitude_Giga_getInstance;
  _.$_$.o1 = Magnitude_Kilo_getInstance;
  _.$_$.p1 = Magnitude_Mega_getInstance;
  _.$_$.q1 = Magnitude_Micro_getInstance;
  _.$_$.r1 = Magnitude_Milli_getInstance;
  _.$_$.s1 = Magnitude_Nano_getInstance;
  _.$_$.t1 = Magnitude_One_getInstance;
  _.$_$.u1 = SIUnit_Ampere_getInstance;
  _.$_$.v1 = SIUnit_Factor_getInstance;
  _.$_$.w1 = SIUnit_Farad_getInstance;
  _.$_$.x1 = SIUnit_Henry_getInstance;
  _.$_$.y1 = SIUnit_Hertz_getInstance;
  _.$_$.z1 = SIUnit_Ohm_getInstance;
  _.$_$.a2 = SIUnit_Second_getInstance;
  _.$_$.b2 = SIUnit_Volt_getInstance;
  _.$_$.c2 = SelectionDrawingStrategy_ABOVE_getInstance;
  _.$_$.d2 = SelectionDrawingStrategy_BELOW_getInstance;
  _.$_$.e2 = SelectionDrawingStrategy_REPLACE_getInstance;
  _.$_$.f2 = AddCommand_init_$Create$;
  _.$_$.g2 = EditorImpl_init_$Init$;
  _.$_$.h2 = CompactablePolyline_init_$Create$;
  _.$_$.i2 = RectangleComponent_init_$Create$;
  _.$_$.j2 = Description_init_$Create$;
  _.$_$.k2 = Name_init_$Create$;
  _.$_$.l2 = TranslatableText_init_$Create$_0;
  _.$_$.m2 = TranslatableText_init_$Create$;
  _.$_$.n2 = AbstractComponent_init_$Init$;
  _.$_$.o2 = MagnitudeValue_init_$Create$;
  _.$_$.p2 = DeleteQuestion;
  _.$_$.q2 = DrawingAppServiceImpl;
  _.$_$.r2 = DrawingAppService;
  _.$_$.s2 = DesktopUserHolder;
  _.$_$.t2 = DesktopUser;
  _.$_$.u2 = UserIdentity;
  _.$_$.v2 = AbstractCommand;
  _.$_$.w2 = AbstractDrawingViewCommand;
  _.$_$.x2 = DragDestinationHighlightFactory;
  _.$_$.y2 = DragDestination;
  _.$_$.z2 = DragManagerImpl;
  _.$_$.a3 = EditorImpl;
  _.$_$.b3 = AbstractPathFigure;
  _.$_$.c3 = FigureFactory;
  _.$_$.d3 = FigureProvider;
  _.$_$.e3 = DrawingViewSearch;
  _.$_$.f3 = ImageComponent;
  _.$_$.g3 = ImageData;
  _.$_$.h3 = ImageIdentification;
  _.$_$.i3 = CompactablePolyline;
  _.$_$.j3 = PolylineComponent;
  _.$_$.k3 = AbstractRectangularComponent;
  _.$_$.l3 = RectangularBelowSelectionModel;
  _.$_$.m3 = RectangularComponent;
  _.$_$.n3 = RectangularHandleSelectionModel;
  _.$_$.o3 = RectangularReplaceSelectionModel;
  _.$_$.p3 = Describable;
  _.$_$.q3 = Description;
  _.$_$.r3 = Namable;
  _.$_$.s3 = NameChangedEvent;
  _.$_$.t3 = Name;
  _.$_$.u3 = observableDescription;
  _.$_$.v3 = observableName;
  _.$_$.w3 = Alignment;
  _.$_$.x3 = HorizontalLabel;
  _.$_$.y3 = LabelComponent;
  _.$_$.z3 = Labeled;
  _.$_$.a4 = Label;
  _.$_$.b4 = ScriptProperty;
  _.$_$.c4 = SimpleTextComponent;
  _.$_$.d4 = TextDrawableButtonRenderer;
  _.$_$.e4 = TranslatableText;
  _.$_$.f4 = Translatable;
  _.$_$.g4 = Translation;
  _.$_$.h4 = AbstractComponent;
  _.$_$.i4 = ComponentMessage;
  _.$_$.j4 = DrawingImpl;
  _.$_$.k4 = DrawingServiceImpl;
  _.$_$.l4 = MagnitudeValue;
  _.$_$.m4 = PropertyValueException;
  _.$_$.n4 = AbstractBelowSelectionModel;
  _.$_$.o4 = AbstractSelectionModel;
  _.$_$.p4 = BoundingBoxBelowSelectionModel;
  _.$_$.q4 = SelectedColorSelectionModel;
  _.$_$.r4 = get_selectedColorSelectionModelFactory;
  _.$_$.s4 = EditStyleType;
  _.$_$.t4 = EditTheme;
  _.$_$.u4 = AttentionDrawerImpl;
  _.$_$.v4 = DrawingViewImpl;
  _.$_$.w4 = ComponentContainer;
  _.$_$.x4 = Component;
  _.$_$.y4 = DrawingViewContent;
  _.$_$.z4 = DrawingView;
  _.$_$.a5 = Drawing;
  _.$_$.b5 = EditInputEventContext;
  _.$_$.c5 = SnapResult;
  _.$_$.d5 = getSnapHighlightX;
  _.$_$.e5 = getSnapHighlightY;
  _.$_$.f5 = SnappableXCoordinate;
  _.$_$.g5 = SnappableYCoordinate;
  _.$_$.h5 = Snappable;
  _.$_$.i5 = get_canUndo;
  _.$_$.j5 = Undoable;
  //endregion
  return _;
}));

//# sourceMappingURL=jabbah-edit.js.map
