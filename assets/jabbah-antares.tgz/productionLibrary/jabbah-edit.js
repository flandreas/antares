(function (factory) {
  if (typeof define === 'function' && define.amd)
    define(['exports', './kotlin-kotlin-stdlib.js', './jabbah-base.js', './jabbah-io.js', './jabbah-draw.js', './kotlinx-serialization-kotlinx-serialization-core-js-ir.js', './jabbah-animation.js'], factory);
  else if (typeof exports === 'object')
    factory(module.exports, require('./kotlin-kotlin-stdlib.js'), require('./jabbah-base.js'), require('./jabbah-io.js'), require('./jabbah-draw.js'), require('./kotlinx-serialization-kotlinx-serialization-core-js-ir.js'), require('./jabbah-animation.js'));
  else {
    if (typeof globalThis['kotlin-kotlin-stdlib'] === 'undefined') {
      throw new Error("Error loading module 'jabbah-edit'. Its dependency 'kotlin-kotlin-stdlib' was not found. Please, check whether 'kotlin-kotlin-stdlib' is loaded prior to 'jabbah-edit'.");
    }
    if (typeof globalThis['jabbah-base'] === 'undefined') {
      throw new Error("Error loading module 'jabbah-edit'. Its dependency 'jabbah-base' was not found. Please, check whether 'jabbah-base' is loaded prior to 'jabbah-edit'.");
    }
    if (typeof globalThis['jabbah-io'] === 'undefined') {
      throw new Error("Error loading module 'jabbah-edit'. Its dependency 'jabbah-io' was not found. Please, check whether 'jabbah-io' is loaded prior to 'jabbah-edit'.");
    }
    if (typeof globalThis['jabbah-draw'] === 'undefined') {
      throw new Error("Error loading module 'jabbah-edit'. Its dependency 'jabbah-draw' was not found. Please, check whether 'jabbah-draw' is loaded prior to 'jabbah-edit'.");
    }
    if (typeof globalThis['kotlinx-serialization-kotlinx-serialization-core-js-ir'] === 'undefined') {
      throw new Error("Error loading module 'jabbah-edit'. Its dependency 'kotlinx-serialization-kotlinx-serialization-core-js-ir' was not found. Please, check whether 'kotlinx-serialization-kotlinx-serialization-core-js-ir' is loaded prior to 'jabbah-edit'.");
    }
    if (typeof globalThis['jabbah-animation'] === 'undefined') {
      throw new Error("Error loading module 'jabbah-edit'. Its dependency 'jabbah-animation' was not found. Please, check whether 'jabbah-animation' is loaded prior to 'jabbah-edit'.");
    }
    globalThis['jabbah-edit'] = factory(typeof globalThis['jabbah-edit'] === 'undefined' ? {} : globalThis['jabbah-edit'], globalThis['kotlin-kotlin-stdlib'], globalThis['jabbah-base'], globalThis['jabbah-io'], globalThis['jabbah-draw'], globalThis['kotlinx-serialization-kotlinx-serialization-core-js-ir'], globalThis['jabbah-animation']);
  }
}(function (_, kotlin_kotlin, kotlin_jabbah_base, kotlin_jabbah_io, kotlin_jabbah_draw, kotlin_org_jetbrains_kotlinx_kotlinx_serialization_core, kotlin_jabbah_animation) {
  'use strict';
  //region block: imports
  var imul = Math.imul;
  var log10 = Math.log10;
  var protoOf = kotlin_kotlin.$_$.t7;
  var initMetadataForClass = kotlin_kotlin.$_$.d7;
  var AbstractModule = kotlin_jabbah_base.$_$.d7;
  var IOModuleJs_getInstance = kotlin_jabbah_io.$_$.a;
  var DrawModuleJs_getInstance = kotlin_jabbah_draw.$_$.c1;
  var initMetadataForObject = kotlin_kotlin.$_$.i7;
  var VOID = kotlin_kotlin.$_$.b;
  var initMetadataForInterface = kotlin_kotlin.$_$.g7;
  var Unit_instance = kotlin_kotlin.$_$.i;
  var toString = kotlin_kotlin.$_$.v7;
  var hashCode = kotlin_kotlin.$_$.c7;
  var equals = kotlin_kotlin.$_$.u6;
  var Enum = kotlin_kotlin.$_$.va;
  var Movable = kotlin_jabbah_draw.$_$.s3;
  var Locatable = kotlin_jabbah_draw.$_$.n3;
  var Storable = kotlin_jabbah_io.$_$.o;
  var Stylable = kotlin_jabbah_draw.$_$.i5;
  var Focusable = kotlin_jabbah_draw.$_$.d6;
  var DrawableContainer = kotlin_jabbah_draw.$_$.w5;
  var View = kotlin_jabbah_draw.$_$.k6;
  var InputEventContext = kotlin_jabbah_draw.$_$.e6;
  var LinkedHashMap_init_$Create$ = kotlin_kotlin.$_$.q;
  var ensureNotNull = kotlin_kotlin.$_$.kb;
  var BaseModule_getInstance = kotlin_jabbah_base.$_$.n;
  var LogicalFontFamily_DIALOG_getInstance = kotlin_jabbah_draw.$_$.w1;
  var FontStyle_PLAIN_getInstance = kotlin_jabbah_draw.$_$.p1;
  var FontImpl = kotlin_jabbah_draw.$_$.s4;
  var LogicalFontFamily_SANS_SERIF_getInstance = kotlin_jabbah_draw.$_$.y1;
  var numberToInt = kotlin_kotlin.$_$.r7;
  var LogicalFontFamily_MONOSPACED_getInstance = kotlin_jabbah_draw.$_$.x1;
  var PreferencesChangedEvent = kotlin_jabbah_base.$_$.k7;
  var getKClass = kotlin_kotlin.$_$.q8;
  var Themes_getInstance = kotlin_jabbah_draw.$_$.w;
  var objectCreate = kotlin_kotlin.$_$.s7;
  var initMetadataForCompanion = kotlin_kotlin.$_$.e7;
  var getNumberHashCode = kotlin_kotlin.$_$.y6;
  var emptyList = kotlin_kotlin.$_$.c3;
  var logger = kotlin_jabbah_base.$_$.q7;
  var collectionSizeOrDefault = kotlin_kotlin.$_$.s2;
  var ArrayList_init_$Create$ = kotlin_kotlin.$_$.m;
  var toList = kotlin_kotlin.$_$.s4;
  var throwUninitializedPropertyAccessException = kotlin_kotlin.$_$.t5;
  var ArrayList_init_$Create$_0 = kotlin_kotlin.$_$.n;
  var getStringHashCode = kotlin_kotlin.$_$.b7;
  var getBooleanHashCode = kotlin_kotlin.$_$.x6;
  var System_getInstance = kotlin_jabbah_base.$_$.c1;
  var PluginGeneratedSerialDescriptor = kotlin_org_jetbrains_kotlinx_kotlinx_serialization_core.$_$.e;
  var StringSerializer_getInstance = kotlin_org_jetbrains_kotlinx_kotlinx_serialization_core.$_$.a;
  var typeParametersSerializers = kotlin_org_jetbrains_kotlinx_kotlinx_serialization_core.$_$.c;
  var GeneratedSerializer = kotlin_org_jetbrains_kotlinx_kotlinx_serialization_core.$_$.d;
  var defineProp = kotlin_kotlin.$_$.t6;
  var KProperty1 = kotlin_kotlin.$_$.t8;
  var getPropertyCallableRef = kotlin_kotlin.$_$.a7;
  var LinkedHashSet_init_$Create$ = kotlin_kotlin.$_$.r;
  var Translations_getInstance = kotlin_jabbah_base.$_$.d1;
  var lazy = kotlin_kotlin.$_$.ob;
  var addAll = kotlin_kotlin.$_$.m2;
  var StorableCloner_getInstance = kotlin_jabbah_io.$_$.c;
  var Stack = kotlin_jabbah_base.$_$.e4;
  var Disposable = kotlin_jabbah_base.$_$.f7;
  var isInterface = kotlin_kotlin.$_$.m7;
  var AbstractIterator = kotlin_kotlin.$_$.e2;
  var copyToArray = kotlin_kotlin.$_$.a3;
  var IllegalStateException_init_$Create$ = kotlin_kotlin.$_$.d1;
  var first = kotlin_kotlin.$_$.h3;
  var Collection = kotlin_kotlin.$_$.g2;
  var reversed = kotlin_kotlin.$_$.h4;
  var THROW_CCE = kotlin_kotlin.$_$.db;
  var _Char___init__impl__6a9atx = kotlin_kotlin.$_$.n1;
  var StringBuilder_init_$Create$ = kotlin_kotlin.$_$.v;
  var emptySet = kotlin_kotlin.$_$.e3;
  var Point2D = kotlin_jabbah_base.$_$.e6;
  var Companion_getInstance = kotlin_jabbah_base.$_$.h;
  var first_0 = kotlin_kotlin.$_$.i3;
  var Companion_instance = kotlin_jabbah_draw.$_$.b;
  var IllegalArgumentException_init_$Create$ = kotlin_kotlin.$_$.b1;
  var Direction_SOUTH_getInstance = kotlin_jabbah_base.$_$.v2;
  var Companion_instance_0 = kotlin_jabbah_base.$_$.e;
  var Direction_NORTH_getInstance = kotlin_jabbah_base.$_$.u2;
  var Direction_WEST_getInstance = kotlin_jabbah_base.$_$.w2;
  var Direction_EAST_getInstance = kotlin_jabbah_base.$_$.t2;
  var InputEventHandlerAdapter = kotlin_jabbah_draw.$_$.f6;
  var Point2D_init_$Create$ = kotlin_jabbah_base.$_$.q3;
  var InputEventHandler = kotlin_jabbah_draw.$_$.g6;
  var getKClassFromExpression = kotlin_kotlin.$_$.p8;
  var MouseAdapter = kotlin_jabbah_base.$_$.q5;
  var KeyAdapter = kotlin_jabbah_base.$_$.o5;
  var PropertyChangeListener = kotlin_jabbah_base.$_$.t5;
  var DrawableContainerAdapter = kotlin_jabbah_draw.$_$.s2;
  var PropertyChangeSupport = kotlin_jabbah_base.$_$.u5;
  var Rectangle2D_init_$Create$ = kotlin_jabbah_base.$_$.t3;
  var DropShadow_instance = kotlin_jabbah_draw.$_$.j;
  var DrawStyleModule_getInstance = kotlin_jabbah_draw.$_$.s;
  var Companion_getInstance_0 = kotlin_jabbah_draw.$_$.v;
  var get_canMirror = kotlin_jabbah_draw.$_$.o3;
  var Mirrorable = kotlin_jabbah_draw.$_$.p3;
  var FunctionAdapter = kotlin_kotlin.$_$.k6;
  var Rectangle2D_init_$Create$_0 = kotlin_jabbah_base.$_$.u3;
  var Ellipse2D_init_$Create$ = kotlin_jabbah_base.$_$.p3;
  var Colorable = kotlin_jabbah_draw.$_$.g3;
  var contains = kotlin_kotlin.$_$.u2;
  var to = kotlin_kotlin.$_$.tb;
  var mapOf = kotlin_kotlin.$_$.u3;
  var StylableImpl = kotlin_jabbah_draw.$_$.h5;
  var AbstractStyledDrawable = kotlin_jabbah_draw.$_$.e3;
  var Rotation_R0_getInstance = kotlin_jabbah_base.$_$.x2;
  var Companion_instance_1 = kotlin_jabbah_base.$_$.j;
  var DrawModule_getInstance = kotlin_jabbah_draw.$_$.n;
  var prepareMoveBy = kotlin_jabbah_draw.$_$.r3;
  var completeMoveBy = kotlin_jabbah_draw.$_$.q3;
  var get_isReferencable = kotlin_jabbah_io.$_$.l;
  var get_isNotReading = kotlin_jabbah_io.$_$.k;
  var resolutionDone = kotlin_jabbah_io.$_$.n;
  var allResolutionDone = kotlin_jabbah_io.$_$.j;
  var readFromStore = kotlin_jabbah_io.$_$.m;
  var get_isFocusOwner = kotlin_jabbah_draw.$_$.b6;
  var requestFocus = kotlin_jabbah_draw.$_$.c6;
  var compareTo = kotlin_kotlin.$_$.s6;
  var DrawableContainerImpl = kotlin_jabbah_draw.$_$.u2;
  var listOf = kotlin_kotlin.$_$.s3;
  var Reference = kotlin_jabbah_io.$_$.i;
  var toString_0 = kotlin_kotlin.$_$.rb;
  var enumEntries = kotlin_kotlin.$_$.s5;
  var noWhenBranchMatchedException = kotlin_kotlin.$_$.pb;
  var checkIndexOverflow = kotlin_kotlin.$_$.r2;
  var TransparentImpl = kotlin_jabbah_draw.$_$.i4;
  var applyTo = kotlin_jabbah_draw.$_$.h4;
  var Transparent = kotlin_jabbah_draw.$_$.j4;
  var Stroke = kotlin_jabbah_draw.$_$.b5;
  var Cursor_CROSSHAIR_getInstance = kotlin_jabbah_draw.$_$.e1;
  var Point2D_init_$Create$_0 = kotlin_jabbah_base.$_$.r3;
  var listOf_0 = kotlin_kotlin.$_$.t3;
  var AbstractRectangularUnzoomable = kotlin_jabbah_draw.$_$.d3;
  var Rectangle2D = kotlin_jabbah_base.$_$.f6;
  var asReversed = kotlin_kotlin.$_$.p2;
  var resettableLazy = kotlin_jabbah_base.$_$.r7;
  var UUID = kotlin_jabbah_base.$_$.p7;
  var AbstractStorable = kotlin_jabbah_io.$_$.f;
  var ImageType_SVG_getInstance = kotlin_jabbah_draw.$_$.q1;
  var KMutableProperty1 = kotlin_kotlin.$_$.r8;
  var Companion_instance_2 = kotlin_jabbah_draw.$_$.k;
  var Geometry_instance = kotlin_jabbah_base.$_$.g;
  var until = kotlin_kotlin.$_$.o8;
  var Companion_getInstance_1 = kotlin_jabbah_base.$_$.f;
  var Companion_getInstance_2 = kotlin_jabbah_draw.$_$.o;
  var PolylineDrawable = kotlin_jabbah_draw.$_$.d5;
  var DrawableOwner = kotlin_jabbah_draw.$_$.y2;
  var MutableRectangularShape = kotlin_jabbah_base.$_$.c6;
  var findSegment$default = kotlin_jabbah_draw.$_$.k2;
  var Polyline = kotlin_jabbah_draw.$_$.e5;
  var Tooltip = kotlin_jabbah_base.$_$.n7;
  var Ellipse2D = kotlin_jabbah_base.$_$.b6;
  var RoundRectangle2D = kotlin_jabbah_base.$_$.i6;
  var Status_getInstance = kotlin_jabbah_base.$_$.a1;
  var StatusType_Small_getInstance = kotlin_jabbah_base.$_$.h3;
  var Cursor_NW_RESIZE_getInstance = kotlin_jabbah_draw.$_$.j1;
  var Cursor_N_RESIZE_getInstance = kotlin_jabbah_draw.$_$.k1;
  var Cursor_NE_RESIZE_getInstance = kotlin_jabbah_draw.$_$.i1;
  var Cursor_E_RESIZE_getInstance = kotlin_jabbah_draw.$_$.g1;
  var Cursor_SE_RESIZE_getInstance = kotlin_jabbah_draw.$_$.l1;
  var Cursor_S_RESIZE_getInstance = kotlin_jabbah_draw.$_$.n1;
  var Cursor_SW_RESIZE_getInstance = kotlin_jabbah_draw.$_$.m1;
  var Cursor_W_RESIZE_getInstance = kotlin_jabbah_draw.$_$.o1;
  var Companion_getInstance_3 = kotlin_jabbah_draw.$_$.g;
  var AbstractDrawable = kotlin_jabbah_draw.$_$.b3;
  var Companion_getInstance_4 = kotlin_jabbah_draw.$_$.c;
  var moveBy = kotlin_jabbah_draw.$_$.m3;
  var Companion_instance_3 = kotlin_jabbah_base.$_$.i;
  var Rotation_R180_getInstance = kotlin_jabbah_base.$_$.y2;
  var Dimension2D = kotlin_jabbah_base.$_$.z5;
  var UnsupportedOperationException_init_$Create$ = kotlin_kotlin.$_$.m1;
  var RectangularShape = kotlin_jabbah_base.$_$.g6;
  var AbstractDrawableButtonRenderer = kotlin_jabbah_draw.$_$.z2;
  var StringUtils_getInstance = kotlin_jabbah_base.$_$.b1;
  var charSequenceLength = kotlin_kotlin.$_$.r6;
  var toMutableMap = kotlin_kotlin.$_$.v4;
  var Companion_getInstance_5 = kotlin_jabbah_base.$_$.x;
  var firstOrNull = kotlin_kotlin.$_$.g3;
  var asSequence = kotlin_kotlin.$_$.u8;
  var joinToString = kotlin_kotlin.$_$.v8;
  var ObservableProperty = kotlin_kotlin.$_$.z7;
  var IOModule_getInstance = kotlin_jabbah_io.$_$.b;
  var IllegalArgumentException = kotlin_kotlin.$_$.ya;
  var IllegalArgumentException_init_$Init$ = kotlin_kotlin.$_$.a1;
  var captureStack = kotlin_kotlin.$_$.n6;
  var toNumber = kotlin_kotlin.$_$.j6;
  var IllegalArgumentException_init_$Create$_0 = kotlin_kotlin.$_$.z;
  var numberToLong = kotlin_kotlin.$_$.e6;
  var round = kotlin_kotlin.$_$.y7;
  var multiply = kotlin_kotlin.$_$.c6;
  var Cursor_MOVE_getInstance = kotlin_jabbah_draw.$_$.h1;
  var DrawableAdapter = kotlin_jabbah_draw.$_$.u5;
  var Drawable = kotlin_jabbah_draw.$_$.y5;
  var Color = kotlin_jabbah_draw.$_$.n4;
  var LineCap_SQUARE_getInstance = kotlin_jabbah_draw.$_$.t1;
  var LineJoin_MITER_getInstance = kotlin_jabbah_draw.$_$.u1;
  var Unzoomable = kotlin_jabbah_draw.$_$.k4;
  var AbstractRectangle = kotlin_jabbah_draw.$_$.c3;
  var emptyMap = kotlin_kotlin.$_$.d3;
  var StatusType_Tool_getInstance = kotlin_jabbah_base.$_$.i3;
  var CurrentPanMethod_getInstance = kotlin_jabbah_draw.$_$.x;
  var mutableListOf = kotlin_kotlin.$_$.y3;
  var TooltipHandler = kotlin_jabbah_draw.$_$.m5;
  var Cursor_DEFAULT_getInstance = kotlin_jabbah_draw.$_$.f1;
  var Button_BUTTON1_getInstance = kotlin_jabbah_base.$_$.z1;
  var Companion_getInstance_6 = kotlin_jabbah_draw.$_$.u;
  var StyleType = kotlin_jabbah_draw.$_$.j5;
  var Color_init_$Create$ = kotlin_jabbah_draw.$_$.p2;
  var CompositeColor = kotlin_jabbah_draw.$_$.p4;
  var BasicStyle = kotlin_jabbah_draw.$_$.f5;
  var DrawTheme = kotlin_jabbah_draw.$_$.g5;
  var ReferenceColorSequenceProvider_getInstance = kotlin_jabbah_draw.$_$.l;
  var Companion_getInstance_7 = kotlin_jabbah_draw.$_$.t;
  var AbstractAction = kotlin_jabbah_base.$_$.c7;
  var AbstractAction_init_$Init$ = kotlin_jabbah_base.$_$.y3;
  var Ring2D = kotlin_jabbah_base.$_$.h6;
  var AnimationTaskAdapter = kotlin_jabbah_animation.$_$.c;
  var DoubleRange = kotlin_jabbah_animation.$_$.f;
  var FlexibleTextView = kotlin_jabbah_draw.$_$.k3;
  var Companion_getInstance_8 = kotlin_jabbah_draw.$_$.f;
  var DisplayDuration_instance = kotlin_jabbah_base.$_$.v;
  var AnimationModule_getInstance = kotlin_jabbah_animation.$_$.a;
  var UnzoomableContainer = kotlin_jabbah_draw.$_$.x2;
  var ViewImpl = kotlin_jabbah_draw.$_$.n5;
  var DrawableContainerDrawer = kotlin_jabbah_draw.$_$.t2;
  var InvalidatableViewPainter = kotlin_jabbah_draw.$_$.l5;
  var ViewContentBounds = kotlin_jabbah_draw.$_$.i6;
  //endregion
  //region block: pre-declaration
  initMetadataForClass(TextComponentFactoryJs, 'TextComponentFactoryJs', TextComponentFactoryJs);
  initMetadataForObject(EditModuleJs, 'EditModuleJs', VOID, AbstractModule);
  function getDetailedDescription() {
    return this.q39();
  }
  function notifyUndo() {
  }
  initMetadataForInterface(Command, 'Command');
  initMetadataForClass(AbstractCommand, 'AbstractCommand', VOID, VOID, [Command]);
  function get_canUndo() {
    return true;
  }
  initMetadataForInterface(Undoable, 'Undoable');
  initMetadataForClass(AbstractPropertyCommand, 'AbstractPropertyCommand', VOID, AbstractCommand, [Undoable]);
  function beginTransaction$default(command, register, $super) {
    register = register === VOID ? false : register;
    var tmp;
    if ($super === VOID) {
      this.a3a(command, register);
      tmp = Unit_instance;
    } else {
      tmp = $super.a3a.call(this, command, register);
    }
    return tmp;
  }
  initMetadataForInterface(CommandManager, 'CommandManager');
  initMetadataForClass(CommandEvent, 'CommandEvent');
  initMetadataForClass(CommandEventType, 'CommandEventType', VOID, Enum);
  initMetadataForClass(CommandManagerActiveEvent, 'CommandManagerActiveEvent');
  function getSnapHighlightX(x, y) {
    return null;
  }
  function getSnapHighlightY(x, y) {
    return null;
  }
  initMetadataForInterface(Snappable, 'Snappable');
  function get_isDragManager() {
    return false;
  }
  function collectSelectBuddies(drawing, buddies) {
  }
  function notifyEditable(editable) {
  }
  initMetadataForInterface(Component, 'Component', VOID, VOID, [Movable, Locatable, Snappable, Storable, Stylable, Focusable]);
  initMetadataForInterface(ComponentContainer, 'ComponentContainer', VOID, VOID, [DrawableContainer, Storable]);
  initMetadataForInterface(DragManagerDestinationPlugin, 'DragManagerDestinationPlugin');
  initMetadataForInterface(Namable, 'Namable');
  function notifyEditable_0(editable) {
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = this.e20().i();
    while (_iterator__ex2g4s.j()) {
      var element = _iterator__ex2g4s.k();
      element.s3a(editable);
    }
  }
  initMetadataForInterface(Drawing, 'Drawing', VOID, VOID, [ComponentContainer, Namable]);
  initMetadataForInterface(DrawingView, 'DrawingView', VOID, VOID, [View]);
  initMetadataForInterface(DrawingViewContent, 'DrawingViewContent');
  initMetadataForClass(EditInputEventContext, 'EditInputEventContext', VOID, InputEventContext);
  function get_drawing() {
    return this.f1o().e3b();
  }
  initMetadataForInterface(Editor, 'Editor');
  initMetadataForObject(GridPainterRegistry, 'GridPainterRegistry');
  initMetadataForObject(Look, 'Look');
  initMetadataForClass(Type, 'Type', VOID, Enum);
  initMetadataForClass(SelectionChangeEvent, 'SelectionChangeEvent');
  initMetadataForClass(SelectionDrawingStrategy, 'SelectionDrawingStrategy', VOID, Enum);
  function get_selectionCount() {
    // Inline function 'kotlin.collections.count' call
    return this.f3d().o();
  }
  initMetadataForInterface(SelectionManager, 'SelectionManager');
  initMetadataForClass(SnapResult, 'SnapResult', SnapResult);
  initMetadataForCompanion(Companion);
  initMetadataForClass(SnappableXCoordinate, 'SnappableXCoordinate');
  initMetadataForClass(SnappableYCoordinate, 'SnappableYCoordinate');
  function getSnapHighlightX_0(x, y, snappable) {
    return null;
  }
  function getSnapHighlightY_0(x, y, snappable) {
    return null;
  }
  initMetadataForInterface(Snapper, 'Snapper');
  function mouseClicked(e, p) {
    return this.n3e(e, p.in_1, p.jn_1);
  }
  function mousePressed(e, p) {
    return this.p3e(e, p.in_1, p.jn_1);
  }
  function mouseReleased(e, p) {
    return this.r3e(e, p.in_1, p.jn_1);
  }
  function mouseMoved(e, p) {
    return this.t3e(e, p.in_1, p.jn_1);
  }
  function mouseDragged(e, p) {
    return this.v3e(e, p.in_1, p.jn_1);
  }
  initMetadataForInterface(Tool, 'Tool');
  initMetadataForClass(DeleteQuestion, 'DeleteQuestion');
  function move$default(movables, offset, editor, register, additionalCommands, $super) {
    additionalCommands = additionalCommands === VOID ? emptyList() : additionalCommands;
    var tmp;
    if ($super === VOID) {
      this.z3e(movables, offset, editor, register, additionalCommands);
      tmp = Unit_instance;
    } else {
      tmp = $super.z3e.call(this, movables, offset, editor, register, additionalCommands);
    }
    return tmp;
  }
  initMetadataForInterface(DrawingAppService, 'DrawingAppService');
  initMetadataForCompanion(Companion_0);
  initMetadataForClass(DrawingAppServiceImpl, 'DrawingAppServiceImpl', DrawingAppServiceImpl, VOID, [DrawingAppService]);
  initMetadataForClass(AuthorizationBuilder, 'AuthorizationBuilder', AuthorizationBuilder);
  initMetadataForClass(Authorization, 'Authorization');
  initMetadataForObject(Authorizer, 'Authorizer');
  initMetadataForClass(DesktopUserHolder, 'DesktopUserHolder');
  initMetadataForCompanion(Companion_1);
  initMetadataForClass(DesktopUser, 'DesktopUser');
  initMetadataForObject(EditAuthModule, 'EditAuthModule', VOID, AbstractModule);
  initMetadataForClass(Operation, 'Operation', VOID, Enum);
  initMetadataForCompanion(Companion_2);
  initMetadataForObject($serializer, '$serializer', VOID, VOID, [GeneratedSerializer]);
  initMetadataForClass(UserIdentity, 'UserIdentity', VOID, VOID, VOID, VOID, VOID, {0: $serializer_getInstance});
  initMetadataForClass(AbstractDrawingViewCommand, 'AbstractDrawingViewCommand', VOID, AbstractCommand);
  initMetadataForCompanion(Companion_3);
  initMetadataForClass(Snapshot, 'Snapshot', VOID, VOID, [Disposable]);
  initMetadataForCompanion(Companion_4);
  initMetadataForClass(CommandIterator, 'CommandIterator', VOID, AbstractIterator);
  initMetadataForClass(SourcingCommandManager, 'SourcingCommandManager', SourcingCommandManager, VOID, [CommandManager]);
  initMetadataForCompanion(Companion_5);
  initMetadataForClass(Transaction, 'Transaction', Transaction);
  initMetadataForClass(TransactionCommand, 'TransactionCommand', VOID, AbstractCommand, [Undoable]);
  initMetadataForClass(TransactionStackWriter, 'TransactionStackWriter');
  initMetadataForClass(DropEvent, 'DropEvent');
  initMetadataForInterface(DragDestination, 'DragDestination', VOID, VOID, [Component]);
  initMetadataForClass(DragDestinationHighlightFactoryRegistry, 'DragDestinationHighlightFactoryRegistry', DragDestinationHighlightFactoryRegistry);
  initMetadataForInterface(DragDestinationHighlightFactory, 'DragDestinationHighlightFactory');
  initMetadataForObject(DragDestinationHighlighter, 'DragDestinationHighlighter', VOID, VOID, [DragManagerDestinationPlugin]);
  initMetadataForCompanion(Companion_6);
  initMetadataForClass(DragManagerImpl, 'DragManagerImpl', VOID, InputEventHandlerAdapter, [InputEventHandler]);
  initMetadataForObject(EditDragModule, 'EditDragModule', VOID, AbstractModule);
  initMetadataForClass(AddCommand, 'AddCommand', VOID, AbstractDrawingViewCommand, [Undoable]);
  initMetadataForObject(EditEditorModule, 'EditEditorModule', VOID, AbstractModule);
  initMetadataForClass(MouseEventDelegator, 'MouseEventDelegator', VOID, MouseAdapter);
  initMetadataForClass(KeyEventDelegator, 'KeyEventDelegator', VOID, KeyAdapter);
  initMetadataForClass(DrawingViewListener, 'DrawingViewListener', VOID, VOID, [PropertyChangeListener]);
  initMetadataForClass(DrawingListener, 'DrawingListener', VOID, DrawableContainerAdapter);
  initMetadataForClass(EditorImpl, 'EditorImpl', VOID, VOID, [Editor]);
  initMetadataForClass(AbstractComponent, 'AbstractComponent', VOID, AbstractStyledDrawable, [Component]);
  initMetadataForClass(AbstractPathFigure, 'AbstractPathFigure', VOID, AbstractComponent, [Mirrorable, Component]);
  initMetadataForInterface(FigureFactory, 'FigureFactory');
  initMetadataForClass(sam$io_antarescircuit_jabbah_edit_figure_FigureFactory$0, 'sam$io_antarescircuit_jabbah_edit_figure_FigureFactory$0', VOID, VOID, [FigureFactory, FunctionAdapter]);
  initMetadataForObject(FigureRegistry, 'FigureRegistry');
  initMetadataForClass(FigureGroup, 'FigureGroup');
  initMetadataForClass(FigureProvider, 'FigureProvider');
  initMetadataForClass(DrawingViewSearch, 'DrawingViewSearch', DrawingViewSearch);
  initMetadataForCompanion(Companion_7);
  initMetadataForClass(BelowSmHighlighter, 'BelowSmHighlighter');
  initMetadataForClass(EditHighlightModule$highlighterFactory$1);
  initMetadataForObject(EditHighlightModule, 'EditHighlightModule', VOID, AbstractModule);
  initMetadataForClass(Type_0, 'Type', VOID, Enum);
  initMetadataForClass(HighlightChangeEvent, 'HighlightChangeEvent');
  initMetadataForClass(ComponentContainerImpl, 'ComponentContainerImpl', ComponentContainerImpl, DrawableContainerImpl, [ComponentContainer]);
  initMetadataForClass(ComponentMessage, 'ComponentMessage');
  initMetadataForClass(ComponentMessageType, 'ComponentMessageType', VOID, Enum);
  initMetadataForClass(CopyPasteService, 'CopyPasteService', CopyPasteService);
  initMetadataForClass(DrawingImpl, 'DrawingImpl', DrawingImpl, ComponentContainerImpl, [Drawing]);
  initMetadataForClass(DrawingServiceImpl, 'DrawingServiceImpl', DrawingServiceImpl);
  initMetadataForCompanion(Companion_8);
  initMetadataForClass(Size, 'Size', VOID, Enum);
  initMetadataForCompanion(Companion_9);
  initMetadataForClass(AbstractCurveComponent, 'AbstractCurveComponent', VOID, AbstractComponent, [Transparent, Mirrorable]);
  initMetadataForCompanion(Companion_10);
  initMetadataForClass(EventHandler, 'EventHandler', VOID, InputEventHandlerAdapter);
  initMetadataForClass(CurveEventHandler, 'CurveEventHandler', VOID, EventHandler);
  initMetadataForClass(QuadCurveInputEventHandler, 'QuadCurveInputEventHandler', VOID, InputEventHandlerAdapter);
  initMetadataForClass(AbstractSelectionModel, 'AbstractSelectionModel', VOID, AbstractDrawable, [Drawable]);
  initMetadataForInterface(UnzoomableSelectionModel, 'UnzoomableSelectionModel', VOID, VOID, [Drawable, Unzoomable]);
  initMetadataForClass(AbstractHandleSelectionModel, 'AbstractHandleSelectionModel', VOID, AbstractSelectionModel, [UnzoomableSelectionModel]);
  initMetadataForClass(AbstractCurveHandleSelectionModel, 'AbstractCurveHandleSelectionModel', VOID, AbstractHandleSelectionModel);
  initMetadataForCompanion(Companion_11);
  initMetadataForClass(CubicCurveComponent, 'CubicCurveComponent', CubicCurveComponent, AbstractCurveComponent);
  initMetadataForClass(CubicCurveHandleSelectionModel, 'CubicCurveHandleSelectionModel', VOID, AbstractCurveHandleSelectionModel);
  initMetadataForClass(SelectedColorSelectionModel, 'SelectedColorSelectionModel', VOID, AbstractSelectionModel);
  initMetadataForClass(AbstractSelectedColorWrappingSelectionModel, 'AbstractSelectedColorWrappingSelectionModel', VOID, SelectedColorSelectionModel);
  initMetadataForClass(CubicCurveReplaceSelectionModel, 'CubicCurveReplaceSelectionModel', VOID, AbstractSelectedColorWrappingSelectionModel);
  initMetadataForObject(EditModuleCurveModule, 'EditModuleCurveModule', VOID, AbstractModule);
  initMetadataForClass(MoveCurvePointCommand, 'MoveCurvePointCommand', VOID, AbstractDrawingViewCommand, [Undoable]);
  initMetadataForCompanion(Companion_12);
  initMetadataForClass(QuadCurveComponent, 'QuadCurveComponent', QuadCurveComponent, AbstractCurveComponent);
  initMetadataForClass(QuadCurveHandleSelectionModel, 'QuadCurveHandleSelectionModel', VOID, AbstractCurveHandleSelectionModel);
  initMetadataForClass(QuadCurveReplaceSelectionModel, 'QuadCurveReplaceSelectionModel', VOID, AbstractSelectedColorWrappingSelectionModel);
  initMetadataForObject(EditModelGroupModule, 'EditModelGroupModule', VOID, AbstractModule);
  initMetadataForCompanion(Companion_13);
  initMetadataForClass(GroupComponent, 'GroupComponent', GroupComponent, AbstractComponent);
  initMetadataForClass(GroupComponentSelectionModel, 'GroupComponentSelectionModel', VOID, AbstractSelectionModel);
  initMetadataForCompanion(Companion_14);
  initMetadataForClass(AbstractRectangularComponent, 'AbstractRectangularComponent', VOID, AbstractComponent, [MutableRectangularShape, Mirrorable]);
  initMetadataForInterface(Describable, 'Describable');
  initMetadataForInterface(Labeled, 'Labeled');
  initMetadataForClass(RectangularComponent, 'RectangularComponent', VOID, AbstractRectangularComponent, [Transparent, Describable, Labeled, Mirrorable, Component]);
  initMetadataForClass(RectangleComponent, 'RectangleComponent', RectangleComponent, RectangularComponent);
  initMetadataForClass(ImageComponent, 'ImageComponent', ImageComponent, RectangleComponent);
  initMetadataForClass(ImageIdentification, 'ImageIdentification', ImageIdentification, AbstractStorable, [Namable]);
  initMetadataForClass(ImageData, 'ImageData');
  initMetadataForClass(AddPolylinePointCommand, 'AddPolylinePointCommand', VOID, AbstractCommand, [Undoable]);
  initMetadataForCompanion(Companion_15);
  initMetadataForClass(CompactablePolyline, 'CompactablePolyline', CompactablePolyline_init_$Create$);
  initMetadataForObject(EditModelPolylineModule, 'EditModelPolylineModule', VOID, AbstractModule);
  initMetadataForClass(JoinPolylinePointsCommand, 'JoinPolylinePointsCommand', VOID, AbstractCommand, [Undoable]);
  initMetadataForCompanion(Companion_16);
  initMetadataForClass(MovePolylinePointCommand, 'MovePolylinePointCommand', VOID, AbstractCommand, [Undoable]);
  initMetadataForCompanion(Companion_17);
  initMetadataForClass(PolylineComponent, 'PolylineComponent', PolylineComponent, AbstractComponent, [Polyline, Transparent, Mirrorable, Component]);
  initMetadataForCompanion(Companion_18);
  initMetadataForClass(PolylineEventHandler, 'PolylineEventHandler', VOID, EventHandler);
  initMetadataForClass(PolylinePointInputEventHandler, 'PolylinePointInputEventHandler', VOID, InputEventHandlerAdapter);
  initMetadataForClass(PolylineHandleSelectionModel, 'PolylineHandleSelectionModel', VOID, AbstractHandleSelectionModel);
  initMetadataForClass(PolylineReplaceSelectionModel, 'PolylineReplaceSelectionModel', VOID, AbstractSelectedColorWrappingSelectionModel);
  initMetadataForCompanion(Companion_19);
  initMetadataForObject(EditModelRectangleModule, 'EditModelRectangleModule', VOID, AbstractModule);
  initMetadataForCompanion(Companion_20);
  initMetadataForClass(RectangularBelowSelectionModel, 'RectangularBelowSelectionModel', VOID, AbstractSelectionModel);
  initMetadataForCompanion(Companion_21);
  initMetadataForCompanion(Companion_22);
  initMetadataForCompanion(Companion_23);
  initMetadataForClass(EllipseComponent, 'EllipseComponent', EllipseComponent, RectangularComponent);
  initMetadataForCompanion(Companion_24);
  initMetadataForClass(RoundRectangleComponent, 'RoundRectangleComponent', RoundRectangleComponent, RectangularComponent);
  initMetadataForCompanion(Companion_25);
  initMetadataForClass(RectangleEventHandler, 'RectangleEventHandler', VOID, EventHandler);
  initMetadataForClass(NorthWestHandler, 'NorthWestHandler', VOID, InputEventHandlerAdapter);
  initMetadataForClass(NorthHandler, 'NorthHandler', VOID, InputEventHandlerAdapter);
  initMetadataForClass(NorthEastHandler, 'NorthEastHandler', VOID, InputEventHandlerAdapter);
  initMetadataForClass(EastHandler, 'EastHandler', VOID, InputEventHandlerAdapter);
  initMetadataForClass(SouthEastHandler, 'SouthEastHandler', VOID, InputEventHandlerAdapter);
  initMetadataForClass(SouthHandler, 'SouthHandler', VOID, InputEventHandlerAdapter);
  initMetadataForClass(SouthWestHandler, 'SouthWestHandler', VOID, InputEventHandlerAdapter);
  initMetadataForClass(WestHandler, 'WestHandler', VOID, InputEventHandlerAdapter);
  initMetadataForClass(RectangularHandleSelectionModel, 'RectangularHandleSelectionModel', VOID, AbstractHandleSelectionModel);
  initMetadataForClass(DrawStrategy, 'DrawStrategy', VOID, Enum);
  initMetadataForClass(RectangularReplaceSelectionModel$DrawStrategy$SHAPE, 'SHAPE', VOID, DrawStrategy);
  initMetadataForClass(RectangularReplaceSelectionModel$DrawStrategy$COMPONENT, 'COMPONENT', VOID, DrawStrategy);
  initMetadataForClass(RectangularReplaceSelectionModel, 'RectangularReplaceSelectionModel', VOID, AbstractSelectedColorWrappingSelectionModel);
  initMetadataForClass(ResizeRectangleCommand, 'ResizeRectangleCommand', VOID, AbstractCommand, [Undoable]);
  initMetadataForCompanion(Companion_26);
  function contains_0(x, y) {
    throw UnsupportedOperationException_init_$Create$('not implemented');
  }
  function contains_1(p) {
    throw UnsupportedOperationException_init_$Create$('not implemented');
  }
  function intersects(rect) {
    throw UnsupportedOperationException_init_$Create$('not implemented');
  }
  initMetadataForInterface(TextComponent, 'TextComponent', VOID, VOID, [Component, RectangularShape]);
  initMetadataForClass(AbstractTextComponent, 'AbstractTextComponent', VOID, AbstractRectangularComponent, [TextComponent, Transparent]);
  initMetadataForClass(HorizontalAlignment, 'HorizontalAlignment', VOID, Enum);
  initMetadataForClass(HorizontalAlignment$LEFT, 'LEFT', VOID, HorizontalAlignment);
  initMetadataForClass(HorizontalAlignment$CENTER, 'CENTER', VOID, HorizontalAlignment);
  initMetadataForClass(HorizontalAlignment$RIGHT, 'RIGHT', VOID, HorizontalAlignment);
  initMetadataForCompanion(Companion_27);
  initMetadataForClass(VerticalAlignment, 'VerticalAlignment', VOID, Enum);
  initMetadataForClass(VerticalAlignment$TOP, 'TOP', VOID, VerticalAlignment);
  initMetadataForClass(VerticalAlignment$CENTER, 'CENTER', VOID, VerticalAlignment);
  initMetadataForClass(VerticalAlignment$BOTTOM, 'BOTTOM', VOID, VerticalAlignment);
  initMetadataForCompanion(Companion_28);
  initMetadataForCompanion(Companion_29);
  initMetadataForClass(Alignment, 'Alignment');
  initMetadataForObject(EditModelTextModule, 'EditModelTextModule', VOID, AbstractModule);
  initMetadataForClass(HorizontalLabel, 'HorizontalLabel');
  initMetadataForCompanion(Companion_30);
  initMetadataForClass(Label, 'Label', VOID, AbstractDrawable, [Mirrorable, Locatable]);
  initMetadataForCompanion(Companion_31);
  initMetadataForClass(LabelComponent, 'LabelComponent', LabelComponent, AbstractRectangularComponent, [TextComponent, Transparent, Labeled]);
  initMetadataForClass(RotationDisplayStrategy, 'RotationDisplayStrategy', VOID, Enum);
  initMetadataForClass(RotationDisplayStrategy$IGNORE, 'IGNORE', VOID, RotationDisplayStrategy);
  initMetadataForClass(RotationDisplayStrategy$ROTATE_HALF, 'ROTATE_HALF', VOID, RotationDisplayStrategy);
  initMetadataForClass(RotationDisplayStrategy$KEEP_HORIZONTAL, 'KEEP_HORIZONTAL', VOID, RotationDisplayStrategy);
  initMetadataForCompanion(Companion_32);
  initMetadataForClass(SimpleTextComponent, 'SimpleTextComponent', SimpleTextComponent, AbstractTextComponent, [TextComponent, Transparent]);
  initMetadataForClass(UndefinedTextComponentFactory, 'UndefinedTextComponentFactory', UndefinedTextComponentFactory);
  initMetadataForClass(RectangularShapeTextComponentDecorator, 'RectangularShapeTextComponentDecorator');
  initMetadataForClass(TextDrawableButtonRenderer, 'TextDrawableButtonRenderer', VOID, AbstractDrawableButtonRenderer);
  initMetadataForClass(ScriptProperty, 'ScriptProperty', ScriptProperty);
  function get_isNotEmpty() {
    return !this.ov();
  }
  function getTranslation() {
    return this.u4d(System_getInstance().fm());
  }
  function withTranslation(text) {
    return this.w4d(System_getInstance().fm(), text);
  }
  function getOptionalTranslation() {
    return this.y4d(System_getInstance().fm());
  }
  initMetadataForInterface(Translatable, 'Translatable');
  initMetadataForClass(TranslatableText, 'TranslatableText', TranslatableText, VOID, [Translatable]);
  initMetadataForCompanion(Companion_33);
  initMetadataForClass(Translation, 'Translation', Translation, VOID, [Storable]);
  initMetadataForCompanion(Companion_34);
  initMetadataForClass(Description, 'Description', VOID, VOID, [Translatable]);
  initMetadataForClass(DescriptionChangedEvent, 'DescriptionChangedEvent');
  initMetadataForClass(observableDescription$3, VOID, VOID, ObservableProperty);
  initMetadataForCompanion(Companion_35);
  initMetadataForClass(Name, 'Name', VOID, VOID, [Translatable]);
  initMetadataForClass(NameChangedEvent, 'NameChangedEvent');
  initMetadataForClass(observableName$3, VOID, VOID, ObservableProperty);
  initMetadataForClass(EditModule$drawingViewFactory$1);
  initMetadataForClass(EditModule$imageRepository$1);
  initMetadataForObject(EditModule, 'EditModule', VOID, AbstractModule);
  initMetadataForClass(PropertyValueException, 'PropertyValueException', VOID, IllegalArgumentException);
  initMetadataForCompanion(Companion_36);
  initMetadataForClass(Magnitude, 'Magnitude', VOID, Enum);
  initMetadataForCompanion(Companion_37);
  initMetadataForClass(MagnitudeValue, 'MagnitudeValue');
  initMetadataForCompanion(Companion_38);
  initMetadataForClass(SIUnit, 'SIUnit', VOID, Enum);
  initMetadataForCompanion(Companion_39);
  initMetadataForClass(AbstractBelowSelectionModel, 'AbstractBelowSelectionModel', VOID, AbstractSelectionModel, [Colorable]);
  initMetadataForClass(EventHandler_0, 'EventHandler', VOID, InputEventHandlerAdapter);
  initMetadataForClass(AbstractSelectionModel$geometryUpdateListener$1, VOID, VOID, DrawableAdapter);
  initMetadataForClass(BoundingBoxBelowSelectionModel, 'BoundingBoxBelowSelectionModel', VOID, AbstractBelowSelectionModel);
  initMetadataForObject(EditSelectModule, 'EditSelectModule', VOID, AbstractModule);
  function setLocation(x, y) {
    this.f20(new Point2D(x, y));
  }
  initMetadataForInterface(Handle, 'Handle', VOID, VOID, [Drawable, Unzoomable]);
  initMetadataForClass(MoveCommand, 'MoveCommand', VOID, AbstractCommand);
  initMetadataForClass(RectangularHandle, 'RectangularHandle', VOID, AbstractRectangularUnzoomable, [Handle]);
  initMetadataForCompanion(Companion_40);
  initMetadataForClass(EventHandler_1, 'EventHandler', VOID, InputEventHandlerAdapter);
  function contains_2(rect) {
    return this.fo(rect.z19(), rect.a1a(), rect.p1b(), rect.r1b());
  }
  initMetadataForInterface(RubberBand, 'RubberBand', VOID, VOID, [Unzoomable]);
  initMetadataForClass(RectangularRubberBand, 'RectangularRubberBand', RectangularRubberBand, AbstractRectangle, [RubberBand]);
  initMetadataForClass(SelectionTargetStrategy, 'SelectionTargetStrategy', VOID, Enum);
  initMetadataForClass(RubberBandHandler$SelectionTargetStrategy$CONTAINS, 'CONTAINS', VOID, SelectionTargetStrategy);
  initMetadataForClass(RubberBandHandler$SelectionTargetStrategy$INTERSECTS, 'INTERSECTS', VOID, SelectionTargetStrategy);
  initMetadataForCompanion(Companion_41);
  initMetadataForCompanion(Companion_42);
  initMetadataForClass(RubberBandHandler, 'RubberBandHandler', VOID, InputEventHandlerAdapter);
  initMetadataForCompanion(Companion_43);
  initMetadataForClass(SelectionManagerImpl, 'SelectionManagerImpl', VOID, VOID, [SelectionManager]);
  initMetadataForClass(Entry, 'Entry');
  initMetadataForClass(SelectionModelFactoryImpl, 'SelectionModelFactoryImpl', SelectionModelFactoryImpl);
  initMetadataForCompanion(Companion_44);
  initMetadataForClass(AbstractTool, 'AbstractTool', VOID, VOID, [Tool]);
  initMetadataForClass(ToolAdapter, 'ToolAdapter', VOID, AbstractTool);
  initMetadataForClass(SelectionToolImpl, 'SelectionToolImpl', VOID, ToolAdapter, [Tool]);
  initMetadataForClass(SimpleSelectionModelProvider, 'SimpleSelectionModelProvider');
  initMetadataForObject(SemanticRegistry, 'SemanticRegistry');
  initMetadataForClass(DoSnapResult, 'DoSnapResult');
  initMetadataForClass(AbstractSnapper, 'AbstractSnapper', VOID, AbstractDrawable, [Snapper]);
  initMetadataForCompanion(Companion_45);
  initMetadataForClass(SnapHighlightX, 'SnapHighlightX', VOID, AbstractDrawable, [Unzoomable]);
  initMetadataForClass(SnapHighlightY, 'SnapHighlightY', VOID, AbstractDrawable, [Unzoomable]);
  initMetadataForClass(ComponentSnapper, 'ComponentSnapper', VOID, AbstractSnapper);
  initMetadataForCompanion(Companion_46);
  initMetadataForClass(DottedGridPainter, 'DottedGridPainter');
  initMetadataForObject(EditSnapModule, 'EditSnapModule', VOID, AbstractModule);
  initMetadataForCompanion(Companion_47);
  initMetadataForClass(GridImpl, 'GridImpl', GridImpl, AbstractSnapper, [Unzoomable, Snapper]);
  initMetadataForCompanion(Companion_48);
  initMetadataForClass(LineGridPainter, 'LineGridPainter');
  initMetadataForClass(MultiComponentSnappable, 'MultiComponentSnappable', VOID, VOID, [Snappable]);
  initMetadataForCompanion(Companion_49);
  initMetadataForClass(SnapManagerImpl$mouseListener$1, VOID, VOID, MouseAdapter);
  initMetadataForClass(SnapManagerImpl$viewCanvasListener$1, VOID, VOID, VOID, [PropertyChangeListener]);
  initMetadataForClass(SnapManagerImpl, 'SnapManagerImpl');
  initMetadataForCompanion(Companion_50);
  initMetadataForClass(EditStyleType, 'EditStyleType', VOID, StyleType);
  initMetadataForCompanion(Companion_51);
  initMetadataForClass(EditTheme, 'EditTheme', EditTheme, DrawTheme);
  initMetadataForClass(ToolLockAction, 'ToolLockAction', VOID, AbstractAction);
  initMetadataForCompanion(Companion_52);
  initMetadataForClass(GrowingRing, 'GrowingRing', VOID, AbstractRectangularUnzoomable);
  initMetadataForClass(AttentionDrawerImpl$drawAttentionTo$1, VOID, VOID, AnimationTaskAdapter);
  initMetadataForClass(AttentionDrawerImpl, 'AttentionDrawerImpl', AttentionDrawerImpl);
  initMetadataForCompanion(Companion_53);
  initMetadataForClass(ComponentMessageDisplayer, 'ComponentMessageDisplayer');
  initMetadataForClass(ComponentRemoveListener, 'ComponentRemoveListener', VOID, DrawableContainerAdapter);
  initMetadataForClass(BackdropDrawer, 'BackdropDrawer', VOID, AbstractDrawable);
  initMetadataForClass(DrawingViewContentImpl, 'DrawingViewContentImpl', VOID, VOID, [DrawingViewContent]);
  initMetadataForCompanion(Companion_54);
  initMetadataForClass(DrawingViewDrawer, 'DrawingViewDrawer', VOID, DrawableContainerDrawer);
  initMetadataForClass(DrawingViewImpl, 'DrawingViewImpl', VOID, ViewImpl, [DrawingView]);
  //endregion
  function TextComponentFactoryJs() {
  }
  function EditModuleJs() {
    EditModuleJs_instance = this;
    AbstractModule.call(this);
  }
  protoOf(EditModuleJs).ro = function () {
    IOModuleJs_getInstance().to();
    DrawModuleJs_getInstance().to();
    EditModule_getInstance().to();
    EditModelTextModule_getInstance().p39_1 = new TextComponentFactoryJs();
  };
  var EditModuleJs_instance;
  function EditModuleJs_getInstance() {
    if (EditModuleJs_instance == null)
      new EditModuleJs();
    return EditModuleJs_instance;
  }
  function AbstractPropertyCommand() {
  }
  function Command() {
  }
  function Undoable() {
  }
  function CommandManager() {
  }
  function CommandEvent(commandManager, type) {
    this.h3a_1 = commandManager;
    this.i3a_1 = type;
  }
  protoOf(CommandEvent).toString = function () {
    return 'CommandEvent(commandManager=' + toString(this.h3a_1) + ', type=' + this.i3a_1.toString() + ')';
  };
  protoOf(CommandEvent).hashCode = function () {
    var result = hashCode(this.h3a_1);
    result = imul(result, 31) + this.i3a_1.hashCode() | 0;
    return result;
  };
  protoOf(CommandEvent).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof CommandEvent))
      return false;
    if (!equals(this.h3a_1, other.h3a_1))
      return false;
    if (!this.i3a_1.equals(other.i3a_1))
      return false;
    return true;
  };
  var CommandEventType_OPEN_CHECKPOINT_instance;
  var CommandEventType_CLOSE_CHECKPOINT_instance;
  var CommandEventType_COMMIT_TRANSACTION_instance;
  var CommandEventType_UNDO_instance;
  var CommandEventType_REDO_instance;
  var CommandEventType_RESET_instance;
  var CommandEventType_entriesInitialized;
  function CommandEventType_initEntries() {
    if (CommandEventType_entriesInitialized)
      return Unit_instance;
    CommandEventType_entriesInitialized = true;
    CommandEventType_OPEN_CHECKPOINT_instance = new CommandEventType('OPEN_CHECKPOINT', 0);
    CommandEventType_CLOSE_CHECKPOINT_instance = new CommandEventType('CLOSE_CHECKPOINT', 1);
    CommandEventType_COMMIT_TRANSACTION_instance = new CommandEventType('COMMIT_TRANSACTION', 2);
    CommandEventType_UNDO_instance = new CommandEventType('UNDO', 3);
    CommandEventType_REDO_instance = new CommandEventType('REDO', 4);
    CommandEventType_RESET_instance = new CommandEventType('RESET', 5);
  }
  function CommandEventType(name, ordinal) {
    Enum.call(this, name, ordinal);
  }
  function CommandManagerActiveEvent(commandManager) {
    this.j3a_1 = commandManager;
  }
  protoOf(CommandManagerActiveEvent).toString = function () {
    return 'CommandManagerActiveEvent(commandManager=' + toString(this.j3a_1) + ')';
  };
  protoOf(CommandManagerActiveEvent).hashCode = function () {
    return hashCode(this.j3a_1);
  };
  protoOf(CommandManagerActiveEvent).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof CommandManagerActiveEvent))
      return false;
    if (!equals(this.j3a_1, other.j3a_1))
      return false;
    return true;
  };
  function CommandEventType_COMMIT_TRANSACTION_getInstance() {
    CommandEventType_initEntries();
    return CommandEventType_COMMIT_TRANSACTION_instance;
  }
  function Component() {
  }
  function ComponentContainer() {
  }
  function DragManagerDestinationPlugin() {
  }
  function Drawing() {
  }
  function DrawingView() {
  }
  function DrawingViewContent() {
  }
  function EditInputEventContext(editor, mouseEvent, keyEvent, x, y, readonly) {
    mouseEvent = mouseEvent === VOID ? null : mouseEvent;
    keyEvent = keyEvent === VOID ? null : keyEvent;
    x = x === VOID ? 0.0 : x;
    y = y === VOID ? 0.0 : y;
    readonly = readonly === VOID ? false : readonly;
    InputEventContext.call(this, editor.f1o(), mouseEvent, keyEvent, x, y, readonly);
    this.e3c_1 = editor;
  }
  protoOf(EditInputEventContext).f22 = function (x, y) {
    return new EditInputEventContext(this.e3c_1, this.y21_1, this.z21_1, x, y);
  };
  protoOf(EditInputEventContext).n3b = function () {
    return this.e3c_1.f1o();
  };
  protoOf(EditInputEventContext).f3c = function () {
    return this.e3c_1.f1o();
  };
  function Editor() {
  }
  function GridPainterRegistry() {
    GridPainterRegistry_instance = this;
    var tmp = this;
    // Inline function 'kotlin.collections.mutableMapOf' call
    tmp.m3c_1 = LinkedHashMap_init_$Create$();
  }
  protoOf(GridPainterRegistry).n3c = function (name, factory) {
    // Inline function 'kotlin.collections.set' call
    this.m3c_1.y1(name, factory);
  };
  protoOf(GridPainterRegistry).nb = function (name) {
    return ensureNotNull(this.m3c_1.g2(name));
  };
  var GridPainterRegistry_instance;
  function GridPainterRegistry_getInstance() {
    if (GridPainterRegistry_instance == null)
      new GridPainterRegistry();
    return GridPainterRegistry_instance;
  }
  function updateFillBasicComponents($this) {
    $this.p3c_1 = BaseModule_getInstance().xo_1.ft('antares.view.fillBasicComponents');
  }
  function Look$initialize$lambda(it) {
    updateFillBasicComponents(Look_getInstance());
    return Unit_instance;
  }
  function Look() {
    Look_instance = this;
    this.o3c_1 = 'antares.view.fillBasicComponents';
    this.p3c_1 = true;
    this.q3c_1 = 7;
    this.r3c_1 = 7;
    this.s3c_1 = new FontImpl(LogicalFontFamily_DIALOG_getInstance(), FontStyle_PLAIN_getInstance().z2m_1, 11);
    this.t3c_1 = new FontImpl(LogicalFontFamily_SANS_SERIF_getInstance(), FontStyle_PLAIN_getInstance().z2m_1, numberToInt(1.5 * 7));
    this.u3c_1 = new FontImpl(LogicalFontFamily_SANS_SERIF_getInstance(), FontStyle_PLAIN_getInstance().z2m_1, numberToInt(1.5 * 7));
    this.v3c_1 = new FontImpl(LogicalFontFamily_SANS_SERIF_getInstance(), FontStyle_PLAIN_getInstance().z2m_1, numberToInt(1.4 * 7));
    this.w3c_1 = new FontImpl(LogicalFontFamily_MONOSPACED_getInstance(), FontStyle_PLAIN_getInstance().z2m_1, numberToInt(1.8 * 7));
  }
  protoOf(Look).u1i = function (eventBus) {
    var tmp = getKClass(PreferencesChangedEvent);
    eventBus.j17(tmp, Look$initialize$lambda);
    updateFillBasicComponents(this);
  };
  protoOf(Look).x3c = function (value) {
    // Inline function 'kotlin.math.ceil' call
    var x = value / 2 / 7;
    var tmp$ret$0 = Math.ceil(x);
    return imul(14, numberToInt(tmp$ret$0));
  };
  protoOf(Look).y3c = function () {
    return Themes_getInstance().r2f().h2f_1.m1t().i1x_1.b2f(192);
  };
  protoOf(Look).z3c = function () {
    return this.y3c();
  };
  var Look_instance;
  function Look_getInstance() {
    if (Look_instance == null)
      new Look();
    return Look_instance;
  }
  var Type_SELECTED_instance;
  var Type_DESELECTED_instance;
  var Type_entriesInitialized;
  function Type_initEntries() {
    if (Type_entriesInitialized)
      return Unit_instance;
    Type_entriesInitialized = true;
    Type_SELECTED_instance = new Type('SELECTED', 0);
    Type_DESELECTED_instance = new Type('DESELECTED', 1);
  }
  function SelectionChangeEvent_init_$Init$(view, components, selected, $this) {
    SelectionChangeEvent.call($this, view, selected ? Type_SELECTED_getInstance() : Type_DESELECTED_getInstance(), components);
    return $this;
  }
  function SelectionChangeEvent_init_$Create$(view, components, selected) {
    return SelectionChangeEvent_init_$Init$(view, components, selected, objectCreate(protoOf(SelectionChangeEvent)));
  }
  function Type(name, ordinal) {
    Enum.call(this, name, ordinal);
  }
  function Type_SELECTED_getInstance() {
    Type_initEntries();
    return Type_SELECTED_instance;
  }
  function Type_DESELECTED_getInstance() {
    Type_initEntries();
    return Type_DESELECTED_instance;
  }
  function SelectionChangeEvent(view, type, components) {
    this.a3d_1 = view;
    this.b3d_1 = type;
    this.c3d_1 = components;
    this.d3d_1 = this.b3d_1.equals(Type_SELECTED_getInstance());
  }
  protoOf(SelectionChangeEvent).toString = function () {
    return 'SelectionChangeEvent(view=' + toString(this.a3d_1) + ', type=' + this.b3d_1.toString() + ', components=' + toString(this.c3d_1) + ')';
  };
  protoOf(SelectionChangeEvent).hashCode = function () {
    var result = hashCode(this.a3d_1);
    result = imul(result, 31) + this.b3d_1.hashCode() | 0;
    result = imul(result, 31) + hashCode(this.c3d_1) | 0;
    return result;
  };
  protoOf(SelectionChangeEvent).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof SelectionChangeEvent))
      return false;
    if (!equals(this.a3d_1, other.a3d_1))
      return false;
    if (!this.b3d_1.equals(other.b3d_1))
      return false;
    if (!equals(this.c3d_1, other.c3d_1))
      return false;
    return true;
  };
  var SelectionDrawingStrategy_ABOVE_instance;
  var SelectionDrawingStrategy_REPLACE_instance;
  var SelectionDrawingStrategy_BELOW_instance;
  var SelectionDrawingStrategy_entriesInitialized;
  function SelectionDrawingStrategy_initEntries() {
    if (SelectionDrawingStrategy_entriesInitialized)
      return Unit_instance;
    SelectionDrawingStrategy_entriesInitialized = true;
    SelectionDrawingStrategy_ABOVE_instance = new SelectionDrawingStrategy('ABOVE', 0);
    SelectionDrawingStrategy_REPLACE_instance = new SelectionDrawingStrategy('REPLACE', 1);
    SelectionDrawingStrategy_BELOW_instance = new SelectionDrawingStrategy('BELOW', 2);
  }
  function SelectionDrawingStrategy(name, ordinal) {
    Enum.call(this, name, ordinal);
  }
  function SelectionDrawingStrategy_ABOVE_getInstance() {
    SelectionDrawingStrategy_initEntries();
    return SelectionDrawingStrategy_ABOVE_instance;
  }
  function SelectionDrawingStrategy_REPLACE_getInstance() {
    SelectionDrawingStrategy_initEntries();
    return SelectionDrawingStrategy_REPLACE_instance;
  }
  function SelectionDrawingStrategy_BELOW_getInstance() {
    SelectionDrawingStrategy_initEntries();
    return SelectionDrawingStrategy_BELOW_instance;
  }
  function SelectionManager() {
  }
  function SnapResult(x, y) {
    x = x === VOID ? 0.0 : x;
    y = y === VOID ? 0.0 : y;
    this.n3d_1 = x;
    this.o3d_1 = y;
    this.p3d_1 = 0.0;
    this.q3d_1 = 0.0;
    this.r3d_1 = false;
    this.s3d_1 = false;
    this.t3d_1 = null;
    this.u3d_1 = null;
    this.v3d_1 = null;
    this.w3d_1 = null;
  }
  protoOf(SnapResult).bu = function () {
    this.n3d_1 = 0.0;
    this.o3d_1 = 0.0;
    this.p3d_1 = 0.0;
    this.q3d_1 = 0.0;
    this.r3d_1 = false;
    this.s3d_1 = false;
    this.t3d_1 = null;
    this.u3d_1 = null;
    this.v3d_1 = null;
    this.w3d_1 = null;
  };
  protoOf(SnapResult).x3d = function (dx, x, snapper) {
    this.p3d_1 = this.p3d_1 + dx;
    this.n3d_1 = x;
    this.t3d_1 = snapper;
    this.r3d_1 = true;
  };
  protoOf(SnapResult).y3d = function (dy, y, snapper) {
    this.q3d_1 = this.q3d_1 + dy;
    this.o3d_1 = y;
    this.u3d_1 = snapper;
    this.s3d_1 = true;
  };
  function Companion() {
    Companion_instance_4 = this;
    var tmp = this;
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    tmp.z3d_1 = [];
    var tmp_0 = this;
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    tmp_0.a3e_1 = [];
  }
  var Companion_instance_4;
  function Companion_getInstance_9() {
    if (Companion_instance_4 == null)
      new Companion();
    return Companion_instance_4;
  }
  function Snappable() {
  }
  function SnappableXCoordinate(x) {
    this.b3e_1 = x;
  }
  protoOf(SnappableXCoordinate).z19 = function () {
    return this.b3e_1;
  };
  protoOf(SnappableXCoordinate).c3e = function (other) {
    return true;
  };
  protoOf(SnappableXCoordinate).toString = function () {
    return 'SnappableXCoordinate(x=' + this.b3e_1 + ')';
  };
  protoOf(SnappableXCoordinate).hashCode = function () {
    return getNumberHashCode(this.b3e_1);
  };
  protoOf(SnappableXCoordinate).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof SnappableXCoordinate))
      return false;
    if (!equals(this.b3e_1, other.b3e_1))
      return false;
    return true;
  };
  function SnappableYCoordinate(y) {
    this.d3e_1 = y;
  }
  protoOf(SnappableYCoordinate).a1a = function () {
    return this.d3e_1;
  };
  protoOf(SnappableYCoordinate).e3e = function (other) {
    return true;
  };
  protoOf(SnappableYCoordinate).toString = function () {
    return 'SnappableYCoordinate(y=' + this.d3e_1 + ')';
  };
  protoOf(SnappableYCoordinate).hashCode = function () {
    return getNumberHashCode(this.d3e_1);
  };
  protoOf(SnappableYCoordinate).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof SnappableYCoordinate))
      return false;
    if (!equals(this.d3e_1, other.d3e_1))
      return false;
    return true;
  };
  function Snapper() {
  }
  function Tool() {
  }
  function DeleteQuestion(components, drawingView) {
    this.x3e_1 = components;
    this.y3e_1 = drawingView;
  }
  protoOf(DeleteQuestion).toString = function () {
    return 'DeleteQuestion(components=' + toString(this.x3e_1) + ', drawingView=' + toString(this.y3e_1) + ')';
  };
  protoOf(DeleteQuestion).hashCode = function () {
    var result = hashCode(this.x3e_1);
    result = imul(result, 31) + hashCode(this.y3e_1) | 0;
    return result;
  };
  protoOf(DeleteQuestion).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof DeleteQuestion))
      return false;
    if (!equals(this.x3e_1, other.x3e_1))
      return false;
    if (!equals(this.y3e_1, other.y3e_1))
      return false;
    return true;
  };
  function DrawingAppService() {
  }
  function Companion_0() {
    Companion_instance_5 = this;
    this.b3f_1 = logger(getKClass(DrawingAppServiceImpl));
  }
  var Companion_instance_5;
  function Companion_getInstance_10() {
    if (Companion_instance_5 == null)
      new Companion_0();
    return Companion_instance_5;
  }
  function DrawingAppServiceImpl(copyPasteService, commandManager, eventBus) {
    Companion_getInstance_10();
    copyPasteService = copyPasteService === VOID ? EditModule_getInstance().h3f_1 : copyPasteService;
    commandManager = commandManager === VOID ? EditModule_getInstance().d3f_1 : commandManager;
    eventBus = eventBus === VOID ? BaseModule_getInstance().zo_1 : eventBus;
    this.l3f_1 = copyPasteService;
    this.m3f_1 = commandManager;
    this.n3f_1 = eventBus;
  }
  protoOf(DrawingAppServiceImpl).o3f = function (component, drawing) {
  };
  protoOf(DrawingAppServiceImpl).z3e = function (movables, offset, editor, register, additionalCommands) {
    // Inline function 'kotlin.collections.map' call
    // Inline function 'kotlin.collections.mapTo' call
    var destination = ArrayList_init_$Create$(collectionSizeOrDefault(movables, 10));
    var _iterator__ex2g4s = movables.i();
    while (_iterator__ex2g4s.j()) {
      var item = _iterator__ex2g4s.k();
      var tmp$ret$2 = item.av();
      destination.h(tmp$ret$2);
    }
    var command = new MoveCommand(editor, toList(destination), offset, additionalCommands);
    if (register) {
      // Inline function 'kotlin.collections.forEach' call
      var _iterator__ex2g4s_0 = additionalCommands.i();
      while (_iterator__ex2g4s_0.j()) {
        var element = _iterator__ex2g4s_0.k();
        element.s39();
      }
      this.m3f_1.e3a(command);
    } else {
      this.m3f_1.d3a(command);
    }
  };
  function _get_userCondition__5rrdq9($this) {
    var tmp = $this.p3f_1;
    if (!(tmp == null))
      return tmp;
    else {
      throwUninitializedPropertyAccessException('userCondition');
    }
  }
  function _get_operation__lk4gty($this) {
    var tmp = $this.q3f_1;
    if (!(tmp == null))
      return tmp;
    else {
      throwUninitializedPropertyAccessException('operation');
    }
  }
  function _get_dataCondition__8uu00w($this) {
    var tmp = $this.r3f_1;
    if (!(tmp == null))
      return tmp;
    else {
      throwUninitializedPropertyAccessException('dataCondition');
    }
  }
  function currentUserCondition$ref() {
    var l = function (p0) {
      return currentUserCondition(p0);
    };
    l.callableName = 'currentUserCondition';
    return l;
  }
  function addAuthorization($this, authorization) {
    $this.s3f_1.h(authorization);
  }
  function AuthorizationBuilder() {
  }
  protoOf(AuthorizationBuilder).t3f = function () {
    var tmp = this;
    tmp.p3f_1 = currentUserCondition$ref();
    return this;
  };
  protoOf(AuthorizationBuilder).u3f = function (operation) {
    this.q3f_1 = operation;
    return this;
  };
  protoOf(AuthorizationBuilder).v3f = function (data) {
    this.r3f_1 = data;
    addAuthorization(Authorizer_getInstance(), new Authorization(_get_userCondition__5rrdq9(this), _get_operation__lk4gty(this), _get_dataCondition__8uu00w(this)));
  };
  function Authorization(userCondition, operation, dataCondition) {
    this.w3f_1 = userCondition;
    this.x3f_1 = operation;
    this.y3f_1 = dataCondition;
  }
  protoOf(Authorization).toString = function () {
    return 'Authorization(userCondition=' + toString(this.w3f_1) + ', operation=' + this.x3f_1.toString() + ', dataCondition=' + toString(this.y3f_1) + ')';
  };
  protoOf(Authorization).hashCode = function () {
    var result = hashCode(this.w3f_1);
    result = imul(result, 31) + this.x3f_1.hashCode() | 0;
    result = imul(result, 31) + hashCode(this.y3f_1) | 0;
    return result;
  };
  protoOf(Authorization).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof Authorization))
      return false;
    if (!equals(this.w3f_1, other.w3f_1))
      return false;
    if (!this.x3f_1.equals(other.x3f_1))
      return false;
    if (!equals(this.y3f_1, other.y3f_1))
      return false;
    return true;
  };
  function Authorizer() {
    Authorizer_instance = this;
    var tmp = this;
    // Inline function 'kotlin.collections.mutableListOf' call
    tmp.s3f_1 = ArrayList_init_$Create$_0();
  }
  protoOf(Authorizer).z3f = function () {
    return new AuthorizationBuilder();
  };
  var Authorizer_instance;
  function Authorizer_getInstance() {
    if (Authorizer_instance == null)
      new Authorizer();
    return Authorizer_instance;
  }
  function currentUserCondition(user) {
    return user.a3g().equals(EditAuthModule_getInstance().d3g().e3g().a3g());
  }
  function DesktopUserHolder(user) {
    this.f3g_1 = user;
  }
  protoOf(DesktopUserHolder).e3g = function () {
    return this.f3g_1;
  };
  function Companion_1() {
    Companion_instance_6 = this;
    this.g3g_1 = new DesktopUser(Companion_getInstance_12().DEVELOPER, 'developer', true);
    this.h3g_1 = new DesktopUser(Companion_getInstance_12().ANYBODY, 'anybody', false);
  }
  var Companion_instance_6;
  function Companion_getInstance_11() {
    if (Companion_instance_6 == null)
      new Companion_1();
    return Companion_instance_6;
  }
  function DesktopUser(identity, name, isDeveloper) {
    Companion_getInstance_11();
    this.i3g_1 = identity;
    this.j3g_1 = name;
    this.k3g_1 = isDeveloper;
  }
  protoOf(DesktopUser).a3g = function () {
    return this.i3g_1;
  };
  protoOf(DesktopUser).toString = function () {
    return 'DesktopUser(identity=' + this.i3g_1.toString() + ', name=' + this.j3g_1 + ', isDeveloper=' + this.k3g_1 + ')';
  };
  protoOf(DesktopUser).hashCode = function () {
    var result = this.i3g_1.hashCode();
    result = imul(result, 31) + getStringHashCode(this.j3g_1) | 0;
    result = imul(result, 31) + getBooleanHashCode(this.k3g_1) | 0;
    return result;
  };
  protoOf(DesktopUser).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof DesktopUser))
      return false;
    if (!this.i3g_1.equals(other.i3g_1))
      return false;
    if (!(this.j3g_1 === other.j3g_1))
      return false;
    if (!(this.k3g_1 === other.k3g_1))
      return false;
    return true;
  };
  function EditAuthModule() {
    EditAuthModule_instance = this;
    AbstractModule.call(this);
  }
  protoOf(EditAuthModule).d3g = function () {
    var tmp = this.c3g_1;
    if (!(tmp == null))
      return tmp;
    else {
      throwUninitializedPropertyAccessException('userHolder');
    }
  };
  protoOf(EditAuthModule).ro = function () {
  };
  var EditAuthModule_instance;
  function EditAuthModule_getInstance() {
    if (EditAuthModule_instance == null)
      new EditAuthModule();
    return EditAuthModule_instance;
  }
  var Operation_View_instance;
  var Operation_Change_instance;
  var Operation_Execute_instance;
  var Operation_entriesInitialized;
  function Operation_initEntries() {
    if (Operation_entriesInitialized)
      return Unit_instance;
    Operation_entriesInitialized = true;
    Operation_View_instance = new Operation('View', 0);
    Operation_Change_instance = new Operation('Change', 1);
    Operation_Execute_instance = new Operation('Execute', 2);
  }
  function Operation(name, ordinal) {
    Enum.call(this, name, ordinal);
  }
  function Operation_View_getInstance() {
    Operation_initEntries();
    return Operation_View_instance;
  }
  function Operation_Change_getInstance() {
    Operation_initEntries();
    return Operation_Change_instance;
  }
  function Companion_2() {
    Companion_instance_7 = this;
    this.DEVELOPER = new UserIdentity('5ecf330b-e395-4e17-88b0-0883834b384a');
    this.ANYBODY = new UserIdentity('7e840175-f9c4-4886-a221-ef91e3493e27');
  }
  protoOf(Companion_2).l3g = function () {
    return this.DEVELOPER;
  };
  protoOf(Companion_2).m3g = function () {
    return this.ANYBODY;
  };
  protoOf(Companion_2).random = function () {
    return new UserIdentity(System_getInstance().bm(null).toString());
  };
  protoOf(Companion_2).n3g = function () {
    return $serializer_getInstance();
  };
  var Companion_instance_7;
  function Companion_getInstance_12() {
    if (Companion_instance_7 == null)
      new Companion_2();
    return Companion_instance_7;
  }
  function $serializer() {
    $serializer_instance = this;
    var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('io.antarescircuit.jabbah.edit.auth.UserIdentity', this, 1);
    tmp0_serialDesc.al('id', false);
    this.o3g_1 = tmp0_serialDesc;
  }
  protoOf($serializer).vj = function () {
    return this.o3g_1;
  };
  protoOf($serializer).xk = function () {
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [StringSerializer_getInstance()];
  };
  var $serializer_instance;
  function $serializer_getInstance() {
    if ($serializer_instance == null)
      new $serializer();
    return $serializer_instance;
  }
  function UserIdentity(id) {
    Companion_getInstance_12();
    this.id = id;
  }
  protoOf(UserIdentity).av = function () {
    return this.id;
  };
  protoOf(UserIdentity).toString = function () {
    return this.id;
  };
  protoOf(UserIdentity).xd = function () {
    return this.id;
  };
  protoOf(UserIdentity).bv = function (id) {
    return new UserIdentity(id);
  };
  protoOf(UserIdentity).copy = function (id, $super) {
    id = id === VOID ? this.id : id;
    return $super === VOID ? this.bv(id) : $super.bv.call(this, id);
  };
  protoOf(UserIdentity).hashCode = function () {
    return getStringHashCode(this.id);
  };
  protoOf(UserIdentity).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof UserIdentity))
      return false;
    if (!(this.id === other.id))
      return false;
    return true;
  };
  function _get_tags__de2s7m($this) {
    var tmp0 = $this.r3g_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('tags', 1, tmp, AbstractCommand$_get_tags_$ref_c6j3vo(), null);
    return tmp0.j2();
  }
  function AbstractCommand$tags$delegate$lambda() {
    // Inline function 'kotlin.collections.mutableSetOf' call
    return LinkedHashSet_init_$Create$();
  }
  function AbstractCommand$_get_tags_$ref_c6j3vo() {
    return function (p0) {
      return _get_tags__de2s7m(p0);
    };
  }
  function AbstractCommand(descriptionKey, editor) {
    editor = editor === VOID ? null : editor;
    this.p3g_1 = editor;
    this.q3g_1 = Translations_getInstance().zm(descriptionKey, []);
    var tmp = this;
    tmp.r3g_1 = lazy(AbstractCommand$tags$delegate$lambda);
  }
  protoOf(AbstractCommand).q39 = function () {
    return this.q3g_1;
  };
  protoOf(AbstractCommand).u1z = function () {
    var tmp0_safe_receiver = this.p3g_1;
    var tmp1_safe_receiver = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.e3b();
    if (tmp1_safe_receiver == null)
      null;
    else {
      tmp1_safe_receiver.u1z();
    }
  };
  protoOf(AbstractCommand).t39 = function (names) {
    addAll(_get_tags__de2s7m(this), names);
  };
  function AbstractDrawingViewCommand(descriptionKey, view) {
    AbstractCommand.call(this, descriptionKey);
    this.v3g_1 = view;
  }
  protoOf(AbstractDrawingViewCommand).u1z = function () {
    this.v3g_1.e3b().u1z();
  };
  function _get_LOG__e5r759($this) {
    var tmp0 = $this.w3g_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('LOG', 1, tmp, Snapshot$Companion$_get_LOG_$ref_mr21gk(), null);
    return tmp0.j2();
  }
  function Snapshot$Companion$_get_LOG_$ref_mr21gk() {
    return function (p0) {
      return _get_LOG__e5r759(p0);
    };
  }
  function Companion_3() {
    Companion_instance_8 = this;
    this.w3g_1 = logger(getKClass(Snapshot));
  }
  var Companion_instance_8;
  function Companion_getInstance_13() {
    if (Companion_instance_8 == null)
      new Companion_3();
    return Companion_instance_8;
  }
  function replayFromSnapshot($this) {
    var undoStackWriter = new TransactionStackWriter('Undo stack');
    try {
      var clonedData = StorableCloner_getInstance().c36($this.x3g_1);
      _get_LOG__e5r759(Companion_getInstance_13()).ol('Clone snapshot and set as new undoable data ' + toString(clonedData));
      $this.y3g_1.b3h(clonedData);
      _get_LOG__e5r759(Companion_getInstance_13()).ol('Replaying');
      // Inline function 'kotlin.collections.forEach' call
      var _iterator__ex2g4s = $this.z3g_1.tv_1.i();
      while (_iterator__ex2g4s.j()) {
        var element = _iterator__ex2g4s.k();
        _get_LOG__e5r759(Companion_getInstance_13()).ol('.. replaying transaction ' + element.d3h().q39());
        element.s39();
        undoStackWriter.f3h(element);
      }
      $this.y3g_1.g3h(clonedData);
    } catch ($p) {
      if ($p instanceof Error) {
        var e = $p;
        _get_LOG__e5r759(Companion_getInstance_13()).jl('Error in replaying snapshot for undo', e);
        _get_LOG__e5r759(Companion_getInstance_13()).kl(undoStackWriter.toString());
        _get_LOG__e5r759(Companion_getInstance_13()).il(undoStackWriter.toString());
        throw e;
      } else {
        throw $p;
      }
    }
  }
  function Snapshot(data, undoableDataHolder) {
    Companion_getInstance_13();
    this.x3g_1 = data;
    this.y3g_1 = undoableDataHolder;
    this.z3g_1 = new Stack();
    this.a3h_1 = new Stack();
  }
  protoOf(Snapshot).h3h = function () {
    return this.z3g_1.o();
  };
  protoOf(Snapshot).es = function () {
    var tmp = this.x3g_1;
    if (isInterface(tmp, Disposable)) {
      this.x3g_1.es();
    }
  };
  protoOf(Snapshot).i3h = function (transaction) {
    this.z3g_1.wv(transaction);
  };
  protoOf(Snapshot).j3h = function (forRedo) {
    var transaction = this.z3g_1.xv();
    transaction.u39();
    if (forRedo) {
      this.a3h_1.wv(transaction);
    }
    if (transaction.v39()) {
      transaction.w39();
    } else {
      replayFromSnapshot(this);
    }
  };
  protoOf(Snapshot).k3h = function () {
    this.a3h_1.a2();
  };
  function _get_LOG__e5r759_0($this) {
    var tmp0 = $this.l3h_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('LOG', 1, tmp, SourcingCommandManager$Companion$_get_LOG_$ref_ehtvpi(), null);
    return tmp0.j2();
  }
  function SourcingCommandManager$Companion$_get_LOG_$ref_ehtvpi() {
    return function (p0) {
      return _get_LOG__e5r759_0(p0);
    };
  }
  function nextFromCommandIterator($this) {
    var tmp0_safe_receiver = $this.s3h_1;
    if ((tmp0_safe_receiver == null ? null : tmp0_safe_receiver.j()) === true) {
      $this.mc(ensureNotNull($this.s3h_1).k());
      return true;
    }
    return false;
  }
  function nextFromTransactionIterator($this) {
    var tmp0_safe_receiver = $this.r3h_1;
    if ((tmp0_safe_receiver == null ? null : tmp0_safe_receiver.j()) === true) {
      $this.s3h_1 = ensureNotNull($this.r3h_1).k().c3h_1.i();
      if (nextFromCommandIterator($this)) {
        return true;
      }
    }
    return false;
  }
  function nextFromSnapshotIterator($this) {
    if ($this.q3h_1.j()) {
      $this.r3h_1 = $this.q3h_1.k().z3g_1.tv_1.i();
      if (nextFromTransactionIterator($this)) {
        return true;
      }
    }
    return false;
  }
  function Companion_4() {
    Companion_instance_9 = this;
    this.l3h_1 = logger(getKClass(SourcingCommandManager));
    this.m3h_1 = 'edit.commandManager.cmdPerSnapshot';
    this.n3h_1 = 'default';
  }
  var Companion_instance_9;
  function Companion_getInstance_14() {
    if (Companion_instance_9 == null)
      new Companion_4();
    return Companion_instance_9;
  }
  function _get_maxCommandCountPerSnapshot__1yc9wu($this) {
    return $this.v3h_1.it('edit.commandManager.cmdPerSnapshot');
  }
  function _get_maxSnapshotSizeReached__jf518i($this) {
    return !_get_state__b8zcm8($this).a3i_1.uv() && _get_state__b8zcm8($this).a3i_1.pv().h3h() >= _get_maxCommandCountPerSnapshot__1yc9wu($this);
  }
  function _get_state__b8zcm8($this) {
    return $this.w3h_1.pv();
  }
  function CommandIterator($outer) {
    this.t3h_1 = $outer;
    AbstractIterator.call(this);
    this.q3h_1 = _get_state__b8zcm8(this.t3h_1).a3i_1.tv_1.i();
    var tmp = this;
    var tmp_0;
    if (this.q3h_1.j()) {
      tmp_0 = this.q3h_1.k().z3g_1.tv_1.i();
    } else {
      tmp_0 = null;
    }
    tmp.r3h_1 = tmp_0;
    var tmp_1 = this;
    var tmp_2;
    var tmp0_safe_receiver = this.r3h_1;
    if ((tmp0_safe_receiver == null ? null : tmp0_safe_receiver.j()) === true) {
      tmp_2 = ensureNotNull(this.r3h_1).k().c3h_1.i();
    } else {
      tmp_2 = null;
    }
    tmp_1.s3h_1 = tmp_2;
  }
  protoOf(CommandIterator).lc = function () {
    if (nextFromCommandIterator(this)) {
      return Unit_instance;
    }
    if (nextFromTransactionIterator(this)) {
      return Unit_instance;
    }
    if (nextFromSnapshotIterator(this)) {
      return Unit_instance;
    }
    this.nc();
  };
  function tryCommandExecution($this, command) {
    try {
      command.s39();
    } catch ($p) {
      if ($p instanceof Error) {
        var e = $p;
        if (!(command instanceof AbstractPropertyCommand)) {
          _get_LOG__e5r759_0(Companion_getInstance_14()).kl('Exception in command execution: ' + e.message);
        }
        $this.g3a();
        throw e;
      } else {
        throw $p;
      }
    }
  }
  function transferUndoneSnapshotIfNecessary($this, storeForRedo) {
    var snapshot = _get_state__b8zcm8($this).a3i_1.pv();
    if (snapshot.z3g_1.uv() && _get_state__b8zcm8($this).a3i_1.o() > 1) {
      _get_state__b8zcm8($this).a3i_1.xv();
      if (storeForRedo) {
        _get_state__b8zcm8($this).b3i_1.wv(snapshot);
      }
    }
    if (_get_state__b8zcm8($this).a3i_1.uv()) {
      $this.f3i();
    }
  }
  function beginTransactionImpl($this, command, register, allowNewSnapshot) {
    _get_LOG__e5r759_0(Companion_getInstance_14()).ol("Begin transaction for '" + command.q39() + "'");
    if (_get_state__b8zcm8($this).c3i_1 == null) {
      _get_state__b8zcm8($this).c3i_1 = new Transaction();
      if (allowNewSnapshot && !register) {
        addableSnapshot($this).i3h(ensureNotNull(_get_state__b8zcm8($this).c3i_1));
      } else {
        _get_state__b8zcm8($this).a3i_1.pv().i3h(ensureNotNull(_get_state__b8zcm8($this).c3i_1));
      }
    }
    var _receiver__tnumb7 = _get_state__b8zcm8($this);
    _receiver__tnumb7.d3i_1 = _receiver__tnumb7.d3i_1 + 1 | 0;
    var tmp0_safe_receiver = _get_state__b8zcm8($this).c3i_1;
    if (tmp0_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      // Inline function 'kotlin.collections.toTypedArray' call
      var this_0 = _get_state__b8zcm8($this).e3i_1;
      var tmp$ret$2 = copyToArray(this_0);
      command.t39(tmp$ret$2.slice());
      tmp0_safe_receiver.g3i(command);
      if (!register) {
        tryCommandExecution($this, command);
        command.u1z();
      }
    }
  }
  function resetRedo($this) {
    if (!_get_state__b8zcm8($this).a3i_1.uv()) {
      _get_state__b8zcm8($this).a3i_1.pv().k3h();
    }
    _get_state__b8zcm8($this).b3i_1.a2();
  }
  function addableSnapshot($this) {
    if (_get_state__b8zcm8($this).a3i_1.uv() || _get_maxSnapshotSizeReached__jf518i($this)) {
      if (_get_maxSnapshotSizeReached__jf518i($this)) {
        _get_LOG__e5r759_0(Companion_getInstance_14()).il('Max snapshot size ' + _get_maxCommandCountPerSnapshot__1yc9wu($this) + ' reached. Create new snapshot.');
      }
      $this.f3i();
    }
    return _get_state__b8zcm8($this).a3i_1.pv();
  }
  function createSnapshotData($this) {
    _get_LOG__e5r759_0(Companion_getInstance_14()).ol('Create new snapshot');
    return StorableCloner_getInstance().c36(ensureNotNull(_get_state__b8zcm8($this).z3h_1.h3i()));
  }
  function SourcingCommandManager(eventBus, properties) {
    Companion_getInstance_14();
    eventBus = eventBus === VOID ? BaseModule_getInstance().zo_1 : eventBus;
    properties = properties === VOID ? BaseModule_getInstance().xo_1 : properties;
    this.u3h_1 = eventBus;
    this.v3h_1 = properties;
    this.w3h_1 = new Stack();
    this.x3h_1 = true;
  }
  protoOf(SourcingCommandManager).i = function () {
    return new CommandIterator(this);
  };
  protoOf(SourcingCommandManager).x39 = function (value) {
    if (!(value === this.x3h_1)) {
      this.x3h_1 = value;
      this.u3h_1.eu(new CommandManagerActiveEvent(this));
    }
  };
  protoOf(SourcingCommandManager).y39 = function () {
    return this.x3h_1;
  };
  protoOf(SourcingCommandManager).z39 = function () {
    return !(_get_state__b8zcm8(this).c3i_1 == null);
  };
  protoOf(SourcingCommandManager).e3a = function (command) {
    _get_LOG__e5r759_0(Companion_getInstance_14()).ol("Register command '" + command.q39() + "'");
    resetRedo(this);
    if (_get_state__b8zcm8(this).c3i_1 == null) {
      beginTransactionImpl(this, command, true, true);
      this.f3a();
    } else {
      // Inline function 'kotlin.collections.toTypedArray' call
      var this_0 = _get_state__b8zcm8(this).e3i_1;
      var tmp$ret$0 = copyToArray(this_0);
      command.t39(tmp$ret$0.slice());
      ensureNotNull(_get_state__b8zcm8(this).c3i_1).g3i(command);
      command.u1z();
    }
  };
  protoOf(SourcingCommandManager).d3a = function (command) {
    _get_LOG__e5r759_0(Companion_getInstance_14()).ol("Execute command '" + command.q39() + "'");
    resetRedo(this);
    if (_get_state__b8zcm8(this).c3i_1 == null) {
      beginTransactionImpl(this, command, false, true);
      this.f3a();
    } else {
      // Inline function 'kotlin.collections.toTypedArray' call
      var this_0 = _get_state__b8zcm8(this).e3i_1;
      var tmp$ret$0 = copyToArray(this_0);
      command.t39(tmp$ret$0.slice());
      ensureNotNull(_get_state__b8zcm8(this).c3i_1).g3i(command);
      tryCommandExecution(this, command);
      command.u1z();
    }
  };
  protoOf(SourcingCommandManager).a3a = function (command, register) {
    beginTransactionImpl(this, command, register, false);
  };
  protoOf(SourcingCommandManager).c3a = function (descriptionKey, drawingView) {
    this.a3a(new TransactionCommand(descriptionKey, drawingView), true);
  };
  protoOf(SourcingCommandManager).f3a = function () {
    if (_get_state__b8zcm8(this).c3i_1 == null) {
      throw IllegalStateException_init_$Create$('no transaction to commit');
    }
    var _receiver__tnumb7 = _get_state__b8zcm8(this);
    _receiver__tnumb7.d3i_1 = _receiver__tnumb7.d3i_1 - 1 | 0;
    if (_get_state__b8zcm8(this).d3i_1 === 0) {
      _get_LOG__e5r759_0(Companion_getInstance_14()).ol('Commit transaction');
      resetRedo(this);
      this.u3h_1.eu(new CommandEvent(this, CommandEventType_COMMIT_TRANSACTION_getInstance()));
      _get_state__b8zcm8(this).c3i_1 = null;
    }
  };
  protoOf(SourcingCommandManager).g3a = function () {
    if (_get_state__b8zcm8(this).c3i_1 == null) {
      throw IllegalStateException_init_$Create$('no transaction to rollback');
    }
    _get_LOG__e5r759_0(Companion_getInstance_14()).nl('Rollback transaction');
    try {
      _get_state__b8zcm8(this).a3i_1.pv().j3h(false);
    } catch ($p) {
      if ($p instanceof Error) {
        var e = $p;
        _get_LOG__e5r759_0(Companion_getInstance_14()).jl('Error in undo during rollbackTransaction', e);
        throw e;
      } else {
        throw $p;
      }
    }
    finally {
      transferUndoneSnapshotIfNecessary(this, false);
      _get_state__b8zcm8(this).d3i_1 = 0;
      _get_state__b8zcm8(this).c3i_1 = null;
    }
  };
  protoOf(SourcingCommandManager).f3i = function () {
    _get_state__b8zcm8(this).a3i_1.wv(new Snapshot(createSnapshotData(this), _get_state__b8zcm8(this).z3h_1));
  };
  function _get_LOG__e5r759_1($this) {
    var tmp0 = $this.i3i_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('LOG', 1, tmp, Transaction$Companion$_get_LOG_$ref_knacsi(), null);
    return tmp0.j2();
  }
  function Transaction$Companion$_get_LOG_$ref_knacsi() {
    return function (p0) {
      return _get_LOG__e5r759_1(p0);
    };
  }
  function Companion_5() {
    Companion_instance_10 = this;
    this.i3i_1 = logger(getKClass(Transaction));
  }
  var Companion_instance_10;
  function Companion_getInstance_15() {
    if (Companion_instance_10 == null)
      new Companion_5();
    return Companion_instance_10;
  }
  function Transaction() {
    Companion_getInstance_15();
    var tmp = this;
    // Inline function 'kotlin.collections.mutableListOf' call
    tmp.c3h_1 = ArrayList_init_$Create$_0();
  }
  protoOf(Transaction).d3h = function () {
    return first(this.c3h_1);
  };
  protoOf(Transaction).v39 = function () {
    var tmp0 = this.c3h_1;
    var tmp$ret$0;
    $l$block_0: {
      // Inline function 'kotlin.collections.all' call
      var tmp;
      if (isInterface(tmp0, Collection)) {
        tmp = tmp0.m();
      } else {
        tmp = false;
      }
      if (tmp) {
        tmp$ret$0 = true;
        break $l$block_0;
      }
      var _iterator__ex2g4s = tmp0.i();
      while (_iterator__ex2g4s.j()) {
        var element = _iterator__ex2g4s.k();
        var tmp_0;
        if (isInterface(element, Undoable)) {
          tmp_0 = element.v39();
        } else {
          tmp_0 = false;
        }
        if (!tmp_0) {
          tmp$ret$0 = false;
          break $l$block_0;
        }
      }
      tmp$ret$0 = true;
    }
    return tmp$ret$0;
  };
  protoOf(Transaction).g3i = function (command) {
    this.c3h_1.h(command);
  };
  protoOf(Transaction).s39 = function () {
    var _iterator__ex2g4s = this.c3h_1.i();
    while (_iterator__ex2g4s.j()) {
      var c = _iterator__ex2g4s.k();
      c.s39();
      c.u1z();
    }
  };
  protoOf(Transaction).w39 = function () {
    // Inline function 'kotlin.check' call
    if (!this.v39()) {
      var message = 'Cannot undo Transaction';
      throw IllegalStateException_init_$Create$(toString(message));
    }
    try {
      // Inline function 'kotlin.collections.forEach' call
      var _iterator__ex2g4s = reversed(this.c3h_1).i();
      while (_iterator__ex2g4s.j()) {
        var element = _iterator__ex2g4s.k();
        (isInterface(element, Undoable) ? element : THROW_CCE()).w39();
        element.u1z();
      }
    } catch ($p) {
      if ($p instanceof Error) {
        var e = $p;
        _get_LOG__e5r759_1(Companion_getInstance_15()).jl('Error in undoing Transaction', e);
        throw e;
      } else {
        throw $p;
      }
    }
  };
  protoOf(Transaction).u39 = function () {
    // Inline function 'kotlin.collections.filter' call
    var tmp0 = this.c3h_1;
    // Inline function 'kotlin.collections.filterTo' call
    var destination = ArrayList_init_$Create$_0();
    var _iterator__ex2g4s = tmp0.i();
    while (_iterator__ex2g4s.j()) {
      var element = _iterator__ex2g4s.k();
      if (!isInterface(element, Undoable)) {
        destination.h(element);
      }
    }
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s_0 = reversed(destination).i();
    while (_iterator__ex2g4s_0.j()) {
      var element_0 = _iterator__ex2g4s_0.k();
      element_0.u39();
    }
  };
  function TransactionCommand(descriptionKey, drawingView) {
    drawingView = drawingView === VOID ? null : drawingView;
    AbstractCommand.call(this, descriptionKey, null);
    this.m3i_1 = drawingView;
  }
  protoOf(TransactionCommand).s39 = function () {
  };
  protoOf(TransactionCommand).w39 = function () {
  };
  protoOf(TransactionCommand).u1z = function () {
    var tmp0_safe_receiver = this.m3i_1;
    var tmp1_safe_receiver = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.e3b();
    if (tmp1_safe_receiver == null)
      null;
    else {
      tmp1_safe_receiver.u1z();
    }
  };
  function writeTransaction($this, transaction, out) {
    // Inline function 'kotlin.text.appendLine' call
    var value = '# Transaction';
    // Inline function 'kotlin.text.appendLine' call
    out.h7(value).i7(_Char___init__impl__6a9atx(10));
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = transaction.c3h_1.i();
    while (_iterator__ex2g4s.j()) {
      var element = _iterator__ex2g4s.k();
      writeCommand($this, element, out);
    }
  }
  function writeCommand($this, command, out) {
    out.h7('-- ');
    // Inline function 'kotlin.text.appendLine' call
    var value = command.r39();
    // Inline function 'kotlin.text.appendLine' call
    out.h7(value).i7(_Char___init__impl__6a9atx(10));
  }
  function TransactionStackWriter(title) {
    this.e3h_1 = StringBuilder_init_$Create$();
    // Inline function 'kotlin.text.appendLine' call
    // Inline function 'kotlin.text.appendLine' call
    this.e3h_1.h7(title).i7(_Char___init__impl__6a9atx(10));
  }
  protoOf(TransactionStackWriter).f3h = function (transaction) {
    writeTransaction(this, transaction, this.e3h_1);
  };
  protoOf(TransactionStackWriter).toString = function () {
    return this.e3h_1.toString();
  };
  function DropEvent(editor, component) {
    this.n3i_1 = editor;
    this.o3i_1 = component;
  }
  protoOf(DropEvent).toString = function () {
    return 'DropEvent(editor=' + toString(this.n3i_1) + ', component=' + toString(this.o3i_1) + ')';
  };
  protoOf(DropEvent).hashCode = function () {
    var result = hashCode(this.n3i_1);
    result = imul(result, 31) + hashCode(this.o3i_1) | 0;
    return result;
  };
  protoOf(DropEvent).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof DropEvent))
      return false;
    if (!equals(this.n3i_1, other.n3i_1))
      return false;
    if (!equals(this.o3i_1, other.o3i_1))
      return false;
    return true;
  };
  function DragDestination() {
  }
  function DragDestinationHighlightFactoryRegistry() {
    var tmp = this;
    // Inline function 'kotlin.collections.mutableMapOf' call
    tmp.q3i_1 = LinkedHashMap_init_$Create$();
  }
  protoOf(DragDestinationHighlightFactoryRegistry).r3i = function (destinationClass, factory) {
    var tmp0 = this.q3i_1;
    // Inline function 'kotlin.collections.set' call
    var key = System_getInstance().vl(destinationClass);
    tmp0.y1(key, factory);
  };
  protoOf(DragDestinationHighlightFactoryRegistry).s3i = function (destination) {
    var tmp = this.q3i_1.g2(System_getInstance().wl(destination));
    var tmp0_safe_receiver = (tmp == null ? true : isInterface(tmp, DragDestinationHighlightFactory)) ? tmp : THROW_CCE();
    return tmp0_safe_receiver == null ? null : tmp0_safe_receiver.t3i(destination);
  };
  function DragDestinationHighlightFactory() {
  }
  function addHighlightIfAny($this, drawingView, destination) {
    var tmp0_safe_receiver = createHighlight($this, destination);
    if (tmp0_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      DragDestinationHighlighter_instance.v3i_1 = tmp0_safe_receiver;
      DragDestinationHighlighter_instance.u3i_1 = destination;
      drawingView.j3b().l20(tmp0_safe_receiver);
      tmp0_safe_receiver.u1z();
    }
  }
  function removeHighlight($this, drawingView) {
    if (!($this.v3i_1 == null)) {
      drawingView.j3b().m20(ensureNotNull($this.v3i_1));
      drawingView.e3b().u1z();
      $this.v3i_1 = null;
    }
  }
  function createHighlight($this, destination) {
    return EditDragModule_getInstance().x3i_1.s3i(destination);
  }
  function DragDestinationHighlighter() {
    this.u3i_1 = null;
    this.v3i_1 = null;
  }
  protoOf(DragDestinationHighlighter).z3a = function (editor, component, destination) {
    var tmp;
    var tmp_0;
    if (!(destination == null)) {
      tmp_0 = isInterface(destination, DragDestination);
    } else {
      tmp_0 = false;
    }
    if (tmp_0) {
      tmp = destination.p3i(component);
    } else {
      tmp = false;
    }
    if (tmp) {
      if (this.v3i_1 == null) {
        addHighlightIfAny(this, editor.f1o(), destination);
      } else {
        if (!equals(this.u3i_1, destination)) {
          removeHighlight(this, editor.f1o());
          addHighlightIfAny(this, editor.f1o(), destination);
        }
      }
      var tmp0_safe_receiver = this.v3i_1;
      if (tmp0_safe_receiver == null)
        null;
      else {
        tmp0_safe_receiver.y3i(component, destination);
      }
    } else {
      removeHighlight(this, editor.f1o());
    }
  };
  protoOf(DragDestinationHighlighter).z3i = function (editor, component) {
    this.z3a(editor, component, null);
  };
  protoOf(DragDestinationHighlighter).a3j = function (editor, component) {
    return emptySet();
  };
  protoOf(DragDestinationHighlighter).b3j = function (editor) {
    removeHighlight(this, editor.f1o());
  };
  var DragDestinationHighlighter_instance;
  function DragDestinationHighlighter_getInstance() {
    return DragDestinationHighlighter_instance;
  }
  function _get_LOG__e5r759_2($this) {
    var tmp0 = $this.c3j_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('LOG', 1, tmp, DragManagerImpl$Companion$_get_LOG_$ref_9hucft(), null);
    return tmp0.j2();
  }
  function DragManagerImpl$Companion$_get_LOG_$ref_9hucft() {
    return function (p0) {
      return _get_LOG__e5r759_2(p0);
    };
  }
  function Companion_6() {
    Companion_instance_11 = this;
    this.c3j_1 = logger(getKClass(DragManagerImpl));
  }
  var Companion_instance_11;
  function Companion_getInstance_16() {
    if (Companion_instance_11 == null)
      new Companion_6();
    return Companion_instance_11;
  }
  function drag($this, components, x, y, orthogonal, doSnap) {
    if (components.m() || $this.i3j_1 == null) {
      return Unit_instance;
    }
    var dx = x - $this.k3j_1.in_1;
    var dy = y - $this.k3j_1.jn_1;
    if (orthogonal) {
      // Inline function 'kotlin.math.abs' call
      var x_0 = dx;
      var tmp = Math.abs(x_0);
      // Inline function 'kotlin.math.abs' call
      var x_1 = dy;
      if (tmp >= Math.abs(x_1)) {
        dy = 0.0;
      } else {
        dx = 0.0;
      }
    }
    var tmp_0 = $this;
    var tmp0 = $this.n3j_1;
    // Inline function 'kotlin.math.max' call
    var b = numberToInt($this.k3j_1.o1g($this.j3j_1.in_1 + dx, $this.j3j_1.jn_1 + dy));
    tmp_0.n3j_1 = Math.max(tmp0, b);
    var delta = (new Point2D($this.j3j_1.in_1 + dx, $this.j3j_1.jn_1 + dy)).t1g(ensureNotNull($this.i3j_1).hw());
    var snap = Companion_getInstance().g1a_1;
    if (doSnap && $this.e3j_1.j3c().q3j()) {
      if (components.o() > 1) {
        if ($this.m3j_1 == null) {
          $this.m3j_1 = new MultiComponentSnappable(components);
        }
        snap = $this.e3j_1.j3c().p3j(ensureNotNull($this.m3j_1), delta.in_1, delta.jn_1);
      } else if (components.o() === 1) {
        snap = $this.e3j_1.j3c().p3j(first_0(components), delta.in_1, delta.jn_1);
      }
    }
    Companion_instance.s2h(components, delta.in_1 + snap.in_1, delta.jn_1 + snap.jn_1);
    $this.l3j_1 = new Point2D(x + snap.in_1, y + snap.jn_1);
  }
  function involvePluginsDragged($this, component) {
    var destination = null;
    if ($this.h3j_1) {
      var tmp = $this.e3j_1.e3b();
      var tmp_0 = component.do();
      destination = tmp.q20(tmp_0, DragManagerImpl$involvePluginsDragged$lambda(component));
    }
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = $this.g3j_1.i();
    while (_iterator__ex2g4s.j()) {
      var element = _iterator__ex2g4s.k();
      if (isInterface(element, DragManagerDestinationPlugin)) {
        element.z3a($this.e3j_1, component, destination);
      } else {
        element.z3i($this.e3j_1, component);
      }
    }
  }
  function involvePluginsDragFinished($this, component) {
    // Inline function 'kotlin.collections.mutableListOf' call
    var commands = ArrayList_init_$Create$_0();
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = $this.g3j_1.i();
    while (_iterator__ex2g4s.j()) {
      var element = _iterator__ex2g4s.k();
      commands.f1(element.a3j($this.e3j_1, component));
    }
    return commands;
  }
  function involvePluginsDragTerminated($this) {
    $this.m3j_1 = null;
    $this.i3j_1 = null;
    $this.o3j_1 = null;
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = $this.g3j_1.i();
    while (_iterator__ex2g4s.j()) {
      var element = _iterator__ex2g4s.k();
      element.b3j($this.e3j_1);
    }
  }
  function logMove($this, action, offset, additionalCommandsCount) {
    var selection = $this.e3j_1.f1o().f3b().f3d();
    if (selection.o() === 1) {
      _get_LOG__e5r759_2(Companion_getInstance_16()).il("Move component '" + first_0(selection).u19() + "' with ID " + first_0(selection).av() + ' with ' + action + ' by ' + offset.toString() + ', ' + additionalCommandsCount + ' additional commands');
    } else {
      _get_LOG__e5r759_2(Companion_getInstance_16()).il('Move ' + selection.o() + ' components by ' + action);
    }
  }
  function getKeyMoveDirection($this, event) {
    var tmp0_subject = event.i2();
    var tmp;
    if (tmp0_subject === Companion_instance_0.z17_1) {
      tmp = Direction_EAST_getInstance();
    } else if (tmp0_subject === Companion_instance_0.y17_1) {
      tmp = Direction_WEST_getInstance();
    } else if (tmp0_subject === Companion_instance_0.a18_1) {
      tmp = Direction_NORTH_getInstance();
    } else if (tmp0_subject === Companion_instance_0.b18_1) {
      tmp = Direction_SOUTH_getInstance();
    } else {
      throw IllegalArgumentException_init_$Create$("KeyEvent doesn't represent a move direction");
    }
    return tmp;
  }
  function DragManagerImpl$involvePluginsDragged$lambda($component) {
    return function (it) {
      return !(it === $component);
    };
  }
  function DragManagerImpl(editor, drawingAppService, plugins) {
    Companion_getInstance_16();
    drawingAppService = drawingAppService === VOID ? EditModule_getInstance().j3f_1 : drawingAppService;
    plugins = plugins === VOID ? emptySet() : plugins;
    InputEventHandlerAdapter.call(this);
    this.e3j_1 = editor;
    this.f3j_1 = drawingAppService;
    var tmp = this;
    // Inline function 'kotlin.collections.mutableSetOf' call
    tmp.g3j_1 = LinkedHashSet_init_$Create$();
    this.h3j_1 = false;
    this.i3j_1 = null;
    this.j3j_1 = Companion_getInstance().g1a_1;
    this.k3j_1 = Companion_getInstance().g1a_1;
    this.l3j_1 = Companion_getInstance().g1a_1;
    this.m3j_1 = null;
    this.n3j_1 = 0;
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = plugins.i();
    while (_iterator__ex2g4s.j()) {
      var element = _iterator__ex2g4s.k();
      this.r3j(element);
    }
    this.o3j_1 = null;
  }
  protoOf(DragManagerImpl).r3j = function (plugin) {
    this.g3j_1.h(plugin);
    this.h3j_1 = true;
  };
  protoOf(DragManagerImpl).s3j = function (component, x, y) {
    if (!component.q3a()) {
      this.i3j_1 = component;
      this.j3j_1 = Point2D_init_$Create$(ensureNotNull(this.i3j_1).hw());
      this.l3j_1 = new Point2D(x, y);
      this.k3j_1 = new Point2D(x, y);
      this.n3j_1 = 0;
    }
  };
  protoOf(DragManagerImpl).t3j = function (context) {
    var selection = this.e3j_1.f1o().f3b().f3d();
    if (selection.o() === 1 && first_0(selection).q3a()) {
      return null;
    }
    var tmp0_safe_receiver = context.y21_1;
    var tmp = (tmp0_safe_receiver == null ? null : tmp0_safe_receiver.isShiftDown) === true;
    var tmp1_safe_receiver = context.y21_1;
    drag(this, selection, context.a22_1, context.b22_1, tmp, !((tmp1_safe_receiver == null ? null : tmp1_safe_receiver.isAltDown) === true));
    if (selection.o() === 1) {
      involvePluginsDragged(this, first_0(selection));
    }
    this.e3j_1.e3b().u1z();
    return null;
  };
  protoOf(DragManagerImpl).l22 = function (context) {
    return this.t3j(context instanceof InputEventContext ? context : THROW_CCE());
  };
  protoOf(DragManagerImpl).u3j = function (context) {
    if (!(this.i3j_1 == null)) {
      var selection = this.e3j_1.f1o().f3b().f3d();
      if (selection.o() === 1 && first_0(selection).q3a()) {
        return null;
      }
      var tmp;
      if (selection.o() === 1 && this.n3j_1 > 0) {
        tmp = involvePluginsDragFinished(this, first_0(selection));
      } else {
        tmp = emptyList();
      }
      var additionalCommands = tmp;
      var tmp_0;
      // Inline function 'kotlin.collections.isNotEmpty' call
      if (!additionalCommands.m()) {
        tmp_0 = true;
      } else {
        var tmp_1 = this.j3j_1;
        var tmp0_safe_receiver = this.i3j_1;
        tmp_0 = !tmp_1.equals(tmp0_safe_receiver == null ? null : tmp0_safe_receiver.hw());
      }
      if (tmp_0) {
        try {
          var offset = ensureNotNull(this.i3j_1).hw().t1g(this.j3j_1);
          logMove(this, 'mouse', offset, additionalCommands.o());
          this.f3j_1.z3e(selection, offset, this.e3j_1, true, additionalCommands);
        } catch ($p) {
          if ($p instanceof Error) {
            var e = $p;
            _get_LOG__e5r759_2(Companion_getInstance_16()).kl("mouseReleased: error '" + e.message + "'");
            throw e;
          } else {
            throw $p;
          }
        }
      }
    }
    involvePluginsDragTerminated(this);
    return null;
  };
  protoOf(DragManagerImpl).m22 = function (context) {
    return this.u3j(context instanceof InputEventContext ? context : THROW_CCE());
  };
  protoOf(DragManagerImpl).v3j = function (context) {
    var tmp0_safe_receiver = context.z21_1;
    if ((tmp0_safe_receiver == null ? null : tmp0_safe_receiver.i2()) === Companion_instance_0.e18_1) {
      return this;
    }
    var tmp;
    if (!(this.i3j_1 == null)) {
      var tmp1_safe_receiver = context.z21_1;
      tmp = (tmp1_safe_receiver == null ? null : tmp1_safe_receiver.i2()) === Companion_instance_0.h18_1;
    } else {
      tmp = false;
    }
    if (tmp) {
      var selection = this.e3j_1.f1o().f3b().f3d();
      if (selection.o() === 1 && first_0(selection).q3a()) {
        return null;
      }
      drag(this, selection, this.l3j_1.in_1, this.l3j_1.jn_1, true, true);
    }
    return null;
  };
  protoOf(DragManagerImpl).n22 = function (context) {
    return this.v3j(context instanceof InputEventContext ? context : THROW_CCE());
  };
  protoOf(DragManagerImpl).w3j = function (context) {
    var tmp;
    if (!(this.i3j_1 == null)) {
      var tmp0_safe_receiver = context.z21_1;
      tmp = (tmp0_safe_receiver == null ? null : tmp0_safe_receiver.i2()) === Companion_instance_0.h18_1;
    } else {
      tmp = false;
    }
    if (tmp) {
      var selection = this.e3j_1.f1o().f3b().f3d();
      if (selection.o() === 1 && first_0(selection).q3a()) {
        return null;
      }
      drag(this, selection, this.l3j_1.in_1, this.l3j_1.jn_1, false, true);
    }
    return null;
  };
  protoOf(DragManagerImpl).o22 = function (context) {
    return this.w3j(context instanceof InputEventContext ? context : THROW_CCE());
  };
  protoOf(DragManagerImpl).x3j = function (event) {
    var tmp0_subject = event.i2();
    return tmp0_subject === Companion_instance_0.z17_1 || tmp0_subject === Companion_instance_0.y17_1 || (tmp0_subject === Companion_instance_0.a18_1 || tmp0_subject === Companion_instance_0.b18_1) ? event.modifiers === 0 || event.isAltDown : false;
  };
  protoOf(DragManagerImpl).y3j = function (event) {
    var tmp;
    if (event.isAltDown) {
      tmp = getKeyMoveDirection(this, event).m1f();
    } else {
      tmp = getKeyMoveDirection(this, event).m1f().i1f(this.e3j_1.f1o().h3b().z3j());
    }
    var offset = tmp;
    logMove(this, 'key', offset, 0);
    this.f3j_1.a3f(this.e3j_1.f1o().f3b().f3d(), offset, this.e3j_1, false);
  };
  function EditDragModule() {
    EditDragModule_instance = this;
    AbstractModule.call(this);
    this.x3i_1 = new DragDestinationHighlightFactoryRegistry();
  }
  protoOf(EditDragModule).ro = function () {
  };
  var EditDragModule_instance;
  function EditDragModule_getInstance() {
    if (EditDragModule_instance == null)
      new EditDragModule();
    return EditDragModule_instance;
  }
  function AddCommand_init_$Init$(editor, component, $this) {
    AddCommand.call($this, editor.f1o(), component);
    return $this;
  }
  function AddCommand_init_$Create$(editor, component) {
    return AddCommand_init_$Init$(editor, component, objectCreate(protoOf(AddCommand)));
  }
  function AddCommand(drawingView, component, componentCustomizer) {
    componentCustomizer = componentCustomizer === VOID ? null : componentCustomizer;
    AbstractDrawingViewCommand.call(this, 'edit.command.add', drawingView);
    this.e3k_1 = component;
    this.f3k_1 = componentCustomizer;
    this.g3k_1 = 0;
  }
  protoOf(AddCommand).r39 = function () {
    return protoOf(AbstractDrawingViewCommand).r39.call(this) + ' ' + getKClassFromExpression(this.e3k_1).l9() + ' ' + this.g3k_1;
  };
  protoOf(AddCommand).s39 = function () {
    var clone = this.e3k_1.x3a();
    var tmp = this.v3g_1;
    (isInterface(tmp, DrawingView) ? tmp : THROW_CCE()).e3b().l20(clone);
    var tmp0_safe_receiver = this.f3k_1;
    if (tmp0_safe_receiver == null)
      null;
    else {
      tmp0_safe_receiver.o3f(clone, this.v3g_1.e3b());
    }
    this.g3k_1 = clone.av();
  };
  protoOf(AddCommand).w39 = function () {
    var tmp = this.v3g_1.e3b();
    var tmp_0 = this.v3g_1.e3b().y3a(this.g3k_1);
    tmp.m20((!(tmp_0 == null) ? isInterface(tmp_0, Component) : false) ? tmp_0 : THROW_CCE());
  };
  function EditEditorModule$dragManagerFactory$lambda(editor) {
    return new DragManagerImpl(editor);
  }
  function EditEditorModule() {
    EditEditorModule_instance = this;
    AbstractModule.call(this);
    var tmp = this;
    tmp.i3k_1 = EditEditorModule$dragManagerFactory$lambda;
  }
  protoOf(EditEditorModule).ro = function () {
  };
  var EditEditorModule_instance;
  function EditEditorModule_getInstance() {
    if (EditEditorModule_instance == null)
      new EditEditorModule();
    return EditEditorModule_instance;
  }
  function EditorImpl$DrawingViewListener$propertyChanged$lambda(this$0) {
    return function () {
      this$0.z3k(this$0.s3k_1);
      return Unit_instance;
    };
  }
  function EditorImpl_init_$Init$(view, name, $this) {
    name = name === VOID ? '' : name;
    EditorImpl.call($this, view, EditModule_getInstance().d3f_1, EditSelectModule_getInstance().e3l_1, name);
    return $this;
  }
  function MouseEventDelegator($outer) {
    this.h3l_1 = $outer;
    MouseAdapter.call(this);
    this.f3l_1 = false;
    this.g3l_1 = Companion_getInstance().g1a_1;
  }
  protoOf(MouseEventDelegator).v1a = function (e) {
    this.h3l_1.t3k_1.u3e(e, this.h3l_1.j3k_1.n24(e.hw()));
  };
  protoOf(MouseEventDelegator).r1a = function (e) {
    this.h3l_1.t3k_1.o3e(e, this.h3l_1.j3k_1.n24(e.hw()));
  };
  protoOf(MouseEventDelegator).s1a = function (e) {
    this.g3l_1 = e.hw();
    this.h3l_1.t3k_1.q3e(e, this.h3l_1.j3k_1.n24(e.hw()));
  };
  protoOf(MouseEventDelegator).u1a = function (e) {
    if (!this.f3l_1 && this.g3l_1.o1g(e.z19(), e.a1a()) > 15) {
      this.f3l_1 = true;
    }
    if (this.f3l_1) {
      this.h3l_1.t3k_1.w3e(e, this.h3l_1.j3k_1.n24(e.hw()));
    }
  };
  protoOf(MouseEventDelegator).t1a = function (e) {
    this.h3l_1.t3k_1.s3e(e, this.h3l_1.j3k_1.n24(e.hw()));
    this.f3l_1 = false;
  };
  function KeyEventDelegator($outer) {
    this.i3l_1 = $outer;
    KeyAdapter.call(this);
  }
  protoOf(KeyEventDelegator).x19 = function (e) {
    this.i3l_1.t3k_1.x19(e);
  };
  protoOf(KeyEventDelegator).y19 = function (e) {
    this.i3l_1.t3k_1.y19(e);
  };
  function DrawingViewListener($outer) {
    this.j3l_1 = $outer;
  }
  protoOf(DrawingViewListener).propertyChanged = function (e) {
    var tmp0_subject = e.name;
    if (tmp0_subject === 'PROP_DRAWING') {
      var tmp = e.oldValue;
      ((!(tmp == null) ? isInterface(tmp, Drawing) : false) ? tmp : THROW_CCE()).a21(this.j3l_1.y3k_1);
      var tmp_0 = e.newValue;
      ((!(tmp_0 == null) ? isInterface(tmp_0, Drawing) : false) ? tmp_0 : THROW_CCE()).a21(this.j3l_1.y3k_1);
    } else if (tmp0_subject === 'PROP_CANVAS') {
      this.j3l_1.x39(true);
      var tmp_1 = System_getInstance();
      tmp_1.dm(EditorImpl$DrawingViewListener$propertyChanged$lambda(this.j3l_1));
    }
    if (e.name === 'PROP_DRAWING') {
      var tmp_2 = e.oldValue;
      ((!(tmp_2 == null) ? isInterface(tmp_2, Drawing) : false) ? tmp_2 : THROW_CCE()).a21(this.j3l_1.y3k_1);
      var tmp_3 = e.newValue;
      ((!(tmp_3 == null) ? isInterface(tmp_3, Drawing) : false) ? tmp_3 : THROW_CCE()).a21(this.j3l_1.y3k_1);
    }
  };
  function DrawingListener($outer) {
    this.k3l_1 = $outer;
    DrawableContainerAdapter.call(this);
  }
  protoOf(DrawingListener).l3l = function (event) {
    var tmp = event.h21_1;
    if (isInterface(tmp, Component)) {
      var tmp_0 = event.h21_1;
      this.k3l_1.m3l(isInterface(tmp_0, Component) ? tmp_0 : THROW_CCE());
    }
  };
  protoOf(DrawingListener).i21 = function (event) {
    return this.l3l(event);
  };
  protoOf(DrawingListener).n3l = function (event) {
    var tmp = event.h21_1;
    if (isInterface(tmp, Component)) {
      var tmp_0 = event.h21_1;
      this.k3l_1.o3l(isInterface(tmp_0, Component) ? tmp_0 : THROW_CCE());
    }
  };
  protoOf(DrawingListener).j21 = function (event) {
    return this.n3l(event);
  };
  function EditorImpl(view, commandManager, selectionToolFactory, name, dragManagerFactory) {
    name = name === VOID ? '' : name;
    dragManagerFactory = dragManagerFactory === VOID ? EditEditorModule_getInstance().i3k_1 : dragManagerFactory;
    this.j3k_1 = view;
    this.k3k_1 = commandManager;
    this.l3k_1 = name;
    this.m3k_1 = new PropertyChangeSupport(this);
    this.n3k_1 = new ComponentSnapper(this);
    this.o3k_1 = SnapManagerImpl_init_$Create$(this);
    this.p3k_1 = dragManagerFactory(this);
    this.q3k_1 = false;
    this.r3k_1 = false;
    this.s3k_1 = selectionToolFactory(this);
    this.t3k_1 = this.s3k_1;
    this.u3k_1 = new ToolLockAction(this);
    this.v3k_1 = new MouseEventDelegator(this);
    this.w3k_1 = new KeyEventDelegator(this);
    this.x3k_1 = new DrawingViewListener(this);
    this.y3k_1 = new DrawingListener(this);
    this.o3k_1.p3l(this.n3k_1);
    this.o3k_1.p3l(this.j3k_1.h3b());
    this.j3k_1.e3b().a21(this.y3k_1);
    this.j3k_1.l1y(this.x3k_1);
  }
  protoOf(EditorImpl).f1o = function () {
    return this.j3k_1;
  };
  protoOf(EditorImpl).l3c = function () {
    return this.k3k_1;
  };
  protoOf(EditorImpl).j3c = function () {
    return this.o3k_1;
  };
  protoOf(EditorImpl).k3c = function () {
    return this.p3k_1;
  };
  protoOf(EditorImpl).x39 = function (value) {
    if (value === this.q3k_1) {
      return Unit_instance;
    }
    var oldValue = this.q3k_1;
    this.q3k_1 = value;
    if (this.q3k_1) {
      this.j3k_1.b1y(this.v3k_1);
      this.j3k_1.d1y(this.v3k_1);
      this.j3k_1.h1y(this.w3k_1);
      this.t3k_1.w2u();
    } else {
      this.j3k_1.c1y(this.v3k_1);
      this.j3k_1.e1y(this.v3k_1);
      this.j3k_1.i1y(this.w3k_1);
      this.t3k_1.x2u();
      this.j3k_1.f3b().k3d();
    }
    this.j3k_1.e24(this.q3k_1);
    this.m3k_1.lr('active', oldValue, this.q3k_1);
  };
  protoOf(EditorImpl).g3c = function (value) {
    if (value === this.r3k_1) {
      return Unit_instance;
    }
    var oldValue = this.r3k_1;
    this.r3k_1 = value;
    this.m3k_1.lr('lockTool', oldValue, this.r3k_1);
  };
  protoOf(EditorImpl).h3c = function () {
    return this.r3k_1;
  };
  protoOf(EditorImpl).z3k = function (value) {
    var oldValue = this.t3k_1;
    this.t3k_1 = value;
    oldValue.x2u();
    this.t3k_1.w2u();
    this.m3k_1.lr('currentTool', oldValue, this.t3k_1);
  };
  protoOf(EditorImpl).i3c = function () {
    return this.t3k_1;
  };
  protoOf(EditorImpl).m3l = function (component) {
  };
  protoOf(EditorImpl).o3l = function (component) {
  };
  function AbstractPathFigure$draw$lambda($context, this$0) {
    return function (it) {
      $context.t1y_1.u1u(this$0.z3l_1);
      return Unit_instance;
    };
  }
  function AbstractPathFigure(path, type) {
    AbstractComponent_init_$Init$(VOID, VOID, this);
    this.z3l_1 = path;
    this.a3m_1 = type;
    this.b3m_1 = Companion_getInstance().g1a_1;
  }
  protoOf(AbstractPathFigure).u19 = function () {
    return this.a3m_1;
  };
  protoOf(AbstractPathFigure).do = function () {
    // Inline function 'kotlin.also' call
    var this_0 = Rectangle2D_init_$Create$(this.z3l_1.do());
    this_0.s1b(this.hw().in_1 + this_0.e1h_1, this.hw().jn_1 + this_0.f1h_1, this_0.g1h_1, this_0.h1h_1);
    this_0.z1b(this.v1t().p1t_1);
    return this_0;
  };
  protoOf(AbstractPathFigure).eo = function (x, y) {
    return this.do().eo(x, y);
  };
  protoOf(AbstractPathFigure).r1z = function (context) {
    context.t1y_1.v1c(this.hw().in_1, this.hw().jn_1);
    if (this.s2c()) {
      var tmp = DropShadow_instance;
      tmp.v2m(context, 255, AbstractPathFigure$draw$lambda(context, this));
    }
    var tmp_0;
    if (context.w1y_1) {
      tmp_0 = ensureNotNull(context.x1y_1).i1x_1;
    } else {
      tmp_0 = Look_getInstance().p3c_1 ? this.j2c() : DrawStyleModule_getInstance().g1x_1.p1x(Companion_getInstance_0().n1x_1).m1t().i1x_1;
    }
    context.t1y_1.l1t(tmp_0);
    context.t1y_1.u1u(this.z3l_1);
    context.t1y_1.l1t(context.b1z(this.i2c()));
    context.t1y_1.o1t(this.v1t());
    context.t1y_1.t1u(this.z3l_1);
    context.t1y_1.v1c(-this.hw().in_1, -this.hw().jn_1);
  };
  protoOf(AbstractPathFigure).f20 = function (value) {
    this.s1z();
    this.b3m_1 = value;
    this.s1z();
    this.v1z();
  };
  protoOf(AbstractPathFigure).hw = function () {
    return this.b3m_1;
  };
  protoOf(AbstractPathFigure).r37 = function (writer) {
    protoOf(AbstractComponent).r37.call(this, writer);
    writer.d39('location', this.hw());
  };
  protoOf(AbstractPathFigure).s37 = function (reader) {
    protoOf(AbstractComponent).s37.call(this, reader);
    this.f20(reader.i38('location'));
  };
  protoOf(AbstractPathFigure).p2h = function (x) {
    var transform = System_getInstance().zl();
    transform.x1c(-1.0, 1.0);
    transform.v1c(-x, 0.0);
    this.z3l_1.kn(transform);
    this.f20(this.hw().q1g(x));
  };
  protoOf(AbstractPathFigure).q2h = function (y) {
    var transform = System_getInstance().zl();
    transform.x1c(1.0, -1.0);
    transform.v1c(0.0, -y);
    this.z3l_1.kn(transform);
    this.f20(this.hw().r1g(y));
  };
  function sam$io_antarescircuit_jabbah_edit_figure_FigureFactory$0(function_0) {
    this.m3m_1 = function_0;
  }
  protoOf(sam$io_antarescircuit_jabbah_edit_figure_FigureFactory$0).p2 = function () {
    return this.m3m_1;
  };
  protoOf(sam$io_antarescircuit_jabbah_edit_figure_FigureFactory$0).equals = function (other) {
    var tmp;
    if (!(other == null) ? isInterface(other, FigureFactory) : false) {
      var tmp_0;
      if (!(other == null) ? isInterface(other, FunctionAdapter) : false) {
        tmp_0 = equals(this.p2(), other.p2());
      } else {
        tmp_0 = false;
      }
      tmp = tmp_0;
    } else {
      tmp = false;
    }
    return tmp;
  };
  protoOf(sam$io_antarescircuit_jabbah_edit_figure_FigureFactory$0).hashCode = function () {
    return hashCode(this.p2());
  };
  function FigureRegistry$registerDefaultGeometricalFigures$lambda() {
    return new RectangleComponent(VOID, VOID, Rectangle2D_init_$Create$_0(0, 0, 60, 30));
  }
  function FigureRegistry$registerDefaultGeometricalFigures$lambda_0() {
    return new EllipseComponent(VOID, VOID, Ellipse2D_init_$Create$(0, 0, 60, 30));
  }
  function FigureRegistry() {
    FigureRegistry_instance = this;
    this.n3m_1 = 'edit.figure.geometrical';
    var tmp = this;
    // Inline function 'kotlin.collections.mutableListOf' call
    tmp.o3m_1 = ArrayList_init_$Create$_0();
  }
  protoOf(FigureRegistry).p3m = function (name) {
    var tmp0 = this.o3m_1;
    var tmp$ret$0;
    $l$block_0: {
      // Inline function 'kotlin.collections.any' call
      var tmp;
      if (isInterface(tmp0, Collection)) {
        tmp = tmp0.m();
      } else {
        tmp = false;
      }
      if (tmp) {
        tmp$ret$0 = false;
        break $l$block_0;
      }
      var _iterator__ex2g4s = tmp0.i();
      while (_iterator__ex2g4s.j()) {
        var element = _iterator__ex2g4s.k();
        if (element.q3m_1 === name) {
          tmp$ret$0 = true;
          break $l$block_0;
        }
      }
      tmp$ret$0 = false;
    }
    if (tmp$ret$0) {
      throw IllegalArgumentException_init_$Create$('FigureGroup ' + name + ' already registered');
    }
    // Inline function 'kotlin.also' call
    var this_0 = new FigureGroup(name);
    FigureRegistry_getInstance().o3m_1.h(this_0);
    return this_0;
  };
  protoOf(FigureRegistry).s3m = function () {
    // Inline function 'kotlin.apply' call
    var this_0 = this.p3m(Translations_getInstance().zm('edit.figure.geometrical', []));
    var tmp = Companion_getInstance_32().t3m_1;
    var tmp_0 = FigureRegistry$registerDefaultGeometricalFigures$lambda;
    this_0.u3m(new FigureProvider(tmp, new sam$io_antarescircuit_jabbah_edit_figure_FigureFactory$0(tmp_0)));
    var tmp_1 = Companion_getInstance_33().v3m_1;
    var tmp_2 = FigureRegistry$registerDefaultGeometricalFigures$lambda_0;
    this_0.u3m(new FigureProvider(tmp_1, new sam$io_antarescircuit_jabbah_edit_figure_FigureFactory$0(tmp_2)));
  };
  var FigureRegistry_instance;
  function FigureRegistry_getInstance() {
    if (FigureRegistry_instance == null)
      new FigureRegistry();
    return FigureRegistry_instance;
  }
  function FigureGroup(name) {
    this.q3m_1 = name;
    var tmp = this;
    // Inline function 'kotlin.collections.mutableListOf' call
    tmp.r3m_1 = ArrayList_init_$Create$_0();
  }
  protoOf(FigureGroup).u3m = function (provider) {
    this.r3m_1.h(provider);
  };
  function FigureProvider(name, factory) {
    this.w3m_1 = name;
    this.x3m_1 = factory;
  }
  protoOf(FigureProvider).toString = function () {
    return 'FigureProvider(name=' + this.w3m_1 + ', factory=' + toString(this.x3m_1) + ')';
  };
  protoOf(FigureProvider).hashCode = function () {
    var result = getStringHashCode(this.w3m_1);
    result = imul(result, 31) + hashCode(this.x3m_1) | 0;
    return result;
  };
  protoOf(FigureProvider).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof FigureProvider))
      return false;
    if (!(this.w3m_1 === other.w3m_1))
      return false;
    if (!equals(this.x3m_1, other.x3m_1))
      return false;
    return true;
  };
  function FigureFactory() {
  }
  function DrawingViewSearch() {
  }
  function _get_LOG__e5r759_3($this) {
    var tmp0 = $this.y3m_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('LOG', 1, tmp, BelowSmHighlighter$Companion$_get_LOG_$ref_biufiu(), null);
    return tmp0.j2();
  }
  function BelowSmHighlighter$Companion$_get_LOG_$ref_biufiu() {
    return function (p0) {
      return _get_LOG__e5r759_3(p0);
    };
  }
  function Companion_7() {
    Companion_instance_12 = this;
    this.y3m_1 = logger(getKClass(BelowSmHighlighter));
  }
  var Companion_instance_12;
  function Companion_getInstance_17() {
    if (Companion_instance_12 == null)
      new Companion_7();
    return Companion_instance_12;
  }
  function _get_highlights__9xcox8($this) {
    var tmp0 = $this.c3n_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('highlights', 1, tmp, BelowSmHighlighter$_get_highlights_$ref_r7n561(), null);
    return tmp0.j2();
  }
  function highlightImpl($this, c, color) {
    color = color === VOID ? null : color;
    _get_LOG__e5r759_3(Companion_getInstance_17()).ol("Highlight component '" + c.av() + "'");
    var highlight = $this.z3m_1.d3n(c, SelectionDrawingStrategy_BELOW_getInstance());
    if (highlight == null) {
      _get_LOG__e5r759_3(Companion_getInstance_17()).kl('No suitable highlight SelectionMo`del found for ' + System_getInstance().wl(c));
      return Unit_instance;
    }
    if (!(color == null)) {
      if (isInterface(highlight, Colorable)) {
        highlight.v2d(color);
      } else {
        _get_LOG__e5r759_3(Companion_getInstance_17()).ll('requested highlight color for non-colorable SelectionModel ' + getKClassFromExpression(highlight).l9());
      }
    }
    // Inline function 'kotlin.collections.set' call
    _get_highlights__9xcox8($this).y1(c, highlight);
    $this.b3n_1.o3b().l20(highlight);
  }
  function unhighlightImpl($this, c) {
    _get_LOG__e5r759_3(Companion_getInstance_17()).ol("Unhighlight component '" + c.av() + "'");
    var highlight = _get_highlights__9xcox8($this).g2(c);
    _get_highlights__9xcox8($this).z1(c);
    $this.b3n_1.o3b().m20(ensureNotNull(highlight));
  }
  function postHighlightChangedEvent($this, c, highlighted) {
    var tmp0_content = $this.b3n_1;
    $this.a3n_1.eu(HighlightChangeEvent_init_$Create$(tmp0_content, $this, c, highlighted));
  }
  function BelowSmHighlighter$highlights$delegate$lambda() {
    // Inline function 'kotlin.collections.mutableMapOf' call
    return LinkedHashMap_init_$Create$();
  }
  function BelowSmHighlighter$_get_highlights_$ref_r7n561() {
    return function (p0) {
      return _get_highlights__9xcox8(p0);
    };
  }
  function BelowSmHighlighter$highlight$lambda($ids) {
    return function (it) {
      return contains($ids, it.av());
    };
  }
  function BelowSmHighlighter$unhighlight$lambda($ids) {
    return function (it) {
      return contains($ids, it.av());
    };
  }
  function BelowSmHighlighter(highlightModelProvider, eventBus, content) {
    Companion_getInstance_17();
    highlightModelProvider = highlightModelProvider === VOID ? EditHighlightModule_getInstance().g3n_1 : highlightModelProvider;
    eventBus = eventBus === VOID ? BaseModule_getInstance().zo_1 : eventBus;
    this.z3m_1 = highlightModelProvider;
    this.a3n_1 = eventBus;
    this.b3n_1 = content;
    var tmp = this;
    tmp.c3n_1 = lazy(BelowSmHighlighter$highlights$delegate$lambda);
  }
  protoOf(BelowSmHighlighter).i3n = function (components) {
    // Inline function 'kotlin.collections.mutableListOf' call
    var newHighlights = ArrayList_init_$Create$_0();
    // Inline function 'kotlin.collections.filter' call
    // Inline function 'kotlin.collections.filterTo' call
    var destination = ArrayList_init_$Create$_0();
    var _iterator__ex2g4s = components.i();
    while (_iterator__ex2g4s.j()) {
      var element = _iterator__ex2g4s.k();
      if (!this.j3n(element)) {
        destination.h(element);
      }
    }
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s_0 = destination.i();
    while (_iterator__ex2g4s_0.j()) {
      var element_0 = _iterator__ex2g4s_0.k();
      highlightImpl(this, element_0);
      newHighlights.h(element_0);
    }
    if (newHighlights.o() > 0) {
      this.b3n_1.o3b().u1z();
      postHighlightChangedEvent(this, newHighlights, true);
    }
  };
  protoOf(BelowSmHighlighter).k3n = function (ids) {
    var tmp = this.b3n_1.e3b();
    this.i3n(tmp.u20(BelowSmHighlighter$highlight$lambda(ids)));
  };
  protoOf(BelowSmHighlighter).l3n = function (components) {
    // Inline function 'kotlin.collections.mutableListOf' call
    var oldHighlights = ArrayList_init_$Create$_0();
    // Inline function 'kotlin.collections.filter' call
    // Inline function 'kotlin.collections.filterTo' call
    var destination = ArrayList_init_$Create$_0();
    var _iterator__ex2g4s = components.i();
    while (_iterator__ex2g4s.j()) {
      var element = _iterator__ex2g4s.k();
      if (this.j3n(element)) {
        destination.h(element);
      }
    }
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s_0 = destination.i();
    while (_iterator__ex2g4s_0.j()) {
      var element_0 = _iterator__ex2g4s_0.k();
      unhighlightImpl(this, element_0);
      oldHighlights.h(element_0);
    }
    if (oldHighlights.o() > 0) {
      this.b3n_1.o3b().u1z();
      postHighlightChangedEvent(this, oldHighlights, false);
    }
  };
  protoOf(BelowSmHighlighter).m3n = function (ids) {
    var tmp = this.b3n_1.e3b();
    this.l3n(tmp.u20(BelowSmHighlighter$unhighlight$lambda(ids)));
  };
  protoOf(BelowSmHighlighter).j3n = function (component) {
    return _get_highlights__9xcox8(this).e2(component);
  };
  function EditHighlightModule$highlightModelFactory$lambda(component) {
    return new BoundingBoxBelowSelectionModel(component, VOID, Companion_getInstance_60().o3n_1);
  }
  function EditHighlightModule$highlighterFactory$1() {
  }
  protoOf(EditHighlightModule$highlighterFactory$1).r3n = function (content) {
    return new BelowSmHighlighter(VOID, VOID, content);
  };
  function EditHighlightModule() {
    EditHighlightModule_instance = this;
    AbstractModule.call(this);
    var tmp = this;
    var tmp_0 = SelectionDrawingStrategy_BELOW_getInstance();
    tmp.f3n_1 = new SelectionModelFactoryImpl(mapOf(to(tmp_0, EditHighlightModule$highlightModelFactory$lambda)));
    this.g3n_1 = new SimpleSelectionModelProvider(this.f3n_1);
    var tmp_1 = this;
    tmp_1.h3n_1 = new EditHighlightModule$highlighterFactory$1();
  }
  protoOf(EditHighlightModule).ro = function () {
  };
  var EditHighlightModule_instance;
  function EditHighlightModule_getInstance() {
    if (EditHighlightModule_instance == null)
      new EditHighlightModule();
    return EditHighlightModule_instance;
  }
  var Type_HIGHLIGHTED_instance;
  var Type_UNHIGHLIGHTED_instance;
  var Type_entriesInitialized_0;
  function Type_initEntries_0() {
    if (Type_entriesInitialized_0)
      return Unit_instance;
    Type_entriesInitialized_0 = true;
    Type_HIGHLIGHTED_instance = new Type_0('HIGHLIGHTED', 0);
    Type_UNHIGHLIGHTED_instance = new Type_0('UNHIGHLIGHTED', 1);
  }
  function HighlightChangeEvent_init_$Init$(content, highlighter, components, highlighted, $this) {
    HighlightChangeEvent.call($this, content, highlighter, highlighted ? Type_HIGHLIGHTED_getInstance() : Type_UNHIGHLIGHTED_getInstance(), components);
    return $this;
  }
  function HighlightChangeEvent_init_$Create$(content, highlighter, components, highlighted) {
    return HighlightChangeEvent_init_$Init$(content, highlighter, components, highlighted, objectCreate(protoOf(HighlightChangeEvent)));
  }
  function Type_0(name, ordinal) {
    Enum.call(this, name, ordinal);
  }
  function Type_HIGHLIGHTED_getInstance() {
    Type_initEntries_0();
    return Type_HIGHLIGHTED_instance;
  }
  function Type_UNHIGHLIGHTED_getInstance() {
    Type_initEntries_0();
    return Type_UNHIGHLIGHTED_instance;
  }
  function HighlightChangeEvent(content, highlighter, type, components) {
    this.s3n_1 = content;
    this.t3n_1 = highlighter;
    this.u3n_1 = type;
    this.v3n_1 = components;
    this.w3n_1 = this.u3n_1.equals(Type_HIGHLIGHTED_getInstance());
    this.x3n_1 = this.u3n_1.equals(Type_UNHIGHLIGHTED_getInstance());
  }
  protoOf(HighlightChangeEvent).toString = function () {
    return 'HighlightChangeEvent(content=' + toString(this.s3n_1) + ', highlighter=' + toString(this.t3n_1) + ', type=' + this.u3n_1.toString() + ', components=' + toString(this.v3n_1) + ')';
  };
  protoOf(HighlightChangeEvent).hashCode = function () {
    var result = hashCode(this.s3n_1);
    result = imul(result, 31) + hashCode(this.t3n_1) | 0;
    result = imul(result, 31) + this.u3n_1.hashCode() | 0;
    result = imul(result, 31) + hashCode(this.v3n_1) | 0;
    return result;
  };
  protoOf(HighlightChangeEvent).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof HighlightChangeEvent))
      return false;
    if (!equals(this.s3n_1, other.s3n_1))
      return false;
    if (!equals(this.t3n_1, other.t3n_1))
      return false;
    if (!this.u3n_1.equals(other.u3n_1))
      return false;
    if (!equals(this.v3n_1, other.v3n_1))
      return false;
    return true;
  };
  function AbstractComponent_init_$Init$(styleProvider, styleType, $this) {
    styleProvider = styleProvider === VOID ? DrawStyleModule_getInstance().g1x_1 : styleProvider;
    styleType = styleType === VOID ? Companion_getInstance_0().l1x_1 : styleType;
    AbstractComponent.call($this, new StylableImpl(VOID, styleType, styleProvider));
    return $this;
  }
  function AbstractComponent(stylable) {
    AbstractStyledDrawable.call(this, stylable);
    this.g3m_1 = 0;
    this.h3m_1 = null;
    this.i3m_1 = false;
    this.j3m_1 = false;
    this.k3m_1 = Rotation_R0_getInstance();
  }
  protoOf(AbstractComponent).x3a = function () {
    return StorableCloner_getInstance().c36(this);
  };
  protoOf(AbstractComponent).k3a = function (_set____db54di) {
    this.g3m_1 = _set____db54di;
  };
  protoOf(AbstractComponent).av = function () {
    return this.g3m_1;
  };
  protoOf(AbstractComponent).l3a = function () {
    return null;
  };
  protoOf(AbstractComponent).o3a = function (_set____db54di) {
    this.h3m_1 = _set____db54di;
  };
  protoOf(AbstractComponent).p3a = function () {
    return this.h3m_1;
  };
  protoOf(AbstractComponent).m3a = function () {
    return false;
  };
  protoOf(AbstractComponent).n3a = function () {
    return this;
  };
  protoOf(AbstractComponent).t3a = function () {
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [new SnappableXCoordinate(this.hw().in_1)];
  };
  protoOf(AbstractComponent).u3a = function () {
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [new SnappableYCoordinate(this.hw().jn_1)];
  };
  protoOf(AbstractComponent).f21 = function (dx, dy) {
    this.f20(new Point2D(this.hw().in_1 + dx, this.hw().jn_1 + dy));
  };
  protoOf(AbstractComponent).o37 = function (_set____db54di) {
    this.i3m_1 = _set____db54di;
  };
  protoOf(AbstractComponent).p37 = function () {
    return this.i3m_1;
  };
  protoOf(AbstractComponent).r37 = function (writer) {
    writer.t38('id', this.av());
    if (!this.m3a()) {
      writer.w38('style', this.r28().n28_1);
    }
    if (!(this.u2c() == null)) {
      writer.w38('color', ensureNotNull(this.u2c()).m2());
    }
    if (!(this.w2c() == null)) {
      writer.w38('stroke', ensureNotNull(this.w2c()).s2n_1.y2n_1);
    }
    if (this.x2h()) {
      writer.w38('rot', this.g20().r1h_1);
    }
    writer.y38('filled', this.p2c());
    writer.y38('stroked', this.r2c());
    if (!(this.z2c() == null)) {
      writer.y38('shadow', ensureNotNull(this.z2c()));
    }
  };
  protoOf(AbstractComponent).s37 = function (reader) {
    if (reader.d35('id')) {
      this.k3a(reader.z37('id'));
    }
    if (this.x2h() && reader.d35('rot')) {
      this.w27(Companion_instance_1.r1e(reader.b38('rot')));
    }
    if (!this.m3a() && reader.d35('style')) {
      var storedStyle = reader.b38('style');
      if (storedStyle === 'explanation') {
        storedStyle = Companion_getInstance_0().k1x_1.n28_1;
      }
      this.m2c(this.h2c().c2t(storedStyle));
    }
    if (reader.d35('color')) {
      this.t2c(this.h2c().a2t().q2n(reader.b38('color')));
    }
    if (reader.d35('stroke')) {
      this.v2c(this.h2c().b2t().u2n(reader.b38('stroke')));
    }
    if (reader.d35('filled')) {
      this.o2c(reader.d38('filled'));
    }
    if (reader.d35('stroked')) {
      this.q2c(reader.d38('stroked'));
    }
    if (reader.d35('shadow')) {
      this.y2c(reader.d38('shadow'));
    }
  };
  protoOf(AbstractComponent).k37 = function (reference, referenceResolver) {
  };
  protoOf(AbstractComponent).y3n = function (_set____db54di) {
    this.j3m_1 = _set____db54di;
  };
  protoOf(AbstractComponent).p21 = function () {
    return this.j3m_1;
  };
  protoOf(AbstractComponent).u21 = function () {
    this.s1z();
    this.u1z();
  };
  protoOf(AbstractComponent).v21 = function () {
    this.s1z();
    this.u1z();
  };
  protoOf(AbstractComponent).w27 = function (value) {
    if (!this.x2h()) {
      throw IllegalArgumentException_init_$Create$('rotation not supported');
    }
    if (!value.equals(this.k3m_1)) {
      this.s1z();
      this.k3m_1 = value;
      this.l3m(this.k3m_1);
      this.s1z();
      this.v1z();
    }
  };
  protoOf(AbstractComponent).g20 = function () {
    return this.k3m_1;
  };
  protoOf(AbstractComponent).x2h = function () {
    return false;
  };
  protoOf(AbstractComponent).l3m = function (newRotation) {
  };
  protoOf(AbstractComponent).z3n = function (context, drawer) {
    var tmp2 = this.hw();
    // Inline function 'io.antarescircuit.jabbah.draw.DrawContext.translatedAndRotated' call
    var angle = this.g20().s1h_1;
    context.t1y_1.v1c(tmp2.in_1, tmp2.jn_1);
    context.t1y_1.y1c(angle);
    drawer(context);
    context.t1y_1.y1c(-angle);
    context.t1y_1.v1c(-tmp2.in_1, -tmp2.jn_1);
    DrawModule_getInstance().j2p(this, context);
  };
  function fixMissingComponentIds($this) {
    // Inline function 'kotlin.collections.filter' call
    var tmp0 = $this.e20();
    // Inline function 'kotlin.collections.filterTo' call
    var destination = ArrayList_init_$Create$_0();
    var _iterator__ex2g4s = tmp0.i();
    while (_iterator__ex2g4s.j()) {
      var element = _iterator__ex2g4s.k();
      if (element.av() === 0) {
        destination.h(element);
      }
    }
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s_0 = destination.i();
    while (_iterator__ex2g4s_0.j()) {
      var element_0 = _iterator__ex2g4s_0.k();
      element_0.k3a(getMaxId($this) + 1 | 0);
    }
  }
  function getMaxId($this) {
    if ($this.e20().m()) {
      return 0;
    }
    var tmp0 = $this.e20();
    var tmp$ret$0;
    $l$block_0: {
      // Inline function 'kotlin.collections.maxByOrNull' call
      var iterator = tmp0.i();
      if (!iterator.j()) {
        tmp$ret$0 = null;
        break $l$block_0;
      }
      var maxElem = iterator.k();
      if (!iterator.j()) {
        tmp$ret$0 = maxElem;
        break $l$block_0;
      }
      var maxValue = maxElem.av();
      do {
        var e = iterator.k();
        var v = e.av();
        if (compareTo(maxValue, v) < 0) {
          maxElem = e;
          maxValue = v;
        }
      }
       while (iterator.j());
      tmp$ret$0 = maxElem;
    }
    return ensureNotNull(tmp$ret$0).av();
  }
  function ComponentContainerImpl() {
    DrawableContainerImpl.call(this);
    this.n3o_1 = false;
    this.o3o_1 = false;
  }
  protoOf(ComponentContainerImpl).p3o = function (drawable, index) {
    if (!this.h20(drawable)) {
      if (!this.n3o_1) {
        drawable.k3a(getMaxId(this) + 1 | 0);
      }
      return protoOf(DrawableContainerImpl).k20.call(this, drawable, index);
    }
    return this;
  };
  protoOf(ComponentContainerImpl).k20 = function (drawable, index) {
    return this.p3o(isInterface(drawable, Component) ? drawable : THROW_CCE(), index);
  };
  protoOf(ComponentContainerImpl).y3a = function (id) {
    var tmp0 = this.e20();
    var tmp$ret$0;
    $l$block: {
      // Inline function 'kotlin.collections.firstOrNull' call
      var _iterator__ex2g4s = tmp0.i();
      while (_iterator__ex2g4s.j()) {
        var element = _iterator__ex2g4s.k();
        if (element.av() === id) {
          tmp$ret$0 = element;
          break $l$block;
        }
      }
      tmp$ret$0 = null;
    }
    return tmp$ret$0;
  };
  protoOf(ComponentContainerImpl).o37 = function (_set____db54di) {
    this.o3o_1 = _set____db54di;
  };
  protoOf(ComponentContainerImpl).p37 = function () {
    return this.o3o_1;
  };
  protoOf(ComponentContainerImpl).r37 = function (writer) {
    writer.r38('components', this.o20());
  };
  protoOf(ComponentContainerImpl).s37 = function (reader) {
    this.j20();
    var _iterator__ex2g4s = reader.x37('components').i();
    while (_iterator__ex2g4s.j()) {
      var storable = _iterator__ex2g4s.k();
      reader.f37(this, new Reference('component', VOID, storable, listOf(reader.h37(storable))));
    }
  };
  protoOf(ComponentContainerImpl).k37 = function (reference, referenceResolver) {
    if (reference.u36_1 === 'component') {
      try {
        this.n3o_1 = true;
        var tmp = reference.w36_1;
        this.l20((!(tmp == null) ? isInterface(tmp, Component) : false) ? tmp : THROW_CCE());
      }finally {
        this.n3o_1 = false;
      }
    }
  };
  protoOf(ComponentContainerImpl).m37 = function () {
    allResolutionDone.call(this);
    fixMissingComponentIds(this);
    this.i29();
  };
  function ComponentMessage(type, source, messageKey, messageParam) {
    type = type === VOID ? ComponentMessageType_Info_getInstance() : type;
    messageParam = messageParam === VOID ? null : messageParam;
    this.q3o_1 = type;
    this.r3o_1 = source;
    this.s3o_1 = messageKey;
    this.t3o_1 = messageParam;
  }
  protoOf(ComponentMessage).toString = function () {
    return 'ComponentMessage(type=' + this.q3o_1.toString() + ', source=' + toString_0(this.r3o_1) + ', messageKey=' + this.s3o_1 + ', messageParam=' + toString_0(this.t3o_1) + ')';
  };
  protoOf(ComponentMessage).hashCode = function () {
    var result = this.q3o_1.hashCode();
    result = imul(result, 31) + (this.r3o_1 == null ? 0 : hashCode(this.r3o_1)) | 0;
    result = imul(result, 31) + getStringHashCode(this.s3o_1) | 0;
    result = imul(result, 31) + (this.t3o_1 == null ? 0 : hashCode(this.t3o_1)) | 0;
    return result;
  };
  protoOf(ComponentMessage).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof ComponentMessage))
      return false;
    if (!this.q3o_1.equals(other.q3o_1))
      return false;
    if (!equals(this.r3o_1, other.r3o_1))
      return false;
    if (!(this.s3o_1 === other.s3o_1))
      return false;
    if (!equals(this.t3o_1, other.t3o_1))
      return false;
    return true;
  };
  var ComponentMessageType_Info_instance;
  var ComponentMessageType_Error_instance;
  var ComponentMessageType_entriesInitialized;
  function ComponentMessageType_initEntries() {
    if (ComponentMessageType_entriesInitialized)
      return Unit_instance;
    ComponentMessageType_entriesInitialized = true;
    ComponentMessageType_Info_instance = new ComponentMessageType('Info', 0);
    ComponentMessageType_Error_instance = new ComponentMessageType('Error', 1);
  }
  function ComponentMessageType(name, ordinal) {
    Enum.call(this, name, ordinal);
  }
  function ComponentMessageType_Info_getInstance() {
    ComponentMessageType_initEntries();
    return ComponentMessageType_Info_instance;
  }
  function ComponentMessageType_Error_getInstance() {
    ComponentMessageType_initEntries();
    return ComponentMessageType_Error_instance;
  }
  function CopyPasteService() {
  }
  function DrawingImpl(name) {
    name = name === VOID ? Name_init_$Create$('Drawing') : name;
    ComponentContainerImpl.call(this);
    this.j3p_1 = name;
  }
  protoOf(DrawingImpl).k3p = function (_set____db54di) {
    this.j3p_1 = _set____db54di;
  };
  protoOf(DrawingImpl).m2 = function () {
    return this.j3p_1;
  };
  protoOf(DrawingImpl).es = function () {
  };
  function DrawingServiceImpl() {
  }
  var Size_SMALL_instance;
  var Size_MEDIUM_instance;
  var Size_LARGE_instance;
  function Companion_8() {
    this.l3p_1 = 'edit.property.size';
  }
  protoOf(Companion_8).r1e = function (name) {
    var tmp0 = get_entries();
    var tmp$ret$0;
    $l$block: {
      // Inline function 'kotlin.collections.firstOrNull' call
      var _iterator__ex2g4s = tmp0.i();
      while (_iterator__ex2g4s.j()) {
        var element = _iterator__ex2g4s.k();
        if (element.o3p_1 === name) {
          tmp$ret$0 = element;
          break $l$block;
        }
      }
      tmp$ret$0 = null;
    }
    var tmp0_elvis_lhs = tmp$ret$0;
    var tmp;
    if (tmp0_elvis_lhs == null) {
      throw IllegalArgumentException_init_$Create$("unknown Size '" + name + "'");
    } else {
      tmp = tmp0_elvis_lhs;
    }
    return tmp;
  };
  var Companion_instance_13;
  function Companion_getInstance_18() {
    return Companion_instance_13;
  }
  function values() {
    return [Size_SMALL_getInstance(), Size_MEDIUM_getInstance(), Size_LARGE_getInstance()];
  }
  function get_entries() {
    if ($ENTRIES == null)
      $ENTRIES = enumEntries(values());
    return $ENTRIES;
  }
  var Size_entriesInitialized;
  function Size_initEntries() {
    if (Size_entriesInitialized)
      return Unit_instance;
    Size_entriesInitialized = true;
    Size_SMALL_instance = new Size('SMALL', 0, 'small', 0.5);
    Size_MEDIUM_instance = new Size('MEDIUM', 1, 'medium', 0.75);
    Size_LARGE_instance = new Size('LARGE', 2, 'large', 1.0);
  }
  var $ENTRIES;
  function Size(name, ordinal, customName, factor) {
    Enum.call(this, name, ordinal);
    this.o3p_1 = customName;
    this.p3p_1 = factor;
  }
  protoOf(Size).toString = function () {
    var tmp;
    switch (this.l2_1) {
      case 0:
        tmp = Translations_getInstance().zm('edit.property.size.small.name', []);
        break;
      case 1:
        tmp = Translations_getInstance().zm('edit.property.size.medium.name', []);
        break;
      case 2:
        tmp = Translations_getInstance().zm('edit.property.size.large.name', []);
        break;
      default:
        noWhenBranchMatchedException();
        break;
    }
    return tmp;
  };
  function Size_SMALL_getInstance() {
    Size_initEntries();
    return Size_SMALL_instance;
  }
  function Size_MEDIUM_getInstance() {
    Size_initEntries();
    return Size_MEDIUM_instance;
  }
  function Size_LARGE_getInstance() {
    Size_initEntries();
    return Size_LARGE_instance;
  }
  function Companion_9() {
    this.q3p_1 = 2.0;
  }
  var Companion_instance_14;
  function Companion_getInstance_19() {
    return Companion_instance_14;
  }
  function _set__points__m4els3($this, value) {
    if ($this.a3q_1.o() > 0) {
      $this.s1z();
    }
    $this.a3q_1 = value;
    $this.f3q();
    $this.s1z();
    $this.v1z();
  }
  function drawImpl($this, context, lineColor, fillColor) {
    var oldColor = context.t1y_1.m1t();
    if ($this.s2c() && !(fillColor == null)) {
      var tmp = DropShadow_instance;
      var tmp_0 = $this.n2h();
      tmp.v2m(context, tmp_0, AbstractCurveComponent$drawImpl$lambda(context, $this));
    }
    if (!(fillColor == null)) {
      context.t1y_1.l1t(fillColor);
      context.t1y_1.u1u($this.g3q());
    }
    context.t1y_1.l1t(lineColor);
    context.t1y_1.o1t($this.v1t());
    context.t1y_1.t1u($this.g3q());
    context.t1y_1.l1t(oldColor);
  }
  function doInvalidating($this, logic) {
    if ($this.h3q().o() === $this.d2k()) {
      $this.s1z();
    }
    logic();
    $this.f3q();
    $this.s1z();
    $this.v1z();
  }
  function setPointsImpl($this, newPoints) {
    // Inline function 'kotlin.collections.mutableListOf' call
    var p = ArrayList_init_$Create$_0();
    p.f1(newPoints);
    _set__points__m4els3($this, p);
  }
  function AbstractCurveComponent$_set_location_$lambda_joojqt($value, this$0) {
    return function () {
      var dx = $value.in_1 - this$0.h3q().l(0).in_1;
      var dy = $value.jn_1 - this$0.h3q().l(0).jn_1;
      // Inline function 'kotlin.collections.forEachIndexed' call
      var index = 0;
      var _iterator__ex2g4s = toList(this$0.a3q_1).i();
      while (_iterator__ex2g4s.j()) {
        var item = _iterator__ex2g4s.k();
        var _unary__edvuaz = index;
        index = _unary__edvuaz + 1 | 0;
        var index_0 = checkIndexOverflow(_unary__edvuaz);
        this$0.a3q_1.u2(index_0, item.tn(dx, dy));
      }
      return Unit_instance;
    };
  }
  function AbstractCurveComponent$drawImpl$lambda($context, this$0) {
    return function (it) {
      $context.t1y_1.u1u(this$0.g3q());
      return Unit_instance;
    };
  }
  function AbstractCurveComponent$setPointAt$lambda(this$0, $index, $location) {
    return function () {
      this$0.a3q_1.u2($index, $location);
      return Unit_instance;
    };
  }
  function AbstractCurveComponent(points) {
    AbstractComponent_init_$Init$(VOID, VOID, this);
    var tmp = this;
    // Inline function 'kotlin.collections.mutableListOf' call
    tmp.a3q_1 = ArrayList_init_$Create$_0();
    // Inline function 'kotlin.require' call
    if (!(points.o() === this.d2k())) {
      var message = 'Points count must be ' + this.d2k() + ', but is ' + points.o();
      throw IllegalArgumentException_init_$Create$(toString(message));
    }
    setPointsImpl(this, points);
    this.c3q_1 = false;
    this.d3q_1 = false;
    this.e3q_1 = new TransparentImpl(this);
  }
  protoOf(AbstractCurveComponent).g3q = function () {
    var tmp = this.b3q_1;
    if (!(tmp == null))
      return tmp;
    else {
      throwUninitializedPropertyAccessException('path');
    }
  };
  protoOf(AbstractCurveComponent).i3q = function (value) {
    // Inline function 'kotlin.check' call
    if (!(value.o() === this.d2k())) {
      throw IllegalStateException_init_$Create$('Check failed.');
    }
    setPointsImpl(this, value);
  };
  protoOf(AbstractCurveComponent).h3q = function () {
    return this.a3q_1;
  };
  protoOf(AbstractCurveComponent).j3q = function (value) {
    if (!(this.c3q_1 === value)) {
      this.c3q_1 = value;
      if (!this.p37()) {
        this.p2h(this.hw().in_1);
      }
    }
  };
  protoOf(AbstractCurveComponent).k3q = function (value) {
    if (!(this.d3q_1 === value)) {
      this.d3q_1 = value;
      if (!this.p37()) {
        this.q2h(this.hw().jn_1);
      }
    }
  };
  protoOf(AbstractCurveComponent).f20 = function (value) {
    if (!this.hw().equals(value)) {
      doInvalidating(this, AbstractCurveComponent$_set_location_$lambda_joojqt(value, this));
    }
  };
  protoOf(AbstractCurveComponent).hw = function () {
    return this.a3q_1.l(0);
  };
  protoOf(AbstractCurveComponent).k2h = function (value) {
    this.e3q_1.k2h(value);
  };
  protoOf(AbstractCurveComponent).n2h = function () {
    return this.e3q_1.m2h_1;
  };
  protoOf(AbstractCurveComponent).x2h = function () {
    return false;
  };
  protoOf(AbstractCurveComponent).p2h = function (x) {
    // Inline function 'kotlin.collections.map' call
    var this_0 = this.h3q();
    // Inline function 'kotlin.collections.mapTo' call
    var destination = ArrayList_init_$Create$(collectionSizeOrDefault(this_0, 10));
    var _iterator__ex2g4s = this_0.i();
    while (_iterator__ex2g4s.j()) {
      var item = _iterator__ex2g4s.k();
      var tmp$ret$2 = item.q1g(x);
      destination.h(tmp$ret$2);
    }
    this.i3q(destination);
  };
  protoOf(AbstractCurveComponent).q2h = function (y) {
    // Inline function 'kotlin.collections.map' call
    var this_0 = this.h3q();
    // Inline function 'kotlin.collections.mapTo' call
    var destination = ArrayList_init_$Create$(collectionSizeOrDefault(this_0, 10));
    var _iterator__ex2g4s = this_0.i();
    while (_iterator__ex2g4s.j()) {
      var item = _iterator__ex2g4s.k();
      var tmp$ret$2 = item.r1g(y);
      destination.h(tmp$ret$2);
    }
    this.i3q(destination);
  };
  protoOf(AbstractCurveComponent).t3a = function () {
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [new SnappableXCoordinate(this.h3q().l(0).in_1), new SnappableXCoordinate(this.h3q().l(2).in_1)];
  };
  protoOf(AbstractCurveComponent).u3a = function () {
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [new SnappableYCoordinate(this.h3q().l(0).jn_1), new SnappableYCoordinate(this.h3q().l(2).jn_1)];
  };
  protoOf(AbstractCurveComponent).s37 = function (reader) {
    protoOf(AbstractComponent).s37.call(this, reader);
    // Inline function 'kotlin.collections.mutableListOf' call
    var p = ArrayList_init_$Create$_0();
    p.f1(reader.g38('points'));
    _set__points__m4els3(this, p);
    if (reader.d35('mirrorH')) {
      this.j3q(reader.d38('mirrorH'));
    }
    if (reader.d35('mirrorV')) {
      this.k3q(reader.d38('mirrorV'));
    }
  };
  protoOf(AbstractCurveComponent).r37 = function (writer) {
    protoOf(AbstractComponent).r37.call(this, writer);
    writer.b39('points', this.h3q());
    if (this.c3q_1) {
      writer.y38('mirrorH', this.c3q_1);
    }
    if (this.d3q_1) {
      writer.y38('mirrorV', this.d3q_1);
    }
  };
  protoOf(AbstractCurveComponent).do = function () {
    return this.g3q().do();
  };
  protoOf(AbstractCurveComponent).eo = function (x, y) {
    return this.g3q().go(x - 2.0, y - 2.0, 2 * 2.0, 2 * 2.0);
  };
  protoOf(AbstractCurveComponent).r1z = function (context) {
    if (context.w1y_1) {
      drawImpl(this, context, ensureNotNull(context.x1y_1).h1x_1, this.p2c() ? ensureNotNull(context.x1y_1).i1x_1 : null);
    } else {
      drawImpl(this, context, this.e3q_1.v2g(this.i2c()), this.p2c() ? this.e3q_1.v2g(this.j2c()) : null);
    }
  };
  protoOf(AbstractCurveComponent).p3a = function () {
    return SelectionDrawingStrategy_ABOVE_getInstance();
  };
  protoOf(AbstractCurveComponent).e2k = function (index) {
    return this.h3q().l(index);
  };
  protoOf(AbstractCurveComponent).l3q = function (index, location) {
    // Inline function 'kotlin.require' call
    if (!(0 <= index ? index < this.d2k() : false)) {
      var message = 'index ' + index + ' not in range 0..' + this.d2k();
      throw IllegalArgumentException_init_$Create$(toString(message));
    }
    doInvalidating(this, AbstractCurveComponent$setPointAt$lambda(this, index, location));
  };
  function _get_LOG__e5r759_4($this) {
    var tmp0 = $this.m3q_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('LOG', 1, tmp, AbstractCurveHandleSelectionModel$Companion$_get_LOG_$ref_whlqcy(), null);
    return tmp0.j2();
  }
  function AbstractCurveHandleSelectionModel$Companion$_get_LOG_$ref_whlqcy() {
    return function (p0) {
      return _get_LOG__e5r759_4(p0);
    };
  }
  function Companion_10() {
    Companion_instance_15 = this;
    this.m3q_1 = logger(getKClass(AbstractCurveHandleSelectionModel));
    var tmp = this;
    // Inline function 'kotlin.floatArrayOf' call
    var tmp$ret$0 = new Float32Array([2.0, 4.0]);
    tmp.n3q_1 = new Stroke(0.5, VOID, VOID, VOID, tmp$ret$0);
  }
  var Companion_instance_15;
  function Companion_getInstance_20() {
    if (Companion_instance_15 == null)
      new Companion_10();
    return Companion_instance_15;
  }
  function createHandles($this) {
    $this.y3q();
    var inductionVariable = 0;
    var last = $this.z3q();
    if (inductionVariable < last)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        $this.l3r(new RectangularHandle($this.k3r_1));
      }
       while (inductionVariable < last);
    $this.v3q_1 = $this.z3q();
  }
  function CurveEventHandler($outer) {
    this.q3r_1 = $outer;
    EventHandler.call(this, $outer);
    this.p3r_1 = Companion_getInstance().g1a_1;
  }
  protoOf(CurveEventHandler).r3r = function (view) {
    var index = this.q3r_1.v3r(ensureNotNull(this.t3r_1));
    this.p3r_1 = Point2D_init_$Create$(this.q3r_1.b3s().e2k(index));
  };
  protoOf(CurveEventHandler).c3s = function (context) {
    var index = this.q3r_1.v3r(ensureNotNull(this.t3r_1));
    var newLocation = this.q3r_1.b3s().e2k(index);
    _get_LOG__e5r759_4(Companion_getInstance_20()).il('Move point ' + index + " of '" + this.q3r_1.b3s().u19() + "' " + this.q3r_1.b3s().av() + ' to ' + newLocation.toString());
    context.e3c_1.l3c().e3a(new MoveCurvePointCommand(context.e3c_1.f1o(), this.q3r_1.b3s().av(), index, this.p3r_1, newLocation));
  };
  function QuadCurveInputEventHandler($outer) {
    this.k3s_1 = $outer;
    InputEventHandlerAdapter.call(this);
  }
  protoOf(QuadCurveInputEventHandler).f3s = function (context) {
    context.x21_1.v1x(Cursor_CROSSHAIR_getInstance());
    return this;
  };
  protoOf(QuadCurveInputEventHandler).j22 = function (context) {
    return this.f3s(context instanceof EditInputEventContext ? context : THROW_CCE());
  };
  protoOf(QuadCurveInputEventHandler).h3s = function (context) {
    var tmp = this.k3s_1.b3s();
    var tmp_0 = this.k3s_1.l3s();
    tmp.l3q(this.k3s_1.v3r(ensureNotNull((tmp_0 instanceof CurveEventHandler ? tmp_0 : THROW_CCE()).t3r_1)), new Point2D(context.a22_1, context.b22_1));
    return this;
  };
  protoOf(QuadCurveInputEventHandler).l22 = function (context) {
    return this.h3s(context instanceof EditInputEventContext ? context : THROW_CCE());
  };
  function AbstractCurveHandleSelectionModel(c) {
    Companion_getInstance_20();
    AbstractHandleSelectionModel.call(this, c);
    this.k3r_1 = new QuadCurveInputEventHandler(this);
  }
  protoOf(AbstractCurveHandleSelectionModel).m3s = function () {
    return new CurveEventHandler(this);
  };
  protoOf(AbstractCurveHandleSelectionModel).n3s = function () {
    if (!(this.v3q_1 === this.z3q())) {
      createHandles(this);
    }
    var inductionVariable = 0;
    var last = this.z3q();
    if (inductionVariable < last)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        this.o3s(i).f20(this.b3s().e2k(i));
      }
       while (inductionVariable < last);
  };
  function Companion_11() {
    Companion_instance_16 = this;
    this.x3s_1 = Translations_getInstance().zm('edit.component.cubicCurve', []);
    this.y3s_1 = listOf_0([Point2D_init_$Create$_0(0, 0), Point2D_init_$Create$_0(100, 100), Point2D_init_$Create$_0(200, 100), Point2D_init_$Create$_0(200, 0)]);
  }
  var Companion_instance_16;
  function Companion_getInstance_21() {
    if (Companion_instance_16 == null)
      new Companion_11();
    return Companion_instance_16;
  }
  function CubicCurveComponent(points) {
    Companion_getInstance_21();
    points = points === VOID ? Companion_getInstance_21().y3s_1 : points;
    AbstractCurveComponent.call(this, points);
  }
  protoOf(CubicCurveComponent).u19 = function () {
    return Companion_getInstance_21().x3s_1;
  };
  protoOf(CubicCurveComponent).d2k = function () {
    return 4;
  };
  protoOf(CubicCurveComponent).f3q = function () {
    // Inline function 'kotlin.check' call
    if (!(this.h3q().o() === this.d2k())) {
      throw IllegalStateException_init_$Create$('Check failed.');
    }
    this.b3q_1 = System_getInstance().am();
    this.g3q().sn(this.h3q().l(0).in_1, this.h3q().l(0).jn_1);
    this.g3q().ao(this.h3q().l(1).in_1, this.h3q().l(1).jn_1, this.h3q().l(2).in_1, this.h3q().l(2).jn_1, this.h3q().l(3).in_1, this.h3q().l(3).jn_1);
  };
  function drawTangents($this, context) {
    context.t1y_1.o1t(Companion_getInstance_20().n3q_1);
    context.t1y_1.l1t(DrawModule_getInstance().v29_1.j1z('select.handle.color.border'));
    var tmp = $this.o3s(0);
    var tmp_0 = (tmp instanceof AbstractRectangularUnzoomable ? tmp : THROW_CCE()).a2c();
    var tmp_1 = $this.o3s(1);
    context.t1y_1.l1v(tmp_0, (tmp_1 instanceof AbstractRectangularUnzoomable ? tmp_1 : THROW_CCE()).a2c());
    var tmp_2 = $this.o3s(3);
    var tmp_3 = (tmp_2 instanceof AbstractRectangularUnzoomable ? tmp_2 : THROW_CCE()).a2c();
    var tmp_4 = $this.o3s(2);
    context.t1y_1.l1v(tmp_3, (tmp_4 instanceof AbstractRectangularUnzoomable ? tmp_4 : THROW_CCE()).a2c());
  }
  function CubicCurveHandleSelectionModel(c) {
    AbstractCurveHandleSelectionModel.call(this, c);
  }
  protoOf(CubicCurveHandleSelectionModel).z3q = function () {
    return 4;
  };
  protoOf(CubicCurveHandleSelectionModel).r1z = function (context) {
    drawTangents(this, context);
    protoOf(AbstractCurveHandleSelectionModel).r1z.call(this, context);
  };
  function CubicCurveReplaceSelectionModel(component) {
    AbstractSelectedColorWrappingSelectionModel.call(this, component);
  }
  protoOf(CubicCurveReplaceSelectionModel).g3u = function (component) {
    return new CubicCurveHandleSelectionModel(component);
  };
  protoOf(CubicCurveReplaceSelectionModel).h3u = function (component) {
    return this.g3u(component instanceof CubicCurveComponent ? component : THROW_CCE());
  };
  function EditModuleCurveModule$initialize$lambda(it) {
    return new QuadCurveReplaceSelectionModel(it instanceof QuadCurveComponent ? it : THROW_CCE());
  }
  function EditModuleCurveModule$initialize$lambda_0(it) {
    return new CubicCurveReplaceSelectionModel(it instanceof CubicCurveComponent ? it : THROW_CCE());
  }
  function EditModuleCurveModule() {
    EditModuleCurveModule_instance = this;
    AbstractModule.call(this);
  }
  protoOf(EditModuleCurveModule).ro = function () {
    var tmp = EditSelectModule_getInstance().b3l_1;
    var tmp_0 = SelectionDrawingStrategy_ABOVE_getInstance();
    var tmp_1 = getKClass(QuadCurveComponent);
    tmp.w3u(tmp_0, tmp_1, EditModuleCurveModule$initialize$lambda);
    var tmp_2 = EditSelectModule_getInstance().b3l_1;
    var tmp_3 = SelectionDrawingStrategy_ABOVE_getInstance();
    var tmp_4 = getKClass(CubicCurveComponent);
    tmp_2.w3u(tmp_3, tmp_4, EditModuleCurveModule$initialize$lambda_0);
  };
  var EditModuleCurveModule_instance;
  function EditModuleCurveModule_getInstance() {
    if (EditModuleCurveModule_instance == null)
      new EditModuleCurveModule();
    return EditModuleCurveModule_instance;
  }
  function _get_curve__isum2m($this) {
    var tmp = ensureNotNull($this.b3v_1.e3b().y3a($this.c3v_1)).n3a();
    return tmp instanceof AbstractCurveComponent ? tmp : THROW_CCE();
  }
  function MoveCurvePointCommand(drawingView, curveId, index, oldLocation, newLocation) {
    AbstractDrawingViewCommand.call(this, 'edit.model.polyline.movePoint', drawingView);
    this.b3v_1 = drawingView;
    this.c3v_1 = curveId;
    this.d3v_1 = index;
    this.e3v_1 = oldLocation;
    this.f3v_1 = newLocation;
  }
  protoOf(MoveCurvePointCommand).s39 = function () {
    _get_curve__isum2m(this).l3q(this.d3v_1, this.f3v_1);
  };
  protoOf(MoveCurvePointCommand).w39 = function () {
    _get_curve__isum2m(this).l3q(this.d3v_1, this.e3v_1);
  };
  function Companion_12() {
    Companion_instance_17 = this;
    this.g3v_1 = Translations_getInstance().zm('edit.component.quadraticCurve', []);
    this.h3v_1 = listOf_0([Point2D_init_$Create$_0(0, 0), Point2D_init_$Create$_0(100, 100), Point2D_init_$Create$_0(200, 0)]);
  }
  var Companion_instance_17;
  function Companion_getInstance_22() {
    if (Companion_instance_17 == null)
      new Companion_12();
    return Companion_instance_17;
  }
  function QuadCurveComponent(points) {
    Companion_getInstance_22();
    points = points === VOID ? Companion_getInstance_22().h3v_1 : points;
    AbstractCurveComponent.call(this, points);
  }
  protoOf(QuadCurveComponent).u19 = function () {
    return Companion_getInstance_22().g3v_1;
  };
  protoOf(QuadCurveComponent).d2k = function () {
    return 3;
  };
  protoOf(QuadCurveComponent).f3q = function () {
    // Inline function 'kotlin.check' call
    if (!(this.h3q().o() === this.d2k())) {
      throw IllegalStateException_init_$Create$('Check failed.');
    }
    this.b3q_1 = System_getInstance().am();
    this.g3q().sn(this.h3q().l(0).in_1, this.h3q().l(0).jn_1);
    this.g3q().zn(this.h3q().l(1).in_1, this.h3q().l(1).jn_1, this.h3q().l(2).in_1, this.h3q().l(2).jn_1);
  };
  function drawTangents_0($this, context) {
    context.t1y_1.o1t(Companion_getInstance_20().n3q_1);
    context.t1y_1.l1t(DrawModule_getInstance().v29_1.j1z('select.handle.color.border'));
    var tmp = $this.o3s(0);
    var tmp_0 = (tmp instanceof AbstractRectangularUnzoomable ? tmp : THROW_CCE()).a2c();
    var tmp_1 = $this.o3s(1);
    context.t1y_1.l1v(tmp_0, (tmp_1 instanceof AbstractRectangularUnzoomable ? tmp_1 : THROW_CCE()).a2c());
    var tmp_2 = $this.o3s(1);
    var tmp_3 = (tmp_2 instanceof AbstractRectangularUnzoomable ? tmp_2 : THROW_CCE()).a2c();
    var tmp_4 = $this.o3s(2);
    context.t1y_1.l1v(tmp_3, (tmp_4 instanceof AbstractRectangularUnzoomable ? tmp_4 : THROW_CCE()).a2c());
  }
  function QuadCurveHandleSelectionModel(c) {
    AbstractCurveHandleSelectionModel.call(this, c);
  }
  protoOf(QuadCurveHandleSelectionModel).z3q = function () {
    return 3;
  };
  protoOf(QuadCurveHandleSelectionModel).r1z = function (context) {
    drawTangents_0(this, context);
    protoOf(AbstractCurveHandleSelectionModel).r1z.call(this, context);
  };
  function QuadCurveReplaceSelectionModel(component) {
    AbstractSelectedColorWrappingSelectionModel.call(this, component);
  }
  protoOf(QuadCurveReplaceSelectionModel).p3w = function (component) {
    return new QuadCurveHandleSelectionModel(component);
  };
  protoOf(QuadCurveReplaceSelectionModel).h3u = function (component) {
    return this.p3w(component instanceof QuadCurveComponent ? component : THROW_CCE());
  };
  function EditModelGroupModule$initialize$lambda(it) {
    return new GroupComponentSelectionModel(it instanceof GroupComponent ? it : THROW_CCE());
  }
  function EditModelGroupModule() {
    EditModelGroupModule_instance = this;
    AbstractModule.call(this);
  }
  protoOf(EditModelGroupModule).ro = function () {
    var tmp = EditSelectModule_getInstance().b3l_1;
    var tmp_0 = SelectionDrawingStrategy_REPLACE_getInstance();
    var tmp_1 = getKClass(GroupComponent);
    tmp.w3u(tmp_0, tmp_1, EditModelGroupModule$initialize$lambda);
  };
  var EditModelGroupModule_instance;
  function EditModelGroupModule_getInstance() {
    if (EditModelGroupModule_instance == null)
      new EditModelGroupModule();
    return EditModelGroupModule_instance;
  }
  function Companion_13() {
    Companion_instance_18 = this;
    this.r3w_1 = Translations_getInstance().zm('edit.component.group', []);
  }
  var Companion_instance_18;
  function Companion_getInstance_23() {
    if (Companion_instance_18 == null)
      new Companion_13();
    return Companion_instance_18;
  }
  function updateBoundingBox($this) {
    // Inline function 'kotlin.collections.isNotEmpty' call
    if (!$this.d3x().m()) {
      $this.c3x_1.w1b($this.d3x().l(0).do());
      var inductionVariable = 1;
      var last = $this.d3x().o();
      if (inductionVariable < last)
        do {
          var i = inductionVariable;
          inductionVariable = inductionVariable + 1 | 0;
          $this.c3x_1.x1b($this.d3x().l(i).do());
        }
         while (inductionVariable < last);
    }
  }
  function GroupComponent(components) {
    Companion_getInstance_23();
    var tmp;
    if (components === VOID) {
      // Inline function 'kotlin.collections.listOf' call
      tmp = emptyList();
    } else {
      tmp = components;
    }
    components = tmp;
    AbstractComponent_init_$Init$(VOID, VOID, this);
    var tmp_0 = this;
    // Inline function 'kotlin.collections.mutableListOf' call
    tmp_0.b3x_1 = ArrayList_init_$Create$_0();
    this.c3x_1 = new Rectangle2D();
    this.b3x_1.f1(components);
    updateBoundingBox(this);
  }
  protoOf(GroupComponent).d3x = function () {
    return this.b3x_1;
  };
  protoOf(GroupComponent).u19 = function () {
    return Companion_getInstance_23().r3w_1;
  };
  protoOf(GroupComponent).f20 = function (value) {
    this.s1z();
    var offsetX = value.in_1 - this.c3x_1.e1h_1;
    var offsetY = value.jn_1 - this.c3x_1.f1h_1;
    this.c3x_1.s1b(value.in_1, value.jn_1, this.c3x_1.g1h_1, this.c3x_1.h1h_1);
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = this.d3x().i();
    while (_iterator__ex2g4s.j()) {
      var element = _iterator__ex2g4s.k();
      element.f20(element.hw().tn(offsetX, offsetY));
    }
    this.s1z();
    this.v1z();
  };
  protoOf(GroupComponent).hw = function () {
    return new Point2D(this.c3x_1.e1h_1, this.c3x_1.f1h_1);
  };
  protoOf(GroupComponent).do = function () {
    return Rectangle2D_init_$Create$(this.c3x_1);
  };
  protoOf(GroupComponent).r1z = function (context) {
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = asReversed(this.d3x()).i();
    while (_iterator__ex2g4s.j()) {
      var element = _iterator__ex2g4s.k();
      element.r1z(context);
    }
  };
  protoOf(GroupComponent).eo = function (x, y) {
    var tmp0 = this.d3x();
    var tmp$ret$0;
    $l$block_0: {
      // Inline function 'kotlin.collections.any' call
      var tmp;
      if (isInterface(tmp0, Collection)) {
        tmp = tmp0.m();
      } else {
        tmp = false;
      }
      if (tmp) {
        tmp$ret$0 = false;
        break $l$block_0;
      }
      var _iterator__ex2g4s = tmp0.i();
      while (_iterator__ex2g4s.j()) {
        var element = _iterator__ex2g4s.k();
        if (element.eo(x, y)) {
          tmp$ret$0 = true;
          break $l$block_0;
        }
      }
      tmp$ret$0 = false;
    }
    return tmp$ret$0;
  };
  protoOf(GroupComponent).r37 = function (writer) {
    protoOf(AbstractComponent).r37.call(this, writer);
    writer.r38('component', this.d3x().i());
  };
  protoOf(GroupComponent).s37 = function (reader) {
    protoOf(AbstractComponent).s37.call(this, reader);
    this.b3x_1.a2();
    this.b3x_1.f1(reader.x37('component'));
    updateBoundingBox(this);
  };
  function GroupComponentSelectionModel(model, provider) {
    provider = provider === VOID ? EditSelectModule_getInstance().c3l_1 : provider;
    AbstractSelectionModel.call(this, model);
    this.j3x_1 = provider;
    var tmp = this;
    // Inline function 'kotlin.collections.mutableMapOf' call
    tmp.k3x_1 = LinkedHashMap_init_$Create$();
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = this.b3s().d3x().i();
    while (_iterator__ex2g4s.j()) {
      var element = _iterator__ex2g4s.k();
      var tmp0 = this.k3x_1;
      var tmp0_elvis_lhs = this.j3x_1.d3n(element, SelectionDrawingStrategy_REPLACE_getInstance());
      // Inline function 'kotlin.collections.set' call
      var value = tmp0_elvis_lhs == null ? new SelectedColorSelectionModel(element) : tmp0_elvis_lhs;
      tmp0.y1(element, value);
    }
  }
  protoOf(GroupComponentSelectionModel).do = function () {
    return this.b3s().do();
  };
  protoOf(GroupComponentSelectionModel).r1z = function (context) {
    var oldUseContextColors = context.w1y_1;
    context.w1y_1 = true;
    context.z1y_1 = Themes_getInstance().r2f().x3x_1.m1t();
    context.t1y_1.l1t(ensureNotNull(context.z1y_1).h1x_1);
    context.x1y_1 = context.z1y_1;
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = asReversed(this.b3s().d3x()).i();
    while (_iterator__ex2g4s.j()) {
      var element = _iterator__ex2g4s.k();
      ensureNotNull(this.k3x_1.g2(element)).r1z(context);
    }
    context.w1y_1 = oldUseContextColors;
  };
  protoOf(GroupComponentSelectionModel).eo = function (x, y) {
    return this.b3s().eo(x, y);
  };
  protoOf(GroupComponentSelectionModel).r3s = function () {
  };
  function Companion_14() {
    this.c3y_1 = 100.0;
    this.d3y_1 = 50.0;
  }
  var Companion_instance_19;
  function Companion_getInstance_24() {
    return Companion_instance_19;
  }
  function drawImage($this, context) {
    var scaleX = $this.p1b() / ensureNotNull($this.f3z_1.j2()).o3y_1.p1b();
    var scaleY = $this.r1b() / ensureNotNull($this.f3z_1.j2()).o3y_1.r1b();
    // Inline function 'io.antarescircuit.jabbah.draw.DrawContext.translated' call
    var d = $this.hw();
    context.t1y_1.v1c(d.in_1, d.jn_1);
    context.t1y_1.x1c(scaleX, scaleY);
    context.t1y_1.y1u(ensureNotNull($this.f3z_1.j2()).o3y_1, 0, 0);
    context.t1y_1.x1c(1 / scaleX, 1 / scaleY);
    context.t1y_1.v1c(-d.in_1, -d.jn_1);
  }
  function initializeGeometry($this) {
    if (!($this.f3z_1.j2() == null)) {
      $this.s1b($this.z19(), $this.a1a(), ensureNotNull($this.f3z_1.j2()).o3y_1.p1b(), ensureNotNull($this.f3z_1.j2()).o3y_1.r1b());
    } else {
      $this.s1b($this.z19(), $this.a1a(), 100.0, 50.0);
    }
  }
  function updateGeometry($this) {
    if (!($this.f3z_1.j2() == null)) {
      $this.s1b($this.z19(), $this.a1a(), $this.p1b(), $this.r1b());
    } else {
      $this.s1b($this.z19(), $this.a1a(), 100.0, 50.0);
    }
  }
  function ImageComponent$imageData$lambda(this$0) {
    return function () {
      var tmp0_safe_receiver = this$0.e3z_1;
      var tmp;
      if (tmp0_safe_receiver == null) {
        tmp = null;
      } else {
        // Inline function 'kotlin.let' call
        tmp = EditModule_getInstance().k3f_1.v3z(tmp0_safe_receiver);
      }
      return tmp;
    };
  }
  function ImageComponent$type$delegate$lambda() {
    return Translations_getInstance().zm('edit.component.image', []);
  }
  function ImageComponent$_get_type_$ref_bx7542() {
    return function (p0) {
      return p0.u19();
    };
  }
  function ImageComponent(uuid) {
    uuid = uuid === VOID ? null : uuid;
    RectangleComponent.call(this);
    this.e3z_1 = uuid;
    var tmp = this;
    tmp.f3z_1 = resettableLazy(ImageComponent$imageData$lambda(this));
    initializeGeometry(this);
    var tmp_0 = this;
    tmp_0.g3z_1 = lazy(ImageComponent$type$delegate$lambda);
  }
  protoOf(ImageComponent).w3z = function (value) {
    if (!equals(this.e3z_1, value)) {
      this.s1z();
      this.e3z_1 = value;
      this.f3z_1.bu();
      updateGeometry(this);
      this.s1z();
      this.v1z();
    }
  };
  protoOf(ImageComponent).x2h = function () {
    return true;
  };
  protoOf(ImageComponent).u19 = function () {
    var tmp0 = this.g3z_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('type', 1, tmp, ImageComponent$_get_type_$ref_bx7542(), null);
    return tmp0.j2();
  };
  protoOf(ImageComponent).s37 = function (reader) {
    protoOf(RectangleComponent).s37.call(this, reader);
    this.w3z(new UUID(reader.b38('uuid')));
  };
  protoOf(ImageComponent).r37 = function (writer) {
    protoOf(RectangleComponent).r37.call(this, writer);
    writer.w38('uuid', toString_0(this.e3z_1));
  };
  protoOf(ImageComponent).x3z = function () {
    return true;
  };
  protoOf(ImageComponent).y3z = function (context, strokeColor, fillColor) {
    if (!(this.f3z_1.j2() == null)) {
      drawImage(this, context);
    } else {
      protoOf(RectangleComponent).y3z.call(this, context, strokeColor, fillColor);
      if (!(strokeColor == null)) {
        context.t1y_1.l1t(strokeColor);
        context.t1y_1.o1t(this.v1t());
        context.t1y_1.d1u(this.z19(), this.a1a(), this.z19() + this.p1b(), this.a1a() + this.r1b());
        context.t1y_1.d1u(this.z19(), this.a1a() + this.r1b(), this.z19() + this.p1b(), this.a1a());
      }
    }
  };
  protoOf(ImageComponent).z3z = function (context, strokeColor, fillColor) {
  };
  protoOf(ImageComponent).a40 = function (context) {
    context.t1y_1.l1t(ensureNotNull(context.x1y_1).h1x_1);
    protoOf(RectangleComponent).y3z.call(this, context, ensureNotNull(context.x1y_1).h1x_1, null);
  };
  function ImageIdentification$_get_name_$ref_birc7e() {
    return function (p0) {
      return p0.m2();
    };
  }
  function ImageIdentification$_set_name_$ref_obnno6() {
    return function (p0, p1) {
      p0.k3p(p1);
      return Unit_instance;
    };
  }
  function ImageIdentification$_get_name_$ref_birc7e_0() {
    return function (p0) {
      return p0.m2();
    };
  }
  function ImageIdentification$_set_name_$ref_obnno6_0() {
    return function (p0, p1) {
      p0.k3p(p1);
      return Unit_instance;
    };
  }
  function ImageIdentification(uuid, imageType, name) {
    uuid = uuid === VOID ? new UUID('undefined') : uuid;
    imageType = imageType === VOID ? ImageType_SVG_getInstance() : imageType;
    name = name === VOID ? new Name(new TranslatableText()) : name;
    AbstractStorable.call(this);
    this.l40_1 = uuid;
    this.m40_1 = imageType;
    this.n40_1 = observableName(name);
  }
  protoOf(ImageIdentification).k3p = function (_set____db54di) {
    var tmp = KMutableProperty1;
    var tmp_0 = ImageIdentification$_get_name_$ref_birc7e_0();
    return this.n40_1.xf(this, getPropertyCallableRef('name', 1, tmp, tmp_0, ImageIdentification$_set_name_$ref_obnno6_0()), _set____db54di);
  };
  protoOf(ImageIdentification).m2 = function () {
    var tmp = KMutableProperty1;
    var tmp_0 = ImageIdentification$_get_name_$ref_birc7e();
    return this.n40_1.vf(this, getPropertyCallableRef('name', 1, tmp, tmp_0, ImageIdentification$_set_name_$ref_obnno6()));
  };
  protoOf(ImageIdentification).s37 = function (reader) {
    this.l40_1 = new UUID(reader.b38('uuid'));
    this.m40_1 = Companion_instance_2.r1e(reader.b38('type'));
    this.k3p(Companion_instance_40.o40('name', reader));
  };
  protoOf(ImageIdentification).r37 = function (writer) {
    writer.w38('uuid', this.l40_1.toString());
    writer.w38('type', this.m40_1.g1r_1);
    this.m2().q40('name', writer);
  };
  protoOf(ImageIdentification).k37 = function (reference, referenceResolver) {
  };
  protoOf(ImageIdentification).toString = function () {
    return this.m2().j2();
  };
  protoOf(ImageIdentification).equals = function (other) {
    if (this === other)
      return true;
    if (other == null || !getKClassFromExpression(this).equals(getKClassFromExpression(other)))
      return false;
    if (!(other instanceof ImageIdentification))
      THROW_CCE();
    if (!this.l40_1.equals(other.l40_1))
      return false;
    if (!this.m40_1.equals(other.m40_1))
      return false;
    if (!this.m2().equals(other.m2()))
      return false;
    return true;
  };
  protoOf(ImageIdentification).hashCode = function () {
    var result = this.l40_1.hashCode();
    result = imul(31, result) + this.m40_1.hashCode() | 0;
    result = imul(31, result) + this.m2().hashCode() | 0;
    return result;
  };
  function ImageData(image, name) {
    this.o3y_1 = image;
    this.p3y_1 = name;
  }
  protoOf(ImageData).toString = function () {
    return 'ImageData(image=' + toString(this.o3y_1) + ', name=' + this.p3y_1.toString() + ')';
  };
  protoOf(ImageData).hashCode = function () {
    var result = hashCode(this.o3y_1);
    result = imul(result, 31) + this.p3y_1.hashCode() | 0;
    return result;
  };
  protoOf(ImageData).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof ImageData))
      return false;
    if (!equals(this.o3y_1, other.o3y_1))
      return false;
    if (!this.p3y_1.equals(other.p3y_1))
      return false;
    return true;
  };
  function _get_polyline__sh9y4r($this) {
    var tmp = ensureNotNull(ensureNotNull($this.p3g_1).e3b().y3a($this.u40_1)).n3a();
    return tmp instanceof PolylineComponent ? tmp : THROW_CCE();
  }
  function AddPolylinePointCommand(editor, polylineId, index, location) {
    AbstractCommand.call(this, 'edit.model.polyline.addPoint', editor);
    this.u40_1 = polylineId;
    this.v40_1 = index;
    this.w40_1 = location;
  }
  protoOf(AddPolylinePointCommand).s39 = function () {
    _get_polyline__sh9y4r(this).j2q(this.v40_1, this.w40_1.in_1, this.w40_1.jn_1);
  };
  protoOf(AddPolylinePointCommand).w39 = function () {
    _get_polyline__sh9y4r(this).k2q(this.v40_1);
  };
  function CompactablePolyline_init_$Init$($this) {
    // Inline function 'kotlin.collections.listOf' call
    var tmp$ret$0 = emptyList();
    CompactablePolyline.call($this, tmp$ret$0);
    return $this;
  }
  function CompactablePolyline_init_$Create$() {
    return CompactablePolyline_init_$Init$(objectCreate(protoOf(CompactablePolyline)));
  }
  function Companion_15() {
    this.k41_1 = 0.1;
  }
  var Companion_instance_20;
  function Companion_getInstance_25() {
    return Companion_instance_20;
  }
  function updateBoundingBox_0($this) {
    if ($this.l41_1.o() > 0) {
      $this.m41_1.s1b($this.l41_1.l(0).in_1, $this.l41_1.l(0).jn_1, 1.0, 1.0);
    }
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = $this.l41_1.i();
    while (_iterator__ex2g4s.j()) {
      var element = _iterator__ex2g4s.k();
      $this.m41_1.co(element);
    }
    $this.m41_1.s1b($this.m41_1.e1h_1, $this.m41_1.f1h_1, $this.m41_1.g1h_1, $this.m41_1.h1h_1);
  }
  function canCompactPoint($this, i) {
    if ($this.l41_1.l(i).equals($this.l41_1.l(i - 1 | 0))) {
      return true;
    }
    if (i > ($this.l41_1.o() - 2 | 0)) {
      return false;
    }
    var angle1 = Geometry_instance.a1g(Companion_getInstance().g1a_1, Geometry_instance.c1g($this.l41_1.l(i - 1 | 0).in_1, $this.l41_1.l(i - 1 | 0).jn_1, $this.l41_1.l(i).in_1, $this.l41_1.l(i).jn_1));
    var angle2 = Geometry_instance.a1g(Companion_getInstance().g1a_1, Geometry_instance.c1g($this.l41_1.l(i).in_1, $this.h3q().l(i).jn_1, $this.l41_1.l(i + 1 | 0).in_1, $this.l41_1.l(i + 1 | 0).jn_1));
    var tmp;
    // Inline function 'kotlin.math.abs' call
    var x = angle1 - angle2;
    if (Math.abs(x) <= 0.1) {
      tmp = true;
    } else {
      // Inline function 'kotlin.math.abs' call
      var x_0 = angle1 - angle2;
      // Inline function 'kotlin.math.abs' call
      var x_1 = Math.abs(x_0) - 3.141592653589793;
      tmp = Math.abs(x_1) < 0.1;
    }
    return tmp;
  }
  function isSegmentHorizontal($this, index) {
    return Geometry_instance.x1f($this.l41_1.l(index).jn_1, $this.l41_1.l(index + 1 | 0).jn_1);
  }
  function isSegmentVertical($this, index) {
    return Geometry_instance.x1f($this.l41_1.l(index).in_1, $this.l41_1.l(index + 1 | 0).in_1);
  }
  function isSegmentOrthogonal($this, index) {
    return isSegmentHorizontal($this, index) || isSegmentVertical($this, index);
  }
  function CompactablePolyline(points) {
    var tmp = this;
    // Inline function 'kotlin.collections.mutableListOf' call
    tmp.l41_1 = ArrayList_init_$Create$_0();
    this.m41_1 = new Rectangle2D();
    this.n41(points);
  }
  protoOf(CompactablePolyline).h3q = function () {
    return this.l41_1;
  };
  protoOf(CompactablePolyline).o = function () {
    return this.l41_1.o();
  };
  protoOf(CompactablePolyline).do = function () {
    return Rectangle2D_init_$Create$(this.m41_1);
  };
  protoOf(CompactablePolyline).o41 = function () {
    return this.o() < 2 || this.l41_1.l(0).equals(this.l41_1.l(1));
  };
  protoOf(CompactablePolyline).p41 = function () {
    var tmp;
    if (!this.o41()) {
      var tmp0 = until(0, this.o() - 1 | 0);
      var tmp$ret$0;
      $l$block_0: {
        // Inline function 'kotlin.collections.all' call
        var tmp_0;
        if (isInterface(tmp0, Collection)) {
          tmp_0 = tmp0.m();
        } else {
          tmp_0 = false;
        }
        if (tmp_0) {
          tmp$ret$0 = true;
          break $l$block_0;
        }
        var inductionVariable = tmp0.y_1;
        var last = tmp0.z_1;
        if (inductionVariable <= last)
          do {
            var element = inductionVariable;
            inductionVariable = inductionVariable + 1 | 0;
            var it = element;
            if (!isSegmentOrthogonal(this, it)) {
              tmp$ret$0 = false;
              break $l$block_0;
            }
          }
           while (!(element === last));
        tmp$ret$0 = true;
      }
      tmp = tmp$ret$0;
    } else {
      tmp = false;
    }
    return tmp;
  };
  protoOf(CompactablePolyline).toString = function () {
    var s = StringBuilder_init_$Create$();
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = this.l41_1.i();
    while (_iterator__ex2g4s.j()) {
      var element = _iterator__ex2g4s.k();
      s.h7('(' + element.in_1 + ',' + element.jn_1 + ')');
    }
    return s.toString();
  };
  protoOf(CompactablePolyline).co = function (point) {
    this.n41(listOf(point));
    return this;
  };
  protoOf(CompactablePolyline).n41 = function (points) {
    // Inline function 'kotlin.collections.isNotEmpty' call
    if (!points.m()) {
      this.l41_1.f1(points);
      this.q41();
      updateBoundingBox_0(this);
    }
    return this;
  };
  protoOf(CompactablePolyline).l = function (index) {
    return this.l41_1.l(index);
  };
  protoOf(CompactablePolyline).r41 = function (segmentIndex) {
    if (this.o41()) {
      return null;
    }
    return Companion_getInstance_1().a1f(this.l41_1.l(segmentIndex), this.l41_1.l(segmentIndex + 1 | 0));
  };
  protoOf(CompactablePolyline).q41 = function () {
    if (this.l41_1.o() <= 2) {
      return Unit_instance;
    }
    var i = 1;
    while (i < this.l41_1.o()) {
      if (canCompactPoint(this, i)) {
        this.l41_1.h3(i);
      } else {
        i = i + 1 | 0;
      }
    }
  };
  function EditModelPolylineModule$initialize$lambda(it) {
    return new PolylineReplaceSelectionModel(it instanceof PolylineComponent ? it : THROW_CCE());
  }
  function EditModelPolylineModule() {
    EditModelPolylineModule_instance = this;
    AbstractModule.call(this);
  }
  protoOf(EditModelPolylineModule).ro = function () {
    var tmp = EditSelectModule_getInstance().b3l_1;
    var tmp_0 = SelectionDrawingStrategy_ABOVE_getInstance();
    var tmp_1 = getKClass(PolylineComponent);
    tmp.w3u(tmp_0, tmp_1, EditModelPolylineModule$initialize$lambda);
  };
  var EditModelPolylineModule_instance;
  function EditModelPolylineModule_getInstance() {
    if (EditModelPolylineModule_instance == null)
      new EditModelPolylineModule();
    return EditModelPolylineModule_instance;
  }
  function _get_polyline__sh9y4r_0($this) {
    var tmp = ensureNotNull(ensureNotNull($this.p3g_1).e3b().y3a($this.w41_1)).n3a();
    return tmp instanceof PolylineComponent ? tmp : THROW_CCE();
  }
  function JoinPolylinePointsCommand(editor, polylineId, index, oldLocation) {
    AbstractCommand.call(this, 'edit.model.polyline.joinPoints', editor);
    this.w41_1 = polylineId;
    this.x41_1 = index;
    this.y41_1 = oldLocation;
  }
  protoOf(JoinPolylinePointsCommand).s39 = function () {
    _get_polyline__sh9y4r_0(this).k2q(this.x41_1);
  };
  protoOf(JoinPolylinePointsCommand).w39 = function () {
    _get_polyline__sh9y4r_0(this).j2q(this.x41_1, this.y41_1.in_1, this.y41_1.jn_1);
  };
  function Companion_16() {
  }
  protoOf(Companion_16).z41 = function (editor, polyline, index, oldLocation) {
    return new MovePolylinePointCommand(editor, polyline.av(), index, oldLocation, polyline.e2k(index));
  };
  var Companion_instance_21;
  function Companion_getInstance_26() {
    return Companion_instance_21;
  }
  function _get_polyline__sh9y4r_1($this) {
    var tmp = ensureNotNull(ensureNotNull($this.p3g_1).e3b().y3a($this.d42_1)).n3a();
    return tmp instanceof PolylineComponent ? tmp : THROW_CCE();
  }
  function MovePolylinePointCommand(editor, polylineId, index, oldLocation, newLocation) {
    AbstractCommand.call(this, 'edit.model.polyline.movePoint', editor);
    this.d42_1 = polylineId;
    this.e42_1 = index;
    this.f42_1 = oldLocation;
    this.g42_1 = newLocation;
  }
  protoOf(MovePolylinePointCommand).s39 = function () {
    _get_polyline__sh9y4r_1(this).n2q(this.e42_1, this.g42_1.in_1, this.g42_1.jn_1);
  };
  protoOf(MovePolylinePointCommand).w39 = function () {
    _get_polyline__sh9y4r_1(this).n2q(this.e42_1, this.f42_1.in_1, this.f42_1.jn_1);
  };
  function Companion_17() {
    Companion_instance_22 = this;
    this.h42_1 = 'draw.property.polyline.arrow';
    this.i42_1 = Translations_getInstance().zm('edit.component.polyline', []);
  }
  var Companion_instance_22;
  function Companion_getInstance_27() {
    if (Companion_instance_22 == null)
      new Companion_17();
    return Companion_instance_22;
  }
  function updateEndLineTerminator($this) {
    if ($this.j41_1) {
      $this.g41_1.g2q(Companion_getInstance_2().s2p());
    } else {
      $this.g41_1.g2q(null);
    }
  }
  function PolylineComponent(polyline) {
    Companion_getInstance_27();
    polyline = polyline === VOID ? new PolylineDrawable() : polyline;
    AbstractComponent.call(this, polyline);
    this.g41_1 = polyline;
    this.h41_1 = false;
    this.i41_1 = false;
    this.j41_1 = false;
    new DrawableOwner(this, this.g41_1);
  }
  protoOf(PolylineComponent).j3q = function (value) {
    if (!(this.h41_1 === value)) {
      this.h41_1 = value;
      if (!this.p37()) {
        this.p2h(this.hw().in_1);
      }
    }
  };
  protoOf(PolylineComponent).k3q = function (value) {
    if (!(this.i41_1 === value)) {
      this.i41_1 = value;
      if (!this.p37()) {
        this.q2h(this.hw().jn_1);
      }
    }
  };
  protoOf(PolylineComponent).j42 = function (value) {
    if (!(this.j41_1 === value)) {
      this.s1z();
      this.j41_1 = value;
      updateEndLineTerminator(this);
      this.s1z();
      this.v1z();
    }
  };
  protoOf(PolylineComponent).f20 = function (value) {
    this.g41_1.f20(value);
  };
  protoOf(PolylineComponent).hw = function () {
    return this.g41_1.hw();
  };
  protoOf(PolylineComponent).k2h = function (value) {
    this.g41_1.k2h(value);
  };
  protoOf(PolylineComponent).n2h = function () {
    return this.g41_1.n2h();
  };
  protoOf(PolylineComponent).do = function () {
    var bb = this.g41_1.do();
    var tmp;
    if (this.s2c()) {
      tmp = isInterface(bb, MutableRectangularShape);
    } else {
      tmp = false;
    }
    if (tmp) {
      DropShadow_instance.w2m(bb, this.g20());
    }
    return bb;
  };
  protoOf(PolylineComponent).r1z = function (context) {
    this.g41_1.r1z(context);
  };
  protoOf(PolylineComponent).eo = function (x, y) {
    return this.g41_1.eo(x, y);
  };
  protoOf(PolylineComponent).p2h = function (x) {
    this.g41_1.p2h(x);
  };
  protoOf(PolylineComponent).q2h = function (y) {
    this.g41_1.q2h(y);
  };
  protoOf(PolylineComponent).u19 = function () {
    return Companion_getInstance_27().i42_1;
  };
  protoOf(PolylineComponent).p3a = function () {
    return SelectionDrawingStrategy_ABOVE_getInstance();
  };
  protoOf(PolylineComponent).t3a = function () {
    if (this.d2k() > 0) {
      // Inline function 'kotlin.arrayOf' call
      // Inline function 'kotlin.js.unsafeCast' call
      // Inline function 'kotlin.js.asDynamic' call
      return [new SnappableXCoordinate(this.g41_1.l2q().in_1)];
    }
    return protoOf(AbstractComponent).t3a.call(this);
  };
  protoOf(PolylineComponent).u3a = function () {
    if (this.d2k() > 0) {
      // Inline function 'kotlin.arrayOf' call
      // Inline function 'kotlin.js.unsafeCast' call
      // Inline function 'kotlin.js.asDynamic' call
      return [new SnappableYCoordinate(this.g41_1.l2q().jn_1)];
    }
    return protoOf(AbstractComponent).u3a.call(this);
  };
  protoOf(PolylineComponent).r37 = function (writer) {
    protoOf(AbstractComponent).r37.call(this, writer);
    writer.b39('points', this.g41_1.w2q(0, this.g41_1.d2k()));
    if (this.j41_1) {
      writer.y38('arrow', this.j41_1);
    }
    if (this.h41_1) {
      writer.y38('mirrorH', this.h41_1);
    }
    if (this.i41_1) {
      writer.y38('mirrorV', this.i41_1);
    }
  };
  protoOf(PolylineComponent).s37 = function (reader) {
    protoOf(AbstractComponent).s37.call(this, reader);
    this.g41_1.o2q(reader.g38('points'));
    if (reader.d35('arrow')) {
      this.j42(reader.d38('arrow'));
    }
    if (reader.d35('mirrorH')) {
      this.j3q(reader.d38('mirrorH'));
    }
    if (reader.d35('mirrorV')) {
      this.k3q(reader.d38('mirrorV'));
    }
  };
  protoOf(PolylineComponent).i2q = function () {
    return this.g41_1.i2q();
  };
  protoOf(PolylineComponent).a2 = function () {
    this.g41_1.a2();
  };
  protoOf(PolylineComponent).j2q = function (index, x, y) {
    return this.g41_1.j2q(index, x, y);
  };
  protoOf(PolylineComponent).k2q = function (index) {
    return this.g41_1.k2q(index);
  };
  protoOf(PolylineComponent).e2k = function (index) {
    return this.g41_1.e2k(index);
  };
  protoOf(PolylineComponent).l2q = function () {
    return this.g41_1.l2q();
  };
  protoOf(PolylineComponent).m2q = function () {
    return this.g41_1.m2q();
  };
  protoOf(PolylineComponent).n2q = function (index, x, y) {
    return this.g41_1.n2q(index, x, y);
  };
  protoOf(PolylineComponent).o2q = function (points) {
    return this.g41_1.o2q(points);
  };
  protoOf(PolylineComponent).p2q = function (x, y) {
    return this.g41_1.p2q(x, y);
  };
  protoOf(PolylineComponent).q2q = function (x, y, area) {
    return this.g41_1.q2q(x, y, area);
  };
  protoOf(PolylineComponent).s2q = function (x, y, area) {
    return this.g41_1.s2q(x, y, area);
  };
  protoOf(PolylineComponent).t2q = function (index) {
    return this.g41_1.t2q(index);
  };
  protoOf(PolylineComponent).u2q = function () {
    return this.g41_1.u2q();
  };
  protoOf(PolylineComponent).v2q = function (index) {
    return this.g41_1.v2q(index);
  };
  protoOf(PolylineComponent).w2q = function (startIndex, endIndex) {
    return this.g41_1.w2q(startIndex, endIndex);
  };
  protoOf(PolylineComponent).x2q = function (index) {
    return this.g41_1.x2q(index);
  };
  protoOf(PolylineComponent).y2q = function (index) {
    return this.g41_1.y2q(index);
  };
  protoOf(PolylineComponent).z2q = function (index) {
    return this.g41_1.z2q(index);
  };
  protoOf(PolylineComponent).a2r = function (index, otherIndex, other) {
    return this.g41_1.a2r(index, otherIndex, other);
  };
  protoOf(PolylineComponent).b2r = function (otherIndex, other) {
    return this.g41_1.b2r(otherIndex, other);
  };
  protoOf(PolylineComponent).d2k = function () {
    return this.g41_1.d2k();
  };
  protoOf(PolylineComponent).e2q = function (_set____db54di) {
    this.g41_1.e2q(_set____db54di);
  };
  protoOf(PolylineComponent).f2q = function () {
    return this.g41_1.f2q();
  };
  protoOf(PolylineComponent).g2q = function (_set____db54di) {
    this.g41_1.g2q(_set____db54di);
  };
  protoOf(PolylineComponent).h2q = function () {
    return this.g41_1.h2q();
  };
  protoOf(PolylineComponent).a = function () {
    return this.g41_1.a();
  };
  function _get_LOG__e5r759_5($this) {
    var tmp0 = $this.k42_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('LOG', 1, tmp, PolylineHandleSelectionModel$Companion$_get_LOG_$ref_mrpayj(), null);
    return tmp0.j2();
  }
  function PolylineHandleSelectionModel$Companion$_get_LOG_$ref_mrpayj() {
    return function (p0) {
      return _get_LOG__e5r759_5(p0);
    };
  }
  function Companion_18() {
    Companion_instance_23 = this;
    this.k42_1 = logger(getKClass(PolylineHandleSelectionModel));
  }
  var Companion_instance_23;
  function Companion_getInstance_28() {
    if (Companion_instance_23 == null)
      new Companion_18();
    return Companion_instance_23;
  }
  function createHandles_0($this) {
    $this.y3q();
    var inductionVariable = 0;
    var last = $this.b3s().d2k();
    if (inductionVariable < last)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        $this.l3r(new RectangularHandle($this.v42_1));
      }
       while (inductionVariable < last);
    $this.v3q_1 = $this.b3s().d2k();
  }
  function PolylineEventHandler($outer) {
    this.b43_1 = $outer;
    EventHandler.call(this, $outer);
    this.z42_1 = Companion_getInstance().g1a_1;
    this.a43_1 = 0;
  }
  protoOf(PolylineEventHandler).r3r = function (view) {
    var index = this.b43_1.v3r(ensureNotNull(this.t3r_1));
    this.z42_1 = Point2D_init_$Create$(this.b43_1.b3s().e2k(index));
    this.a43_1 = this.b43_1.b3s().d2k();
  };
  protoOf(PolylineEventHandler).c3s = function (context) {
    var index = this.b43_1.v3r(ensureNotNull(this.t3r_1));
    this.b43_1.b3s().u2q();
    var tmp;
    if (!(this.b43_1.b3s().d2k() === this.a43_1)) {
      _get_LOG__e5r759_5(Companion_getInstance_28()).il('Join point ' + index + ' of polyline ' + this.b43_1.b3s().av() + ' at ' + this.z42_1.toString());
      tmp = new JoinPolylinePointsCommand(context.e3c_1, this.b43_1.b3s().av(), index, this.z42_1);
    } else {
      _get_LOG__e5r759_5(Companion_getInstance_28()).il('Move point ' + index + ' of polyline ' + this.b43_1.b3s().av() + ' to ' + this.z42_1.toString());
      tmp = Companion_instance_21.z41(context.e3c_1, this.b43_1.b3s(), index, this.z42_1);
    }
    var command = tmp;
    context.e3c_1.l3c().e3a(command);
  };
  protoOf(PolylineEventHandler).c43 = function (context) {
    var tmp1_safe_receiver = context.y21_1;
    if ((tmp1_safe_receiver == null ? null : tmp1_safe_receiver.c1a()) === 2) {
      var tmp0_safe_receiver = this.b43_1.b3s().q2q(context.a22_1, context.b22_1, 10);
      if (tmp0_safe_receiver == null)
        null;
      else {
        // Inline function 'kotlin.let' call
        _get_LOG__e5r759_5(Companion_getInstance_28()).ol('Add handle ' + tmp0_safe_receiver);
        var snap = context.e3c_1.j3c().d43(context.a22_1, context.b22_1);
        var location = snap.co(context.d22_1);
        _get_LOG__e5r759_5(Companion_getInstance_28()).il('Add point ' + (tmp0_safe_receiver + 1 | 0) + ' to polyline ' + this.b43_1.b3s().av() + ' at ' + location.toString());
        context.e3c_1.l3c().d3a(new AddPolylinePointCommand(context.e3c_1, this.b43_1.b3s().av(), tmp0_safe_receiver + 1 | 0, location));
      }
    }
    return null;
  };
  protoOf(PolylineEventHandler).i22 = function (context) {
    return this.c43(context instanceof EditInputEventContext ? context : THROW_CCE());
  };
  function PolylinePointInputEventHandler($outer) {
    this.f43_1 = $outer;
    InputEventHandlerAdapter.call(this);
  }
  protoOf(PolylinePointInputEventHandler).f3s = function (context) {
    context.x21_1.v1x(Cursor_CROSSHAIR_getInstance());
    return this;
  };
  protoOf(PolylinePointInputEventHandler).j22 = function (context) {
    return this.f3s(context instanceof EditInputEventContext ? context : THROW_CCE());
  };
  protoOf(PolylinePointInputEventHandler).h3s = function (context) {
    var tmp = this.f43_1.b3s();
    var tmp_0 = this.f43_1.l3s();
    tmp.n2q(this.f43_1.v3r(ensureNotNull((tmp_0 instanceof PolylineEventHandler ? tmp_0 : THROW_CCE()).t3r_1)), context.a22_1, context.b22_1);
    return this;
  };
  protoOf(PolylinePointInputEventHandler).l22 = function (context) {
    return this.h3s(context instanceof EditInputEventContext ? context : THROW_CCE());
  };
  function PolylineHandleSelectionModel(c) {
    Companion_getInstance_28();
    AbstractHandleSelectionModel.call(this, c);
    this.v42_1 = new PolylinePointInputEventHandler(this);
  }
  protoOf(PolylineHandleSelectionModel).m3s = function () {
    return new PolylineEventHandler(this);
  };
  protoOf(PolylineHandleSelectionModel).z3q = function () {
    return this.b3s().d2k();
  };
  protoOf(PolylineHandleSelectionModel).n3s = function () {
    if (!(this.v3q_1 === this.z3q())) {
      createHandles_0(this);
    }
    var inductionVariable = 0;
    var last = this.b3s().d2k();
    if (inductionVariable < last)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        this.o3s(i).g43(this.b3s().e2k(i).in_1, this.b3s().e2k(i).jn_1);
      }
       while (inductionVariable < last);
  };
  function PolylineReplaceSelectionModel(component) {
    AbstractSelectedColorWrappingSelectionModel.call(this, component);
  }
  protoOf(PolylineReplaceSelectionModel).p43 = function (component) {
    return new PolylineHandleSelectionModel(component);
  };
  protoOf(PolylineReplaceSelectionModel).h3u = function (component) {
    return this.p43(component instanceof PolylineComponent ? component : THROW_CCE());
  };
  function Companion_19() {
  }
  protoOf(Companion_19).q43 = function (c, shape) {
    var bb = Rectangle2D_init_$Create$(shape.do());
    var lw = c.v1t().p1t_1;
    bb.s1b(bb.e1h_1 - lw, bb.f1h_1 - lw, bb.g1h_1 + 2 * lw, bb.h1h_1 + 2 * lw);
    if (c.s2c()) {
      DropShadow_instance.w2m(bb, c.g20());
    }
    return bb;
  };
  var Companion_instance_24;
  function Companion_getInstance_29() {
    return Companion_instance_24;
  }
  function AbstractRectangularComponent(styleType, styleProvider, shape) {
    styleType = styleType === VOID ? Companion_getInstance_0().l1x_1 : styleType;
    styleProvider = styleProvider === VOID ? DrawStyleModule_getInstance().g1x_1 : styleProvider;
    shape = shape === VOID ? new Rectangle2D() : shape;
    AbstractComponent_init_$Init$(styleProvider, styleType, this);
    this.n3y_1 = shape;
  }
  protoOf(AbstractRectangularComponent).j40 = function () {
    return this.n3y_1;
  };
  protoOf(AbstractRectangularComponent).x3z = function () {
    return false;
  };
  protoOf(AbstractRectangularComponent).i40 = function (context) {
  };
  protoOf(AbstractRectangularComponent).s1b = function (x, y, width, height) {
    this.s1z();
    this.n3y_1.s1b(x, y, width, height);
    this.s1z();
    this.v1z();
  };
  protoOf(AbstractRectangularComponent).w1b = function (rect) {
    this.s1b(rect.z19(), rect.a1a(), rect.p1b(), rect.r1b());
  };
  protoOf(AbstractRectangularComponent).f20 = function (value) {
    this.s1b(value.in_1, value.jn_1, this.p1b(), this.r1b());
  };
  protoOf(AbstractRectangularComponent).hw = function () {
    return new Point2D(this.z19(), this.a1a());
  };
  protoOf(AbstractRectangularComponent).do = function () {
    return Companion_instance_24.q43(this, this.n3y_1);
  };
  protoOf(AbstractRectangularComponent).eo = function (x, y) {
    return this.n3y_1.eo(x, y);
  };
  protoOf(AbstractRectangularComponent).no = function (p) {
    return this.n3y_1.no(p);
  };
  protoOf(AbstractRectangularComponent).po = function (rect) {
    return this.n3y_1.po(rect);
  };
  protoOf(AbstractRectangularComponent).p2h = function (x) {
    this.s1b((new Point2D(this.z19() + this.p1b(), this.a1a())).q1g(x).in_1, this.a1a(), this.p1b(), this.r1b());
  };
  protoOf(AbstractRectangularComponent).q2h = function (y) {
    this.s1b(this.z19(), (new Point2D(this.z19(), this.a1a() + this.r1b())).r1g(y).jn_1, this.p1b(), this.r1b());
  };
  protoOf(AbstractRectangularComponent).t3a = function () {
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [new SnappableXCoordinate(this.j1c()), new SnappableXCoordinate(this.h1c()), new SnappableXCoordinate(this.l1c())];
  };
  protoOf(AbstractRectangularComponent).u3a = function () {
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [new SnappableYCoordinate(this.k1c()), new SnappableYCoordinate(this.i1c()), new SnappableYCoordinate(this.m1c())];
  };
  protoOf(AbstractRectangularComponent).r37 = function (writer) {
    protoOf(AbstractComponent).r37.call(this, writer);
    writer.u38('x', this.z19());
    writer.u38('y', this.a1a());
    writer.u38('w', this.p1b());
    writer.u38('h', this.r1b());
  };
  protoOf(AbstractRectangularComponent).s37 = function (reader) {
    protoOf(AbstractComponent).s37.call(this, reader);
    this.s1b(reader.a38('x'), reader.a38('y'), reader.a38('w'), reader.a38('h'));
  };
  protoOf(AbstractRectangularComponent).v1b = function (v) {
    return this.n3y_1.v1b(v);
  };
  protoOf(AbstractRectangularComponent).fo = function (x, y, width, height) {
    return this.n3y_1.fo(x, y, width, height);
  };
  protoOf(AbstractRectangularComponent).oo = function (rect) {
    return this.n3y_1.oo(rect);
  };
  protoOf(AbstractRectangularComponent).go = function (x, y, w, h) {
    return this.n3y_1.go(x, y, w, h);
  };
  protoOf(AbstractRectangularComponent).tn = function (x, y) {
    return this.n3y_1.tn(x, y);
  };
  protoOf(AbstractRectangularComponent).x1b = function (rect) {
    return this.n3y_1.x1b(rect);
  };
  protoOf(AbstractRectangularComponent).y1b = function (deltaX, deltaY) {
    return this.n3y_1.y1b(deltaX, deltaY);
  };
  protoOf(AbstractRectangularComponent).z1b = function (delta) {
    return this.n3y_1.z1b(delta);
  };
  protoOf(AbstractRectangularComponent).a1c = function (topY, leftX, bottomY, rightX) {
    return this.n3y_1.a1c(topY, leftX, bottomY, rightX);
  };
  protoOf(AbstractRectangularComponent).z19 = function () {
    return this.n3y_1.z19();
  };
  protoOf(AbstractRectangularComponent).a1a = function () {
    return this.n3y_1.a1a();
  };
  protoOf(AbstractRectangularComponent).p1b = function () {
    return this.n3y_1.p1b();
  };
  protoOf(AbstractRectangularComponent).r1b = function () {
    return this.n3y_1.r1b();
  };
  protoOf(AbstractRectangularComponent).c1c = function () {
    return this.n3y_1.c1c();
  };
  protoOf(AbstractRectangularComponent).d1c = function () {
    return this.n3y_1.d1c();
  };
  protoOf(AbstractRectangularComponent).e1c = function () {
    return this.n3y_1.e1c();
  };
  protoOf(AbstractRectangularComponent).f1c = function () {
    return this.n3y_1.f1c();
  };
  protoOf(AbstractRectangularComponent).g1c = function () {
    return this.n3y_1.g1c();
  };
  protoOf(AbstractRectangularComponent).ov = function () {
    return this.n3y_1.ov();
  };
  protoOf(AbstractRectangularComponent).h1c = function () {
    return this.n3y_1.h1c();
  };
  protoOf(AbstractRectangularComponent).i1c = function () {
    return this.n3y_1.i1c();
  };
  protoOf(AbstractRectangularComponent).j1c = function () {
    return this.n3y_1.j1c();
  };
  protoOf(AbstractRectangularComponent).k1c = function () {
    return this.n3y_1.k1c();
  };
  protoOf(AbstractRectangularComponent).l1c = function () {
    return this.n3y_1.l1c();
  };
  protoOf(AbstractRectangularComponent).m1c = function () {
    return this.n3y_1.m1c();
  };
  protoOf(AbstractRectangularComponent).n1c = function () {
    return this.n3y_1.n1c();
  };
  protoOf(AbstractRectangularComponent).o1c = function () {
    return this.n3y_1.o1c();
  };
  protoOf(AbstractRectangularComponent).p1c = function () {
    return this.n3y_1.p1c();
  };
  protoOf(AbstractRectangularComponent).q1c = function () {
    return this.n3y_1.q1c();
  };
  protoOf(AbstractRectangularComponent).r1c = function () {
    return this.n3y_1.r1c();
  };
  function EditModelRectangleModule$initialize$lambda(it) {
    return new RectangularBelowSelectionModel(it instanceof AbstractRectangularComponent ? it : THROW_CCE());
  }
  function EditModelRectangleModule$initialize$lambda_0(it) {
    return new RectangularHandleSelectionModel(it instanceof AbstractRectangularComponent ? it : THROW_CCE());
  }
  function EditModelRectangleModule$initialize$lambda_1(it) {
    return new RectangularReplaceSelectionModel(it instanceof AbstractRectangularComponent ? it : THROW_CCE());
  }
  function EditModelRectangleModule$initialize$lambda_2(it) {
    return new RectangularBelowSelectionModel(it instanceof AbstractRectangularComponent ? it : THROW_CCE());
  }
  function EditModelRectangleModule$initialize$lambda_3(it) {
    return new RectangularHandleSelectionModel(it instanceof AbstractRectangularComponent ? it : THROW_CCE());
  }
  function EditModelRectangleModule$initialize$lambda_4(it) {
    return new RectangularReplaceSelectionModel(it instanceof AbstractRectangularComponent ? it : THROW_CCE());
  }
  function EditModelRectangleModule$initialize$lambda_5(it) {
    return new RectangularBelowSelectionModel(it instanceof AbstractRectangularComponent ? it : THROW_CCE());
  }
  function EditModelRectangleModule$initialize$lambda_6(it) {
    return new RectangularHandleSelectionModel(it instanceof AbstractRectangularComponent ? it : THROW_CCE());
  }
  function EditModelRectangleModule$initialize$lambda_7(it) {
    return new RectangularReplaceSelectionModel(it instanceof AbstractRectangularComponent ? it : THROW_CCE());
  }
  function EditModelRectangleModule$initialize$lambda_8(it) {
    return new RectangularBelowSelectionModel(it instanceof AbstractRectangularComponent ? it : THROW_CCE());
  }
  function EditModelRectangleModule$initialize$lambda_9(it) {
    return new RectangularReplaceSelectionModel(it instanceof AbstractRectangularComponent ? it : THROW_CCE());
  }
  function EditModelRectangleModule$initialize$lambda_10(it) {
    return new RectangularHandleSelectionModel(it instanceof AbstractRectangularComponent ? it : THROW_CCE());
  }
  function EditModelRectangleModule() {
    EditModelRectangleModule_instance = this;
    AbstractModule.call(this);
  }
  protoOf(EditModelRectangleModule).ro = function () {
    var tmp = EditSelectModule_getInstance().b3l_1;
    var tmp_0 = SelectionDrawingStrategy_BELOW_getInstance();
    var tmp_1 = getKClass(RectangleComponent);
    tmp.w3u(tmp_0, tmp_1, EditModelRectangleModule$initialize$lambda);
    var tmp_2 = EditSelectModule_getInstance().b3l_1;
    var tmp_3 = SelectionDrawingStrategy_ABOVE_getInstance();
    var tmp_4 = getKClass(RectangleComponent);
    tmp_2.w3u(tmp_3, tmp_4, EditModelRectangleModule$initialize$lambda_0);
    var tmp_5 = EditSelectModule_getInstance().b3l_1;
    var tmp_6 = SelectionDrawingStrategy_REPLACE_getInstance();
    var tmp_7 = getKClass(RectangleComponent);
    tmp_5.w3u(tmp_6, tmp_7, EditModelRectangleModule$initialize$lambda_1);
    var tmp_8 = EditSelectModule_getInstance().b3l_1;
    var tmp_9 = SelectionDrawingStrategy_BELOW_getInstance();
    var tmp_10 = getKClass(EllipseComponent);
    tmp_8.w3u(tmp_9, tmp_10, EditModelRectangleModule$initialize$lambda_2);
    var tmp_11 = EditSelectModule_getInstance().b3l_1;
    var tmp_12 = SelectionDrawingStrategy_ABOVE_getInstance();
    var tmp_13 = getKClass(EllipseComponent);
    tmp_11.w3u(tmp_12, tmp_13, EditModelRectangleModule$initialize$lambda_3);
    var tmp_14 = EditSelectModule_getInstance().b3l_1;
    var tmp_15 = SelectionDrawingStrategy_REPLACE_getInstance();
    var tmp_16 = getKClass(EllipseComponent);
    tmp_14.w3u(tmp_15, tmp_16, EditModelRectangleModule$initialize$lambda_4);
    var tmp_17 = EditSelectModule_getInstance().b3l_1;
    var tmp_18 = SelectionDrawingStrategy_BELOW_getInstance();
    var tmp_19 = getKClass(RoundRectangleComponent);
    tmp_17.w3u(tmp_18, tmp_19, EditModelRectangleModule$initialize$lambda_5);
    var tmp_20 = EditSelectModule_getInstance().b3l_1;
    var tmp_21 = SelectionDrawingStrategy_ABOVE_getInstance();
    var tmp_22 = getKClass(RoundRectangleComponent);
    tmp_20.w3u(tmp_21, tmp_22, EditModelRectangleModule$initialize$lambda_6);
    var tmp_23 = EditSelectModule_getInstance().b3l_1;
    var tmp_24 = SelectionDrawingStrategy_REPLACE_getInstance();
    var tmp_25 = getKClass(RoundRectangleComponent);
    tmp_23.w3u(tmp_24, tmp_25, EditModelRectangleModule$initialize$lambda_7);
    var tmp_26 = EditSelectModule_getInstance().b3l_1;
    var tmp_27 = SelectionDrawingStrategy_BELOW_getInstance();
    var tmp_28 = getKClass(ImageComponent);
    tmp_26.w3u(tmp_27, tmp_28, EditModelRectangleModule$initialize$lambda_8);
    var tmp_29 = EditSelectModule_getInstance().b3l_1;
    var tmp_30 = SelectionDrawingStrategy_REPLACE_getInstance();
    var tmp_31 = getKClass(ImageComponent);
    tmp_29.w3u(tmp_30, tmp_31, EditModelRectangleModule$initialize$lambda_9);
    var tmp_32 = EditSelectModule_getInstance().b3l_1;
    var tmp_33 = SelectionDrawingStrategy_ABOVE_getInstance();
    var tmp_34 = getKClass(ImageComponent);
    tmp_32.w3u(tmp_33, tmp_34, EditModelRectangleModule$initialize$lambda_10);
  };
  var EditModelRectangleModule_instance;
  function EditModelRectangleModule_getInstance() {
    if (EditModelRectangleModule_instance == null)
      new EditModelRectangleModule();
    return EditModelRectangleModule_instance;
  }
  function Companion_20() {
    Companion_instance_25 = this;
    this.s43_1 = 5;
    this.t43_1 = 10;
    this.u43_1 = new Stroke(10);
  }
  var Companion_instance_25;
  function Companion_getInstance_30() {
    if (Companion_instance_25 == null)
      new Companion_20();
    return Companion_instance_25;
  }
  function RectangularBelowSelectionModel(component) {
    Companion_getInstance_30();
    AbstractSelectionModel.call(this, component);
    this.a44_1 = new Rectangle2D();
  }
  protoOf(RectangularBelowSelectionModel).do = function () {
    return new Rectangle2D(this.a44_1.e1h_1 - 5 - 1, this.a44_1.f1h_1 - 5 - 1, this.a44_1.g1h_1 + 10 + 1, this.a44_1.h1h_1 + 10 + 1);
  };
  protoOf(RectangularBelowSelectionModel).r1z = function (context) {
    context.t1y_1.o1t(Companion_getInstance_30().u43_1);
    context.t1y_1.l1t(Themes_getInstance().r2f().x3x_1.m1t().h1x_1);
    context.t1y_1.t1u(this.a44_1);
  };
  protoOf(RectangularBelowSelectionModel).eo = function (x, y) {
    return this.a44_1.eo(x, y);
  };
  protoOf(RectangularBelowSelectionModel).r3s = function () {
    this.s1z();
    this.a44_1.s1b(this.b3s().n3y_1.z19(), this.b3s().n3y_1.a1a(), this.b3s().n3y_1.p1b(), this.b3s().n3y_1.r1b());
    this.s1z();
    this.u1z();
  };
  function Companion_21() {
    this.b44_1 = 10;
  }
  var Companion_instance_26;
  function Companion_getInstance_31() {
    return Companion_instance_26;
  }
  function updateLabelLocation($this) {
    var tmp;
    switch ($this.e40().l2_1) {
      case 2:
        tmp = $this.r1b() - 10;
        break;
      case 1:
        tmp = $this.r1b() / 2;
        break;
      case 0:
        tmp = 10;
        break;
      default:
        noWhenBranchMatchedException();
        break;
    }
    var y = tmp;
    var tmp_0;
    switch ($this.g40().l2_1) {
      case 0:
        tmp_0 = 10;
        break;
      case 1:
        tmp_0 = $this.p1b() / 2;
        break;
      case 2:
        tmp_0 = $this.p1b() - 10;
        break;
      default:
        noWhenBranchMatchedException();
        break;
    }
    var x = tmp_0;
    $this.v17().f20(new Point2D(x, y));
  }
  function RectangularComponent$_get_description_$ref_d7mo81() {
    return function (p0) {
      return p0.kq();
    };
  }
  function RectangularComponent$_set_description_$ref_nbcvql() {
    return function (p0, p1) {
      p0.b40(p1);
      return Unit_instance;
    };
  }
  function RectangularComponent$_get_description_$ref_d7mo81_0() {
    return function (p0) {
      return p0.kq();
    };
  }
  function RectangularComponent$_set_description_$ref_nbcvql_0() {
    return function (p0, p1) {
      p0.b40(p1);
      return Unit_instance;
    };
  }
  function RectangularComponent$drawShadow$lambda($fillColor, this$0, $context, $strokeColor) {
    return function (it) {
      var tmp;
      if (!($fillColor == null)) {
        this$0.c2b($context, this$0.j40(), $context.a1z(Themes_getInstance().r2f().m2f_1).h1x_1);
        tmp = Unit_instance;
      }
      var tmp_0;
      if (!($strokeColor == null)) {
        this$0.d2b($context, this$0.j40(), $context.a1z(Themes_getInstance().r2f().m2f_1).h1x_1, this$0.v1t());
        tmp_0 = Unit_instance;
      }
      return Unit_instance;
    };
  }
  function RectangularComponent(styleType, styleProvider, shape, labelRotation, labelRotationDisplayStrategy) {
    styleType = styleType === VOID ? Companion_getInstance_0().l1x_1 : styleType;
    styleProvider = styleProvider === VOID ? DrawStyleModule_getInstance().g1x_1 : styleProvider;
    labelRotation = labelRotation === VOID ? Rotation_R0_getInstance() : labelRotation;
    labelRotationDisplayStrategy = labelRotationDisplayStrategy === VOID ? RotationDisplayStrategy_IGNORE_getInstance() : labelRotationDisplayStrategy;
    AbstractRectangularComponent.call(this, styleType, styleProvider, shape);
    var tmp = this;
    var tmp0_font = this.l2c();
    tmp.r3z_1 = new Label('', tmp0_font, VOID, VOID, VOID, VOID, labelRotationDisplayStrategy, labelRotation);
    this.s3z_1 = observableDescription(Description_init_$Create$(''));
    this.t3z_1 = new TranslatableText();
    updateLabelLocation(this);
    this.u3z_1 = new TransparentImpl(this);
  }
  protoOf(RectangularComponent).v17 = function () {
    return this.r3z_1;
  };
  protoOf(RectangularComponent).b40 = function (_set____db54di) {
    var tmp = KMutableProperty1;
    var tmp_0 = RectangularComponent$_get_description_$ref_d7mo81_0();
    return this.s3z_1.xf(this, getPropertyCallableRef('description', 1, tmp, tmp_0, RectangularComponent$_set_description_$ref_nbcvql_0()), _set____db54di);
  };
  protoOf(RectangularComponent).kq = function () {
    var tmp = KMutableProperty1;
    var tmp_0 = RectangularComponent$_get_description_$ref_d7mo81();
    return this.s3z_1.vf(this, getPropertyCallableRef('description', 1, tmp, tmp_0, RectangularComponent$_set_description_$ref_nbcvql()));
  };
  protoOf(RectangularComponent).c40 = function (value) {
    if (!this.t3z_1.equals(value)) {
      this.s1z();
      this.t3z_1 = value;
      this.v17().w44(this.t3z_1.ov() ? '' : this.t3z_1.u44());
      this.s1z();
      this.v1z();
    }
  };
  protoOf(RectangularComponent).d40 = function (value) {
    if (!this.v17().e40().equals(value)) {
      this.s1z();
      this.v17().d40(value);
      updateLabelLocation(this);
      this.s1z();
    }
  };
  protoOf(RectangularComponent).e40 = function () {
    return this.v17().e40();
  };
  protoOf(RectangularComponent).f40 = function (value) {
    if (!this.v17().g40().equals(value)) {
      this.s1z();
      this.v17().f40(value);
      updateLabelLocation(this);
      this.s1z();
    }
  };
  protoOf(RectangularComponent).g40 = function () {
    return this.v17().g40();
  };
  protoOf(RectangularComponent).l3m = function (newRotation) {
    protoOf(AbstractRectangularComponent).l3m.call(this, newRotation);
    this.v17().p44_1 = this.g20();
  };
  protoOf(RectangularComponent).k2h = function (value) {
    this.u3z_1.k2h(value);
  };
  protoOf(RectangularComponent).n2h = function () {
    return this.u3z_1.m2h_1;
  };
  protoOf(RectangularComponent).s1b = function (x, y, width, height) {
    protoOf(AbstractRectangularComponent).s1b.call(this, x, y, width, height);
    updateLabelLocation(this);
  };
  protoOf(RectangularComponent).r37 = function (writer) {
    protoOf(AbstractRectangularComponent).r37.call(this, writer);
    if (!this.t3z_1.ov()) {
      writer.r38('text', this.t3z_1.x44());
    }
    if (!this.e40().equals(VerticalAlignment_CENTER_getInstance())) {
      writer.w38('vAlign', this.e40().a45_1);
    }
    if (!this.g40().equals(HorizontalAlignment_CENTER_getInstance())) {
      writer.w38('hAlign', this.g40().d45_1);
    }
    this.kq().q40('desc', writer);
  };
  protoOf(RectangularComponent).s37 = function (reader) {
    protoOf(AbstractRectangularComponent).s37.call(this, reader);
    if (reader.d35('text')) {
      this.c40(TranslatableText_init_$Create$(reader.b38('text')));
    }
    if (reader.e35('text')) {
      this.c40(new TranslatableText(reader.x37('text')));
    }
    if (reader.d35('vAlign')) {
      this.d40(Companion_instance_33.r1e(reader.b38('vAlign')));
    }
    if (reader.d35('hAlign')) {
      this.f40(Companion_instance_32.r1e(reader.b38('hAlign')));
    }
    this.b40(Companion_instance_39.f45('desc', reader));
  };
  protoOf(RectangularComponent).do = function () {
    var tmp = Rectangle2D_init_$Create$(protoOf(AbstractRectangularComponent).do.call(this)).x1b(Rectangle2D_init_$Create$(this.v17().t44_1).v1b(this.hw()));
    return tmp instanceof Rectangle2D ? tmp : THROW_CCE();
  };
  protoOf(RectangularComponent).r1z = function (context) {
    if (context.w1y_1) {
      this.h40(context, ensureNotNull(context.x1y_1).h1x_1, ensureNotNull(context.x1y_1).i1x_1);
    } else {
      this.h40(context, this.r2c() ? this.u3z_1.v2g(this.i2c()) : null, this.p2c() ? this.u3z_1.v2g(this.j2c()) : null);
    }
  };
  protoOf(RectangularComponent).h40 = function (context, strokeColor, fillColor) {
    var oldColor = context.t1y_1.m1t();
    this.z3z(context, strokeColor, fillColor);
    this.y3z(context, strokeColor, fillColor);
    context.t1y_1.l1t(this.u3z_1.v2g(this.k2c()));
    this.i40(context);
    DrawModule_getInstance().j2p(this, context);
    context.t1y_1.l1t(oldColor);
  };
  protoOf(RectangularComponent).y3z = function (context, strokeColor, fillColor) {
    this.c2b(context, this.j40(), fillColor);
    this.d2b(context, this.j40(), strokeColor, this.v1t());
  };
  protoOf(RectangularComponent).z3z = function (context, strokeColor, fillColor) {
    if (this.s2c()) {
      var tmp = DropShadow_instance;
      var tmp_0 = this.n2h();
      tmp.v2m(context, tmp_0, RectangularComponent$drawShadow$lambda(fillColor, this, context, strokeColor));
    }
  };
  protoOf(RectangularComponent).i40 = function (context) {
    this.v17().w1t(this.l2c());
    // Inline function 'io.antarescircuit.jabbah.draw.DrawContext.translated' call
    var d = this.hw();
    context.t1y_1.v1c(d.in_1, d.jn_1);
    this.v17().r1z(context);
    context.t1y_1.v1c(-d.in_1, -d.jn_1);
  };
  protoOf(RectangularComponent).y1z = function (context) {
    if (this.t3z_1.g45() && this.v17().no(context.d22_1.t1g(this.hw()))) {
      var tmp0_safe_receiver = this.e2b(null, this.kq().j2(), null);
      var tmp;
      if (tmp0_safe_receiver == null) {
        tmp = null;
      } else {
        // Inline function 'kotlin.let' call
        tmp = new Tooltip(tmp0_safe_receiver, Rectangle2D_init_$Create$(this.v17().t44_1).v1b(this.hw()));
      }
      return tmp;
    }
    return null;
  };
  function Companion_22() {
    Companion_instance_27 = this;
    this.t3m_1 = Translations_getInstance().zm('edit.component.rectangle', []);
  }
  var Companion_instance_27;
  function Companion_getInstance_32() {
    if (Companion_instance_27 == null)
      new Companion_22();
    return Companion_instance_27;
  }
  function RectangleComponent_init_$Init$(x, y, w, h, $this) {
    RectangleComponent.call($this, VOID, VOID, new Rectangle2D(x, y, w, h));
    return $this;
  }
  function RectangleComponent_init_$Create$(x, y, w, h) {
    return RectangleComponent_init_$Init$(x, y, w, h, objectCreate(protoOf(RectangleComponent)));
  }
  function RectangleComponent(styleType, styleProvider, shape) {
    Companion_getInstance_32();
    styleType = styleType === VOID ? Companion_getInstance_0().l1x_1 : styleType;
    styleProvider = styleProvider === VOID ? DrawStyleModule_getInstance().g1x_1 : styleProvider;
    shape = shape === VOID ? new Rectangle2D(0.0, 0.0, 0.0, 0.0) : shape;
    RectangularComponent.call(this, styleType, styleProvider, shape);
  }
  protoOf(RectangleComponent).u19 = function () {
    return Companion_getInstance_32().t3m_1;
  };
  function Companion_23() {
    Companion_instance_28 = this;
    this.v3m_1 = Translations_getInstance().zm('edit.component.ellipse', []);
  }
  var Companion_instance_28;
  function Companion_getInstance_33() {
    if (Companion_instance_28 == null)
      new Companion_23();
    return Companion_instance_28;
  }
  function EllipseComponent(styleType, styleProvider, shape) {
    Companion_getInstance_33();
    styleType = styleType === VOID ? Companion_getInstance_0().l1x_1 : styleType;
    styleProvider = styleProvider === VOID ? DrawStyleModule_getInstance().g1x_1 : styleProvider;
    shape = shape === VOID ? new Ellipse2D(0.0, 0.0, 0.0, 0.0) : shape;
    RectangularComponent.call(this, styleType, styleProvider, shape);
    this.j46_1 = Companion_getInstance_33().v3m_1;
  }
  protoOf(EllipseComponent).u19 = function () {
    return this.j46_1;
  };
  function Companion_24() {
    Companion_instance_29 = this;
    this.k46_1 = Translations_getInstance().zm('edit.component.roundrect', []);
  }
  var Companion_instance_29;
  function Companion_getInstance_34() {
    if (Companion_instance_29 == null)
      new Companion_24();
    return Companion_instance_29;
  }
  function RoundRectangleComponent(styleType, styleProvider, shape) {
    Companion_getInstance_34();
    styleType = styleType === VOID ? Companion_getInstance_0().l1x_1 : styleType;
    styleProvider = styleProvider === VOID ? DrawStyleModule_getInstance().g1x_1 : styleProvider;
    shape = shape === VOID ? new RoundRectangle2D(0.0, 0.0, 0.0, 0.0, 10.0, 10.0) : shape;
    RectangularComponent.call(this, styleType, styleProvider, shape);
  }
  protoOf(RoundRectangleComponent).u19 = function () {
    return Companion_getInstance_34().k46_1;
  };
  function _get_LOG__e5r759_6($this) {
    var tmp0 = $this.z46_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('LOG', 1, tmp, RectangularHandleSelectionModel$Companion$_get_LOG_$ref_ovfwlf(), null);
    return tmp0.j2();
  }
  function RectangularHandleSelectionModel$Companion$_get_LOG_$ref_ovfwlf() {
    return function (p0) {
      return _get_LOG__e5r759_6(p0);
    };
  }
  function Companion_25() {
    Companion_instance_30 = this;
    this.z46_1 = logger(getKClass(RectangularHandleSelectionModel));
  }
  var Companion_instance_30;
  function Companion_getInstance_35() {
    if (Companion_instance_30 == null)
      new Companion_25();
    return Companion_instance_30;
  }
  function reportSize($this) {
    Status_getInstance().du(StatusType_Small_getInstance(), 'w=' + numberToInt($this.b3s().p1b()) + ', h=' + numberToInt($this.b3s().r1b()));
  }
  function RectangleEventHandler($outer) {
    this.e47_1 = $outer;
    EventHandler.call(this, $outer);
    this.d47_1 = null;
  }
  protoOf(RectangleEventHandler).r3r = function (view) {
    this.d47_1 = Rectangle2D_init_$Create$(this.e47_1.b3s().n3y_1);
    var tmp = this.e47_1;
    var tmp0_safe_receiver = this.d47_1;
    var tmp_0;
    if (tmp0_safe_receiver == null) {
      tmp_0 = null;
    } else {
      // Inline function 'kotlin.let' call
      var tmp_1;
      if (tmp0_safe_receiver.h1h_1 < 1.0E-7) {
        tmp_1 = 1.7976931348623157E308;
      } else {
        tmp_1 = tmp0_safe_receiver.g1h_1 / tmp0_safe_receiver.h1h_1;
      }
      tmp_0 = tmp_1;
    }
    var tmp1_elvis_lhs = tmp_0;
    tmp.x47_1 = tmp1_elvis_lhs == null ? 0.0 : tmp1_elvis_lhs;
  };
  protoOf(RectangleEventHandler).c3s = function (context) {
    if (!ensureNotNull(this.d47_1).equals(this.e47_1.b3s().n3y_1)) {
      _get_LOG__e5r759_6(Companion_getInstance_35()).il("Resize '" + this.e47_1.b3s().u19() + "' " + this.e47_1.b3s().av() + ' to ' + toString(this.e47_1.b3s().n3y_1));
      context.e3c_1.l3c().e3a(new ResizeRectangleCommand(context.e3c_1, this.e47_1.b3s().av(), Rectangle2D_init_$Create$(ensureNotNull(this.d47_1)), Rectangle2D_init_$Create$(this.e47_1.b3s().n3y_1)));
    }
  };
  function NorthWestHandler($outer) {
    this.z47_1 = $outer;
    InputEventHandlerAdapter.call(this);
  }
  protoOf(NorthWestHandler).f3s = function (context) {
    context.x21_1.v1x(Cursor_NW_RESIZE_getInstance());
    return this;
  };
  protoOf(NorthWestHandler).j22 = function (context) {
    return this.f3s(context instanceof EditInputEventContext ? context : THROW_CCE());
  };
  protoOf(NorthWestHandler).h3s = function (context) {
    var bounds = this.z47_1.b3s().n3y_1;
    var tmp0 = context.a22_1;
    // Inline function 'kotlin.math.min' call
    var b = bounds.l1c();
    var x = Math.min(tmp0, b);
    var tmp0_0 = context.b22_1;
    // Inline function 'kotlin.math.min' call
    var b_0 = bounds.m1c();
    var y = Math.min(tmp0_0, b_0);
    if (this.z47_1.b3s().x3z()) {
      var prefWidth = bounds.l1c() - x;
      var height = prefWidth / this.z47_1.x47_1;
      this.z47_1.b3s().s1b(bounds.l1c() - prefWidth, bounds.m1c() - height, prefWidth, height);
    } else {
      this.z47_1.b3s().s1b(x, y, bounds.p1b() + (bounds.z19() - x), bounds.r1b() + (bounds.a1a() - y));
    }
    reportSize(this.z47_1);
    return this;
  };
  protoOf(NorthWestHandler).l22 = function (context) {
    return this.h3s(context instanceof EditInputEventContext ? context : THROW_CCE());
  };
  function NorthHandler($outer) {
    this.b48_1 = $outer;
    InputEventHandlerAdapter.call(this);
  }
  protoOf(NorthHandler).f3s = function (context) {
    context.x21_1.v1x(Cursor_N_RESIZE_getInstance());
    return this;
  };
  protoOf(NorthHandler).j22 = function (context) {
    return this.f3s(context instanceof EditInputEventContext ? context : THROW_CCE());
  };
  protoOf(NorthHandler).h3s = function (context) {
    var bounds = this.b48_1.b3s().n3y_1;
    var tmp0 = context.b22_1;
    // Inline function 'kotlin.math.min' call
    var b = bounds.m1c();
    var y = Math.min(tmp0, b);
    this.b48_1.b3s().s1b(bounds.z19(), y, bounds.p1b(), bounds.r1b() + (bounds.a1a() - y));
    reportSize(this.b48_1);
    return this;
  };
  protoOf(NorthHandler).l22 = function (context) {
    return this.h3s(context instanceof EditInputEventContext ? context : THROW_CCE());
  };
  function NorthEastHandler($outer) {
    this.d48_1 = $outer;
    InputEventHandlerAdapter.call(this);
  }
  protoOf(NorthEastHandler).f3s = function (context) {
    context.x21_1.v1x(Cursor_NE_RESIZE_getInstance());
    return this;
  };
  protoOf(NorthEastHandler).j22 = function (context) {
    return this.f3s(context instanceof EditInputEventContext ? context : THROW_CCE());
  };
  protoOf(NorthEastHandler).h3s = function (context) {
    var bounds = this.d48_1.b3s().n3y_1;
    var tmp0 = context.a22_1;
    // Inline function 'kotlin.math.max' call
    var b = bounds.z19();
    var x = Math.max(tmp0, b);
    var tmp0_0 = context.b22_1;
    // Inline function 'kotlin.math.min' call
    var b_0 = bounds.m1c();
    var y = Math.min(tmp0_0, b_0);
    if (this.d48_1.b3s().x3z()) {
      var prefWidth = x - bounds.z19();
      var height = prefWidth / this.d48_1.x47_1;
      this.d48_1.b3s().s1b(bounds.j1c(), bounds.m1c() - height, prefWidth, height);
    } else {
      this.d48_1.b3s().s1b(bounds.z19(), y, x - bounds.z19(), bounds.r1b() + (bounds.a1a() - y));
    }
    reportSize(this.d48_1);
    return this;
  };
  protoOf(NorthEastHandler).l22 = function (context) {
    return this.h3s(context instanceof EditInputEventContext ? context : THROW_CCE());
  };
  function EastHandler($outer) {
    this.f48_1 = $outer;
    InputEventHandlerAdapter.call(this);
  }
  protoOf(EastHandler).f3s = function (context) {
    context.x21_1.v1x(Cursor_E_RESIZE_getInstance());
    return this;
  };
  protoOf(EastHandler).j22 = function (context) {
    return this.f3s(context instanceof EditInputEventContext ? context : THROW_CCE());
  };
  protoOf(EastHandler).h3s = function (context) {
    var bounds = this.f48_1.b3s().n3y_1;
    var tmp0 = context.a22_1;
    // Inline function 'kotlin.math.max' call
    var b = bounds.z19();
    var x = Math.max(tmp0, b);
    this.f48_1.b3s().s1b(bounds.z19(), bounds.a1a(), x - bounds.z19(), bounds.r1b());
    reportSize(this.f48_1);
    return this;
  };
  protoOf(EastHandler).l22 = function (context) {
    return this.h3s(context instanceof EditInputEventContext ? context : THROW_CCE());
  };
  function SouthEastHandler($outer) {
    this.h48_1 = $outer;
    InputEventHandlerAdapter.call(this);
  }
  protoOf(SouthEastHandler).f3s = function (context) {
    context.x21_1.v1x(Cursor_SE_RESIZE_getInstance());
    return this;
  };
  protoOf(SouthEastHandler).j22 = function (context) {
    return this.f3s(context instanceof EditInputEventContext ? context : THROW_CCE());
  };
  protoOf(SouthEastHandler).h3s = function (context) {
    var bounds = this.h48_1.b3s().n3y_1;
    var tmp0 = context.a22_1;
    // Inline function 'kotlin.math.max' call
    var b = bounds.z19();
    var x = Math.max(tmp0, b);
    var tmp0_0 = context.b22_1;
    // Inline function 'kotlin.math.max' call
    var b_0 = bounds.a1a();
    var y = Math.max(tmp0_0, b_0);
    if (this.h48_1.b3s().x3z()) {
      var prefHeight = y - bounds.a1a();
      this.h48_1.b3s().s1b(bounds.z19(), bounds.a1a(), this.h48_1.x47_1 * prefHeight, prefHeight);
    } else {
      this.h48_1.b3s().s1b(bounds.z19(), bounds.a1a(), x - bounds.z19(), y - bounds.a1a());
    }
    reportSize(this.h48_1);
    return this;
  };
  protoOf(SouthEastHandler).l22 = function (context) {
    return this.h3s(context instanceof EditInputEventContext ? context : THROW_CCE());
  };
  function SouthHandler($outer) {
    this.j48_1 = $outer;
    InputEventHandlerAdapter.call(this);
  }
  protoOf(SouthHandler).f3s = function (context) {
    context.x21_1.v1x(Cursor_S_RESIZE_getInstance());
    return this;
  };
  protoOf(SouthHandler).j22 = function (context) {
    return this.f3s(context instanceof EditInputEventContext ? context : THROW_CCE());
  };
  protoOf(SouthHandler).h3s = function (context) {
    var bounds = this.j48_1.b3s().n3y_1;
    var tmp0 = context.b22_1;
    // Inline function 'kotlin.math.max' call
    var b = bounds.a1a();
    var y = Math.max(tmp0, b);
    this.j48_1.b3s().s1b(bounds.z19(), bounds.a1a(), bounds.p1b(), y - bounds.a1a());
    reportSize(this.j48_1);
    return this;
  };
  protoOf(SouthHandler).l22 = function (context) {
    return this.h3s(context instanceof EditInputEventContext ? context : THROW_CCE());
  };
  function SouthWestHandler($outer) {
    this.l48_1 = $outer;
    InputEventHandlerAdapter.call(this);
  }
  protoOf(SouthWestHandler).f3s = function (context) {
    context.x21_1.v1x(Cursor_SW_RESIZE_getInstance());
    return this;
  };
  protoOf(SouthWestHandler).j22 = function (context) {
    return this.f3s(context instanceof EditInputEventContext ? context : THROW_CCE());
  };
  protoOf(SouthWestHandler).h3s = function (context) {
    var bounds = this.l48_1.b3s().n3y_1;
    var tmp0 = context.a22_1;
    // Inline function 'kotlin.math.min' call
    var b = bounds.l1c();
    var x = Math.min(tmp0, b);
    var tmp0_0 = context.b22_1;
    // Inline function 'kotlin.math.max' call
    var b_0 = bounds.a1a();
    var y = Math.max(tmp0_0, b_0);
    if (this.l48_1.b3s().x3z()) {
      var prefHeight = y - bounds.a1a();
      var width = this.l48_1.x47_1 * prefHeight;
      this.l48_1.b3s().s1b(bounds.l1c() - width, bounds.a1a(), width, prefHeight);
    } else {
      this.l48_1.b3s().s1b(x, bounds.a1a(), bounds.l1c() - x, y - bounds.a1a());
    }
    reportSize(this.l48_1);
    return this;
  };
  protoOf(SouthWestHandler).l22 = function (context) {
    return this.h3s(context instanceof EditInputEventContext ? context : THROW_CCE());
  };
  function WestHandler($outer) {
    this.n48_1 = $outer;
    InputEventHandlerAdapter.call(this);
  }
  protoOf(WestHandler).f3s = function (context) {
    context.x21_1.v1x(Cursor_W_RESIZE_getInstance());
    return this;
  };
  protoOf(WestHandler).j22 = function (context) {
    return this.f3s(context instanceof EditInputEventContext ? context : THROW_CCE());
  };
  protoOf(WestHandler).h3s = function (context) {
    var bounds = this.n48_1.b3s().n3y_1;
    var tmp0 = context.a22_1;
    // Inline function 'kotlin.math.min' call
    var b = bounds.l1c();
    var x = Math.min(tmp0, b);
    this.n48_1.b3s().s1b(x, bounds.a1a(), bounds.p1b() + (bounds.z19() - x), bounds.r1b());
    reportSize(this.n48_1);
    return this;
  };
  protoOf(WestHandler).l22 = function (context) {
    return this.h3s(context instanceof EditInputEventContext ? context : THROW_CCE());
  };
  function RectangularHandleSelectionModel(component) {
    Companion_getInstance_35();
    AbstractHandleSelectionModel.call(this, component);
    this.p47_1 = this.l3r(new RectangularHandle(new NorthWestHandler(this)));
    this.q47_1 = this.l3r(new RectangularHandle(new NorthEastHandler(this)));
    this.r47_1 = this.l3r(new RectangularHandle(new SouthEastHandler(this)));
    this.s47_1 = this.l3r(new RectangularHandle(new SouthWestHandler(this)));
    var tmp = this;
    var tmp_0;
    if (!component.x3z()) {
      tmp_0 = this.l3r(new RectangularHandle(new NorthHandler(this)));
    } else {
      tmp_0 = null;
    }
    tmp.t47_1 = tmp_0;
    var tmp_1 = this;
    var tmp_2;
    if (!component.x3z()) {
      tmp_2 = this.l3r(new RectangularHandle(new EastHandler(this)));
    } else {
      tmp_2 = null;
    }
    tmp_1.u47_1 = tmp_2;
    var tmp_3 = this;
    var tmp_4;
    if (!component.x3z()) {
      tmp_4 = this.l3r(new RectangularHandle(new SouthHandler(this)));
    } else {
      tmp_4 = null;
    }
    tmp_3.v47_1 = tmp_4;
    var tmp_5 = this;
    var tmp_6;
    if (!component.x3z()) {
      tmp_6 = this.l3r(new RectangularHandle(new WestHandler(this)));
    } else {
      tmp_6 = null;
    }
    tmp_5.w47_1 = tmp_6;
    this.x47_1 = 0.0;
  }
  protoOf(RectangularHandleSelectionModel).z3q = function () {
    return 8;
  };
  protoOf(RectangularHandleSelectionModel).n3s = function () {
    var r = this.b3s().n3y_1;
    this.p47_1.g43(r.z19(), r.a1a());
    this.q47_1.g43(r.z19() + r.p1b(), r.a1a());
    this.s47_1.g43(r.z19(), r.a1a() + r.r1b());
    this.r47_1.g43(r.z19() + r.p1b(), r.a1a() + r.r1b());
    var tmp0_safe_receiver = this.t47_1;
    if (tmp0_safe_receiver == null)
      null;
    else {
      tmp0_safe_receiver.g43(r.z19() + r.p1b() / 2, r.a1a());
    }
    var tmp1_safe_receiver = this.u47_1;
    if (tmp1_safe_receiver == null)
      null;
    else {
      tmp1_safe_receiver.g43(r.z19() + r.p1b(), r.a1a() + r.r1b() / 2);
    }
    var tmp2_safe_receiver = this.v47_1;
    if (tmp2_safe_receiver == null)
      null;
    else {
      tmp2_safe_receiver.g43(r.z19() + r.p1b() / 2, r.a1a() + r.r1b());
    }
    var tmp3_safe_receiver = this.w47_1;
    if (tmp3_safe_receiver == null)
      null;
    else {
      tmp3_safe_receiver.g43(r.z19(), r.a1a() + r.r1b() / 2);
    }
  };
  protoOf(RectangularHandleSelectionModel).m3s = function () {
    return new RectangleEventHandler(this);
  };
  function RectangularReplaceSelectionModel$DrawStrategy$SHAPE() {
    DrawStrategy.call(this, 'SHAPE', 0);
    DrawStrategy_SHAPE_instance = this;
  }
  protoOf(RectangularReplaceSelectionModel$DrawStrategy$SHAPE).q48 = function (component, context) {
    var oldStroke = context.t1y_1.v1t();
    context.t1y_1.l1t(Themes_getInstance().r2f().x3x_1.m1t().h1x_1);
    context.t1y_1.o1t(component.v1t());
    context.t1y_1.t1u(component.j40());
    component.i40(context);
    context.t1y_1.o1t(oldStroke);
  };
  var DrawStrategy_SHAPE_instance;
  function RectangularReplaceSelectionModel$DrawStrategy$COMPONENT() {
    DrawStrategy.call(this, 'COMPONENT', 1);
    DrawStrategy_COMPONENT_instance = this;
  }
  protoOf(RectangularReplaceSelectionModel$DrawStrategy$COMPONENT).q48 = function (component, context) {
    var oldUseContextColor = context.w1y_1;
    var oldContextColor = context.x1y_1;
    context.w1y_1 = true;
    context.x1y_1 = Themes_getInstance().r2f().x3x_1.m1t();
    component.r1z(context);
    context.w1y_1 = oldUseContextColor;
    context.x1y_1 = oldContextColor;
  };
  var DrawStrategy_COMPONENT_instance;
  var DrawStrategy_entriesInitialized;
  function DrawStrategy_initEntries() {
    if (DrawStrategy_entriesInitialized)
      return Unit_instance;
    DrawStrategy_entriesInitialized = true;
    DrawStrategy_SHAPE_instance = new RectangularReplaceSelectionModel$DrawStrategy$SHAPE();
    DrawStrategy_COMPONENT_instance = new RectangularReplaceSelectionModel$DrawStrategy$COMPONENT();
  }
  function DrawStrategy(name, ordinal) {
    Enum.call(this, name, ordinal);
  }
  function DrawStrategy_SHAPE_getInstance() {
    DrawStrategy_initEntries();
    return DrawStrategy_SHAPE_instance;
  }
  function DrawStrategy_COMPONENT_getInstance() {
    DrawStrategy_initEntries();
    return DrawStrategy_COMPONENT_instance;
  }
  function RectangularReplaceSelectionModel(component, drawStrategy) {
    drawStrategy = drawStrategy === VOID ? DrawStrategy_SHAPE_getInstance() : drawStrategy;
    AbstractSelectedColorWrappingSelectionModel.call(this, component);
    this.d49_1 = drawStrategy;
  }
  protoOf(RectangularReplaceSelectionModel).do = function () {
    return Rectangle2D_init_$Create$(this.b3s().do()).z1b(this.b3s().v1t().p1t_1);
  };
  protoOf(RectangularReplaceSelectionModel).r1z = function (context) {
    this.d49_1.q48(this.b3s(), context);
  };
  protoOf(RectangularReplaceSelectionModel).eo = function (x, y) {
    return this.n3u_1.eo(x, y);
  };
  protoOf(RectangularReplaceSelectionModel).e49 = function (component) {
    return new RectangularHandleSelectionModel(component);
  };
  protoOf(RectangularReplaceSelectionModel).h3u = function (component) {
    return this.e49(component instanceof AbstractRectangularComponent ? component : THROW_CCE());
  };
  function _get_rectangle__f04u2m($this) {
    var tmp = ensureNotNull(ensureNotNull($this.p3g_1).e3b().y3a($this.i49_1)).n3a();
    return tmp instanceof AbstractRectangularComponent ? tmp : THROW_CCE();
  }
  function ResizeRectangleCommand(editor, rectangleId, oldBounds, newBounds) {
    AbstractCommand.call(this, 'edit.model.rectangle.resize', editor);
    this.i49_1 = rectangleId;
    this.j49_1 = oldBounds;
    this.k49_1 = newBounds;
  }
  protoOf(ResizeRectangleCommand).s39 = function () {
    _get_rectangle__f04u2m(this).w1b(this.k49_1);
  };
  protoOf(ResizeRectangleCommand).w39 = function () {
    _get_rectangle__f04u2m(this).w1b(this.j49_1);
  };
  function Companion_26() {
    Companion_instance_31 = this;
    this.l49_1 = Translations_getInstance().zm('edit.component.text', []);
    this.m49_1 = 10;
    this.n49_1 = 10;
  }
  var Companion_instance_31;
  function Companion_getInstance_36() {
    if (Companion_instance_31 == null)
      new Companion_26();
    return Companion_instance_31;
  }
  function AbstractTextComponent(location, shape, styleType, styleProvider) {
    Companion_getInstance_36();
    location = location === VOID ? Companion_getInstance().g1a_1 : location;
    shape = shape === VOID ? new Rectangle2D(location.in_1, location.jn_1, 0.0, 0.0) : shape;
    styleType = styleType === VOID ? Companion_getInstance_0().k1x_1 : styleType;
    styleProvider = styleProvider === VOID ? DrawStyleModule_getInstance().g1x_1 : styleProvider;
    AbstractRectangularComponent.call(this, styleType, styleProvider, shape);
    this.y49_1 = false;
    this.z49_1 = new TransparentImpl(this);
    this.a4a_1 = HorizontalAlignment_LEFT_getInstance();
    this.b4a_1 = new RectangularShapeTextComponentDecorator(new RoundRectangle2D(0.0, 0.0, 0.0, 0.0, 20.0, 20.0), this, this.z49_1);
  }
  protoOf(AbstractTextComponent).eo = function (x, y) {
    return protoOf(AbstractRectangularComponent).eo.call(this, x, y);
  };
  protoOf(AbstractTextComponent).no = function (p) {
    return protoOf(AbstractRectangularComponent).no.call(this, p);
  };
  protoOf(AbstractTextComponent).po = function (rect) {
    return protoOf(AbstractRectangularComponent).po.call(this, rect);
  };
  protoOf(AbstractTextComponent).k2h = function (value) {
    this.z49_1.k2h(value);
  };
  protoOf(AbstractTextComponent).n2h = function () {
    return this.z49_1.m2h_1;
  };
  protoOf(AbstractTextComponent).r37 = function (writer) {
    protoOf(AbstractRectangularComponent).r37.call(this, writer);
    if (!this.c4a().ov()) {
      writer.r38('text', this.c4a().x44());
    }
    if (this.y49_1) {
      writer.y38('richText', this.y49_1);
    }
  };
  protoOf(AbstractTextComponent).s37 = function (reader) {
    protoOf(AbstractRectangularComponent).s37.call(this, reader);
    if (reader.d35('text')) {
      this.d4a(TranslatableText_init_$Create$(reader.b38('text')));
    }
    if (reader.e35('text')) {
      this.d4a(new TranslatableText(reader.x37('text')));
    }
    if (reader.d35('richText')) {
      this.y49_1 = reader.d38('richText');
    }
  };
  protoOf(AbstractTextComponent).u19 = function () {
    return Companion_getInstance_36().l49_1;
  };
  function HorizontalAlignment$LEFT() {
    HorizontalAlignment.call(this, 'LEFT', 0, 'left');
    HorizontalAlignment_LEFT_instance = this;
  }
  protoOf(HorizontalAlignment$LEFT).e1f = function () {
    return HorizontalAlignment_RIGHT_getInstance();
  };
  protoOf(HorizontalAlignment$LEFT).h4a = function (baselineRect) {
    return baselineRect.z19();
  };
  var HorizontalAlignment_LEFT_instance;
  function HorizontalAlignment$CENTER() {
    HorizontalAlignment.call(this, 'CENTER', 1, 'center');
    HorizontalAlignment_CENTER_instance = this;
  }
  protoOf(HorizontalAlignment$CENTER).e1f = function () {
    return HorizontalAlignment_CENTER_getInstance();
  };
  protoOf(HorizontalAlignment$CENTER).h4a = function (baselineRect) {
    return baselineRect.z19() - baselineRect.p1b() / 2 + 1;
  };
  var HorizontalAlignment_CENTER_instance;
  function HorizontalAlignment$RIGHT() {
    HorizontalAlignment.call(this, 'RIGHT', 2, 'right');
    HorizontalAlignment_RIGHT_instance = this;
  }
  protoOf(HorizontalAlignment$RIGHT).e1f = function () {
    return HorizontalAlignment_LEFT_getInstance();
  };
  protoOf(HorizontalAlignment$RIGHT).h4a = function (baselineRect) {
    return baselineRect.z19() - baselineRect.p1b();
  };
  var HorizontalAlignment_RIGHT_instance;
  function Companion_27() {
  }
  protoOf(Companion_27).r1e = function (name) {
    var indexedObject = values_0();
    var inductionVariable = 0;
    var last = indexedObject.length;
    while (inductionVariable < last) {
      var alignment = indexedObject[inductionVariable];
      inductionVariable = inductionVariable + 1 | 0;
      if (alignment.d45_1 === name) {
        return alignment;
      }
    }
    throw IllegalArgumentException_init_$Create$("Cannot determine HorizontalAlignment for '" + name + "'");
  };
  var Companion_instance_32;
  function Companion_getInstance_37() {
    return Companion_instance_32;
  }
  function values_0() {
    return [HorizontalAlignment_LEFT_getInstance(), HorizontalAlignment_CENTER_getInstance(), HorizontalAlignment_RIGHT_getInstance()];
  }
  var HorizontalAlignment_entriesInitialized;
  function HorizontalAlignment_initEntries() {
    if (HorizontalAlignment_entriesInitialized)
      return Unit_instance;
    HorizontalAlignment_entriesInitialized = true;
    HorizontalAlignment_LEFT_instance = new HorizontalAlignment$LEFT();
    HorizontalAlignment_CENTER_instance = new HorizontalAlignment$CENTER();
    HorizontalAlignment_RIGHT_instance = new HorizontalAlignment$RIGHT();
  }
  function HorizontalAlignment(name, ordinal, customName) {
    Enum.call(this, name, ordinal);
    this.d45_1 = customName;
  }
  protoOf(HorizontalAlignment).toString = function () {
    var tmp;
    switch (this.l2_1) {
      case 0:
        tmp = Translations_getInstance().zm('edit.property.horizontalAlignment.left.name', []);
        break;
      case 1:
        tmp = Translations_getInstance().zm('edit.property.horizontalAlignment.center.name', []);
        break;
      case 2:
        tmp = Translations_getInstance().zm('edit.property.horizontalAlignment.right.name', []);
        break;
      default:
        noWhenBranchMatchedException();
        break;
    }
    return tmp;
  };
  function VerticalAlignment$TOP() {
    VerticalAlignment.call(this, 'TOP', 0, 'top');
    VerticalAlignment_TOP_instance = this;
  }
  protoOf(VerticalAlignment$TOP).r4a = function () {
    return VerticalAlignment_BOTTOM_getInstance();
  };
  protoOf(VerticalAlignment$TOP).s4a = function (baselineRect) {
    return 0.0;
  };
  var VerticalAlignment_TOP_instance;
  function VerticalAlignment$CENTER() {
    VerticalAlignment.call(this, 'CENTER', 1, 'center');
    VerticalAlignment_CENTER_instance = this;
  }
  protoOf(VerticalAlignment$CENTER).r4a = function () {
    return VerticalAlignment_CENTER_getInstance();
  };
  protoOf(VerticalAlignment$CENTER).s4a = function (baselineRect) {
    return baselineRect.r1b() / 2 + 1;
  };
  var VerticalAlignment_CENTER_instance;
  function VerticalAlignment$BOTTOM() {
    VerticalAlignment.call(this, 'BOTTOM', 2, 'bottom');
    VerticalAlignment_BOTTOM_instance = this;
  }
  protoOf(VerticalAlignment$BOTTOM).r4a = function () {
    return VerticalAlignment_TOP_getInstance();
  };
  protoOf(VerticalAlignment$BOTTOM).s4a = function (baselineRect) {
    return baselineRect.r1b();
  };
  var VerticalAlignment_BOTTOM_instance;
  function Companion_28() {
  }
  protoOf(Companion_28).r1e = function (name) {
    var indexedObject = values_1();
    var inductionVariable = 0;
    var last = indexedObject.length;
    while (inductionVariable < last) {
      var alignment = indexedObject[inductionVariable];
      inductionVariable = inductionVariable + 1 | 0;
      if (alignment.a45_1 === name) {
        return alignment;
      }
    }
    throw IllegalArgumentException_init_$Create$("Cannot determine HorizontalAlignment for '" + name + "'");
  };
  var Companion_instance_33;
  function Companion_getInstance_38() {
    return Companion_instance_33;
  }
  function values_1() {
    return [VerticalAlignment_TOP_getInstance(), VerticalAlignment_CENTER_getInstance(), VerticalAlignment_BOTTOM_getInstance()];
  }
  var VerticalAlignment_entriesInitialized;
  function VerticalAlignment_initEntries() {
    if (VerticalAlignment_entriesInitialized)
      return Unit_instance;
    VerticalAlignment_entriesInitialized = true;
    VerticalAlignment_TOP_instance = new VerticalAlignment$TOP();
    VerticalAlignment_CENTER_instance = new VerticalAlignment$CENTER();
    VerticalAlignment_BOTTOM_instance = new VerticalAlignment$BOTTOM();
  }
  function VerticalAlignment(name, ordinal, customName) {
    Enum.call(this, name, ordinal);
    this.a45_1 = customName;
  }
  protoOf(VerticalAlignment).toString = function () {
    var tmp;
    switch (this.l2_1) {
      case 0:
        tmp = Translations_getInstance().zm('edit.property.verticalAlignment.top.name', []);
        break;
      case 1:
        tmp = Translations_getInstance().zm('edit.property.verticalAlignment.center.name', []);
        break;
      case 2:
        tmp = Translations_getInstance().zm('edit.property.verticalAlignment.bottom.name', []);
        break;
      default:
        noWhenBranchMatchedException();
        break;
    }
    return tmp;
  };
  function Companion_29() {
  }
  protoOf(Companion_29).z4a = function (orientation) {
    var tmp;
    switch (orientation.l2_1) {
      case 0:
        tmp = new Alignment(HorizontalAlignment_RIGHT_getInstance(), VerticalAlignment_CENTER_getInstance());
        break;
      case 1:
        tmp = new Alignment(HorizontalAlignment_CENTER_getInstance(), VerticalAlignment_TOP_getInstance());
        break;
      case 2:
        tmp = new Alignment(HorizontalAlignment_LEFT_getInstance(), VerticalAlignment_CENTER_getInstance());
        break;
      case 3:
        tmp = new Alignment(HorizontalAlignment_CENTER_getInstance(), VerticalAlignment_BOTTOM_getInstance());
        break;
      default:
        noWhenBranchMatchedException();
        break;
    }
    return tmp;
  };
  var Companion_instance_34;
  function Companion_getInstance_39() {
    return Companion_instance_34;
  }
  function Alignment(horizontal, vertical) {
    this.a4b_1 = horizontal;
    this.b4b_1 = vertical;
  }
  protoOf(Alignment).toString = function () {
    return 'Alignment(horizontal=' + this.a4b_1.toString() + ', vertical=' + this.b4b_1.toString() + ')';
  };
  protoOf(Alignment).hashCode = function () {
    var result = this.a4b_1.hashCode();
    result = imul(result, 31) + this.b4b_1.hashCode() | 0;
    return result;
  };
  protoOf(Alignment).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof Alignment))
      return false;
    if (!this.a4b_1.equals(other.a4b_1))
      return false;
    if (!this.b4b_1.equals(other.b4b_1))
      return false;
    return true;
  };
  function HorizontalAlignment_LEFT_getInstance() {
    HorizontalAlignment_initEntries();
    return HorizontalAlignment_LEFT_instance;
  }
  function HorizontalAlignment_CENTER_getInstance() {
    HorizontalAlignment_initEntries();
    return HorizontalAlignment_CENTER_instance;
  }
  function HorizontalAlignment_RIGHT_getInstance() {
    HorizontalAlignment_initEntries();
    return HorizontalAlignment_RIGHT_instance;
  }
  function VerticalAlignment_TOP_getInstance() {
    VerticalAlignment_initEntries();
    return VerticalAlignment_TOP_instance;
  }
  function VerticalAlignment_CENTER_getInstance() {
    VerticalAlignment_initEntries();
    return VerticalAlignment_CENTER_instance;
  }
  function VerticalAlignment_BOTTOM_getInstance() {
    VerticalAlignment_initEntries();
    return VerticalAlignment_BOTTOM_instance;
  }
  function fillProperties($this, properties) {
    properties.ct('edit.grid.painter', 'line');
  }
  function EditModelTextModule$initialize$lambda(s) {
    return new DottedGridPainter(s);
  }
  function EditModelTextModule$initialize$lambda_0(s) {
    return new LineGridPainter(s);
  }
  function EditModelTextModule$initialize$lambda_1(it) {
    return new RectangularHandleSelectionModel(it instanceof AbstractRectangularComponent ? it : THROW_CCE());
  }
  function EditModelTextModule$initialize$lambda_2(it) {
    return new RectangularHandleSelectionModel(it instanceof AbstractRectangularComponent ? it : THROW_CCE());
  }
  function EditModelTextModule$initialize$lambda_3(it) {
    return new RectangularReplaceSelectionModel(it instanceof AbstractRectangularComponent ? it : THROW_CCE());
  }
  function EditModelTextModule() {
    EditModelTextModule_instance = this;
    AbstractModule.call(this);
    this.p39_1 = new UndefinedTextComponentFactory();
  }
  protoOf(EditModelTextModule).ro = function () {
    var tmp = GridPainterRegistry_getInstance();
    tmp.n3c('dot', EditModelTextModule$initialize$lambda);
    var tmp_0 = GridPainterRegistry_getInstance();
    tmp_0.n3c('line', EditModelTextModule$initialize$lambda_0);
    var tmp_1 = EditSelectModule_getInstance().b3l_1;
    var tmp_2 = SelectionDrawingStrategy_ABOVE_getInstance();
    var tmp_3 = getKClass(TextComponent);
    tmp_1.w3u(tmp_2, tmp_3, EditModelTextModule$initialize$lambda_1);
    var tmp_4 = EditSelectModule_getInstance().b3l_1;
    var tmp_5 = SelectionDrawingStrategy_ABOVE_getInstance();
    var tmp_6 = getKClass(SimpleTextComponent);
    tmp_4.w3u(tmp_5, tmp_6, EditModelTextModule$initialize$lambda_2);
    var tmp_7 = EditSelectModule_getInstance().b3l_1;
    var tmp_8 = SelectionDrawingStrategy_REPLACE_getInstance();
    var tmp_9 = getKClass(SimpleTextComponent);
    tmp_7.w3u(tmp_8, tmp_9, EditModelTextModule$initialize$lambda_3);
    fillProperties(this, DrawModule_getInstance().v29_1);
  };
  var EditModelTextModule_instance;
  function EditModelTextModule_getInstance() {
    if (EditModelTextModule_instance == null)
      new EditModelTextModule();
    return EditModelTextModule_instance;
  }
  function updateLocation($this) {
    $this.d4b_1.f20($this.c4b_1.g20().w1h($this.f4b_1.in_1, $this.f4b_1.jn_1));
  }
  function updateAlignment($this) {
    if ($this.e4b_1 == null) {
      $this.d4b_1.g4b(new Alignment(HorizontalAlignment_CENTER_getInstance(), VerticalAlignment_CENTER_getInstance()));
    } else {
      switch ($this.c4b_1.g20().a1i(ensureNotNull($this.e4b_1)).l2_1) {
        case 0:
          $this.d4b_1.g4b(new Alignment(HorizontalAlignment_LEFT_getInstance(), VerticalAlignment_CENTER_getInstance()));
          break;
        case 2:
          $this.d4b_1.g4b(new Alignment(HorizontalAlignment_RIGHT_getInstance(), VerticalAlignment_CENTER_getInstance()));
          break;
        case 1:
          $this.d4b_1.g4b(new Alignment(HorizontalAlignment_CENTER_getInstance(), VerticalAlignment_BOTTOM_getInstance()));
          break;
        case 3:
          $this.d4b_1.g4b(new Alignment(HorizontalAlignment_CENTER_getInstance(), VerticalAlignment_TOP_getInstance()));
          break;
        default:
          noWhenBranchMatchedException();
          break;
      }
    }
  }
  function HorizontalLabel(owner, relLocation, orientation, text, font, color) {
    orientation = orientation === VOID ? Direction_EAST_getInstance() : orientation;
    text = text === VOID ? null : text;
    color = color === VOID ? null : color;
    this.c4b_1 = owner;
    this.d4b_1 = new Label(text, font, color, VOID, VOID, relLocation);
    this.e4b_1 = orientation;
    this.f4b_1 = relLocation;
    this.v1z();
  }
  protoOf(HorizontalLabel).w44 = function (value) {
    this.d4b_1.w44(value);
  };
  protoOf(HorizontalLabel).c4a = function () {
    return this.d4b_1.j44_1;
  };
  protoOf(HorizontalLabel).do = function () {
    return this.d4b_1.t44_1;
  };
  protoOf(HorizontalLabel).h4b = function (value) {
    if (!equals(this.e4b_1, value)) {
      this.e4b_1 = value;
      updateAlignment(this);
    }
  };
  protoOf(HorizontalLabel).i4b = function (value) {
    if (!this.f4b_1.equals(value)) {
      this.f4b_1 = value;
      updateLocation(this);
    }
  };
  protoOf(HorizontalLabel).v1z = function () {
    updateLocation(this);
    updateAlignment(this);
  };
  protoOf(HorizontalLabel).r1z = function (context) {
    // Inline function 'io.antarescircuit.jabbah.draw.DrawContext.translated' call
    var d = this.c4b_1.hw();
    context.t1y_1.v1c(d.in_1, d.jn_1);
    this.d4b_1.r1z(context);
    context.t1y_1.v1c(-d.in_1, -d.jn_1);
  };
  function Companion_30() {
    Companion_instance_35 = this;
    this.j4b_1 = HorizontalAlignment_CENTER_getInstance();
    this.k4b_1 = VerticalAlignment_CENTER_getInstance();
    this.l4b_1 = 1;
  }
  var Companion_instance_35;
  function Companion_getInstance_40() {
    if (Companion_instance_35 == null)
      new Companion_30();
    return Companion_instance_35;
  }
  function updateBoundingBox_1($this) {
    $this.t44_1 = $this.g44_1.z1h($this.l44_1, $this.r44_1);
  }
  function drawImpl_0($this, richText, context) {
    var oldColor = context.t1y_1.m1t();
    DrawModule_getInstance().g2p($this, context.t1y_1, Companion_getInstance_3().s1s_1);
    DrawModule_getInstance().i2p($this.l44_1, context, Companion_getInstance_3().w1s_1);
    var tmp;
    if (context.w1y_1) {
      var tmp_0;
      if ($this.s44_1) {
        tmp_0 = ensureNotNull(context.x1y_1).i1x_1;
      } else {
        tmp_0 = ensureNotNull(context.x1y_1).j1x_1;
      }
      tmp = tmp_0;
    } else {
      var tmp0_elvis_lhs = $this.f44_1;
      tmp = tmp0_elvis_lhs == null ? context.t1y_1.m1t() : tmp0_elvis_lhs;
    }
    var foregroundColor = tmp;
    context.t1y_1.w1t($this.k44_1);
    drawTextRotated($this, richText, context, foregroundColor);
    context.t1y_1.l1t(oldColor);
  }
  function drawTextRotated($this, richText, context, foregroundColor) {
    $this.o44_1.o4b(context, $this);
    context.t1y_1.v1c($this.l44_1.in_1, $this.l44_1.jn_1);
    context.t1y_1.y1c($this.g44_1.s1h_1);
    context.t1y_1.v1c(-$this.l44_1.in_1, -$this.l44_1.jn_1);
    if ($this.i44_1) {
      context.t1y_1.l1t(DrawStyleModule_getInstance().g1x_1.p1x(Companion_getInstance_0().n1x_1).m1t().i1x_1);
      context.t1y_1.u1u($this.r44_1);
    }
    context.t1y_1.l1t(foregroundColor);
    richText.r1z(context);
    context.t1y_1.v1c($this.l44_1.in_1, $this.l44_1.jn_1);
    context.t1y_1.y1c(-$this.g44_1.s1h_1);
    context.t1y_1.v1c(-$this.l44_1.in_1, -$this.l44_1.jn_1);
    $this.o44_1.p4b(context, $this);
  }
  function updateGeometry_0($this) {
    $this.s1z();
    positionDisplayableText($this, $this.q44_1);
    $this.r44_1.w1b($this.q44_1.k2b());
    updateBoundingBox_1($this);
    $this.v1z();
    $this.u1z();
  }
  function positionDisplayableText($this, text) {
    text.f20(new Point2D($this.l44_1.in_1 + $this.g40().h4a(text.h2h_1) - 1, $this.l44_1.jn_1 - $this.e40().s4a(text.h2h_1) + 1 - 1));
  }
  function Label(text, font, color, horizontalAlignment, verticalAlignment, location, rotationDisplayStrategy, rotation, ownerRotation, richText, displayableText, fillBackground) {
    Companion_getInstance_40();
    color = color === VOID ? null : color;
    horizontalAlignment = horizontalAlignment === VOID ? Companion_getInstance_40().j4b_1 : horizontalAlignment;
    verticalAlignment = verticalAlignment === VOID ? Companion_getInstance_40().k4b_1 : verticalAlignment;
    location = location === VOID ? Companion_getInstance().g1a_1 : location;
    rotationDisplayStrategy = rotationDisplayStrategy === VOID ? RotationDisplayStrategy_IGNORE_getInstance() : rotationDisplayStrategy;
    rotation = rotation === VOID ? Rotation_R0_getInstance() : rotation;
    ownerRotation = ownerRotation === VOID ? Rotation_R0_getInstance() : ownerRotation;
    richText = richText === VOID ? true : richText;
    var tmp;
    if (displayableText === VOID) {
      var tmp_0;
      if (richText) {
        var tmp_1 = Companion_getInstance_4();
        tmp_0 = tmp_1.m2i(text == null ? '' : text, font);
      } else {
        var tmp_2 = Companion_getInstance_4();
        tmp_0 = tmp_2.o2i(text == null ? '' : text, font);
      }
      tmp = tmp_0;
    } else {
      tmp = displayableText;
    }
    displayableText = tmp;
    fillBackground = fillBackground === VOID ? false : fillBackground;
    AbstractDrawable.call(this);
    this.f44_1 = color;
    this.g44_1 = rotation;
    this.h44_1 = richText;
    this.i44_1 = fillBackground;
    var tmp_3 = this;
    tmp_3.j44_1 = text == null ? '' : text;
    this.k44_1 = font;
    this.l44_1 = location;
    this.m44_1 = horizontalAlignment;
    this.n44_1 = verticalAlignment;
    this.o44_1 = rotationDisplayStrategy;
    this.p44_1 = ownerRotation;
    this.q44_1 = displayableText;
    this.r44_1 = new Rectangle2D();
    this.s44_1 = false;
    this.t44_1 = new Rectangle2D();
    updateGeometry_0(this);
  }
  protoOf(Label).w44 = function (value) {
    if (!(this.j44_1 === value)) {
      this.s1z();
      this.j44_1 = value;
      if (this.h44_1) {
        this.q44_1 = Companion_getInstance_4().m2i(value, this.k44_1);
      } else {
        this.q44_1 = Companion_getInstance_4().o2i(value, this.k44_1);
      }
      updateGeometry_0(this);
    }
  };
  protoOf(Label).w1t = function (value) {
    if (!equals(this.k44_1, value)) {
      this.s1z();
      this.k44_1 = value;
      this.q44_1 = Companion_getInstance_4().m2i(this.j44_1, this.k44_1);
      updateGeometry_0(this);
    }
  };
  protoOf(Label).f20 = function (value) {
    if (!this.l44_1.equals(value)) {
      this.s1z();
      this.l44_1 = value;
      updateGeometry_0(this);
    }
  };
  protoOf(Label).hw = function () {
    return this.l44_1;
  };
  protoOf(Label).f40 = function (value) {
    if (!this.m44_1.equals(value)) {
      this.s1z();
      this.m44_1 = value;
      updateGeometry_0(this);
    }
  };
  protoOf(Label).g40 = function () {
    return this.m44_1;
  };
  protoOf(Label).d40 = function (value) {
    if (!this.e40().equals(value)) {
      this.s1z();
      this.n44_1 = value;
      updateGeometry_0(this);
    }
  };
  protoOf(Label).e40 = function () {
    return this.n44_1;
  };
  protoOf(Label).g4b = function (value) {
    if (!this.q4b().equals(value)) {
      this.s1z();
      this.m44_1 = value.a4b_1;
      this.n44_1 = value.b4b_1;
      updateGeometry_0(this);
    }
  };
  protoOf(Label).q4b = function () {
    return new Alignment(this.g40(), this.e40());
  };
  protoOf(Label).r4b = function (value) {
    if (!this.o44_1.equals(value)) {
      this.o44_1 = value;
      this.s1z();
    }
  };
  protoOf(Label).do = function () {
    return this.t44_1;
  };
  protoOf(Label).eo = function (x, y) {
    return this.r44_1.eo(x, y);
  };
  protoOf(Label).r1z = function (context) {
    drawImpl_0(this, this.q44_1, context);
  };
  protoOf(Label).s4b = function (text, context) {
    positionDisplayableText(this, text);
    drawImpl_0(this, text, context);
  };
  protoOf(Label).p2h = function (x) {
    this.f20(this.l44_1.q1g(x));
    this.f40(this.g40().e1f());
    updateGeometry_0(this);
  };
  protoOf(Label).q2h = function (y) {
    this.f20(this.l44_1.r1g(y));
    this.d40(this.e40().r4a());
    updateGeometry_0(this);
  };
  function Labeled() {
  }
  function createLabel($this, text, styleProvider) {
    return new Label(text, styleProvider.p1x(Companion_getInstance_0().k1x_1).l2c(), VOID, HorizontalAlignment_CENTER_getInstance(), VerticalAlignment_CENTER_getInstance(), Companion_getInstance().g1a_1, RotationDisplayStrategy_IGNORE_getInstance());
  }
  function Companion_31() {
    Companion_instance_36 = this;
    this.t4b_1 = Translations_getInstance().zm('edit.component.label', []);
    this.u4b_1 = 'text';
  }
  var Companion_instance_36;
  function Companion_getInstance_41() {
    if (Companion_instance_36 == null)
      new Companion_31();
    return Companion_instance_36;
  }
  function LabelComponent(styleProvider, label, inverse) {
    Companion_getInstance_41();
    styleProvider = styleProvider === VOID ? DrawStyleModule_getInstance().g1x_1 : styleProvider;
    label = label === VOID ? createLabel(Companion_getInstance_41(), 'text', styleProvider) : label;
    inverse = inverse === VOID ? false : inverse;
    AbstractRectangularComponent.call(this, Companion_getInstance_0().l1x_1, styleProvider);
    this.f4c_1 = label;
    this.g4c_1 = inverse;
    this.h4c_1 = null;
    new DrawableOwner(this, this.f4c_1);
    this.i4c_1 = TranslatableText_init_$Create$(this.f4c_1.j44_1);
    this.j4c_1 = HorizontalAlignment_CENTER_getInstance();
    this.k4c_1 = new TransparentImpl(this);
    this.l4c_1 = Companion_getInstance_41().t4b_1;
  }
  protoOf(LabelComponent).v17 = function () {
    return this.f4c_1;
  };
  protoOf(LabelComponent).m4c = function (value) {
    this.g4c_1 = value;
    this.f4c_1.s44_1 = this.g4c_1;
  };
  protoOf(LabelComponent).d4a = function (value) {
    if (!equals(this.i4c_1, value)) {
      this.s1z();
      this.i4c_1 = value;
      this.f4c_1.w44(this.i4c_1.ov() ? '' : this.i4c_1.u44());
      this.w1b(this.f4c_1.t44_1);
      this.s1z();
      this.v1z();
    }
  };
  protoOf(LabelComponent).k2h = function (value) {
    this.k4c_1.k2h(value);
  };
  protoOf(LabelComponent).n2h = function () {
    return this.k4c_1.m2h_1;
  };
  protoOf(LabelComponent).t3a = function () {
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [new SnappableXCoordinate(this.hw().in_1)];
  };
  protoOf(LabelComponent).u3a = function () {
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [new SnappableYCoordinate(this.hw().jn_1)];
  };
  protoOf(LabelComponent).do = function () {
    var tmp;
    if (this.h4c_1 == null) {
      tmp = this.f4c_1.t44_1;
    } else {
      var tmp_0 = Companion_instance_3.z1g(this.hw(), ensureNotNull(this.h4c_1).e1e_1, ensureNotNull(this.h4c_1).f1e_1).z1b(this.v1t().p1t_1 / 2.0);
      tmp = tmp_0 instanceof Rectangle2D ? tmp_0 : THROW_CCE();
    }
    var bbox = tmp;
    var tmp_1;
    if (this.g20().equals(Rotation_R0_getInstance()) || this.g20().equals(Rotation_R180_getInstance())) {
      tmp_1 = bbox;
    } else {
      tmp_1 = this.g20().z1h(bbox.n1c(), bbox);
    }
    return tmp_1;
  };
  protoOf(LabelComponent).eo = function (x, y) {
    return this.f4c_1.eo(x, y);
  };
  protoOf(LabelComponent).no = function (p) {
    return this.f4c_1.no(p);
  };
  protoOf(LabelComponent).po = function (rect) {
    return this.f4c_1.po(rect);
  };
  protoOf(LabelComponent).r1z = function (context) {
    context.t1y_1.v1c(this.hw().in_1, this.hw().jn_1);
    context.t1y_1.y1c(this.g20().s1h_1);
    context.t1y_1.v1c(-this.hw().in_1, -this.hw().jn_1);
    if (this.g4c_1 && !(this.h4c_1 == null)) {
      var tmp;
      if (context.w1y_1) {
        tmp = ensureNotNull(context.x1y_1).h1x_1;
      } else {
        tmp = this.k4c_1.v2g(this.i2c());
      }
      context.t1y_1.l1t(tmp);
      var rect = Companion_instance_3.z1g(this.hw(), ensureNotNull(this.h4c_1).e1e_1, ensureNotNull(this.h4c_1).f1e_1);
      context.t1y_1.u1u(rect);
      context.t1y_1.o1t(this.v1t());
      context.t1y_1.t1u(rect);
    }
    if (!context.w1y_1) {
      var tmp_0;
      if (this.g4c_1 && !(this.h4c_1 == null)) {
        tmp_0 = this.k4c_1.v2g(this.j2c());
      } else {
        tmp_0 = this.k4c_1.v2g(this.i2c());
      }
      context.t1y_1.l1t(tmp_0);
    }
    this.f4c_1.r1z(context);
    context.t1y_1.v1c(this.hw().in_1, this.hw().jn_1);
    context.t1y_1.y1c(-this.g20().s1h_1);
    context.t1y_1.v1c(-this.hw().in_1, -this.hw().jn_1);
  };
  protoOf(LabelComponent).p2h = function (x) {
    protoOf(AbstractRectangularComponent).p2h.call(this, x);
    this.f4c_1.p2h(x);
  };
  protoOf(LabelComponent).q2h = function (y) {
    protoOf(AbstractRectangularComponent).q2h.call(this, y);
    this.f4c_1.q2h(y);
  };
  protoOf(LabelComponent).f20 = function (value) {
    this.f4c_1.f20(value);
  };
  protoOf(LabelComponent).hw = function () {
    return this.f4c_1.l44_1;
  };
  protoOf(LabelComponent).r37 = function (writer) {
    writer.t38('id', this.av());
    if (!this.i4c_1.ov()) {
      writer.r38('text', this.i4c_1.x44());
    }
    writer.d39('location', this.f4c_1.l44_1);
    writer.w38('rot', this.g20().r1h_1);
    if (this.g4c_1) {
      writer.y38('inverse', this.g4c_1);
    }
    var tmp0_safe_receiver = this.h4c_1;
    if (tmp0_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      writer.u38('w', tmp0_safe_receiver.e1e_1);
      writer.u38('h', tmp0_safe_receiver.f1e_1);
    }
    if (!(this.u2c() == null)) {
      writer.w38('color', ensureNotNull(this.u2c()).m2());
    }
  };
  protoOf(LabelComponent).s37 = function (reader) {
    if (reader.d35('id')) {
      this.k3a(reader.z37('id'));
    }
    if (reader.d35('text')) {
      this.d4a(TranslatableText_init_$Create$(reader.b38('text')));
    }
    if (reader.e35('text')) {
      this.d4a(new TranslatableText(reader.x37('text')));
    }
    this.f20(reader.i38('location'));
    if (reader.d35('rot')) {
      this.w27(Companion_instance_1.r1e(reader.b38('rot')));
    }
    if (reader.d35('inverse')) {
      this.m4c(reader.d38('inverse'));
    }
    if (reader.d35('w') && reader.d35('h')) {
      this.h4c_1 = new Dimension2D(reader.a38('w'), reader.a38('h'));
    }
    if (reader.d35('color')) {
      this.t2c(this.h2c().a2t().q2n(reader.b38('color')));
    }
  };
  protoOf(LabelComponent).u19 = function () {
    return this.l4c_1;
  };
  protoOf(LabelComponent).p3a = function () {
    return SelectionDrawingStrategy_REPLACE_getInstance();
  };
  protoOf(LabelComponent).x2h = function () {
    return true;
  };
  protoOf(LabelComponent).l3m = function (newRotation) {
    this.f4c_1.p44_1 = this.g20();
  };
  function calculateRotation($this, label) {
    var tmp;
    switch (label.p44_1.v1h(label.g44_1).l2_1) {
      case 0:
        tmp = Rotation_R0_getInstance();
        break;
      case 2:
        tmp = Rotation_R180_getInstance();
        break;
      case 1:
        tmp = Rotation_R0_getInstance();
        break;
      case 3:
        tmp = Rotation_R180_getInstance();
        break;
      default:
        noWhenBranchMatchedException();
        break;
    }
    return tmp;
  }
  function RotationDisplayStrategy$IGNORE() {
    RotationDisplayStrategy.call(this, 'IGNORE', 0);
    RotationDisplayStrategy_IGNORE_instance = this;
  }
  protoOf(RotationDisplayStrategy$IGNORE).o4b = function (context, label) {
  };
  protoOf(RotationDisplayStrategy$IGNORE).p4b = function (context, label) {
  };
  var RotationDisplayStrategy_IGNORE_instance;
  function RotationDisplayStrategy$ROTATE_HALF() {
    RotationDisplayStrategy.call(this, 'ROTATE_HALF', 1);
    RotationDisplayStrategy_ROTATE_HALF_instance = this;
  }
  protoOf(RotationDisplayStrategy$ROTATE_HALF).o4b = function (context, label) {
    var pivot = label.g44_1.y1h(label.l44_1, label.r44_1.n1c());
    context.t1y_1.w1c(pivot);
    context.t1y_1.y1c(calculateRotation(this, label).s1h_1);
    context.t1y_1.w1c(pivot.m1g());
  };
  protoOf(RotationDisplayStrategy$ROTATE_HALF).p4b = function (context, label) {
    var pivot = label.g44_1.y1h(label.l44_1, label.r44_1.n1c());
    context.t1y_1.w1c(pivot);
    context.t1y_1.y1c(calculateRotation(this, label).s1h_1);
    context.t1y_1.w1c(pivot.m1g());
  };
  var RotationDisplayStrategy_ROTATE_HALF_instance;
  function RotationDisplayStrategy$KEEP_HORIZONTAL() {
    RotationDisplayStrategy.call(this, 'KEEP_HORIZONTAL', 2);
    RotationDisplayStrategy_KEEP_HORIZONTAL_instance = this;
  }
  protoOf(RotationDisplayStrategy$KEEP_HORIZONTAL).o4b = function (context, label) {
    var pivot = label.g44_1.y1h(label.l44_1, label.r44_1.n1c());
    context.t1y_1.w1c(pivot);
    context.t1y_1.y1c(-label.p44_1.s1h_1);
    context.t1y_1.w1c(pivot.m1g());
  };
  protoOf(RotationDisplayStrategy$KEEP_HORIZONTAL).p4b = function (context, label) {
    var pivot = label.g44_1.y1h(label.l44_1, label.r44_1.n1c());
    context.t1y_1.w1c(pivot);
    context.t1y_1.y1c(label.p44_1.s1h_1);
    context.t1y_1.w1c(pivot.m1g());
  };
  var RotationDisplayStrategy_KEEP_HORIZONTAL_instance;
  var RotationDisplayStrategy_entriesInitialized;
  function RotationDisplayStrategy_initEntries() {
    if (RotationDisplayStrategy_entriesInitialized)
      return Unit_instance;
    RotationDisplayStrategy_entriesInitialized = true;
    RotationDisplayStrategy_IGNORE_instance = new RotationDisplayStrategy$IGNORE();
    RotationDisplayStrategy_ROTATE_HALF_instance = new RotationDisplayStrategy$ROTATE_HALF();
    RotationDisplayStrategy_KEEP_HORIZONTAL_instance = new RotationDisplayStrategy$KEEP_HORIZONTAL();
  }
  function RotationDisplayStrategy(name, ordinal) {
    Enum.call(this, name, ordinal);
  }
  function RotationDisplayStrategy_IGNORE_getInstance() {
    RotationDisplayStrategy_initEntries();
    return RotationDisplayStrategy_IGNORE_instance;
  }
  function RotationDisplayStrategy_ROTATE_HALF_getInstance() {
    RotationDisplayStrategy_initEntries();
    return RotationDisplayStrategy_ROTATE_HALF_instance;
  }
  function RotationDisplayStrategy_KEEP_HORIZONTAL_getInstance() {
    RotationDisplayStrategy_initEntries();
    return RotationDisplayStrategy_KEEP_HORIZONTAL_instance;
  }
  function Companion_32() {
    this.t4c_1 = 16;
  }
  var Companion_instance_37;
  function Companion_getInstance_42() {
    return Companion_instance_37;
  }
  function _get_displayedText__nja87x($this) {
    return $this.i4d_1.ov() ? '' : $this.i4d_1.u44();
  }
  function updateMultilineText($this) {
    $this.j4d_1 = createMultilineText($this);
  }
  function createMultilineText($this) {
    return Companion_getInstance_4().t2g(_get_displayedText__nja87x($this), $this.l2c(), numberToInt($this.p1b()) - imul(2, Companion_getInstance_36().m49_1) | 0);
  }
  function SimpleTextComponent(text, location, styleType, styleProvider) {
    text = text === VOID ? new TranslatableText() : text;
    location = location === VOID ? Companion_getInstance().g1a_1 : location;
    styleType = styleType === VOID ? Companion_getInstance_0().l1x_1 : styleType;
    styleProvider = styleProvider === VOID ? DrawStyleModule_getInstance().g1x_1 : styleProvider;
    var tmp0_shape = new Rectangle2D(location.in_1, location.jn_1, 100.0, 50.0);
    AbstractTextComponent.call(this, VOID, tmp0_shape, styleType, styleProvider);
    this.i4d_1 = text;
    this.j4d_1 = createMultilineText(this);
    updateMultilineText(this);
  }
  protoOf(SimpleTextComponent).d4a = function (value) {
    if (!equals(this.i4d_1, value)) {
      this.s1z();
      this.i4d_1 = value;
      updateMultilineText(this);
      this.s1z();
      this.v1z();
      this.u1z();
    }
  };
  protoOf(SimpleTextComponent).c4a = function () {
    return this.i4d_1;
  };
  protoOf(SimpleTextComponent).r1z = function (context) {
    if (this.p2c()) {
      this.b4a_1.k4d(this, context);
    }
    context.t1y_1.w1t(this.l2c());
    context.t1y_1.l1t(this.k2c());
    var tmp2 = this.z19() + Companion_getInstance_36().m49_1;
    // Inline function 'io.antarescircuit.jabbah.draw.DrawContext.translated' call
    var dy = this.a1a() + Companion_getInstance_36().n49_1 + 16;
    context.t1y_1.v1c(tmp2, dy);
    this.j4d_1.r1z(context);
    context.t1y_1.v1c(-tmp2, -dy);
    if (this.r2c()) {
      this.b4a_1.l4d(this, context);
    }
  };
  protoOf(SimpleTextComponent).v1z = function () {
    updateMultilineText(this);
    protoOf(AbstractTextComponent).v1z.call(this);
  };
  function TextComponent() {
  }
  function UndefinedTextComponentFactory() {
  }
  function adjustShape($this, c) {
    $this.m4d_1.s1b(c.z19(), c.a1a(), c.p1b(), c.r1b());
  }
  function RectangularShapeTextComponentDecorator(shape, stylable, transparent) {
    this.m4d_1 = shape;
    this.n4d_1 = stylable;
    this.o4d_1 = transparent;
  }
  protoOf(RectangularShapeTextComponentDecorator).k4d = function (component, context) {
    if (this.n4d_1.p2c()) {
      adjustShape(this, component);
      context.t1y_1.l1t(context.w1y_1 ? ensureNotNull(context.x1y_1).i1x_1 : this.o4d_1.v2g(this.n4d_1.j2c()));
      context.t1y_1.u1u(this.m4d_1);
    }
  };
  protoOf(RectangularShapeTextComponentDecorator).l4d = function (component, context) {
    adjustShape(this, component);
    context.t1y_1.l1t(context.w1y_1 ? ensureNotNull(context.x1y_1).h1x_1 : this.o4d_1.v2g(this.n4d_1.i2c()));
    context.t1y_1.o1t(this.n4d_1.v1t());
    context.t1y_1.t1u(this.m4d_1);
  };
  function TextDrawableButtonRenderer(text, dimension, style) {
    AbstractDrawableButtonRenderer.call(this);
    this.p4d_1 = dimension;
    this.q4d_1 = style;
    this.r4d_1 = new Label(text, this.q4d_1.l2c(), null);
  }
  protoOf(TextDrawableButtonRenderer).c1x = function () {
    return this.p4d_1;
  };
  protoOf(TextDrawableButtonRenderer).w2e = function (button, context) {
    var tmp;
    if (context.w1y_1) {
      tmp = ensureNotNull(context.x1y_1);
    } else {
      tmp = this.z2e(button);
    }
    var color = tmp;
    context.t1y_1.l1t(color.h1x_1);
    context.t1y_1.o1t(this.q4d_1.v1t());
    context.t1y_1.t1u(button.k2b());
    context.t1y_1.w1c(button.k2b().n1c());
    this.r4d_1.f44_1 = color.j1x_1;
    this.r4d_1.r1z(context);
    context.t1y_1.w1c(button.k2b().n1c().m1g());
  };
  function ScriptProperty(script) {
    script = script === VOID ? null : script;
    this.s4d_1 = script;
  }
  protoOf(ScriptProperty).t4d = function () {
    return StringUtils_getInstance().ju(this.s4d_1);
  };
  protoOf(ScriptProperty).toString = function () {
    return 'ScriptProperty(script=' + this.s4d_1 + ')';
  };
  protoOf(ScriptProperty).hashCode = function () {
    return this.s4d_1 == null ? 0 : getStringHashCode(this.s4d_1);
  };
  protoOf(ScriptProperty).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof ScriptProperty))
      return false;
    if (!(this.s4d_1 == other.s4d_1))
      return false;
    return true;
  };
  function Translatable() {
  }
  function TranslatableText_init_$Init$(text, $this) {
    TranslatableText_init_$Init$_1(System_getInstance().fm(), text, $this);
    return $this;
  }
  function TranslatableText_init_$Create$(text) {
    return TranslatableText_init_$Init$(text, objectCreate(protoOf(TranslatableText)));
  }
  function TranslatableText_init_$Init$_0(translation, $this) {
    TranslatableText.call($this, listOf(translation));
    return $this;
  }
  function TranslatableText_init_$Create$_0(translation) {
    return TranslatableText_init_$Init$_0(translation, objectCreate(protoOf(TranslatableText)));
  }
  function TranslatableText_init_$Init$_1(language, text, $this) {
    TranslatableText.call($this, listOf(new Translation(language, text)));
    return $this;
  }
  function TranslatableText(translations) {
    translations = translations === VOID ? null : translations;
    var tmp = this;
    // Inline function 'kotlin.collections.mutableMapOf' call
    tmp.v44_1 = LinkedHashMap_init_$Create$();
    if (translations == null)
      null;
    else {
      // Inline function 'kotlin.collections.forEach' call
      var _iterator__ex2g4s = translations.i();
      while (_iterator__ex2g4s.j()) {
        var element = _iterator__ex2g4s.k();
        var tmp0 = this.v44_1;
        // Inline function 'kotlin.collections.set' call
        var key = element.z4d_1;
        tmp0.y1(key, element);
      }
    }
  }
  protoOf(TranslatableText).toString = function () {
    var tmp0_elvis_lhs = this.x4d();
    return tmp0_elvis_lhs == null ? '' : tmp0_elvis_lhs;
  };
  protoOf(TranslatableText).equals = function (other) {
    if (this === other)
      return true;
    if (other == null)
      return false;
    if (!getKClassFromExpression(this).equals(getKClassFromExpression(other)))
      return false;
    if (!(other instanceof TranslatableText))
      THROW_CCE();
    if (!equals(this.v44_1, other.v44_1))
      return false;
    return true;
  };
  protoOf(TranslatableText).hashCode = function () {
    return hashCode(this.v44_1);
  };
  protoOf(TranslatableText).ov = function () {
    var tmp0 = this.v44_1.c2();
    var tmp$ret$0;
    $l$block_0: {
      // Inline function 'kotlin.collections.all' call
      var tmp;
      if (isInterface(tmp0, Collection)) {
        tmp = tmp0.m();
      } else {
        tmp = false;
      }
      if (tmp) {
        tmp$ret$0 = true;
        break $l$block_0;
      }
      var _iterator__ex2g4s = tmp0.i();
      while (_iterator__ex2g4s.j()) {
        var element = _iterator__ex2g4s.k();
        // Inline function 'kotlin.text.isEmpty' call
        var this_0 = element.a4e_1;
        if (!(charSequenceLength(this_0) === 0)) {
          tmp$ret$0 = false;
          break $l$block_0;
        }
      }
      tmp$ret$0 = true;
    }
    return tmp$ret$0;
  };
  protoOf(TranslatableText).u4d = function (language) {
    var tmp0_elvis_lhs = this.y4d(language);
    var tmp;
    if (tmp0_elvis_lhs == null) {
      throw IllegalArgumentException_init_$Create$('no translation available');
    } else {
      tmp = tmp0_elvis_lhs;
    }
    return tmp;
  };
  protoOf(TranslatableText).w4d = function (language, text) {
    // Inline function 'kotlin.require' call
    if (!StringUtils_getInstance().ju(text)) {
      var message = 'text must not be empty';
      throw IllegalArgumentException_init_$Create$(toString(message));
    }
    var values = toMutableMap(this.v44_1);
    // Inline function 'kotlin.collections.set' call
    var value = new Translation(language, text);
    values.y1(language, value);
    return new TranslatableText(values.c2());
  };
  protoOf(TranslatableText).y4d = function (language) {
    var tmp0_safe_receiver = this.v44_1.g2(language);
    var tmp1_elvis_lhs = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.a4e_1;
    var tmp;
    if (tmp1_elvis_lhs == null) {
      var tmp2_safe_receiver = this.v44_1.g2(Companion_getInstance_5().xu_1);
      tmp = tmp2_safe_receiver == null ? null : tmp2_safe_receiver.a4e_1;
    } else {
      tmp = tmp1_elvis_lhs;
    }
    var tmp3_elvis_lhs = tmp;
    var tmp_0;
    if (tmp3_elvis_lhs == null) {
      var tmp4_safe_receiver = firstOrNull(this.v44_1.c2());
      tmp_0 = tmp4_safe_receiver == null ? null : tmp4_safe_receiver.a4e_1;
    } else {
      tmp_0 = tmp3_elvis_lhs;
    }
    return tmp_0;
  };
  protoOf(TranslatableText).x44 = function () {
    return this.v44_1.c2().i();
  };
  function Companion_33() {
  }
  protoOf(Companion_33).c4e = function (key) {
    return new Translation(System_getInstance().fm(), Translations_getInstance().zm(key, []));
  };
  var Companion_instance_38;
  function Companion_getInstance_43() {
    return Companion_instance_38;
  }
  function Translation(language, text) {
    language = language === VOID ? Companion_getInstance_5().xu_1 : language;
    text = text === VOID ? '' : text;
    this.z4d_1 = language;
    this.a4e_1 = text;
    this.b4e_1 = false;
  }
  protoOf(Translation).o37 = function (_set____db54di) {
    this.b4e_1 = _set____db54di;
  };
  protoOf(Translation).p37 = function () {
    return this.b4e_1;
  };
  protoOf(Translation).n37 = function () {
    return false;
  };
  protoOf(Translation).r37 = function (writer) {
    writer.w38('lang', this.z4d_1.om_1);
    writer.w38('text', this.a4e_1);
  };
  protoOf(Translation).s37 = function (reader) {
    this.z4d_1 = Companion_getInstance_5().zu(reader.b38('lang'));
    this.a4e_1 = reader.b38('text');
  };
  protoOf(Translation).k37 = function (reference, referenceResolver) {
  };
  protoOf(Translation).equals = function (other) {
    if (this === other)
      return true;
    if (other == null)
      return false;
    if (!getKClassFromExpression(this).equals(getKClassFromExpression(other)))
      return false;
    if (!(other instanceof Translation))
      THROW_CCE();
    if (!this.z4d_1.equals(other.z4d_1))
      return false;
    if (!(this.a4e_1 === other.a4e_1))
      return false;
    return true;
  };
  protoOf(Translation).hashCode = function () {
    var result = this.z4d_1.hashCode();
    result = imul(31, result) + getStringHashCode(this.a4e_1) | 0;
    return result;
  };
  protoOf(Translation).toString = function () {
    return '[' + this.z4d_1.om_1 + "]='" + this.a4e_1 + "'";
  };
  function Companion_34() {
  }
  protoOf(Companion_34).d4e = function (externalName, reader, orElse) {
    if (reader.e35(externalName)) {
      return new Description(new TranslatableText(reader.x37(externalName)));
    }
    return orElse;
  };
  protoOf(Companion_34).f45 = function (externalName, reader, orElse, $super) {
    orElse = orElse === VOID ? Description_init_$Create$('') : orElse;
    return $super === VOID ? this.d4e(externalName, reader, orElse) : $super.d4e.call(this, externalName, reader, orElse);
  };
  var Companion_instance_39;
  function Companion_getInstance_44() {
    return Companion_instance_39;
  }
  function Description_init_$Init$(value, $this) {
    value = value === VOID ? '' : value;
    Description.call($this, TranslatableText_init_$Create$(value));
    return $this;
  }
  function Description_init_$Create$(value) {
    return Description_init_$Init$(value, objectCreate(protoOf(Description)));
  }
  function Description$toString$lambda(it) {
    return it.toString();
  }
  function Description(text) {
    text = text === VOID ? new TranslatableText() : text;
    this.e45_1 = text;
  }
  protoOf(Description).j2 = function () {
    return this.e45_1.x4d();
  };
  protoOf(Description).q40 = function (externalName, writer) {
    if (this.e45_1.g45()) {
      writer.r38(externalName, this.e45_1.x44());
    }
  };
  protoOf(Description).equals = function (other) {
    if (this === other)
      return true;
    if (other == null || !getKClassFromExpression(this).equals(getKClassFromExpression(other)))
      return false;
    if (!(other instanceof Description))
      THROW_CCE();
    if (!this.e45_1.equals(other.e45_1))
      return false;
    return true;
  };
  protoOf(Description).hashCode = function () {
    return this.e45_1.hashCode();
  };
  protoOf(Description).toString = function () {
    var tmp = asSequence(this.x44());
    return joinToString(tmp, VOID, VOID, VOID, VOID, VOID, Description$toString$lambda);
  };
  protoOf(Description).ov = function () {
    return this.e45_1.ov();
  };
  protoOf(Description).u4d = function (language) {
    return this.e45_1.u4d(language);
  };
  protoOf(Description).w4d = function (language, text) {
    return new Description(this.e45_1.w4d(language, text));
  };
  protoOf(Description).y4d = function (language) {
    return this.e45_1.y4d(language);
  };
  protoOf(Description).x44 = function () {
    return this.e45_1.x44();
  };
  function Describable() {
  }
  function observableDescription(initialValue, changeHandler) {
    initialValue = initialValue === VOID ? Description_init_$Create$('') : initialValue;
    var tmp;
    if (changeHandler === VOID) {
      tmp = observableDescription$lambda;
    } else {
      tmp = changeHandler;
    }
    changeHandler = tmp;
    return new observableDescription$3(initialValue, changeHandler);
  }
  function DescriptionChangedEvent(owner, description, oldValue) {
    this.e4e_1 = owner;
    this.f4e_1 = description;
    this.g4e_1 = oldValue;
  }
  protoOf(DescriptionChangedEvent).toString = function () {
    return 'DescriptionChangedEvent(owner=' + toString(this.e4e_1) + ', description=' + this.f4e_1.toString() + ', oldValue=' + this.g4e_1.toString() + ')';
  };
  protoOf(DescriptionChangedEvent).hashCode = function () {
    var result = hashCode(this.e4e_1);
    result = imul(result, 31) + this.f4e_1.hashCode() | 0;
    result = imul(result, 31) + this.g4e_1.hashCode() | 0;
    return result;
  };
  protoOf(DescriptionChangedEvent).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof DescriptionChangedEvent))
      return false;
    if (!equals(this.e4e_1, other.e4e_1))
      return false;
    if (!this.f4e_1.equals(other.f4e_1))
      return false;
    if (!this.g4e_1.equals(other.g4e_1))
      return false;
    return true;
  };
  function observableDescription$lambda(it) {
    return Unit_instance;
  }
  function observableDescription$3($initialValue, $changeHandler) {
    this.i4e_1 = $changeHandler;
    ObservableProperty.call(this, $initialValue);
  }
  protoOf(observableDescription$3).j4e = function (thisRef, property, value) {
    var oldValue = this.uf(thisRef, property);
    protoOf(ObservableProperty).wf.call(this, thisRef, property, value);
    var tmp;
    if (!(!(thisRef == null) ? isInterface(thisRef, Storable) : false)) {
      tmp = true;
    } else {
      tmp = !thisRef.p37();
    }
    if (tmp) {
      var tmp_0 = BaseModule_getInstance().zo_1;
      tmp_0.eu(new DescriptionChangedEvent((!(thisRef == null) ? isInterface(thisRef, Describable) : false) ? thisRef : THROW_CCE(), value, oldValue));
    }
    this.i4e_1(value);
  };
  protoOf(observableDescription$3).xf = function (thisRef, property, value) {
    return this.j4e(thisRef, property, value instanceof Description ? value : THROW_CCE());
  };
  protoOf(observableDescription$3).wf = function (thisRef, property, value) {
    return this.j4e(thisRef, property, value instanceof Description ? value : THROW_CCE());
  };
  function Namable() {
  }
  function Companion_35() {
  }
  protoOf(Companion_35).k4e = function (externalName, reader, orElse) {
    if (reader.e35(externalName)) {
      return new Name(new TranslatableText(reader.x37(externalName)));
    }
    return orElse;
  };
  protoOf(Companion_35).o40 = function (externalName, reader, orElse, $super) {
    orElse = orElse === VOID ? Name_init_$Create$('') : orElse;
    return $super === VOID ? this.k4e(externalName, reader, orElse) : $super.k4e.call(this, externalName, reader, orElse);
  };
  var Companion_instance_40;
  function Companion_getInstance_45() {
    return Companion_instance_40;
  }
  function Name_init_$Init$(value, $this) {
    value = value === VOID ? '' : value;
    Name.call($this, TranslatableText_init_$Create$(value));
    return $this;
  }
  function Name_init_$Create$(value) {
    return Name_init_$Init$(value, objectCreate(protoOf(Name)));
  }
  function Name(text) {
    text = text === VOID ? new TranslatableText() : text;
    this.p40_1 = text;
  }
  protoOf(Name).j2 = function () {
    return this.p40_1.u44();
  };
  protoOf(Name).q40 = function (externalName, writer) {
    if (!this.p40_1.ov()) {
      writer.r38(externalName, this.p40_1.x44());
    }
  };
  protoOf(Name).toString = function () {
    return this.j2();
  };
  protoOf(Name).equals = function (other) {
    if (this === other)
      return true;
    if (other == null || !getKClassFromExpression(this).equals(getKClassFromExpression(other)))
      return false;
    if (!(other instanceof Name))
      THROW_CCE();
    if (!this.p40_1.equals(other.p40_1))
      return false;
    return true;
  };
  protoOf(Name).hashCode = function () {
    return this.p40_1.hashCode();
  };
  protoOf(Name).ov = function () {
    return this.p40_1.ov();
  };
  protoOf(Name).u4d = function (language) {
    return this.p40_1.u4d(language);
  };
  protoOf(Name).w4d = function (language, text) {
    return new Name(this.p40_1.w4d(language, text));
  };
  protoOf(Name).y4d = function (language) {
    return this.p40_1.y4d(language);
  };
  protoOf(Name).x44 = function () {
    return this.p40_1.x44();
  };
  function observableName(initialValue, handler) {
    var tmp;
    if (handler === VOID) {
      tmp = observableName$lambda;
    } else {
      tmp = handler;
    }
    handler = tmp;
    return new observableName$3(initialValue, handler);
  }
  function NameChangedEvent(owner, name, oldValue) {
    this.l4e_1 = owner;
    this.m4e_1 = name;
    this.n4e_1 = oldValue;
  }
  protoOf(NameChangedEvent).toString = function () {
    return 'NameChangedEvent(owner=' + toString(this.l4e_1) + ', name=' + this.m4e_1.toString() + ', oldValue=' + this.n4e_1.toString() + ')';
  };
  protoOf(NameChangedEvent).hashCode = function () {
    var result = hashCode(this.l4e_1);
    result = imul(result, 31) + this.m4e_1.hashCode() | 0;
    result = imul(result, 31) + this.n4e_1.hashCode() | 0;
    return result;
  };
  protoOf(NameChangedEvent).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof NameChangedEvent))
      return false;
    if (!equals(this.l4e_1, other.l4e_1))
      return false;
    if (!this.m4e_1.equals(other.m4e_1))
      return false;
    if (!this.n4e_1.equals(other.n4e_1))
      return false;
    return true;
  };
  function observableName$lambda(it) {
    return Unit_instance;
  }
  function observableName$3($initialValue, $handler) {
    this.p4e_1 = $handler;
    ObservableProperty.call(this, $initialValue);
  }
  protoOf(observableName$3).q4e = function (thisRef, property, value) {
    var oldValue = this.uf(thisRef, property);
    protoOf(ObservableProperty).wf.call(this, thisRef, property, value);
    this.p4e_1(value);
    var tmp;
    if (!(!(thisRef == null) ? isInterface(thisRef, Storable) : false)) {
      tmp = true;
    } else {
      tmp = !thisRef.p37();
    }
    if (tmp) {
      var tmp_0 = BaseModule_getInstance().zo_1;
      tmp_0.eu(new NameChangedEvent((!(thisRef == null) ? isInterface(thisRef, Namable) : false) ? thisRef : THROW_CCE(), value, oldValue));
    }
  };
  protoOf(observableName$3).xf = function (thisRef, property, value) {
    return this.q4e(thisRef, property, value instanceof Name ? value : THROW_CCE());
  };
  protoOf(observableName$3).wf = function (thisRef, property, value) {
    return this.q4e(thisRef, property, value instanceof Name ? value : THROW_CCE());
  };
  function configureTypeMap($this, typeMap) {
    typeMap.t36('drawing', getKClass(DrawingImpl));
    typeMap.t36('rectangle', getKClass(RectangleComponent));
    typeMap.t36('ellipse', getKClass(EllipseComponent));
    typeMap.t36('roundrect', getKClass(RoundRectangleComponent));
    typeMap.t36('polyline', getKClass(PolylineComponent));
    typeMap.t36('label', getKClass(LabelComponent));
    typeMap.t36('text', getKClass(SimpleTextComponent));
    typeMap.t36('group', getKClass(GroupComponent));
    typeMap.t36('quadCurve', getKClass(QuadCurveComponent));
    typeMap.t36('cubicCurve', getKClass(CubicCurveComponent));
    typeMap.t36('translation', getKClass(Translation));
    typeMap.t36('image', getKClass(ImageComponent));
  }
  function fillProperties_0($this, properties) {
    properties.ct('edit.view.AttentionDrawer.color', Companion_getInstance_3().q1s_1);
    properties.ct('edit.view.AttentionDrawer.duration', 500.0);
    properties.ct('edit.view.AttentionDrawer.maxRadius', 30.0);
    properties.ct('edit.commandManager.cmdPerSnapshot', 10);
    properties.ct('ComponentPropertyPanelController.maxMultiSelectCount', 8);
  }
  function EditModule$drawingViewFactory$1() {
  }
  protoOf(EditModule$drawingViewFactory$1).r4e = function (drawing, contextHolder, displayGlobalMessages, name) {
    return new DrawingViewImpl(drawing, VOID, contextHolder, displayGlobalMessages, VOID, VOID, VOID, VOID, VOID, name);
  };
  function EditModule$drawingViewSearchFactory$lambda() {
    return new DrawingViewSearch();
  }
  function EditModule$attentionDrawerFactory$lambda(it) {
    return new AttentionDrawerImpl();
  }
  function EditModule$imageRepository$1() {
  }
  protoOf(EditModule$imageRepository$1).v3z = function (uuid) {
    return null;
  };
  function EditModule() {
    EditModule_instance = this;
    AbstractModule.call(this);
    this.d3f_1 = new SourcingCommandManager();
    var tmp = this;
    tmp.e3f_1 = new EditModule$drawingViewFactory$1();
    var tmp_0 = this;
    tmp_0.f3f_1 = EditModule$drawingViewSearchFactory$lambda;
    var tmp_1 = this;
    tmp_1.g3f_1 = EditModule$attentionDrawerFactory$lambda;
    this.h3f_1 = new CopyPasteService();
    this.i3f_1 = new DrawingServiceImpl();
    this.j3f_1 = new DrawingAppServiceImpl();
    var tmp_2 = this;
    tmp_2.k3f_1 = new EditModule$imageRepository$1();
  }
  protoOf(EditModule).ro = function () {
    DrawModule_getInstance().to();
    EditModelRectangleModule_getInstance().to();
    EditModelPolylineModule_getInstance().to();
    EditModelTextModule_getInstance().to();
    EditModelGroupModule_getInstance().to();
    EditModuleCurveModule_getInstance().to();
    EditSnapModule_getInstance().to();
    EditDragModule_getInstance().to();
    EditSelectModule_getInstance().to();
    EditEditorModule_getInstance().to();
    EditAuthModule_getInstance().to();
    Translations_getInstance().um('jabbah-edit');
    Themes_getInstance().e2t([new EditTheme()]);
    configureTypeMap(this, IOModule_getInstance().o35_1);
    fillProperties_0(this, BaseModule_getInstance().xo_1);
  };
  var EditModule_instance;
  function EditModule_getInstance() {
    if (EditModule_instance == null)
      new EditModule();
    return EditModule_instance;
  }
  function PropertyValueException(msg, event) {
    IllegalArgumentException_init_$Init$(msg, this);
    captureStack(this, PropertyValueException);
    this.s4e_1 = event;
  }
  var Magnitude_Pico_instance;
  var Magnitude_Nano_instance;
  var Magnitude_Micro_instance;
  var Magnitude_Milli_instance;
  var Magnitude_One_instance;
  var Magnitude_Kilo_instance;
  var Magnitude_Mega_instance;
  var Magnitude_Giga_instance;
  var Magnitude_Tera_instance;
  function Companion_36() {
  }
  protoOf(Companion_36).t4e = function (name) {
    var tmp0 = get_entries_0();
    var tmp$ret$0;
    $l$block: {
      // Inline function 'kotlin.collections.firstOrNull' call
      var _iterator__ex2g4s = tmp0.i();
      while (_iterator__ex2g4s.j()) {
        var element = _iterator__ex2g4s.k();
        if (element.w4e_1 === name) {
          tmp$ret$0 = element;
          break $l$block;
        }
      }
      tmp$ret$0 = null;
    }
    var tmp0_elvis_lhs = tmp$ret$0;
    var tmp;
    if (tmp0_elvis_lhs == null) {
      throw IllegalArgumentException_init_$Create$(Translations_getInstance().zm('edit.magnitude.unknown.text', [name]));
    } else {
      tmp = tmp0_elvis_lhs;
    }
    return tmp;
  };
  protoOf(Companion_36).b4f = function (name, reader) {
    var tmp;
    if (reader.d35(name)) {
      tmp = this.t4e(reader.b38(name));
    } else {
      tmp = Magnitude_One_getInstance();
    }
    return tmp;
  };
  var Companion_instance_41;
  function Companion_getInstance_46() {
    return Companion_instance_41;
  }
  function values_2() {
    return [Magnitude_Pico_getInstance(), Magnitude_Nano_getInstance(), Magnitude_Micro_getInstance(), Magnitude_Milli_getInstance(), Magnitude_One_getInstance(), Magnitude_Kilo_getInstance(), Magnitude_Mega_getInstance(), Magnitude_Giga_getInstance(), Magnitude_Tera_getInstance()];
  }
  function get_entries_0() {
    if ($ENTRIES_0 == null)
      $ENTRIES_0 = enumEntries(values_2());
    return $ENTRIES_0;
  }
  var Magnitude_entriesInitialized;
  function Magnitude_initEntries() {
    if (Magnitude_entriesInitialized)
      return Unit_instance;
    Magnitude_entriesInitialized = true;
    Magnitude_Pico_instance = new Magnitude('Pico', 0, 'p', 1000000000000n, true);
    Magnitude_Nano_instance = new Magnitude('Nano', 1, 'n', 1000000000n, true, VOID, 'n');
    Magnitude_Micro_instance = new Magnitude('Micro', 2, 'u', 1000000n, true, VOID, '\xB5');
    Magnitude_Milli_instance = new Magnitude('Milli', 3, 'm', 1000n, true, true);
    Magnitude_One_instance = new Magnitude('One', 4, '', 1n);
    Magnitude_Kilo_instance = new Magnitude('Kilo', 5, 'K', 1000n);
    Magnitude_Mega_instance = new Magnitude('Mega', 6, 'M', 1000000n, VOID, true);
    Magnitude_Giga_instance = new Magnitude('Giga', 7, 'G', 1000000000n);
    Magnitude_Tera_instance = new Magnitude('Tera', 8, 'T', 1000000000000n);
  }
  var $ENTRIES_0;
  function Magnitude(name, ordinal, customName, factor, inverse, caseSensitive, denotation) {
    inverse = inverse === VOID ? false : inverse;
    caseSensitive = caseSensitive === VOID ? false : caseSensitive;
    denotation = denotation === VOID ? customName : denotation;
    Enum.call(this, name, ordinal);
    this.w4e_1 = customName;
    this.x4e_1 = factor;
    this.y4e_1 = inverse;
    this.z4e_1 = caseSensitive;
    this.a4f_1 = denotation;
  }
  protoOf(Magnitude).q40 = function (name, writer) {
    if (!this.equals(Magnitude_One_getInstance())) {
      writer.w38(name, this.w4e_1);
    }
  };
  function Magnitude_Pico_getInstance() {
    Magnitude_initEntries();
    return Magnitude_Pico_instance;
  }
  function Magnitude_Nano_getInstance() {
    Magnitude_initEntries();
    return Magnitude_Nano_instance;
  }
  function Magnitude_Micro_getInstance() {
    Magnitude_initEntries();
    return Magnitude_Micro_instance;
  }
  function Magnitude_Milli_getInstance() {
    Magnitude_initEntries();
    return Magnitude_Milli_instance;
  }
  function Magnitude_One_getInstance() {
    Magnitude_initEntries();
    return Magnitude_One_instance;
  }
  function Magnitude_Kilo_getInstance() {
    Magnitude_initEntries();
    return Magnitude_Kilo_instance;
  }
  function Magnitude_Mega_getInstance() {
    Magnitude_initEntries();
    return Magnitude_Mega_instance;
  }
  function Magnitude_Giga_getInstance() {
    Magnitude_initEntries();
    return Magnitude_Giga_instance;
  }
  function Magnitude_Tera_getInstance() {
    Magnitude_initEntries();
    return Magnitude_Tera_instance;
  }
  function Companion_37() {
    this.c4f_1 = 'Value';
    this.d4f_1 = 'Magnitude';
    this.e4f_1 = 'Unit';
    this.f4f_1 = 3;
  }
  protoOf(Companion_37).g4f = function (name, reader) {
    return new MagnitudeValue(reader.a38(name + 'Value'), Companion_instance_41.b4f(name + 'Magnitude', reader), Companion_instance_43.t4e(reader.b38(name + 'Unit')));
  };
  protoOf(Companion_37).h4f = function (name, reader, unit) {
    return new MagnitudeValue(reader.a38(name + 'Value'), Companion_instance_41.b4f(name + 'Magnitude', reader), unit);
  };
  var Companion_instance_42;
  function Companion_getInstance_47() {
    return Companion_instance_42;
  }
  function MagnitudeValue_init_$Init$(value, magnitude, unit, $this) {
    MagnitudeValue.call($this, toNumber(value), magnitude, unit);
    return $this;
  }
  function MagnitudeValue_init_$Create$(value, magnitude, unit) {
    return MagnitudeValue_init_$Init$(value, magnitude, unit, objectCreate(protoOf(MagnitudeValue)));
  }
  function ensureMinimumMagnitude($this, value, magnitude, unit) {
    var tmp;
    if (magnitude.l2_1 >= unit.m4f_1.l2_1) {
      tmp = new MagnitudeValue(value, magnitude, unit);
    } else {
      throw IllegalArgumentException_init_$Create$_0();
    }
    return tmp;
  }
  function truncate($this, value, snap) {
    if (value === 0.0) {
      return 0.0;
    }
    // Inline function 'kotlin.math.log10' call
    var x = value < 0 ? -value : value;
    // Inline function 'kotlin.math.ceil' call
    var x_0 = log10(x);
    var d = Math.ceil(x_0);
    // Inline function 'kotlin.math.pow' call
    var n = 3 - numberToInt(d) | 0;
    var factor = Math.pow(10.0, n);
    // Inline function 'kotlin.math.floor' call
    var x_1 = value * factor;
    var tmp$ret$3 = Math.floor(x_1);
    var shifted = numberToLong(tmp$ret$3);
    // Inline function 'kotlin.Long.div' call
    var truncated = toNumber(shifted) / factor;
    var tmp;
    if (snap) {
      var tmp_0;
      if (truncated < 10) {
        var tmp_1;
        if (truncated >= 9) {
          // Inline function 'kotlin.math.floor' call
          tmp_1 = Math.floor(value);
        } else {
          tmp_1 = round(value);
        }
        tmp_0 = tmp_1;
      } else if (truncated < 100) {
        var tmp_2;
        if (truncated >= 90) {
          // Inline function 'kotlin.math.floor' call
          var x_2 = truncated / 10;
          tmp_2 = Math.floor(x_2) * 10;
        } else {
          tmp_2 = round(truncated / 10) * 10;
        }
        tmp_0 = tmp_2;
      } else if (truncated < 1000) {
        var tmp_3;
        if (truncated >= 900) {
          // Inline function 'kotlin.math.floor' call
          var x_3 = truncated / 100;
          tmp_3 = Math.floor(x_3) * 100;
        } else {
          tmp_3 = round(truncated / 100) * 100;
        }
        tmp_0 = tmp_3;
      } else {
        tmp_0 = truncated;
      }
      tmp = tmp_0;
    } else {
      tmp = truncated;
    }
    return tmp;
  }
  function MagnitudeValue$baseValue$delegate$lambda(this$0) {
    return function () {
      var tmp;
      if (this$0.p4f_1.y4e_1) {
        tmp = this$0.o4f_1 / toNumber(this$0.p4f_1.x4e_1);
      } else {
        var tmp0 = this$0.p4f_1.x4e_1;
        // Inline function 'kotlin.Long.times' call
        var other = this$0.o4f_1;
        tmp = toNumber(tmp0) * other;
      }
      return tmp;
    };
  }
  function MagnitudeValue$_get_baseValue_$ref_nn3yzh() {
    return function (p0) {
      return p0.t4f();
    };
  }
  function MagnitudeValue$northBaseValue$delegate$lambda(this$0) {
    return function () {
      var tmp;
      if (this$0.p4f_1.y4e_1) {
        var tmp_0;
        if (this$0.t4f() < 10.0 / toNumber(this$0.p4f_1.x4e_1)) {
          tmp_0 = 1.0 / toNumber(this$0.p4f_1.x4e_1);
        } else if (this$0.t4f() < 100.0 / toNumber(this$0.p4f_1.x4e_1)) {
          tmp_0 = 10.0 / toNumber(this$0.p4f_1.x4e_1);
        } else {
          tmp_0 = 100.0 / toNumber(this$0.p4f_1.x4e_1);
        }
        tmp = tmp_0;
      } else {
        var tmp_1;
        if (this$0.t4f() < toNumber(multiply(numberToLong(10), this$0.p4f_1.x4e_1))) {
          tmp_1 = toNumber(this$0.p4f_1.x4e_1);
        } else if (this$0.t4f() < toNumber(multiply(numberToLong(100), this$0.p4f_1.x4e_1))) {
          tmp_1 = 10.0 * toNumber(this$0.p4f_1.x4e_1);
        } else {
          tmp_1 = 100.0 * toNumber(this$0.p4f_1.x4e_1);
        }
        tmp = tmp_1;
      }
      return tmp;
    };
  }
  function MagnitudeValue$_get_northBaseValue_$ref_tas6ua() {
    return function (p0) {
      return p0.u4f();
    };
  }
  function MagnitudeValue(value, magnitude, unit) {
    this.o4f_1 = value;
    this.p4f_1 = magnitude;
    this.q4f_1 = unit;
    if (this.p4f_1.l2_1 < this.q4f_1.m4f_1.l2_1) {
      throw IllegalArgumentException_init_$Create$(Translations_getInstance().zm('edit.magnitude.tooSmall.text', [this.p4f_1.w4e_1, this.q4f_1.k4f_1]));
    }
    var tmp = this;
    tmp.r4f_1 = lazy(MagnitudeValue$baseValue$delegate$lambda(this));
    var tmp_0 = this;
    tmp_0.s4f_1 = lazy(MagnitudeValue$northBaseValue$delegate$lambda(this));
  }
  protoOf(MagnitudeValue).v4f = function (value, snap) {
    return (new MagnitudeValue(value, Magnitude_One_getInstance(), this.q4f_1)).w4f(snap);
  };
  protoOf(MagnitudeValue).x4f = function (name, writer, writeUnit) {
    writer.u38(name + 'Value', this.o4f_1);
    this.p4f_1.q40(name + 'Magnitude', writer);
    if (writeUnit) {
      writer.w38(name + 'Unit', this.q4f_1.k4f_1);
    }
  };
  protoOf(MagnitudeValue).y4f = function (name, writer, writeUnit, $super) {
    writeUnit = writeUnit === VOID ? false : writeUnit;
    var tmp;
    if ($super === VOID) {
      this.x4f(name, writer, writeUnit);
      tmp = Unit_instance;
    } else {
      tmp = $super.x4f.call(this, name, writer, writeUnit);
    }
    return tmp;
  };
  protoOf(MagnitudeValue).toString = function () {
    var tmp;
    // Inline function 'kotlin.math.floor' call
    var x = this.o4f_1;
    if (Math.floor(x) === this.o4f_1) {
      tmp = numberToLong(this.o4f_1).toString() + ' ' + this.p4f_1.a4f_1 + this.q4f_1.l4f_1;
    } else {
      tmp = '' + this.o4f_1 + ' ' + this.p4f_1.a4f_1 + this.q4f_1.l4f_1;
    }
    return tmp;
  };
  protoOf(MagnitudeValue).t4f = function () {
    var tmp0 = this.r4f_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('baseValue', 1, tmp, MagnitudeValue$_get_baseValue_$ref_nn3yzh(), null);
    return tmp0.j2();
  };
  protoOf(MagnitudeValue).u4f = function () {
    var tmp0 = this.s4f_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('northBaseValue', 1, tmp, MagnitudeValue$_get_northBaseValue_$ref_tas6ua(), null);
    return tmp0.j2();
  };
  protoOf(MagnitudeValue).z4f = function (magnitude) {
    var tmp;
    if (magnitude.y4e_1) {
      tmp = this.t4f() * toNumber(magnitude.x4e_1);
    } else {
      tmp = this.t4f() / toNumber(magnitude.x4e_1);
    }
    return tmp;
  };
  protoOf(MagnitudeValue).w4f = function (snap) {
    if (this.t4f() >= 1) {
      return this.t4f() < toNumber(Magnitude_Kilo_getInstance().x4e_1) ? ensureMinimumMagnitude(this, truncate(this, this.t4f(), snap), Magnitude_One_getInstance(), this.q4f_1) : this.t4f() < toNumber(Magnitude_Mega_getInstance().x4e_1) ? ensureMinimumMagnitude(this, truncate(this, this.t4f() / toNumber(Magnitude_Kilo_getInstance().x4e_1), snap), Magnitude_Kilo_getInstance(), this.q4f_1) : this.t4f() < toNumber(Magnitude_Giga_getInstance().x4e_1) ? ensureMinimumMagnitude(this, truncate(this, this.t4f() / toNumber(Magnitude_Mega_getInstance().x4e_1), snap), Magnitude_Mega_getInstance(), this.q4f_1) : new MagnitudeValue(truncate(this, this.t4f() / toNumber(Magnitude_Giga_getInstance().x4e_1), snap), Magnitude_Giga_getInstance(), this.q4f_1);
    } else {
      return this.t4f() >= 1.0 / toNumber(Magnitude_Kilo_getInstance().x4e_1) ? ensureMinimumMagnitude(this, truncate(this, this.t4f() * toNumber(Magnitude_Kilo_getInstance().x4e_1), snap), Magnitude_Milli_getInstance(), this.q4f_1) : this.t4f() >= 1.0 / toNumber(Magnitude_Mega_getInstance().x4e_1) ? ensureMinimumMagnitude(this, truncate(this, this.t4f() * toNumber(Magnitude_Mega_getInstance().x4e_1), snap), Magnitude_Micro_getInstance(), this.q4f_1) : this.t4f() >= 1.0 / toNumber(Magnitude_Giga_getInstance().x4e_1) ? ensureMinimumMagnitude(this, truncate(this, this.t4f() * toNumber(Magnitude_Giga_getInstance().x4e_1), snap), Magnitude_Nano_getInstance(), this.q4f_1) : this.t4f() >= 1.0 / toNumber(Magnitude_Tera_getInstance().x4e_1) ? ensureMinimumMagnitude(this, truncate(this, this.t4f() * toNumber(Magnitude_Tera_getInstance().x4e_1), snap), Magnitude_Pico_getInstance(), this.q4f_1) : this;
    }
  };
  protoOf(MagnitudeValue).a4g = function (snap, $super) {
    snap = snap === VOID ? false : snap;
    return $super === VOID ? this.w4f(snap) : $super.w4f.call(this, snap);
  };
  protoOf(MagnitudeValue).b4g = function (value, magnitude, unit) {
    return new MagnitudeValue(value, magnitude, unit);
  };
  protoOf(MagnitudeValue).c4g = function (value, magnitude, unit, $super) {
    value = value === VOID ? this.o4f_1 : value;
    magnitude = magnitude === VOID ? this.p4f_1 : magnitude;
    unit = unit === VOID ? this.q4f_1 : unit;
    return $super === VOID ? this.b4g(value, magnitude, unit) : $super.b4g.call(this, value, magnitude, unit);
  };
  protoOf(MagnitudeValue).hashCode = function () {
    var result = getNumberHashCode(this.o4f_1);
    result = imul(result, 31) + this.p4f_1.hashCode() | 0;
    result = imul(result, 31) + this.q4f_1.hashCode() | 0;
    return result;
  };
  protoOf(MagnitudeValue).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof MagnitudeValue))
      return false;
    if (!equals(this.o4f_1, other.o4f_1))
      return false;
    if (!this.p4f_1.equals(other.p4f_1))
      return false;
    if (!this.q4f_1.equals(other.q4f_1))
      return false;
    return true;
  };
  var SIUnit_Factor_instance;
  var SIUnit_Ohm_instance;
  var SIUnit_Farad_instance;
  var SIUnit_Henry_instance;
  var SIUnit_Volt_instance;
  var SIUnit_Ampere_instance;
  var SIUnit_Second_instance;
  var SIUnit_Hertz_instance;
  function Companion_38() {
  }
  protoOf(Companion_38).t4e = function (name) {
    var tmp0 = get_entries_1();
    var tmp$ret$0;
    $l$block: {
      // Inline function 'kotlin.collections.firstOrNull' call
      var _iterator__ex2g4s = tmp0.i();
      while (_iterator__ex2g4s.j()) {
        var element = _iterator__ex2g4s.k();
        if (element.k4f_1 === name) {
          tmp$ret$0 = element;
          break $l$block;
        }
      }
      tmp$ret$0 = null;
    }
    var tmp0_elvis_lhs = tmp$ret$0;
    var tmp;
    if (tmp0_elvis_lhs == null) {
      throw IllegalArgumentException_init_$Create$(Translations_getInstance().zm('edit.magnitude.invalidUnit.text', [name]));
    } else {
      tmp = tmp0_elvis_lhs;
    }
    return tmp;
  };
  var Companion_instance_43;
  function Companion_getInstance_48() {
    return Companion_instance_43;
  }
  function values_3() {
    return [SIUnit_Factor_getInstance(), SIUnit_Ohm_getInstance(), SIUnit_Farad_getInstance(), SIUnit_Henry_getInstance(), SIUnit_Volt_getInstance(), SIUnit_Ampere_getInstance(), SIUnit_Second_getInstance(), SIUnit_Hertz_getInstance()];
  }
  function get_entries_1() {
    if ($ENTRIES_1 == null)
      $ENTRIES_1 = enumEntries(values_3());
    return $ENTRIES_1;
  }
  var SIUnit_entriesInitialized;
  function SIUnit_initEntries() {
    if (SIUnit_entriesInitialized)
      return Unit_instance;
    SIUnit_entriesInitialized = true;
    SIUnit_Factor_instance = new SIUnit('Factor', 0, 'Factor', 'x', Magnitude_One_getInstance(), Magnitude_One_getInstance());
    SIUnit_Ohm_instance = new SIUnit('Ohm', 1, 'Ohm', '\u03A9', Magnitude_One_getInstance(), Magnitude_One_getInstance());
    SIUnit_Farad_instance = new SIUnit('Farad', 2, 'Farad', 'F', Magnitude_Pico_getInstance(), Magnitude_Micro_getInstance());
    SIUnit_Henry_instance = new SIUnit('Henry', 3, 'Henry', 'H', Magnitude_Nano_getInstance(), Magnitude_One_getInstance());
    SIUnit_Volt_instance = new SIUnit('Volt', 4, 'Volt', 'V', Magnitude_Micro_getInstance(), Magnitude_One_getInstance());
    SIUnit_Ampere_instance = new SIUnit('Ampere', 5, 'Amp\xE8re', 'A', Magnitude_Micro_getInstance(), Magnitude_Milli_getInstance());
    SIUnit_Second_instance = new SIUnit('Second', 6, 'Second', 's', Magnitude_Nano_getInstance(), Magnitude_Nano_getInstance());
    SIUnit_Hertz_instance = new SIUnit('Hertz', 7, 'Hertz', 'Hz', Magnitude_One_getInstance(), Magnitude_One_getInstance());
  }
  var $ENTRIES_1;
  function SIUnit(name, ordinal, customName, symbol, minimumMagnitude, defaultMagnitude) {
    Enum.call(this, name, ordinal);
    this.k4f_1 = customName;
    this.l4f_1 = symbol;
    this.m4f_1 = minimumMagnitude;
    this.n4f_1 = defaultMagnitude;
  }
  function SIUnit_Factor_getInstance() {
    SIUnit_initEntries();
    return SIUnit_Factor_instance;
  }
  function SIUnit_Ohm_getInstance() {
    SIUnit_initEntries();
    return SIUnit_Ohm_instance;
  }
  function SIUnit_Farad_getInstance() {
    SIUnit_initEntries();
    return SIUnit_Farad_instance;
  }
  function SIUnit_Henry_getInstance() {
    SIUnit_initEntries();
    return SIUnit_Henry_instance;
  }
  function SIUnit_Volt_getInstance() {
    SIUnit_initEntries();
    return SIUnit_Volt_instance;
  }
  function SIUnit_Ampere_getInstance() {
    SIUnit_initEntries();
    return SIUnit_Ampere_instance;
  }
  function SIUnit_Second_getInstance() {
    SIUnit_initEntries();
    return SIUnit_Second_instance;
  }
  function SIUnit_Hertz_getInstance() {
    SIUnit_initEntries();
    return SIUnit_Hertz_instance;
  }
  function Companion_39() {
    this.d4g_1 = 5;
    this.e4g_1 = 15;
  }
  var Companion_instance_44;
  function Companion_getInstance_49() {
    return Companion_instance_44;
  }
  function AbstractBelowSelectionModel(component, styleProvider, styleType, outset) {
    styleProvider = styleProvider === VOID ? DrawStyleModule_getInstance().g1x_1 : styleProvider;
    styleType = styleType === VOID ? Companion_getInstance_60().n3n_1 : styleType;
    outset = outset === VOID ? 5 : outset;
    AbstractSelectionModel.call(this, component);
    this.k4g_1 = outset;
    this.l4g_1 = styleProvider.p1x(styleType).m1t();
  }
  protoOf(AbstractBelowSelectionModel).v2d = function (value) {
    this.l4g_1 = value;
    this.s1z();
  };
  protoOf(AbstractBelowSelectionModel).m1t = function () {
    return this.l4g_1;
  };
  function EventHandler($outer) {
    this.u3r_1 = $outer;
    InputEventHandlerAdapter.call(this);
    this.t3r_1 = null;
  }
  protoOf(EventHandler).r3r = function (view) {
  };
  protoOf(EventHandler).c3s = function (context) {
  };
  protoOf(EventHandler).d3s = function (context) {
    return !(this.t3r_1 == null) ? this : null;
  };
  protoOf(EventHandler).n22 = function (context) {
    return this.d3s(context instanceof EditInputEventContext ? context : THROW_CCE());
  };
  protoOf(EventHandler).e3s = function (context) {
    return !(this.t3r_1 == null) ? this : null;
  };
  protoOf(EventHandler).o22 = function (context) {
    return this.e3s(context instanceof EditInputEventContext ? context : THROW_CCE());
  };
  protoOf(EventHandler).f3s = function (context) {
    var tmp0_elvis_lhs = this.u3r_1.t3s(context.a22_1, context.b22_1);
    var tmp;
    if (tmp0_elvis_lhs == null) {
      return null;
    } else {
      tmp = tmp0_elvis_lhs;
    }
    var handle = tmp;
    handle.o1z(context).j22(context);
    return this;
  };
  protoOf(EventHandler).j22 = function (context) {
    return this.f3s(context instanceof EditInputEventContext ? context : THROW_CCE());
  };
  protoOf(EventHandler).g3s = function (context) {
    var handle = this.u3r_1.t3s(context.a22_1, context.b22_1);
    if (handle == null) {
      this.t3r_1 = null;
      return null;
    }
    this.t3r_1 = handle;
    this.r3r(context.x21_1);
    return this;
  };
  protoOf(EventHandler).k22 = function (context) {
    return this.g3s(context instanceof EditInputEventContext ? context : THROW_CCE());
  };
  protoOf(EventHandler).h3s = function (context) {
    if (this.t3r_1 == null) {
      return null;
    }
    var snap = Companion_getInstance().g1a_1;
    var tmp0_safe_receiver = context.y21_1;
    if (!((tmp0_safe_receiver == null ? null : tmp0_safe_receiver.isAltDown) === true)) {
      snap = context.e3c_1.j3c().d43(context.a22_1, context.b22_1);
    }
    var tmp1_safe_receiver = this.t3r_1;
    var tmp2_safe_receiver = tmp1_safe_receiver == null ? null : tmp1_safe_receiver.o1z(context);
    if (tmp2_safe_receiver == null)
      null;
    else
      tmp2_safe_receiver.l22(context.f22(context.a22_1 + snap.in_1, context.b22_1 + snap.jn_1));
    return this;
  };
  protoOf(EventHandler).l22 = function (context) {
    return this.h3s(context instanceof EditInputEventContext ? context : THROW_CCE());
  };
  protoOf(EventHandler).i3s = function (context) {
    if (this.t3r_1 == null) {
      return null;
    }
    this.c3s(context);
    var tmp0_safe_receiver = this.t3r_1;
    var tmp1_safe_receiver = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.o1z(context);
    if (tmp1_safe_receiver == null)
      null;
    else
      tmp1_safe_receiver.m22(context);
    return this;
  };
  protoOf(EventHandler).m22 = function (context) {
    return this.i3s(context instanceof EditInputEventContext ? context : THROW_CCE());
  };
  function AbstractHandleSelectionModel$inputEventHandler$delegate$lambda(this$0) {
    return function () {
      return this$0.m3s();
    };
  }
  function AbstractHandleSelectionModel$_get_inputEventHandler_$ref_59ceo9() {
    return function (p0) {
      return p0.l3s();
    };
  }
  function AbstractHandleSelectionModel(component) {
    AbstractSelectionModel.call(this, component);
    var tmp = this;
    // Inline function 'kotlin.collections.mutableListOf' call
    tmp.t3q_1 = ArrayList_init_$Create$_0();
    var tmp_0 = this;
    tmp_0.u3q_1 = lazy(AbstractHandleSelectionModel$inputEventHandler$delegate$lambda(this));
    this.v3q_1 = 0;
    this.w3q_1 = null;
    this.x3q_1 = new Rectangle2D();
  }
  protoOf(AbstractHandleSelectionModel).l3s = function () {
    var tmp0 = this.u3q_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('inputEventHandler', 1, tmp, AbstractHandleSelectionModel$_get_inputEventHandler_$ref_59ceo9(), null);
    return tmp0.j2();
  };
  protoOf(AbstractHandleSelectionModel).y2a = function (value) {
    this.s1z();
    this.w3q_1 = value;
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = this.t3q_1.i();
    while (_iterator__ex2g4s.j()) {
      var element = _iterator__ex2g4s.k();
      element.y2a(this.w3q_1);
    }
    this.u3s();
  };
  protoOf(AbstractHandleSelectionModel).r23 = function () {
    return this.w3q_1;
  };
  protoOf(AbstractHandleSelectionModel).do = function () {
    return this.x3q_1;
  };
  protoOf(AbstractHandleSelectionModel).p3s = function (context) {
    var tmp = this.l3s();
    return isInterface(tmp, InputEventHandler) ? tmp : THROW_CCE();
  };
  protoOf(AbstractHandleSelectionModel).o1z = function (context) {
    return this.p3s(context instanceof InputEventContext ? context : THROW_CCE());
  };
  protoOf(AbstractHandleSelectionModel).r1z = function (context) {
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = this.t3q_1.i();
    while (_iterator__ex2g4s.j()) {
      var element = _iterator__ex2g4s.k();
      element.r1z(context);
    }
  };
  protoOf(AbstractHandleSelectionModel).eo = function (x, y) {
    return this.x3q_1.eo(x, y);
  };
  protoOf(AbstractHandleSelectionModel).q3s = function (view) {
    this.r3s();
    this.v3q_1 = this.z3q();
  };
  protoOf(AbstractHandleSelectionModel).r3s = function () {
    this.u3s();
  };
  protoOf(AbstractHandleSelectionModel).l3r = function (handle) {
    return this.s3s(this.t3q_1.o(), handle);
  };
  protoOf(AbstractHandleSelectionModel).s3s = function (index, handle) {
    this.t3q_1.t3(index, handle);
    if (!(this.r23() == null)) {
      handle.y2a(this.r23());
    }
    return handle;
  };
  protoOf(AbstractHandleSelectionModel).o3s = function (index) {
    return this.t3q_1.l(index);
  };
  protoOf(AbstractHandleSelectionModel).v3r = function (handle) {
    return this.t3q_1.p(handle);
  };
  protoOf(AbstractHandleSelectionModel).t3s = function (x, y) {
    var tmp0 = this.t3q_1;
    var tmp$ret$0;
    $l$block: {
      // Inline function 'kotlin.collections.firstOrNull' call
      var _iterator__ex2g4s = tmp0.i();
      while (_iterator__ex2g4s.j()) {
        var element = _iterator__ex2g4s.k();
        if (element.eo(x, y)) {
          tmp$ret$0 = element;
          break $l$block;
        }
      }
      tmp$ret$0 = null;
    }
    return tmp$ret$0;
  };
  protoOf(AbstractHandleSelectionModel).y3q = function () {
    this.t3q_1.a2();
  };
  protoOf(AbstractHandleSelectionModel).i29 = function () {
    if (this.t3q_1.m()) {
      this.x3q_1.s1b(0.0, 0.0, 0.0, 0.0);
      return Unit_instance;
    }
    this.x3q_1.w1b(this.t3q_1.l(0).do());
    var inductionVariable = 1;
    var last = this.t3q_1.o();
    if (inductionVariable < last)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        this.x3q_1.x1b(this.t3q_1.l(i).do());
      }
       while (inductionVariable < last);
  };
  protoOf(AbstractHandleSelectionModel).u3s = function () {
    this.s1z();
    this.n3s();
    this.i29();
    this.s1z();
    this.u1z();
  };
  function displayHandles($this, view) {
    if (view.b3b() && !$this.o3u_1) {
      view.i3b().l20($this.n3u_1);
      $this.o3u_1 = true;
    }
  }
  function hideHandles($this, view) {
    if ($this.o3u_1) {
      view.i3b().m20($this.n3u_1);
      view.i3b().u1z();
      $this.o3u_1 = false;
    }
  }
  function EventHandler_0($outer) {
    this.n4g_1 = $outer;
    InputEventHandlerAdapter.call(this);
  }
  protoOf(EventHandler_0).d3s = function (context) {
    return this.n4g_1.n3u_1.p3s(context).n22(context);
  };
  protoOf(EventHandler_0).n22 = function (context) {
    return this.d3s(context instanceof EditInputEventContext ? context : THROW_CCE());
  };
  protoOf(EventHandler_0).e3s = function (context) {
    return this.n4g_1.n3u_1.p3s(context).o22(context);
  };
  protoOf(EventHandler_0).o22 = function (context) {
    return this.e3s(context instanceof EditInputEventContext ? context : THROW_CCE());
  };
  protoOf(EventHandler_0).f3s = function (context) {
    if (this.n4g_1.o3u_1 && this.n4g_1.n3u_1.eo(context.a22_1, context.b22_1)) {
      var handler = this.n4g_1.n3u_1.p3s(context).j22(context);
      if (handler == null) {
        context.x21_1.v1x(Cursor_MOVE_getInstance());
      }
      return this;
    }
    if (this.n4g_1.b3s().eo(context.a22_1, context.b22_1)) {
      displayHandles(this.n4g_1, context.n3b());
      context.x21_1.v1x(Cursor_MOVE_getInstance());
      return this;
    }
    hideHandles(this.n4g_1, context.n3b());
    return null;
  };
  protoOf(EventHandler_0).j22 = function (context) {
    return this.f3s(context instanceof EditInputEventContext ? context : THROW_CCE());
  };
  protoOf(EventHandler_0).g3s = function (context) {
    var mousePressed = this.n4g_1.n3u_1.p3s(context).k22(context);
    return !(mousePressed == null) ? this : null;
  };
  protoOf(EventHandler_0).k22 = function (context) {
    return this.g3s(context instanceof EditInputEventContext ? context : THROW_CCE());
  };
  protoOf(EventHandler_0).h3s = function (context) {
    this.n4g_1.n3u_1.p3s(context).l22(context);
    return this;
  };
  protoOf(EventHandler_0).l22 = function (context) {
    return this.h3s(context instanceof EditInputEventContext ? context : THROW_CCE());
  };
  protoOf(EventHandler_0).i3s = function (context) {
    this.n4g_1.n3u_1.p3s(context).m22(context);
    return this;
  };
  protoOf(EventHandler_0).m22 = function (context) {
    return this.i3s(context instanceof EditInputEventContext ? context : THROW_CCE());
  };
  function AbstractSelectedColorWrappingSelectionModel(component) {
    SelectedColorSelectionModel.call(this, component);
    this.n3u_1 = this.h3u(component);
    this.o3u_1 = false;
    this.p3u_1 = new EventHandler_0(this);
  }
  protoOf(AbstractSelectedColorWrappingSelectionModel).o1z = function (context) {
    var tmp = this.p3u_1;
    return isInterface(tmp, InputEventHandler) ? tmp : THROW_CCE();
  };
  protoOf(AbstractSelectedColorWrappingSelectionModel).r3s = function () {
    this.n3u_1.r3s();
    this.s1z();
    this.u1z();
  };
  protoOf(AbstractSelectedColorWrappingSelectionModel).q3s = function (view) {
    if (this.no(view.n24(view.c23().r1x()))) {
      displayHandles(this, view);
    }
  };
  protoOf(AbstractSelectedColorWrappingSelectionModel).w3s = function (view) {
    view.i3b().m20(this.n3u_1);
  };
  function AbstractSelectionModel$geometryUpdateListener$1(this$0) {
    this.o4g_1 = this$0;
    DrawableAdapter.call(this);
  }
  protoOf(AbstractSelectionModel$geometryUpdateListener$1).o21 = function (event) {
    this.o4g_1.r3s();
  };
  function AbstractSelectionModel(component) {
    AbstractDrawable.call(this);
    this.z3r_1 = component;
    var tmp = this;
    tmp.a3s_1 = new AbstractSelectionModel$geometryUpdateListener$1(this);
  }
  protoOf(AbstractSelectionModel).b3s = function () {
    return this.z3r_1;
  };
  protoOf(AbstractSelectionModel).v3s = function () {
    this.b3s().p1z(this.a3s_1);
    this.r3s();
  };
  protoOf(AbstractSelectionModel).es = function () {
    this.b3s().q1z(this.a3s_1);
  };
  protoOf(AbstractSelectionModel).q3s = function (view) {
  };
  protoOf(AbstractSelectionModel).w3s = function (view) {
  };
  function BoundingBoxBelowSelectionModel(component, styleProvider, styleType, outset) {
    styleProvider = styleProvider === VOID ? DrawStyleModule_getInstance().g1x_1 : styleProvider;
    styleType = styleType === VOID ? Companion_getInstance_60().n3n_1 : styleType;
    outset = outset === VOID ? 5 : outset;
    AbstractBelowSelectionModel.call(this, component, styleProvider, styleType, outset);
    this.w4g_1 = new Rectangle2D();
  }
  protoOf(BoundingBoxBelowSelectionModel).do = function () {
    return this.w4g_1;
  };
  protoOf(BoundingBoxBelowSelectionModel).eo = function (x, y) {
    return this.w4g_1.eo(x, y);
  };
  protoOf(BoundingBoxBelowSelectionModel).r1z = function (context) {
    var oldColor = context.t1y_1.m1t();
    context.t1y_1.l1t(this.m1t().h1x_1);
    context.t1y_1.k1u(numberToInt(this.w4g_1.e1h_1), numberToInt(this.w4g_1.f1h_1), numberToInt(this.w4g_1.g1h_1), numberToInt(this.w4g_1.h1h_1), 15, 15);
    context.t1y_1.l1t(oldColor);
  };
  protoOf(BoundingBoxBelowSelectionModel).r3s = function () {
    this.s1z();
    var bbox = this.b3s().do();
    this.w4g_1 = new Rectangle2D(bbox.z19() - this.k4g_1, bbox.a1a() - this.k4g_1, bbox.p1b() + imul(2, this.k4g_1), bbox.r1b() + imul(2, this.k4g_1));
    this.s1z();
    this.u1z();
  };
  function createRubberBand($this) {
    return new RectangularRubberBand();
  }
  function createRubberBandHandler($this) {
    return new RubberBandHandler(createRubberBand($this));
  }
  function fillProperties_1($this, properties) {
    properties.ct('edit.select.rubberband.stroke.paint', Companion_getInstance_3().n1s_1);
    properties.ct('edit.select.rubberband.fill.paint', new Color(255, 200, 0, 32));
    var tmp = LineCap_SQUARE_getInstance();
    var tmp_0 = LineJoin_MITER_getInstance();
    // Inline function 'kotlin.floatArrayOf' call
    var tmp$ret$0 = new Float32Array([5.0, 5.0]);
    properties.ct('edit.select.rubberband.stroke', new Stroke(0.1, tmp, tmp_0, 10.0, tmp$ret$0, 0.0));
    properties.ct('edit.select.rubberBandHandler.selectionTargetStrategy', SelectionTargetStrategy_CONTAINS_getInstance().e2p());
    properties.ct('edit.select.rubberBandHandler.selectDelayMs', 200);
    properties.ct('select.handle.size_half', 4);
    properties.ct('select.handle.color.border', Companion_getInstance_3().n1s_1);
    properties.ct('select.handle.color.content', Companion_getInstance_3().o1s_1);
    properties.ct('select.handle.stroke', new Stroke(1.0));
  }
  function EditSelectModule$selectionManagerFactory$lambda(content) {
    return new SelectionManagerImpl(content);
  }
  function EditSelectModule$selectionToolFactory$lambda(editor) {
    return new SelectionToolImpl(editor, createRubberBandHandler(EditSelectModule_getInstance()), BaseModule_getInstance().zo_1);
  }
  function EditSelectModule() {
    EditSelectModule_instance = this;
    AbstractModule.call(this);
    this.b3l_1 = new SelectionModelFactoryImpl();
    this.c3l_1 = new SimpleSelectionModelProvider(this.b3l_1);
    var tmp = this;
    tmp.d3l_1 = EditSelectModule$selectionManagerFactory$lambda;
    var tmp_0 = this;
    tmp_0.e3l_1 = EditSelectModule$selectionToolFactory$lambda;
  }
  protoOf(EditSelectModule).ro = function () {
    fillProperties_1(this, BaseModule_getInstance().xo_1);
  };
  var EditSelectModule_instance;
  function EditSelectModule_getInstance() {
    if (EditSelectModule_instance == null)
      new EditSelectModule();
    return EditSelectModule_instance;
  }
  function Handle() {
  }
  function MoveCommand(editor, componentIds, offset, children) {
    children = children === VOID ? emptyList() : children;
    AbstractCommand.call(this, 'edit.command.move', editor);
    this.e4h_1 = componentIds;
    this.f4h_1 = offset;
    this.g4h_1 = children;
  }
  protoOf(MoveCommand).r39 = function () {
    var tmp;
    if (this.e4h_1.o() === 1) {
      var out = StringBuilder_init_$Create$();
      var id = first_0(this.e4h_1);
      var component = ensureNotNull(ensureNotNull(this.p3g_1).e3b().y3a(id));
      // Inline function 'kotlin.text.appendLine' call
      var value = protoOf(AbstractCommand).r39.call(this) + ' ' + getKClassFromExpression(component).l9() + ' ' + id + ' childrenSize:' + this.g4h_1.o();
      // Inline function 'kotlin.text.appendLine' call
      out.h7(value).i7(_Char___init__impl__6a9atx(10));
      // Inline function 'kotlin.collections.forEach' call
      var _iterator__ex2g4s = this.g4h_1.i();
      while (_iterator__ex2g4s.j()) {
        var element = _iterator__ex2g4s.k();
        // Inline function 'kotlin.text.appendLine' call
        var value_0 = '- child: ' + element.r39();
        // Inline function 'kotlin.text.appendLine' call
        out.h7(value_0).i7(_Char___init__impl__6a9atx(10));
      }
      tmp = out.toString();
    } else {
      tmp = protoOf(AbstractCommand).r39.call(this);
    }
    return tmp;
  };
  protoOf(MoveCommand).s39 = function () {
    var tmp = Companion_instance;
    // Inline function 'kotlin.collections.map' call
    var this_0 = this.e4h_1;
    // Inline function 'kotlin.collections.mapTo' call
    var destination = ArrayList_init_$Create$(collectionSizeOrDefault(this_0, 10));
    var _iterator__ex2g4s = this_0.i();
    while (_iterator__ex2g4s.j()) {
      var item = _iterator__ex2g4s.k();
      var tmp$ret$2 = ensureNotNull(ensureNotNull(this.p3g_1).e3b().y3a(item));
      destination.h(tmp$ret$2);
    }
    tmp.r2h(toList(destination), this.f4h_1);
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s_0 = this.g4h_1.i();
    while (_iterator__ex2g4s_0.j()) {
      var element = _iterator__ex2g4s_0.k();
      element.s39();
    }
  };
  function RectangularHandle(handler) {
    AbstractRectangularUnzoomable.call(this, DrawModule_getInstance().v29_1.it('select.handle.size_half'));
    this.o4h_1 = handler;
    this.p4h_1 = DrawModule_getInstance().v29_1.k1z('select.handle.stroke').p1t_1;
  }
  protoOf(RectangularHandle).l2b = function () {
    return this.p4h_1;
  };
  protoOf(RectangularHandle).r1z = function (context) {
    var rect = this.b2c();
    context.t1y_1.l1t(DrawModule_getInstance().v29_1.j1z('select.handle.color.content'));
    context.t1y_1.u1u(rect);
    context.t1y_1.l1t(DrawModule_getInstance().v29_1.j1z('select.handle.color.border'));
    context.t1y_1.o1t(DrawModule_getInstance().v29_1.k1z('select.handle.stroke'));
    context.t1y_1.t1u(rect);
  };
  protoOf(RectangularHandle).o1z = function (context) {
    var tmp = this.o4h_1;
    return isInterface(tmp, InputEventHandler) ? tmp : THROW_CCE();
  };
  function Companion_40() {
    this.q4h_1 = 2;
  }
  var Companion_instance_45;
  function Companion_getInstance_50() {
    return Companion_instance_45;
  }
  function EventHandler_1($outer) {
    this.u4h_1 = $outer;
    InputEventHandlerAdapter.call(this);
    this.s4h_1 = Companion_getInstance().g1a_1;
    this.t4h_1 = false;
  }
  protoOf(EventHandler_1).g3s = function (context) {
    protoOf(InputEventHandlerAdapter).k22.call(this, context);
    this.u4h_1.z4h_1 = context.x21_1.r23();
    this.s4h_1 = context.d22_1;
    this.u4h_1.j2b(this.s4h_1.in_1, this.s4h_1.jn_1, 0.0, 0.0);
    return this;
  };
  protoOf(EventHandler_1).k22 = function (context) {
    return this.g3s(context instanceof EditInputEventContext ? context : THROW_CCE());
  };
  protoOf(EventHandler_1).h3s = function (context) {
    protoOf(InputEventHandlerAdapter).l22.call(this, context);
    if (!this.t4h_1 && this.s4h_1.o1g(context.a22_1, context.b22_1) >= 2) {
      this.t4h_1 = true;
      context.n3b().i3b().l20(this.u4h_1);
    }
    if (this.t4h_1) {
      var tmp0 = this.s4h_1.in_1;
      // Inline function 'kotlin.math.min' call
      var b = context.a22_1;
      var tmp = Math.min(tmp0, b);
      var tmp0_0 = this.s4h_1.jn_1;
      // Inline function 'kotlin.math.min' call
      var b_0 = context.b22_1;
      var tmp_0 = Math.min(tmp0_0, b_0);
      // Inline function 'kotlin.math.abs' call
      var x = this.s4h_1.in_1 - context.a22_1;
      var tmp_1 = Math.abs(x);
      // Inline function 'kotlin.math.abs' call
      var x_0 = this.s4h_1.jn_1 - context.b22_1;
      var tmp$ret$3 = Math.abs(x_0);
      this.u4h_1.j2b(tmp, tmp_0, tmp_1, tmp$ret$3);
      this.u4h_1.u1z();
    }
    return this;
  };
  protoOf(EventHandler_1).l22 = function (context) {
    return this.h3s(context instanceof EditInputEventContext ? context : THROW_CCE());
  };
  protoOf(EventHandler_1).i3s = function (context) {
    protoOf(InputEventHandlerAdapter).m22.call(this, context);
    if (this.t4h_1) {
      context.n3b().i3b().m20(this.u4h_1);
      context.n3b().i3b().u1z();
    }
    this.t4h_1 = false;
    return this;
  };
  protoOf(EventHandler_1).m22 = function (context) {
    return this.i3s(context instanceof EditInputEventContext ? context : THROW_CCE());
  };
  function RectangularRubberBand() {
    AbstractRectangle.call(this, new Rectangle2D());
    this.z4h_1 = null;
    this.a4i_1 = new EventHandler_1(this);
  }
  protoOf(RectangularRubberBand).y2a = function (_set____db54di) {
    this.z4h_1 = _set____db54di;
  };
  protoOf(RectangularRubberBand).l3s = function () {
    return this.a4i_1;
  };
  protoOf(RectangularRubberBand).r1z = function (context) {
    if (!(this.z4h_1 == null)) {
      var p1 = ensureNotNull(this.z4h_1).t23_1.q24(new Point2D(this.z19(), this.a1a()));
      var p2 = ensureNotNull(this.z4h_1).t23_1.q24(new Point2D(this.z19() + this.p1b(), this.a1a() + this.r1b()));
      this.o2b(context, p1.in_1, p1.jn_1, p2.in_1 - p1.in_1, p2.jn_1 - p1.jn_1, DrawModule_getInstance().v29_1.j1z('edit.select.rubberband.stroke.paint'), DrawModule_getInstance().v29_1.j1z('edit.select.rubberband.fill.paint'), DrawModule_getInstance().v29_1.k1z('edit.select.rubberband.stroke'));
    }
  };
  protoOf(RectangularRubberBand).l2b = function () {
    return DrawModule_getInstance().v29_1.k1z('edit.select.rubberband.stroke').p1t_1;
  };
  function RubberBand() {
  }
  function _get_LOG__e5r759_7($this) {
    var tmp0 = $this.b4i_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('LOG', 1, tmp, RubberBandHandler$Companion$_get_LOG_$ref_3kggbf(), null);
    return tmp0.j2();
  }
  function RubberBandHandler$Companion$_get_LOG_$ref_3kggbf() {
    return function (p0) {
      return _get_LOG__e5r759_7(p0);
    };
  }
  function RubberBandHandler$SelectionTargetStrategy$CONTAINS$select$lambda($currentSelection, $rubberBand) {
    return function (it) {
      return $currentSelection.n(it) || (it.n1z() && $rubberBand.oo(it.do()));
    };
  }
  function RubberBandHandler$SelectionTargetStrategy$INTERSECTS$select$lambda($currentSelection, $rubberBand) {
    return function (it) {
      return $currentSelection.n(it) || (it.n1z() && $rubberBand.po(it.do()));
    };
  }
  function RubberBandHandler$SelectionTargetStrategy$CONTAINS() {
    SelectionTargetStrategy.call(this, 'CONTAINS', 0, 'contains', 'edit.preferences.RubberBand.targetStrategy.contains');
    SelectionTargetStrategy_CONTAINS_instance = this;
  }
  protoOf(RubberBandHandler$SelectionTargetStrategy$CONTAINS).i4i = function (context, currentSelection, rubberBand) {
    var tmp = context.n3b().f3b();
    tmp.m3d(RubberBandHandler$SelectionTargetStrategy$CONTAINS$select$lambda(currentSelection, rubberBand));
  };
  var SelectionTargetStrategy_CONTAINS_instance;
  function RubberBandHandler$SelectionTargetStrategy$INTERSECTS() {
    SelectionTargetStrategy.call(this, 'INTERSECTS', 1, 'intersects', 'edit.preferences.RubberBand.targetStrategy.intersects');
    SelectionTargetStrategy_INTERSECTS_instance = this;
  }
  protoOf(RubberBandHandler$SelectionTargetStrategy$INTERSECTS).i4i = function (context, currentSelection, rubberBand) {
    var tmp = context.n3b().f3b();
    tmp.m3d(RubberBandHandler$SelectionTargetStrategy$INTERSECTS$select$lambda(currentSelection, rubberBand));
  };
  var SelectionTargetStrategy_INTERSECTS_instance;
  function Companion_41() {
  }
  protoOf(Companion_41).r1e = function (name) {
    var tmp0 = values_4();
    var tmp$ret$0;
    $l$block: {
      // Inline function 'kotlin.collections.firstOrNull' call
      var inductionVariable = 0;
      var last = tmp0.length;
      while (inductionVariable < last) {
        var element = tmp0[inductionVariable];
        inductionVariable = inductionVariable + 1 | 0;
        if (element.e2p() === name) {
          tmp$ret$0 = element;
          break $l$block;
        }
      }
      tmp$ret$0 = null;
    }
    var tmp0_elvis_lhs = tmp$ret$0;
    var tmp;
    if (tmp0_elvis_lhs == null) {
      throw IllegalArgumentException_init_$Create$("unknown SelectionTargetStrategy '" + name + "'");
    } else {
      tmp = tmp0_elvis_lhs;
    }
    return tmp;
  };
  var Companion_instance_46;
  function Companion_getInstance_51() {
    return Companion_instance_46;
  }
  function values_4() {
    return [SelectionTargetStrategy_CONTAINS_getInstance(), SelectionTargetStrategy_INTERSECTS_getInstance()];
  }
  var SelectionTargetStrategy_entriesInitialized;
  function SelectionTargetStrategy_initEntries() {
    if (SelectionTargetStrategy_entriesInitialized)
      return Unit_instance;
    SelectionTargetStrategy_entriesInitialized = true;
    SelectionTargetStrategy_CONTAINS_instance = new RubberBandHandler$SelectionTargetStrategy$CONTAINS();
    SelectionTargetStrategy_INTERSECTS_instance = new RubberBandHandler$SelectionTargetStrategy$INTERSECTS();
  }
  function Companion_42() {
    Companion_instance_47 = this;
    this.b4i_1 = logger(getKClass(RubberBandHandler));
    this.c4i_1 = 'edit.select.rubberBandHandler.selectionTargetStrategy';
    this.d4i_1 = 'edit.select.rubberBandHandler.selectDelayMs';
  }
  var Companion_instance_47;
  function Companion_getInstance_52() {
    if (Companion_instance_47 == null)
      new Companion_42();
    return Companion_instance_47;
  }
  function _get_context__ps0bpe($this) {
    var tmp = $this.s4i_1;
    if (!(tmp == null))
      return tmp;
    else {
      throwUninitializedPropertyAccessException('context');
    }
  }
  function _get_selectionTargetStrategy__4q6g8v($this) {
    var tmp0 = $this.t4i_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('selectionTargetStrategy', 1, tmp, RubberBandHandler$_get_selectionTargetStrategy_$ref_3g6n1t(), null);
    return tmp0.j2();
  }
  function captureCurrentSelection($this, selectionManager) {
    $this.r4i_1.a2();
    $this.r4i_1.f1(selectionManager.f3d());
  }
  function initializeTimer($this, timer) {
    if (timer == null) {
      return null;
    }
    var delay = BaseModule_getInstance().xo_1.mt('edit.select.rubberBandHandler.selectDelayMs');
    var tmp;
    if (!(delay == null)) {
      timer.tp(delay, false, RubberBandHandler$initializeTimer$lambda($this));
      tmp = timer;
    } else {
      tmp = null;
    }
    return tmp;
  }
  function performSelection($this, isOther) {
    effectiveTargetStrategy($this, isOther).i4i(_get_context__ps0bpe($this), $this.r4i_1, $this.p4i_1);
  }
  function requestExpandSelection($this, context) {
    if (!($this.q4i_1 == null)) {
      if (!ensureNotNull($this.q4i_1).xp()) {
        $this.s4i_1 = context;
        ensureNotNull($this.q4i_1).vp();
      }
    } else {
      $this.s4i_1 = context;
      var tmp0_safe_receiver = context.y21_1;
      effectiveTargetStrategy($this, (tmp0_safe_receiver == null ? null : tmp0_safe_receiver.isAltDown) === true).i4i(_get_context__ps0bpe($this), $this.r4i_1, $this.p4i_1);
    }
  }
  function effectiveTargetStrategy($this, isOther) {
    var tmp;
    if (isOther) {
      tmp = _get_selectionTargetStrategy__4q6g8v($this).j4i();
    } else {
      tmp = _get_selectionTargetStrategy__4q6g8v($this);
    }
    return tmp;
  }
  function SelectionTargetStrategy(name, ordinal, customName, nameKey) {
    Enum.call(this, name, ordinal);
    this.z4g_1 = customName;
    this.a4h_1 = nameKey;
  }
  protoOf(SelectionTargetStrategy).e2p = function () {
    return this.z4g_1;
  };
  protoOf(SelectionTargetStrategy).toString = function () {
    return Translations_getInstance().zm(this.a4h_1, []);
  };
  protoOf(SelectionTargetStrategy).j4i = function () {
    var tmp;
    switch (this.l2_1) {
      case 0:
        tmp = SelectionTargetStrategy_INTERSECTS_getInstance();
        break;
      case 1:
        tmp = SelectionTargetStrategy_CONTAINS_getInstance();
        break;
      default:
        noWhenBranchMatchedException();
        break;
    }
    return tmp;
  };
  function RubberBandHandler$selectionTargetStrategy$delegate$lambda() {
    return Companion_instance_46.r1e(BaseModule_getInstance().xo_1.ht('edit.select.rubberBandHandler.selectionTargetStrategy'));
  }
  function RubberBandHandler$_get_selectionTargetStrategy_$ref_3g6n1t() {
    return function (p0) {
      return _get_selectionTargetStrategy__4q6g8v(p0);
    };
  }
  function RubberBandHandler$initializeTimer$lambda(this$0) {
    return function (it) {
      var tmp0_safe_receiver = _get_context__ps0bpe(this$0).y21_1;
      performSelection(this$0, (tmp0_safe_receiver == null ? null : tmp0_safe_receiver.isAltDown) === true);
      return Unit_instance;
    };
  }
  function SelectionTargetStrategy_CONTAINS_getInstance() {
    SelectionTargetStrategy_initEntries();
    return SelectionTargetStrategy_CONTAINS_instance;
  }
  function SelectionTargetStrategy_INTERSECTS_getInstance() {
    SelectionTargetStrategy_initEntries();
    return SelectionTargetStrategy_INTERSECTS_instance;
  }
  function RubberBandHandler(rubberBand) {
    Companion_getInstance_52();
    InputEventHandlerAdapter.call(this);
    this.p4i_1 = rubberBand;
    this.q4i_1 = System_getInstance().ul();
    var tmp = this;
    // Inline function 'kotlin.collections.mutableListOf' call
    tmp.r4i_1 = ArrayList_init_$Create$_0();
    var tmp_0 = this;
    tmp_0.t4i_1 = lazy(RubberBandHandler$selectionTargetStrategy$delegate$lambda);
    initializeTimer(this, this.q4i_1);
  }
  protoOf(RubberBandHandler).d3s = function (context) {
    var tmp0_safe_receiver = context.z21_1;
    if ((tmp0_safe_receiver == null ? null : tmp0_safe_receiver.i2()) === Companion_instance_0.e18_1) {
      this.s4i_1 = context;
      performSelection(this, true);
    }
    return this;
  };
  protoOf(RubberBandHandler).n22 = function (context) {
    return this.d3s(context instanceof EditInputEventContext ? context : THROW_CCE());
  };
  protoOf(RubberBandHandler).e3s = function (context) {
    var tmp0_safe_receiver = context.z21_1;
    if ((tmp0_safe_receiver == null ? null : tmp0_safe_receiver.i2()) === Companion_instance_0.e18_1) {
      this.s4i_1 = context;
      performSelection(this, false);
    }
    return this;
  };
  protoOf(RubberBandHandler).o22 = function (context) {
    return this.e3s(context instanceof EditInputEventContext ? context : THROW_CCE());
  };
  protoOf(RubberBandHandler).g3s = function (context) {
    protoOf(InputEventHandlerAdapter).k22.call(this, context);
    captureCurrentSelection(this, context.n3b().f3b());
    return this.p4i_1.l3s().k22(context);
  };
  protoOf(RubberBandHandler).k22 = function (context) {
    return this.g3s(context instanceof EditInputEventContext ? context : THROW_CCE());
  };
  protoOf(RubberBandHandler).h3s = function (context) {
    protoOf(InputEventHandlerAdapter).l22.call(this, context);
    this.p4i_1.l3s().l22(context);
    requestExpandSelection(this, context);
    return this;
  };
  protoOf(RubberBandHandler).l22 = function (context) {
    return this.h3s(context instanceof EditInputEventContext ? context : THROW_CCE());
  };
  protoOf(RubberBandHandler).i3s = function (context) {
    protoOf(InputEventHandlerAdapter).m22.call(this, context);
    this.p4i_1.l3s().m22(context);
    var tmp;
    if (_get_LOG__e5r759_7(Companion_getInstance_52()).pl()) {
      var tmp_0 = this.p4i_1;
      tmp = tmp_0 instanceof RectangularRubberBand;
    } else {
      tmp = false;
    }
    if (tmp) {
      if (this.p4i_1.e1c() > 0 || this.p4i_1.f1c() > 0) {
        _get_LOG__e5r759_7(Companion_getInstance_52()).nl('Rectangular selection from ' + this.p4i_1.c1c() + '/' + this.p4i_1.d1c() + ' to ' + (this.p4i_1.c1c() + this.p4i_1.e1c() | 0) + '/' + (this.p4i_1.d1c() + this.p4i_1.f1c() | 0));
      }
    }
    return null;
  };
  protoOf(RubberBandHandler).m22 = function (context) {
    return this.i3s(context instanceof EditInputEventContext ? context : THROW_CCE());
  };
  function get_selectedColorSelectionModelFactory() {
    _init_properties_SelectedColorSelectionModel_kt__z8798t();
    return selectedColorSelectionModelFactory;
  }
  var selectedColorSelectionModelFactory;
  function SelectedColorSelectionModel(component) {
    AbstractSelectionModel.call(this, component);
  }
  protoOf(SelectedColorSelectionModel).r1z = function (context) {
    var oldColor = context.t1y_1.m1t();
    var oldUseContextColors = context.w1y_1;
    context.t1y_1.l1t(Themes_getInstance().r2f().x3x_1.m1t().h1x_1);
    context.w1y_1 = true;
    context.x1y_1 = Themes_getInstance().r2f().x3x_1.m1t();
    this.b3s().r1z(context);
    context.t1y_1.l1t(oldColor);
    context.w1y_1 = oldUseContextColors;
  };
  protoOf(SelectedColorSelectionModel).do = function () {
    return this.b3s().do();
  };
  protoOf(SelectedColorSelectionModel).eo = function (x, y) {
    return this.b3s().eo(x, y);
  };
  protoOf(SelectedColorSelectionModel).r3s = function () {
    this.u1z();
  };
  function selectedColorSelectionModelFactory$lambda(it) {
    _init_properties_SelectedColorSelectionModel_kt__z8798t();
    return new SelectedColorSelectionModel(it);
  }
  var properties_initialized_SelectedColorSelectionModel_kt_3rj7ez;
  function _init_properties_SelectedColorSelectionModel_kt__z8798t() {
    if (!properties_initialized_SelectedColorSelectionModel_kt_3rj7ez) {
      properties_initialized_SelectedColorSelectionModel_kt_3rj7ez = true;
      selectedColorSelectionModelFactory = selectedColorSelectionModelFactory$lambda;
    }
  }
  function _get_LOG__e5r759_8($this) {
    var tmp0 = $this.u4i_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('LOG', 1, tmp, SelectionManagerImpl$Companion$_get_LOG_$ref_t1fzq7(), null);
    return tmp0.j2();
  }
  function SelectionManagerImpl$Companion$_get_LOG_$ref_t1fzq7() {
    return function (p0) {
      return _get_LOG__e5r759_8(p0);
    };
  }
  function Companion_43() {
    Companion_instance_48 = this;
    this.u4i_1 = logger(getKClass(SelectionManagerImpl));
  }
  var Companion_instance_48;
  function Companion_getInstance_53() {
    if (Companion_instance_48 == null)
      new Companion_43();
    return Companion_instance_48;
  }
  function canSelect($this, component) {
    return component.n1z() && !$this.l3d(component);
  }
  function postSelectionChanged($this, components, selected) {
    $this.x4i_1.eu(SelectionChangeEvent_init_$Create$($this.v4i_1.n3b(), components, selected));
  }
  function selectImpl($this, component) {
    var strategy = $this.v4i_1.n3b().m3b(component);
    var selectionModel = $this.w4i_1.d3n(component, strategy);
    if (selectionModel == null && !(component.p3a() == null)) {
      strategy = ensureNotNull(component.p3a());
      selectionModel = $this.w4i_1.d3n(component, strategy);
    }
    if (selectionModel == null) {
      _get_LOG__e5r759_8(Companion_getInstance_53()).kl('SelectionManagerImpl: No suitable SelectionModel found for ' + (System_getInstance().wl(component.n3a()) + ' and strategy ' + strategy.toString()));
      return Unit_instance;
    }
    $this.v4i_1.r3b(selectionModel, strategy);
    var tmp0 = $this.y4i_1;
    // Inline function 'kotlin.collections.set' call
    var value = selectionModel;
    tmp0.y1(component, value);
    selectionModel.q3s($this.v4i_1.n3b());
  }
  function deselectImpl($this, component) {
    var selectionModel = $this.y4i_1.g2(component);
    if (!(selectionModel == null)) {
      $this.y4i_1.z1(component);
      $this.v4i_1.s3b(selectionModel);
      $this.w4i_1.z4i(selectionModel);
      selectionModel.w3s($this.v4i_1.n3b());
    }
  }
  function SelectionManagerImpl$replace$lambda($condition) {
    return function (it) {
      return $condition(it);
    };
  }
  function SelectionManagerImpl(content, selectionModelProvider, eventBus) {
    Companion_getInstance_53();
    selectionModelProvider = selectionModelProvider === VOID ? EditSelectModule_getInstance().c3l_1 : selectionModelProvider;
    eventBus = eventBus === VOID ? BaseModule_getInstance().zo_1 : eventBus;
    this.v4i_1 = content;
    this.w4i_1 = selectionModelProvider;
    this.x4i_1 = eventBus;
    var tmp = this;
    // Inline function 'kotlin.collections.mutableMapOf' call
    tmp.y4i_1 = LinkedHashMap_init_$Create$();
  }
  protoOf(SelectionManagerImpl).f3d = function () {
    return toList(this.y4i_1.b2());
  };
  protoOf(SelectionManagerImpl).w2u = function () {
    // Inline function 'kotlin.with' call
    var $this$with = this.f3d();
    if ($this$with.m()) {
      postSelectionChanged(this, emptyList(), false);
    } else {
      postSelectionChanged(this, $this$with, true);
    }
  };
  protoOf(SelectionManagerImpl).g3d = function (component) {
    if (canSelect(this, component)) {
      selectImpl(this, component);
      this.v4i_1.e3b().u1z();
      postSelectionChanged(this, listOf(component), true);
    }
  };
  protoOf(SelectionManagerImpl).h3d = function (components) {
    // Inline function 'kotlin.collections.mutableListOf' call
    var newSelections = ArrayList_init_$Create$_0();
    var _iterator__ex2g4s = components.i();
    while (_iterator__ex2g4s.j()) {
      var c = _iterator__ex2g4s.k();
      if (canSelect(this, c)) {
        selectImpl(this, c);
        newSelections.h(c);
      }
    }
    // Inline function 'kotlin.collections.isNotEmpty' call
    if (!newSelections.m()) {
      postSelectionChanged(this, newSelections, true);
      this.v4i_1.e3b().u1z();
    }
  };
  protoOf(SelectionManagerImpl).i3d = function (component) {
    if (this.l3d(component)) {
      deselectImpl(this, component);
      this.v4i_1.e3b().u1z();
      postSelectionChanged(this, listOf(component), false);
    }
  };
  protoOf(SelectionManagerImpl).j3d = function (components) {
    // Inline function 'kotlin.collections.mutableListOf' call
    var list = ArrayList_init_$Create$_0();
    var _iterator__ex2g4s = components.i();
    while (_iterator__ex2g4s.j()) {
      var c = _iterator__ex2g4s.k();
      if (this.l3d(c)) {
        deselectImpl(this, c);
        list.h(c);
      }
    }
    // Inline function 'kotlin.collections.isNotEmpty' call
    if (!list.m()) {
      postSelectionChanged(this, list, false);
      this.v4i_1.e3b().u1z();
    }
  };
  protoOf(SelectionManagerImpl).k3d = function () {
    // Inline function 'kotlin.collections.mutableListOf' call
    var list = ArrayList_init_$Create$_0();
    var _iterator__ex2g4s = toList(this.y4i_1.b2()).i();
    while (_iterator__ex2g4s.j()) {
      var c = _iterator__ex2g4s.k();
      deselectImpl(this, c);
      list.h(c);
    }
    // Inline function 'kotlin.collections.isNotEmpty' call
    if (!list.m()) {
      postSelectionChanged(this, list, false);
      this.v4i_1.e3b().u1z();
    }
  };
  protoOf(SelectionManagerImpl).l3d = function (component) {
    return this.y4i_1.e2(component);
  };
  protoOf(SelectionManagerImpl).m3d = function (condition) {
    var currentSelection = this.f3d();
    // Inline function 'kotlin.collections.mutableListOf' call
    var toDeselect = ArrayList_init_$Create$_0();
    // Inline function 'kotlin.collections.mutableListOf' call
    var toSelect = ArrayList_init_$Create$_0();
    // Inline function 'kotlin.collections.filter' call
    // Inline function 'kotlin.collections.filterTo' call
    var destination = ArrayList_init_$Create$_0();
    var _iterator__ex2g4s = currentSelection.i();
    while (_iterator__ex2g4s.j()) {
      var element = _iterator__ex2g4s.k();
      if (!condition(element)) {
        destination.h(element);
      }
    }
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s_0 = destination.i();
    while (_iterator__ex2g4s_0.j()) {
      var element_0 = _iterator__ex2g4s_0.k();
      toDeselect.h(element_0);
    }
    var tmp = this.v4i_1.e3b();
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s_1 = tmp.u20(SelectionManagerImpl$replace$lambda(condition)).i();
    while (_iterator__ex2g4s_1.j()) {
      var element_1 = _iterator__ex2g4s_1.k();
      toSelect.h(element_1);
    }
    // Inline function 'kotlin.collections.isNotEmpty' call
    if (!toDeselect.m()) {
      this.j3d(toDeselect);
    }
    // Inline function 'kotlin.collections.isNotEmpty' call
    if (!toSelect.m()) {
      this.h3d(toSelect);
    }
  };
  function Entry(componentClassName, factory) {
    this.a4j_1 = componentClassName;
    this.b4j_1 = factory;
  }
  protoOf(Entry).toString = function () {
    return 'Entry(componentClassName=' + this.a4j_1 + ', factory=' + toString(this.b4j_1) + ')';
  };
  protoOf(Entry).hashCode = function () {
    var result = getStringHashCode(this.a4j_1);
    result = imul(result, 31) + hashCode(this.b4j_1) | 0;
    return result;
  };
  protoOf(Entry).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof Entry))
      return false;
    if (!(this.a4j_1 === other.a4j_1))
      return false;
    if (!equals(this.b4j_1, other.b4j_1))
      return false;
    return true;
  };
  function SelectionModelFactoryImpl(defaultFactories) {
    defaultFactories = defaultFactories === VOID ? emptyMap() : defaultFactories;
    this.c4j_1 = defaultFactories;
    var tmp = this;
    // Inline function 'kotlin.collections.mutableMapOf' call
    tmp.d4j_1 = LinkedHashMap_init_$Create$();
  }
  protoOf(SelectionModelFactoryImpl).e4j = function (component, strategy) {
    var entries = this.d4j_1.g2(strategy);
    if (!(entries == null)) {
      var tmp$ret$0;
      $l$block: {
        // Inline function 'kotlin.collections.firstOrNull' call
        var _iterator__ex2g4s = entries.i();
        while (_iterator__ex2g4s.j()) {
          var element = _iterator__ex2g4s.k();
          if (element.a4j_1 === System_getInstance().wl(component.n3a())) {
            tmp$ret$0 = element;
            break $l$block;
          }
        }
        tmp$ret$0 = null;
      }
      var entry = tmp$ret$0;
      if (!(entry == null)) {
        return entry.b4j_1(component.n3a());
      }
    }
    var tmp0_safe_receiver = this.c4j_1.g2(strategy);
    var tmp;
    if (tmp0_safe_receiver == null) {
      tmp = null;
    } else {
      // Inline function 'kotlin.let' call
      tmp = tmp0_safe_receiver(component.n3a());
    }
    return tmp;
  };
  protoOf(SelectionModelFactoryImpl).w3u = function (strategy, componentClass, factory) {
    // Inline function 'kotlin.collections.getOrPut' call
    var this_0 = this.d4j_1;
    var value = this_0.g2(strategy);
    var tmp;
    if (value == null) {
      // Inline function 'kotlin.collections.mutableListOf' call
      var answer = ArrayList_init_$Create$_0();
      this_0.y1(strategy, answer);
      tmp = answer;
    } else {
      tmp = value;
    }
    tmp.h(new Entry(System_getInstance().vl(componentClass), factory));
  };
  function _get_LOG__e5r759_9($this) {
    var tmp0 = $this.f4j_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('LOG', 1, tmp, SelectionToolImpl$Companion$_get_LOG_$ref_ftap0(), null);
    return tmp0.j2();
  }
  function SelectionToolImpl$Companion$_get_LOG_$ref_ftap0() {
    return function (p0) {
      return _get_LOG__e5r759_9(p0);
    };
  }
  function Companion_44() {
    Companion_instance_49 = this;
    this.f4j_1 = logger(getKClass(SelectionToolImpl));
  }
  var Companion_instance_49;
  function Companion_getInstance_54() {
    if (Companion_instance_49 == null)
      new Companion_44();
    return Companion_instance_49;
  }
  function updateStatus($this) {
    if ($this.g4j_1.i3c() === $this) {
      Status_getInstance().du(StatusType_Tool_getInstance(), Translations_getInstance().zm('edit.tool.select.zoom.text', []) + '. ' + CurrentPanMethod_getInstance().z2w_1.kq());
    }
  }
  function selectionLogic($this, e, x, y, allowRubberband) {
    if (CurrentPanMethod_getInstance().z2w_1.q2w(e)) {
      return Unit_instance;
    }
    var component = $this.g4j_1.e3b().s20(x, y);
    if (!(component == null)) {
      var scope = mutableListOf([component]);
      if (e.isMetaDown) {
        // Inline function 'kotlin.collections.mutableSetOf' call
        var buddies = LinkedHashSet_init_$Create$();
        component.r3a($this.g4j_1.e3b(), buddies);
        scope.f1(buddies);
      }
      if (e.isShiftDown) {
        if ($this.g4j_1.f1o().f3b().l3d(component)) {
          _get_LOG__e5r759_9(Companion_getInstance_54()).ol('Removing component from selection');
          $this.g4j_1.f1o().f3b().j3d(scope);
        } else {
          _get_LOG__e5r759_9(Companion_getInstance_54()).ol('Adding component to selection');
          $this.g4j_1.f1o().f3b().h3d(scope);
        }
      } else {
        if (!$this.g4j_1.f1o().f3b().l3d(component)) {
          _get_LOG__e5r759_9(Companion_getInstance_54()).nl('Select single component at ' + numberToInt(x) + '/' + numberToInt(y));
          $this.g4j_1.f1o().f3b().k3d();
          $this.g4j_1.f1o().f3b().h3d(scope);
        }
      }
      $this.g4j_1.k3c().s3j(component, x, y);
      $this.j4j_1 = $this.g4j_1.f1o().n23(e).k22($this.m4j(e, x, y));
    } else {
      if (!e.isShiftDown) {
        $this.g4j_1.f1o().f3b().k3d();
      }
      if (allowRubberband) {
        _get_LOG__e5r759_9(Companion_getInstance_54()).ol('delegating to rubberband');
        $this.j4j_1 = $this.i4j_1;
        var tmp0_safe_receiver = $this.j4j_1;
        if (tmp0_safe_receiver == null)
          null;
        else
          tmp0_safe_receiver.k22($this.m4j(e, x, y));
      }
    }
  }
  function SelectionToolImpl$lambda$lambda(this$0) {
    return function () {
      updateStatus(this$0);
      return Unit_instance;
    };
  }
  function SelectionToolImpl$lambda(this$0) {
    return function (it) {
      var tmp = System_getInstance();
      tmp.dm(SelectionToolImpl$lambda$lambda(this$0));
      return Unit_instance;
    };
  }
  function SelectionToolImpl(editor, rubberBandHandler, eventBus) {
    Companion_getInstance_54();
    ToolAdapter.call(this, editor);
    this.i4j_1 = rubberBandHandler;
    this.j4j_1 = null;
    this.k4j_1 = new TooltipHandler(eventBus);
    this.l4j_1 = false;
    var tmp = getKClass(PreferencesChangedEvent);
    eventBus.j17(tmp, SelectionToolImpl$lambda(this));
  }
  protoOf(SelectionToolImpl).w2u = function () {
    this.g4j_1.f1o().v1x(Cursor_DEFAULT_getInstance());
    updateStatus(this);
  };
  protoOf(SelectionToolImpl).x19 = function (e) {
    if (!this.g4j_1.f1o().b3b()) {
      return Unit_instance;
    }
    _get_LOG__e5r759_9(Companion_getInstance_54()).ol('keyPressed');
    var context = this.n4j(e);
    if (!(this.j4j_1 == null)) {
      var tmp = this;
      var tmp0_safe_receiver = this.j4j_1;
      tmp.j4j_1 = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.n22(context);
      return Unit_instance;
    }
    if (this.g4j_1.k3c().x3j(e) && this.g4j_1.f1o().f3b().e3d() > 0) {
      this.g4j_1.k3c().y3j(e);
    } else {
      this.g4j_1.k3c().n22(context);
    }
  };
  protoOf(SelectionToolImpl).y19 = function (e) {
    if (!this.g4j_1.f1o().b3b()) {
      return Unit_instance;
    }
    _get_LOG__e5r759_9(Companion_getInstance_54()).ol('keyReleased');
    var context = this.n4j(e);
    this.g4j_1.k3c().o22(context);
    var tmp = this;
    var tmp0_safe_receiver = this.j4j_1;
    tmp.j4j_1 = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.o22(context);
  };
  protoOf(SelectionToolImpl).n3e = function (e, x, y) {
    if (!this.g4j_1.f1o().b3b()) {
      return Unit_instance;
    }
    _get_LOG__e5r759_9(Companion_getInstance_54()).ol('mouseClicked at ' + x + ',' + y);
    if (!(this.j4j_1 == null)) {
      var tmp = this;
      var tmp0_safe_receiver = this.j4j_1;
      tmp.j4j_1 = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.i22(this.m4j(e, x, y));
      if (!(this.j4j_1 == null)) {
        return Unit_instance;
      }
    }
    this.j4j_1 = this.g4j_1.f1o().n23(e).i22(this.m4j(e, x, y));
  };
  protoOf(SelectionToolImpl).t3e = function (e, x, y) {
    protoOf(ToolAdapter).t3e.call(this, e, x, y);
    if (!this.g4j_1.f1o().b3b()) {
      return Unit_instance;
    }
    var context = this.m4j(e, x, y);
    if (!(this.j4j_1 == null)) {
      var tmp = this;
      var tmp0_safe_receiver = this.j4j_1;
      tmp.j4j_1 = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.j22(context);
      if (!(this.j4j_1 == null)) {
        return Unit_instance;
      }
    }
    this.j4j_1 = this.g4j_1.f1o().n23(e).j22(context);
    if (this.j4j_1 == null) {
      this.p4j(this.g4j_1.e3b().s20(x, y));
    }
    this.k4j_1.x2x(this.g4j_1.f1o(), this.g4j_1.e3b(), context);
  };
  protoOf(SelectionToolImpl).p3e = function (e, x, y) {
    if (!this.g4j_1.f1o().b3b()) {
      selectionLogic(this, e, x, y, false);
      return Unit_instance;
    }
    this.k4j_1.w2x(this.g4j_1.f1o());
    if (!e.b1a().equals(Button_BUTTON1_getInstance())) {
      return Unit_instance;
    }
    _get_LOG__e5r759_9(Companion_getInstance_54()).ol('mousePressed at ' + x + ',' + y);
    this.l4j_1 = this.g4j_1.l3c().y39();
    this.g4j_1.l3c().x39(false);
    if (!(this.j4j_1 == null)) {
      var tmp = this;
      var tmp0_safe_receiver = this.j4j_1;
      tmp.j4j_1 = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.k22(this.m4j(e, x, y));
      if (!(this.j4j_1 == null)) {
        return Unit_instance;
      }
    }
    this.l4j_1 = true;
    this.j4j_1 = this.g4j_1.f1o().n23(e).k22(this.m4j(e, x, y));
    selectionLogic(this, e, x, y, true);
  };
  protoOf(SelectionToolImpl).v3e = function (e, x, y) {
    if (!this.g4j_1.f1o().b3b()) {
      return Unit_instance;
    }
    if (!e.e1a()) {
      _get_LOG__e5r759_9(Companion_getInstance_54()).ol('Drag with other than button 1: ' + e.b1a().k2_1);
      return Unit_instance;
    }
    if (_get_LOG__e5r759_9(Companion_getInstance_54()).ql()) {
      _get_LOG__e5r759_9(Companion_getInstance_54()).ol('drag to ' + x + ',' + y + ', target is ' + toString_0(this.j4j_1));
    }
    var context = this.m4j(e, x, y);
    if (!(this.j4j_1 == null)) {
      var tmp = this;
      var tmp0_safe_receiver = this.j4j_1;
      tmp.j4j_1 = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.l22(context);
      if (!(this.j4j_1 == null)) {
        return Unit_instance;
      }
    }
    this.g4j_1.k3c().l22(context);
  };
  protoOf(SelectionToolImpl).r3e = function (e, x, y) {
    if (!this.g4j_1.f1o().b3b()) {
      return Unit_instance;
    }
    if (!e.b1a().equals(Button_BUTTON1_getInstance())) {
      return Unit_instance;
    }
    _get_LOG__e5r759_9(Companion_getInstance_54()).ol('mouseReleased at ' + x + ',' + y);
    this.g4j_1.l3c().x39(this.l4j_1);
    var context = this.m4j(e, x, y);
    if (!(this.j4j_1 == null)) {
      var tmp = this;
      var tmp0_safe_receiver = this.j4j_1;
      tmp.j4j_1 = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.m22(context);
    }
    this.g4j_1.k3c().m22(context);
    if (this.j4j_1 == null) {
      this.p4j(this.g4j_1.e3b().s20(x, y));
    }
  };
  function SimpleSelectionModelProvider(factory) {
    this.r4j_1 = factory;
  }
  protoOf(SimpleSelectionModelProvider).d3n = function (component, strategy) {
    var selectionModel = this.r4j_1.e4j(component, strategy);
    if (selectionModel == null)
      null;
    else {
      selectionModel.v3s();
    }
    return selectionModel;
  };
  protoOf(SimpleSelectionModelProvider).z4i = function (selectionModel) {
    selectionModel.es();
  };
  function UnzoomableSelectionModel() {
  }
  function SemanticRegistry() {
    SemanticRegistry_instance = this;
    var tmp = this;
    // Inline function 'kotlin.collections.mutableSetOf' call
    tmp.s4j_1 = LinkedHashSet_init_$Create$();
  }
  protoOf(SemanticRegistry).t4j = function (semantic) {
    if (this.s4j_1.n(semantic)) {
      throw IllegalArgumentException_init_$Create$('Semantic ' + semantic.e2p() + ' already registered');
    }
    this.s4j_1.h(semantic);
  };
  protoOf(SemanticRegistry).t4e = function (customName) {
    var tmp0 = this.s4j_1;
    var tmp$ret$0;
    $l$block: {
      // Inline function 'kotlin.collections.firstOrNull' call
      var _iterator__ex2g4s = tmp0.i();
      while (_iterator__ex2g4s.j()) {
        var element = _iterator__ex2g4s.k();
        if (element.e2p() === customName) {
          tmp$ret$0 = element;
          break $l$block;
        }
      }
      tmp$ret$0 = null;
    }
    var tmp0_elvis_lhs = tmp$ret$0;
    var tmp;
    if (tmp0_elvis_lhs == null) {
      throw IllegalArgumentException_init_$Create$('Semantic ' + customName + ' not registered');
    } else {
      tmp = tmp0_elvis_lhs;
    }
    return tmp;
  };
  var SemanticRegistry_instance;
  function SemanticRegistry_getInstance() {
    if (SemanticRegistry_instance == null)
      new SemanticRegistry();
    return SemanticRegistry_instance;
  }
  function DoSnapResult(value, snappable) {
    this.u4j_1 = value;
    this.v4j_1 = snappable;
  }
  protoOf(DoSnapResult).toString = function () {
    return 'DoSnapResult(value=' + this.u4j_1 + ', snappable=' + toString_0(this.v4j_1) + ')';
  };
  protoOf(DoSnapResult).hashCode = function () {
    var result = getNumberHashCode(this.u4j_1);
    result = imul(result, 31) + (this.v4j_1 == null ? 0 : hashCode(this.v4j_1)) | 0;
    return result;
  };
  protoOf(DoSnapResult).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof DoSnapResult))
      return false;
    if (!equals(this.u4j_1, other.u4j_1))
      return false;
    if (!equals(this.v4j_1, other.v4j_1))
      return false;
    return true;
  };
  function AbstractSnapper$snappableXFilter$lambda(_unused_var__etf5q3, _unused_var__etf5q3_0) {
    return true;
  }
  function AbstractSnapper$snappableYFilter$lambda(_unused_var__etf5q3, _unused_var__etf5q3_0) {
    return true;
  }
  function AbstractSnapper(snapEnabled) {
    snapEnabled = snapEnabled === VOID ? true : snapEnabled;
    AbstractDrawable.call(this);
    this.z4j_1 = snapEnabled;
    var tmp = this;
    tmp.a4k_1 = AbstractSnapper$snappableXFilter$lambda;
    var tmp_0 = this;
    tmp_0.b4k_1 = AbstractSnapper$snappableYFilter$lambda;
  }
  protoOf(AbstractSnapper).q3j = function () {
    return this.z4j_1;
  };
  protoOf(AbstractSnapper).f3e = function (x, y, result) {
    if (this.q3j()) {
      this.g3e(x, result);
      this.h3e(y, result);
    }
  };
  protoOf(AbstractSnapper).g3e = function (x, result) {
    if (this.q3j()) {
      var tmp0_safe_receiver = this.c4k(new SnappableXCoordinate(x), 0.0);
      if (tmp0_safe_receiver == null)
        null;
      else {
        // Inline function 'kotlin.let' call
        result.x3d(tmp0_safe_receiver.u4j_1 - x, tmp0_safe_receiver.u4j_1, this);
        result.v3d_1 = tmp0_safe_receiver.v4j_1;
      }
    }
  };
  protoOf(AbstractSnapper).h3e = function (y, result) {
    if (this.q3j()) {
      var tmp0_safe_receiver = this.d4k(new SnappableYCoordinate(y), 0.0);
      if (tmp0_safe_receiver == null)
        null;
      else {
        // Inline function 'kotlin.let' call
        result.y3d(tmp0_safe_receiver.u4j_1 - y, tmp0_safe_receiver.u4j_1, this);
        result.w3d_1 = tmp0_safe_receiver.v4j_1;
      }
    }
  };
  protoOf(AbstractSnapper).i3e = function (snappable, dx, dy, result) {
    if (this.q3j()) {
      this.j3e(snappable, dx, result);
      this.k3e(snappable, dy, result);
    }
  };
  protoOf(AbstractSnapper).j3e = function (snappable, dx, result) {
    if (!this.q3j()) {
      return Unit_instance;
    }
    var snappableX = snappable.t3a();
    var minSnapDX = 1.7976931348623157E308;
    var minSnapX = 0.0;
    var minSnappable = null;
    var inductionVariable = 0;
    // Inline function 'kotlin.collections.filterIndexed' call
    var predicate = this.e4k();
    // Inline function 'kotlin.collections.filterIndexedTo' call
    var destination = ArrayList_init_$Create$_0();
    // Inline function 'kotlin.collections.forEachIndexed' call
    var index = 0;
    var inductionVariable_0 = 0;
    var last = snappableX.length;
    while (inductionVariable_0 < last) {
      var item = snappableX[inductionVariable_0];
      inductionVariable_0 = inductionVariable_0 + 1 | 0;
      var _unary__edvuaz = index;
      index = _unary__edvuaz + 1 | 0;
      if (predicate(_unary__edvuaz, item)) {
        destination.h(item);
      }
    }
    var last_0 = destination.o() - 1 | 0;
    if (inductionVariable <= last_0)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        var tmp0_safe_receiver = this.c4k(snappableX[i], dx);
        if (tmp0_safe_receiver == null)
          null;
        else {
          // Inline function 'kotlin.let' call
          var dX = tmp0_safe_receiver.u4j_1 - (snappableX[i].z19() + dx);
          // Inline function 'kotlin.math.abs' call
          var tmp = Math.abs(dX);
          // Inline function 'kotlin.math.abs' call
          var x = minSnapDX;
          if (tmp < Math.abs(x)) {
            minSnapX = tmp0_safe_receiver.u4j_1;
            minSnapDX = dX;
            minSnappable = tmp0_safe_receiver.v4j_1;
          }
        }
      }
       while (inductionVariable <= last_0);
    if (!(minSnapDX === 1.7976931348623157E308)) {
      result.x3d(minSnapDX, minSnapX, this);
      result.v3d_1 = minSnappable;
    }
  };
  protoOf(AbstractSnapper).k3e = function (snappable, dy, result) {
    if (!this.q3j()) {
      return Unit_instance;
    }
    var snappableY = snappable.u3a();
    var minSnapDY = 1.7976931348623157E308;
    var minSnapY = 0.0;
    var minSnappable = null;
    var inductionVariable = 0;
    // Inline function 'kotlin.collections.filterIndexed' call
    var predicate = this.f4k();
    // Inline function 'kotlin.collections.filterIndexedTo' call
    var destination = ArrayList_init_$Create$_0();
    // Inline function 'kotlin.collections.forEachIndexed' call
    var index = 0;
    var inductionVariable_0 = 0;
    var last = snappableY.length;
    while (inductionVariable_0 < last) {
      var item = snappableY[inductionVariable_0];
      inductionVariable_0 = inductionVariable_0 + 1 | 0;
      var _unary__edvuaz = index;
      index = _unary__edvuaz + 1 | 0;
      if (predicate(_unary__edvuaz, item)) {
        destination.h(item);
      }
    }
    var last_0 = destination.o() - 1 | 0;
    if (inductionVariable <= last_0)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        var tmp0_safe_receiver = this.d4k(snappableY[i], dy);
        if (tmp0_safe_receiver == null)
          null;
        else {
          // Inline function 'kotlin.let' call
          var dY = tmp0_safe_receiver.u4j_1 - (snappableY[i].a1a() + dy);
          // Inline function 'kotlin.math.abs' call
          var tmp = Math.abs(dY);
          // Inline function 'kotlin.math.abs' call
          var x = minSnapDY;
          if (tmp < Math.abs(x)) {
            minSnapY = tmp0_safe_receiver.u4j_1;
            minSnapDY = dY;
            minSnappable = tmp0_safe_receiver.v4j_1;
          }
        }
      }
       while (inductionVariable <= last_0);
    if (!(minSnapDY === 1.7976931348623157E308)) {
      result.y3d(minSnapDY, minSnapY, this);
      result.w3d_1 = minSnappable;
    }
  };
  protoOf(AbstractSnapper).e4k = function () {
    return this.a4k_1;
  };
  protoOf(AbstractSnapper).f4k = function () {
    return this.b4k_1;
  };
  function _get_LOG__e5r759_10($this) {
    var tmp0 = $this.g4k_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('LOG', 1, tmp, ComponentSnapper$Companion$_get_LOG_$ref_5drjbe(), null);
    return tmp0.j2();
  }
  function ComponentSnapper$Companion$_get_LOG_$ref_5drjbe() {
    return function (p0) {
      return _get_LOG__e5r759_10(p0);
    };
  }
  function Companion_45() {
    Companion_instance_50 = this;
    this.g4k_1 = logger(getKClass(ComponentSnapper));
    this.h4k_1 = 'edit.snap.highlight.color';
    this.i4k_1 = 'edit.snap.highlight.stroke';
    this.j4k_1 = 'edit.componentSnap.enabled';
    this.k4k_1 = 15.0;
    this.l4k_1 = new Rectangle2D();
  }
  var Companion_instance_50;
  function Companion_getInstance_55() {
    if (Companion_instance_50 == null)
      new Companion_45();
    return Companion_instance_50;
  }
  function SnapHighlightX($outer) {
    this.s4k_1 = $outer;
    AbstractDrawable.call(this);
    this.p4k_1 = 0;
    this.q4k_1 = null;
    this.r4k_1 = new Rectangle2D();
  }
  protoOf(SnapHighlightX).y2a = function (_set____db54di) {
    this.q4k_1 = _set____db54di;
  };
  protoOf(SnapHighlightX).do = function () {
    return this.r4k_1;
  };
  protoOf(SnapHighlightX).r1z = function (context) {
    var oldColor = context.t1y_1.m1t();
    var oldStroke = context.t1y_1.v1t();
    context.t1y_1.l1t(DrawModule_getInstance().v29_1.j1z('edit.snap.highlight.color'));
    context.t1y_1.o1t(DrawModule_getInstance().v29_1.k1z('edit.snap.highlight.stroke'));
    var begin = this.s4k_1.z4k_1.f1o().q24(new Point2D(this.p4k_1, 0.0));
    context.t1y_1.c1u(numberToInt(begin.in_1), 0, numberToInt(begin.in_1), this.s4k_1.z4k_1.f1o().r1b());
    context.t1y_1.l1t(oldColor);
    context.t1y_1.o1t(oldStroke);
  };
  protoOf(SnapHighlightX).eo = function (x, y) {
    return false;
  };
  protoOf(SnapHighlightX).d4l = function (x) {
    var lineWidth = DrawModule_getInstance().v29_1.k1z('edit.snap.highlight.stroke').p1t_1;
    this.s1z();
    this.p4k_1 = x;
    this.r4k_1.s1b(this.p4k_1 - lineWidth / 2, this.s4k_1.z4k_1.f1o().m24(0.0), lineWidth, this.s4k_1.z4k_1.f1o().m24(this.s4k_1.z4k_1.f1o().r1b()) - this.s4k_1.z4k_1.f1o().m24(0.0));
    this.s1z();
  };
  function SnapHighlightY($outer) {
    this.k4l_1 = $outer;
    AbstractDrawable.call(this);
    this.h4l_1 = 0;
    this.i4l_1 = null;
    this.j4l_1 = new Rectangle2D();
  }
  protoOf(SnapHighlightY).y2a = function (_set____db54di) {
    this.i4l_1 = _set____db54di;
  };
  protoOf(SnapHighlightY).do = function () {
    return this.j4l_1;
  };
  protoOf(SnapHighlightY).r1z = function (context) {
    var oldColor = context.t1y_1.m1t();
    var oldStroke = context.t1y_1.v1t();
    context.t1y_1.l1t(DrawModule_getInstance().v29_1.j1z('edit.snap.highlight.color'));
    context.t1y_1.o1t(DrawModule_getInstance().v29_1.k1z('edit.snap.highlight.stroke'));
    var begin = this.k4l_1.z4k_1.f1o().q24(new Point2D(0.0, this.h4l_1));
    context.t1y_1.c1u(0, numberToInt(begin.jn_1), this.k4l_1.z4k_1.f1o().p1b(), numberToInt(begin.jn_1));
    context.t1y_1.l1t(oldColor);
    context.t1y_1.o1t(oldStroke);
  };
  protoOf(SnapHighlightY).eo = function (x, y) {
    return false;
  };
  protoOf(SnapHighlightY).l4l = function (y) {
    var lineWidth = DrawModule_getInstance().v29_1.k1z('edit.snap.highlight.stroke').p1t_1;
    this.s1z();
    this.h4l_1 = y;
    this.j4l_1.s1b(this.k4l_1.z4k_1.f1o().l24(0.0), this.h4l_1 - lineWidth / 2, this.k4l_1.z4k_1.f1o().l24(this.k4l_1.z4k_1.f1o().p1b()) - this.k4l_1.z4k_1.f1o().l24(0.0), lineWidth);
    this.s1z();
  };
  function ComponentSnapper(editor) {
    Companion_getInstance_55();
    AbstractSnapper.call(this, BaseModule_getInstance().yo_1.st('edit.componentSnap.enabled', false));
    this.z4k_1 = editor;
    this.a4l_1 = null;
    this.b4l_1 = null;
    this.c4l_1 = Companion_getInstance_55().l4k_1;
  }
  protoOf(ComponentSnapper).do = function () {
    return this.c4l_1;
  };
  protoOf(ComponentSnapper).r1z = function (context) {
  };
  protoOf(ComponentSnapper).eo = function (x, y) {
    return false;
  };
  protoOf(ComponentSnapper).q3j = function () {
    return protoOf(AbstractSnapper).q3j.call(this);
  };
  protoOf(ComponentSnapper).c4k = function (initSnappableX, initDx) {
    var minSnapDX = 1.7976931348623157E308;
    var minSnapX = 1.7976931348623157E308;
    var otherSnappableX;
    var dx;
    var minSnappable = null;
    var iter = this.z4k_1.e3b().n20();
    $l$loop: while (iter.j()) {
      var comp = iter.k();
      if (this.z4k_1.f1o().f3b().l3d(comp)) {
        continue $l$loop;
      }
      otherSnappableX = comp.t3a();
      var inductionVariable = 0;
      var last = otherSnappableX.length - 1 | 0;
      if (inductionVariable <= last)
        $l$loop_1: do {
          var i = inductionVariable;
          inductionVariable = inductionVariable + 1 | 0;
          if (!initSnappableX.c3e(otherSnappableX[i]) || !otherSnappableX[i].c3e(initSnappableX)) {
            continue $l$loop_1;
          }
          if (otherSnappableX[i].z19() < initDx + initSnappableX.z19() - 15.0 || otherSnappableX[i].z19() > initDx + initSnappableX.z19() + 15.0) {
            continue $l$loop_1;
          }
          dx = otherSnappableX[i].z19() - (initDx + initSnappableX.z19());
          // Inline function 'kotlin.math.abs' call
          var tmp = Math.abs(dx);
          // Inline function 'kotlin.math.abs' call
          var x = minSnapDX;
          if (tmp < Math.abs(x)) {
            minSnapDX = dx;
            minSnapX = otherSnappableX[i].z19();
            minSnappable = comp;
          }
        }
         while (inductionVariable <= last);
    }
    var tmp0_safe_receiver = minSnappable;
    var tmp_0;
    if (tmp0_safe_receiver == null) {
      tmp_0 = null;
    } else {
      // Inline function 'kotlin.let' call
      tmp_0 = new DoSnapResult(minSnapX, tmp0_safe_receiver);
    }
    return tmp_0;
  };
  protoOf(ComponentSnapper).d4k = function (initSnappableY, initDy) {
    var minSnapDY = 1.7976931348623157E308;
    var minSnapY = 1.7976931348623157E308;
    var otherSnappableY;
    var dy;
    var minSnappable = null;
    var iter = this.z4k_1.e3b().n20();
    $l$loop: while (iter.j()) {
      var comp = iter.k();
      if (this.z4k_1.f1o().f3b().l3d(comp)) {
        continue $l$loop;
      }
      otherSnappableY = comp.u3a();
      var inductionVariable = 0;
      var last = otherSnappableY.length - 1 | 0;
      if (inductionVariable <= last)
        $l$loop_1: do {
          var i = inductionVariable;
          inductionVariable = inductionVariable + 1 | 0;
          if (!initSnappableY.e3e(otherSnappableY[i]) && !otherSnappableY[i].e3e(initSnappableY)) {
            continue $l$loop_1;
          }
          if (otherSnappableY[i].a1a() < initDy + initSnappableY.a1a() - 15.0 || otherSnappableY[i].a1a() > initDy + initSnappableY.a1a() + 15.0) {
            continue $l$loop_1;
          }
          dy = otherSnappableY[i].a1a() - (initDy + initSnappableY.a1a());
          // Inline function 'kotlin.math.abs' call
          var tmp = Math.abs(dy);
          // Inline function 'kotlin.math.abs' call
          var x = minSnapDY;
          if (tmp < Math.abs(x)) {
            minSnapDY = dy;
            minSnapY = otherSnappableY[i].a1a();
            minSnappable = comp;
          }
        }
         while (inductionVariable <= last);
    }
    var tmp0_safe_receiver = minSnappable;
    var tmp_0;
    if (tmp0_safe_receiver == null) {
      tmp_0 = null;
    } else {
      // Inline function 'kotlin.let' call
      tmp_0 = new DoSnapResult(minSnapY, tmp0_safe_receiver);
    }
    return tmp_0;
  };
  protoOf(ComponentSnapper).l3e = function (x, y, snappable) {
    _get_LOG__e5r759_10(Companion_getInstance_55()).ol('getSnapHighlightX for ' + x);
    if (!(snappable == null)) {
      var snappableHighlight = snappable.v3a(x, y);
      if (!(snappableHighlight == null)) {
        return snappableHighlight;
      }
    }
    if (this.a4l_1 == null) {
      this.a4l_1 = new SnapHighlightX(this);
    }
    ensureNotNull(this.a4l_1).d4l(x);
    return this.a4l_1;
  };
  protoOf(ComponentSnapper).m3e = function (x, y, snappable) {
    _get_LOG__e5r759_10(Companion_getInstance_55()).ol('getSnapHighlightX for ' + y);
    if (!(snappable == null)) {
      var snappableHighlight = snappable.w3a(x, y);
      if (!(snappableHighlight == null)) {
        return snappableHighlight;
      }
    }
    if (this.b4l_1 == null) {
      this.b4l_1 = new SnapHighlightY(this);
    }
    ensureNotNull(this.b4l_1).l4l(y);
    return this.b4l_1;
  };
  function Companion_46() {
    Companion_instance_51 = this;
    this.m4l_1 = 'dot';
    this.n4l_1 = logger(getKClass(DottedGridPainter));
  }
  var Companion_instance_51;
  function Companion_getInstance_56() {
    if (Companion_instance_51 == null)
      new Companion_46();
    return Companion_instance_51;
  }
  function DottedGridPainter(styleProvider) {
    Companion_getInstance_56();
    this.o4l_1 = styleProvider;
    this.p4l_1 = 10.0;
    this.q4l_1 = 10.0;
    this.r4l_1 = null;
  }
  protoOf(DottedGridPainter).s4l = function (_set____db54di) {
    this.p4l_1 = _set____db54di;
  };
  protoOf(DottedGridPainter).t4l = function (_set____db54di) {
    this.q4l_1 = _set____db54di;
  };
  protoOf(DottedGridPainter).y2a = function (_set____db54di) {
    this.r4l_1 = _set____db54di;
  };
  protoOf(DottedGridPainter).u4l = function (context, rect) {
    var oldColor = context.t1y_1.m1t();
    context.t1y_1.l1t(this.o4l_1.p1x(Companion_getInstance_0().n1x_1).m1t().h1x_1);
    var dx = this.p4l_1 * ensureNotNull(this.r4l_1).u23_1;
    var dy = this.q4l_1 * ensureNotNull(this.r4l_1).u23_1;
    var tmp = ensureNotNull(this.r4l_1).t23_1;
    var tmp_0 = this.p4l_1;
    // Inline function 'kotlin.math.floor' call
    var x = ensureNotNull(this.r4l_1).t23_1.l24(rect.e1h_1) / this.p4l_1;
    var tmp_1 = tmp_0 * Math.floor(x);
    var tmp_2 = this.q4l_1;
    // Inline function 'kotlin.math.floor' call
    var x_0 = ensureNotNull(this.r4l_1).t23_1.m24(rect.f1h_1) / this.q4l_1;
    var tmp$ret$1 = Math.floor(x_0);
    var low = tmp.q24(new Point2D(tmp_1, tmp_2 * tmp$ret$1));
    var tmp_3 = ensureNotNull(this.r4l_1).t23_1;
    var tmp_4 = this.p4l_1;
    // Inline function 'kotlin.math.ceil' call
    var x_1 = ensureNotNull(this.r4l_1).t23_1.l24(rect.l1c()) / this.p4l_1;
    var tmp_5 = tmp_4 * Math.ceil(x_1);
    var tmp_6 = this.q4l_1;
    // Inline function 'kotlin.math.ceil' call
    var x_2 = ensureNotNull(this.r4l_1).t23_1.m24(rect.m1c()) / this.q4l_1;
    var tmp$ret$3 = Math.ceil(x_2);
    var high = tmp_3.q24(new Point2D(tmp_5, tmp_6 * tmp$ret$3));
    var x_3 = low.in_1;
    while (x_3 <= high.in_1) {
      var y = low.jn_1;
      while (y <= high.jn_1) {
        context.t1y_1.s1u(numberToInt(x_3), numberToInt(y));
        y = y + dy;
      }
      x_3 = x_3 + dx;
    }
    context.t1y_1.l1t(oldColor);
  };
  function fillProperties_2($this, properties) {
    properties.ct('edit.grid.distance.default', 10);
    properties.ct('edit.grid.distance.min', 8);
    properties.ct('edit.grid.paintFactor.default', 2);
    properties.ct('edit.snap.highlight.color', Companion_getInstance_3().u1s_1);
    properties.ct('edit.snap.highlight.stroke', new Stroke(0.5));
  }
  function EditSnapModule() {
    EditSnapModule_instance = this;
    AbstractModule.call(this);
  }
  protoOf(EditSnapModule).ro = function () {
    fillProperties_2(this, BaseModule_getInstance().xo_1);
  };
  var EditSnapModule_instance;
  function EditSnapModule_getInstance() {
    if (EditSnapModule_instance == null)
      new EditSnapModule();
    return EditSnapModule_instance;
  }
  function _get_LOG__e5r759_11($this) {
    var tmp0 = $this.w4l_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('LOG', 1, tmp, GridImpl$Companion$_get_LOG_$ref_bqzgwq(), null);
    return tmp0.j2();
  }
  function GridImpl$Companion$_get_LOG_$ref_bqzgwq() {
    return function (p0) {
      return _get_LOG__e5r759_11(p0);
    };
  }
  function Companion_47() {
    Companion_instance_52 = this;
    this.w4l_1 = logger(getKClass(GridImpl));
  }
  var Companion_instance_52;
  function Companion_getInstance_57() {
    if (Companion_instance_52 == null)
      new Companion_47();
    return Companion_instance_52;
  }
  function _get_configuredGridPainter__gh08eu($this) {
    return GridPainterRegistry_getInstance().nb(BaseModule_getInstance().xo_1.ht('edit.grid.painter'))($this.d4m_1);
  }
  function snapValue($this, d) {
    var q = d / $this.z3j();
    // Inline function 'kotlin.math.floor' call
    var floor = Math.floor(q);
    var ceil = floor + 1;
    if (q - floor < ceil - q) {
      return floor * $this.z3j();
    }
    return ceil * $this.z3j();
  }
  function updateGridPainterProperties($this) {
    $this.g4m_1.s4l($this.z3j() * $this.o4m());
    $this.g4m_1.t4l($this.z3j() * $this.o4m());
    $this.g4m_1.y2a($this.l4m_1);
  }
  function GridImpl$preferencesHandler$lambda(this$0) {
    return function (it) {
      this$0.p4m(_get_configuredGridPainter__gh08eu(this$0));
      updateGridPainterProperties(this$0);
      this$0.s1z();
      this$0.c2a();
      return Unit_instance;
    };
  }
  function GridImpl$snappableXFilter$lambda(i, _unused_var__etf5q3) {
    return i === 0;
  }
  function GridImpl$snappableYFilter$lambda(i, _unused_var__etf5q3) {
    return i === 0;
  }
  function GridImpl(styleProvider, chosenDistance, chosenPaintFactor, eventBus) {
    Companion_getInstance_57();
    styleProvider = styleProvider === VOID ? Companion_getInstance_6().x2r_1 : styleProvider;
    chosenDistance = chosenDistance === VOID ? null : chosenDistance;
    chosenPaintFactor = chosenPaintFactor === VOID ? null : chosenPaintFactor;
    eventBus = eventBus === VOID ? BaseModule_getInstance().zo_1 : eventBus;
    AbstractSnapper.call(this, BaseModule_getInstance().yo_1.st('edit.grid.snapEnabled', true));
    this.d4m_1 = styleProvider;
    this.e4m_1 = eventBus;
    this.f4m_1 = new Rectangle2D();
    this.g4m_1 = _get_configuredGridPainter__gh08eu(this);
    this.h4m_1 = chosenPaintFactor;
    this.i4m_1 = chosenDistance;
    var tmp = this;
    tmp.j4m_1 = GridImpl$preferencesHandler$lambda(this);
    _get_LOG__e5r759_11(Companion_getInstance_57()).il('Snap to grid enabled=' + BaseModule_getInstance().yo_1.st('edit.grid.snapEnabled', true));
    this.e4m_1.j17(getKClass(PreferencesChangedEvent), this.j4m_1);
    updateGridPainterProperties(this);
    this.k4m_1 = null;
    this.l4m_1 = null;
    var tmp_0 = this;
    tmp_0.m4m_1 = GridImpl$snappableXFilter$lambda;
    var tmp_1 = this;
    tmp_1.n4m_1 = GridImpl$snappableYFilter$lambda;
  }
  protoOf(GridImpl).p4m = function (value) {
    if (!equals(this.g4m_1, value)) {
      this.s1z();
      this.g4m_1 = value;
      updateGridPainterProperties(this);
      this.s1z();
      this.u1z();
    }
  };
  protoOf(GridImpl).o4m = function () {
    var tmp0_elvis_lhs = this.h4m_1;
    return tmp0_elvis_lhs == null ? BaseModule_getInstance().xo_1.it('edit.grid.paintFactor.default') : tmp0_elvis_lhs;
  };
  protoOf(GridImpl).z3j = function () {
    var tmp0_elvis_lhs = this.i4m_1;
    return tmp0_elvis_lhs == null ? BaseModule_getInstance().xo_1.it('edit.grid.distance.default') : tmp0_elvis_lhs;
  };
  protoOf(GridImpl).es = function () {
    protoOf(AbstractSnapper).es.call(this);
    this.e4m_1.k17(getKClass(PreferencesChangedEvent), this.j4m_1);
  };
  protoOf(GridImpl).q4m = function (value) {
    if (value == null) {
      throw IllegalArgumentException_init_$Create$('view must not be null');
    }
    this.k4m_1 = value;
    this.y2a(ensureNotNull(this.k4m_1).r23());
  };
  protoOf(GridImpl).y2a = function (value) {
    this.l4m_1 = value;
    this.s1z();
    updateGridPainterProperties(this);
    this.s1z();
  };
  protoOf(GridImpl).do = function () {
    if (this.k4m_1 == null) {
      return new Rectangle2D();
    }
    return new Rectangle2D(0.0, 0.0, ensureNotNull(this.k4m_1).p1b(), ensureNotNull(this.k4m_1).r1b());
  };
  protoOf(GridImpl).eo = function (x, y) {
    return true;
  };
  protoOf(GridImpl).r1z = function (context) {
    if (ensureNotNull(this.l4m_1).u23_1 * this.z3j() * this.o4m() < BaseModule_getInstance().xo_1.it('edit.grid.distance.min')) {
      return Unit_instance;
    }
    if (context.t1y_1.g1t()) {
      context.t1y_1.w1u(this.f4m_1);
      this.g4m_1.u4l(context, this.f4m_1);
    } else {
      if (!(this.k4m_1 == null)) {
        this.g4m_1.u4l(context, Rectangle2D_init_$Create$_0(0, 0, ensureNotNull(this.k4m_1).p1b(), ensureNotNull(this.k4m_1).r1b()));
      }
    }
  };
  protoOf(GridImpl).q3j = function () {
    return protoOf(AbstractSnapper).q3j.call(this);
  };
  protoOf(GridImpl).c4k = function (initSnappableX, initDx) {
    return new DoSnapResult(snapValue(this, initSnappableX.z19() + initDx), null);
  };
  protoOf(GridImpl).d4k = function (initSnappableY, initDy) {
    return new DoSnapResult(snapValue(this, initSnappableY.a1a() + initDy), null);
  };
  protoOf(GridImpl).e4k = function () {
    return this.m4m_1;
  };
  protoOf(GridImpl).f4k = function () {
    return this.n4m_1;
  };
  function Companion_48() {
    this.r4m_1 = 'line';
  }
  var Companion_instance_53;
  function Companion_getInstance_58() {
    return Companion_instance_53;
  }
  function LineGridPainter(styleProvider) {
    this.s4m_1 = styleProvider;
    this.t4m_1 = 10.0;
    this.u4m_1 = 10.0;
    this.v4m_1 = null;
  }
  protoOf(LineGridPainter).s4l = function (_set____db54di) {
    this.t4m_1 = _set____db54di;
  };
  protoOf(LineGridPainter).t4l = function (_set____db54di) {
    this.u4m_1 = _set____db54di;
  };
  protoOf(LineGridPainter).y2a = function (_set____db54di) {
    this.v4m_1 = _set____db54di;
  };
  protoOf(LineGridPainter).u4l = function (context, rect) {
    var oldColor = context.t1y_1.m1t();
    context.t1y_1.l1t(this.s4m_1.p1x(Companion_getInstance_0().n1x_1).m1t().h1x_1);
    var dx = this.t4m_1 * ensureNotNull(this.v4m_1).u23_1;
    var dy = this.u4m_1 * ensureNotNull(this.v4m_1).u23_1;
    var tmp = ensureNotNull(this.v4m_1).t23_1;
    var tmp_0 = this.t4m_1;
    // Inline function 'kotlin.math.floor' call
    var x = ensureNotNull(this.v4m_1).t23_1.l24(rect.e1h_1) / this.t4m_1;
    var tmp_1 = tmp_0 * Math.floor(x);
    var tmp_2 = this.u4m_1;
    // Inline function 'kotlin.math.floor' call
    var x_0 = ensureNotNull(this.v4m_1).t23_1.m24(rect.f1h_1) / this.u4m_1;
    var tmp$ret$1 = Math.floor(x_0);
    var low = tmp.q24(new Point2D(tmp_1, tmp_2 * tmp$ret$1));
    var tmp_3 = ensureNotNull(this.v4m_1).t23_1;
    var tmp_4 = this.t4m_1;
    // Inline function 'kotlin.math.ceil' call
    var x_1 = ensureNotNull(this.v4m_1).t23_1.l24(rect.l1c()) / this.t4m_1;
    var tmp_5 = tmp_4 * Math.ceil(x_1);
    var tmp_6 = this.u4m_1;
    // Inline function 'kotlin.math.ceil' call
    var x_2 = ensureNotNull(this.v4m_1).t23_1.m24(rect.m1c()) / this.u4m_1;
    var tmp$ret$3 = Math.ceil(x_2);
    var high = tmp_3.q24(new Point2D(tmp_5, tmp_6 * tmp$ret$3));
    var x_3 = low.in_1;
    while (x_3 <= high.in_1) {
      context.t1y_1.d1u(x_3, low.jn_1, x_3, high.jn_1);
      x_3 = x_3 + dx;
    }
    var y = low.jn_1;
    while (y <= high.jn_1) {
      context.t1y_1.d1u(low.in_1, y, high.in_1, y);
      y = y + dy;
    }
    context.t1y_1.l1t(oldColor);
  };
  function MultiComponentSnappable(components) {
    this.w4m_1 = toList(components);
  }
  protoOf(MultiComponentSnappable).t3a = function () {
    // Inline function 'kotlin.collections.mutableListOf' call
    var result = ArrayList_init_$Create$_0();
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = this.w4m_1.i();
    while (_iterator__ex2g4s.j()) {
      var element = _iterator__ex2g4s.k();
      addAll(result, element.t3a());
    }
    // Inline function 'kotlin.collections.toTypedArray' call
    return copyToArray(result);
  };
  protoOf(MultiComponentSnappable).u3a = function () {
    // Inline function 'kotlin.collections.mutableListOf' call
    var result = ArrayList_init_$Create$_0();
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = this.w4m_1.i();
    while (_iterator__ex2g4s.j()) {
      var element = _iterator__ex2g4s.k();
      addAll(result, element.u3a());
    }
    // Inline function 'kotlin.collections.toTypedArray' call
    return copyToArray(result);
  };
  function _get_LOG__e5r759_12($this) {
    var tmp0 = $this.x4m_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('LOG', 1, tmp, SnapManagerImpl$Companion$_get_LOG_$ref_xwqfj7(), null);
    return tmp0.j2();
  }
  function SnapManagerImpl$Companion$_get_LOG_$ref_xwqfj7() {
    return function (p0) {
      return _get_LOG__e5r759_12(p0);
    };
  }
  function SnapManagerImpl_init_$Init$(editor, $this) {
    SnapManagerImpl.call($this, editor, BaseModule_getInstance().zo_1);
    return $this;
  }
  function SnapManagerImpl_init_$Create$(editor) {
    return SnapManagerImpl_init_$Init$(editor, objectCreate(protoOf(SnapManagerImpl)));
  }
  function Companion_49() {
    Companion_instance_54 = this;
    this.x4m_1 = logger(getKClass(SnapManagerImpl));
    this.y4m_1 = Companion_getInstance().g1a_1;
  }
  var Companion_instance_54;
  function Companion_getInstance_59() {
    if (Companion_instance_54 == null)
      new Companion_49();
    return Companion_instance_54;
  }
  function highlightSnapX($this, y) {
    var newHighlightX = null;
    if ($this.b4n_1.r3d_1) {
      newHighlightX = ensureNotNull($this.b4n_1.t3d_1).l3e($this.b4n_1.n3d_1, $this.b4n_1.s3d_1 ? $this.b4n_1.o3d_1 : y, $this.b4n_1.v3d_1);
    }
    if (!($this.c4n_1 == null) && (newHighlightX == null || !(newHighlightX === $this.c4n_1))) {
      $this.z4m_1.f1o().i3b().m20(ensureNotNull($this.c4n_1));
    }
    if (!(newHighlightX == null) && $this.b4n_1.r3d_1) {
      _get_LOG__e5r759_12(Companion_getInstance_59()).ol('Highlight x coordinate at ' + $this.b4n_1.n3d_1);
      $this.z4m_1.f1o().i3b().l20(newHighlightX);
    }
    $this.c4n_1 = newHighlightX;
  }
  function highlightSnapY($this, x) {
    var newHighlightY = null;
    if ($this.b4n_1.s3d_1) {
      newHighlightY = ensureNotNull($this.b4n_1.u3d_1).m3e($this.b4n_1.r3d_1 ? $this.b4n_1.n3d_1 : x, $this.b4n_1.o3d_1, $this.b4n_1.w3d_1);
    }
    if (!($this.d4n_1 == null) && (newHighlightY == null || !(newHighlightY === $this.d4n_1))) {
      $this.z4m_1.f1o().i3b().m20(ensureNotNull($this.d4n_1));
    }
    if (!(newHighlightY == null) && $this.b4n_1.s3d_1) {
      _get_LOG__e5r759_12(Companion_getInstance_59()).ol('Highlight y coordinate at ' + $this.b4n_1.o3d_1);
      $this.z4m_1.f1o().i3b().l20(newHighlightY);
    }
    $this.d4n_1 = newHighlightY;
  }
  function removeAllHighlights($this) {
    var removed = false;
    if ($this.c4n_1 == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      _get_LOG__e5r759_12(Companion_getInstance_59()).ol('removing highlightX from view');
      $this.z4m_1.f1o().i3b().m20(ensureNotNull($this.c4n_1));
      removed = true;
      $this.c4n_1 = null;
    }
    if ($this.d4n_1 == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      _get_LOG__e5r759_12(Companion_getInstance_59()).ol('removing highlightY from view');
      $this.z4m_1.f1o().i3b().m20(ensureNotNull($this.d4n_1));
      removed = true;
      $this.d4n_1 = null;
    }
    if (removed) {
      $this.z4m_1.f1o().i3b().u1z();
    }
  }
  function SnapManagerImpl$mouseListener$1(this$0) {
    this.i4n_1 = this$0;
    MouseAdapter.call(this);
  }
  protoOf(SnapManagerImpl$mouseListener$1).t1a = function (e) {
    removeAllHighlights(this.i4n_1);
  };
  function SnapManagerImpl$viewCanvasListener$1(this$0) {
    this.j4n_1 = this$0;
  }
  protoOf(SnapManagerImpl$viewCanvasListener$1).propertyChanged = function (e) {
    if (e.name === 'PROP_CANVAS') {
      this.j4n_1.z4m_1.f1o().b1y(this.j4n_1.e4n_1);
    }
  };
  function SnapManagerImpl$lambda(this$0) {
    return function (it) {
      removeAllHighlights(this$0);
      return Unit_instance;
    };
  }
  function SnapManagerImpl(editor, eventBus) {
    Companion_getInstance_59();
    this.z4m_1 = editor;
    var tmp = this;
    // Inline function 'kotlin.collections.mutableListOf' call
    tmp.a4n_1 = ArrayList_init_$Create$_0();
    this.b4n_1 = new SnapResult();
    this.c4n_1 = null;
    this.d4n_1 = null;
    var tmp_0 = this;
    tmp_0.e4n_1 = new SnapManagerImpl$mouseListener$1(this);
    var tmp_1 = this;
    tmp_1.f4n_1 = new SnapManagerImpl$viewCanvasListener$1(this);
    this.z4m_1.f1o().l1y(this.f4n_1);
    var tmp_2 = getKClass(DropEvent);
    eventBus.j17(tmp_2, SnapManagerImpl$lambda(this));
    this.g4n_1 = true;
    this.h4n_1 = true;
  }
  protoOf(SnapManagerImpl).q3j = function () {
    return this.g4n_1;
  };
  protoOf(SnapManagerImpl).p3l = function (snapper) {
    if (!this.a4n_1.n(snapper)) {
      _get_LOG__e5r759_12(Companion_getInstance_59()).ol("adding snapper '" + System_getInstance().wl(snapper) + "'");
      this.a4n_1.h(snapper);
    }
  };
  protoOf(SnapManagerImpl).d43 = function (x, y) {
    if (!this.g4n_1) {
      return Companion_getInstance_59().y4m_1;
    }
    var snapX = x;
    var snapY = y;
    var index = 0;
    var done = false;
    this.b4n_1.bu();
    while (!done && index < this.a4n_1.o()) {
      if (this.b4n_1.r3d_1 && this.b4n_1.s3d_1) {
        done = true;
      } else if (!this.b4n_1.r3d_1 && !this.b4n_1.s3d_1) {
        snapX = snapX + this.b4n_1.p3d_1;
        snapY = snapY + this.b4n_1.q3d_1;
        this.a4n_1.l(index).f3e(snapX, snapY, this.b4n_1);
      } else if (!this.b4n_1.r3d_1) {
        snapX = snapX + this.b4n_1.p3d_1;
        this.a4n_1.l(index).g3e(snapX, this.b4n_1);
      } else if (!this.b4n_1.s3d_1) {
        snapY = snapY + this.b4n_1.q3d_1;
        this.a4n_1.l(index).h3e(snapY, this.b4n_1);
      }
      index = index + 1 | 0;
    }
    index = index - 2 | 0;
    while (index >= 0) {
      snapX = x + this.b4n_1.p3d_1;
      snapY = y + this.b4n_1.q3d_1;
      this.a4n_1.l(index).f3e(snapX, snapY, this.b4n_1);
      index = index - 1 | 0;
    }
    if (this.h4n_1) {
      highlightSnapX(this, y);
      highlightSnapY(this, x);
      this.z4m_1.f1o().i3b().u1z();
    }
    return new Point2D(this.b4n_1.p3d_1, this.b4n_1.q3d_1);
  };
  protoOf(SnapManagerImpl).k4n = function (x, y) {
    if (!this.g4n_1) {
      return 0.0;
    }
    var snapX = x;
    var index = 0;
    var done = false;
    this.b4n_1.bu();
    while (!done && index < this.a4n_1.o()) {
      var snapper = this.a4n_1.l(index);
      if (this.b4n_1.r3d_1) {
        done = true;
      } else {
        snapX = snapX + this.b4n_1.p3d_1;
        snapper.g3e(snapX, this.b4n_1);
      }
      index = index + 1 | 0;
    }
    snapX = x;
    index = index - 2 | 0;
    while (index >= 0) {
      var snapper_0 = this.a4n_1.l(index);
      snapX = snapX + this.b4n_1.p3d_1;
      snapper_0.g3e(snapX, this.b4n_1);
      index = index - 1 | 0;
    }
    if (this.h4n_1) {
      highlightSnapX(this, y);
      this.z4m_1.f1o().i3b().u1z();
    }
    return this.b4n_1.p3d_1;
  };
  protoOf(SnapManagerImpl).l4n = function (x, y) {
    if (!this.g4n_1) {
      return 0.0;
    }
    var snapY = y;
    var index = 0;
    var done = false;
    this.b4n_1.bu();
    while (!done && index < this.a4n_1.o()) {
      var snapper = this.a4n_1.l(index);
      if (this.b4n_1.s3d_1) {
        done = true;
      } else {
        snapY = snapY + this.b4n_1.q3d_1;
        snapper.h3e(snapY, this.b4n_1);
      }
      index = index + 1 | 0;
    }
    snapY = y;
    index = index - 2 | 0;
    while (index >= 0) {
      var snapper_0 = this.a4n_1.l(index);
      snapY = snapY + this.b4n_1.q3d_1;
      snapper_0.h3e(snapY, this.b4n_1);
      index = index - 1 | 0;
    }
    if (this.h4n_1) {
      highlightSnapY(this, x);
      this.z4m_1.f1o().i3b().u1z();
    }
    return this.b4n_1.q3d_1;
  };
  protoOf(SnapManagerImpl).p3j = function (snappable, dx, dy) {
    if (!this.g4n_1) {
      return Companion_getInstance().g1a_1;
    }
    var snapDX = dx;
    var snapDY = dy;
    var index = 0;
    var done = false;
    this.b4n_1.bu();
    while (!done && index < this.a4n_1.o()) {
      var snapper = this.a4n_1.l(index);
      if (this.b4n_1.r3d_1 && this.b4n_1.s3d_1) {
        done = true;
      } else if (!this.b4n_1.r3d_1 && !this.b4n_1.s3d_1) {
        snapDX = snapDX + this.b4n_1.p3d_1;
        snapDY = snapDY + this.b4n_1.q3d_1;
        snapper.i3e(snappable, snapDX, snapDY, this.b4n_1);
      } else if (!this.b4n_1.r3d_1) {
        snapDX = snapDX + this.b4n_1.p3d_1;
        snapper.j3e(snappable, snapDX, this.b4n_1);
      } else if (!this.b4n_1.s3d_1) {
        snapDY = snapDY + this.b4n_1.q3d_1;
        snapper.k3e(snappable, snapDY, this.b4n_1);
      }
      index = index + 1 | 0;
    }
    index = index - 2 | 0;
    while (index >= 0) {
      var snapper_0 = this.a4n_1.l(index);
      snapDX = dx + this.b4n_1.p3d_1;
      snapDY = dy + this.b4n_1.q3d_1;
      snapper_0.i3e(snappable, snapDX, snapDY, this.b4n_1);
      index = index - 1 | 0;
    }
    if (this.h4n_1) {
      highlightSnapX(this, 0.0);
      highlightSnapY(this, 0.0);
      this.z4m_1.f1o().i3b().u1z();
    }
    return new Point2D(this.b4n_1.p3d_1, this.b4n_1.q3d_1);
  };
  protoOf(SnapManagerImpl).nc = function () {
    removeAllHighlights(this);
  };
  function Companion_50() {
    Companion_instance_55 = this;
    this.n3n_1 = new EditStyleType('selection', 'edit.styleType.selection.name', true);
    this.o3n_1 = new EditStyleType('highlight', 'edit.styleType.highlight.name', true);
    this.p3n_1 = new EditStyleType('message-info', 'edit.styleType.message-info.name', true);
    this.q3n_1 = new EditStyleType('message-error', 'edit.styleType.message-error.name', true);
  }
  var Companion_instance_55;
  function Companion_getInstance_60() {
    if (Companion_instance_55 == null)
      new Companion_50();
    return Companion_instance_55;
  }
  function EditStyleType(name, descriptionKey, isSystem, isBackdrop) {
    Companion_getInstance_60();
    isSystem = isSystem === VOID ? false : isSystem;
    isBackdrop = isBackdrop === VOID ? false : isBackdrop;
    StyleType.call(this, name, descriptionKey, isSystem, isBackdrop);
  }
  function Companion_51() {
    Companion_instance_56 = this;
    this.m4n_1 = new CompositeColor(Color_init_$Create$(237, 76, 48), Color_init_$Create$(251, 225, 216), Companion_getInstance_3().n1s_1);
    var tmp = this;
    var tmp0_backgroundColor = Color_init_$Create$(198, 226, 184);
    var tmp1_foregroundColor = Color_init_$Create$(115, 191, 91);
    var tmp2_textColor = Companion_getInstance_3().n1s_1;
    tmp.n4n_1 = new CompositeColor(tmp1_foregroundColor, tmp0_backgroundColor, tmp2_textColor);
    this.o4n_1 = new BasicStyle(new CompositeColor(Companion_getInstance_3().q1s_1, Companion_getInstance_3().o1s_1, Companion_getInstance_3().q1s_1));
    this.p4n_1 = new BasicStyle(new CompositeColor(Companion_getInstance_3().v1s_1, Companion_getInstance_3().v1s_1, Companion_getInstance_3().n1s_1));
    this.q4n_1 = new BasicStyle(new CompositeColor(Companion_getInstance_3().w1s_1, Companion_getInstance_3().w1s_1, Companion_getInstance_3().w1s_1), new Stroke(0.5));
    this.r4n_1 = new BasicStyle(this.m4n_1);
    this.s4n_1 = new BasicStyle(this.n4n_1);
  }
  var Companion_instance_56;
  function Companion_getInstance_61() {
    if (Companion_instance_56 == null)
      new Companion_51();
    return Companion_instance_56;
  }
  function EditTheme(name, dark, referenceColorSequenceProvider, referenceColors, predefinedColors, background, text, figure, annotation, tooltip, shadow, hover, selection, highlight, snap, messageInfo, messageError) {
    Companion_getInstance_61();
    name = name === VOID ? 'default' : name;
    dark = dark === VOID ? false : dark;
    referenceColorSequenceProvider = referenceColorSequenceProvider === VOID ? ReferenceColorSequenceProvider_getInstance() : referenceColorSequenceProvider;
    referenceColors = referenceColors === VOID ? Companion_getInstance_7().i2s_1 : referenceColors;
    predefinedColors = predefinedColors === VOID ? Companion_getInstance_7().j2s_1 : predefinedColors;
    background = background === VOID ? Companion_getInstance_7().b2s_1 : background;
    text = text === VOID ? Companion_getInstance_7().c2s_1 : text;
    figure = figure === VOID ? Companion_getInstance_7().d2s_1 : figure;
    annotation = annotation === VOID ? Companion_getInstance_7().e2s_1 : annotation;
    tooltip = tooltip === VOID ? Companion_getInstance_7().f2s_1 : tooltip;
    shadow = shadow === VOID ? Companion_getInstance_7().g2s_1 : shadow;
    hover = hover === VOID ? Companion_getInstance_7().h2s_1 : hover;
    selection = selection === VOID ? Companion_getInstance_61().o4n_1 : selection;
    highlight = highlight === VOID ? Companion_getInstance_61().p4n_1 : highlight;
    snap = snap === VOID ? Companion_getInstance_61().q4n_1 : snap;
    messageInfo = messageInfo === VOID ? Companion_getInstance_61().s4n_1 : messageInfo;
    messageError = messageError === VOID ? Companion_getInstance_61().r4n_1 : messageError;
    DrawTheme.call(this, name, dark, referenceColorSequenceProvider, referenceColors, predefinedColors, background, text, figure, annotation, tooltip, shadow, hover);
    this.x3x_1 = selection;
    this.y3x_1 = highlight;
    this.z3x_1 = snap;
    this.a3y_1 = messageInfo;
    this.b3y_1 = messageError;
  }
  protoOf(EditTheme).p2s = function (styleRepository, styleOnly) {
    protoOf(DrawTheme).p2s.call(this, styleRepository, styleOnly);
    styleRepository.w2r(Companion_getInstance_60().n3n_1, this.x3x_1);
    styleRepository.w2r(Companion_getInstance_60().o3n_1, this.y3x_1);
    styleRepository.w2r(Companion_getInstance_60().p3n_1, this.a3y_1);
    styleRepository.w2r(Companion_getInstance_60().q3n_1, this.b3y_1);
    if (!styleOnly) {
      BaseModule_getInstance().xo_1.ct('edit.select.rubberband.fill.paint', this.x3x_1.m1t().h1x_1.b2f(32));
      BaseModule_getInstance().xo_1.ct('edit.select.rubberband.stroke.paint', this.x3x_1.m1t().h1x_1);
    }
  };
  function AbstractTool(editor) {
    this.g4j_1 = editor;
  }
  protoOf(AbstractTool).n4j = function (e) {
    return new EditInputEventContext(this.g4j_1, VOID, e);
  };
  protoOf(AbstractTool).m4j = function (e, x, y) {
    return new EditInputEventContext(this.g4j_1, e, VOID, x, y, !this.g4j_1.f1o().b3b());
  };
  protoOf(AbstractTool).p4j = function (component) {
    if (component == null) {
      this.g4j_1.f1o().v1x(Cursor_DEFAULT_getInstance());
    } else {
      this.g4j_1.f1o().v1x(Cursor_MOVE_getInstance());
    }
  };
  function clearPointStatus($this) {
    Status_getInstance().du(StatusType_Small_getInstance(), null);
  }
  function ToolAdapter(editor) {
    AbstractTool.call(this, editor);
  }
  protoOf(ToolAdapter).w2u = function () {
  };
  protoOf(ToolAdapter).x2u = function () {
    clearPointStatus(this);
    Status_getInstance().du(StatusType_Tool_getInstance(), null);
  };
  protoOf(ToolAdapter).n3e = function (e, x, y) {
  };
  protoOf(ToolAdapter).p3e = function (e, x, y) {
  };
  protoOf(ToolAdapter).r3e = function (e, x, y) {
  };
  protoOf(ToolAdapter).t3e = function (e, x, y) {
    this.q4j(x, y);
  };
  protoOf(ToolAdapter).v3e = function (e, x, y) {
  };
  protoOf(ToolAdapter).w19 = function (e) {
  };
  protoOf(ToolAdapter).x19 = function (e) {
  };
  protoOf(ToolAdapter).y19 = function (e) {
  };
  protoOf(ToolAdapter).q4j = function (x, y) {
    Status_getInstance().du(StatusType_Small_getInstance(), '' + numberToInt(x) + ',' + numberToInt(y));
  };
  function ToolLockAction(editor) {
    AbstractAction_init_$Init$('edit.action.toolLock', '/img/lock-24.png', VOID, this);
    this.b4o_1 = editor;
    this.pq(this.b4o_1.h3c());
  }
  protoOf(ToolLockAction).execute = function (event) {
    this.b4o_1.g3c(!this.b4o_1.h3c());
  };
  function Companion_52() {
    Companion_instance_57 = this;
    this.c4o_1 = 'edit.view.AttentionDrawer.duration';
    this.d4o_1 = 'edit.view.AttentionDrawer.maxRadius';
    this.e4o_1 = new Stroke();
  }
  var Companion_instance_57;
  function Companion_getInstance_62() {
    if (Companion_instance_57 == null)
      new Companion_52();
    return Companion_instance_57;
  }
  function container($this, view) {
    return view.j3b();
  }
  function GrowingRing($outer, center, maxRadius, color) {
    this.p4o_1 = $outer;
    AbstractRectangularUnzoomable.call(this, maxRadius, center);
    this.m4o_1 = maxRadius;
    this.n4o_1 = color;
    this.o4o_1 = 0.0;
  }
  protoOf(GrowingRing).l2b = function () {
    return Companion_getInstance_62().e4o_1.p1t_1;
  };
  protoOf(GrowingRing).q4o = function (value) {
    this.o4o_1 = value;
    protoOf(AbstractRectangularUnzoomable).z2b.call(this, this.o4o_1);
    this.u1z();
  };
  protoOf(GrowingRing).r1z = function (context) {
    context.t1y_1.o1t(Companion_getInstance_62().e4o_1);
    context.t1y_1.l1t(this.n4o_1);
    var rect = this.b2c();
    var tmp;
    if (this.o4o_1 < this.m4o_1 * 0.75) {
      tmp = this.o4o_1;
    } else {
      tmp = this.m4o_1 - this.o4o_1;
    }
    var thickness = tmp;
    context.t1y_1.t1u(new Ring2D(rect.e1h_1, rect.f1h_1, rect.g1h_1, rect.h1h_1, thickness));
  };
  function AttentionDrawerImpl$drawAttentionTo$lambda($ring) {
    return function (it) {
      $ring.q4o(it);
      return Unit_instance;
    };
  }
  function AttentionDrawerImpl$drawAttentionTo$1(this$0, $view, $ring) {
    this.r4o_1 = this$0;
    this.s4o_1 = $view;
    this.t4o_1 = $ring;
    AnimationTaskAdapter.call(this);
  }
  protoOf(AttentionDrawerImpl$drawAttentionTo$1).c1p = function (task, canceled) {
    container(this.r4o_1, this.s4o_1).m20(this.t4o_1);
    container(this.r4o_1, this.s4o_1).u1z();
  };
  function AttentionDrawerImpl(properties, color) {
    Companion_getInstance_62();
    properties = properties === VOID ? BaseModule_getInstance().xo_1 : properties;
    color = color === VOID ? properties.lt('edit.view.AttentionDrawer.color') : color;
    this.u4o_1 = properties;
    this.v4o_1 = color;
  }
  protoOf(AttentionDrawerImpl).w4o = function (location, view, animator) {
    var maxRadius = this.u4o_1.jt('edit.view.AttentionDrawer.maxRadius');
    var ring = new GrowingRing(this, location, maxRadius, this.v4o_1);
    var animation = animator.u1p(ring, AttentionDrawerImpl$drawAttentionTo$lambda(ring), new DoubleRange(0.0, maxRadius), this.u4o_1.jt('edit.view.AttentionDrawer.duration'));
    animation.t1o(new AttentionDrawerImpl$drawAttentionTo$1(this, view, ring));
    container(this, view).l20(ring);
    animation.vp();
  };
  function Companion_53() {
    this.x4o_1 = 10.0;
    this.y4o_1 = 10.0;
    this.z4o_1 = 300;
    this.a4p_1 = 600;
  }
  var Companion_instance_58;
  function Companion_getInstance_63() {
    return Companion_instance_58;
  }
  function handle($this, msg) {
    if (!(msg.r3o_1 == null) && !$this.b4p_1.e3b().h20(msg.r3o_1)) {
      return Unit_instance;
    }
    if (msg.r3o_1 == null && !$this.c4p_1) {
      return Unit_instance;
    }
    var tmp;
    if (msg.t3o_1 == null) {
      tmp = Translations_getInstance().zm(msg.s3o_1, []);
    } else {
      tmp = Translations_getInstance().zm(msg.s3o_1, [msg.t3o_1]);
    }
    var text = tmp;
    var messageView = new FlexibleTextView(text, calculateAnchorPoint($this, msg), Direction_SOUTH_getInstance(), VOID, VOID, VOID, determineStyleType($this, msg.q3o_1));
    if (!(msg.r3o_1 == null)) {
      var makeVisibleOffset = getMakeVisibleOffset($this, messageView);
      messageView.f21(makeVisibleOffset.in_1, makeVisibleOffset.jn_1);
    }
    var tmp_0;
    if (msg.r3o_1 == null) {
      tmp_0 = $this.b4p_1.l23();
    } else {
      var tmp_1 = $this.b4p_1.i3b();
      tmp_0 = isInterface(tmp_1, DrawableContainer) ? tmp_1 : THROW_CCE();
    }
    var container = tmp_0;
    container.l20(messageView);
    container.u1z();
    Companion_getInstance_8().c2k(messageView, container, 300, DisplayDuration_instance.b1o(text), 600, $this.e4p_1);
  }
  function calculateAnchorPoint($this, msg) {
    var tmp;
    if (msg.r3o_1 == null) {
      tmp = Point2D_init_$Create$_0($this.b4p_1.p1b() / 2 | 0, $this.b4p_1.r1b() / 2 | 0);
    } else {
      var bbox = msg.r3o_1.do();
      tmp = new Point2D(bbox.h1c(), bbox.m1c() + 10.0);
    }
    return tmp;
  }
  function getMakeVisibleOffset($this, messageView) {
    var bbox = messageView.do();
    var locationView = $this.b4p_1.q24(messageView.f2g_1);
    var minXView = locationView.in_1 - bbox.p1b() / 2;
    var maxXView = locationView.in_1 + bbox.p1b() / 2;
    var minYView = locationView.jn_1;
    var maxYView = locationView.jn_1 + bbox.r1b();
    var tmp;
    if (minXView - 10.0 < 0) {
      // Inline function 'kotlin.math.abs' call
      var x = minXView - 10.0;
      tmp = Math.abs(x);
    } else if (maxXView + 10.0 > $this.b4p_1.p1b()) {
      tmp = -(maxXView + 10.0 - $this.b4p_1.p1b());
    } else {
      tmp = 0.0;
    }
    var dx = tmp;
    var tmp_0;
    if (minYView - 10.0 < 0) {
      // Inline function 'kotlin.math.abs' call
      var x_0 = minYView - 10.0;
      tmp_0 = Math.abs(x_0);
    } else if (maxYView + 10.0 > $this.b4p_1.r1b()) {
      tmp_0 = -(maxYView + 10.0 - $this.b4p_1.r1b());
    } else {
      tmp_0 = 0.0;
    }
    var dy = tmp_0;
    return new Point2D(dx / $this.b4p_1.s23(), dy / $this.b4p_1.s23());
  }
  function determineStyleType($this, msgType) {
    var tmp;
    switch (msgType.l2_1) {
      case 0:
        tmp = Companion_getInstance_60().p3n_1;
        break;
      case 1:
        tmp = Companion_getInstance_60().q3n_1;
        break;
      default:
        noWhenBranchMatchedException();
        break;
    }
    return tmp;
  }
  function ComponentMessageDisplayer$handle$ref(p0) {
    var l = function (_this__u8e3s4) {
      var tmp0 = p0;
      handle(tmp0, _this__u8e3s4);
      return Unit_instance;
    };
    l.callableName = 'handle';
    return l;
  }
  function ComponentMessageDisplayer$handle$ref_0(p0) {
    var l = function (_this__u8e3s4) {
      var tmp0 = p0;
      handle(tmp0, _this__u8e3s4);
      return Unit_instance;
    };
    l.callableName = 'handle';
    return l;
  }
  function ComponentMessageDisplayer(drawingView, displayGlobalMessages, eventBus, animator) {
    eventBus = eventBus === VOID ? BaseModule_getInstance().zo_1 : eventBus;
    animator = animator === VOID ? AnimationModule_getInstance().r1p_1 : animator;
    this.b4p_1 = drawingView;
    this.c4p_1 = displayGlobalMessages;
    this.d4p_1 = eventBus;
    this.e4p_1 = animator;
    var tmp = getKClass(ComponentMessage);
    this.d4p_1.j17(tmp, ComponentMessageDisplayer$handle$ref(this));
  }
  protoOf(ComponentMessageDisplayer).es = function () {
    var tmp = getKClass(ComponentMessage);
    this.d4p_1.k17(tmp, ComponentMessageDisplayer$handle$ref_0(this));
  };
  function DrawingViewContentImpl$BackdropDrawer$draw$lambda(it) {
    return it.r28().q28_1;
  }
  function ComponentRemoveListener($outer) {
    this.f4p_1 = $outer;
    DrawableContainerAdapter.call(this);
  }
  protoOf(ComponentRemoveListener).g4p = function (event) {
    var tmp;
    var tmp_0 = event.h21_1;
    if (isInterface(tmp_0, Component)) {
      var tmp_1 = event.h21_1;
      tmp = this.f4p_1.n4p_1.l3d(isInterface(tmp_1, Component) ? tmp_1 : THROW_CCE());
    } else {
      tmp = false;
    }
    if (tmp) {
      var tmp_2 = event.h21_1;
      this.f4p_1.n4p_1.i3d(isInterface(tmp_2, Component) ? tmp_2 : THROW_CCE());
    }
  };
  protoOf(ComponentRemoveListener).j21 = function (event) {
    return this.g4p(event);
  };
  function BackdropDrawer($outer) {
    this.x4p_1 = $outer;
    AbstractDrawable.call(this);
  }
  protoOf(BackdropDrawer).do = function () {
    return this.x4p_1.i4p_1.do();
  };
  protoOf(BackdropDrawer).r1z = function (context) {
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = this.x4p_1.i4p_1.u20(DrawingViewContentImpl$BackdropDrawer$draw$lambda).i();
    while (_iterator__ex2g4s.j()) {
      var element = _iterator__ex2g4s.k();
      element.r1z(context);
    }
  };
  protoOf(BackdropDrawer).eo = function (x, y) {
    return this.do().eo(x, y);
  };
  function DrawingViewContentImpl(drawingView, drawing, selectionManagerFactory, highlighterFactory) {
    this.h4p_1 = drawingView;
    this.i4p_1 = drawing;
    var tmp = this;
    // Inline function 'kotlin.collections.mutableMapOf' call
    tmp.j4p_1 = LinkedHashMap_init_$Create$();
    var tmp_0 = this;
    // Inline function 'kotlin.collections.mutableMapOf' call
    tmp_0.k4p_1 = LinkedHashMap_init_$Create$();
    this.l4p_1 = new ComponentRemoveListener(this);
    var tmp0 = this.j4p_1;
    var tmp2 = SelectionDrawingStrategy_ABOVE_getInstance();
    // Inline function 'kotlin.collections.set' call
    var value = new DrawableContainerImpl();
    tmp0.y1(tmp2, value);
    var tmp0_0 = this.j4p_1;
    var tmp2_0 = SelectionDrawingStrategy_REPLACE_getInstance();
    // Inline function 'kotlin.collections.set' call
    var value_0 = new DrawableContainerImpl();
    tmp0_0.y1(tmp2_0, value_0);
    var tmp0_1 = this.j4p_1;
    var tmp2_1 = SelectionDrawingStrategy_BELOW_getInstance();
    // Inline function 'kotlin.collections.set' call
    var value_1 = new DrawableContainerImpl();
    tmp0_1.y1(tmp2_1, value_1);
    var tmp0_2 = this.k4p_1;
    var tmp2_2 = SelectionDrawingStrategy_ABOVE_getInstance();
    // Inline function 'kotlin.collections.set' call
    var value_2 = new UnzoomableContainer();
    tmp0_2.y1(tmp2_2, value_2);
    this.i4p_1.a21(this.l4p_1);
    this.m4p_1 = this.h4p_1.q23().a25();
    this.n4p_1 = selectionManagerFactory(this);
    this.o4p_1 = highlighterFactory.r3n(this);
    this.p4p_1 = new DrawableContainerImpl();
    this.q4p_1 = new UnzoomableContainer();
    this.r4p_1 = new DrawableContainerImpl();
    this.s4p_1 = new BackdropDrawer(this);
    this.t4p_1 = new DrawableContainerImpl(VOID, VOID, false);
  }
  protoOf(DrawingViewContentImpl).n3b = function () {
    return this.h4p_1;
  };
  protoOf(DrawingViewContentImpl).e3b = function () {
    return this.i4p_1;
  };
  protoOf(DrawingViewContentImpl).p23 = function (_set____db54di) {
    this.m4p_1 = _set____db54di;
  };
  protoOf(DrawingViewContentImpl).q23 = function () {
    return this.m4p_1;
  };
  protoOf(DrawingViewContentImpl).f3b = function () {
    return this.n4p_1;
  };
  protoOf(DrawingViewContentImpl).g3b = function () {
    return this.o4p_1;
  };
  protoOf(DrawingViewContentImpl).j3b = function () {
    return this.p4p_1;
  };
  protoOf(DrawingViewContentImpl).i3b = function () {
    return this.q4p_1;
  };
  protoOf(DrawingViewContentImpl).o3b = function () {
    return this.r4p_1;
  };
  protoOf(DrawingViewContentImpl).p3b = function () {
    return this.s4p_1;
  };
  protoOf(DrawingViewContentImpl).q3b = function () {
    return this.t4p_1;
  };
  protoOf(DrawingViewContentImpl).r3b = function (selectionModel, strategy) {
    if (isInterface(selectionModel, Unzoomable)) {
      var tmp0_safe_receiver = this.k4p_1.g2(strategy);
      var tmp;
      if (tmp0_safe_receiver == null) {
        tmp = null;
      } else {
        tmp = tmp0_safe_receiver.l20(isInterface(selectionModel, UnzoomableSelectionModel) ? selectionModel : THROW_CCE());
      }
      if (tmp == null)
        throw IllegalArgumentException_init_$Create$('no suitable selection container found');
    } else {
      var tmp2_safe_receiver = this.j4p_1.g2(strategy);
      if ((tmp2_safe_receiver == null ? null : tmp2_safe_receiver.l20(selectionModel)) == null)
        throw IllegalArgumentException_init_$Create$('no suitable selection container found');
    }
  };
  protoOf(DrawingViewContentImpl).s3b = function (selectionModel) {
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = this.j4p_1.c2().i();
    while (_iterator__ex2g4s.j()) {
      var element = _iterator__ex2g4s.k();
      element.m20(selectionModel);
    }
    if (isInterface(selectionModel, UnzoomableSelectionModel)) {
      // Inline function 'kotlin.collections.forEach' call
      var _iterator__ex2g4s_0 = this.k4p_1.c2().i();
      while (_iterator__ex2g4s_0.j()) {
        var element_0 = _iterator__ex2g4s_0.k();
        element_0.m20(selectionModel);
      }
    }
  };
  protoOf(DrawingViewContentImpl).t3b = function () {
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = this.j4p_1.c2().i();
    while (_iterator__ex2g4s.j()) {
      var element = _iterator__ex2g4s.k();
      element.j20();
    }
  };
  protoOf(DrawingViewContentImpl).u3b = function (component) {
    var tmp0 = ensureNotNull(this.j4p_1.g2(SelectionDrawingStrategy_REPLACE_getInstance())).e20();
    var tmp$ret$0;
    $l$block: {
      // Inline function 'kotlin.collections.firstOrNull' call
      var _iterator__ex2g4s = tmp0.i();
      while (_iterator__ex2g4s.j()) {
        var element = _iterator__ex2g4s.k();
        if (element.b3s() === component.n3a()) {
          tmp$ret$0 = element;
          break $l$block;
        }
      }
      tmp$ret$0 = null;
    }
    return tmp$ret$0;
  };
  protoOf(DrawingViewContentImpl).v3b = function (strategy) {
    return this.j4p_1.g2(strategy);
  };
  protoOf(DrawingViewContentImpl).w3b = function (strategy) {
    return this.k4p_1.g2(strategy);
  };
  function _get_LOG__e5r759_13($this) {
    var tmp0 = $this.y4p_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('LOG', 1, tmp, DrawingViewImpl$Companion$_get_LOG_$ref_uhrqmb(), null);
    return tmp0.j2();
  }
  function DrawingViewImpl$Companion$_get_LOG_$ref_uhrqmb() {
    return function (p0) {
      return _get_LOG__e5r759_13(p0);
    };
  }
  function Companion_54() {
    Companion_instance_59 = this;
    this.y4p_1 = logger(getKClass(DrawingViewImpl));
  }
  var Companion_instance_59;
  function Companion_getInstance_64() {
    if (Companion_instance_59 == null)
      new Companion_54();
    return Companion_instance_59;
  }
  function setupContent($this) {
    protoOf(ViewImpl).a30.call($this, $this.i3b());
    protoOf(ViewImpl).a30.call($this, $this.j3b());
    protoOf(ViewImpl).a30.call($this, ensureNotNull($this.g4r_1.v3b(SelectionDrawingStrategy_ABOVE_getInstance())));
    protoOf(ViewImpl).a30.call($this, ensureNotNull($this.g4r_1.w3b(SelectionDrawingStrategy_ABOVE_getInstance())));
    protoOf(ViewImpl).a30.call($this, ensureNotNull($this.g4r_1.v3b(SelectionDrawingStrategy_REPLACE_getInstance())));
    protoOf(ViewImpl).a30.call($this, $this.e3b());
    protoOf(ViewImpl).a30.call($this, ensureNotNull($this.g4r_1.v3b(SelectionDrawingStrategy_BELOW_getInstance())));
    protoOf(ViewImpl).a30.call($this, $this.o3b());
    protoOf(ViewImpl).a30.call($this, $this.g4r_1.p3b());
    protoOf(ViewImpl).a30.call($this, $this.g4r_1.q3b());
  }
  function replaceContent($this, newContent) {
    $this.j24($this.g4r_1.i3b(), newContent.i3b());
    $this.j24($this.g4r_1.j3b(), newContent.j3b());
    $this.j24(ensureNotNull($this.g4r_1.v3b(SelectionDrawingStrategy_ABOVE_getInstance())), ensureNotNull(newContent.v3b(SelectionDrawingStrategy_ABOVE_getInstance())));
    $this.j24(ensureNotNull($this.g4r_1.w3b(SelectionDrawingStrategy_ABOVE_getInstance())), ensureNotNull(newContent.w3b(SelectionDrawingStrategy_ABOVE_getInstance())));
    $this.j24(ensureNotNull($this.g4r_1.v3b(SelectionDrawingStrategy_REPLACE_getInstance())), ensureNotNull(newContent.v3b(SelectionDrawingStrategy_REPLACE_getInstance())));
    $this.j24($this.g4r_1.e3b(), newContent.e3b());
    $this.j24(ensureNotNull($this.g4r_1.v3b(SelectionDrawingStrategy_BELOW_getInstance())), ensureNotNull(newContent.v3b(SelectionDrawingStrategy_BELOW_getInstance())));
    $this.j24($this.g4r_1.o3b(), newContent.o3b());
    $this.j24($this.g4r_1.p3b(), newContent.p3b());
    $this.j24($this.g4r_1.q3b(), newContent.q3b());
    $this.p23(newContent.q23());
    $this.d1x();
  }
  function showGridIfNeeded($this) {
    var gridNeeded = $this.i4r_1 && $this.h4r_1;
    if (gridNeeded) {
      if (!$this.i24($this.j4r_1)) {
        protoOf(ViewImpl).a30.call($this, $this.j4r_1);
      }
    } else {
      protoOf(ViewImpl).b30.call($this, $this.j4r_1);
    }
    $this.d1x();
  }
  function DrawingViewDrawer($outer) {
    this.n4r_1 = $outer;
    DrawableContainerDrawer.call(this);
  }
  protoOf(DrawingViewDrawer).o4r = function (context, drawable) {
    if (this.n4r_1.f3b().l3d(drawable)) {
      var replacingSelectionModel = this.n4r_1.g4r_1.u3b(drawable);
      if (replacingSelectionModel == null) {
        this.k28(drawable, context);
      }
    } else {
      this.k28(drawable, context);
    }
    this.m28(context, drawable);
  };
  protoOf(DrawingViewDrawer).j28 = function (context, drawable) {
    return this.o4r(context, isInterface(drawable, Component) ? drawable : THROW_CCE());
  };
  function DrawingViewImpl$_init_$lambda_5y0iw() {
    return System_getInstance().zl();
  }
  function DrawingViewImpl$_init_$lambda_5y0iw_0(it) {
    return new InvalidatableViewPainter(it);
  }
  function DrawingViewImpl$preferenceChangeHandler$lambda(this$0) {
    return function (it) {
      this$0.i2z();
      this$0.d1x();
      return Unit_instance;
    };
  }
  function DrawingViewImpl$commandEventHandler$lambda(this$0) {
    return function (it) {
      this$0.i2z();
      this$0.d1x();
      return Unit_instance;
    };
  }
  function DrawingViewImpl$createViewContentBounds$lambda(this$0) {
    return function () {
      this$0.l4r_1.w1b(this$0.e3b().do());
      var tmp;
      if (this$0.q3b().n1z()) {
        this$0.l4r_1.x1b(this$0.q3b().do());
        tmp = Unit_instance;
      }
      return this$0.l4r_1;
    };
  }
  function DrawingViewImpl(drawing, transformFactory, applicationContextHolder, displayGlobalMessages, selectionManagerFactory, highlighterFactory, eventBus, viewPainterFactory, editable, name) {
    Companion_getInstance_64();
    var tmp;
    if (transformFactory === VOID) {
      tmp = DrawingViewImpl$_init_$lambda_5y0iw;
    } else {
      tmp = transformFactory;
    }
    transformFactory = tmp;
    applicationContextHolder = applicationContextHolder === VOID ? null : applicationContextHolder;
    displayGlobalMessages = displayGlobalMessages === VOID ? false : displayGlobalMessages;
    selectionManagerFactory = selectionManagerFactory === VOID ? EditSelectModule_getInstance().d3l_1 : selectionManagerFactory;
    highlighterFactory = highlighterFactory === VOID ? EditHighlightModule_getInstance().h3n_1 : highlighterFactory;
    eventBus = eventBus === VOID ? BaseModule_getInstance().zo_1 : eventBus;
    var tmp_0;
    if (viewPainterFactory === VOID) {
      tmp_0 = DrawingViewImpl$_init_$lambda_5y0iw_0;
    } else {
      tmp_0 = viewPainterFactory;
    }
    viewPainterFactory = tmp_0;
    editable = editable === VOID ? true : editable;
    name = name === VOID ? '' : name;
    ViewImpl.call(this, transformFactory, applicationContextHolder, eventBus, name, viewPainterFactory);
    this.a4r_1 = selectionManagerFactory;
    this.b4r_1 = highlighterFactory;
    this.c4r_1 = new DrawingViewDrawer(this);
    this.d4r_1 = new ComponentMessageDisplayer(this, displayGlobalMessages, eventBus);
    var tmp_1 = this;
    tmp_1.e4r_1 = DrawingViewImpl$preferenceChangeHandler$lambda(this);
    var tmp_2 = this;
    tmp_2.f4r_1 = DrawingViewImpl$commandEventHandler$lambda(this);
    this.g4r_1 = this.l3b(drawing);
    this.h4r_1 = editable;
    this.i4r_1 = false;
    this.j4r_1 = new GridImpl();
    this.k4r_1 = SelectionDrawingStrategy_REPLACE_getInstance();
    eventBus.j17(getKClass(PreferencesChangedEvent), this.e4r_1);
    eventBus.j17(getKClass(CommandEvent), this.f4r_1);
    this.l4r_1 = new Rectangle2D();
  }
  protoOf(DrawingViewImpl).q1x = function (value) {
    var firstTime = this.i2y_1 == null;
    protoOf(ViewImpl).q1x.call(this, value);
    if (firstTime) {
      setupContent(this);
      this.j4r_1.q4m(this);
      this.p4r(true);
    }
  };
  protoOf(DrawingViewImpl).c23 = function () {
    return protoOf(ViewImpl).c23.call(this);
  };
  protoOf(DrawingViewImpl).c3b = function (value) {
    if (this.g4r_1 === value) {
      return Unit_instance;
    }
    var oldDrawing = this.g4r_1.e3b();
    replaceContent(this, value);
    this.g4r_1 = value;
    this.g4r_1.e3b().z20(this.c4r_1);
    this.p2z('PROP_DRAWING', oldDrawing, this.g4r_1.e3b());
    this.g4r_1.e3b().s3a(this.h4r_1);
    this.g4r_1.f3b().w2u();
  };
  protoOf(DrawingViewImpl).d3b = function () {
    return this.g4r_1;
  };
  protoOf(DrawingViewImpl).a3b = function (value) {
    if (!(value === this.h4r_1)) {
      _get_LOG__e5r759_13(Companion_getInstance_64()).nl("Setting DrawingView with '" + toString(this.e3b()) + "' to editable=" + value);
      this.h4r_1 = value;
      showGridIfNeeded(this);
      this.p2z('PROP_EDITABLE', !this.h4r_1, this.h4r_1);
      this.g4r_1.e3b().s3a(this.h4r_1);
    }
  };
  protoOf(DrawingViewImpl).b3b = function () {
    return this.h4r_1;
  };
  protoOf(DrawingViewImpl).f3b = function () {
    return this.g4r_1.f3b();
  };
  protoOf(DrawingViewImpl).g3b = function () {
    return this.g4r_1.g3b();
  };
  protoOf(DrawingViewImpl).i3b = function () {
    return this.g4r_1.i3b();
  };
  protoOf(DrawingViewImpl).j3b = function () {
    return this.g4r_1.j3b();
  };
  protoOf(DrawingViewImpl).o3b = function () {
    return this.g4r_1.o3b();
  };
  protoOf(DrawingViewImpl).q3b = function () {
    return this.g4r_1.q3b();
  };
  protoOf(DrawingViewImpl).e3b = function () {
    return this.g4r_1.e3b();
  };
  protoOf(DrawingViewImpl).p4r = function (value) {
    if (!(value === this.i4r_1)) {
      this.i4r_1 = value;
      showGridIfNeeded(this);
      this.d1x();
      this.p2z('PROP_SHOW_GRID', !this.i4r_1, this.i4r_1);
    }
  };
  protoOf(DrawingViewImpl).h3b = function () {
    return this.j4r_1;
  };
  protoOf(DrawingViewImpl).es = function () {
    protoOf(ViewImpl).es.call(this);
    this.z2x_1.k17(getKClass(PreferencesChangedEvent), this.e4r_1);
    this.z2x_1.k17(getKClass(CommandEvent), this.f4r_1);
    this.d4r_1.es();
    this.j4r_1.es();
  };
  protoOf(DrawingViewImpl).k3b = function (drawing, applyDefaultZoomStrategy) {
    if (!(drawing === this.g4r_1.e3b())) {
      this.c3b(this.l3b(drawing));
      if (applyDefaultZoomStrategy) {
        this.f24();
      }
    }
  };
  protoOf(DrawingViewImpl).l3b = function (drawing) {
    return new DrawingViewContentImpl(this, drawing, this.a4r_1, this.b4r_1);
  };
  protoOf(DrawingViewImpl).q4r = function (drawableDrawer) {
    drawableDrawer.s28(this.c4r_1);
    this.c4r_1 = drawableDrawer;
    this.e3b().z20(this.c4r_1);
  };
  protoOf(DrawingViewImpl).m3b = function (component) {
    var tmp0_elvis_lhs = component.p3a();
    return tmp0_elvis_lhs == null ? this.k4r_1 : tmp0_elvis_lhs;
  };
  protoOf(DrawingViewImpl).m2z = function () {
    return new ViewContentBounds(VOID, DrawingViewImpl$createViewContentBounds$lambda(this));
  };
  protoOf(DrawingViewImpl).b30 = function (drawable) {
    throw UnsupportedOperationException_init_$Create$('Clients cannot remove Drawable from DrawingViewImpl');
  };
  protoOf(DrawingViewImpl).a30 = function (drawable) {
    throw UnsupportedOperationException_init_$Create$('Clients cannot add Drawable to DrawingViewImpl');
  };
  //region block: post-declaration
  protoOf(AbstractCommand).r39 = getDetailedDescription;
  protoOf(AbstractCommand).u39 = notifyUndo;
  protoOf(DrawingAppServiceImpl).a3f = move$default;
  protoOf($serializer).yk = typeParametersSerializers;
  protoOf(SourcingCommandManager).b3a = beginTransaction$default;
  protoOf(TransactionCommand).v39 = get_canUndo;
  protoOf(AddCommand).v39 = get_canUndo;
  protoOf(EditorImpl).e3b = get_drawing;
  protoOf(AbstractComponent).q3a = get_isDragManager;
  protoOf(AbstractComponent).r3a = collectSelectBuddies;
  protoOf(AbstractComponent).s3a = notifyEditable;
  protoOf(AbstractComponent).t2h = prepareMoveBy;
  protoOf(AbstractComponent).u2h = completeMoveBy;
  protoOf(AbstractComponent).v3a = getSnapHighlightX;
  protoOf(AbstractComponent).w3a = getSnapHighlightY;
  protoOf(AbstractComponent).n37 = get_isReferencable;
  protoOf(AbstractComponent).q37 = get_isNotReading;
  protoOf(AbstractComponent).l37 = resolutionDone;
  protoOf(AbstractComponent).m37 = allResolutionDone;
  protoOf(AbstractComponent).t37 = readFromStore;
  protoOf(AbstractComponent).q21 = get_isFocusOwner;
  protoOf(AbstractComponent).s21 = requestFocus;
  protoOf(AbstractPathFigure).o2h = get_canMirror;
  protoOf(ComponentContainerImpl).n37 = get_isReferencable;
  protoOf(ComponentContainerImpl).q37 = get_isNotReading;
  protoOf(ComponentContainerImpl).l37 = resolutionDone;
  protoOf(ComponentContainerImpl).t37 = readFromStore;
  protoOf(DrawingImpl).s3a = notifyEditable_0;
  protoOf(AbstractCurveComponent).v2g = applyTo;
  protoOf(AbstractCurveComponent).o2h = get_canMirror;
  protoOf(MoveCurvePointCommand).v39 = get_canUndo;
  protoOf(AbstractRectangularComponent).o2h = get_canMirror;
  protoOf(RectangularComponent).v2g = applyTo;
  protoOf(AddPolylinePointCommand).v39 = get_canUndo;
  protoOf(JoinPolylinePointsCommand).v39 = get_canUndo;
  protoOf(MovePolylinePointCommand).v39 = get_canUndo;
  protoOf(PolylineComponent).r2q = findSegment$default;
  protoOf(PolylineComponent).v2g = applyTo;
  protoOf(PolylineComponent).o2h = get_canMirror;
  protoOf(ResizeRectangleCommand).v39 = get_canUndo;
  protoOf(AbstractTextComponent).v2g = applyTo;
  protoOf(Label).o2h = get_canMirror;
  protoOf(Label).f21 = moveBy;
  protoOf(LabelComponent).v2g = applyTo;
  protoOf(TranslatableText).g45 = get_isNotEmpty;
  protoOf(TranslatableText).u44 = getTranslation;
  protoOf(TranslatableText).v4d = withTranslation;
  protoOf(TranslatableText).x4d = getOptionalTranslation;
  protoOf(Translation).q37 = get_isNotReading;
  protoOf(Translation).l37 = resolutionDone;
  protoOf(Translation).m37 = allResolutionDone;
  protoOf(Translation).t37 = readFromStore;
  protoOf(Description).g45 = get_isNotEmpty;
  protoOf(Description).u44 = getTranslation;
  protoOf(Name).g45 = get_isNotEmpty;
  protoOf(Name).u44 = getTranslation;
  protoOf(RectangularHandle).g43 = setLocation;
  protoOf(RectangularRubberBand).oo = contains_2;
  protoOf(SelectionManagerImpl).e3d = get_selectionCount;
  protoOf(AbstractTool).o3e = mouseClicked;
  protoOf(AbstractTool).q3e = mousePressed;
  protoOf(AbstractTool).s3e = mouseReleased;
  protoOf(AbstractTool).u3e = mouseMoved;
  protoOf(AbstractTool).w3e = mouseDragged;
  protoOf(AbstractSnapper).l3e = getSnapHighlightX_0;
  protoOf(AbstractSnapper).m3e = getSnapHighlightY_0;
  protoOf(MultiComponentSnappable).v3a = getSnapHighlightX;
  protoOf(MultiComponentSnappable).w3a = getSnapHighlightY;
  defineProp(protoOf(ToolLockAction), 'requestFocusOnClick', function () {
    return this.uq();
  });
  //endregion
  //region block: init
  DragDestinationHighlighter_instance = new DragDestinationHighlighter();
  Companion_instance_13 = new Companion_8();
  Companion_instance_14 = new Companion_9();
  Companion_instance_19 = new Companion_14();
  Companion_instance_20 = new Companion_15();
  Companion_instance_21 = new Companion_16();
  Companion_instance_24 = new Companion_19();
  Companion_instance_26 = new Companion_21();
  Companion_instance_32 = new Companion_27();
  Companion_instance_33 = new Companion_28();
  Companion_instance_34 = new Companion_29();
  Companion_instance_37 = new Companion_32();
  Companion_instance_38 = new Companion_33();
  Companion_instance_39 = new Companion_34();
  Companion_instance_40 = new Companion_35();
  Companion_instance_41 = new Companion_36();
  Companion_instance_42 = new Companion_37();
  Companion_instance_43 = new Companion_38();
  Companion_instance_44 = new Companion_39();
  Companion_instance_45 = new Companion_40();
  Companion_instance_46 = new Companion_41();
  Companion_instance_53 = new Companion_48();
  Companion_instance_58 = new Companion_53();
  //endregion
  //region block: exports
  function $jsExportAll$(_) {
    var io = _.io || (_.io = {});
    var antarescircuit = io.antarescircuit || (io.antarescircuit = {});
    var jabbah = antarescircuit.jabbah || (antarescircuit.jabbah = {});
    var edit = jabbah.edit || (jabbah.edit = {});
    var auth = edit.auth || (edit.auth = {});
    auth.UserIdentity = UserIdentity;
    defineProp(auth.UserIdentity, 'Companion', Companion_getInstance_12, VOID, true);
  }
  $jsExportAll$(_);
  _.$jsExportAll$ = $jsExportAll$;
  _.$_$ = _.$_$ || {};
  _.$_$.a = Authorizer_getInstance;
  _.$_$.b = EditAuthModule_getInstance;
  _.$_$.c = Companion_getInstance_12;
  _.$_$.d = DragDestinationHighlighter_instance;
  _.$_$.e = EditDragModule_getInstance;
  _.$_$.f = EditEditorModule_getInstance;
  _.$_$.g = FigureRegistry_getInstance;
  _.$_$.h = EditHighlightModule_getInstance;
  _.$_$.i = Companion_instance_24;
  _.$_$.j = Companion_instance_39;
  _.$_$.k = Companion_instance_40;
  _.$_$.l = Companion_instance_34;
  _.$_$.m = Companion_instance_38;
  _.$_$.n = Companion_instance_13;
  _.$_$.o = EditModuleJs_getInstance;
  _.$_$.p = EditModule_getInstance;
  _.$_$.q = Companion_instance_42;
  _.$_$.r = EditSelectModule_getInstance;
  _.$_$.s = SemanticRegistry_getInstance;
  _.$_$.t = Companion_getInstance_60;
  _.$_$.u = Companion_getInstance_61;
  _.$_$.v = Look_getInstance;
  _.$_$.w = Companion_getInstance_9;
  _.$_$.x = Operation_Change_getInstance;
  _.$_$.y = Operation_View_getInstance;
  _.$_$.z = DrawStrategy_COMPONENT_getInstance;
  _.$_$.a1 = HorizontalAlignment_CENTER_getInstance;
  _.$_$.b1 = HorizontalAlignment_LEFT_getInstance;
  _.$_$.c1 = HorizontalAlignment_RIGHT_getInstance;
  _.$_$.d1 = RotationDisplayStrategy_KEEP_HORIZONTAL_getInstance;
  _.$_$.e1 = RotationDisplayStrategy_ROTATE_HALF_getInstance;
  _.$_$.f1 = VerticalAlignment_BOTTOM_getInstance;
  _.$_$.g1 = VerticalAlignment_CENTER_getInstance;
  _.$_$.h1 = VerticalAlignment_TOP_getInstance;
  _.$_$.i1 = ComponentMessageType_Error_getInstance;
  _.$_$.j1 = ComponentMessageType_Info_getInstance;
  _.$_$.k1 = Size_LARGE_getInstance;
  _.$_$.l1 = Size_MEDIUM_getInstance;
  _.$_$.m1 = Size_SMALL_getInstance;
  _.$_$.n1 = Magnitude_Giga_getInstance;
  _.$_$.o1 = Magnitude_Kilo_getInstance;
  _.$_$.p1 = Magnitude_Mega_getInstance;
  _.$_$.q1 = Magnitude_Micro_getInstance;
  _.$_$.r1 = Magnitude_Milli_getInstance;
  _.$_$.s1 = Magnitude_Nano_getInstance;
  _.$_$.t1 = Magnitude_One_getInstance;
  _.$_$.u1 = SIUnit_Ampere_getInstance;
  _.$_$.v1 = SIUnit_Factor_getInstance;
  _.$_$.w1 = SIUnit_Farad_getInstance;
  _.$_$.x1 = SIUnit_Henry_getInstance;
  _.$_$.y1 = SIUnit_Hertz_getInstance;
  _.$_$.z1 = SIUnit_Ohm_getInstance;
  _.$_$.a2 = SIUnit_Second_getInstance;
  _.$_$.b2 = SIUnit_Volt_getInstance;
  _.$_$.c2 = SelectionDrawingStrategy_ABOVE_getInstance;
  _.$_$.d2 = SelectionDrawingStrategy_BELOW_getInstance;
  _.$_$.e2 = SelectionDrawingStrategy_REPLACE_getInstance;
  _.$_$.f2 = AddCommand_init_$Create$;
  _.$_$.g2 = EditorImpl_init_$Init$;
  _.$_$.h2 = CompactablePolyline_init_$Create$;
  _.$_$.i2 = RectangleComponent_init_$Create$;
  _.$_$.j2 = Description_init_$Create$;
  _.$_$.k2 = Name_init_$Create$;
  _.$_$.l2 = TranslatableText_init_$Create$_0;
  _.$_$.m2 = TranslatableText_init_$Create$;
  _.$_$.n2 = AbstractComponent_init_$Init$;
  _.$_$.o2 = MagnitudeValue_init_$Create$;
  _.$_$.p2 = DeleteQuestion;
  _.$_$.q2 = DrawingAppServiceImpl;
  _.$_$.r2 = DrawingAppService;
  _.$_$.s2 = DesktopUserHolder;
  _.$_$.t2 = DesktopUser;
  _.$_$.u2 = UserIdentity;
  _.$_$.v2 = AbstractCommand;
  _.$_$.w2 = AbstractDrawingViewCommand;
  _.$_$.x2 = DragDestinationHighlightFactory;
  _.$_$.y2 = DragDestination;
  _.$_$.z2 = DragManagerImpl;
  _.$_$.a3 = EditorImpl;
  _.$_$.b3 = AbstractPathFigure;
  _.$_$.c3 = FigureFactory;
  _.$_$.d3 = FigureProvider;
  _.$_$.e3 = DrawingViewSearch;
  _.$_$.f3 = ImageComponent;
  _.$_$.g3 = ImageData;
  _.$_$.h3 = ImageIdentification;
  _.$_$.i3 = CompactablePolyline;
  _.$_$.j3 = PolylineComponent;
  _.$_$.k3 = AbstractRectangularComponent;
  _.$_$.l3 = RectangularBelowSelectionModel;
  _.$_$.m3 = RectangularComponent;
  _.$_$.n3 = RectangularHandleSelectionModel;
  _.$_$.o3 = RectangularReplaceSelectionModel;
  _.$_$.p3 = Describable;
  _.$_$.q3 = Description;
  _.$_$.r3 = Namable;
  _.$_$.s3 = NameChangedEvent;
  _.$_$.t3 = Name;
  _.$_$.u3 = observableDescription;
  _.$_$.v3 = observableName;
  _.$_$.w3 = Alignment;
  _.$_$.x3 = HorizontalLabel;
  _.$_$.y3 = LabelComponent;
  _.$_$.z3 = Labeled;
  _.$_$.a4 = Label;
  _.$_$.b4 = ScriptProperty;
  _.$_$.c4 = SimpleTextComponent;
  _.$_$.d4 = TextDrawableButtonRenderer;
  _.$_$.e4 = TranslatableText;
  _.$_$.f4 = Translatable;
  _.$_$.g4 = Translation;
  _.$_$.h4 = AbstractComponent;
  _.$_$.i4 = ComponentMessage;
  _.$_$.j4 = DrawingImpl;
  _.$_$.k4 = DrawingServiceImpl;
  _.$_$.l4 = MagnitudeValue;
  _.$_$.m4 = PropertyValueException;
  _.$_$.n4 = AbstractBelowSelectionModel;
  _.$_$.o4 = AbstractSelectionModel;
  _.$_$.p4 = BoundingBoxBelowSelectionModel;
  _.$_$.q4 = SelectedColorSelectionModel;
  _.$_$.r4 = get_selectedColorSelectionModelFactory;
  _.$_$.s4 = EditStyleType;
  _.$_$.t4 = EditTheme;
  _.$_$.u4 = AttentionDrawerImpl;
  _.$_$.v4 = DrawingViewImpl;
  _.$_$.w4 = ComponentContainer;
  _.$_$.x4 = Component;
  _.$_$.y4 = DrawingViewContent;
  _.$_$.z4 = DrawingView;
  _.$_$.a5 = Drawing;
  _.$_$.b5 = EditInputEventContext;
  _.$_$.c5 = SnapResult;
  _.$_$.d5 = getSnapHighlightX;
  _.$_$.e5 = getSnapHighlightY;
  _.$_$.f5 = SnappableXCoordinate;
  _.$_$.g5 = SnappableYCoordinate;
  _.$_$.h5 = Snappable;
  _.$_$.i5 = get_canUndo;
  _.$_$.j5 = Undoable;
  //endregion
  return _;
}));

//# sourceMappingURL=jabbah-edit.js.map
