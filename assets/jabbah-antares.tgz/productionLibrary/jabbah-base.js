(function (factory) {
  if (typeof define === 'function' && define.amd)
    define(['exports', './kotlin-kotlin-stdlib.js'], factory);
  else if (typeof exports === 'object')
    factory(module.exports, require('./kotlin-kotlin-stdlib.js'));
  else {
    if (typeof globalThis['kotlin-kotlin-stdlib'] === 'undefined') {
      throw new Error("Error loading module 'jabbah-base'. Its dependency 'kotlin-kotlin-stdlib' was not found. Please, check whether 'kotlin-kotlin-stdlib' is loaded prior to 'jabbah-base'.");
    }
    globalThis['jabbah-base'] = factory(typeof globalThis['jabbah-base'] === 'undefined' ? {} : globalThis['jabbah-base'], globalThis['kotlin-kotlin-stdlib']);
  }
}(function (_, kotlin_kotlin) {
  'use strict';
  //region block: imports
  var imul = Math.imul;
  var log2 = Math.log2;
  var sign = Math.sign;
  var VOID = kotlin_kotlin.$_$.b;
  var protoOf = kotlin_kotlin.$_$.t7;
  var Unit_instance = kotlin_kotlin.$_$.i;
  var initMetadataForClass = kotlin_kotlin.$_$.d7;
  var LinkedHashMap_init_$Create$ = kotlin_kotlin.$_$.q;
  var lazy = kotlin_kotlin.$_$.ob;
  var initMetadataForObject = kotlin_kotlin.$_$.i7;
  var numberToLong = kotlin_kotlin.$_$.e6;
  var ensureNotNull = kotlin_kotlin.$_$.kb;
  var getKClassFromExpression = kotlin_kotlin.$_$.p8;
  var get_js = kotlin_kotlin.$_$.n7;
  var Default_getInstance = kotlin_kotlin.$_$.f;
  var KProperty1 = kotlin_kotlin.$_$.t8;
  var getPropertyCallableRef = kotlin_kotlin.$_$.a7;
  var getKClass = kotlin_kotlin.$_$.q8;
  var initMetadataForCompanion = kotlin_kotlin.$_$.e7;
  var emptyMap = kotlin_kotlin.$_$.d3;
  var ArrayList_init_$Create$ = kotlin_kotlin.$_$.n;
  var toString = kotlin_kotlin.$_$.v7;
  var replace = kotlin_kotlin.$_$.t9;
  var defineProp = kotlin_kotlin.$_$.t6;
  var THROW_CCE = kotlin_kotlin.$_$.db;
  var hashCode = kotlin_kotlin.$_$.c7;
  var equals = kotlin_kotlin.$_$.u6;
  var UnsupportedOperationException_init_$Create$ = kotlin_kotlin.$_$.m1;
  var multiply = kotlin_kotlin.$_$.c6;
  var IllegalStateException_init_$Create$ = kotlin_kotlin.$_$.d1;
  var initMetadataForInterface = kotlin_kotlin.$_$.g7;
  var ObservableProperty = kotlin_kotlin.$_$.z7;
  var Delegates_instance = kotlin_kotlin.$_$.e;
  var KMutableProperty1 = kotlin_kotlin.$_$.r8;
  var Enum = kotlin_kotlin.$_$.va;
  var noWhenBranchMatchedException = kotlin_kotlin.$_$.pb;
  var toString_0 = kotlin_kotlin.$_$.rb;
  var getStringHashCode = kotlin_kotlin.$_$.b7;
  var getBigIntHashCode = kotlin_kotlin.$_$.w6;
  var getBooleanHashCode = kotlin_kotlin.$_$.x6;
  var toInt = kotlin_kotlin.$_$.ia;
  var toDouble = kotlin_kotlin.$_$.ga;
  var NoSuchElementException_init_$Create$ = kotlin_kotlin.$_$.h1;
  var _Char___init__impl__6a9atx = kotlin_kotlin.$_$.n1;
  var isBlank = kotlin_kotlin.$_$.j9;
  var charSequenceLength = kotlin_kotlin.$_$.r6;
  var StringBuilder_init_$Create$ = kotlin_kotlin.$_$.v;
  var isCharSequence = kotlin_kotlin.$_$.k7;
  var reversed = kotlin_kotlin.$_$.v9;
  var charCodeAt = kotlin_kotlin.$_$.p6;
  var Char = kotlin_kotlin.$_$.sa;
  var joinToString = kotlin_kotlin.$_$.o3;
  var emptyList = kotlin_kotlin.$_$.c3;
  var dropLast = kotlin_kotlin.$_$.b9;
  var toString_1 = kotlin_kotlin.$_$.q1;
  var last = kotlin_kotlin.$_$.o9;
  var charArrayOf = kotlin_kotlin.$_$.o6;
  var split = kotlin_kotlin.$_$.w9;
  var collectionSizeOrDefault = kotlin_kotlin.$_$.s2;
  var ArrayList_init_$Create$_0 = kotlin_kotlin.$_$.m;
  var replace_0 = kotlin_kotlin.$_$.u9;
  var take = kotlin_kotlin.$_$.fa;
  var charSequenceGet = kotlin_kotlin.$_$.q6;
  var isWhitespace = kotlin_kotlin.$_$.n9;
  var objectCreate = kotlin_kotlin.$_$.s7;
  var IllegalArgumentException_init_$Create$ = kotlin_kotlin.$_$.b1;
  var KtList = kotlin_kotlin.$_$.h2;
  var KtSet = kotlin_kotlin.$_$.l2;
  var LinkedHashSet_init_$Create$ = kotlin_kotlin.$_$.r;
  var sort = kotlin_kotlin.$_$.o4;
  var last_0 = kotlin_kotlin.$_$.r3;
  var isInterface = kotlin_kotlin.$_$.m7;
  var extendThrowable = kotlin_kotlin.$_$.v6;
  var captureStack = kotlin_kotlin.$_$.n6;
  var Exception = kotlin_kotlin.$_$.xa;
  var isLetterOrDigit = kotlin_kotlin.$_$.l9;
  var isLetter = kotlin_kotlin.$_$.m9;
  var isDigit = kotlin_kotlin.$_$.k9;
  var toLong = kotlin_kotlin.$_$.ka;
  var NumberFormatException = kotlin_kotlin.$_$.bb;
  var toNumber = kotlin_kotlin.$_$.j6;
  var FunctionAdapter = kotlin_kotlin.$_$.k6;
  var to = kotlin_kotlin.$_$.tb;
  var mapOf = kotlin_kotlin.$_$.v3;
  var setOf = kotlin_kotlin.$_$.k4;
  var plus = kotlin_kotlin.$_$.b4;
  var mutableListOf = kotlin_kotlin.$_$.y3;
  var lastOrNull = kotlin_kotlin.$_$.q3;
  var removeLast = kotlin_kotlin.$_$.g4;
  var contains = kotlin_kotlin.$_$.t2;
  var add = kotlin_kotlin.$_$.w5;
  var subtract = kotlin_kotlin.$_$.i6;
  var divide = kotlin_kotlin.$_$.z5;
  var convertToInt = kotlin_kotlin.$_$.y5;
  var shiftLeft = kotlin_kotlin.$_$.f6;
  var shiftRight = kotlin_kotlin.$_$.h6;
  var modulo = kotlin_kotlin.$_$.b6;
  var negate = kotlin_kotlin.$_$.d6;
  var KtMutableMap = kotlin_kotlin.$_$.k2;
  var mutableMapOf = kotlin_kotlin.$_$.z3;
  var KtMap = kotlin_kotlin.$_$.i2;
  var _ULong___init__impl__c78o9k = kotlin_kotlin.$_$.w1;
  var ULong = kotlin_kotlin.$_$.fb;
  var throwUninitializedPropertyAccessException = kotlin_kotlin.$_$.t5;
  var MutableCollection = kotlin_kotlin.$_$.j2;
  var toList = kotlin_kotlin.$_$.s4;
  var THROW_IAE = kotlin_kotlin.$_$.eb;
  var Char__hashCode_impl_otmys = kotlin_kotlin.$_$.o1;
  var getNumberHashCode = kotlin_kotlin.$_$.y6;
  var numberToInt = kotlin_kotlin.$_$.r7;
  var abs = kotlin_kotlin.$_$.w7;
  var rangeTo = kotlin_kotlin.$_$.l8;
  var contains_0 = kotlin_kotlin.$_$.z8;
  var roundToInt = kotlin_kotlin.$_$.x7;
  var first = kotlin_kotlin.$_$.h9;
  var listOf = kotlin_kotlin.$_$.t3;
  var listOf_0 = kotlin_kotlin.$_$.s3;
  var compareTo = kotlin_kotlin.$_$.s6;
  var numberRangeToNumber = kotlin_kotlin.$_$.o7;
  var checkIndexOverflow = kotlin_kotlin.$_$.r2;
  var first_0 = kotlin_kotlin.$_$.h3;
  var Collection = kotlin_kotlin.$_$.g2;
  var lines = kotlin_kotlin.$_$.p9;
  var startsWith = kotlin_kotlin.$_$.z9;
  var trim = kotlin_kotlin.$_$.qa;
  var removeSuffix = kotlin_kotlin.$_$.r9;
  var endsWith = kotlin_kotlin.$_$.e9;
  //endregion
  //region block: pre-declaration
  initMetadataForClass(Logger, 'Logger', Logger);
  initMetadataForObject(LogSystem, 'LogSystem');
  initMetadataForObject(System, 'System');
  initMetadataForCompanion(Companion);
  initMetadataForClass(TranslationServiceJsImpl, 'TranslationServiceJsImpl');
  initMetadataForObject(Translations, 'Translations');
  initMetadataForObject(TranslationsOutlet, 'TranslationsOutlet');
  initMetadataForInterface(PropertyChangeListener, 'PropertyChangeListener');
  initMetadataForClass(mpListener$1, VOID, VOID, VOID, [PropertyChangeListener]);
  initMetadataForClass(MoveTo, 'MoveTo');
  initMetadataForClass(LineTo, 'LineTo');
  initMetadataForClass(QuadTo, 'QuadTo');
  initMetadataForClass(CurveTo, 'CurveTo');
  initMetadataForClass(ClosePath, 'ClosePath', ClosePath);
  initMetadataForClass(Entry, 'Entry');
  function contains_1(p) {
    return this.eo(p.in_1, p.jn_1);
  }
  function contains_2(rect) {
    return this.fo(rect.z19(), rect.a1a(), rect.p1b(), rect.r1b());
  }
  function intersects(rect) {
    return this.go(rect.z19(), rect.a1a(), rect.p1b(), rect.r1b());
  }
  initMetadataForInterface(Shape, 'Shape');
  function moveTo(x, y) {
    return this.sn(x, y);
  }
  function moveTo_0(x, y) {
    return this.sn(x, y);
  }
  function lineTo(x, y) {
    return this.wn(x, y);
  }
  function lineTo_0(x, y) {
    return this.wn(x, y);
  }
  function quadTo(x1, y1, x2, y2) {
    return this.zn(x1, y1, x2, y2);
  }
  initMetadataForInterface(Path, 'Path', VOID, VOID, [Shape]);
  initMetadataForClass(Path2DJs, 'Path2DJs', Path2DJs, VOID, [Path]);
  initMetadataForClass(InvocationHandler, 'InvocationHandler');
  initMetadataForClass(InvocationHandlerJs, 'InvocationHandlerJs', InvocationHandlerJs, InvocationHandler);
  initMetadataForClass(AbstractModule, 'AbstractModule');
  initMetadataForObject(BaseModuleJs, 'BaseModuleJs', VOID, AbstractModule);
  initMetadataForObject(SoundClipFactory, 'SoundClipFactory');
  initMetadataForObject(SoundClipJs, 'SoundClipJs');
  initMetadataForObject(ToneFactory, 'ToneFactory');
  initMetadataForClass(RealTimeServiceJs, 'RealTimeServiceJs', RealTimeServiceJs);
  function initialize$default(interval, repeats, handler, $super) {
    repeats = repeats === VOID ? true : repeats;
    return $super === VOID ? this.tp(interval, repeats, handler) : $super.tp.call(this, interval, repeats, handler);
  }
  initMetadataForInterface(Timer, 'Timer');
  initMetadataForClass(RealTimeTimerJs, 'RealTimeTimerJs', RealTimeTimerJs, VOID, [Timer]);
  initMetadataForClass(Throttle, 'Throttle');
  initMetadataForObject(ActionProperty, 'ActionProperty');
  function get_opensDialog() {
    return false;
  }
  function get_requestFocusOnClick() {
    return false;
  }
  initMetadataForInterface(Action, 'Action');
  initMetadataForCompanion(Companion_0);
  initMetadataForClass(AbstractAction$name$$inlined$observable$1, VOID, VOID, ObservableProperty);
  initMetadataForClass(AbstractAction$description$$inlined$observable$1, VOID, VOID, ObservableProperty);
  initMetadataForClass(AbstractAction$accelerator$$inlined$observable$1, VOID, VOID, ObservableProperty);
  initMetadataForClass(AbstractAction$enabled$$inlined$observable$1, VOID, VOID, ObservableProperty);
  initMetadataForClass(AbstractAction$selected$$inlined$observable$1, VOID, VOID, ObservableProperty);
  initMetadataForClass(AbstractAction$imagePath$$inlined$observable$1, VOID, VOID, ObservableProperty);
  initMetadataForClass(AbstractAction, 'AbstractAction', VOID, VOID, [Action]);
  initMetadataForCompanion(Companion_1);
  initMetadataForClass(DataLocation, 'DataLocation', VOID, Enum);
  initMetadataForInterface(Disposable, 'Disposable');
  initMetadataForClass(EmptyHierarchyVisitor, 'EmptyHierarchyVisitor', EmptyHierarchyVisitor);
  initMetadataForClass(IssueImpl, 'IssueImpl');
  initMetadataForClass(IssueSeverity, 'IssueSeverity', VOID, Enum);
  initMetadataForClass(LogLevel, 'LogLevel', VOID, Enum);
  initMetadataForCompanion(Companion_2);
  initMetadataForInterface(LongValue, 'LongValue');
  initMetadataForClass(LongValueImpl, 'LongValueImpl', VOID, VOID, [LongValue]);
  initMetadataForClass(Entry_0, 'Entry');
  initMetadataForClass(Properties, 'Properties', Properties);
  initMetadataForClass(PropertiesProxy, 'PropertiesProxy', VOID, Properties);
  initMetadataForClass(PreferencesChangedEvent, 'PreferencesChangedEvent');
  initMetadataForClass(Settings, 'Settings', Settings);
  initMetadataForClass(ResettableLazy, 'ResettableLazy');
  initMetadataForObject(UninitializedValue, 'UninitializedValue');
  initMetadataForObject(Status, 'Status');
  initMetadataForClass(StatusType, 'StatusType', VOID, Enum);
  initMetadataForClass(StatusEvent, 'StatusEvent');
  initMetadataForObject(StringUtils, 'StringUtils');
  initMetadataForClass(Tooltip, 'Tooltip');
  initMetadataForCompanion(Companion_3);
  initMetadataForClass(Language, 'Language', VOID, Enum);
  initMetadataForClass(UUID, 'UUID');
  initMetadataForClass(ImmutableList, 'ImmutableList', VOID, VOID, [KtList]);
  initMetadataForClass(EmptyIterator, 'EmptyIterator', EmptyIterator);
  initMetadataForClass(ImmutableSet, 'ImmutableSet', VOID, VOID, [KtSet]);
  initMetadataForClass(DirectedGraph, 'DirectedGraph', DirectedGraph);
  initMetadataForCompanion(Companion_4);
  initMetadataForClass(Pair, 'Pair');
  initMetadataForClass(PriorityQueue, 'PriorityQueue', PriorityQueue);
  initMetadataForClass(Stack, 'Stack', Stack);
  initMetadataForClass(EmptyStackException, 'EmptyStackException', EmptyStackException, Error);
  initMetadataForObject(TopologicalSort, 'TopologicalSort');
  initMetadataForClass(AbstractBaseInterpreter, 'AbstractBaseInterpreter');
  function getValue$default(name, location, $super) {
    location = location === VOID ? Companion_getInstance_18().ax_1 : location;
    return $super === VOID ? this.yw(name, location) : $super.yw.call(this, name, location);
  }
  function getOptionalValue$default(name, location, $super) {
    location = location === VOID ? Companion_getInstance_18().ax_1 : location;
    return $super === VOID ? this.cx(name, location) : $super.cx.call(this, name, location);
  }
  initMetadataForInterface(ActivationRecord, 'ActivationRecord');
  initMetadataForCompanion(Companion_5);
  initMetadataForClass(AbstractLexer, 'AbstractLexer');
  initMetadataForClass(BaseLexer, 'BaseLexer', VOID, AbstractLexer);
  initMetadataForClass(BaseTokenType, 'BaseTokenType', VOID, Enum);
  initMetadataForObject(Dsl, 'Dsl');
  initMetadataForClass(DslError, 'DslError', VOID, Error);
  initMetadataForClass(SyntaxError, 'SyntaxError', VOID, DslError);
  initMetadataForClass(SemanticError, 'SemanticError', VOID, DslError);
  initMetadataForClass(RuntimeError, 'RuntimeError', VOID, DslError);
  initMetadataForInterface(ExternalFunction, 'ExternalFunction');
  initMetadataForClass(sam$io_antarescircuit_jabbah_base_dsl_ExternalFunction$0, 'sam$io_antarescircuit_jabbah_base_dsl_ExternalFunction$0', VOID, VOID, [ExternalFunction, FunctionAdapter]);
  initMetadataForClass(DslGlobalFunctions, 'DslGlobalFunctions', DslGlobalFunctions);
  initMetadataForCompanion(Companion_6);
  initMetadataForClass(DslLexer, 'DslLexer', VOID, BaseLexer);
  initMetadataForCompanion(Companion_7);
  initMetadataForClass(AbstractParser, 'AbstractParser');
  initMetadataForClass(DslParser, 'DslParser', VOID, AbstractParser);
  initMetadataForClass(Visitor, 'Visitor', VOID, EmptyHierarchyVisitor);
  initMetadataForClass(DslSemanticAnalyser, 'DslSemanticAnalyser');
  initMetadataForCompanion(Companion_8);
  initMetadataForClass(Interpreter, 'Interpreter', VOID, AbstractBaseInterpreter);
  initMetadataForClass(Memory, 'Memory', Memory);
  initMetadataForClass(ScriptMetaData, 'ScriptMetaData');
  initMetadataForClass(StoringActivationRecord, 'StoringActivationRecord', VOID, VOID, [ActivationRecord]);
  initMetadataForClass(Symbol, 'Symbol');
  initMetadataForClass(BuiltInTypeSymbol, 'BuiltInTypeSymbol', VOID, Symbol);
  initMetadataForClass(VariableSymbol, 'VariableSymbol', VOID, Symbol);
  initMetadataForClass(ExternalFunctionSymbol, 'ExternalFunctionSymbol', VOID, Symbol);
  function hasSymbol$default(name, currentScopeOnly, $super) {
    currentScopeOnly = currentScopeOnly === VOID ? false : currentScopeOnly;
    return $super === VOID ? this.q12(name, currentScopeOnly) : $super.q12.call(this, name, currentScopeOnly);
  }
  function lookup$default(name, currentScopeOnly, $super) {
    currentScopeOnly = currentScopeOnly === VOID ? false : currentScopeOnly;
    return $super === VOID ? this.m16(name, currentScopeOnly) : $super.m16.call(this, name, currentScopeOnly);
  }
  initMetadataForInterface(SymbolTable, 'SymbolTable');
  initMetadataForClass(ScopedSymbolTable, 'ScopedSymbolTable', VOID, VOID, [SymbolTable]);
  initMetadataForClass(AbstractNode, 'AbstractNode');
  initMetadataForClass(Compound, 'Compound', VOID, AbstractNode);
  initMetadataForClass(Declaration, 'Declaration', VOID, AbstractNode);
  initMetadataForClass(Variable, 'Variable', VOID, AbstractNode);
  initMetadataForClass(Assignment, 'Assignment', VOID, AbstractNode);
  initMetadataForClass(Block, 'Block', VOID, Compound);
  initMetadataForClass(ForStatement, 'ForStatement', VOID, AbstractNode);
  initMetadataForClass(FunctionCall, 'FunctionCall', VOID, AbstractNode);
  initMetadataForClass(NoOp, 'NoOp', VOID, AbstractNode);
  initMetadataForClass(AssocArray, 'AssocArray', VOID, Variable);
  initMetadataForClass(IfStatement, 'IfStatement', VOID, AbstractNode);
  initMetadataForClass(WhenClause, 'WhenClause', VOID, AbstractNode);
  initMetadataForClass(WhenStatement, 'WhenStatement', VOID, AbstractNode);
  initMetadataForClass(ReturnStatement, 'ReturnStatement', VOID, AbstractNode);
  initMetadataForClass(BinaryOperation, 'BinaryOperation', VOID, AbstractNode);
  initMetadataForClass(UnaryOperation, 'UnaryOperation', VOID, AbstractNode);
  initMetadataForClass(Literal, 'Literal', VOID, AbstractNode);
  initMetadataForClass(DslTokenType, 'DslTokenType', VOID, Enum);
  function get_isAltDown() {
    return !((this.modifiers & Modifier_Alt_getInstance().mask) === 0);
  }
  function get_isControlDown() {
    return !((this.modifiers & Modifier_Ctrl_getInstance().mask) === 0);
  }
  function get_isShiftDown() {
    return !((this.modifiers & Modifier_Shift_getInstance().mask) === 0);
  }
  function get_isCtrlDown() {
    return !((this.modifiers & Modifier_Ctrl_getInstance().mask) === 0);
  }
  function get_isAltGraphDown() {
    return !((this.modifiers & Modifier_AltGraph_getInstance().mask) === 0);
  }
  function get_isMetaDown() {
    return !((this.modifiers & Modifier_Meta_getInstance().mask) === 0);
  }
  function hasModifier(modifier) {
    return !((this.modifiers & modifier.mask) === 0);
  }
  initMetadataForInterface(InputEvent, 'InputEvent');
  initMetadataForClass(ActionEvent, 'ActionEvent', VOID, VOID, [InputEvent]);
  initMetadataForInterface(ActionListener, 'ActionListener');
  function postVetoable$default(event, undoEvent, thenHandler, elseHandler, $super) {
    var tmp;
    if (thenHandler === VOID) {
      tmp = EventBus$postVetoable$lambda;
    } else {
      tmp = thenHandler;
    }
    thenHandler = tmp;
    var tmp_0;
    if (elseHandler === VOID) {
      tmp_0 = EventBus$postVetoable$lambda_0;
    } else {
      tmp_0 = elseHandler;
    }
    elseHandler = tmp_0;
    var tmp_1;
    if ($super === VOID) {
      this.m17(event, undoEvent, thenHandler, elseHandler);
      tmp_1 = Unit_instance;
    } else {
      tmp_1 = $super.m17.call(this, event, undoEvent, thenHandler, elseHandler);
    }
    return tmp_1;
  }
  function postTwoPhase$default(prepareEvent, execEvent, thenHandler, $super) {
    thenHandler = thenHandler === VOID ? null : thenHandler;
    var tmp;
    if ($super === VOID) {
      this.o17(prepareEvent, execEvent, thenHandler);
      tmp = Unit_instance;
    } else {
      tmp = $super.o17.call(this, prepareEvent, execEvent, thenHandler);
    }
    return tmp;
  }
  initMetadataForInterface(EventBus, 'EventBus');
  initMetadataForClass(VetoException, 'VetoException', VOID, Error);
  initMetadataForCompanion(Companion_9);
  initMetadataForClass(EventBusImpl, 'EventBusImpl', EventBusImpl, VOID, [EventBus]);
  initMetadataForClass(Modifier, 'Modifier', VOID, Enum);
  initMetadataForCompanion(Companion_10);
  initMetadataForClass(KeyEventType, 'KeyEventType', VOID, Enum);
  initMetadataForClass(KeyEventImpl, 'KeyEventImpl', VOID, VOID, [InputEvent]);
  initMetadataForClass(KeyAdapter, 'KeyAdapter', KeyAdapter);
  function get_location() {
    return new Point2D(this.z19(), this.a1a());
  }
  initMetadataForInterface(MouseEvent, 'MouseEvent', VOID, VOID, [InputEvent]);
  initMetadataForClass(MouseEventType, 'MouseEventType', VOID, Enum);
  initMetadataForClass(Button, 'Button', VOID, Enum);
  initMetadataForClass(MouseEventImpl, 'MouseEventImpl', MouseEventImpl, VOID, [MouseEvent]);
  initMetadataForClass(MouseAdapter, 'MouseAdapter', MouseAdapter);
  initMetadataForClass(PropertyChangeEvent, 'PropertyChangeEvent');
  initMetadataForClass(PropertyOwnerImpl, 'PropertyOwnerImpl', PropertyOwnerImpl);
  initMetadataForClass(sam$io_antarescircuit_jabbah_base_event_PropertyChangeListener$0, 'sam$io_antarescircuit_jabbah_base_event_PropertyChangeListener$0', VOID, VOID, [PropertyChangeListener, FunctionAdapter]);
  initMetadataForClass(PropertyChangeSupport, 'PropertyChangeSupport');
  initMetadataForCompanion(Companion_11);
  function contains_3(x, y) {
    return x >= this.z19() && x <= this.z19() + this.p1b() && y >= this.a1a() && y <= this.a1a() + this.r1b();
  }
  function contains_4(x, y, width, height) {
    if (this.ov()) {
      return false;
    }
    return x >= this.z19() && x + width <= this.l1c() && y >= this.a1a() && y + height <= this.m1c();
  }
  function get_xInt() {
    return numberToInt(this.z19());
  }
  function get_yInt() {
    return numberToInt(this.a1a());
  }
  function get_widthInt() {
    return numberToInt(this.p1b());
  }
  function get_heightInt() {
    return numberToInt(this.r1b());
  }
  function get_isInitial() {
    return this.ov() && this.z19() === 0.0 && this.a1a() === 0.0;
  }
  function get_isEmpty() {
    return this.p1b() <= 0 && this.r1b() <= 0;
  }
  function get_centerX() {
    return this.z19() + this.p1b() / 2.0;
  }
  function get_centerY() {
    return this.a1a() + this.r1b() / 2.0;
  }
  function get_minX() {
    return this.z19();
  }
  function get_minY() {
    return this.a1a();
  }
  function get_maxX() {
    return this.z19() + this.p1b();
  }
  function get_maxY() {
    return this.a1a() + this.r1b();
  }
  function get_center() {
    return new Point2D(this.h1c(), this.i1c());
  }
  function get_topLeft() {
    return new Point2D(this.j1c(), this.k1c());
  }
  function get_bottomCenter() {
    return new Point2D(this.h1c(), this.m1c());
  }
  function get_centerLeft() {
    return new Point2D(this.j1c(), this.i1c());
  }
  function get_centerRight() {
    return new Point2D(this.l1c(), this.i1c());
  }
  initMetadataForInterface(RectangularShape, 'RectangularShape', VOID, VOID, [Shape]);
  function moveBy(v) {
    this.s1b(this.z19() + v.in_1, this.a1a() + v.jn_1, this.p1b(), this.r1b());
    return this;
  }
  function setFrame(rect) {
    this.s1b(rect.z19(), rect.a1a(), rect.p1b(), rect.r1b());
  }
  function add_0(x, y) {
    if (this.g1c()) {
      this.s1b(x, y, 0.0, 0.0);
    } else {
      // Inline function 'kotlin.math.min' call
      var a = this.j1c();
      var x1 = Math.min(a, x);
      // Inline function 'kotlin.math.max' call
      var a_0 = this.l1c();
      var x2 = Math.max(a_0, x);
      // Inline function 'kotlin.math.min' call
      var a_1 = this.k1c();
      var y1 = Math.min(a_1, y);
      // Inline function 'kotlin.math.max' call
      var a_2 = this.m1c();
      var y2 = Math.max(a_2, y);
      this.s1b(x1, y1, x2 - x1, y2 - y1);
    }
    return this;
  }
  function add_1(p) {
    return this.tn(p.in_1, p.jn_1);
  }
  function add_2(rect) {
    if (this.g1c()) {
      this.w1b(rect);
    } else {
      var tmp0 = this.j1c();
      // Inline function 'kotlin.math.min' call
      var b = rect.j1c();
      var x1 = Math.min(tmp0, b);
      var tmp0_0 = this.l1c();
      // Inline function 'kotlin.math.max' call
      var b_0 = rect.l1c();
      var x2 = Math.max(tmp0_0, b_0);
      var tmp0_1 = this.k1c();
      // Inline function 'kotlin.math.min' call
      var b_1 = rect.k1c();
      var y1 = Math.min(tmp0_1, b_1);
      var tmp0_2 = this.m1c();
      // Inline function 'kotlin.math.max' call
      var b_2 = rect.m1c();
      var y2 = Math.max(tmp0_2, b_2);
      this.s1b(x1, y1, x2 - x1, y2 - y1);
    }
    return this;
  }
  function expandBy(deltaX, deltaY) {
    this.s1b(this.z19() - deltaX, this.a1a() - deltaY, this.p1b() + 2 * deltaX, this.r1b() + 2 * deltaY);
    return this;
  }
  function expandBy_0(delta) {
    return this.y1b(delta, delta);
  }
  function expandBy_1(topY, leftX, bottomY, rightX) {
    this.s1b(this.z19() - leftX, this.a1a() - topY, this.p1b() + leftX + rightX, this.r1b() + topY + bottomY);
    return this;
  }
  function expandLeftBy(deltaX) {
    this.s1b(this.z19() - deltaX, this.a1a(), this.p1b() + deltaX, this.r1b());
    return this;
  }
  initMetadataForInterface(MutableRectangularShape, 'MutableRectangularShape', VOID, VOID, [RectangularShape]);
  initMetadataForClass(AbstractRectangularShape, 'AbstractRectangularShape', VOID, VOID, [MutableRectangularShape]);
  function get_uniformScale() {
    // Inline function 'kotlin.math.sqrt' call
    var x = this.s1c();
    return Math.sqrt(x);
  }
  function translate(d) {
    return this.v1c(d.in_1, d.jn_1);
  }
  initMetadataForInterface(AffineTransform, 'AffineTransform');
  initMetadataForClass(NonInvertibleTransformException, 'NonInvertibleTransformException', VOID, Error);
  initMetadataForCompanion(Companion_12);
  initMetadataForClass(AffineTransformImpl, 'AffineTransformImpl', VOID, VOID, [AffineTransform]);
  initMetadataForClass(Dimension2D, 'Dimension2D');
  initMetadataForCompanion(Companion_13);
  initMetadataForClass(Direction, 'Direction', VOID, Enum);
  initMetadataForClass(Ellipse2D, 'Ellipse2D', Ellipse2D, AbstractRectangularShape);
  initMetadataForObject(Geometry, 'Geometry');
  initMetadataForCompanion(Companion_14);
  initMetadataForClass(Point2D, 'Point2D', Point2D);
  initMetadataForCompanion(Companion_15);
  initMetadataForClass(Rectangle2D, 'Rectangle2D', Rectangle2D, AbstractRectangularShape);
  initMetadataForClass(Ring2D, 'Ring2D', VOID, AbstractRectangularShape);
  initMetadataForCompanion(Companion_16);
  initMetadataForClass(Rotation, 'Rotation', VOID, Enum);
  initMetadataForClass(RoundRectangle2D, 'RoundRectangle2D', VOID, AbstractRectangularShape);
  initMetadataForClass(Turn, 'Turn', VOID, Enum);
  initMetadataForClass(Vector2D, 'Vector2D');
  initMetadataForClass(HelpId, 'HelpId');
  initMetadataForObject(HelpSourceRegistry, 'HelpSourceRegistry');
  initMetadataForClass(HelpSource, 'HelpSource');
  initMetadataForCompanion(Companion_17);
  initMetadataForClass(UnimplementedInvocationHandler, 'UnimplementedInvocationHandler', UnimplementedInvocationHandler, InvocationHandler);
  initMetadataForObject(BaseModule, 'BaseModule', VOID, AbstractModule);
  initMetadataForClass(State, 'State');
  initMetadataForCompanion(Companion_18);
  initMetadataForClass(TextLocation, 'TextLocation');
  initMetadataForClass(Token, 'Token');
  initMetadataForCompanion(Companion_19);
  initMetadataForClass(RichTextLexer, 'RichTextLexer', VOID, AbstractLexer);
  initMetadataForClass(RichTextTokenType, 'RichTextTokenType', VOID, Enum);
  initMetadataForCompanion(Companion_20);
  initMetadataForClass(RichTextParser, 'RichTextParser', VOID, AbstractParser);
  initMetadataForCompanion(Companion_21);
  initMetadataForClass(RichText, 'RichText', VOID, Compound);
  initMetadataForClass(Fragment, 'Fragment', VOID, AbstractNode);
  initMetadataForClass(StyledChunk, 'StyledChunk', VOID, AbstractNode);
  initMetadataForClass(StyledText, 'StyledText', VOID, AbstractNode);
  initMetadataForClass(AbstractFragmentPart, 'AbstractFragmentPart', VOID, AbstractNode);
  initMetadataForClass(FragmentText, 'FragmentText', VOID, AbstractFragmentPart);
  initMetadataForCompanion(Companion_22);
  initMetadataForClass(TextStyle, 'TextStyle');
  initMetadataForClass(Subscript, 'Subscript', VOID, AbstractFragmentPart);
  initMetadataForClass(Superscript, 'Superscript', VOID, AbstractFragmentPart);
  initMetadataForObject(SoundEffects, 'SoundEffects');
  initMetadataForCompanion(Companion_23);
  initMetadataForClass(WaveformType, 'WaveformType', VOID, Enum);
  initMetadataForClass(ToneParams, 'ToneParams');
  initMetadataForClass(State_0, 'State');
  initMetadataForCompanion(Companion_24);
  initMetadataForClass(StateMachine, 'StateMachine', StateMachine);
  initMetadataForClass(UnhandledEventBehaviour, 'UnhandledEventBehaviour', VOID, Enum);
  initMetadataForClass(UnhandledEventBehaviour$Strict, 'Strict', VOID, UnhandledEventBehaviour);
  initMetadataForClass(UnhandledEventBehaviour$Unhandled, 'Unhandled', VOID, UnhandledEventBehaviour);
  initMetadataForClass(SuperState, 'SuperState', VOID, State_0);
  initMetadataForClass(Transition, 'Transition');
  initMetadataForObject(PropertiesFileParser, 'PropertiesFileParser');
  initMetadataForCompanion(Companion_25);
  initMetadataForClass(SystemSpeed, 'SystemSpeed', SystemSpeed);
  initMetadataForClass(SystemSpeedEvent, 'SystemSpeedEvent');
  initMetadataForClass(SystemSpeedPauseEvent, 'SystemSpeedPauseEvent');
  initMetadataForCompanion(Companion_26);
  initMetadataForClass(ControlledTimeService, 'ControlledTimeService', ControlledTimeService);
  initMetadataForObject(DisplayDuration, 'DisplayDuration');
  initMetadataForClass(AbstractUIController, 'AbstractUIController');
  initMetadataForObject(UI, 'UI');
  //endregion
  function effectiveLevel($this) {
    var tmp0_elvis_lhs = $this.el_1;
    return tmp0_elvis_lhs == null ? LogSystem_getInstance().hl_1 : tmp0_elvis_lhs;
  }
  function Logger(level) {
    level = level === VOID ? null : level;
    this.el_1 = level;
  }
  protoOf(Logger).il = function (msg) {
    console.info(msg);
  };
  protoOf(Logger).jl = function (msg, t) {
    if (effectiveLevel(this).l2_1 >= LogLevel_Error_getInstance().l2_1) {
      console.error(msg);
    }
  };
  protoOf(Logger).kl = function (msg, t, $super) {
    t = t === VOID ? null : t;
    var tmp;
    if ($super === VOID) {
      this.jl(msg, t);
      tmp = Unit_instance;
    } else {
      tmp = $super.jl.call(this, msg, t);
    }
    return tmp;
  };
  protoOf(Logger).ll = function (msg) {
    if (effectiveLevel(this).l2_1 >= LogLevel_Warning_getInstance().l2_1) {
      console.warn(msg);
    }
  };
  protoOf(Logger).ml = function (msg) {
    if (effectiveLevel(this).l2_1 >= LogLevel_Info_getInstance().l2_1) {
      console.info(msg);
    }
  };
  protoOf(Logger).nl = function (msg) {
    if (effectiveLevel(this).l2_1 >= LogLevel_Debug_getInstance().l2_1) {
      console.log(msg);
    }
  };
  protoOf(Logger).ol = function (msg) {
    if (effectiveLevel(this).l2_1 >= LogLevel_Trace_getInstance().l2_1) {
      console.log(msg);
    }
  };
  protoOf(Logger).pl = function () {
    return effectiveLevel(this).l2_1 >= LogLevel_Debug_getInstance().l2_1;
  };
  protoOf(Logger).ql = function () {
    return effectiveLevel(this).l2_1 >= LogLevel_Trace_getInstance().l2_1;
  };
  function LogSystem$getLogger$lambda() {
    return new Logger();
  }
  function LogSystem() {
    LogSystem_instance = this;
    var tmp = this;
    // Inline function 'kotlin.collections.mutableMapOf' call
    tmp.fl_1 = LinkedHashMap_init_$Create$();
    this.gl_1 = 'base.logLevel';
    this.hl_1 = LogLevel_Warning_getInstance();
  }
  protoOf(LogSystem).rl = function (clazz) {
    // Inline function 'kotlin.collections.getOrPut' call
    var this_0 = this.fl_1;
    var value = this_0.g2(clazz);
    var tmp;
    if (value == null) {
      var answer = lazy(LogSystem$getLogger$lambda);
      this_0.y1(clazz, answer);
      tmp = answer;
    } else {
      tmp = value;
    }
    return tmp;
  };
  var LogSystem_instance;
  function LogSystem_getInstance() {
    if (LogSystem_instance == null)
      new LogSystem();
    return LogSystem_instance;
  }
  function System$invoker$lambda(it) {
    it();
    return Unit_instance;
  }
  function System() {
    System_instance = this;
    var tmp = this;
    tmp.sl_1 = System$invoker$lambda;
  }
  protoOf(System).tl = function () {
    return numberToLong((new Date()).getTime());
  };
  protoOf(System).ul = function () {
    return new RealTimeTimerJs();
  };
  protoOf(System).vl = function (clazz) {
    return ensureNotNull(clazz.l9());
  };
  protoOf(System).wl = function (obj) {
    return ensureNotNull(getKClassFromExpression(obj).l9());
  };
  protoOf(System).xl = function (obj) {
    return getKClassFromExpression(obj);
  };
  protoOf(System).yl = function (clazz) {
    return newInstance(get_js(clazz));
  };
  protoOf(System).zl = function () {
    return AffineTransformImpl_init_$Create$();
  };
  protoOf(System).am = function () {
    return new Path2DJs();
  };
  protoOf(System).bm = function (uuid) {
    var tmp;
    if (uuid == null) {
      tmp = null;
    } else {
      // Inline function 'kotlin.let' call
      tmp = new UUID(uuid);
    }
    var tmp1_elvis_lhs = tmp;
    return tmp1_elvis_lhs == null ? new UUID(Default_getInstance().ag(10000, 99000).toString() + '-TEMP-UUID') : tmp1_elvis_lhs;
  };
  protoOf(System).cm = function (uuid, $super) {
    uuid = uuid === VOID ? null : uuid;
    return $super === VOID ? this.bm(uuid) : $super.bm.call(this, uuid);
  };
  protoOf(System).dm = function (invocable) {
    this.sl_1(invocable);
  };
  protoOf(System).em = function (baseName) {
    return baseName + '.accelerator';
  };
  protoOf(System).fm = function () {
    return Language_English_getInstance();
  };
  protoOf(System).gm = function (path) {
    return null;
  };
  var System_instance;
  function System_getInstance() {
    if (System_instance == null)
      new System();
    return System_instance;
  }
  function newInstance(_this__u8e3s4) {
    // Inline function 'kotlin.js.asDynamic' call
    // Inline function 'io.antarescircuit.jabbah.base.newInstance.callCtor' call
    return new _this__u8e3s4();
  }
  function _get_LOG__e5r759($this) {
    var tmp0 = $this.hm_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('LOG', 1, tmp, TranslationServiceJsImpl$Companion$_get_LOG_$ref_nlqk25(), null);
    return tmp0.j2();
  }
  function TranslationServiceJsImpl$Companion$_get_LOG_$ref_nlqk25() {
    return function (p0) {
      return _get_LOG__e5r759(p0);
    };
  }
  function Companion() {
    Companion_instance = this;
    this.hm_1 = logger(getKClass(TranslationServiceJsImpl));
  }
  var Companion_instance;
  function Companion_getInstance() {
    if (Companion_instance == null)
      new Companion();
    return Companion_instance;
  }
  function TranslationServiceJsImpl$load$lambda(it) {
    return it.text();
  }
  function TranslationServiceJsImpl$load$lambda_0(it) {
    return PropertiesFileParser_getInstance().jm(it);
  }
  function TranslationServiceJsImpl$load$lambda_1($url) {
    return function (it) {
      _get_LOG__e5r759(Companion_getInstance()).kl('Error while loading translations from ' + $url + ': ' + it.toString());
      // Inline function 'kotlin.collections.mapOf' call
      return emptyMap();
    };
  }
  function TranslationServiceJsImpl(baseUrl) {
    Companion_getInstance();
    this.km_1 = baseUrl;
  }
  protoOf(TranslationServiceJsImpl).lm = function (name) {
    var lang = System_getInstance().fm().om_1;
    var url = this.km_1 + '/translation/' + name + '/' + lang;
    var tmp = window.fetch(url);
    var tmp0 = tmp.then(TranslationServiceJsImpl$load$lambda);
    // Inline function 'kotlin.js.then' call
    var onFulfilled = TranslationServiceJsImpl$load$lambda_0;
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    var tmp_0 = tmp0.then(onFulfilled);
    return tmp_0.catch(TranslationServiceJsImpl$load$lambda_1(url));
  };
  function _get_LOG__e5r759_0($this) {
    var tmp0 = $this.pm_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('LOG', 1, tmp, Translations$_get_LOG_$ref_o5a43e(), null);
    return tmp0.j2();
  }
  function Translations$_get_LOG_$ref_o5a43e() {
    return function (p0) {
      return _get_LOG__e5r759_0(p0);
    };
  }
  function Translations$addBundleAsync$lambda($name) {
    return function (translation) {
      // Inline function 'kotlin.collections.forEach' call
      // Inline function 'kotlin.collections.iterator' call
      var _iterator__ex2g4s = translation.d2().i();
      while (_iterator__ex2g4s.j()) {
        var element = _iterator__ex2g4s.k();
        Translations_getInstance().tm(element.i2(), element.j2());
      }
      Translations_getInstance().sm_1.h($name);
      return Unit_instance;
    };
  }
  function Translations() {
    Translations_instance = this;
    this.pm_1 = logger(getKClass(Translations));
    var tmp = this;
    // Inline function 'kotlin.collections.mutableMapOf' call
    tmp.qm_1 = LinkedHashMap_init_$Create$();
    var tmp_0 = this;
    // Inline function 'kotlin.collections.mutableListOf' call
    tmp_0.rm_1 = ArrayList_init_$Create$();
    var tmp_1 = this;
    // Inline function 'kotlin.collections.mutableListOf' call
    tmp_1.sm_1 = ArrayList_init_$Create$();
  }
  protoOf(Translations).um = function (name) {
    this.vm(name);
  };
  protoOf(Translations).vm = function (name) {
    if (!this.ym(name)) {
      _get_LOG__e5r759_0(this).ol("Adding translation bundle '" + name + "'");
      this.rm_1.h(name);
      var tmp = BaseModuleJs_getInstance().xm_1.lm(name);
      return tmp.then(Translations$addBundleAsync$lambda(name));
    }
    return null;
  };
  protoOf(Translations).ym = function (name) {
    return this.sm_1.n(name);
  };
  protoOf(Translations).tm = function (key, value) {
    // Inline function 'kotlin.collections.set' call
    this.qm_1.y1(key, value);
  };
  protoOf(Translations).zm = function (key, params) {
    // Inline function 'kotlin.collections.getOrElse' call
    var tmp0_elvis_lhs = this.qm_1.g2(key);
    var tmp;
    if (tmp0_elvis_lhs == null) {
      tmp = key;
    } else {
      tmp = tmp0_elvis_lhs;
    }
    var value = tmp;
    // Inline function 'kotlin.collections.forEachIndexed' call
    var index = 0;
    var inductionVariable = 0;
    var last = params.length;
    while (inductionVariable < last) {
      var item = params[inductionVariable];
      inductionVariable = inductionVariable + 1 | 0;
      var _unary__edvuaz = index;
      index = _unary__edvuaz + 1 | 0;
      value = replace(value, '{' + _unary__edvuaz + '}', toString(item));
    }
    return value;
  };
  protoOf(Translations).an = function (key) {
    return this.qm_1.g2(key);
  };
  var Translations_instance;
  function Translations_getInstance() {
    if (Translations_instance == null)
      new Translations();
    return Translations_instance;
  }
  function TranslationsOutlet() {
  }
  protoOf(TranslationsOutlet).getString = function (key) {
    return Translations_getInstance().zm(key, []);
  };
  protoOf(TranslationsOutlet).getOptionalString = function (key) {
    return Translations_getInstance().an(key);
  };
  var TranslationsOutlet_instance;
  function TranslationsOutlet_getInstance() {
    return TranslationsOutlet_instance;
  }
  function mpListener(l) {
    return new mpListener$1(l);
  }
  function mpListener$1($l) {
    this.bn_1 = $l;
  }
  protoOf(mpListener$1).propertyChanged = function (e) {
    this.bn_1.propertyChanged(e);
  };
  function lastMoveToEntry($this) {
    var tmp0 = $this.cn_1;
    var tmp$ret$0;
    $l$block: {
      // Inline function 'kotlin.collections.lastOrNull' call
      var iterator = tmp0.v1(tmp0.o());
      while (iterator.n3()) {
        var element = iterator.o3();
        var tmp = element.en_1;
        if (tmp instanceof MoveTo) {
          tmp$ret$0 = element;
          break $l$block;
        }
      }
      tmp$ret$0 = null;
    }
    return tmp$ret$0;
  }
  function MoveTo(p) {
    this.fn_1 = p;
  }
  protoOf(MoveTo).gn = function () {
    return new MoveTo(this.fn_1);
  };
  protoOf(MoveTo).hn = function (path, ctx) {
    ctx.moveTo(this.fn_1.in_1, this.fn_1.jn_1);
  };
  protoOf(MoveTo).kn = function (transform) {
    this.fn_1 = transform.ln(this.fn_1);
  };
  protoOf(MoveTo).toString = function () {
    return 'MoveTo(p=' + this.fn_1.toString() + ')';
  };
  protoOf(MoveTo).hashCode = function () {
    return this.fn_1.hashCode();
  };
  protoOf(MoveTo).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof MoveTo))
      return false;
    if (!this.fn_1.equals(other.fn_1))
      return false;
    return true;
  };
  function LineTo(p) {
    this.mn_1 = p;
  }
  protoOf(LineTo).gn = function () {
    return new LineTo(this.mn_1);
  };
  protoOf(LineTo).hn = function (path, ctx) {
    ctx.lineTo(this.mn_1.in_1, this.mn_1.jn_1);
  };
  protoOf(LineTo).kn = function (transform) {
    this.mn_1 = transform.ln(this.mn_1);
  };
  protoOf(LineTo).toString = function () {
    return 'LineTo(p=' + this.mn_1.toString() + ')';
  };
  protoOf(LineTo).hashCode = function () {
    return this.mn_1.hashCode();
  };
  protoOf(LineTo).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof LineTo))
      return false;
    if (!this.mn_1.equals(other.mn_1))
      return false;
    return true;
  };
  function QuadTo(controlPoint, endPoint) {
    this.nn_1 = controlPoint;
    this.on_1 = endPoint;
  }
  protoOf(QuadTo).gn = function () {
    return new QuadTo(this.nn_1, this.on_1);
  };
  protoOf(QuadTo).hn = function (path, ctx) {
    ctx.quadraticCurveTo(this.nn_1.in_1, this.nn_1.jn_1, this.on_1.in_1, this.on_1.jn_1);
  };
  protoOf(QuadTo).kn = function (transform) {
    this.nn_1 = transform.ln(this.nn_1);
    this.on_1 = transform.ln(this.on_1);
  };
  protoOf(QuadTo).toString = function () {
    return 'QuadTo(controlPoint=' + this.nn_1.toString() + ', endPoint=' + this.on_1.toString() + ')';
  };
  protoOf(QuadTo).hashCode = function () {
    var result = this.nn_1.hashCode();
    result = imul(result, 31) + this.on_1.hashCode() | 0;
    return result;
  };
  protoOf(QuadTo).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof QuadTo))
      return false;
    if (!this.nn_1.equals(other.nn_1))
      return false;
    if (!this.on_1.equals(other.on_1))
      return false;
    return true;
  };
  function CurveTo(cp1, cp2, endPoint) {
    this.pn_1 = cp1;
    this.qn_1 = cp2;
    this.rn_1 = endPoint;
  }
  protoOf(CurveTo).gn = function () {
    return new CurveTo(this.pn_1, this.qn_1, this.rn_1);
  };
  protoOf(CurveTo).hn = function (path, ctx) {
    ctx.bezierCurveTo(this.pn_1.in_1, this.pn_1.jn_1, this.qn_1.in_1, this.qn_1.jn_1, this.rn_1.in_1, this.rn_1.jn_1);
  };
  protoOf(CurveTo).kn = function (transform) {
    this.pn_1 = transform.ln(this.pn_1);
    this.qn_1 = transform.ln(this.qn_1);
    this.rn_1 = transform.ln(this.rn_1);
  };
  protoOf(CurveTo).toString = function () {
    return 'CurveTo(cp1=' + this.pn_1.toString() + ', cp2=' + this.qn_1.toString() + ', endPoint=' + this.rn_1.toString() + ')';
  };
  protoOf(CurveTo).hashCode = function () {
    var result = this.pn_1.hashCode();
    result = imul(result, 31) + this.qn_1.hashCode() | 0;
    result = imul(result, 31) + this.rn_1.hashCode() | 0;
    return result;
  };
  protoOf(CurveTo).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof CurveTo))
      return false;
    if (!this.pn_1.equals(other.pn_1))
      return false;
    if (!this.qn_1.equals(other.qn_1))
      return false;
    if (!this.rn_1.equals(other.rn_1))
      return false;
    return true;
  };
  function ClosePath() {
  }
  protoOf(ClosePath).gn = function () {
    return new ClosePath();
  };
  protoOf(ClosePath).hn = function (path, ctx) {
    var tmp0_safe_receiver = lastMoveToEntry(path);
    if (tmp0_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      var tmp = tmp0_safe_receiver.en_1;
      ctx.lineTo((tmp instanceof MoveTo ? tmp : THROW_CCE()).fn_1.in_1, tmp0_safe_receiver.en_1.fn_1.jn_1);
    }
  };
  protoOf(ClosePath).kn = function (transform) {
  };
  function Entry(command) {
    this.en_1 = command;
  }
  protoOf(Entry).hn = function (path, ctx) {
    this.en_1.hn(path, ctx);
  };
  protoOf(Entry).kn = function (transform) {
    this.en_1.kn(transform);
  };
  protoOf(Entry).toString = function () {
    return 'Entry(command=' + toString(this.en_1) + ')';
  };
  protoOf(Entry).hashCode = function () {
    return hashCode(this.en_1);
  };
  protoOf(Entry).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof Entry))
      return false;
    if (!equals(this.en_1, other.en_1))
      return false;
    return true;
  };
  function Path2DJs(boundingBox) {
    boundingBox = boundingBox === VOID ? new Rectangle2D() : boundingBox;
    var tmp = this;
    // Inline function 'kotlin.collections.mutableListOf' call
    tmp.cn_1 = ArrayList_init_$Create$();
    this.dn_1 = boundingBox;
  }
  protoOf(Path2DJs).gn = function () {
    var clone = new Path2DJs(Rectangle2D_init_$Create$_0(this.dn_1));
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = this.cn_1.i();
    while (_iterator__ex2g4s.j()) {
      var element = _iterator__ex2g4s.k();
      clone.cn_1.h(new Entry(element.en_1.gn()));
    }
    return clone;
  };
  protoOf(Path2DJs).sn = function (x, y) {
    this.dn_1.tn(x, y);
    this.cn_1.h(new Entry(new MoveTo(new Point2D(x, y))));
    return this;
  };
  protoOf(Path2DJs).un = function (x, y) {
    this.dn_1.tn(x, y);
    this.cn_1.h(new Entry(new MoveTo(Point2D_init_$Create$_0(x, y))));
    return this;
  };
  protoOf(Path2DJs).vn = function (x, y) {
    this.dn_1.tn(x, y);
    this.cn_1.h(new Entry(new MoveTo(new Point2D(x, y))));
    return this;
  };
  protoOf(Path2DJs).wn = function (x, y) {
    this.dn_1.tn(x, y);
    this.cn_1.h(new Entry(new LineTo(new Point2D(x, y))));
    return this;
  };
  protoOf(Path2DJs).xn = function (x, y) {
    this.dn_1.tn(x, y);
    this.cn_1.h(new Entry(new LineTo(Point2D_init_$Create$_0(x, y))));
    return this;
  };
  protoOf(Path2DJs).yn = function (x, y) {
    this.dn_1.tn(x, y);
    this.cn_1.h(new Entry(new LineTo(new Point2D(x, y))));
    return this;
  };
  protoOf(Path2DJs).zn = function (x1, y1, x2, y2) {
    this.dn_1.tn(x1, y1);
    this.dn_1.tn(x2, y2);
    this.cn_1.h(new Entry(new QuadTo(new Point2D(x1, y1), new Point2D(x2, y2))));
    return this;
  };
  protoOf(Path2DJs).ao = function (x1, y1, x2, y2, x3, y3) {
    this.dn_1.tn(x1, y1);
    this.dn_1.tn(x2, y2);
    this.dn_1.tn(x3, y3);
    this.cn_1.h(new Entry(new CurveTo(new Point2D(x1, y1), new Point2D(x2, y2), new Point2D(x3, y3))));
    return this;
  };
  protoOf(Path2DJs).bo = function () {
    var tmp0_safe_receiver = lastMoveToEntry(this);
    if (tmp0_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      var tmp = tmp0_safe_receiver.en_1;
      this.dn_1.co((tmp instanceof MoveTo ? tmp : THROW_CCE()).fn_1);
    }
    this.cn_1.h(new Entry(new ClosePath()));
    return this;
  };
  protoOf(Path2DJs).kn = function (transform) {
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = this.cn_1.i();
    while (_iterator__ex2g4s.j()) {
      var element = _iterator__ex2g4s.k();
      element.kn(transform);
    }
  };
  protoOf(Path2DJs).do = function () {
    return this.dn_1;
  };
  protoOf(Path2DJs).eo = function (x, y) {
    return this.dn_1.eo(x, y);
  };
  protoOf(Path2DJs).fo = function (x, y, width, height) {
    return this.dn_1.fo(x, y, width, height);
  };
  protoOf(Path2DJs).go = function (x, y, w, h) {
    return this.dn_1.go(x, y, w, h);
  };
  protoOf(Path2DJs).lo = function (ctx) {
    var _iterator__ex2g4s = this.cn_1.i();
    while (_iterator__ex2g4s.j()) {
      var entry = _iterator__ex2g4s.k();
      entry.hn(this, ctx);
    }
  };
  function InvocationHandlerJs() {
    InvocationHandler.call(this);
  }
  protoOf(InvocationHandlerJs).qo = function (runnable) {
    runnable();
  };
  function BaseModuleJs() {
    BaseModuleJs_instance = this;
    AbstractModule.call(this);
    this.xm_1 = new TranslationServiceJsImpl('http://localhost:8080/api');
  }
  protoOf(BaseModuleJs).ro = function () {
    BaseModule_getInstance().to();
    Companion_getInstance_17().uo_1 = new InvocationHandlerJs();
    BaseModule_getInstance().ap_1 = new RealTimeServiceJs();
  };
  var BaseModuleJs_instance;
  function BaseModuleJs_getInstance() {
    if (BaseModuleJs_instance == null)
      new BaseModuleJs();
    return BaseModuleJs_instance;
  }
  function SoundClipFactory() {
  }
  protoOf(SoundClipFactory).ip = function (path) {
    return SoundClipJs_instance;
  };
  var SoundClipFactory_instance;
  function SoundClipFactory_getInstance() {
    return SoundClipFactory_instance;
  }
  function SoundClipJs() {
  }
  protoOf(SoundClipJs).jp = function () {
  };
  var SoundClipJs_instance;
  function SoundClipJs_getInstance() {
    return SoundClipJs_instance;
  }
  function ToneFactory() {
  }
  protoOf(ToneFactory).kp = function (params) {
    throw UnsupportedOperationException_init_$Create$('not implemented');
  };
  var ToneFactory_instance;
  function ToneFactory_getInstance() {
    return ToneFactory_instance;
  }
  function RealTimeServiceJs() {
  }
  protoOf(RealTimeServiceJs).lp = function () {
    return numberToLong(Date.now());
  };
  protoOf(RealTimeServiceJs).mp = function () {
    return multiply(numberToLong(1000000), this.lp());
  };
  function RealTimeTimerJs$start$lambda(this$0) {
    return function () {
      ensureNotNull(this$0.pp_1)(new ActionEvent(null, window, 0, 'timer', numberToLong((new Date()).getTime())));
      return Unit_instance;
    };
  }
  function RealTimeTimerJs$start$lambda_0(this$0) {
    return function () {
      ensureNotNull(this$0.pp_1)(new ActionEvent(null, window, 0, 'timer', numberToLong((new Date()).getTime())));
      return Unit_instance;
    };
  }
  function RealTimeTimerJs() {
    this.np_1 = null;
    this.op_1 = 0;
    this.pp_1 = null;
    this.qp_1 = true;
  }
  protoOf(RealTimeTimerJs).rp = function (_set____db54di) {
    this.op_1 = _set____db54di;
  };
  protoOf(RealTimeTimerJs).sp = function () {
    return this.op_1;
  };
  protoOf(RealTimeTimerJs).tp = function (interval, repeats, handler) {
    if (this.op_1 > 0) {
      throw IllegalStateException_init_$Create$('already initialized');
    }
    this.op_1 = interval;
    this.pp_1 = handler;
    this.qp_1 = repeats;
    return this;
  };
  protoOf(RealTimeTimerJs).vp = function () {
    if (this.op_1 === 0) {
      throw IllegalStateException_init_$Create$('not yet initialized');
    }
    if (!(this.np_1 == null)) {
      return Unit_instance;
    }
    var tmp = this;
    var tmp_0;
    if (this.qp_1) {
      var tmp_1 = window;
      tmp_0 = tmp_1.setInterval(RealTimeTimerJs$start$lambda(this), this.op_1);
    } else {
      var tmp_2 = window;
      tmp_0 = tmp_2.setTimeout(RealTimeTimerJs$start$lambda_0(this), this.op_1);
    }
    tmp.np_1 = tmp_0;
  };
  protoOf(RealTimeTimerJs).wp = function () {
    if (this.op_1 === 0) {
      throw IllegalStateException_init_$Create$('not yet initialized');
    }
    var tmp0_safe_receiver = this.np_1;
    if (tmp0_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      if (this.qp_1) {
        window.clearInterval(tmp0_safe_receiver);
      } else {
        window.clearTimeout(tmp0_safe_receiver);
      }
      this.np_1 = null;
    }
  };
  protoOf(RealTimeTimerJs).xp = function () {
    return !(this.np_1 == null);
  };
  function Throttle$invokeLast$lambda(this$0) {
    return function () {
      this$0.yp_1();
      this$0.aq_1 = null;
      return Unit_instance;
    };
  }
  function Throttle(function_0, interval) {
    this.yp_1 = function_0;
    this.zp_1 = interval;
    this.aq_1 = null;
  }
  protoOf(Throttle).bq = function () {
    if (this.aq_1 == null) {
      var tmp = this;
      var tmp_0 = window;
      tmp.aq_1 = tmp_0.setTimeout(Throttle$invokeLast$lambda(this), this.zp_1);
    }
  };
  function ActionProperty() {
    this.PROP_NAME = 'name';
    this.PROP_DESCRIPTION = 'description';
    this.PROP_ACCELERATOR = 'accelerator';
    this.PROP_ENABLED = 'enabled';
    this.PROP_SELECTED = 'selected';
    this.PROP_IMAGE_PATH = 'imagePath';
  }
  protoOf(ActionProperty).cq = function () {
    return this.PROP_NAME;
  };
  protoOf(ActionProperty).dq = function () {
    return this.PROP_DESCRIPTION;
  };
  protoOf(ActionProperty).eq = function () {
    return this.PROP_ACCELERATOR;
  };
  protoOf(ActionProperty).fq = function () {
    return this.PROP_ENABLED;
  };
  protoOf(ActionProperty).gq = function () {
    return this.PROP_SELECTED;
  };
  protoOf(ActionProperty).hq = function () {
    return this.PROP_IMAGE_PATH;
  };
  var ActionProperty_instance;
  function ActionProperty_getInstance() {
    return ActionProperty_instance;
  }
  function Action() {
  }
  function Companion_0() {
  }
  protoOf(Companion_0).vq = function (baseName) {
    return Translations_getInstance().zm(baseName + '.name', []);
  };
  protoOf(Companion_0).wq = function (baseName) {
    return Translations_getInstance().an(baseName + '.desc');
  };
  protoOf(Companion_0).xq = function (baseName) {
    return Translations_getInstance().an(System_getInstance().em(baseName));
  };
  var Companion_instance_0;
  function Companion_getInstance_0() {
    return Companion_instance_0;
  }
  function AbstractAction_init_$Init$(baseName, imagePath, opensDialog, $this) {
    imagePath = imagePath === VOID ? null : imagePath;
    opensDialog = opensDialog === VOID ? false : opensDialog;
    AbstractAction.call($this, Companion_instance_0.vq(baseName), Companion_instance_0.wq(baseName), Companion_instance_0.xq(baseName), VOID, VOID, imagePath, opensDialog);
    return $this;
  }
  function AbstractAction$name$$inlined$observable$1($initialValue, this$0) {
    this.zq_1 = this$0;
    ObservableProperty.call(this, $initialValue);
  }
  protoOf(AbstractAction$name$$inlined$observable$1).ar = function (property, oldValue, newValue) {
    this.zq_1.ir_1.lr('name', oldValue, newValue);
    return Unit_instance;
  };
  protoOf(AbstractAction$name$$inlined$observable$1).tf = function (property, oldValue, newValue) {
    return this.ar(property, oldValue, newValue);
  };
  function AbstractAction$_get_name_$ref_109b17() {
    return function (p0) {
      return p0.name;
    };
  }
  function AbstractAction$_set_name_$ref_dt5mhz() {
    return function (p0, p1) {
      p0.iq(p1);
      return Unit_instance;
    };
  }
  function AbstractAction$_get_name_$ref_109b17_0() {
    return function (p0) {
      return p0.name;
    };
  }
  function AbstractAction$_set_name_$ref_dt5mhz_0() {
    return function (p0, p1) {
      p0.iq(p1);
      return Unit_instance;
    };
  }
  function AbstractAction$description$$inlined$observable$1($initialValue, this$0) {
    this.nr_1 = this$0;
    ObservableProperty.call(this, $initialValue);
  }
  protoOf(AbstractAction$description$$inlined$observable$1).ar = function (property, oldValue, newValue) {
    this.nr_1.ir_1.lr('description', oldValue, newValue);
    return Unit_instance;
  };
  protoOf(AbstractAction$description$$inlined$observable$1).tf = function (property, oldValue, newValue) {
    return this.ar(property, oldValue, newValue);
  };
  function AbstractAction$_get_description_$ref_3mhoo() {
    return function (p0) {
      return p0.description;
    };
  }
  function AbstractAction$_set_description_$ref_a7cp78() {
    return function (p0, p1) {
      p0.jq(p1);
      return Unit_instance;
    };
  }
  function AbstractAction$_get_description_$ref_3mhoo_0() {
    return function (p0) {
      return p0.description;
    };
  }
  function AbstractAction$_set_description_$ref_a7cp78_0() {
    return function (p0, p1) {
      p0.jq(p1);
      return Unit_instance;
    };
  }
  function AbstractAction$accelerator$$inlined$observable$1($initialValue, this$0) {
    this.pr_1 = this$0;
    ObservableProperty.call(this, $initialValue);
  }
  protoOf(AbstractAction$accelerator$$inlined$observable$1).ar = function (property, oldValue, newValue) {
    this.pr_1.ir_1.lr('accelerator', oldValue, newValue);
    return Unit_instance;
  };
  protoOf(AbstractAction$accelerator$$inlined$observable$1).tf = function (property, oldValue, newValue) {
    return this.ar(property, oldValue, newValue);
  };
  function AbstractAction$_get_accelerator_$ref_kfihnt() {
    return function (p0) {
      return p0.accelerator;
    };
  }
  function AbstractAction$_set_accelerator_$ref_absa59() {
    return function (p0, p1) {
      p0.lq(p1);
      return Unit_instance;
    };
  }
  function AbstractAction$_get_accelerator_$ref_kfihnt_0() {
    return function (p0) {
      return p0.accelerator;
    };
  }
  function AbstractAction$_set_accelerator_$ref_absa59_0() {
    return function (p0, p1) {
      p0.lq(p1);
      return Unit_instance;
    };
  }
  function AbstractAction$enabled$$inlined$observable$1($initialValue, this$0) {
    this.rr_1 = this$0;
    ObservableProperty.call(this, $initialValue);
  }
  protoOf(AbstractAction$enabled$$inlined$observable$1).ar = function (property, oldValue, newValue) {
    this.rr_1.ir_1.lr('enabled', oldValue, newValue);
    return Unit_instance;
  };
  protoOf(AbstractAction$enabled$$inlined$observable$1).tf = function (property, oldValue, newValue) {
    return this.ar(property, oldValue, newValue);
  };
  function AbstractAction$_get_enabled_$ref_y8lxv1() {
    return function (p0) {
      return p0.enabled;
    };
  }
  function AbstractAction$_set_enabled_$ref_6i3xs7() {
    return function (p0, p1) {
      p0.nq(p1);
      return Unit_instance;
    };
  }
  function AbstractAction$_get_enabled_$ref_y8lxv1_0() {
    return function (p0) {
      return p0.enabled;
    };
  }
  function AbstractAction$_set_enabled_$ref_6i3xs7_0() {
    return function (p0, p1) {
      p0.nq(p1);
      return Unit_instance;
    };
  }
  function AbstractAction$selected$$inlined$observable$1($initialValue, this$0) {
    this.tr_1 = this$0;
    ObservableProperty.call(this, $initialValue);
  }
  protoOf(AbstractAction$selected$$inlined$observable$1).ar = function (property, oldValue, newValue) {
    this.tr_1.ir_1.lr('selected', oldValue, newValue);
    return Unit_instance;
  };
  protoOf(AbstractAction$selected$$inlined$observable$1).tf = function (property, oldValue, newValue) {
    return this.ar(property, oldValue, newValue);
  };
  function AbstractAction$_get_selected_$ref_uj1pcb() {
    return function (p0) {
      return p0.selected;
    };
  }
  function AbstractAction$_set_selected_$ref_ezays7() {
    return function (p0, p1) {
      p0.pq(p1);
      return Unit_instance;
    };
  }
  function AbstractAction$_get_selected_$ref_uj1pcb_0() {
    return function (p0) {
      return p0.selected;
    };
  }
  function AbstractAction$_set_selected_$ref_ezays7_0() {
    return function (p0, p1) {
      p0.pq(p1);
      return Unit_instance;
    };
  }
  function AbstractAction$imagePath$$inlined$observable$1($initialValue, this$0) {
    this.vr_1 = this$0;
    ObservableProperty.call(this, $initialValue);
  }
  protoOf(AbstractAction$imagePath$$inlined$observable$1).ar = function (property, oldValue, newValue) {
    this.vr_1.ir_1.lr('imagePath', oldValue, newValue);
    return Unit_instance;
  };
  protoOf(AbstractAction$imagePath$$inlined$observable$1).tf = function (property, oldValue, newValue) {
    return this.ar(property, oldValue, newValue);
  };
  function AbstractAction$_get_imagePath_$ref_d8tvqk() {
    return function (p0) {
      return p0.imagePath;
    };
  }
  function AbstractAction$_set_imagePath_$ref_1yxmrs() {
    return function (p0, p1) {
      p0.rq(p1);
      return Unit_instance;
    };
  }
  function AbstractAction$_get_imagePath_$ref_d8tvqk_0() {
    return function (p0) {
      return p0.imagePath;
    };
  }
  function AbstractAction$_set_imagePath_$ref_1yxmrs_0() {
    return function (p0, p1) {
      p0.rq(p1);
      return Unit_instance;
    };
  }
  function AbstractAction(name, description, accelerator, enabled, selected, imagePath, opensDialog) {
    enabled = enabled === VOID ? true : enabled;
    selected = selected === VOID ? false : selected;
    imagePath = imagePath === VOID ? null : imagePath;
    opensDialog = opensDialog === VOID ? false : opensDialog;
    this.br_1 = opensDialog;
    var tmp = this;
    // Inline function 'kotlin.properties.Delegates.observable' call
    tmp.cr_1 = new AbstractAction$name$$inlined$observable$1(name, this);
    var tmp_0 = this;
    // Inline function 'kotlin.properties.Delegates.observable' call
    tmp_0.dr_1 = new AbstractAction$description$$inlined$observable$1(description, this);
    var tmp_1 = this;
    // Inline function 'kotlin.properties.Delegates.observable' call
    tmp_1.er_1 = new AbstractAction$accelerator$$inlined$observable$1(accelerator, this);
    var tmp_2 = this;
    // Inline function 'kotlin.properties.Delegates.observable' call
    tmp_2.fr_1 = new AbstractAction$enabled$$inlined$observable$1(enabled, this);
    var tmp_3 = this;
    // Inline function 'kotlin.properties.Delegates.observable' call
    tmp_3.gr_1 = new AbstractAction$selected$$inlined$observable$1(selected, this);
    var tmp_4 = this;
    // Inline function 'kotlin.properties.Delegates.observable' call
    tmp_4.hr_1 = new AbstractAction$imagePath$$inlined$observable$1(imagePath, this);
    this.ir_1 = new PropertyChangeSupport(this);
  }
  protoOf(AbstractAction).tq = function () {
    return this.br_1;
  };
  protoOf(AbstractAction).wr = function () {
    return true;
  };
  protoOf(AbstractAction).iq = function (_set____db54di) {
    var tmp = KMutableProperty1;
    var tmp_0 = AbstractAction$_get_name_$ref_109b17_0();
    return this.cr_1.xf(this, getPropertyCallableRef('name', 1, tmp, tmp_0, AbstractAction$_set_name_$ref_dt5mhz_0()), _set____db54di);
  };
  protoOf(AbstractAction).m2 = function () {
    var tmp = KMutableProperty1;
    var tmp_0 = AbstractAction$_get_name_$ref_109b17();
    return this.cr_1.vf(this, getPropertyCallableRef('name', 1, tmp, tmp_0, AbstractAction$_set_name_$ref_dt5mhz()));
  };
  protoOf(AbstractAction).jq = function (_set____db54di) {
    var tmp = KMutableProperty1;
    var tmp_0 = AbstractAction$_get_description_$ref_3mhoo_0();
    return this.dr_1.xf(this, getPropertyCallableRef('description', 1, tmp, tmp_0, AbstractAction$_set_description_$ref_a7cp78_0()), _set____db54di);
  };
  protoOf(AbstractAction).kq = function () {
    var tmp = KMutableProperty1;
    var tmp_0 = AbstractAction$_get_description_$ref_3mhoo();
    return this.dr_1.vf(this, getPropertyCallableRef('description', 1, tmp, tmp_0, AbstractAction$_set_description_$ref_a7cp78()));
  };
  protoOf(AbstractAction).lq = function (_set____db54di) {
    var tmp = KMutableProperty1;
    var tmp_0 = AbstractAction$_get_accelerator_$ref_kfihnt_0();
    return this.er_1.xf(this, getPropertyCallableRef('accelerator', 1, tmp, tmp_0, AbstractAction$_set_accelerator_$ref_absa59_0()), _set____db54di);
  };
  protoOf(AbstractAction).mq = function () {
    var tmp = KMutableProperty1;
    var tmp_0 = AbstractAction$_get_accelerator_$ref_kfihnt();
    return this.er_1.vf(this, getPropertyCallableRef('accelerator', 1, tmp, tmp_0, AbstractAction$_set_accelerator_$ref_absa59()));
  };
  protoOf(AbstractAction).nq = function (_set____db54di) {
    var tmp = KMutableProperty1;
    var tmp_0 = AbstractAction$_get_enabled_$ref_y8lxv1_0();
    return this.fr_1.xf(this, getPropertyCallableRef('enabled', 1, tmp, tmp_0, AbstractAction$_set_enabled_$ref_6i3xs7_0()), _set____db54di);
  };
  protoOf(AbstractAction).oq = function () {
    var tmp = KMutableProperty1;
    var tmp_0 = AbstractAction$_get_enabled_$ref_y8lxv1();
    return this.fr_1.vf(this, getPropertyCallableRef('enabled', 1, tmp, tmp_0, AbstractAction$_set_enabled_$ref_6i3xs7()));
  };
  protoOf(AbstractAction).pq = function (_set____db54di) {
    var tmp = KMutableProperty1;
    var tmp_0 = AbstractAction$_get_selected_$ref_uj1pcb_0();
    return this.gr_1.xf(this, getPropertyCallableRef('selected', 1, tmp, tmp_0, AbstractAction$_set_selected_$ref_ezays7_0()), _set____db54di);
  };
  protoOf(AbstractAction).qq = function () {
    var tmp = KMutableProperty1;
    var tmp_0 = AbstractAction$_get_selected_$ref_uj1pcb();
    return this.gr_1.vf(this, getPropertyCallableRef('selected', 1, tmp, tmp_0, AbstractAction$_set_selected_$ref_ezays7()));
  };
  protoOf(AbstractAction).rq = function (_set____db54di) {
    var tmp = KMutableProperty1;
    var tmp_0 = AbstractAction$_get_imagePath_$ref_d8tvqk_0();
    return this.hr_1.xf(this, getPropertyCallableRef('imagePath', 1, tmp, tmp_0, AbstractAction$_set_imagePath_$ref_1yxmrs_0()), _set____db54di);
  };
  protoOf(AbstractAction).sq = function () {
    var tmp = KMutableProperty1;
    var tmp_0 = AbstractAction$_get_imagePath_$ref_d8tvqk();
    return this.hr_1.vf(this, getPropertyCallableRef('imagePath', 1, tmp, tmp_0, AbstractAction$_set_imagePath_$ref_1yxmrs()));
  };
  protoOf(AbstractAction).dispose = function () {
  };
  protoOf(AbstractAction).updateEnabled = function () {
    this.nq(this.wr());
  };
  protoOf(AbstractAction).addPropertyChangeListener = function (l) {
    this.ir_1.xr(l);
  };
  protoOf(AbstractAction).removePropertyChangeListener = function (l) {
    this.ir_1.yr(l);
  };
  var DataLocation_Local_instance;
  var DataLocation_Remote_instance;
  function Companion_1() {
    this.zr_1 = 'base.dataLocation';
    this.as_1 = 'base.serverUrl';
  }
  var Companion_instance_1;
  function Companion_getInstance_1() {
    return Companion_instance_1;
  }
  var DataLocation_entriesInitialized;
  function DataLocation_initEntries() {
    if (DataLocation_entriesInitialized)
      return Unit_instance;
    DataLocation_entriesInitialized = true;
    DataLocation_Local_instance = new DataLocation('Local', 0, 'local');
    DataLocation_Remote_instance = new DataLocation('Remote', 1, 'remote');
  }
  function DataLocation(name, ordinal, customName) {
    Enum.call(this, name, ordinal);
    this.ds_1 = customName;
  }
  protoOf(DataLocation).toString = function () {
    var tmp;
    switch (this.l2_1) {
      case 0:
        tmp = Translations_getInstance().zm('base.dataLocation.local.name', []);
        break;
      case 1:
        tmp = Translations_getInstance().zm('base.dataLocation.remote.name', []);
        break;
      default:
        noWhenBranchMatchedException();
        break;
    }
    return tmp;
  };
  function DataLocation_Local_getInstance() {
    DataLocation_initEntries();
    return DataLocation_Local_instance;
  }
  function Disposable() {
  }
  function EmptyHierarchyVisitor() {
  }
  protoOf(EmptyHierarchyVisitor).fs = function (node) {
    return true;
  };
  protoOf(EmptyHierarchyVisitor).gs = function (node) {
    return true;
  };
  protoOf(EmptyHierarchyVisitor).hs = function (node, child) {
    return true;
  };
  protoOf(EmptyHierarchyVisitor).is = function (node) {
    return true;
  };
  function IssueImpl(severity, name, description, origin, context, data, actionHandler) {
    data = data === VOID ? null : data;
    actionHandler = actionHandler === VOID ? null : actionHandler;
    this.js_1 = severity;
    this.ks_1 = name;
    this.ls_1 = description;
    this.ms_1 = origin;
    this.ns_1 = context;
    this.os_1 = data;
    this.ps_1 = actionHandler;
  }
  protoOf(IssueImpl).qs = function () {
    return this.js_1;
  };
  protoOf(IssueImpl).m2 = function () {
    return this.ks_1;
  };
  protoOf(IssueImpl).toString = function () {
    return 'IssueImpl(severity=' + this.js_1.toString() + ', name=' + this.ks_1 + ', description=' + this.ls_1 + ', origin=' + this.ms_1 + ', context=' + this.ns_1 + ', data=' + toString_0(this.os_1) + ', actionHandler=' + toString_0(this.ps_1) + ')';
  };
  protoOf(IssueImpl).hashCode = function () {
    var result = this.js_1.hashCode();
    result = imul(result, 31) + getStringHashCode(this.ks_1) | 0;
    result = imul(result, 31) + (this.ls_1 == null ? 0 : getStringHashCode(this.ls_1)) | 0;
    result = imul(result, 31) + getStringHashCode(this.ms_1) | 0;
    result = imul(result, 31) + (this.ns_1 == null ? 0 : getStringHashCode(this.ns_1)) | 0;
    result = imul(result, 31) + (this.os_1 == null ? 0 : hashCode(this.os_1)) | 0;
    result = imul(result, 31) + (this.ps_1 == null ? 0 : hashCode(this.ps_1)) | 0;
    return result;
  };
  protoOf(IssueImpl).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof IssueImpl))
      return false;
    if (!this.js_1.equals(other.js_1))
      return false;
    if (!(this.ks_1 === other.ks_1))
      return false;
    if (!(this.ls_1 == other.ls_1))
      return false;
    if (!(this.ms_1 === other.ms_1))
      return false;
    if (!(this.ns_1 == other.ns_1))
      return false;
    if (!equals(this.os_1, other.os_1))
      return false;
    if (!equals(this.ps_1, other.ps_1))
      return false;
    return true;
  };
  var IssueSeverity_Warning_instance;
  var IssueSeverity_Error_instance;
  var IssueSeverity_entriesInitialized;
  function IssueSeverity_initEntries() {
    if (IssueSeverity_entriesInitialized)
      return Unit_instance;
    IssueSeverity_entriesInitialized = true;
    IssueSeverity_Warning_instance = new IssueSeverity('Warning', 0);
    IssueSeverity_Error_instance = new IssueSeverity('Error', 1);
  }
  function IssueSeverity(name, ordinal) {
    Enum.call(this, name, ordinal);
  }
  protoOf(IssueSeverity).toString = function () {
    var tmp;
    switch (this.l2_1) {
      case 0:
        tmp = Translations_getInstance().zm('issue.severity.warning.name', []);
        break;
      case 1:
        tmp = Translations_getInstance().zm('issue.severity.error.name', []);
        break;
      default:
        noWhenBranchMatchedException();
        break;
    }
    return tmp;
  };
  function IssueSeverity_Warning_getInstance() {
    IssueSeverity_initEntries();
    return IssueSeverity_Warning_instance;
  }
  function IssueSeverity_Error_getInstance() {
    IssueSeverity_initEntries();
    return IssueSeverity_Error_instance;
  }
  function logger(origin) {
    return LogSystem_getInstance().rl(origin);
  }
  var LogLevel_Error_instance;
  var LogLevel_Warning_instance;
  var LogLevel_Info_instance;
  var LogLevel_Debug_instance;
  var LogLevel_Trace_instance;
  var LogLevel_entriesInitialized;
  function LogLevel_initEntries() {
    if (LogLevel_entriesInitialized)
      return Unit_instance;
    LogLevel_entriesInitialized = true;
    LogLevel_Error_instance = new LogLevel('Error', 0);
    LogLevel_Warning_instance = new LogLevel('Warning', 1);
    LogLevel_Info_instance = new LogLevel('Info', 2);
    LogLevel_Debug_instance = new LogLevel('Debug', 3);
    LogLevel_Trace_instance = new LogLevel('Trace', 4);
  }
  function LogLevel(name, ordinal) {
    Enum.call(this, name, ordinal);
  }
  function LogLevel_Error_getInstance() {
    LogLevel_initEntries();
    return LogLevel_Error_instance;
  }
  function LogLevel_Warning_getInstance() {
    LogLevel_initEntries();
    return LogLevel_Warning_instance;
  }
  function LogLevel_Info_getInstance() {
    LogLevel_initEntries();
    return LogLevel_Info_instance;
  }
  function LogLevel_Debug_getInstance() {
    LogLevel_initEntries();
    return LogLevel_Debug_instance;
  }
  function LogLevel_Trace_getInstance() {
    LogLevel_initEntries();
    return LogLevel_Trace_instance;
  }
  function Companion_2() {
    Companion_instance_2 = this;
    this.rs_1 = new LongValueImpl(0n);
    this.ss_1 = new LongValueImpl(1n);
  }
  var Companion_instance_2;
  function Companion_getInstance_2() {
    if (Companion_instance_2 == null)
      new Companion_2();
    return Companion_instance_2;
  }
  function LongValueImpl(value) {
    Companion_getInstance_2();
    this.ts_1 = value;
  }
  protoOf(LongValueImpl).j2 = function () {
    return this.ts_1;
  };
  protoOf(LongValueImpl).toString = function () {
    return this.ts_1.toString();
  };
  protoOf(LongValueImpl).equals = function (other) {
    if (this === other)
      return true;
    if (other == null || !getKClassFromExpression(this).equals(getKClassFromExpression(other)))
      return false;
    if (!(other instanceof LongValueImpl))
      THROW_CCE();
    return this.ts_1 === other.ts_1;
  };
  protoOf(LongValueImpl).hashCode = function () {
    return getBigIntHashCode(this.ts_1);
  };
  function LongValue() {
  }
  function AbstractModule() {
    this.so_1 = false;
  }
  protoOf(AbstractModule).to = function () {
    if (!this.so_1) {
      this.ro();
      this.so_1 = true;
    }
  };
  function Entry_0(stringValue, objValue, customized) {
    this.us_1 = stringValue;
    this.vs_1 = objValue;
    this.ws_1 = customized;
  }
  protoOf(Entry_0).xs = function (stringValue, objValue, customized) {
    return new Entry_0(stringValue, objValue, customized);
  };
  protoOf(Entry_0).ys = function (stringValue, objValue, customized, $super) {
    stringValue = stringValue === VOID ? this.us_1 : stringValue;
    objValue = objValue === VOID ? this.vs_1 : objValue;
    customized = customized === VOID ? this.ws_1 : customized;
    return $super === VOID ? this.xs(stringValue, objValue, customized) : $super.xs.call(this, stringValue, objValue, customized);
  };
  protoOf(Entry_0).toString = function () {
    return 'Entry(stringValue=' + this.us_1 + ', objValue=' + toString_0(this.vs_1) + ', customized=' + this.ws_1 + ')';
  };
  protoOf(Entry_0).hashCode = function () {
    var result = getStringHashCode(this.us_1);
    result = imul(result, 31) + (this.vs_1 == null ? 0 : hashCode(this.vs_1)) | 0;
    result = imul(result, 31) + getBooleanHashCode(this.ws_1) | 0;
    return result;
  };
  protoOf(Entry_0).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof Entry_0))
      return false;
    if (!(this.us_1 === other.us_1))
      return false;
    if (!equals(this.vs_1, other.vs_1))
      return false;
    if (!(this.ws_1 === other.ws_1))
      return false;
    return true;
  };
  function Properties$entries$delegate$lambda() {
    // Inline function 'kotlin.collections.mutableMapOf' call
    return LinkedHashMap_init_$Create$();
  }
  function Properties$_get_entries_$ref_evzvvl() {
    return function (p0) {
      return p0.d2();
    };
  }
  function Properties() {
    var tmp = this;
    tmp.zs_1 = lazy(Properties$entries$delegate$lambda);
  }
  protoOf(Properties).o = function () {
    return this.d2().o();
  };
  protoOf(Properties).d2 = function () {
    var tmp0 = this.zs_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('entries', 1, tmp, Properties$_get_entries_$ref_evzvvl(), null);
    return tmp0.j2();
  };
  protoOf(Properties).at = function () {
    return this.d2().b2().i();
  };
  protoOf(Properties).bt = function (name) {
    return this.d2().e2(name);
  };
  protoOf(Properties).a2 = function () {
    this.d2().a2();
  };
  protoOf(Properties).ct = function (name, value) {
    var tmp0 = this.d2();
    // Inline function 'kotlin.collections.set' call
    var value_0 = new Entry_0(toString(value), value, false);
    tmp0.y1(name, value_0);
  };
  protoOf(Properties).dt = function (name, value) {
    var tmp0_safe_receiver = this.d2().g2(name);
    if (!equals(value, tmp0_safe_receiver == null ? null : tmp0_safe_receiver.vs_1)) {
      var tmp0 = this.d2();
      // Inline function 'kotlin.collections.set' call
      var value_0 = new Entry_0(toString(value), value, true);
      tmp0.y1(name, value_0);
    }
  };
  protoOf(Properties).et = function (name, value) {
    var tmp0 = this.d2();
    // Inline function 'kotlin.collections.set' call
    var value_0 = new Entry_0(value, null, true);
    tmp0.y1(name, value_0);
  };
  protoOf(Properties).ft = function (name) {
    var entry = this.gt(name);
    if (entry.vs_1 == null) {
      var tmp = entry;
      // Inline function 'kotlin.text.uppercase' call
      // Inline function 'kotlin.js.asDynamic' call
      var tmp$ret$0 = entry.us_1.toUpperCase();
      entry = tmp.ys(VOID, tmp$ret$0 === 'TRUE');
      var tmp0 = this.d2();
      // Inline function 'kotlin.collections.set' call
      var value = entry;
      tmp0.y1(name, value);
    }
    var tmp_0 = entry.vs_1;
    return (!(tmp_0 == null) ? typeof tmp_0 === 'boolean' : false) ? tmp_0 : THROW_CCE();
  };
  protoOf(Properties).ht = function (name) {
    var entry = this.gt(name);
    if (entry.vs_1 == null) {
      entry = entry.ys(VOID, entry.us_1);
      var tmp0 = this.d2();
      // Inline function 'kotlin.collections.set' call
      var value = entry;
      tmp0.y1(name, value);
    }
    var tmp = entry.vs_1;
    return (!(tmp == null) ? typeof tmp === 'string' : false) ? tmp : THROW_CCE();
  };
  protoOf(Properties).it = function (name) {
    var entry = this.gt(name);
    if (entry.vs_1 == null) {
      entry = entry.ys(VOID, toInt(entry.us_1));
      var tmp0 = this.d2();
      // Inline function 'kotlin.collections.set' call
      var value = entry;
      tmp0.y1(name, value);
    }
    var tmp = entry.vs_1;
    return (!(tmp == null) ? typeof tmp === 'number' : false) ? tmp : THROW_CCE();
  };
  protoOf(Properties).jt = function (name) {
    var entry = this.gt(name);
    if (entry.vs_1 == null) {
      var tmp = entry;
      // Inline function 'kotlin.text.toFloat' call
      var this_0 = entry.us_1;
      // Inline function 'kotlin.js.unsafeCast' call
      // Inline function 'kotlin.js.asDynamic' call
      var tmp$ret$0 = toDouble(this_0);
      entry = tmp.ys(VOID, tmp$ret$0);
      var tmp0 = this.d2();
      // Inline function 'kotlin.collections.set' call
      var value = entry;
      tmp0.y1(name, value);
    }
    var tmp_0 = entry.vs_1;
    return (!(tmp_0 == null) ? typeof tmp_0 === 'number' : false) ? tmp_0 : THROW_CCE();
  };
  protoOf(Properties).gt = function (name) {
    var tmp0_elvis_lhs = this.kt(name);
    var tmp;
    if (tmp0_elvis_lhs == null) {
      throw NoSuchElementException_init_$Create$("no property '" + name + "'");
    } else {
      tmp = tmp0_elvis_lhs;
    }
    return tmp;
  };
  protoOf(Properties).kt = function (name) {
    return this.d2().g2(name);
  };
  protoOf(Properties).lt = function (name) {
    return this.gt(name).vs_1;
  };
  protoOf(Properties).mt = function (name) {
    var tmp0_safe_receiver = this.kt(name);
    return tmp0_safe_receiver == null ? null : tmp0_safe_receiver.vs_1;
  };
  function PropertiesProxy(target) {
    Properties.call(this);
    this.ot_1 = target;
  }
  protoOf(PropertiesProxy).kt = function (name) {
    return this.ot_1.kt(name);
  };
  protoOf(PropertiesProxy).ct = function (name, value) {
    this.ot_1.ct(name, value);
  };
  protoOf(PropertiesProxy).dt = function (name, value) {
    this.ot_1.ct(name, value);
  };
  function PreferencesChangedEvent(properties) {
    this.pt_1 = properties;
  }
  protoOf(PreferencesChangedEvent).toString = function () {
    return 'PreferencesChangedEvent(properties=' + toString(this.pt_1) + ')';
  };
  protoOf(PreferencesChangedEvent).hashCode = function () {
    return hashCode(this.pt_1);
  };
  protoOf(PreferencesChangedEvent).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof PreferencesChangedEvent))
      return false;
    if (!equals(this.pt_1, other.pt_1))
      return false;
    return true;
  };
  function _get_values__tel787($this) {
    var tmp0 = $this.qt_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('values', 1, tmp, Settings$_get_values_$ref_qucteh(), null);
    return tmp0.j2();
  }
  function getOptional($this, name) {
    return _get_values__tel787($this).g2(name);
  }
  function Settings$values$delegate$lambda() {
    // Inline function 'kotlin.collections.mutableMapOf' call
    return LinkedHashMap_init_$Create$();
  }
  function Settings$_get_values_$ref_qucteh() {
    return function (p0) {
      return _get_values__tel787(p0);
    };
  }
  function Settings() {
    var tmp = this;
    tmp.qt_1 = lazy(Settings$values$delegate$lambda);
  }
  protoOf(Settings).rt = function (name, defaultValue) {
    var tmp0_elvis_lhs = getOptional(this, name);
    return tmp0_elvis_lhs == null ? defaultValue : tmp0_elvis_lhs;
  };
  protoOf(Settings).st = function (name, defaultValue) {
    var setting = getOptional(this, name);
    if (StringUtils_getInstance().xt(setting)) {
      return defaultValue;
    }
    var tmp;
    if (setting == null) {
      tmp = null;
    } else {
      // Inline function 'kotlin.text.uppercase' call
      // Inline function 'kotlin.js.asDynamic' call
      tmp = setting.toUpperCase();
    }
    return tmp === 'TRUE';
  };
  protoOf(Settings).yt = function (name, defaultValue) {
    var tmp0_safe_receiver = getOptional(this, name);
    var tmp1_elvis_lhs = tmp0_safe_receiver == null ? null : toInt(tmp0_safe_receiver);
    return tmp1_elvis_lhs == null ? defaultValue : tmp1_elvis_lhs;
  };
  protoOf(Settings).ct = function (name, value) {
    var tmp0 = _get_values__tel787(this);
    // Inline function 'kotlin.collections.set' call
    var value_0 = toString(value);
    tmp0.y1(name, value_0);
  };
  function ResettableLazy(initializer) {
    this.zt_1 = initializer;
    this.au_1 = UninitializedValue_instance;
  }
  protoOf(ResettableLazy).j2 = function () {
    if (this.au_1 === UninitializedValue_instance) {
      this.au_1 = this.zt_1();
    }
    return this.au_1;
  };
  protoOf(ResettableLazy).bu = function () {
    this.au_1 = UninitializedValue_instance;
  };
  function resettableLazy(initializer) {
    return new ResettableLazy(initializer);
  }
  function UninitializedValue() {
  }
  var UninitializedValue_instance;
  function UninitializedValue_getInstance() {
    return UninitializedValue_instance;
  }
  function Status() {
    Status_instance = this;
    var tmp = this;
    // Inline function 'kotlin.collections.mutableMapOf' call
    tmp.cu_1 = LinkedHashMap_init_$Create$();
  }
  protoOf(Status).du = function (type, value) {
    var oldValue = this.cu_1.g2(type);
    if (!((value == null ? null : equals(value, oldValue)) === true)) {
      BaseModule_getInstance().zo_1.eu(new StatusEvent(type, value));
      // Inline function 'kotlin.collections.set' call
      this.cu_1.y1(type, value);
    }
  };
  protoOf(Status).fu = function (type, value) {
    var oldValue = this.cu_1.g2(type);
    this.du(type, value);
    return oldValue;
  };
  var Status_instance;
  function Status_getInstance() {
    if (Status_instance == null)
      new Status();
    return Status_instance;
  }
  var StatusType_Large_instance;
  var StatusType_Small_instance;
  var StatusType_Tool_instance;
  var StatusType_entriesInitialized;
  function StatusType_initEntries() {
    if (StatusType_entriesInitialized)
      return Unit_instance;
    StatusType_entriesInitialized = true;
    StatusType_Large_instance = new StatusType('Large', 0);
    StatusType_Small_instance = new StatusType('Small', 1);
    StatusType_Tool_instance = new StatusType('Tool', 2);
  }
  function StatusType(name, ordinal) {
    Enum.call(this, name, ordinal);
  }
  function StatusEvent(type, status) {
    this.gu_1 = type;
    this.hu_1 = status;
  }
  protoOf(StatusEvent).toString = function () {
    return 'StatusEvent(type=' + this.gu_1.toString() + ', status=' + this.hu_1 + ')';
  };
  protoOf(StatusEvent).hashCode = function () {
    var result = this.gu_1.hashCode();
    result = imul(result, 31) + (this.hu_1 == null ? 0 : getStringHashCode(this.hu_1)) | 0;
    return result;
  };
  protoOf(StatusEvent).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof StatusEvent))
      return false;
    if (!this.gu_1.equals(other.gu_1))
      return false;
    if (!(this.hu_1 == other.hu_1))
      return false;
    return true;
  };
  function StatusType_Small_getInstance() {
    StatusType_initEntries();
    return StatusType_Small_instance;
  }
  function StatusType_Tool_getInstance() {
    StatusType_initEntries();
    return StatusType_Tool_instance;
  }
  function StringUtils$fromList$lambda(it) {
    return replace(replace(it, '\\', '\\\\'), ',', '\\,');
  }
  function StringUtils() {
    StringUtils_instance = this;
    this.tt_1 = _Char___init__impl__6a9atx(44);
    this.ut_1 = _Char___init__impl__6a9atx(92);
    this.vt_1 = _Char___init__impl__6a9atx(65534);
    this.wt_1 = _Char___init__impl__6a9atx(65535);
  }
  protoOf(StringUtils).iu = function (s) {
    return s == null || isBlank(s);
  };
  protoOf(StringUtils).xt = function (s) {
    var tmp;
    if (s == null) {
      tmp = true;
    } else {
      // Inline function 'kotlin.text.isEmpty' call
      tmp = charSequenceLength(s) === 0;
    }
    return tmp;
  };
  protoOf(StringUtils).ju = function (s) {
    return !this.xt(s);
  };
  protoOf(StringUtils).ku = function (s) {
    return !this.iu(s);
  };
  protoOf(StringUtils).lu = function (s) {
    if (s == null) {
      return '';
    }
    return s;
  };
  protoOf(StringUtils).mu = function (s, alternative) {
    var tmp;
    if (!this.iu(s)) {
      tmp = ensureNotNull(s);
    } else {
      tmp = alternative;
    }
    return tmp;
  };
  protoOf(StringUtils).nu = function (l, separator) {
    var s = l.toString();
    var result = StringBuilder_init_$Create$();
    var i = 0;
    // Inline function 'kotlin.text.reversed' call
    var indexedObject = toString(reversed(isCharSequence(s) ? s : THROW_CCE()));
    var inductionVariable = 0;
    var last = indexedObject.length;
    while (inductionVariable < last) {
      var c = charCodeAt(indexedObject, inductionVariable);
      inductionVariable = inductionVariable + 1 | 0;
      result.i7(c);
      i = i + 1 | 0;
      if ((i % 3 | 0) === 0 && i < s.length) {
        result.i7(separator);
      }
    }
    // Inline function 'kotlin.text.reversed' call
    var this_0 = result.toString();
    return toString(reversed(isCharSequence(this_0) ? this_0 : THROW_CCE()));
  };
  protoOf(StringUtils).ou = function (l, separator, $super) {
    separator = separator === VOID ? _Char___init__impl__6a9atx(95) : separator;
    return $super === VOID ? this.nu(l, separator) : $super.nu.call(this, l, new Char(separator));
  };
  protoOf(StringUtils).pu = function (list) {
    return joinToString(list, ',', VOID, VOID, VOID, VOID, StringUtils$fromList$lambda);
  };
  protoOf(StringUtils).qu = function (listString) {
    // Inline function 'kotlin.text.isEmpty' call
    if (charSequenceLength(listString) === 0) {
      // Inline function 'kotlin.collections.listOf' call
      return emptyList();
    }
    var s = replace(replace(listString, '\\\\', '\uFFFE'), '\\,', '\uFFFF');
    s = last(s) === _Char___init__impl__6a9atx(92) ? replace(dropLast(s, 1), '\\', '') + toString_1(_Char___init__impl__6a9atx(92)) : replace(s, '\\', '');
    // Inline function 'kotlin.collections.map' call
    var this_0 = split(s, charArrayOf([_Char___init__impl__6a9atx(44)]));
    // Inline function 'kotlin.collections.mapTo' call
    var destination = ArrayList_init_$Create$_0(collectionSizeOrDefault(this_0, 10));
    var _iterator__ex2g4s = this_0.i();
    while (_iterator__ex2g4s.j()) {
      var item = _iterator__ex2g4s.k();
      var tmp$ret$4 = replace_0(replace_0(item, _Char___init__impl__6a9atx(65534), _Char___init__impl__6a9atx(92)), _Char___init__impl__6a9atx(65535), _Char___init__impl__6a9atx(44));
      destination.h(tmp$ret$4);
    }
    return destination;
  };
  protoOf(StringUtils).ru = function (s, length, moreIndicator) {
    var tmp;
    if (s.length > length) {
      tmp = take(s, length) + moreIndicator;
    } else {
      tmp = s;
    }
    return tmp;
  };
  protoOf(StringUtils).su = function (s, length, moreIndicator, $super) {
    moreIndicator = moreIndicator === VOID ? '..' : moreIndicator;
    return $super === VOID ? this.ru(s, length, moreIndicator) : $super.ru.call(this, s, length, moreIndicator);
  };
  protoOf(StringUtils).tu = function (s) {
    // Inline function 'kotlin.text.filter' call
    // Inline function 'kotlin.text.filterTo' call
    var destination = StringBuilder_init_$Create$();
    var inductionVariable = 0;
    var last = charSequenceLength(s);
    if (inductionVariable < last)
      do {
        var index = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        var element = charSequenceGet(s, index);
        if (!isWhitespace(element)) {
          destination.i7(element);
        }
      }
       while (inductionVariable < last);
    return destination.toString();
  };
  var StringUtils_instance;
  function StringUtils_getInstance() {
    if (StringUtils_instance == null)
      new StringUtils();
    return StringUtils_instance;
  }
  function Tooltip_init_$Init$(text, x, y, $this) {
    Tooltip.call($this, text, Companion_instance_15.uu(new Point2D(x, y)));
    return $this;
  }
  function Tooltip_init_$Create$(text, x, y) {
    return Tooltip_init_$Init$(text, x, y, objectCreate(protoOf(Tooltip)));
  }
  function Tooltip(text, sourceRect) {
    this.vu_1 = text;
    this.wu_1 = sourceRect;
  }
  protoOf(Tooltip).toString = function () {
    return 'Tooltip(text=' + this.vu_1 + ', sourceRect=' + toString(this.wu_1) + ')';
  };
  protoOf(Tooltip).hashCode = function () {
    var result = getStringHashCode(this.vu_1);
    result = imul(result, 31) + hashCode(this.wu_1) | 0;
    return result;
  };
  protoOf(Tooltip).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof Tooltip))
      return false;
    if (!(this.vu_1 === other.vu_1))
      return false;
    if (!equals(this.wu_1, other.wu_1))
      return false;
    return true;
  };
  function getLanguage($this, code) {
    var indexedObject = values();
    var inductionVariable = 0;
    var last = indexedObject.length;
    while (inductionVariable < last) {
      var lang = indexedObject[inductionVariable];
      inductionVariable = inductionVariable + 1 | 0;
      if (lang.om_1 === code) {
        return lang;
      }
    }
    return null;
  }
  var Language_English_instance;
  var Language_German_instance;
  function Companion_3() {
    Companion_instance_3 = this;
    this.xu_1 = Language_English_getInstance();
    this.yu_1 = 'base.language';
  }
  protoOf(Companion_3).zu = function (code) {
    var tmp0_elvis_lhs = getLanguage(this, code);
    var tmp;
    if (tmp0_elvis_lhs == null) {
      throw IllegalArgumentException_init_$Create$('unknown Language ' + code);
    } else {
      tmp = tmp0_elvis_lhs;
    }
    return tmp;
  };
  var Companion_instance_3;
  function Companion_getInstance_3() {
    Language_initEntries();
    if (Companion_instance_3 == null)
      new Companion_3();
    return Companion_instance_3;
  }
  function values() {
    return [Language_English_getInstance(), Language_German_getInstance()];
  }
  var Language_entriesInitialized;
  function Language_initEntries() {
    if (Language_entriesInitialized)
      return Unit_instance;
    Language_entriesInitialized = true;
    Language_English_instance = new Language('English', 0, 'en');
    Language_German_instance = new Language('German', 1, 'de');
    Companion_getInstance_3();
  }
  function Language(name, ordinal, code) {
    Enum.call(this, name, ordinal);
    this.om_1 = code;
  }
  protoOf(Language).toString = function () {
    var tmp;
    switch (this.l2_1) {
      case 0:
        tmp = Translations_getInstance().zm('base.language.en.name', []);
        break;
      case 1:
        tmp = Translations_getInstance().zm('base.language.de.name', []);
        break;
      default:
        noWhenBranchMatchedException();
        break;
    }
    return tmp;
  };
  function Language_English_getInstance() {
    Language_initEntries();
    return Language_English_instance;
  }
  function Language_German_getInstance() {
    Language_initEntries();
    return Language_German_instance;
  }
  function UUID(id) {
    this.id = id;
  }
  protoOf(UUID).av = function () {
    return this.id;
  };
  protoOf(UUID).toString = function () {
    return this.id;
  };
  protoOf(UUID).xd = function () {
    return this.id;
  };
  protoOf(UUID).bv = function (id) {
    return new UUID(id);
  };
  protoOf(UUID).copy = function (id, $super) {
    id = id === VOID ? this.id : id;
    return $super === VOID ? this.bv(id) : $super.bv.call(this, id);
  };
  protoOf(UUID).hashCode = function () {
    return getStringHashCode(this.id);
  };
  protoOf(UUID).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof UUID))
      return false;
    if (!(this.id === other.id))
      return false;
    return true;
  };
  function ImmutableList(inner) {
    this.cv_1 = inner;
  }
  protoOf(ImmutableList).m = function () {
    return this.cv_1.m();
  };
  protoOf(ImmutableList).td = function (element) {
    return this.cv_1.n(element);
  };
  protoOf(ImmutableList).n = function (element) {
    if (!true)
      return false;
    return this.td(element);
  };
  protoOf(ImmutableList).i = function () {
    return this.cv_1.i();
  };
  protoOf(ImmutableList).l = function (index) {
    return this.cv_1.l(index);
  };
  protoOf(ImmutableList).dv = function (element) {
    return this.cv_1.p(element);
  };
  protoOf(ImmutableList).p = function (element) {
    if (!true)
      return -1;
    return this.dv(element);
  };
  protoOf(ImmutableList).v1 = function (index) {
    return this.cv_1.v1(index);
  };
  protoOf(ImmutableList).w1 = function (fromIndex, toIndex) {
    return this.cv_1.w1(fromIndex, toIndex);
  };
  protoOf(ImmutableList).o = function () {
    return this.cv_1.o();
  };
  function toImmutableList(_this__u8e3s4) {
    if (_this__u8e3s4 instanceof ImmutableList) {
      return _this__u8e3s4;
    } else {
      return new ImmutableList(_this__u8e3s4);
    }
  }
  function EmptyIterator() {
  }
  protoOf(EmptyIterator).j = function () {
    return false;
  };
  protoOf(EmptyIterator).k = function () {
    throw UnsupportedOperationException_init_$Create$('not implemented');
  };
  function ImmutableSet(inner) {
    this.ev_1 = inner;
  }
  protoOf(ImmutableSet).m = function () {
    return this.ev_1.m();
  };
  protoOf(ImmutableSet).td = function (element) {
    return this.ev_1.n(element);
  };
  protoOf(ImmutableSet).n = function (element) {
    if (!true)
      return false;
    return this.td(element);
  };
  protoOf(ImmutableSet).i = function () {
    return this.ev_1.i();
  };
  protoOf(ImmutableSet).fv = function (elements) {
    return this.ev_1.x1(elements);
  };
  protoOf(ImmutableSet).x1 = function (elements) {
    return this.fv(elements);
  };
  protoOf(ImmutableSet).o = function () {
    return this.ev_1.o();
  };
  function DirectedGraph() {
    var tmp = this;
    // Inline function 'kotlin.collections.mutableMapOf' call
    tmp.gv_1 = LinkedHashMap_init_$Create$();
  }
  protoOf(DirectedGraph).i = function () {
    return this.gv_1.b2().i();
  };
  protoOf(DirectedGraph).hv = function (node) {
    if (this.gv_1.e2(node))
      return false;
    var tmp0 = this.gv_1;
    // Inline function 'kotlin.collections.mutableSetOf' call
    // Inline function 'kotlin.collections.set' call
    var value = LinkedHashSet_init_$Create$();
    tmp0.y1(node, value);
    return true;
  };
  protoOf(DirectedGraph).iv = function (start, dest) {
    if (!this.gv_1.e2(start) || !this.gv_1.e2(dest))
      throw NoSuchElementException_init_$Create$('Both nodes must be in the graph.');
    var tmp0_safe_receiver = this.gv_1.g2(start);
    if (tmp0_safe_receiver == null)
      null;
    else
      tmp0_safe_receiver.h(dest);
  };
  protoOf(DirectedGraph).jv = function (node) {
    var tmp0_elvis_lhs = this.gv_1.g2(node);
    var tmp;
    if (tmp0_elvis_lhs == null) {
      throw NoSuchElementException_init_$Create$('Source node does not exist.');
    } else {
      tmp = tmp0_elvis_lhs;
    }
    var arcs = tmp;
    return new ImmutableSet(arcs);
  };
  function Companion_4() {
  }
  protoOf(Companion_4).kv = function (a, b) {
    // Inline function 'kotlin.collections.mutableSetOf' call
    var product = LinkedHashSet_init_$Create$();
    var _iterator__ex2g4s = a.i();
    while (_iterator__ex2g4s.j()) {
      var first = _iterator__ex2g4s.k();
      var _iterator__ex2g4s_0 = b.i();
      while (_iterator__ex2g4s_0.j()) {
        var second = _iterator__ex2g4s_0.k();
        product.h(new Pair(first, second));
      }
    }
    return product;
  };
  var Companion_instance_4;
  function Companion_getInstance_4() {
    return Companion_instance_4;
  }
  function Pair(first, second) {
    this.lv_1 = first;
    this.mv_1 = second;
  }
  protoOf(Pair).toString = function () {
    return 'Pair(first=' + toString_0(this.lv_1) + ', second=' + toString_0(this.mv_1) + ')';
  };
  protoOf(Pair).hashCode = function () {
    var result = this.lv_1 == null ? 0 : hashCode(this.lv_1);
    result = imul(result, 31) + (this.mv_1 == null ? 0 : hashCode(this.mv_1)) | 0;
    return result;
  };
  protoOf(Pair).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof Pair))
      return false;
    if (!equals(this.lv_1, other.lv_1))
      return false;
    if (!equals(this.mv_1, other.mv_1))
      return false;
    return true;
  };
  function PriorityQueue() {
    var tmp = this;
    // Inline function 'kotlin.collections.mutableListOf' call
    tmp.nv_1 = ArrayList_init_$Create$();
  }
  protoOf(PriorityQueue).o = function () {
    return this.nv_1.o();
  };
  protoOf(PriorityQueue).ov = function () {
    return this.nv_1.m();
  };
  protoOf(PriorityQueue).pv = function () {
    if (this.o() > 0) {
      return this.nv_1.l(0);
    }
    return null;
  };
  protoOf(PriorityQueue).qv = function (elem) {
    this.nv_1.h(elem);
    sort(this.nv_1);
  };
  protoOf(PriorityQueue).rv = function (elem) {
    this.nv_1.h2(elem);
  };
  protoOf(PriorityQueue).sv = function () {
    return toImmutableList(this.nv_1);
  };
  protoOf(PriorityQueue).a2 = function () {
    this.nv_1.a2();
  };
  function Stack() {
    var tmp = this;
    // Inline function 'kotlin.collections.mutableListOf' call
    tmp.tv_1 = ArrayList_init_$Create$();
  }
  protoOf(Stack).o = function () {
    return this.tv_1.o();
  };
  protoOf(Stack).uv = function () {
    return this.tv_1.m();
  };
  protoOf(Stack).vv = function (index) {
    return this.tv_1.l(index);
  };
  protoOf(Stack).wv = function (item) {
    this.tv_1.h(item);
  };
  protoOf(Stack).xv = function () {
    if (this.tv_1.m()) {
      throw new EmptyStackException();
    }
    var obj = this.pv();
    this.tv_1.h3(this.tv_1.o() - 1 | 0);
    return obj;
  };
  protoOf(Stack).pv = function () {
    if (this.tv_1.m()) {
      throw new EmptyStackException();
    }
    return last_0(this.tv_1);
  };
  protoOf(Stack).yv = function () {
    return this.uv() ? null : last_0(this.tv_1);
  };
  protoOf(Stack).a2 = function () {
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = this.tv_1.i();
    while (_iterator__ex2g4s.j()) {
      var element = _iterator__ex2g4s.k();
      if (!(element == null) ? isInterface(element, Disposable) : false) {
        element.es();
      }
    }
    this.tv_1.a2();
  };
  protoOf(Stack).td = function (item) {
    return this.tv_1.n(item);
  };
  function EmptyStackException() {
    extendThrowable(this, 'empty stack');
    captureStack(this, EmptyStackException);
  }
  function explore($this, node, g, ordering, visited, expanded) {
    if (visited.n(node)) {
      if (expanded.n(node)) {
        return Unit_instance;
      }
      throw IllegalArgumentException_init_$Create$('Graph contains a cycle: ' + toString_0(node));
    }
    visited.h(node);
    var _iterator__ex2g4s = g.jv(node).i();
    while (_iterator__ex2g4s.j()) {
      var predecessor = _iterator__ex2g4s.k();
      explore($this, predecessor, g, ordering, visited, expanded);
    }
    ordering.h(node);
    expanded.h(node);
  }
  function reverseGraph($this, g) {
    var result = new DirectedGraph();
    var _iterator__ex2g4s = g.i();
    while (_iterator__ex2g4s.j()) {
      var node = _iterator__ex2g4s.k();
      result.hv(node);
    }
    var _iterator__ex2g4s_0 = g.i();
    while (_iterator__ex2g4s_0.j()) {
      var node_0 = _iterator__ex2g4s_0.k();
      var _iterator__ex2g4s_1 = g.jv(node_0).i();
      while (_iterator__ex2g4s_1.j()) {
        var endpoint = _iterator__ex2g4s_1.k();
        result.iv(endpoint, node_0);
      }
    }
    return result;
  }
  function TopologicalSort() {
  }
  protoOf(TopologicalSort).zv = function (g) {
    var gRev = reverseGraph(this, g);
    // Inline function 'kotlin.collections.mutableListOf' call
    var result = ArrayList_init_$Create$();
    // Inline function 'kotlin.collections.mutableSetOf' call
    var visited = LinkedHashSet_init_$Create$();
    // Inline function 'kotlin.collections.mutableSetOf' call
    var expanded = LinkedHashSet_init_$Create$();
    var _iterator__ex2g4s = gRev.i();
    while (_iterator__ex2g4s.j()) {
      var node = _iterator__ex2g4s.k();
      explore(this, node, gRev, result, visited, expanded);
    }
    return result;
  };
  var TopologicalSort_instance;
  function TopologicalSort_getInstance() {
    return TopologicalSort_instance;
  }
  function postError($this, metaData, msgKey, e) {
    BaseModule_getInstance().zo_1.eu(new IssueImpl(IssueSeverity_Error_getInstance(), Translations_getInstance().zm('base.dsl.scriptError.msg', []), e.toString(), metaData.aw_1, metaData.bw_1));
  }
  function AbstractBaseInterpreter(rootNode, memory) {
    memory = memory === VOID ? new Memory() : memory;
    this.cw_1 = rootNode;
    this.dw_1 = memory;
    this.ew_1 = null;
    this.fw_1 = null;
  }
  protoOf(AbstractBaseInterpreter).gw = function (node) {
    var tmp;
    if (node instanceof Compound) {
      tmp = this.iw(node);
    } else {
      throw new SyntaxError(node.hw(), Translations_getInstance().zm('base.dsl.unknownASTNode.msg', ['' + getKClassFromExpression(node).l9()]));
    }
    return tmp;
  };
  protoOf(AbstractBaseInterpreter).jw = function (params, keepMemory) {
    this.ew_1 = null;
    this.fw_1 = params;
    try {
      return this.gw(this.cw_1);
    }finally {
      if (!keepMemory) {
        this.dw_1.a2();
      }
    }
  };
  protoOf(AbstractBaseInterpreter).ow = function (params, keepMemory, $super) {
    params = params === VOID ? null : params;
    keepMemory = keepMemory === VOID ? false : keepMemory;
    return $super === VOID ? this.jw(params, keepMemory) : $super.jw.call(this, params, keepMemory);
  };
  protoOf(AbstractBaseInterpreter).pw = function (metaData, params, rethrow) {
    var tmp;
    try {
      tmp = this.ow(params);
    } catch ($p) {
      var tmp_0;
      if ($p instanceof DslError) {
        var e = $p;
        postError(this, metaData, 'base.dsl.scriptError.msg', e);
        if (rethrow) {
          throw e;
        }
        tmp_0 = Unit_instance;
      } else {
        if ($p instanceof Exception) {
          var e_0 = $p;
          postError(this, metaData, 'base.dsl.systemError.msg', e_0);
          if (rethrow) {
            throw e_0;
          }
          tmp_0 = Unit_instance;
        } else {
          throw $p;
        }
      }
      tmp = tmp_0;
    }
    return tmp;
  };
  protoOf(AbstractBaseInterpreter).qw = function (metaData, params, rethrow, $super) {
    params = params === VOID ? null : params;
    rethrow = rethrow === VOID ? false : rethrow;
    return $super === VOID ? this.pw(metaData, params, rethrow) : $super.pw.call(this, metaData, params, rethrow);
  };
  protoOf(AbstractBaseInterpreter).iw = function (node) {
    var result = 0n;
    var inductionVariable = 0;
    var last = node.sw_1.o();
    if (inductionVariable < last)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        result = this.gw(node.sw_1.l(i));
        if (!(this.ew_1 == null)) {
          return ensureNotNull(this.ew_1);
        }
      }
       while (inductionVariable < last);
    return result;
  };
  function ActivationRecord() {
  }
  function _get_LOG__e5r759_1($this) {
    var tmp0 = $this.ex_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('LOG', 1, tmp, BaseLexer$Companion$_get_LOG_$ref_95yvtn(), null);
    return tmp0.j2();
  }
  function BaseLexer$Companion$_get_LOG_$ref_95yvtn() {
    return function (p0) {
      return _get_LOG__e5r759_1(p0);
    };
  }
  function Companion_5() {
    Companion_instance_5 = this;
    this.ex_1 = logger(getKClass(BaseLexer));
    var tmp = this;
    // Inline function 'kotlin.collections.mapOf' call
    tmp.fx_1 = emptyMap();
    this.gx_1 = new Token(BaseTokenType_EOF_getInstance());
    this.hx_1 = new Token(BaseTokenType_EOL_getInstance());
    this.ix_1 = new Token(BaseTokenType_DOUBLE_QUOTE_getInstance());
  }
  protoOf(Companion_5).jx = function (value) {
    return new Token(BaseTokenType_ID_getInstance(), value);
  };
  protoOf(Companion_5).kx = function (value) {
    return new Token(BaseTokenType_LITERAL_getInstance(), value);
  };
  var Companion_instance_5;
  function Companion_getInstance_5() {
    if (Companion_instance_5 == null)
      new Companion_5();
    return Companion_instance_5;
  }
  function isComment($this, state) {
    var tmp;
    var tmp_0 = state.mx_1;
    if (equals(tmp_0 == null ? null : new Char(tmp_0), new Char(_Char___init__impl__6a9atx(47)))) {
      var tmp_1 = $this.wx(state);
      tmp = equals(tmp_1 == null ? null : new Char(tmp_1), new Char(_Char___init__impl__6a9atx(47)));
    } else {
      tmp = false;
    }
    return tmp;
  }
  function skipComment($this, state) {
    $l$loop: while (true) {
      var tmp;
      var tmp_0 = state.mx_1;
      if (!((tmp_0 == null ? null : new Char(tmp_0)) == null)) {
        var tmp_1 = state.mx_1;
        tmp = !equals(tmp_1 == null ? null : new Char(tmp_1), new Char(_Char___init__impl__6a9atx(10)));
      } else {
        tmp = false;
      }
      if (!tmp) {
        break $l$loop;
      }
      $this.xx(state);
    }
    $this.xx(state);
  }
  function isIdChar($this, c) {
    return isLetterOrDigit(c) || c === _Char___init__impl__6a9atx(95);
  }
  function quotedId($this, state) {
    var result = StringBuilder_init_$Create$();
    $this.xx(state);
    $l$loop: while (true) {
      var tmp;
      var tmp_0 = state.mx_1;
      if (!((tmp_0 == null ? null : new Char(tmp_0)) == null)) {
        var tmp_1 = state.mx_1;
        tmp = !equals(tmp_1 == null ? null : new Char(tmp_1), new Char(_Char___init__impl__6a9atx(39)));
      } else {
        tmp = false;
      }
      if (!tmp) {
        break $l$loop;
      }
      var tmp_2 = state.mx_1;
      result.g7(tmp_2 == null ? null : new Char(tmp_2));
      $this.xx(state);
    }
    var tmp_3 = state.mx_1;
    if (equals(tmp_3 == null ? null : new Char(tmp_3), new Char(_Char___init__impl__6a9atx(39)))) {
      $this.xx(state);
    } else {
      throw new SyntaxError(state.hw(), Translations_getInstance().zm('base.dsl.expectedSingleQuote.msg', []));
    }
    var id = result.toString();
    if (isBlank(id)) {
      throw new SyntaxError(state.hw(), Translations_getInstance().zm('base.dsl.emptyIdentifier.msg', []));
    }
    return Companion_getInstance_5().jx(id);
  }
  function isString($this, state) {
    var tmp = state.mx_1;
    return ensureNotNull(tmp == null ? null : new Char(tmp)).equals(new Char(_Char___init__impl__6a9atx(34)));
  }
  function string($this, state) {
    var result = StringBuilder_init_$Create$();
    $this.xx(state);
    $l$loop: while (true) {
      var tmp;
      var tmp_0 = state.mx_1;
      if (!((tmp_0 == null ? null : new Char(tmp_0)) == null)) {
        var tmp_1 = state.mx_1;
        tmp = !equals(tmp_1 == null ? null : new Char(tmp_1), new Char(_Char___init__impl__6a9atx(34)));
      } else {
        tmp = false;
      }
      if (!tmp) {
        break $l$loop;
      }
      var tmp_2 = state.mx_1;
      result.g7(tmp_2 == null ? null : new Char(tmp_2));
      $this.xx(state);
    }
    var tmp_3 = state.mx_1;
    if (equals(tmp_3 == null ? null : new Char(tmp_3), new Char(_Char___init__impl__6a9atx(34)))) {
      $this.xx(state);
    } else {
      throw new SyntaxError(state.hw(), Translations_getInstance().zm('base.dsl.expectedDoubleQuote.msg', []));
    }
    return result.toString();
  }
  function BaseLexer(text) {
    Companion_getInstance_5();
    AbstractLexer.call(this, text);
  }
  protoOf(BaseLexer).by = function (state) {
    $l$loop_1: while (true) {
      var tmp = state.mx_1;
      if (!!((tmp == null ? null : new Char(tmp)) == null)) {
        break $l$loop_1;
      }
      if (this.dy(state)) {
        this.cy(state);
        continue $l$loop_1;
      }
      if (isComment(this, state)) {
        this.xx(state);
        this.xx(state);
        skipComment(this, state);
        continue $l$loop_1;
      }
      this.ey(state);
      var token = this.fy(state);
      if (_get_LOG__e5r759_1(Companion_getInstance_5()).ql() && state === this.vx_1) {
        _get_LOG__e5r759_1(Companion_getInstance_5()).ol(token.toString());
      }
      return token;
    }
    return Companion_getInstance_5().gx_1;
  };
  protoOf(BaseLexer).fy = function (state) {
    if (this.hy(state)) {
      return this.gy(state);
    }
    var tmp = state.mx_1;
    if (ensureNotNull(tmp == null ? null : new Char(tmp)).equals(new Char(_Char___init__impl__6a9atx(39)))) {
      return quotedId(this, state);
    }
    var tmp_0 = state.mx_1;
    if (isLetter(ensureNotNull(tmp_0 == null ? null : new Char(tmp_0)).j1_1)) {
      return this.iy(state);
    }
    var tmp_1 = state.mx_1;
    if (ensureNotNull(tmp_1 == null ? null : new Char(tmp_1)).j1_1 === _Char___init__impl__6a9atx(34))
      return this.jy(state, Companion_getInstance_5().ix_1);
    var tmp_2 = state.hw();
    var tmp_3 = Translations_getInstance();
    var tmp_4 = state.mx_1;
    throw new SyntaxError(tmp_2, tmp_3.zm('base.dsl.invalidCharacter.msg', [toString_0(tmp_4 == null ? null : new Char(tmp_4))]));
  };
  protoOf(BaseLexer).ky = function (name) {
    return Companion_getInstance_5().fx_1.g2(name);
  };
  protoOf(BaseLexer).hy = function (state) {
    return this.ly(state) || isString(this, state);
  };
  protoOf(BaseLexer).gy = function (state) {
    var tmp;
    if (this.ly(state)) {
      tmp = this.my(state);
    } else if (isString(this, state)) {
      tmp = Companion_getInstance_5().kx(string(this, state));
    } else {
      throw new SyntaxError(state.hw(), Translations_getInstance().zm('base.dsl.unknownLiteral.msg', []));
    }
    return tmp;
  };
  protoOf(BaseLexer).ly = function (state) {
    var tmp = state.mx_1;
    return isDigit(ensureNotNull(tmp == null ? null : new Char(tmp)).j1_1);
  };
  protoOf(BaseLexer).my = function (state) {
    var result = StringBuilder_init_$Create$();
    $l$loop: while (true) {
      var tmp;
      var tmp_0 = state.mx_1;
      if (!((tmp_0 == null ? null : new Char(tmp_0)) == null)) {
        var tmp_1 = state.mx_1;
        tmp = isDigit(ensureNotNull(tmp_1 == null ? null : new Char(tmp_1)).j1_1);
      } else {
        tmp = false;
      }
      if (!tmp) {
        break $l$loop;
      }
      var tmp_2 = state.mx_1;
      result.g7(tmp_2 == null ? null : new Char(tmp_2));
      this.xx(state);
    }
    var tmp_3 = state.mx_1;
    if (equals(tmp_3 == null ? null : new Char(tmp_3), new Char(_Char___init__impl__6a9atx(46)))) {
      var tmp_4 = state.mx_1;
      result.g7(tmp_4 == null ? null : new Char(tmp_4));
      this.xx(state);
      $l$loop_0: while (true) {
        var tmp_5;
        var tmp_6 = state.mx_1;
        if (!((tmp_6 == null ? null : new Char(tmp_6)) == null)) {
          var tmp_7 = state.mx_1;
          tmp_5 = isDigit(ensureNotNull(tmp_7 == null ? null : new Char(tmp_7)).j1_1);
        } else {
          tmp_5 = false;
        }
        if (!tmp_5) {
          break $l$loop_0;
        }
        var tmp_8 = state.mx_1;
        result.g7(tmp_8 == null ? null : new Char(tmp_8));
        this.xx(state);
      }
      var tmp_9 = Companion_getInstance_5();
      // Inline function 'kotlin.text.toFloat' call
      var this_0 = result.toString();
      // Inline function 'kotlin.js.unsafeCast' call
      // Inline function 'kotlin.js.asDynamic' call
      var tmp$ret$0 = toDouble(this_0);
      return tmp_9.kx(tmp$ret$0);
    } else {
      return Companion_getInstance_5().kx(toLong(result.toString()));
    }
  };
  protoOf(BaseLexer).ny = function (state) {
    var result = StringBuilder_init_$Create$();
    $l$loop: while (true) {
      var tmp;
      var tmp_0 = state.mx_1;
      if (!((tmp_0 == null ? null : new Char(tmp_0)) == null)) {
        var tmp_1 = state.mx_1;
        tmp = isDigit(ensureNotNull(tmp_1 == null ? null : new Char(tmp_1)).j1_1);
      } else {
        tmp = false;
      }
      if (!tmp) {
        break $l$loop;
      }
      var tmp_2 = state.mx_1;
      result.i7(ensureNotNull(tmp_2 == null ? null : new Char(tmp_2)).j1_1);
      this.xx(state);
    }
    try {
      return toLong(result.toString());
    } catch ($p) {
      if ($p instanceof NumberFormatException) {
        var e = $p;
        var tmp_3 = state.hw();
        var tmp_4 = Translations_getInstance();
        // Inline function 'kotlin.text.ifEmpty' call
        var tmp_5;
        // Inline function 'kotlin.text.isEmpty' call
        if (charSequenceLength(result) === 0) {
          var tmp_6 = state.mx_1;
          tmp_5 = tmp_6 == null ? null : new Char(tmp_6);
        } else {
          tmp_5 = result;
        }
        var tmp$ret$0 = tmp_5;
        throw new SyntaxError(tmp_3, tmp_4.zm('base.dsl.illegalNumber.msg', [toString_0(tmp$ret$0)]));
      } else {
        throw $p;
      }
    }
  };
  protoOf(BaseLexer).iy = function (state) {
    var result = StringBuilder_init_$Create$();
    $l$loop: while (true) {
      var tmp;
      var tmp_0 = state.mx_1;
      if (!((tmp_0 == null ? null : new Char(tmp_0)) == null)) {
        var tmp_1 = state.mx_1;
        tmp = isIdChar(this, ensureNotNull(tmp_1 == null ? null : new Char(tmp_1)).j1_1);
      } else {
        tmp = false;
      }
      if (!tmp) {
        break $l$loop;
      }
      var tmp_2 = state.mx_1;
      result.g7(tmp_2 == null ? null : new Char(tmp_2));
      this.xx(state);
    }
    var name = result.toString();
    var tmp0_elvis_lhs = this.ky(name);
    return tmp0_elvis_lhs == null ? Companion_getInstance_5().jx(name) : tmp0_elvis_lhs;
  };
  var BaseTokenType_ID_instance;
  var BaseTokenType_LITERAL_instance;
  var BaseTokenType_EOF_instance;
  var BaseTokenType_EOL_instance;
  var BaseTokenType_DOUBLE_QUOTE_instance;
  var BaseTokenType_SINGLE_QUOTE_instance;
  var BaseTokenType_entriesInitialized;
  function BaseTokenType_initEntries() {
    if (BaseTokenType_entriesInitialized)
      return Unit_instance;
    BaseTokenType_entriesInitialized = true;
    BaseTokenType_ID_instance = new BaseTokenType('ID', 0, 'ID');
    BaseTokenType_LITERAL_instance = new BaseTokenType('LITERAL', 1, 'literal');
    BaseTokenType_EOF_instance = new BaseTokenType('EOF', 2, 'EOF');
    BaseTokenType_EOL_instance = new BaseTokenType('EOL', 3, 'EOL');
    BaseTokenType_DOUBLE_QUOTE_instance = new BaseTokenType('DOUBLE_QUOTE', 4, '"');
    BaseTokenType_SINGLE_QUOTE_instance = new BaseTokenType('SINGLE_QUOTE', 5, "'");
  }
  function BaseTokenType(name, ordinal, id) {
    Enum.call(this, name, ordinal);
    this.ty_1 = id;
  }
  protoOf(BaseTokenType).av = function () {
    return this.ty_1;
  };
  function BaseTokenType_ID_getInstance() {
    BaseTokenType_initEntries();
    return BaseTokenType_ID_instance;
  }
  function BaseTokenType_LITERAL_getInstance() {
    BaseTokenType_initEntries();
    return BaseTokenType_LITERAL_instance;
  }
  function BaseTokenType_EOF_getInstance() {
    BaseTokenType_initEntries();
    return BaseTokenType_EOF_instance;
  }
  function BaseTokenType_EOL_getInstance() {
    BaseTokenType_initEntries();
    return BaseTokenType_EOL_instance;
  }
  function BaseTokenType_DOUBLE_QUOTE_getInstance() {
    BaseTokenType_initEntries();
    return BaseTokenType_DOUBLE_QUOTE_instance;
  }
  function Dsl() {
  }
  protoOf(Dsl).uy = function (script, symbolTable, memory) {
    var parser = BaseModule_getInstance().dp_1(script, BaseModule_getInstance().cp_1(symbolTable));
    var interpreter = BaseModule_getInstance().fp_1(parser.vy(), memory);
    return interpreter.ow();
  };
  var Dsl_instance;
  function Dsl_getInstance() {
    return Dsl_instance;
  }
  function SyntaxError(location, msg) {
    DslError.call(this, location, msg);
    captureStack(this, SyntaxError);
  }
  function DslError(location, msg) {
    extendThrowable(this, msg);
    captureStack(this, DslError);
    this.wy_1 = location;
  }
  protoOf(DslError).toString = function () {
    return Translations_getInstance().zm('base.dsl.error.msg', [ensureNotNull(this.message), this.wy_1]);
  };
  function SemanticError(location, msg) {
    DslError.call(this, location, msg);
    captureStack(this, SemanticError);
  }
  function RuntimeError(location, msg) {
    DslError.call(this, location, msg);
    captureStack(this, RuntimeError);
  }
  function longParam(index, params) {
    if (index >= params.o()) {
      throw new RuntimeError(Companion_getInstance_18().ax_1, Translations_getInstance().zm('base.dsl.notEnoughParameters.msg', []));
    }
    var param = params.l(index);
    if (!(typeof param === 'bigint')) {
      throw new RuntimeError(Companion_getInstance_18().ax_1, Translations_getInstance().zm('base.dsl.expectedNumberParameter.msg', [index + 1 | 0]));
    }
    return param;
  }
  function stringParam(index, params) {
    if (index >= params.o()) {
      throw new RuntimeError(Companion_getInstance_18().ax_1, Translations_getInstance().zm('base.dsl.notEnoughParameters.msg', []));
    }
    var param = params.l(index);
    if (!(typeof param === 'string')) {
      throw new RuntimeError(Companion_getInstance_18().ax_1, Translations_getInstance().zm('base.dsl.expectedStringParameter.msg', [index + 1 | 0]));
    }
    return param;
  }
  function anyParam(index, params) {
    if (index >= params.o()) {
      throw new RuntimeError(Companion_getInstance_18().ax_1, Translations_getInstance().zm('base.dsl.notEnoughParameters.msg', []));
    }
    return params.l(index);
  }
  function log2Impl($this, params, context) {
    context = context === VOID ? null : context;
    return log2_0($this, longParam(0, params));
  }
  function log2_0($this, value) {
    // Inline function 'kotlin.math.log2' call
    var x = toNumber(value);
    // Inline function 'kotlin.math.ceil' call
    var x_0 = log2(x);
    var tmp$ret$1 = Math.ceil(x_0);
    return numberToLong(tmp$ret$1);
  }
  function sam$io_antarescircuit_jabbah_base_dsl_ExternalFunction$0(function_0) {
    this.xy_1 = function_0;
  }
  protoOf(sam$io_antarescircuit_jabbah_base_dsl_ExternalFunction$0).yy = function (params, context) {
    return this.xy_1(params, context);
  };
  protoOf(sam$io_antarescircuit_jabbah_base_dsl_ExternalFunction$0).p2 = function () {
    return this.xy_1;
  };
  protoOf(sam$io_antarescircuit_jabbah_base_dsl_ExternalFunction$0).equals = function (other) {
    var tmp;
    if (!(other == null) ? isInterface(other, ExternalFunction) : false) {
      var tmp_0;
      if (!(other == null) ? isInterface(other, FunctionAdapter) : false) {
        tmp_0 = equals(this.p2(), other.p2());
      } else {
        tmp_0 = false;
      }
      tmp = tmp_0;
    } else {
      tmp = false;
    }
    return tmp;
  };
  protoOf(sam$io_antarescircuit_jabbah_base_dsl_ExternalFunction$0).hashCode = function () {
    return hashCode(this.p2());
  };
  function DslGlobalFunctions$log2Impl$ref(p0) {
    var l = function (_this__u8e3s4, p0_0) {
      var tmp0 = p0;
      return log2Impl(tmp0, _this__u8e3s4, p0_0);
    };
    l.callableName = 'log2Impl';
    return l;
  }
  function DslGlobalFunctions() {
    var tmp = this;
    // Inline function 'kotlin.collections.mutableListOf' call
    tmp.zy_1 = ArrayList_init_$Create$();
    // Inline function 'kotlin.with' call
    this.zy_1.h('log2');
  }
  protoOf(DslGlobalFunctions).az = function (symbolTable) {
    // Inline function 'kotlin.with' call
    var tmp = DslGlobalFunctions$log2Impl$ref(this);
    symbolTable.bz(new ExternalFunctionSymbol('log2', 1, new sam$io_antarescircuit_jabbah_base_dsl_ExternalFunction$0(tmp)));
  };
  function Companion_6() {
    Companion_instance_6 = this;
    this.cz_1 = new Token(DslTokenType_PLUS_getInstance());
    this.dz_1 = new Token(DslTokenType_MINUS_getInstance());
    this.ez_1 = new Token(DslTokenType_MULTIPLY_getInstance());
    this.fz_1 = new Token(DslTokenType_DIVIDE_getInstance());
    this.gz_1 = new Token(DslTokenType_LPAREN_getInstance());
    this.hz_1 = new Token(DslTokenType_RPAREN_getInstance());
    this.iz_1 = new Token(DslTokenType_ASSIGN_getInstance());
    this.jz_1 = new Token(DslTokenType_LCURLEY_getInstance());
    this.kz_1 = new Token(DslTokenType_RCURLEY_getInstance());
    this.lz_1 = new Token(DslTokenType_VAR_getInstance());
    this.mz_1 = new Token(DslTokenType_STORE_getInstance());
    this.nz_1 = new Token(DslTokenType_EQUAL_getInstance());
    this.oz_1 = new Token(DslTokenType_DIFF_getInstance());
    this.pz_1 = new Token(DslTokenType_IF_getInstance());
    this.qz_1 = new Token(DslTokenType_ELSE_getInstance());
    this.rz_1 = new Token(DslTokenType_AND_getInstance());
    this.sz_1 = new Token(DslTokenType_OR_getInstance());
    this.tz_1 = new Token(DslTokenType_NOT_getInstance());
    this.uz_1 = new Token(DslTokenType_GREATER_getInstance());
    this.vz_1 = new Token(DslTokenType_GREATER_EQUAL_getInstance());
    this.wz_1 = new Token(DslTokenType_SMALLER_getInstance());
    this.xz_1 = new Token(DslTokenType_SMALLER_EQUAL_getInstance());
    this.yz_1 = new Token(DslTokenType_SHIFT_LEFT_getInstance());
    this.zz_1 = new Token(DslTokenType_SHIFT_RIGHT_getInstance());
    this.a10_1 = new Token(DslTokenType_MOD_getInstance());
    this.b10_1 = new Token(DslTokenType_WHEN_getInstance());
    this.c10_1 = new Token(DslTokenType_COLON_getInstance());
    this.d10_1 = new Token(DslTokenType_FOR_getInstance());
    this.e10_1 = new Token(DslTokenType_IN_getInstance());
    this.f10_1 = new Token(DslTokenType_TO_getInstance());
    this.g10_1 = new Token(DslTokenType_CARET_getInstance());
    this.h10_1 = new Token(DslTokenType_LEFT_BRACKET_getInstance());
    this.i10_1 = new Token(DslTokenType_RIGHT_BRACKET_getInstance());
    this.j10_1 = new Token(DslTokenType_QUESTION_MARK_getInstance());
    this.k10_1 = new Token(DslTokenType_RETURN_getInstance());
    this.l10_1 = new Token(DslTokenType_INIT_getInstance());
    this.m10_1 = new Token(DslTokenType_AT_getInstance());
    this.n10_1 = new Token(DslTokenType_HASH_getInstance());
    this.o10_1 = new Token(DslTokenType_DOT_getInstance());
    this.p10_1 = new Token(DslTokenType_COMMA_getInstance());
    this.q10_1 = mapOf([to('var', this.lz_1), to('store', this.mz_1), to('if', this.pz_1), to('else', this.qz_1), to('and', this.rz_1), to('or', this.sz_1), to('not', this.tz_1), to('when', this.b10_1), to('for', this.d10_1), to('in', this.e10_1), to('to', this.f10_1), to('return', this.k10_1), to('init', this.l10_1)]);
  }
  protoOf(Companion_6).r10 = function () {
    return this.q10_1.b2();
  };
  var Companion_instance_6;
  function Companion_getInstance_6() {
    if (Companion_instance_6 == null)
      new Companion_6();
    return Companion_instance_6;
  }
  function isEqual($this, state) {
    var tmp;
    var tmp_0 = state.mx_1;
    if (equals(tmp_0 == null ? null : new Char(tmp_0), new Char(_Char___init__impl__6a9atx(61)))) {
      var tmp_1 = $this.wx(state);
      tmp = equals(tmp_1 == null ? null : new Char(tmp_1), new Char(_Char___init__impl__6a9atx(61)));
    } else {
      tmp = false;
    }
    return tmp;
  }
  function isDifferent($this, state) {
    var tmp;
    var tmp_0 = state.mx_1;
    if (equals(tmp_0 == null ? null : new Char(tmp_0), new Char(_Char___init__impl__6a9atx(33)))) {
      var tmp_1 = $this.wx(state);
      tmp = equals(tmp_1 == null ? null : new Char(tmp_1), new Char(_Char___init__impl__6a9atx(61)));
    } else {
      tmp = false;
    }
    return tmp;
  }
  function isSmallerEqual($this, state) {
    var tmp;
    var tmp_0 = state.mx_1;
    if (equals(tmp_0 == null ? null : new Char(tmp_0), new Char(_Char___init__impl__6a9atx(60)))) {
      var tmp_1 = $this.wx(state);
      tmp = equals(tmp_1 == null ? null : new Char(tmp_1), new Char(_Char___init__impl__6a9atx(61)));
    } else {
      tmp = false;
    }
    return tmp;
  }
  function isGreaterEqual($this, state) {
    var tmp;
    var tmp_0 = state.mx_1;
    if (equals(tmp_0 == null ? null : new Char(tmp_0), new Char(_Char___init__impl__6a9atx(62)))) {
      var tmp_1 = $this.wx(state);
      tmp = equals(tmp_1 == null ? null : new Char(tmp_1), new Char(_Char___init__impl__6a9atx(61)));
    } else {
      tmp = false;
    }
    return tmp;
  }
  function isShiftLeft($this, state) {
    var tmp;
    var tmp_0 = state.mx_1;
    if (equals(tmp_0 == null ? null : new Char(tmp_0), new Char(_Char___init__impl__6a9atx(60)))) {
      var tmp_1 = $this.wx(state);
      tmp = equals(tmp_1 == null ? null : new Char(tmp_1), new Char(_Char___init__impl__6a9atx(60)));
    } else {
      tmp = false;
    }
    return tmp;
  }
  function isShiftRight($this, state) {
    var tmp;
    var tmp_0 = state.mx_1;
    if (equals(tmp_0 == null ? null : new Char(tmp_0), new Char(_Char___init__impl__6a9atx(62)))) {
      var tmp_1 = $this.wx(state);
      tmp = equals(tmp_1 == null ? null : new Char(tmp_1), new Char(_Char___init__impl__6a9atx(62)));
    } else {
      tmp = false;
    }
    return tmp;
  }
  function equal($this, state) {
    $this.xx(state);
    $this.xx(state);
    return Companion_getInstance_6().nz_1;
  }
  function diff($this, state) {
    $this.xx(state);
    $this.xx(state);
    return Companion_getInstance_6().oz_1;
  }
  function smallerEqual($this, state) {
    $this.xx(state);
    $this.xx(state);
    return Companion_getInstance_6().xz_1;
  }
  function greaterEqual($this, state) {
    $this.xx(state);
    $this.xx(state);
    return Companion_getInstance_6().vz_1;
  }
  function shiftLeft_0($this, state) {
    $this.xx(state);
    $this.xx(state);
    return Companion_getInstance_6().yz_1;
  }
  function shiftRight_0($this, state) {
    $this.xx(state);
    $this.xx(state);
    return Companion_getInstance_6().zz_1;
  }
  function DslLexer(text) {
    Companion_getInstance_6();
    BaseLexer.call(this, text);
  }
  protoOf(DslLexer).ky = function (name) {
    var tmp0_elvis_lhs = Companion_getInstance_6().q10_1.g2(name);
    return tmp0_elvis_lhs == null ? protoOf(BaseLexer).ky.call(this, name) : tmp0_elvis_lhs;
  };
  protoOf(DslLexer).fy = function (state) {
    if (isEqual(this, state)) {
      return equal(this, state);
    }
    if (isDifferent(this, state)) {
      return diff(this, state);
    }
    if (isSmallerEqual(this, state)) {
      return smallerEqual(this, state);
    }
    if (isGreaterEqual(this, state)) {
      return greaterEqual(this, state);
    }
    if (isShiftLeft(this, state)) {
      return shiftLeft_0(this, state);
    }
    if (isShiftRight(this, state)) {
      return shiftRight_0(this, state);
    }
    var tmp = state.mx_1;
    var tmp0_subject = ensureNotNull(tmp == null ? null : new Char(tmp)).j1_1;
    if (tmp0_subject === _Char___init__impl__6a9atx(47))
      return this.jy(state, Companion_getInstance_6().fz_1);
    else if (tmp0_subject === _Char___init__impl__6a9atx(43))
      return this.jy(state, Companion_getInstance_6().cz_1);
    else if (tmp0_subject === _Char___init__impl__6a9atx(45))
      return this.jy(state, Companion_getInstance_6().dz_1);
    else if (tmp0_subject === _Char___init__impl__6a9atx(42))
      return this.jy(state, Companion_getInstance_6().ez_1);
    else if (tmp0_subject === _Char___init__impl__6a9atx(40))
      return this.jy(state, Companion_getInstance_6().gz_1);
    else if (tmp0_subject === _Char___init__impl__6a9atx(41))
      return this.jy(state, Companion_getInstance_6().hz_1);
    else if (tmp0_subject === _Char___init__impl__6a9atx(61))
      return this.jy(state, Companion_getInstance_6().iz_1);
    else if (tmp0_subject === _Char___init__impl__6a9atx(123))
      return this.jy(state, Companion_getInstance_6().jz_1);
    else if (tmp0_subject === _Char___init__impl__6a9atx(125))
      return this.jy(state, Companion_getInstance_6().kz_1);
    else if (tmp0_subject === _Char___init__impl__6a9atx(60))
      return this.jy(state, Companion_getInstance_6().wz_1);
    else if (tmp0_subject === _Char___init__impl__6a9atx(62))
      return this.jy(state, Companion_getInstance_6().uz_1);
    else if (tmp0_subject === _Char___init__impl__6a9atx(37))
      return this.jy(state, Companion_getInstance_6().a10_1);
    else if (tmp0_subject === _Char___init__impl__6a9atx(58))
      return this.jy(state, Companion_getInstance_6().c10_1);
    else if (tmp0_subject === _Char___init__impl__6a9atx(94))
      return this.jy(state, Companion_getInstance_6().g10_1);
    else if (tmp0_subject === _Char___init__impl__6a9atx(91))
      return this.jy(state, Companion_getInstance_6().h10_1);
    else if (tmp0_subject === _Char___init__impl__6a9atx(93))
      return this.jy(state, Companion_getInstance_6().i10_1);
    else if (tmp0_subject === _Char___init__impl__6a9atx(63))
      return this.jy(state, Companion_getInstance_6().j10_1);
    else if (tmp0_subject === _Char___init__impl__6a9atx(64))
      return this.jy(state, Companion_getInstance_6().m10_1);
    else if (tmp0_subject === _Char___init__impl__6a9atx(35))
      return this.jy(state, Companion_getInstance_6().n10_1);
    else if (tmp0_subject === _Char___init__impl__6a9atx(46))
      return this.jy(state, Companion_getInstance_6().o10_1);
    else if (tmp0_subject === _Char___init__impl__6a9atx(44))
      return this.jy(state, Companion_getInstance_6().p10_1);
    return protoOf(BaseLexer).fy.call(this, state);
  };
  function Companion_7() {
    Companion_instance_7 = this;
    this.v10_1 = setOf([DslTokenType_EQUAL_getInstance(), DslTokenType_DIFF_getInstance(), DslTokenType_SMALLER_getInstance(), DslTokenType_GREATER_getInstance(), DslTokenType_SMALLER_EQUAL_getInstance(), DslTokenType_GREATER_EQUAL_getInstance()]);
    this.w10_1 = setOf([DslTokenType_SHIFT_LEFT_getInstance(), DslTokenType_SHIFT_RIGHT_getInstance()]);
    this.x10_1 = plus(setOf([DslTokenType_MULTIPLY_getInstance(), DslTokenType_DIVIDE_getInstance(), DslTokenType_MOD_getInstance(), DslTokenType_CARET_getInstance()]), this.w10_1);
    this.y10_1 = setOf([DslTokenType_PLUS_getInstance(), DslTokenType_MINUS_getInstance()]);
  }
  var Companion_instance_7;
  function Companion_getInstance_7() {
    if (Companion_instance_7 == null)
      new Companion_7();
    return Companion_instance_7;
  }
  function statementList($this) {
    var node = $this.c11();
    var list = mutableListOf([node]);
    while (!equals(ensureNotNull($this.g11_1).d11_1, BaseTokenType_EOF_getInstance()) && !equals(ensureNotNull($this.g11_1).d11_1, DslTokenType_RCURLEY_getInstance())) {
      list.h($this.c11());
    }
    var tmp0_safe_receiver = lastOrNull(list);
    if (tmp0_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      if (tmp0_safe_receiver instanceof NoOp) {
        removeLast(list);
      }
    }
    return list;
  }
  function lookAheadFromLeftBracket($this) {
    var assocArray_0 = assocArray($this);
    var tmp;
    if (equals(ensureNotNull($this.g11_1).d11_1, DslTokenType_ASSIGN_getInstance())) {
      tmp = $this.h11(assocArray_0);
    } else {
      tmp = assocArray_0;
    }
    return tmp;
  }
  function assignment($this) {
    return $this.h11($this.i11());
  }
  function assocArray($this) {
    // Inline function 'kotlin.let' call
    var location = $this.f11_1.hw();
    var variable = $this.j11();
    $this.k11(DslTokenType_LEFT_BRACKET_getInstance());
    var expr_0 = expr($this);
    $this.k11(DslTokenType_RIGHT_BRACKET_getInstance());
    return new AssocArray(location, variable, expr_0);
  }
  function varDeclaration($this) {
    return declaration($this, DslTokenType_VAR_getInstance(), false);
  }
  function storeDeclaration($this) {
    return declaration($this, DslTokenType_STORE_getInstance(), true);
  }
  function declaration($this, tokenType, store) {
    // Inline function 'kotlin.let' call
    var location = $this.f11_1.hw();
    $this.k11(tokenType);
    var tmp;
    if (equals($this.f11_1.py().d11_1, DslTokenType_ASSIGN_getInstance())) {
      var assignment_0 = assignment($this);
      tmp = new Declaration(location, assignment_0.m11_1, assignment_0.n11_1, store);
    } else {
      tmp = new Declaration(location, $this.i11(), null, store);
    }
    return tmp;
  }
  function ifStatement($this) {
    // Inline function 'kotlin.let' call
    var location = $this.f11_1.hw();
    $this.k11(DslTokenType_IF_getInstance());
    $this.k11(DslTokenType_LPAREN_getInstance());
    var condition = expr($this);
    $this.k11(DslTokenType_RPAREN_getInstance());
    var thenStatement = $this.c11();
    var elseStatement = null;
    if (equals(ensureNotNull($this.g11_1).d11_1, DslTokenType_ELSE_getInstance())) {
      $this.k11(DslTokenType_ELSE_getInstance());
      elseStatement = $this.c11();
    }
    return new IfStatement(location, condition, thenStatement, elseStatement);
  }
  function whenStatement($this) {
    // Inline function 'kotlin.let' call
    var location = $this.f11_1.hw();
    // Inline function 'kotlin.collections.mutableListOf' call
    var clauses = ArrayList_init_$Create$();
    $this.k11(DslTokenType_WHEN_getInstance());
    $this.k11(DslTokenType_LPAREN_getInstance());
    var expr_0 = expr($this);
    $this.k11(DslTokenType_RPAREN_getInstance());
    $this.k11(DslTokenType_LCURLEY_getInstance());
    $l$loop: while (!equals(ensureNotNull($this.g11_1).d11_1, BaseTokenType_EOF_getInstance()) && !equals(ensureNotNull($this.g11_1).d11_1, DslTokenType_RCURLEY_getInstance())) {
      if (equals(ensureNotNull($this.g11_1).d11_1, DslTokenType_ELSE_getInstance())) {
        clauses.h(whenElse($this));
        break $l$loop;
      } else {
        clauses.h(whenThen($this));
      }
    }
    $this.k11(DslTokenType_RCURLEY_getInstance());
    return new WhenStatement(location, expr_0, clauses);
  }
  function whenThen($this) {
    // Inline function 'kotlin.let' call
    var location = $this.f11_1.hw();
    var condition = expr($this);
    $this.k11(DslTokenType_COLON_getInstance());
    return new WhenClause(location, condition, $this.c11());
  }
  function whenElse($this) {
    // Inline function 'kotlin.let' call
    var location = $this.f11_1.hw();
    $this.k11(DslTokenType_ELSE_getInstance());
    $this.k11(DslTokenType_COLON_getInstance());
    return new WhenClause(location, null, $this.c11());
  }
  function forStatement($this) {
    // Inline function 'kotlin.let' call
    var location = $this.f11_1.hw();
    $this.k11(DslTokenType_FOR_getInstance());
    $this.k11(DslTokenType_LPAREN_getInstance());
    var variable = $this.i11();
    $this.k11(DslTokenType_IN_getInstance());
    var inExpr = expr($this);
    $this.k11(DslTokenType_TO_getInstance());
    var toExpr = expr($this);
    $this.k11(DslTokenType_RPAREN_getInstance());
    var statement = $this.c11();
    return new ForStatement(location, variable, inExpr, toExpr, statement);
  }
  function returnStatement($this) {
    // Inline function 'kotlin.let' call
    var location = $this.f11_1.hw();
    $this.k11(DslTokenType_RETURN_getInstance());
    return new ReturnStatement(location, isExpr($this) ? expr($this) : null);
  }
  function functionCall($this) {
    // Inline function 'kotlin.let' call
    var location = $this.f11_1.hw();
    var name = $this.j11();
    // Inline function 'kotlin.collections.mutableListOf' call
    var params = ArrayList_init_$Create$();
    $this.k11(DslTokenType_LPAREN_getInstance());
    if (!equals(ensureNotNull($this.g11_1).d11_1, DslTokenType_RPAREN_getInstance())) {
      params.h(expr($this));
    }
    while (equals(ensureNotNull($this.g11_1).d11_1, DslTokenType_COMMA_getInstance())) {
      $this.k11(DslTokenType_COMMA_getInstance());
      params.h(expr($this));
    }
    $this.k11(DslTokenType_RPAREN_getInstance());
    return new FunctionCall(location, name, params);
  }
  function empty($this) {
    return new NoOp($this.f11_1.hw());
  }
  function expr($this) {
    var node = expr1($this);
    while (equals(ensureNotNull($this.g11_1).d11_1, DslTokenType_OR_getInstance())) {
      // Inline function 'kotlin.let' call
      var location = $this.f11_1.hw();
      var token = ensureNotNull($this.g11_1);
      if (equals(token.d11_1, DslTokenType_OR_getInstance())) {
        $this.k11(token.d11_1);
      } else {
        throw new SyntaxError(location, Translations_getInstance().zm('base.dsl.unexpectedToken.msg', [token.d11_1.av()]));
      }
      node = new BinaryOperation(location, node, token, expr1($this));
    }
    return node;
  }
  function isExpr($this) {
    return isTerm($this);
  }
  function expr1($this) {
    var node = expr2($this);
    while (equals(ensureNotNull($this.g11_1).d11_1, DslTokenType_AND_getInstance())) {
      // Inline function 'kotlin.let' call
      var location = $this.f11_1.hw();
      var token = ensureNotNull($this.g11_1);
      if (equals(token.d11_1, DslTokenType_AND_getInstance())) {
        $this.k11(token.d11_1);
      } else {
        throw new SyntaxError(location, Translations_getInstance().zm('base.dsl.unexpectedToken.msg', [token.d11_1.av()]));
      }
      node = new BinaryOperation(location, node, token, expr2($this));
    }
    return node;
  }
  function expr2($this) {
    var node = expr3($this);
    while (contains(Companion_getInstance_7().v10_1, ensureNotNull($this.g11_1).d11_1)) {
      // Inline function 'kotlin.let' call
      var location = $this.f11_1.hw();
      var token = ensureNotNull($this.g11_1);
      if (contains(Companion_getInstance_7().v10_1, token.d11_1)) {
        $this.k11(token.d11_1);
      } else {
        throw new SyntaxError(location, Translations_getInstance().zm('base.dsl.unexpectedToken.msg', [token.d11_1.av()]));
      }
      node = new BinaryOperation(location, node, token, expr3($this));
    }
    return node;
  }
  function expr3($this) {
    var node = term($this);
    while (contains(Companion_getInstance_7().y10_1, ensureNotNull($this.g11_1).d11_1)) {
      // Inline function 'kotlin.let' call
      var location = $this.f11_1.hw();
      var token = ensureNotNull($this.g11_1);
      if (contains(Companion_getInstance_7().y10_1, token.d11_1)) {
        $this.k11(token.d11_1);
      } else {
        throw new SyntaxError(location, Translations_getInstance().zm('base.dsl.unexpectedToken.msg', [token.d11_1.av()]));
      }
      node = new BinaryOperation(location, node, token, term($this));
    }
    return node;
  }
  function term($this) {
    var node = $this.o11();
    while (contains(Companion_getInstance_7().x10_1, ensureNotNull($this.g11_1).d11_1)) {
      // Inline function 'kotlin.let' call
      var location = $this.f11_1.hw();
      var token = ensureNotNull($this.g11_1);
      if (contains(Companion_getInstance_7().x10_1, token.d11_1)) {
        $this.k11(token.d11_1);
      } else {
        throw new SyntaxError(location, Translations_getInstance().zm('base.dsl.unexpectedToken.msg', [token.d11_1.av()]));
      }
      node = new BinaryOperation(location, node, token, $this.o11());
    }
    return node;
  }
  function isTerm($this) {
    return $this.p11();
  }
  function number($this) {
    var literal = new Literal($this.f11_1.hw(), ensureNotNull($this.g11_1));
    $this.k11(BaseTokenType_LITERAL_getInstance());
    return literal;
  }
  function string_0($this) {
    $this.k11(BaseTokenType_DOUBLE_QUOTE_getInstance());
    var string = new Literal($this.f11_1.hw(), ensureNotNull($this.g11_1));
    $this.k11(BaseTokenType_ID_getInstance());
    $this.k11(BaseTokenType_DOUBLE_QUOTE_getInstance());
    return string;
  }
  function DslParser(lexer, semanticAnalyser) {
    Companion_getInstance_7();
    semanticAnalyser = semanticAnalyser === VOID ? BaseModule_getInstance().cp_1(null) : semanticAnalyser;
    AbstractParser.call(this, lexer);
    this.b11_1 = semanticAnalyser;
  }
  protoOf(DslParser).vy = function () {
    // Inline function 'kotlin.also' call
    var this_0 = new Compound(this.f11_1.hw(), statementList(this));
    var tmp0_safe_receiver = this.b11_1;
    if (tmp0_safe_receiver == null)
      null;
    else {
      tmp0_safe_receiver.q11(this_0);
    }
    return this_0;
  };
  protoOf(DslParser).c11 = function () {
    var tmp0_subject = ensureNotNull(this.g11_1).d11_1;
    return equals(tmp0_subject, BaseTokenType_EOF_getInstance()) ? empty(this) : equals(tmp0_subject, BaseTokenType_ID_getInstance()) ? this.s11() : equals(tmp0_subject, DslTokenType_LCURLEY_getInstance()) ? this.r11() : equals(tmp0_subject, DslTokenType_RCURLEY_getInstance()) ? empty(this) : equals(tmp0_subject, DslTokenType_IF_getInstance()) ? ifStatement(this) : equals(tmp0_subject, DslTokenType_WHEN_getInstance()) ? whenStatement(this) : equals(tmp0_subject, DslTokenType_FOR_getInstance()) ? forStatement(this) : equals(tmp0_subject, DslTokenType_RETURN_getInstance()) ? returnStatement(this) : equals(tmp0_subject, DslTokenType_VAR_getInstance()) ? varDeclaration(this) : equals(tmp0_subject, DslTokenType_STORE_getInstance()) ? storeDeclaration(this) : expr(this);
  };
  protoOf(DslParser).s11 = function () {
    var tmp0_subject = this.f11_1.py().d11_1;
    return equals(tmp0_subject, DslTokenType_ASSIGN_getInstance()) ? assignment(this) : equals(tmp0_subject, DslTokenType_LEFT_BRACKET_getInstance()) ? lookAheadFromLeftBracket(this) : expr(this);
  };
  protoOf(DslParser).h11 = function (variable) {
    // Inline function 'kotlin.let' call
    var location = this.f11_1.hw();
    this.k11(DslTokenType_ASSIGN_getInstance());
    var right = expr(this);
    return new Assignment(location, variable, right);
  };
  protoOf(DslParser).j11 = function () {
    var identifier = ensureNotNull(this.g11_1).t11();
    this.k11(BaseTokenType_ID_getInstance());
    return identifier;
  };
  protoOf(DslParser).i11 = function () {
    var tmp0_subject = this.f11_1.py().d11_1;
    return equals(tmp0_subject, DslTokenType_LEFT_BRACKET_getInstance()) ? assocArray(this) : new Variable(this.f11_1.hw(), this.j11());
  };
  protoOf(DslParser).r11 = function () {
    // Inline function 'kotlin.let' call
    var location = this.f11_1.hw();
    this.k11(DslTokenType_LCURLEY_getInstance());
    var statementList_0 = statementList(this);
    this.k11(DslTokenType_RCURLEY_getInstance());
    return new Block(location, statementList_0);
  };
  protoOf(DslParser).o11 = function () {
    // Inline function 'kotlin.let' call
    var location = this.f11_1.hw();
    var token = ensureNotNull(this.g11_1);
    var tmp0_subject = token.d11_1;
    var tmp;
    if (equals(tmp0_subject, DslTokenType_PLUS_getInstance())) {
      this.k11(DslTokenType_PLUS_getInstance());
      return new UnaryOperation(location, token, this.o11());
    } else if (equals(tmp0_subject, DslTokenType_MINUS_getInstance())) {
      this.k11(DslTokenType_MINUS_getInstance());
      return new UnaryOperation(location, token, this.o11());
    } else if (equals(tmp0_subject, DslTokenType_NOT_getInstance())) {
      this.k11(DslTokenType_NOT_getInstance());
      return new UnaryOperation(location, token, this.o11());
    } else if (equals(tmp0_subject, BaseTokenType_LITERAL_getInstance()) || equals(tmp0_subject, BaseTokenType_DOUBLE_QUOTE_getInstance())) {
      tmp = this.u11();
    } else if (equals(tmp0_subject, DslTokenType_LPAREN_getInstance())) {
      this.k11(DslTokenType_LPAREN_getInstance());
      var node = expr(this);
      this.k11(DslTokenType_RPAREN_getInstance());
      tmp = node;
    } else if (equals(tmp0_subject, BaseTokenType_ID_getInstance())) {
      var tmp_0;
      if (equals(this.f11_1.py().d11_1, DslTokenType_LPAREN_getInstance())) {
        tmp_0 = functionCall(this);
      } else {
        tmp_0 = this.i11();
      }
      tmp = tmp_0;
    } else {
      throw new SyntaxError(location, Translations_getInstance().zm('base.dsl.unexpectedToken.msg', [token.d11_1.av()]));
    }
    return tmp;
  };
  protoOf(DslParser).p11 = function () {
    var tmp0_subject = ensureNotNull(this.g11_1).d11_1;
    return equals(tmp0_subject, DslTokenType_PLUS_getInstance()) ? true : equals(tmp0_subject, DslTokenType_MINUS_getInstance()) ? true : equals(tmp0_subject, DslTokenType_NOT_getInstance()) ? true : equals(tmp0_subject, BaseTokenType_LITERAL_getInstance()) ? true : equals(tmp0_subject, DslTokenType_LPAREN_getInstance()) ? true : equals(tmp0_subject, BaseTokenType_ID_getInstance()) ? true : false;
  };
  protoOf(DslParser).u11 = function () {
    var tmp0_subject = ensureNotNull(this.g11_1).d11_1;
    return equals(tmp0_subject, BaseTokenType_DOUBLE_QUOTE_getInstance()) ? string_0(this) : number(this);
  };
  function Visitor($outer) {
    this.w11_1 = $outer;
    EmptyHierarchyVisitor.call(this);
  }
  protoOf(Visitor).fs = function (node) {
    if (node instanceof Declaration) {
      this.w11_1.a12_1 = node.l12_1.c12_1.e11_1;
      enterDeclaration(this.w11_1, node);
    } else {
      if (node instanceof Assignment) {
        this.w11_1.a12_1 = node.m11_1.c12_1.e11_1;
        this.w11_1.j12(node);
      } else {
        if (node instanceof Block) {
          enterBlock(this.w11_1);
        } else {
          if (node instanceof ForStatement) {
            this.w11_1.a12_1 = node.f12_1.c12_1.e11_1;
            enterForStatement(this.w11_1, node);
          } else {
            if (node instanceof FunctionCall) {
              enterFunctionCall(this.w11_1, node);
            }
          }
        }
      }
    }
    return true;
  };
  protoOf(Visitor).gs = function (node) {
    if (node instanceof Variable) {
      variable(this.w11_1, node);
    }
    return true;
  };
  protoOf(Visitor).is = function (node) {
    if (node instanceof Declaration)
      this.w11_1.a12_1 = null;
    else {
      if (node instanceof Assignment)
        this.w11_1.a12_1 = null;
      else {
        if (node instanceof Block) {
          leaveBlock(this.w11_1);
        } else {
          if (node instanceof ForStatement)
            this.w11_1.a12_1 = null;
        }
      }
    }
    return true;
  };
  function enterDeclaration($this, declaration) {
    if (declaration.n12_1 && !$this.p12()) {
      throw new SemanticError(declaration.hw(), Translations_getInstance().zm('base.dsl.unexpectedStore.msg', []));
    }
    if (declaration.n12_1) {
      var tmp = declaration.l12_1.c12_1.e11_1;
      declareVariableInGlobalScope($this, (!(tmp == null) ? typeof tmp === 'string' : false) ? tmp : THROW_CCE(), declaration.hw());
    } else {
      var tmp_0 = declaration.l12_1.c12_1.e11_1;
      declareVariableInLocalScope($this, (!(tmp_0 == null) ? typeof tmp_0 === 'string' : false) ? tmp_0 : THROW_CCE(), declaration.hw());
    }
  }
  function declareVariableInLocalScope($this, name, location) {
    declareVariable($this, name, $this.y11_1, location);
  }
  function declareVariableInGlobalScope($this, name, location) {
    declareVariable($this, name, $this.x11_1, location);
  }
  function declareVariable($this, name, destinationScope, location) {
    var typeSymbol = (null == null ? true : null instanceof BuiltInTypeSymbol) ? null : THROW_CCE();
    var varSymbol = new VariableSymbol(name, typeSymbol);
    if (destinationScope.q12(name, true)) {
      throw new SemanticError(location, Translations_getInstance().zm('base.dsl.variableAlreadyDeclared.msg', [name]));
    }
    destinationScope.bz(varSymbol);
  }
  function enterForStatement($this, forStatement) {
    var tmp = forStatement.f12_1.c12_1.e11_1;
    declareVariableInLocalScope($this, (!(tmp == null) ? typeof tmp === 'string' : false) ? tmp : THROW_CCE(), forStatement.hw());
  }
  function enterBlock($this) {
    $this.y11_1 = new ScopedSymbolTable('block', $this.y11_1.r12() + 1 | 0, $this.y11_1);
  }
  function enterFunctionCall($this, functionCall) {
    var name = ensureNotNull(functionCall.t12_1.e11_1);
    var tmp0_elvis_lhs = $this.y11_1.w12(name);
    var tmp;
    if (tmp0_elvis_lhs == null) {
      throw new SemanticError(functionCall.hw(), Translations_getInstance().zm('base.dsl.functionNotDefined.msg', [name]));
    } else {
      tmp = tmp0_elvis_lhs;
    }
    var functionSymbol = tmp;
    if (!(functionSymbol instanceof ExternalFunctionSymbol)) {
      throw new SemanticError(functionCall.hw(), Translations_getInstance().zm('base.dsl.expectedFunction.msg', [name]));
    }
    if (!(functionCall.u12_1.o() === functionSymbol.z12_1)) {
      throw new SemanticError(functionCall.hw(), Translations_getInstance().zm('base.dsl.functionParamCount.msg', [name, functionSymbol.z12_1]));
    }
    functionCall.v12_1 = functionSymbol;
  }
  function leaveBlock($this) {
    var tmp0_safe_receiver = $this.y11_1.b13();
    if (tmp0_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      $this.y11_1 = tmp0_safe_receiver;
    }
  }
  function variable($this, variable) {
    var tmp = variable.c12_1.e11_1;
    var name = (!(tmp == null) ? typeof tmp === 'string' : false) ? tmp : THROW_CCE();
    if (!$this.y11_1.c13(name) && !($this.a12_1 === name)) {
      throw new SemanticError(variable.hw(), Translations_getInstance().zm('base.dsl.variableNotDefined.msg', [name]));
    }
  }
  function DslSemanticAnalyser(context) {
    this.x11_1 = new ScopedSymbolTable('global', 1, context);
    this.y11_1 = this.x11_1;
    this.z11_1 = this.d13();
    this.a12_1 = null;
  }
  protoOf(DslSemanticAnalyser).q11 = function (program) {
    program.e13(this.z11_1);
  };
  protoOf(DslSemanticAnalyser).d13 = function () {
    return new Visitor(this);
  };
  protoOf(DslSemanticAnalyser).p12 = function () {
    return this.y11_1.r12() <= 1;
  };
  protoOf(DslSemanticAnalyser).j12 = function (assignment) {
    var tmp = assignment.m11_1.c12_1.e11_1;
    var varName = (!(tmp == null) ? typeof tmp === 'string' : false) ? tmp : THROW_CCE();
    if (!this.y11_1.c13(varName)) {
      throw new SemanticError(assignment.m11_1.hw(), Translations_getInstance().zm('base.dsl.variableNotDefined.msg', [varName]));
    }
  };
  function _get_LOG__e5r759_2($this) {
    var tmp0 = $this.f13_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('LOG', 1, tmp, Interpreter$Companion$_get_LOG_$ref_rm1oyu(), null);
    return tmp0.j2();
  }
  function Interpreter$Companion$_get_LOG_$ref_rm1oyu() {
    return function (p0) {
      return _get_LOG__e5r759_2(p0);
    };
  }
  function Companion_8() {
    Companion_instance_8 = this;
    this.f13_1 = logger(getKClass(Interpreter));
  }
  var Companion_instance_8;
  function Companion_getInstance_8() {
    if (Companion_instance_8 == null)
      new Companion_8();
    return Companion_instance_8;
  }
  function interpretAsLong($this, node) {
    var result = $this.gw(node);
    if (!(typeof result === 'bigint')) {
      throw new RuntimeError(node.hw(), Translations_getInstance().zm('base.dsl.expectedNumber.msg', []));
    }
    return result;
  }
  function block($this, node) {
    $this.dw_1.k13('block');
    var result = $this.iw(node);
    $this.dw_1.l13(node);
    return result;
  }
  function literal($this, node) {
    return ensureNotNull(node.n13_1.e11_1);
  }
  function unaryOperation($this, node) {
    return unaryOpInterpreted($this, node.hw(), node.p13_1.d11_1, $this.gw(node.q13_1));
  }
  function unaryOpInterpreted($this, l, type, value) {
    var tmp;
    if (equals(type, DslTokenType_PLUS_getInstance())) {
      tmp = $this.t13(value, l);
    } else if (equals(type, DslTokenType_MINUS_getInstance())) {
      tmp = $this.s13(value, l);
    } else if (equals(type, DslTokenType_NOT_getInstance())) {
      tmp = $this.r13(value, l);
    } else {
      throw new SyntaxError(l, Translations_getInstance().zm('base.dsl.unknownUnaryOperation.msg', [type.av()]));
    }
    return tmp;
  }
  function assignment_0($this, node) {
    if (!$this.dw_1.u13(node.m11_1)) {
      throw new RuntimeError(node.m11_1.hw(), Translations_getInstance().zm('base.dsl.variableNotDefined.msg', [ensureNotNull(node.m11_1.c12_1.e11_1)]));
    }
    return $this.v13(node.m11_1, $this.gw(node.n11_1));
  }
  function variable_0($this, node) {
    return $this.w13(node);
  }
  function declaration_0($this, node) {
    var tmp;
    if (node.n12_1) {
      tmp = declarationInStore($this, node);
    } else {
      tmp = declarationInScope($this, node);
    }
    return tmp;
  }
  function declarationInStore($this, node) {
    $this.dw_1.x13(node.l12_1, true);
    var tmp0_safe_receiver = node.m12_1;
    var tmp;
    if (tmp0_safe_receiver == null) {
      tmp = null;
    } else {
      // Inline function 'kotlin.let' call
      tmp = $this.gw(tmp0_safe_receiver);
    }
    var value = tmp;
    if (value == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      $this.v13(node.l12_1, value);
    }
    return value == null ? 0n : value;
  }
  function declarationInScope($this, node) {
    if (!$this.dw_1.y13(node.l12_1)) {
      $this.dw_1.x13(node.l12_1, false);
    }
    var tmp0_safe_receiver = node.m12_1;
    var tmp;
    if (tmp0_safe_receiver == null) {
      tmp = null;
    } else {
      // Inline function 'kotlin.let' call
      tmp = $this.gw(tmp0_safe_receiver);
    }
    var value = tmp;
    if (value == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      $this.v13(node.l12_1, value);
    }
    return value == null ? 0n : value;
  }
  function ifStatement_0($this, node) {
    if ($this.d14($this.gw(node.a14_1))) {
      return $this.gw(node.b14_1);
    }
    var tmp0_safe_receiver = node.c14_1;
    var tmp;
    if (tmp0_safe_receiver == null) {
      tmp = null;
    } else {
      // Inline function 'kotlin.let' call
      tmp = $this.gw(tmp0_safe_receiver);
    }
    var tmp1_elvis_lhs = tmp;
    return tmp1_elvis_lhs == null ? 0n : tmp1_elvis_lhs;
  }
  function whenStatement_0($this, node) {
    var expr = $this.gw(node.f14_1);
    var _iterator__ex2g4s = node.g14_1.i();
    while (_iterator__ex2g4s.j()) {
      var clause = _iterator__ex2g4s.k();
      if (clause.i14_1 == null || $this.d14($this.k14(expr, $this.gw(clause.i14_1), clause.hw()))) {
        return $this.gw(clause.j14_1);
      }
    }
    return 0n;
  }
  function forStatement_0($this, node) {
    var startValue = interpretAsLong($this, node.g12_1);
    var endValue = interpretAsLong($this, node.h12_1);
    $this.dw_1.k13('for');
    $this.dw_1.x13(node.f12_1, false);
    if (startValue <= endValue) {
      var inductionVariable = startValue;
      if (inductionVariable <= endValue)
        do {
          var value = inductionVariable;
          inductionVariable = add(inductionVariable, 1n);
          $this.dw_1.ww(node.f12_1, value);
          $this.gw(node.i12_1);
          var tmp0_safe_receiver = $this.ew_1;
          if (tmp0_safe_receiver == null)
            null;
          else {
            // Inline function 'kotlin.let' call
            return tmp0_safe_receiver;
          }
        }
         while (!(value === endValue));
    } else {
      var inductionVariable_0 = startValue;
      if (endValue <= inductionVariable_0)
        do {
          var value_0 = inductionVariable_0;
          inductionVariable_0 = add(inductionVariable_0, -1n);
          $this.dw_1.ww(node.f12_1, value_0);
          $this.gw(node.i12_1);
          var tmp1_safe_receiver = $this.ew_1;
          if (tmp1_safe_receiver == null)
            null;
          else {
            // Inline function 'kotlin.let' call
            return tmp1_safe_receiver;
          }
        }
         while (!(value_0 === endValue));
    }
    $this.dw_1.l13(node);
    return 0n;
  }
  function returnStatement_0($this, node) {
    var tmp = $this;
    var tmp0_safe_receiver = node.m14_1;
    var tmp_0;
    if (tmp0_safe_receiver == null) {
      tmp_0 = null;
    } else {
      // Inline function 'kotlin.let' call
      tmp_0 = $this.gw(tmp0_safe_receiver);
    }
    var tmp1_elvis_lhs = tmp_0;
    tmp.ew_1 = tmp1_elvis_lhs == null ? 0 : tmp1_elvis_lhs;
    return ensureNotNull($this.ew_1);
  }
  function functionCall_0($this, node, context) {
    if (node.v12_1 == null) {
      throw new RuntimeError(node.hw(), Translations_getInstance().zm('base.dsl.noImplementationOfFunction.msg', [ensureNotNull(node.t12_1.e11_1)]));
    }
    try {
      var tmp = ensureNotNull(node.v12_1).a13_1;
      // Inline function 'kotlin.collections.map' call
      var this_0 = node.u12_1;
      // Inline function 'kotlin.collections.mapTo' call
      var destination = ArrayList_init_$Create$_0(collectionSizeOrDefault(this_0, 10));
      var _iterator__ex2g4s = this_0.i();
      while (_iterator__ex2g4s.j()) {
        var item = _iterator__ex2g4s.k();
        var tmp$ret$2 = $this.gw(item);
        destination.h(tmp$ret$2);
      }
      return tmp.yy(destination, context);
    } catch ($p) {
      if ($p instanceof RuntimeError) {
        var e = $p;
        throw new RuntimeError(node.hw(), ensureNotNull(e.message));
      } else {
        throw $p;
      }
    }
  }
  function Interpreter(rootNode, memory) {
    Companion_getInstance_8();
    memory = memory === VOID ? new Memory() : memory;
    AbstractBaseInterpreter.call(this, rootNode, memory);
  }
  protoOf(Interpreter).gw = function (node) {
    try {
      var tmp;
      if (node instanceof Block) {
        tmp = block(this, node);
      } else {
        if (node instanceof NoOp) {
          tmp = 0n;
        } else {
          if (node instanceof UnaryOperation) {
            tmp = unaryOperation(this, node);
          } else {
            if (node instanceof BinaryOperation) {
              tmp = this.n14(node);
            } else {
              if (node instanceof Literal) {
                tmp = literal(this, node);
              } else {
                if (node instanceof Assignment) {
                  tmp = assignment_0(this, node);
                } else {
                  if (node instanceof Variable) {
                    tmp = variable_0(this, node);
                  } else {
                    if (node instanceof Declaration) {
                      tmp = declaration_0(this, node);
                    } else {
                      if (node instanceof IfStatement) {
                        tmp = ifStatement_0(this, node);
                      } else {
                        if (node instanceof WhenStatement) {
                          tmp = whenStatement_0(this, node);
                        } else {
                          if (node instanceof ForStatement) {
                            tmp = forStatement_0(this, node);
                          } else {
                            if (node instanceof ReturnStatement) {
                              tmp = returnStatement_0(this, node);
                            } else {
                              if (node instanceof FunctionCall) {
                                tmp = functionCall_0(this, node, this.fw_1);
                              } else {
                                tmp = protoOf(AbstractBaseInterpreter).gw.call(this, node);
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
      return tmp;
    } catch ($p) {
      if ($p instanceof DslError) {
        var e = $p;
        throw e;
      } else {
        if ($p instanceof Error) {
          var e_0 = $p;
          _get_LOG__e5r759_2(Companion_getInstance_8()).jl('Unexpected error in script interpretation', e_0);
          throw new RuntimeError(node.hw(), Translations_getInstance().zm('base.dsl.systemError.msg', []));
        } else {
          throw $p;
        }
      }
    }
  };
  protoOf(Interpreter).o14 = function (l, type) {
    throw new RuntimeError(l, Translations_getInstance().zm('base.dsl.incompatibleTypes.msg', [type.av()]));
  };
  protoOf(Interpreter).n14 = function (node) {
    return this.t14(node.hw(), node.r14_1.d11_1, this.gw(node.q14_1), this.gw(node.s14_1));
  };
  protoOf(Interpreter).t14 = function (l, type, left, right) {
    var tmp;
    if (equals(type, DslTokenType_PLUS_getInstance())) {
      tmp = this.f15(left, right, l);
    } else if (equals(type, DslTokenType_MINUS_getInstance())) {
      tmp = this.e15(left, right, l);
    } else if (equals(type, DslTokenType_MULTIPLY_getInstance())) {
      tmp = this.d15(left, right, l);
    } else if (equals(type, DslTokenType_DIVIDE_getInstance())) {
      tmp = this.c15(left, right, l);
    } else if (equals(type, DslTokenType_CARET_getInstance())) {
      tmp = this.b15(left, right, l);
    } else if (equals(type, DslTokenType_EQUAL_getInstance())) {
      tmp = this.k14(left, right, l);
    } else if (equals(type, DslTokenType_DIFF_getInstance())) {
      tmp = equals(this.k14(left, right, l), 1n) ? 0n : 1n;
    } else if (equals(type, DslTokenType_SMALLER_getInstance())) {
      tmp = this.a15(left, right, l);
    } else if (equals(type, DslTokenType_SMALLER_EQUAL_getInstance())) {
      tmp = equals(this.a15(left, right, l), 1n) || equals(this.k14(left, right, l), 1n) ? 1n : 0n;
    } else if (equals(type, DslTokenType_GREATER_getInstance())) {
      tmp = this.z14(left, right, l);
    } else if (equals(type, DslTokenType_GREATER_EQUAL_getInstance())) {
      tmp = equals(this.z14(left, right, l), 1n) || equals(this.k14(left, right, l), 1n) ? 1n : 0n;
    } else if (equals(type, DslTokenType_AND_getInstance())) {
      tmp = this.y14(left, right, l);
    } else if (equals(type, DslTokenType_OR_getInstance())) {
      tmp = this.x14(left, right, l);
    } else if (equals(type, DslTokenType_SHIFT_LEFT_getInstance())) {
      tmp = this.w14(left, right, l);
    } else if (equals(type, DslTokenType_SHIFT_RIGHT_getInstance())) {
      tmp = this.v14(left, right, l);
    } else if (equals(type, DslTokenType_MOD_getInstance())) {
      tmp = this.u14(left, right, l);
    } else {
      throw new SyntaxError(l, Translations_getInstance().zm('base.dsl.unknownBinaryOperation.msg', [type.av()]));
    }
    return tmp;
  };
  protoOf(Interpreter).f15 = function (l, r, loc) {
    var tmp;
    if (typeof l === 'bigint') {
      tmp = this.h15(l, r, loc);
    } else {
      if (typeof l === 'number') {
        tmp = this.g15(l, r, loc);
      } else {
        this.o14(loc, DslTokenType_PLUS_getInstance());
      }
    }
    return tmp;
  };
  protoOf(Interpreter).h15 = function (l, r, loc) {
    var tmp;
    if (typeof r === 'bigint') {
      tmp = add(l, r);
    } else {
      if (typeof r === 'number') {
        // Inline function 'kotlin.Long.plus' call
        tmp = toNumber(l) + r;
      } else {
        this.o14(loc, DslTokenType_PLUS_getInstance());
      }
    }
    return tmp;
  };
  protoOf(Interpreter).g15 = function (l, r, loc) {
    var tmp;
    if (typeof r === 'bigint') {
      tmp = l + toNumber(r);
    } else {
      if (typeof r === 'number') {
        tmp = l + r;
      } else {
        this.o14(loc, DslTokenType_PLUS_getInstance());
      }
    }
    return tmp;
  };
  protoOf(Interpreter).e15 = function (l, r, loc) {
    var tmp;
    if (typeof l === 'bigint') {
      tmp = this.j15(l, r, loc);
    } else {
      if (typeof l === 'number') {
        tmp = this.i15(l, r, loc);
      } else {
        this.o14(loc, DslTokenType_MINUS_getInstance());
      }
    }
    return tmp;
  };
  protoOf(Interpreter).j15 = function (l, r, loc) {
    var tmp;
    if (typeof r === 'bigint') {
      tmp = subtract(l, r);
    } else {
      if (typeof r === 'number') {
        // Inline function 'kotlin.Long.minus' call
        tmp = toNumber(l) - r;
      } else {
        this.o14(loc, DslTokenType_MINUS_getInstance());
      }
    }
    return tmp;
  };
  protoOf(Interpreter).i15 = function (l, r, loc) {
    var tmp;
    if (typeof r === 'bigint') {
      tmp = l - toNumber(r);
    } else {
      if (typeof r === 'number') {
        tmp = l - r;
      } else {
        this.o14(loc, DslTokenType_MINUS_getInstance());
      }
    }
    return tmp;
  };
  protoOf(Interpreter).d15 = function (l, r, loc) {
    var tmp;
    if (typeof l === 'bigint') {
      tmp = this.l15(l, r, loc);
    } else {
      if (typeof l === 'number') {
        tmp = this.k15(l, r, loc);
      } else {
        this.o14(loc, DslTokenType_MULTIPLY_getInstance());
      }
    }
    return tmp;
  };
  protoOf(Interpreter).l15 = function (l, r, loc) {
    var tmp;
    if (typeof r === 'bigint') {
      tmp = multiply(l, r);
    } else {
      if (typeof r === 'number') {
        // Inline function 'kotlin.Long.times' call
        tmp = toNumber(l) * r;
      } else {
        this.o14(loc, DslTokenType_MULTIPLY_getInstance());
      }
    }
    return tmp;
  };
  protoOf(Interpreter).k15 = function (l, r, loc) {
    var tmp;
    if (typeof r === 'bigint') {
      tmp = l * toNumber(r);
    } else {
      if (typeof r === 'number') {
        tmp = l * r;
      } else {
        this.o14(loc, DslTokenType_MULTIPLY_getInstance());
      }
    }
    return tmp;
  };
  protoOf(Interpreter).c15 = function (l, r, loc) {
    var tmp;
    if (typeof l === 'bigint') {
      tmp = this.n15(l, r, loc);
    } else {
      if (typeof l === 'number') {
        tmp = this.m15(l, r, loc);
      } else {
        this.o14(loc, DslTokenType_DIVIDE_getInstance());
      }
    }
    return tmp;
  };
  protoOf(Interpreter).n15 = function (l, r, loc) {
    var tmp;
    if (typeof r === 'bigint') {
      tmp = divide(l, r);
    } else {
      if (typeof r === 'number') {
        // Inline function 'kotlin.Long.div' call
        tmp = toNumber(l) / r;
      } else {
        this.o14(loc, DslTokenType_DIVIDE_getInstance());
      }
    }
    return tmp;
  };
  protoOf(Interpreter).m15 = function (l, r, loc) {
    var tmp;
    if (typeof r === 'bigint') {
      tmp = l / toNumber(r);
    } else {
      if (typeof r === 'number') {
        tmp = l / r;
      } else {
        this.o14(loc, DslTokenType_DIVIDE_getInstance());
      }
    }
    return tmp;
  };
  protoOf(Interpreter).b15 = function (l, r, loc) {
    var tmp;
    if (typeof l === 'bigint') {
      tmp = this.p15(l, r, loc);
    } else {
      if (typeof l === 'number') {
        tmp = this.o15(l, r, loc);
      } else {
        this.o14(loc, DslTokenType_CARET_getInstance());
      }
    }
    return tmp;
  };
  protoOf(Interpreter).p15 = function (l, r, loc) {
    var tmp;
    if (typeof r === 'bigint') {
      var tmp0 = toNumber(l);
      // Inline function 'kotlin.math.pow' call
      var n = convertToInt(r);
      var tmp$ret$0 = Math.pow(tmp0, n);
      tmp = numberToLong(tmp$ret$0);
    } else {
      if (typeof r === 'number') {
        // Inline function 'kotlin.math.pow' call
        var this_0 = toNumber(l);
        tmp = Math.pow(this_0, r);
      } else {
        this.o14(loc, DslTokenType_CARET_getInstance());
      }
    }
    return tmp;
  };
  protoOf(Interpreter).o15 = function (l, r, loc) {
    var tmp;
    if (typeof r === 'bigint') {
      // Inline function 'kotlin.math.pow' call
      var n = convertToInt(r);
      tmp = Math.pow(l, n);
    } else {
      if (typeof r === 'number') {
        // Inline function 'kotlin.math.pow' call
        tmp = Math.pow(l, r);
      } else {
        this.o14(loc, DslTokenType_CARET_getInstance());
      }
    }
    return tmp;
  };
  protoOf(Interpreter).k14 = function (l, r, loc) {
    var tmp;
    if (typeof l === 'bigint') {
      tmp = this.r15(l, r, loc);
    } else {
      if (typeof l === 'number') {
        tmp = this.q15(l, r, loc);
      } else {
        this.o14(loc, DslTokenType_EQUAL_getInstance());
      }
    }
    return tmp;
  };
  protoOf(Interpreter).r15 = function (l, r, loc) {
    var tmp;
    if (typeof r === 'bigint') {
      tmp = equals(l, r) ? 1n : 0n;
    } else {
      if (typeof r === 'number') {
        tmp = toNumber(l) === r ? 1n : 0n;
      } else {
        this.o14(loc, DslTokenType_EQUAL_getInstance());
      }
    }
    return tmp;
  };
  protoOf(Interpreter).q15 = function (l, r, loc) {
    var tmp;
    if (typeof r === 'bigint') {
      tmp = l === toNumber(r) ? 1n : 0n;
    } else {
      if (typeof r === 'number') {
        tmp = l === r ? 1n : 0n;
      } else {
        this.o14(loc, DslTokenType_EQUAL_getInstance());
      }
    }
    return tmp;
  };
  protoOf(Interpreter).a15 = function (l, r, loc) {
    var tmp;
    if (typeof l === 'bigint') {
      tmp = this.t15(l, r, loc);
    } else {
      if (typeof l === 'number') {
        tmp = this.s15(l, r, loc);
      } else {
        this.o14(loc, DslTokenType_SMALLER_getInstance());
      }
    }
    return tmp;
  };
  protoOf(Interpreter).t15 = function (l, r, loc) {
    var tmp;
    if (typeof r === 'bigint') {
      tmp = l < r ? 1n : 0n;
    } else {
      if (typeof r === 'number') {
        tmp = toNumber(l) < r ? 1n : 0n;
      } else {
        this.o14(loc, DslTokenType_SMALLER_getInstance());
      }
    }
    return tmp;
  };
  protoOf(Interpreter).s15 = function (l, r, loc) {
    var tmp;
    if (typeof r === 'bigint') {
      tmp = l < toNumber(r) ? 1n : 0n;
    } else {
      if (typeof r === 'number') {
        tmp = l < r ? 1n : 0n;
      } else {
        this.o14(loc, DslTokenType_SMALLER_getInstance());
      }
    }
    return tmp;
  };
  protoOf(Interpreter).z14 = function (l, r, loc) {
    var tmp;
    if (typeof l === 'bigint') {
      tmp = this.v15(l, r, loc);
    } else {
      if (typeof l === 'number') {
        tmp = this.u15(l, r, loc);
      } else {
        this.o14(loc, DslTokenType_GREATER_getInstance());
      }
    }
    return tmp;
  };
  protoOf(Interpreter).v15 = function (l, r, loc) {
    var tmp;
    if (typeof r === 'bigint') {
      tmp = l > r ? 1n : 0n;
    } else {
      if (typeof r === 'number') {
        tmp = toNumber(l) > r ? 1n : 0n;
      } else {
        this.o14(loc, DslTokenType_GREATER_getInstance());
      }
    }
    return tmp;
  };
  protoOf(Interpreter).u15 = function (l, r, loc) {
    var tmp;
    if (typeof r === 'bigint') {
      tmp = l > toNumber(r) ? 1n : 0n;
    } else {
      if (typeof r === 'number') {
        tmp = l > r ? 1n : 0n;
      } else {
        this.o14(loc, DslTokenType_GREATER_getInstance());
      }
    }
    return tmp;
  };
  protoOf(Interpreter).y14 = function (l, r, loc) {
    var tmp;
    if (typeof l === 'bigint') {
      tmp = this.w15(l, r, loc);
    } else {
      this.o14(loc, DslTokenType_AND_getInstance());
    }
    return tmp;
  };
  protoOf(Interpreter).w15 = function (l, r, loc) {
    var tmp;
    if (typeof r === 'bigint') {
      tmp = l & r;
    } else {
      this.o14(loc, DslTokenType_AND_getInstance());
    }
    return tmp;
  };
  protoOf(Interpreter).x14 = function (l, r, loc) {
    var tmp;
    if (typeof l === 'bigint') {
      tmp = this.x15(l, r, loc);
    } else {
      this.o14(loc, DslTokenType_OR_getInstance());
    }
    return tmp;
  };
  protoOf(Interpreter).x15 = function (l, r, loc) {
    var tmp;
    if (typeof r === 'bigint') {
      tmp = l | r;
    } else {
      this.o14(loc, DslTokenType_OR_getInstance());
    }
    return tmp;
  };
  protoOf(Interpreter).w14 = function (l, r, loc) {
    var tmp;
    if (typeof l === 'bigint') {
      tmp = this.y15(l, r, loc);
    } else {
      this.o14(loc, DslTokenType_SHIFT_LEFT_getInstance());
    }
    return tmp;
  };
  protoOf(Interpreter).y15 = function (l, r, loc) {
    var tmp;
    if (typeof r === 'bigint') {
      tmp = shiftLeft(l, convertToInt(r));
    } else {
      this.o14(loc, DslTokenType_SHIFT_LEFT_getInstance());
    }
    return tmp;
  };
  protoOf(Interpreter).v14 = function (l, r, loc) {
    var tmp;
    if (typeof l === 'bigint') {
      tmp = this.z15(l, r, loc);
    } else {
      this.o14(loc, DslTokenType_SHIFT_RIGHT_getInstance());
    }
    return tmp;
  };
  protoOf(Interpreter).z15 = function (l, r, loc) {
    var tmp;
    if (typeof r === 'bigint') {
      tmp = shiftRight(l, convertToInt(r));
    } else {
      this.o14(loc, DslTokenType_SHIFT_RIGHT_getInstance());
    }
    return tmp;
  };
  protoOf(Interpreter).u14 = function (l, r, loc) {
    var tmp;
    if (typeof l === 'bigint') {
      tmp = this.a16(l, r, loc);
    } else {
      this.o14(loc, DslTokenType_MOD_getInstance());
    }
    return tmp;
  };
  protoOf(Interpreter).a16 = function (l, r, loc) {
    var tmp;
    if (typeof r === 'bigint') {
      // Inline function 'kotlin.mod' call
      var r_0 = modulo(l, r);
      tmp = add(r_0, r & shiftRight((r_0 ^ r) & (r_0 | negate(r_0)), 63));
    } else {
      this.o14(loc, DslTokenType_MOD_getInstance());
    }
    return tmp;
  };
  protoOf(Interpreter).t13 = function (value, loc) {
    var tmp;
    if (typeof value === 'bigint') {
      tmp = value;
    } else {
      if (typeof value === 'number') {
        tmp = value;
      } else {
        this.o14(loc, DslTokenType_PLUS_getInstance());
      }
    }
    return tmp;
  };
  protoOf(Interpreter).s13 = function (value, loc) {
    var tmp;
    if (typeof value === 'bigint') {
      tmp = negate(value);
    } else {
      if (typeof value === 'number') {
        tmp = -value;
      } else {
        this.o14(loc, DslTokenType_MINUS_getInstance());
      }
    }
    return tmp;
  };
  protoOf(Interpreter).r13 = function (value, loc) {
    var tmp;
    if (typeof value === 'bigint') {
      tmp = ~value;
    } else {
      this.o14(loc, DslTokenType_NOT_getInstance());
    }
    return tmp;
  };
  protoOf(Interpreter).v13 = function (variable, value) {
    if (variable instanceof AssocArray) {
      var assocArray = this.dw_1.bx(variable);
      var key = this.b16(variable);
      if (assocArray == null) {
        this.dw_1.ww(variable, mutableMapOf([to(key, value)]));
      } else {
        if (!isInterface(assocArray, KtMutableMap)) {
          throw new RuntimeError(this.cw_1.hw(), Translations_getInstance().zm('base.dsl.expectedArray.msg', [ensureNotNull(variable.c12_1.e11_1)]));
        }
        // Inline function 'kotlin.collections.set' call
        (isInterface(assocArray, KtMutableMap) ? assocArray : THROW_CCE()).y1(key, value);
      }
    } else {
      this.dw_1.ww(variable, value);
    }
    return value;
  };
  protoOf(Interpreter).w13 = function (variable) {
    var tmp;
    if (variable instanceof AssocArray) {
      var assocArray = this.dw_1.xw(variable);
      if (!isInterface(assocArray, KtMutableMap)) {
        throw new RuntimeError(this.cw_1.hw(), Translations_getInstance().zm('base.dsl.expectedArray.msg', [ensureNotNull(variable.c12_1.e11_1)]));
      }
      var key = this.b16(variable);
      // Inline function 'kotlin.collections.get' call
      var tmp0_elvis_lhs = (isInterface(assocArray, KtMap) ? assocArray : THROW_CCE()).g2(key);
      var tmp_0;
      if (tmp0_elvis_lhs == null) {
        throw new RuntimeError(this.cw_1.hw(), Translations_getInstance().zm('base.dsl.noArrayKeyValue.msg', []));
      } else {
        tmp_0 = tmp0_elvis_lhs;
      }
      tmp = tmp_0;
    } else {
      tmp = this.dw_1.xw(variable);
    }
    return tmp;
  };
  protoOf(Interpreter).b16 = function (variable) {
    var key = this.gw(variable.f16_1);
    if (!(typeof key === 'bigint')) {
      throw new RuntimeError(variable.hw(), Translations_getInstance().zm('base.dsl.arrayIndexMustBeNumeric.msg', []));
    }
    return key;
  };
  protoOf(Interpreter).d14 = function (value) {
    var tmp;
    if (typeof value === 'bigint') {
      tmp = !equals(value, 0n);
    } else {
      if (value instanceof ULong) {
        tmp = !equals(value, new ULong(_ULong___init__impl__c78o9k(0n)));
      } else {
        tmp = !equals(value, 0n);
      }
    }
    return tmp;
  };
  function _get_store__b8qga8($this) {
    var tmp = $this.lw_1;
    if (!(tmp == null))
      return tmp;
    else {
      throwUninitializedPropertyAccessException('store');
    }
  }
  function _get_global__v8eaew($this) {
    var tmp = $this.mw_1;
    if (!(tmp == null))
      return tmp;
    else {
      throwUninitializedPropertyAccessException('global');
    }
  }
  function Memory(context) {
    context = context === VOID ? null : context;
    this.kw_1 = context;
    this.nw_1 = new Stack();
    this.bu();
  }
  protoOf(Memory).bu = function () {
    this.nw_1.a2();
    this.lw_1 = BaseModule_getInstance().ep_1('Store', this.kw_1);
    this.mw_1 = BaseModule_getInstance().ep_1('Global', _get_store__b8qga8(this));
    var tmp0_safe_receiver = this.kw_1;
    if (tmp0_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      this.nw_1.wv(tmp0_safe_receiver);
    }
    this.nw_1.wv(_get_store__b8qga8(this));
    this.nw_1.wv(_get_global__v8eaew(this));
  };
  protoOf(Memory).a2 = function () {
    _get_global__v8eaew(this).a2();
    this.nw_1.a2();
    var tmp0_safe_receiver = this.kw_1;
    if (tmp0_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      this.nw_1.wv(tmp0_safe_receiver);
    }
    this.nw_1.wv(_get_global__v8eaew(this));
  };
  protoOf(Memory).k13 = function (name) {
    this.nw_1.wv(BaseModule_getInstance().ep_1(name, this.nw_1.yv()));
  };
  protoOf(Memory).l13 = function (node) {
    if (this.nw_1.pv() === _get_global__v8eaew(this)) {
      throw new RuntimeError(node.hw(), Translations_getInstance().zm('base.dsl.cannotExitGlobalScope.msg', []));
    }
    this.nw_1.xv();
  };
  protoOf(Memory).x13 = function (variable, inStore) {
    if (inStore) {
      if (!_get_store__b8qga8(this).uw(ensureNotNull(variable.c12_1.e11_1))) {
        _get_store__b8qga8(this).vw(variable);
      }
    } else {
      this.nw_1.pv().vw(variable);
    }
  };
  protoOf(Memory).u13 = function (variable) {
    return this.nw_1.pv().uw(ensureNotNull(variable.c12_1.e11_1));
  };
  protoOf(Memory).y13 = function (variable) {
    return this.nw_1.pv().tw(ensureNotNull(variable.c12_1.e11_1));
  };
  protoOf(Memory).ww = function (variable, value) {
    this.nw_1.pv().ww(variable, value);
  };
  protoOf(Memory).xw = function (variable) {
    return this.nw_1.pv().xw(variable);
  };
  protoOf(Memory).bx = function (variable) {
    return this.nw_1.pv().bx(variable);
  };
  function ScriptMetaData(origin, context) {
    this.aw_1 = origin;
    this.bw_1 = context;
  }
  protoOf(ScriptMetaData).toString = function () {
    return 'ScriptMetaData(origin=' + this.aw_1 + ', context=' + this.bw_1 + ')';
  };
  protoOf(ScriptMetaData).hashCode = function () {
    var result = getStringHashCode(this.aw_1);
    result = imul(result, 31) + getStringHashCode(this.bw_1) | 0;
    return result;
  };
  protoOf(ScriptMetaData).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof ScriptMetaData))
      return false;
    if (!(this.aw_1 === other.aw_1))
      return false;
    if (!(this.bw_1 === other.bw_1))
      return false;
    return true;
  };
  function StoringActivationRecord(name, parent) {
    this.g16_1 = name;
    this.h16_1 = parent;
    var tmp = this;
    // Inline function 'kotlin.collections.mutableMapOf' call
    tmp.i16_1 = LinkedHashMap_init_$Create$();
  }
  protoOf(StoringActivationRecord).a2 = function () {
    this.i16_1.a2();
  };
  protoOf(StoringActivationRecord).tw = function (name) {
    return this.i16_1.e2(name);
  };
  protoOf(StoringActivationRecord).uw = function (name) {
    var tmp;
    if (this.tw(name)) {
      tmp = true;
    } else {
      var tmp0_safe_receiver = this.h16_1;
      tmp = (tmp0_safe_receiver == null ? null : tmp0_safe_receiver.uw(name)) === true;
    }
    return tmp;
  };
  protoOf(StoringActivationRecord).vw = function (variable) {
    if (this.tw(ensureNotNull(variable.c12_1.e11_1))) {
      throw new RuntimeError(variable.hw(), Translations_getInstance().zm('base.dsl.variableAlreadyDeclared.msg', [variable.c12_1.e11_1]));
    }
    var tmp0 = this.i16_1;
    // Inline function 'kotlin.collections.set' call
    var key = variable.c12_1.e11_1;
    tmp0.y1(key, null);
  };
  protoOf(StoringActivationRecord).ww = function (variable, value) {
    if (this.tw(ensureNotNull(variable.c12_1.e11_1))) {
      this.j16(variable, value);
    } else if (!(this.h16_1 == null)) {
      this.h16_1.ww(variable, value);
    } else
      throw new RuntimeError(variable.hw(), Translations_getInstance().zm('base.dsl.variableNotDefined.msg', [variable.c12_1.e11_1]));
  };
  protoOf(StoringActivationRecord).j16 = function (variable, value) {
    var tmp0 = this.i16_1;
    // Inline function 'kotlin.collections.set' call
    var key = ensureNotNull(variable.c12_1.e11_1);
    tmp0.y1(key, value);
  };
  protoOf(StoringActivationRecord).xw = function (variable) {
    return this.yw(ensureNotNull(variable.c12_1.e11_1), variable.hw());
  };
  protoOf(StoringActivationRecord).yw = function (name, location) {
    var tmp;
    if (this.tw(name)) {
      var tmp0_elvis_lhs = this.i16_1.g2(name);
      var tmp_0;
      if (tmp0_elvis_lhs == null) {
        throw new RuntimeError(Companion_getInstance_18().ax_1, Translations_getInstance().zm('base.dsl.noValueForVariable.msg', [name]));
      } else {
        tmp_0 = tmp0_elvis_lhs;
      }
      tmp = tmp_0;
    } else if (!(this.h16_1 == null)) {
      tmp = this.h16_1.zw(name);
    } else {
      throw new RuntimeError(Companion_getInstance_18().ax_1, Translations_getInstance().zm('base.dsl.variableNotDefined.msg', [name]));
    }
    return tmp;
  };
  protoOf(StoringActivationRecord).bx = function (variable) {
    return this.cx(ensureNotNull(variable.c12_1.e11_1), variable.hw());
  };
  protoOf(StoringActivationRecord).cx = function (name, location) {
    var tmp;
    if (this.tw(name)) {
      tmp = this.i16_1.g2(name);
    } else {
      var tmp0_safe_receiver = this.h16_1;
      tmp = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.cx(name, location);
    }
    return tmp;
  };
  function Symbol(name, type) {
    type = type === VOID ? null : type;
    this.k16_1 = name;
    this.l16_1 = type;
  }
  function BuiltInTypeSymbol(name) {
    Symbol.call(this, name);
  }
  function VariableSymbol(name, type) {
    Symbol.call(this, name, type);
  }
  function ExternalFunctionSymbol(name, paramsCount, function_0) {
    Symbol.call(this, name);
    this.z12_1 = paramsCount;
    this.a13_1 = function_0;
  }
  function ExternalFunction() {
  }
  function SymbolTable() {
  }
  function ScopedSymbolTable(name, scopeLevel, enclosingScope) {
    this.o16_1 = name;
    this.p16_1 = scopeLevel;
    this.q16_1 = enclosingScope;
    var tmp = this;
    // Inline function 'kotlin.collections.mutableMapOf' call
    tmp.r16_1 = LinkedHashMap_init_$Create$();
    if (this.p16_1 <= 1) {
      // Inline function 'kotlin.collections.forEach' call
      var _iterator__ex2g4s = Companion_getInstance_6().r10().i();
      while (_iterator__ex2g4s.j()) {
        var element = _iterator__ex2g4s.k();
        this.bz(new BuiltInTypeSymbol(element));
      }
      BaseModule_getInstance().gp_1.az(this);
    }
  }
  protoOf(ScopedSymbolTable).r12 = function () {
    return this.p16_1;
  };
  protoOf(ScopedSymbolTable).b13 = function () {
    return this.q16_1;
  };
  protoOf(ScopedSymbolTable).toString = function () {
    return 'Scope ' + this.o16_1 + ' at level ' + this.p16_1;
  };
  protoOf(ScopedSymbolTable).bz = function (symbol) {
    var tmp0 = this.r16_1;
    // Inline function 'kotlin.collections.set' call
    var key = symbol.k16_1;
    tmp0.y1(key, symbol);
  };
  protoOf(ScopedSymbolTable).q12 = function (name, currentScopeOnly) {
    if (currentScopeOnly) {
      return this.r16_1.e2(name);
    }
    var tmp;
    if (this.r16_1.e2(name)) {
      tmp = true;
    } else {
      var tmp0_safe_receiver = this.q16_1;
      tmp = (tmp0_safe_receiver == null ? null : tmp0_safe_receiver.c13(name)) === true;
    }
    return tmp;
  };
  protoOf(ScopedSymbolTable).m16 = function (name, currentScopeOnly) {
    if (currentScopeOnly) {
      return this.r16_1.g2(name);
    }
    var tmp0_elvis_lhs = this.r16_1.g2(name);
    var tmp;
    if (tmp0_elvis_lhs == null) {
      var tmp1_safe_receiver = this.q16_1;
      tmp = tmp1_safe_receiver == null ? null : tmp1_safe_receiver.w12(name);
    } else {
      tmp = tmp0_elvis_lhs;
    }
    return tmp;
  };
  protoOf(ScopedSymbolTable).n16 = function (name) {
    if (this.q12(name, true)) {
      return true;
    }
    var tmp0_safe_receiver = this.q16_1;
    var tmp1_elvis_lhs = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.n16(name);
    return tmp1_elvis_lhs == null ? false : tmp1_elvis_lhs;
  };
  function Compound(location, children) {
    AbstractNode.call(this, location);
    this.sw_1 = children;
  }
  protoOf(Compound).toString = function () {
    return 'Compound';
  };
  protoOf(Compound).e13 = function (visitor) {
    if (visitor.fs(this)) {
      var _iterator__ex2g4s = this.sw_1.i();
      $l$loop: while (_iterator__ex2g4s.j()) {
        var child = _iterator__ex2g4s.k();
        if (!child.e13(visitor)) {
          break $l$loop;
        }
      }
    }
    return visitor.is(this);
  };
  function AbstractNode(location) {
    this.o12_1 = location;
  }
  protoOf(AbstractNode).hw = function () {
    return this.o12_1;
  };
  protoOf(AbstractNode).e13 = function (visitor) {
    return visitor.gs(this);
  };
  function Declaration(location, left, right, store) {
    AbstractNode.call(this, location);
    this.l12_1 = left;
    this.m12_1 = right;
    this.n12_1 = store;
  }
  protoOf(Declaration).toString = function () {
    return this.n12_1 ? 'store' : 'var';
  };
  protoOf(Declaration).e13 = function (visitor) {
    if (visitor.fs(this)) {
      this.l12_1.e13(visitor);
      var tmp0_safe_receiver = this.m12_1;
      if (tmp0_safe_receiver == null)
        null;
      else
        tmp0_safe_receiver.e13(visitor);
    }
    return visitor.is(this);
  };
  function Variable(location, token, negated) {
    negated = negated === VOID ? false : negated;
    AbstractNode.call(this, location);
    this.c12_1 = token;
    this.d12_1 = negated;
  }
  protoOf(Variable).toString = function () {
    return ensureNotNull(this.c12_1.e11_1);
  };
  protoOf(Variable).e13 = function (visitor) {
    return visitor.gs(this);
  };
  function Assignment(location, left, right) {
    AbstractNode.call(this, location);
    this.m11_1 = left;
    this.n11_1 = right;
  }
  protoOf(Assignment).toString = function () {
    return '=';
  };
  protoOf(Assignment).e13 = function (visitor) {
    if (visitor.fs(this)) {
      this.m11_1.e13(visitor);
      this.n11_1.e13(visitor);
    }
    return visitor.is(this);
  };
  function Block(location, children) {
    Compound.call(this, location, children);
  }
  protoOf(Block).toString = function () {
    return 'Block';
  };
  function ForStatement(location, variable, inExpr, toExpr, statement) {
    AbstractNode.call(this, location);
    this.f12_1 = variable;
    this.g12_1 = inExpr;
    this.h12_1 = toExpr;
    this.i12_1 = statement;
  }
  protoOf(ForStatement).toString = function () {
    return 'for';
  };
  protoOf(ForStatement).e13 = function (visitor) {
    if (visitor.fs(this)) {
      this.f12_1.e13(visitor);
      this.g12_1.e13(visitor);
      this.h12_1.e13(visitor);
      this.i12_1.e13(visitor);
    }
    return visitor.is(this);
  };
  function FunctionCall(location, name, params, function_0) {
    function_0 = function_0 === VOID ? null : function_0;
    AbstractNode.call(this, location);
    this.t12_1 = name;
    this.u12_1 = params;
    this.v12_1 = function_0;
  }
  protoOf(FunctionCall).toString = function () {
    return '' + this.t12_1.e11_1 + '()';
  };
  protoOf(FunctionCall).e13 = function (visitor) {
    if (visitor.fs(this)) {
      var _iterator__ex2g4s = this.u12_1.i();
      $l$loop: while (_iterator__ex2g4s.j()) {
        var param = _iterator__ex2g4s.k();
        if (!param.e13(visitor)) {
          break $l$loop;
        }
      }
    }
    return visitor.is(this);
  };
  function NoOp(location) {
    AbstractNode.call(this, location);
  }
  protoOf(NoOp).toString = function () {
    return 'NoOp';
  };
  function AssocArray(location, token, key) {
    Variable.call(this, location, token);
    this.f16_1 = key;
  }
  protoOf(AssocArray).toString = function () {
    return protoOf(Variable).toString.call(this) + '[]';
  };
  protoOf(AssocArray).e13 = function (visitor) {
    if (visitor.fs(this)) {
      this.f16_1.e13(visitor);
    }
    return visitor.is(this);
  };
  function IfStatement(location, condition, thenStatement, elseStatement) {
    AbstractNode.call(this, location);
    this.a14_1 = condition;
    this.b14_1 = thenStatement;
    this.c14_1 = elseStatement;
  }
  protoOf(IfStatement).toString = function () {
    return 'if';
  };
  protoOf(IfStatement).e13 = function (visitor) {
    if (visitor.fs(this)) {
      this.a14_1.e13(visitor);
      this.b14_1.e13(visitor);
      var tmp0_safe_receiver = this.c14_1;
      if (tmp0_safe_receiver == null)
        null;
      else
        tmp0_safe_receiver.e13(visitor);
    }
    return visitor.is(this);
  };
  function WhenClause(location, condition, then) {
    AbstractNode.call(this, location);
    this.i14_1 = condition;
    this.j14_1 = then;
  }
  protoOf(WhenClause).toString = function () {
    var tmp;
    if (this.i14_1 == null) {
      tmp = null;
    } else {
      // Inline function 'kotlin.let' call
      tmp = ':';
    }
    var tmp1_elvis_lhs = tmp;
    return tmp1_elvis_lhs == null ? 'else' : tmp1_elvis_lhs;
  };
  protoOf(WhenClause).e13 = function (visitor) {
    if (visitor.fs(this)) {
      var tmp0_safe_receiver = this.i14_1;
      if (tmp0_safe_receiver == null)
        null;
      else
        tmp0_safe_receiver.e13(visitor);
      this.j14_1.e13(visitor);
    }
    return visitor.is(this);
  };
  function WhenStatement(location, expression, clauses) {
    AbstractNode.call(this, location);
    this.f14_1 = expression;
    this.g14_1 = clauses;
  }
  protoOf(WhenStatement).toString = function () {
    return 'when';
  };
  protoOf(WhenStatement).e13 = function (visitor) {
    if (visitor.fs(this)) {
      this.f14_1.e13(visitor);
      var _iterator__ex2g4s = this.g14_1.i();
      $l$loop: while (_iterator__ex2g4s.j()) {
        var clause = _iterator__ex2g4s.k();
        if (!clause.e13(visitor)) {
          break $l$loop;
        }
      }
    }
    return visitor.is(this);
  };
  function ReturnStatement(location, expr) {
    AbstractNode.call(this, location);
    this.m14_1 = expr;
  }
  protoOf(ReturnStatement).toString = function () {
    return 'return';
  };
  protoOf(ReturnStatement).e13 = function (visitor) {
    if (visitor.fs(this)) {
      var tmp0_safe_receiver = this.m14_1;
      if (tmp0_safe_receiver == null)
        null;
      else
        tmp0_safe_receiver.e13(visitor);
    }
    return visitor.is(this);
  };
  function BinaryOperation(location, left, op, right) {
    AbstractNode.call(this, location);
    this.q14_1 = left;
    this.r14_1 = op;
    this.s14_1 = right;
  }
  protoOf(BinaryOperation).toString = function () {
    return this.r14_1.d11_1.av();
  };
  protoOf(BinaryOperation).e13 = function (visitor) {
    if (visitor.fs(this)) {
      this.q14_1.e13(visitor);
      visitor.hs(this, this.q14_1);
      this.s14_1.e13(visitor);
    }
    return visitor.is(this);
  };
  function UnaryOperation(location, op, expr) {
    AbstractNode.call(this, location);
    this.p13_1 = op;
    this.q13_1 = expr;
  }
  protoOf(UnaryOperation).toString = function () {
    var tmp0_subject = this.p13_1.d11_1;
    var tmp;
    if (equals(tmp0_subject, DslTokenType_PLUS_getInstance())) {
      tmp = 'Unary +';
    } else if (equals(tmp0_subject, DslTokenType_MINUS_getInstance())) {
      tmp = 'Unary -';
    } else if (equals(tmp0_subject, DslTokenType_NOT_getInstance())) {
      tmp = 'not';
    } else {
      throw IllegalStateException_init_$Create$('unsupported unary op ' + toString(this.p13_1.d11_1));
    }
    return tmp;
  };
  protoOf(UnaryOperation).e13 = function (visitor) {
    if (visitor.fs(this)) {
      this.q13_1.e13(visitor);
    }
    return visitor.is(this);
  };
  function Literal(location, token) {
    AbstractNode.call(this, location);
    this.n13_1 = token;
  }
  protoOf(Literal).toString = function () {
    return toString(ensureNotNull(this.n13_1.e11_1));
  };
  var DslTokenType_PLUS_instance;
  var DslTokenType_MINUS_instance;
  var DslTokenType_MULTIPLY_instance;
  var DslTokenType_DIVIDE_instance;
  var DslTokenType_CARET_instance;
  var DslTokenType_LPAREN_instance;
  var DslTokenType_RPAREN_instance;
  var DslTokenType_ASSIGN_instance;
  var DslTokenType_LCURLEY_instance;
  var DslTokenType_RCURLEY_instance;
  var DslTokenType_VAR_instance;
  var DslTokenType_STORE_instance;
  var DslTokenType_EQUAL_instance;
  var DslTokenType_DIFF_instance;
  var DslTokenType_SMALLER_instance;
  var DslTokenType_SMALLER_EQUAL_instance;
  var DslTokenType_GREATER_instance;
  var DslTokenType_GREATER_EQUAL_instance;
  var DslTokenType_IF_instance;
  var DslTokenType_ELSE_instance;
  var DslTokenType_AND_instance;
  var DslTokenType_OR_instance;
  var DslTokenType_NOT_instance;
  var DslTokenType_SHIFT_LEFT_instance;
  var DslTokenType_SHIFT_RIGHT_instance;
  var DslTokenType_MOD_instance;
  var DslTokenType_WHEN_instance;
  var DslTokenType_COLON_instance;
  var DslTokenType_FOR_instance;
  var DslTokenType_IN_instance;
  var DslTokenType_TO_instance;
  var DslTokenType_LEFT_BRACKET_instance;
  var DslTokenType_RIGHT_BRACKET_instance;
  var DslTokenType_QUESTION_MARK_instance;
  var DslTokenType_RETURN_instance;
  var DslTokenType_AMPERSAND_instance;
  var DslTokenType_VERTICAL_BAR_instance;
  var DslTokenType_DOLLAR_instance;
  var DslTokenType_INIT_instance;
  var DslTokenType_AT_instance;
  var DslTokenType_HASH_instance;
  var DslTokenType_DOT_instance;
  var DslTokenType_COMMA_instance;
  var DslTokenType_LOGIC_AND_instance;
  var DslTokenType_LOGIC_OR_instance;
  var DslTokenType_LOGIC_NOT_instance;
  var DslTokenType_PROGRAMMING_AND_instance;
  var DslTokenType_PROGRAMMING_OR_instance;
  var DslTokenType_PROGRAMMING_NOT_instance;
  var DslTokenType_entriesInitialized;
  function DslTokenType_initEntries() {
    if (DslTokenType_entriesInitialized)
      return Unit_instance;
    DslTokenType_entriesInitialized = true;
    DslTokenType_PLUS_instance = new DslTokenType('PLUS', 0, '+');
    DslTokenType_MINUS_instance = new DslTokenType('MINUS', 1, '-');
    DslTokenType_MULTIPLY_instance = new DslTokenType('MULTIPLY', 2, '*');
    DslTokenType_DIVIDE_instance = new DslTokenType('DIVIDE', 3, '/');
    DslTokenType_CARET_instance = new DslTokenType('CARET', 4, '^');
    DslTokenType_LPAREN_instance = new DslTokenType('LPAREN', 5, '(');
    DslTokenType_RPAREN_instance = new DslTokenType('RPAREN', 6, ')');
    DslTokenType_ASSIGN_instance = new DslTokenType('ASSIGN', 7, '=');
    DslTokenType_LCURLEY_instance = new DslTokenType('LCURLEY', 8, '{');
    DslTokenType_RCURLEY_instance = new DslTokenType('RCURLEY', 9, '}');
    DslTokenType_VAR_instance = new DslTokenType('VAR', 10, 'var');
    DslTokenType_STORE_instance = new DslTokenType('STORE', 11, 'store');
    DslTokenType_EQUAL_instance = new DslTokenType('EQUAL', 12, '==');
    DslTokenType_DIFF_instance = new DslTokenType('DIFF', 13, '!=');
    DslTokenType_SMALLER_instance = new DslTokenType('SMALLER', 14, '<');
    DslTokenType_SMALLER_EQUAL_instance = new DslTokenType('SMALLER_EQUAL', 15, '<=');
    DslTokenType_GREATER_instance = new DslTokenType('GREATER', 16, '>');
    DslTokenType_GREATER_EQUAL_instance = new DslTokenType('GREATER_EQUAL', 17, '>=');
    DslTokenType_IF_instance = new DslTokenType('IF', 18, 'if');
    DslTokenType_ELSE_instance = new DslTokenType('ELSE', 19, 'else');
    DslTokenType_AND_instance = new DslTokenType('AND', 20, 'and');
    DslTokenType_OR_instance = new DslTokenType('OR', 21, 'or');
    DslTokenType_NOT_instance = new DslTokenType('NOT', 22, 'not');
    DslTokenType_SHIFT_LEFT_instance = new DslTokenType('SHIFT_LEFT', 23, '<<');
    DslTokenType_SHIFT_RIGHT_instance = new DslTokenType('SHIFT_RIGHT', 24, '>>');
    DslTokenType_MOD_instance = new DslTokenType('MOD', 25, '%');
    DslTokenType_WHEN_instance = new DslTokenType('WHEN', 26, 'when');
    DslTokenType_COLON_instance = new DslTokenType('COLON', 27, ':');
    DslTokenType_FOR_instance = new DslTokenType('FOR', 28, 'for');
    DslTokenType_IN_instance = new DslTokenType('IN', 29, 'in');
    DslTokenType_TO_instance = new DslTokenType('TO', 30, 'to');
    DslTokenType_LEFT_BRACKET_instance = new DslTokenType('LEFT_BRACKET', 31, '[');
    DslTokenType_RIGHT_BRACKET_instance = new DslTokenType('RIGHT_BRACKET', 32, ']');
    DslTokenType_QUESTION_MARK_instance = new DslTokenType('QUESTION_MARK', 33, '?');
    DslTokenType_RETURN_instance = new DslTokenType('RETURN', 34, 'return');
    DslTokenType_AMPERSAND_instance = new DslTokenType('AMPERSAND', 35, '&');
    DslTokenType_VERTICAL_BAR_instance = new DslTokenType('VERTICAL_BAR', 36, '|');
    DslTokenType_DOLLAR_instance = new DslTokenType('DOLLAR', 37, '$');
    DslTokenType_INIT_instance = new DslTokenType('INIT', 38, 'init');
    DslTokenType_AT_instance = new DslTokenType('AT', 39, '@');
    DslTokenType_HASH_instance = new DslTokenType('HASH', 40, '#');
    DslTokenType_DOT_instance = new DslTokenType('DOT', 41, '.');
    DslTokenType_COMMA_instance = new DslTokenType('COMMA', 42, ',');
    DslTokenType_LOGIC_AND_instance = new DslTokenType('LOGIC_AND', 43, '\u2227');
    DslTokenType_LOGIC_OR_instance = new DslTokenType('LOGIC_OR', 44, '\u2228');
    DslTokenType_LOGIC_NOT_instance = new DslTokenType('LOGIC_NOT', 45, '\xAC');
    DslTokenType_PROGRAMMING_AND_instance = new DslTokenType('PROGRAMMING_AND', 46, '&&');
    DslTokenType_PROGRAMMING_OR_instance = new DslTokenType('PROGRAMMING_OR', 47, '||');
    DslTokenType_PROGRAMMING_NOT_instance = new DslTokenType('PROGRAMMING_NOT', 48, '!');
  }
  function DslTokenType(name, ordinal, id) {
    Enum.call(this, name, ordinal);
    this.u16_1 = id;
  }
  protoOf(DslTokenType).av = function () {
    return this.u16_1;
  };
  function DslTokenType_PLUS_getInstance() {
    DslTokenType_initEntries();
    return DslTokenType_PLUS_instance;
  }
  function DslTokenType_MINUS_getInstance() {
    DslTokenType_initEntries();
    return DslTokenType_MINUS_instance;
  }
  function DslTokenType_MULTIPLY_getInstance() {
    DslTokenType_initEntries();
    return DslTokenType_MULTIPLY_instance;
  }
  function DslTokenType_DIVIDE_getInstance() {
    DslTokenType_initEntries();
    return DslTokenType_DIVIDE_instance;
  }
  function DslTokenType_CARET_getInstance() {
    DslTokenType_initEntries();
    return DslTokenType_CARET_instance;
  }
  function DslTokenType_LPAREN_getInstance() {
    DslTokenType_initEntries();
    return DslTokenType_LPAREN_instance;
  }
  function DslTokenType_RPAREN_getInstance() {
    DslTokenType_initEntries();
    return DslTokenType_RPAREN_instance;
  }
  function DslTokenType_ASSIGN_getInstance() {
    DslTokenType_initEntries();
    return DslTokenType_ASSIGN_instance;
  }
  function DslTokenType_LCURLEY_getInstance() {
    DslTokenType_initEntries();
    return DslTokenType_LCURLEY_instance;
  }
  function DslTokenType_RCURLEY_getInstance() {
    DslTokenType_initEntries();
    return DslTokenType_RCURLEY_instance;
  }
  function DslTokenType_VAR_getInstance() {
    DslTokenType_initEntries();
    return DslTokenType_VAR_instance;
  }
  function DslTokenType_STORE_getInstance() {
    DslTokenType_initEntries();
    return DslTokenType_STORE_instance;
  }
  function DslTokenType_EQUAL_getInstance() {
    DslTokenType_initEntries();
    return DslTokenType_EQUAL_instance;
  }
  function DslTokenType_DIFF_getInstance() {
    DslTokenType_initEntries();
    return DslTokenType_DIFF_instance;
  }
  function DslTokenType_SMALLER_getInstance() {
    DslTokenType_initEntries();
    return DslTokenType_SMALLER_instance;
  }
  function DslTokenType_SMALLER_EQUAL_getInstance() {
    DslTokenType_initEntries();
    return DslTokenType_SMALLER_EQUAL_instance;
  }
  function DslTokenType_GREATER_getInstance() {
    DslTokenType_initEntries();
    return DslTokenType_GREATER_instance;
  }
  function DslTokenType_GREATER_EQUAL_getInstance() {
    DslTokenType_initEntries();
    return DslTokenType_GREATER_EQUAL_instance;
  }
  function DslTokenType_IF_getInstance() {
    DslTokenType_initEntries();
    return DslTokenType_IF_instance;
  }
  function DslTokenType_ELSE_getInstance() {
    DslTokenType_initEntries();
    return DslTokenType_ELSE_instance;
  }
  function DslTokenType_AND_getInstance() {
    DslTokenType_initEntries();
    return DslTokenType_AND_instance;
  }
  function DslTokenType_OR_getInstance() {
    DslTokenType_initEntries();
    return DslTokenType_OR_instance;
  }
  function DslTokenType_NOT_getInstance() {
    DslTokenType_initEntries();
    return DslTokenType_NOT_instance;
  }
  function DslTokenType_SHIFT_LEFT_getInstance() {
    DslTokenType_initEntries();
    return DslTokenType_SHIFT_LEFT_instance;
  }
  function DslTokenType_SHIFT_RIGHT_getInstance() {
    DslTokenType_initEntries();
    return DslTokenType_SHIFT_RIGHT_instance;
  }
  function DslTokenType_MOD_getInstance() {
    DslTokenType_initEntries();
    return DslTokenType_MOD_instance;
  }
  function DslTokenType_WHEN_getInstance() {
    DslTokenType_initEntries();
    return DslTokenType_WHEN_instance;
  }
  function DslTokenType_COLON_getInstance() {
    DslTokenType_initEntries();
    return DslTokenType_COLON_instance;
  }
  function DslTokenType_FOR_getInstance() {
    DslTokenType_initEntries();
    return DslTokenType_FOR_instance;
  }
  function DslTokenType_IN_getInstance() {
    DslTokenType_initEntries();
    return DslTokenType_IN_instance;
  }
  function DslTokenType_TO_getInstance() {
    DslTokenType_initEntries();
    return DslTokenType_TO_instance;
  }
  function DslTokenType_LEFT_BRACKET_getInstance() {
    DslTokenType_initEntries();
    return DslTokenType_LEFT_BRACKET_instance;
  }
  function DslTokenType_RIGHT_BRACKET_getInstance() {
    DslTokenType_initEntries();
    return DslTokenType_RIGHT_BRACKET_instance;
  }
  function DslTokenType_QUESTION_MARK_getInstance() {
    DslTokenType_initEntries();
    return DslTokenType_QUESTION_MARK_instance;
  }
  function DslTokenType_RETURN_getInstance() {
    DslTokenType_initEntries();
    return DslTokenType_RETURN_instance;
  }
  function DslTokenType_DOLLAR_getInstance() {
    DslTokenType_initEntries();
    return DslTokenType_DOLLAR_instance;
  }
  function DslTokenType_INIT_getInstance() {
    DslTokenType_initEntries();
    return DslTokenType_INIT_instance;
  }
  function DslTokenType_AT_getInstance() {
    DslTokenType_initEntries();
    return DslTokenType_AT_instance;
  }
  function DslTokenType_HASH_getInstance() {
    DslTokenType_initEntries();
    return DslTokenType_HASH_instance;
  }
  function DslTokenType_DOT_getInstance() {
    DslTokenType_initEntries();
    return DslTokenType_DOT_instance;
  }
  function DslTokenType_COMMA_getInstance() {
    DslTokenType_initEntries();
    return DslTokenType_COMMA_instance;
  }
  function ActionEvent(event, source, modifiers, action, time) {
    this.v16_1 = event;
    this.w16_1 = source;
    this.x16_1 = modifiers;
    this.action = action;
    this.time = time;
  }
  protoOf(ActionEvent).y16 = function () {
    return this.v16_1;
  };
  protoOf(ActionEvent).z16 = function () {
    return this.w16_1;
  };
  protoOf(ActionEvent).a17 = function () {
    return this.x16_1;
  };
  protoOf(ActionEvent).b17 = function () {
    return this.action;
  };
  protoOf(ActionEvent).c17 = function () {
    return this.time;
  };
  protoOf(ActionEvent).consumeEvent = function () {
  };
  protoOf(ActionEvent).isEventConsumed = function () {
    return false;
  };
  function ActionListener() {
  }
  function EventBus$postVetoable$lambda(it) {
    return Unit_instance;
  }
  function EventBus$postVetoable$lambda_0(it) {
    return Unit_instance;
  }
  function EventBus() {
  }
  function VetoException(msg, source) {
    source = source === VOID ? null : source;
    extendThrowable(this, msg);
    captureStack(this, VetoException);
    this.q17_1 = source;
  }
  function _get_LOG__e5r759_3($this) {
    var tmp0 = $this.r17_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('LOG', 1, tmp, EventBusImpl$Companion$_get_LOG_$ref_ghr206(), null);
    return tmp0.j2();
  }
  function EventBusImpl$Companion$_get_LOG_$ref_ghr206() {
    return function (p0) {
      return _get_LOG__e5r759_3(p0);
    };
  }
  function Companion_9() {
    Companion_instance_9 = this;
    this.r17_1 = logger(getKClass(EventBusImpl));
  }
  var Companion_instance_9;
  function Companion_getInstance_9() {
    if (Companion_instance_9 == null)
      new Companion_9();
    return Companion_instance_9;
  }
  function unregister($this, eventClassName, handler) {
    _get_LOG__e5r759_3(Companion_getInstance_9()).nl('Unregister ' + eventClassName);
    var tmp0_safe_receiver = $this.s17_1.g2(eventClassName);
    if (tmp0_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.collections.remove' call
      (isInterface(tmp0_safe_receiver, MutableCollection) ? tmp0_safe_receiver : THROW_CCE()).h2(handler);
    }
  }
  function getEventClassName($this, eventClass) {
    return System_getInstance().vl(eventClass);
  }
  function getEventClassName_0($this, event) {
    return System_getInstance().wl(event);
  }
  function EventBusImpl() {
    Companion_getInstance_9();
    var tmp = this;
    // Inline function 'kotlin.collections.mutableMapOf' call
    tmp.s17_1 = LinkedHashMap_init_$Create$();
  }
  protoOf(EventBusImpl).j17 = function (eventClass, handler) {
    var eventName = getEventClassName(this, eventClass);
    _get_LOG__e5r759_3(Companion_getInstance_9()).ol('EventBus ' + hashCode(this) + ': Register ' + toString(eventClass));
    // Inline function 'kotlin.collections.getOrPut' call
    var this_0 = this.s17_1;
    var value = this_0.g2(eventName);
    var tmp;
    if (value == null) {
      // Inline function 'kotlin.collections.mutableListOf' call
      var answer = ArrayList_init_$Create$();
      this_0.y1(eventName, answer);
      tmp = answer;
    } else {
      tmp = value;
    }
    var list = tmp;
    if (!contains(list, handler)) {
      list.h(typeof handler === 'function' ? handler : THROW_CCE());
    }
  };
  protoOf(EventBusImpl).k17 = function (eventClass, handler) {
    var eventName = getEventClassName(this, eventClass);
    unregister(this, eventName, typeof handler === 'function' ? handler : THROW_CCE());
  };
  protoOf(EventBusImpl).l17 = function (handler) {
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = this.s17_1.b2().i();
    while (_iterator__ex2g4s.j()) {
      var element = _iterator__ex2g4s.k();
      unregister(this, element, handler);
    }
  };
  protoOf(EventBusImpl).eu = function (event) {
    var tmp0_safe_receiver = this.s17_1.g2(getEventClassName_0(this, event));
    var tmp1_safe_receiver = tmp0_safe_receiver == null ? null : toList(tmp0_safe_receiver);
    if (tmp1_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.collections.forEach' call
      var _iterator__ex2g4s = tmp1_safe_receiver.i();
      while (_iterator__ex2g4s.j()) {
        var element = _iterator__ex2g4s.k();
        element(event);
      }
    }
  };
  protoOf(EventBusImpl).m17 = function (event, undoEvent, thenHandler, elseHandler) {
    // Inline function 'kotlin.collections.mutableListOf' call
    var successHandlers = ArrayList_init_$Create$();
    try {
      var tmp0_safe_receiver = this.s17_1.g2(getEventClassName_0(this, event));
      if (tmp0_safe_receiver == null)
        null;
      else {
        // Inline function 'kotlin.collections.forEach' call
        var _iterator__ex2g4s = tmp0_safe_receiver.i();
        while (_iterator__ex2g4s.j()) {
          var element = _iterator__ex2g4s.k();
          element(event);
          successHandlers.h(element);
        }
      }
      thenHandler(event);
    } catch ($p) {
      if ($p instanceof VetoException) {
        var x = $p;
        // Inline function 'kotlin.collections.forEach' call
        var _iterator__ex2g4s_0 = successHandlers.i();
        while (_iterator__ex2g4s_0.j()) {
          var element_0 = _iterator__ex2g4s_0.k();
          element_0(undoEvent);
        }
        elseHandler(x);
      } else {
        throw $p;
      }
    }
  };
  protoOf(EventBusImpl).o17 = function (prepareEvent, execEvent, thenHandler) {
    try {
      var tmp0_safe_receiver = this.s17_1.g2(getEventClassName_0(this, prepareEvent));
      if (tmp0_safe_receiver == null)
        null;
      else {
        // Inline function 'kotlin.collections.forEach' call
        var _iterator__ex2g4s = tmp0_safe_receiver.i();
        while (_iterator__ex2g4s.j()) {
          var element = _iterator__ex2g4s.k();
          element(prepareEvent);
        }
      }
      var tmp1_safe_receiver = this.s17_1.g2(getEventClassName_0(this, execEvent));
      if (tmp1_safe_receiver == null)
        null;
      else {
        // Inline function 'kotlin.collections.forEach' call
        var _iterator__ex2g4s_0 = tmp1_safe_receiver.i();
        while (_iterator__ex2g4s_0.j()) {
          var element_0 = _iterator__ex2g4s_0.k();
          element_0(execEvent);
        }
      }
      if (thenHandler == null)
        null;
      else
        thenHandler();
    } catch ($p) {
      if ($p instanceof VetoException) {
        var e = $p;
      } else {
        throw $p;
      }
    }
  };
  var Modifier_Shift_instance;
  var Modifier_Ctrl_instance;
  var Modifier_Meta_instance;
  var Modifier_Alt_instance;
  var Modifier_AltGraph_instance;
  function values_0() {
    return [Modifier_Shift_getInstance(), Modifier_Ctrl_getInstance(), Modifier_Meta_getInstance(), Modifier_Alt_getInstance(), Modifier_AltGraph_getInstance()];
  }
  function valueOf(value) {
    switch (value) {
      case 'Shift':
        return Modifier_Shift_getInstance();
      case 'Ctrl':
        return Modifier_Ctrl_getInstance();
      case 'Meta':
        return Modifier_Meta_getInstance();
      case 'Alt':
        return Modifier_Alt_getInstance();
      case 'AltGraph':
        return Modifier_AltGraph_getInstance();
      default:
        Modifier_initEntries();
        THROW_IAE('No enum constant io.antarescircuit.jabbah.base.event.Modifier.' + value);
        break;
    }
  }
  var Modifier_entriesInitialized;
  function Modifier_initEntries() {
    if (Modifier_entriesInitialized)
      return Unit_instance;
    Modifier_entriesInitialized = true;
    Modifier_Shift_instance = new Modifier('Shift', 0, 'Shift', 64);
    Modifier_Ctrl_instance = new Modifier('Ctrl', 1, 'Ctrl', 128);
    Modifier_Meta_instance = new Modifier('Meta', 2, 'Meta', 256);
    Modifier_Alt_instance = new Modifier('Alt', 3, 'Alt', 512);
    Modifier_AltGraph_instance = new Modifier('AltGraph', 4, 'AltGr', 8192);
  }
  function Modifier(name, ordinal, label, mask) {
    Enum.call(this, name, ordinal);
    this.label = label;
    this.mask = mask;
  }
  protoOf(Modifier).v17 = function () {
    return this.label;
  };
  protoOf(Modifier).w17 = function (_set____db54di) {
    this.mask = _set____db54di;
  };
  protoOf(Modifier).x17 = function () {
    return this.mask;
  };
  function InputEvent() {
  }
  function Modifier_Shift_getInstance() {
    Modifier_initEntries();
    return Modifier_Shift_instance;
  }
  function Modifier_Ctrl_getInstance() {
    Modifier_initEntries();
    return Modifier_Ctrl_instance;
  }
  function Modifier_Meta_getInstance() {
    Modifier_initEntries();
    return Modifier_Meta_instance;
  }
  function Modifier_Alt_getInstance() {
    Modifier_initEntries();
    return Modifier_Alt_instance;
  }
  function Modifier_AltGraph_getInstance() {
    Modifier_initEntries();
    return Modifier_AltGraph_instance;
  }
  function Companion_10() {
    this.y17_1 = 1;
    this.z17_1 = 2;
    this.a18_1 = 3;
    this.b18_1 = 4;
    this.c18_1 = 5;
    this.d18_1 = 6;
    this.e18_1 = 7;
    this.f18_1 = 8;
    this.g18_1 = 9;
    this.h18_1 = 10;
    this.i18_1 = 11;
    this.j18_1 = 12;
    this.k18_1 = 13;
    this.l18_1 = 48;
    this.m18_1 = 49;
    this.n18_1 = 50;
    this.o18_1 = 51;
    this.p18_1 = 52;
    this.q18_1 = 53;
    this.r18_1 = 54;
    this.s18_1 = 55;
    this.t18_1 = 56;
    this.u18_1 = 57;
    this.v18_1 = 65;
    this.w18_1 = 66;
    this.x18_1 = 67;
    this.y18_1 = 68;
    this.z18_1 = 69;
    this.a19_1 = 70;
    this.b19_1 = 88;
    this.c19_1 = 90;
    this.d19_1 = 96;
    this.e19_1 = 97;
    this.f19_1 = 98;
    this.g19_1 = 99;
    this.h19_1 = 100;
    this.i19_1 = 101;
    this.j19_1 = 102;
    this.k19_1 = 103;
    this.l19_1 = 104;
    this.m19_1 = 105;
  }
  var Companion_instance_10;
  function Companion_getInstance_10() {
    return Companion_instance_10;
  }
  var KeyEventType_TYPED_instance;
  var KeyEventType_PRESSED_instance;
  var KeyEventType_RELEASED_instance;
  var KeyEventType_UNKNOWN_instance;
  var KeyEventType_entriesInitialized;
  function KeyEventType_initEntries() {
    if (KeyEventType_entriesInitialized)
      return Unit_instance;
    KeyEventType_entriesInitialized = true;
    KeyEventType_TYPED_instance = new KeyEventType('TYPED', 0);
    KeyEventType_PRESSED_instance = new KeyEventType('PRESSED', 1);
    KeyEventType_RELEASED_instance = new KeyEventType('RELEASED', 2);
    KeyEventType_UNKNOWN_instance = new KeyEventType('UNKNOWN', 3);
  }
  function KeyEventType(name, ordinal) {
    Enum.call(this, name, ordinal);
  }
  function KeyEventImpl(type, event, key, keyChar, source, modifiers) {
    event = event === VOID ? '' : event;
    source = source === VOID ? '' : source;
    modifiers = modifiers === VOID ? 0 : modifiers;
    this.n19_1 = type;
    this.o19_1 = event;
    this.p19_1 = key;
    this.q19_1 = keyChar;
    this.r19_1 = source;
    this.s19_1 = modifiers;
    this.t19_1 = false;
  }
  protoOf(KeyEventImpl).u19 = function () {
    return this.n19_1;
  };
  protoOf(KeyEventImpl).y16 = function () {
    return this.o19_1;
  };
  protoOf(KeyEventImpl).i2 = function () {
    return this.p19_1;
  };
  protoOf(KeyEventImpl).v19 = function () {
    return this.q19_1;
  };
  protoOf(KeyEventImpl).z16 = function () {
    return this.r19_1;
  };
  protoOf(KeyEventImpl).a17 = function () {
    return this.s19_1;
  };
  protoOf(KeyEventImpl).consumeEvent = function () {
    this.t19_1 = true;
  };
  protoOf(KeyEventImpl).isEventConsumed = function () {
    return this.t19_1;
  };
  protoOf(KeyEventImpl).toString = function () {
    return 'KeyEventImpl(type=' + this.n19_1.toString() + ', event=' + toString(this.o19_1) + ', key=' + this.p19_1 + ', keyChar=' + toString_1(this.q19_1) + ', source=' + toString(this.r19_1) + ', modifiers=' + this.s19_1 + ')';
  };
  protoOf(KeyEventImpl).hashCode = function () {
    var result = this.n19_1.hashCode();
    result = imul(result, 31) + hashCode(this.o19_1) | 0;
    result = imul(result, 31) + this.p19_1 | 0;
    result = imul(result, 31) + Char__hashCode_impl_otmys(this.q19_1) | 0;
    result = imul(result, 31) + hashCode(this.r19_1) | 0;
    result = imul(result, 31) + this.s19_1 | 0;
    return result;
  };
  protoOf(KeyEventImpl).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof KeyEventImpl))
      return false;
    if (!this.n19_1.equals(other.n19_1))
      return false;
    if (!equals(this.o19_1, other.o19_1))
      return false;
    if (!(this.p19_1 === other.p19_1))
      return false;
    if (!(this.q19_1 === other.q19_1))
      return false;
    if (!equals(this.r19_1, other.r19_1))
      return false;
    if (!(this.s19_1 === other.s19_1))
      return false;
    return true;
  };
  function KeyAdapter() {
  }
  protoOf(KeyAdapter).w19 = function (e) {
  };
  protoOf(KeyAdapter).x19 = function (e) {
  };
  protoOf(KeyAdapter).y19 = function (e) {
  };
  function KeyEventType_TYPED_getInstance() {
    KeyEventType_initEntries();
    return KeyEventType_TYPED_instance;
  }
  function KeyEventType_PRESSED_getInstance() {
    KeyEventType_initEntries();
    return KeyEventType_PRESSED_instance;
  }
  function KeyEventType_RELEASED_getInstance() {
    KeyEventType_initEntries();
    return KeyEventType_RELEASED_instance;
  }
  function MouseEvent() {
  }
  var MouseEventType_CLICKED_instance;
  var MouseEventType_PRESSED_instance;
  var MouseEventType_RELEASED_instance;
  var MouseEventType_ENTERED_instance;
  var MouseEventType_EXITED_instance;
  var MouseEventType_MOVED_instance;
  var MouseEventType_DRAGGED_instance;
  var MouseEventType_WHEEL_ROTATED_instance;
  var MouseEventType_UNKNOWN_instance;
  var MouseEventType_entriesInitialized;
  function MouseEventType_initEntries() {
    if (MouseEventType_entriesInitialized)
      return Unit_instance;
    MouseEventType_entriesInitialized = true;
    MouseEventType_CLICKED_instance = new MouseEventType('CLICKED', 0);
    MouseEventType_PRESSED_instance = new MouseEventType('PRESSED', 1);
    MouseEventType_RELEASED_instance = new MouseEventType('RELEASED', 2);
    MouseEventType_ENTERED_instance = new MouseEventType('ENTERED', 3);
    MouseEventType_EXITED_instance = new MouseEventType('EXITED', 4);
    MouseEventType_MOVED_instance = new MouseEventType('MOVED', 5);
    MouseEventType_DRAGGED_instance = new MouseEventType('DRAGGED', 6);
    MouseEventType_WHEEL_ROTATED_instance = new MouseEventType('WHEEL_ROTATED', 7);
    MouseEventType_UNKNOWN_instance = new MouseEventType('UNKNOWN', 8);
  }
  function MouseEventType(name, ordinal) {
    Enum.call(this, name, ordinal);
  }
  var Button_NONE_instance;
  var Button_BUTTON1_instance;
  var Button_BUTTON2_instance;
  var Button_BUTTON3_instance;
  var Button_UNKNOWN_instance;
  var Button_entriesInitialized;
  function Button_initEntries() {
    if (Button_entriesInitialized)
      return Unit_instance;
    Button_entriesInitialized = true;
    Button_NONE_instance = new Button('NONE', 0);
    Button_BUTTON1_instance = new Button('BUTTON1', 1);
    Button_BUTTON2_instance = new Button('BUTTON2', 2);
    Button_BUTTON3_instance = new Button('BUTTON3', 3);
    Button_UNKNOWN_instance = new Button('UNKNOWN', 4);
  }
  function Button(name, ordinal) {
    Enum.call(this, name, ordinal);
  }
  function MouseEventImpl(type, event, x, y, button, clickCount, wheelRotation, source, modifiers) {
    type = type === VOID ? MouseEventType_PRESSED_getInstance() : type;
    event = event === VOID ? '' : event;
    x = x === VOID ? 0 : x;
    y = y === VOID ? 0 : y;
    button = button === VOID ? Button_NONE_getInstance() : button;
    clickCount = clickCount === VOID ? 0 : clickCount;
    wheelRotation = wheelRotation === VOID ? Companion_getInstance_14().g1a_1 : wheelRotation;
    source = source === VOID ? '' : source;
    modifiers = modifiers === VOID ? 0 : modifiers;
    this.h1a_1 = type;
    this.i1a_1 = event;
    this.j1a_1 = x;
    this.k1a_1 = y;
    this.l1a_1 = button;
    this.m1a_1 = clickCount;
    this.n1a_1 = wheelRotation;
    this.o1a_1 = source;
    this.p1a_1 = modifiers;
    this.q1a_1 = false;
  }
  protoOf(MouseEventImpl).u19 = function () {
    return this.h1a_1;
  };
  protoOf(MouseEventImpl).y16 = function () {
    return this.i1a_1;
  };
  protoOf(MouseEventImpl).z19 = function () {
    return this.j1a_1;
  };
  protoOf(MouseEventImpl).a1a = function () {
    return this.k1a_1;
  };
  protoOf(MouseEventImpl).b1a = function () {
    return this.l1a_1;
  };
  protoOf(MouseEventImpl).c1a = function () {
    return this.m1a_1;
  };
  protoOf(MouseEventImpl).d1a = function () {
    return this.n1a_1;
  };
  protoOf(MouseEventImpl).z16 = function () {
    return this.o1a_1;
  };
  protoOf(MouseEventImpl).a17 = function () {
    return this.p1a_1;
  };
  protoOf(MouseEventImpl).consumeEvent = function () {
    this.q1a_1 = true;
  };
  protoOf(MouseEventImpl).isEventConsumed = function () {
    return this.q1a_1;
  };
  protoOf(MouseEventImpl).toString = function () {
    return 'Mouse.' + this.h1a_1.toString() + ' at ' + this.j1a_1 + ',' + this.k1a_1;
  };
  protoOf(MouseEventImpl).e1a = function () {
    return this.l1a_1.equals(Button_BUTTON1_getInstance());
  };
  protoOf(MouseEventImpl).f1a = function () {
    return this.l1a_1.equals(Button_BUTTON2_getInstance());
  };
  protoOf(MouseEventImpl).hashCode = function () {
    var result = this.h1a_1.hashCode();
    result = imul(result, 31) + hashCode(this.i1a_1) | 0;
    result = imul(result, 31) + this.j1a_1 | 0;
    result = imul(result, 31) + this.k1a_1 | 0;
    result = imul(result, 31) + this.l1a_1.hashCode() | 0;
    result = imul(result, 31) + this.m1a_1 | 0;
    result = imul(result, 31) + this.n1a_1.hashCode() | 0;
    result = imul(result, 31) + hashCode(this.o1a_1) | 0;
    result = imul(result, 31) + this.p1a_1 | 0;
    return result;
  };
  protoOf(MouseEventImpl).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof MouseEventImpl))
      return false;
    if (!this.h1a_1.equals(other.h1a_1))
      return false;
    if (!equals(this.i1a_1, other.i1a_1))
      return false;
    if (!(this.j1a_1 === other.j1a_1))
      return false;
    if (!(this.k1a_1 === other.k1a_1))
      return false;
    if (!this.l1a_1.equals(other.l1a_1))
      return false;
    if (!(this.m1a_1 === other.m1a_1))
      return false;
    if (!this.n1a_1.equals(other.n1a_1))
      return false;
    if (!equals(this.o1a_1, other.o1a_1))
      return false;
    if (!(this.p1a_1 === other.p1a_1))
      return false;
    return true;
  };
  function MouseAdapter() {
  }
  protoOf(MouseAdapter).r1a = function (e) {
  };
  protoOf(MouseAdapter).s1a = function (e) {
  };
  protoOf(MouseAdapter).t1a = function (e) {
  };
  protoOf(MouseAdapter).u1a = function (e) {
  };
  protoOf(MouseAdapter).v1a = function (e) {
  };
  protoOf(MouseAdapter).w1a = function (e) {
  };
  function MouseEventType_CLICKED_getInstance() {
    MouseEventType_initEntries();
    return MouseEventType_CLICKED_instance;
  }
  function MouseEventType_PRESSED_getInstance() {
    MouseEventType_initEntries();
    return MouseEventType_PRESSED_instance;
  }
  function MouseEventType_RELEASED_getInstance() {
    MouseEventType_initEntries();
    return MouseEventType_RELEASED_instance;
  }
  function MouseEventType_ENTERED_getInstance() {
    MouseEventType_initEntries();
    return MouseEventType_ENTERED_instance;
  }
  function MouseEventType_EXITED_getInstance() {
    MouseEventType_initEntries();
    return MouseEventType_EXITED_instance;
  }
  function MouseEventType_MOVED_getInstance() {
    MouseEventType_initEntries();
    return MouseEventType_MOVED_instance;
  }
  function MouseEventType_DRAGGED_getInstance() {
    MouseEventType_initEntries();
    return MouseEventType_DRAGGED_instance;
  }
  function MouseEventType_WHEEL_ROTATED_getInstance() {
    MouseEventType_initEntries();
    return MouseEventType_WHEEL_ROTATED_instance;
  }
  function MouseEventType_UNKNOWN_getInstance() {
    MouseEventType_initEntries();
    return MouseEventType_UNKNOWN_instance;
  }
  function Button_NONE_getInstance() {
    Button_initEntries();
    return Button_NONE_instance;
  }
  function Button_BUTTON1_getInstance() {
    Button_initEntries();
    return Button_BUTTON1_instance;
  }
  function Button_BUTTON2_getInstance() {
    Button_initEntries();
    return Button_BUTTON2_instance;
  }
  function Button_BUTTON3_getInstance() {
    Button_initEntries();
    return Button_BUTTON3_instance;
  }
  function PropertyChangeEvent(source, name, oldValue, newValue) {
    this.source = source;
    this.name = name;
    this.oldValue = oldValue;
    this.newValue = newValue;
  }
  protoOf(PropertyChangeEvent).z16 = function () {
    return this.source;
  };
  protoOf(PropertyChangeEvent).m2 = function () {
    return this.name;
  };
  protoOf(PropertyChangeEvent).x1a = function () {
    return this.oldValue;
  };
  protoOf(PropertyChangeEvent).y1a = function () {
    return this.newValue;
  };
  protoOf(PropertyChangeEvent).xd = function () {
    return this.source;
  };
  protoOf(PropertyChangeEvent).yd = function () {
    return this.name;
  };
  protoOf(PropertyChangeEvent).z1a = function () {
    return this.oldValue;
  };
  protoOf(PropertyChangeEvent).a1b = function () {
    return this.newValue;
  };
  protoOf(PropertyChangeEvent).b1b = function (source, name, oldValue, newValue) {
    return new PropertyChangeEvent(source, name, oldValue, newValue);
  };
  protoOf(PropertyChangeEvent).copy = function (source, name, oldValue, newValue, $super) {
    source = source === VOID ? this.source : source;
    name = name === VOID ? this.name : name;
    oldValue = oldValue === VOID ? this.oldValue : oldValue;
    newValue = newValue === VOID ? this.newValue : newValue;
    return $super === VOID ? this.b1b(source, name, oldValue, newValue) : $super.b1b.call(this, source, name, oldValue, newValue);
  };
  protoOf(PropertyChangeEvent).toString = function () {
    return 'PropertyChangeEvent(source=' + toString(this.source) + ', name=' + this.name + ', oldValue=' + toString_0(this.oldValue) + ', newValue=' + toString_0(this.newValue) + ')';
  };
  protoOf(PropertyChangeEvent).hashCode = function () {
    var result = hashCode(this.source);
    result = imul(result, 31) + getStringHashCode(this.name) | 0;
    result = imul(result, 31) + (this.oldValue == null ? 0 : hashCode(this.oldValue)) | 0;
    result = imul(result, 31) + (this.newValue == null ? 0 : hashCode(this.newValue)) | 0;
    return result;
  };
  protoOf(PropertyChangeEvent).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof PropertyChangeEvent))
      return false;
    if (!equals(this.source, other.source))
      return false;
    if (!(this.name === other.name))
      return false;
    if (!equals(this.oldValue, other.oldValue))
      return false;
    if (!equals(this.newValue, other.newValue))
      return false;
    return true;
  };
  function PropertyChangeListener() {
  }
  function _get_pcSupport__wx0pzf($this) {
    var tmp = $this.c1b_1;
    if (!(tmp == null))
      return tmp;
    else {
      throwUninitializedPropertyAccessException('pcSupport');
    }
  }
  function PropertyOwnerImpl() {
  }
  protoOf(PropertyOwnerImpl).d1b = function (value) {
    this.c1b_1 = new PropertyChangeSupport(value);
  };
  protoOf(PropertyOwnerImpl).e1b = function (l) {
    _get_pcSupport__wx0pzf(this).xr(l);
  };
  protoOf(PropertyOwnerImpl).f1b = function (l) {
    _get_pcSupport__wx0pzf(this).yr(l);
  };
  protoOf(PropertyOwnerImpl).lr = function (name, oldValue, newValue) {
    _get_pcSupport__wx0pzf(this).lr(name, oldValue, newValue);
  };
  function _get_listeners__760gzy($this) {
    var tmp0 = $this.kr_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('listeners', 1, tmp, PropertyChangeSupport$_get_listeners_$ref_24o3ev(), null);
    return tmp0.j2();
  }
  function fire($this, event) {
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = toList(_get_listeners__760gzy($this)).i();
    while (_iterator__ex2g4s.j()) {
      var element = _iterator__ex2g4s.k();
      element.propertyChanged(event);
    }
    return Unit_instance;
  }
  function sam$io_antarescircuit_jabbah_base_event_PropertyChangeListener$0(function_0) {
    this.g1b_1 = function_0;
  }
  protoOf(sam$io_antarescircuit_jabbah_base_event_PropertyChangeListener$0).propertyChanged = function (e) {
    return this.g1b_1(e);
  };
  protoOf(sam$io_antarescircuit_jabbah_base_event_PropertyChangeListener$0).p2 = function () {
    return this.g1b_1;
  };
  protoOf(sam$io_antarescircuit_jabbah_base_event_PropertyChangeListener$0).equals = function (other) {
    var tmp;
    if (!(other == null) ? isInterface(other, PropertyChangeListener) : false) {
      var tmp_0;
      if (!(other == null) ? isInterface(other, FunctionAdapter) : false) {
        tmp_0 = equals(this.p2(), other.p2());
      } else {
        tmp_0 = false;
      }
      tmp = tmp_0;
    } else {
      tmp = false;
    }
    return tmp;
  };
  protoOf(sam$io_antarescircuit_jabbah_base_event_PropertyChangeListener$0).hashCode = function () {
    return hashCode(this.p2());
  };
  function PropertyChangeSupport$listeners$delegate$lambda() {
    // Inline function 'kotlin.collections.mutableListOf' call
    return ArrayList_init_$Create$();
  }
  function PropertyChangeSupport$_get_listeners_$ref_24o3ev() {
    return function (p0) {
      return _get_listeners__760gzy(p0);
    };
  }
  function PropertyChangeSupport$add$lambda($handler) {
    return function (e) {
      $handler(e);
      return Unit_instance;
    };
  }
  function PropertyChangeSupport(source) {
    this.jr_1 = source;
    var tmp = this;
    tmp.kr_1 = lazy(PropertyChangeSupport$listeners$delegate$lambda);
  }
  protoOf(PropertyChangeSupport).xr = function (l) {
    if (!_get_listeners__760gzy(this).n(l)) {
      _get_listeners__760gzy(this).h(l);
    }
  };
  protoOf(PropertyChangeSupport).h1b = function (handler) {
    var tmp = PropertyChangeSupport$add$lambda(handler);
    var listener = new sam$io_antarescircuit_jabbah_base_event_PropertyChangeListener$0(tmp);
    this.xr(listener);
    return listener;
  };
  protoOf(PropertyChangeSupport).yr = function (l) {
    return _get_listeners__760gzy(this).h2(l);
  };
  protoOf(PropertyChangeSupport).lr = function (name, oldValue, newValue) {
    return fire(this, new PropertyChangeEvent(this.jr_1, name, oldValue, newValue));
  };
  function Companion_11() {
    this.i1b_1 = 1;
    this.j1b_1 = 2;
    this.k1b_1 = 4;
    this.l1b_1 = 8;
  }
  var Companion_instance_11;
  function Companion_getInstance_11() {
    return Companion_instance_11;
  }
  function AbstractRectangularShape(x, y, width, height) {
    this.ho_1 = x;
    this.io_1 = y;
    this.jo_1 = width;
    this.ko_1 = height;
  }
  protoOf(AbstractRectangularShape).m1b = function (_set____db54di) {
    this.ho_1 = _set____db54di;
  };
  protoOf(AbstractRectangularShape).z19 = function () {
    return this.ho_1;
  };
  protoOf(AbstractRectangularShape).n1b = function (_set____db54di) {
    this.io_1 = _set____db54di;
  };
  protoOf(AbstractRectangularShape).a1a = function () {
    return this.io_1;
  };
  protoOf(AbstractRectangularShape).o1b = function (_set____db54di) {
    this.jo_1 = _set____db54di;
  };
  protoOf(AbstractRectangularShape).p1b = function () {
    return this.jo_1;
  };
  protoOf(AbstractRectangularShape).q1b = function (_set____db54di) {
    this.ko_1 = _set____db54di;
  };
  protoOf(AbstractRectangularShape).r1b = function () {
    return this.ko_1;
  };
  protoOf(AbstractRectangularShape).do = function () {
    return this;
  };
  protoOf(AbstractRectangularShape).s1b = function (x, y, width, height) {
    this.m1b(x);
    this.n1b(y);
    this.o1b(width);
    this.q1b(height);
  };
  protoOf(AbstractRectangularShape).go = function (x, y, w, h) {
    if (this.ov() || w <= 0 || h <= 0) {
      return false;
    }
    return x + w > this.z19() && y + h > this.a1a() && x < this.z19() + this.p1b() && y < this.a1a() + this.r1b();
  };
  protoOf(AbstractRectangularShape).t1b = function (x, y) {
    var out = 0;
    if (this.p1b() <= 0) {
      out = out | 5;
    } else if (x < this.z19()) {
      out = out | 1;
    } else if (x > this.z19() + this.p1b()) {
      out = out | 4;
    }
    if (this.r1b() <= 0) {
      out = out | 10;
    } else if (y < this.a1a()) {
      out = out | 2;
    } else if (y > this.a1a() + this.r1b()) {
      out = out | 8;
    }
    return out;
  };
  protoOf(AbstractRectangularShape).u1b = function (xx1, yy1, x2, y2) {
    var x1 = xx1;
    var y1 = yy1;
    var out2 = this.t1b(x2, y2);
    if (out2 === 0) {
      return true;
    }
    var out1 = this.t1b(x1, y1);
    while (!(out1 === 0)) {
      if (!((out1 & out2) === 0)) {
        return false;
      }
      if (!((out1 & 5) === 0)) {
        var x = this.z19();
        if (!((out1 & 4) === 0)) {
          x = x + this.p1b();
        }
        y1 = y1 + (x - x1) * (y2 - y1) / (x2 - x1);
        x1 = x;
      } else {
        var y = this.a1a();
        if (!((out1 & 8) === 0)) {
          y = y + this.r1b();
        }
        x1 = x1 + (y - y1) * (x2 - x1) / (y2 - y1);
        y1 = y;
      }
      out1 = this.t1b(x1, y1);
    }
    return true;
  };
  function AffineTransform() {
  }
  function NonInvertibleTransformException(msg) {
    extendThrowable(this, msg);
    captureStack(this, NonInvertibleTransformException);
  }
  function AffineTransformImpl_init_$Init$($this) {
    AffineTransformImpl.call($this, 1.0, VOID, VOID, 1.0);
    return $this;
  }
  function AffineTransformImpl_init_$Create$() {
    return AffineTransformImpl_init_$Init$(objectCreate(protoOf(AffineTransformImpl)));
  }
  function AffineTransformImpl_init_$Init$_0(t, $this) {
    AffineTransformImpl.call($this, t.e1d_1, t.f1d_1, t.g1d_1, t.h1d_1, t.i1d_1, t.j1d_1);
    return $this;
  }
  function AffineTransformImpl_init_$Create$_0(t) {
    return AffineTransformImpl_init_$Init$_0(t, objectCreate(protoOf(AffineTransformImpl)));
  }
  function Companion_12() {
    Companion_instance_12 = this;
    this.m1d_1 = -1;
    this.n1d_1 = 0;
    this.o1d_1 = 1;
    this.p1d_1 = 8;
    this.q1d_1 = 16;
    this.r1d_1 = 0;
    this.s1d_1 = 1;
    this.t1d_1 = 2;
    this.u1d_1 = 4;
    this.v1d_1 = 3;
    this.w1d_1 = 0;
    this.x1d_1 = 8;
    this.y1d_1 = 16;
    this.z1d_1 = 32;
    var tmp = this;
    // Inline function 'kotlin.intArrayOf' call
    tmp.a1e_1 = new Int32Array([4, 5, 4, 5, 2, 3, 6, 7]);
  }
  var Companion_instance_12;
  function Companion_getInstance_12() {
    if (Companion_instance_12 == null)
      new Companion_12();
    return Companion_instance_12;
  }
  function updateState($this) {
    if ($this.g1d_1 === 0.0 && $this.f1d_1 === 0.0) {
      if ($this.e1d_1 === 1.0 && $this.h1d_1 === 1.0) {
        if ($this.i1d_1 === 0.0 && $this.j1d_1 === 0.0) {
          $this.l1d_1 = 0;
          $this.k1d_1 = 0;
        } else {
          $this.l1d_1 = 1;
          $this.k1d_1 = 1;
        }
      } else {
        if ($this.i1d_1 === 0.0 && $this.j1d_1 === 0.0) {
          $this.l1d_1 = 2;
          $this.k1d_1 = -1;
        } else {
          $this.l1d_1 = 3;
          $this.k1d_1 = -1;
        }
      }
    } else {
      if ($this.e1d_1 === 0.0 && $this.h1d_1 === 0.0) {
        if ($this.i1d_1 === 0.0 && $this.j1d_1 === 0.0) {
          $this.l1d_1 = 4;
          $this.k1d_1 = -1;
        } else {
          $this.l1d_1 = 5;
          $this.k1d_1 = -1;
        }
      } else {
        if ($this.i1d_1 === 0.0 && $this.j1d_1 === 0.0) {
          $this.l1d_1 = 6;
          $this.k1d_1 = -1;
        } else {
          $this.l1d_1 = 7;
          $this.k1d_1 = -1;
        }
      }
    }
  }
  function rotate90($this) {
    var M0 = $this.e1d_1;
    $this.e1d_1 = $this.g1d_1;
    $this.g1d_1 = -M0;
    M0 = $this.f1d_1;
    $this.f1d_1 = $this.h1d_1;
    $this.h1d_1 = -M0;
    var state = Companion_getInstance_12().a1e_1[$this.l1d_1];
    if ((state & 6) === 2 && $this.e1d_1 === 1.0 && $this.h1d_1 === 1.0) {
      state = state - 2 | 0;
    }
    $this.l1d_1 = state;
    $this.k1d_1 = -1;
  }
  function rotate180($this) {
    $this.e1d_1 = -$this.e1d_1;
    $this.h1d_1 = -$this.h1d_1;
    var state = $this.l1d_1;
    if (!((state & 4) === 0)) {
      $this.g1d_1 = -$this.g1d_1;
      $this.f1d_1 = -$this.f1d_1;
    } else {
      if ($this.e1d_1 === 1.0 && $this.h1d_1 === 1.0) {
        $this.l1d_1 = state & -3;
      } else {
        $this.l1d_1 = state | 2;
      }
    }
    $this.k1d_1 = -1;
  }
  function rotate270($this) {
    var M0 = $this.e1d_1;
    $this.e1d_1 = -$this.g1d_1;
    $this.g1d_1 = M0;
    M0 = $this.f1d_1;
    $this.f1d_1 = -$this.h1d_1;
    $this.h1d_1 = M0;
    var state = Companion_getInstance_12().a1e_1[$this.l1d_1];
    if ((state & 6) === 2 && $this.e1d_1 === 1.0 && $this.h1d_1 === 1.0) {
      state = state - 2 | 0;
    }
    $this.l1d_1 = state;
    $this.k1d_1 = -1;
  }
  function AffineTransformImpl(m00, m10, m01, m11, m02, m12) {
    Companion_getInstance_12();
    m00 = m00 === VOID ? 0.0 : m00;
    m10 = m10 === VOID ? 0.0 : m10;
    m01 = m01 === VOID ? 0.0 : m01;
    m11 = m11 === VOID ? 0.0 : m11;
    m02 = m02 === VOID ? 0.0 : m02;
    m12 = m12 === VOID ? 0.0 : m12;
    this.e1d_1 = m00;
    this.f1d_1 = m10;
    this.g1d_1 = m01;
    this.h1d_1 = m11;
    this.i1d_1 = m02;
    this.j1d_1 = m12;
    this.k1d_1 = -1;
    this.l1d_1 = 0;
    updateState(this);
  }
  protoOf(AffineTransformImpl).u1c = function () {
    // Inline function 'kotlin.doubleArrayOf' call
    return new Float64Array([this.e1d_1, this.f1d_1, this.g1d_1, this.h1d_1, this.i1d_1, this.j1d_1]);
  };
  protoOf(AffineTransformImpl).gn = function () {
    return this.b1e();
  };
  protoOf(AffineTransformImpl).s1c = function () {
    return this.e1d_1 * this.h1d_1 - this.g1d_1 * this.f1d_1;
  };
  protoOf(AffineTransformImpl).b1d = function () {
    this.e1d_1 = 1.0;
    this.h1d_1 = 1.0;
    this.f1d_1 = 0.0;
    this.g1d_1 = 0.0;
    this.i1d_1 = 0.0;
    this.j1d_1 = 0.0;
    this.l1d_1 = 0;
    this.k1d_1 = 0;
  };
  protoOf(AffineTransformImpl).c1d = function (tx, ty) {
    this.e1d_1 = 1.0;
    this.f1d_1 = 0.0;
    this.g1d_1 = 0.0;
    this.h1d_1 = 1.0;
    this.i1d_1 = tx;
    this.j1d_1 = ty;
    if (!(tx === 0.0) || !(ty === 0.0)) {
      this.l1d_1 = 1;
      this.k1d_1 = 1;
    } else {
      this.l1d_1 = 0;
      this.k1d_1 = 0;
    }
  };
  protoOf(AffineTransformImpl).d1d = function (theta, anchorX, anchorY) {
    this.c1e(theta);
    var sin = this.f1d_1;
    var oneMinusCos = 1.0 - this.e1d_1;
    this.i1d_1 = anchorX * oneMinusCos + anchorY * sin;
    this.j1d_1 = anchorY * oneMinusCos - anchorX * sin;
    if (!(this.i1d_1 === 0.0) || !(this.j1d_1 === 0.0)) {
      this.l1d_1 = this.l1d_1 | 1;
      this.k1d_1 = this.k1d_1 | 1;
    }
  };
  protoOf(AffineTransformImpl).c1e = function (theta) {
    // Inline function 'kotlin.math.sin' call
    var sin = Math.sin(theta);
    var cos;
    if (sin === 1.0 || sin === -1.0) {
      cos = 0.0;
      this.l1d_1 = 4;
      this.k1d_1 = 8;
    } else {
      // Inline function 'kotlin.math.cos' call
      cos = Math.cos(theta);
      var tmp0_subject = cos;
      if (tmp0_subject === -1.0) {
        sin = 0.0;
        this.l1d_1 = 2;
        this.k1d_1 = 8;
      } else if (tmp0_subject === 1.0) {
        sin = 0.0;
        this.l1d_1 = 0;
        this.k1d_1 = 0;
      } else {
        this.l1d_1 = 6;
        this.k1d_1 = 16;
      }
    }
    this.e1d_1 = cos;
    this.f1d_1 = sin;
    this.g1d_1 = -sin;
    this.h1d_1 = cos;
    this.i1d_1 = 0.0;
    this.j1d_1 = 0.0;
  };
  protoOf(AffineTransformImpl).v1c = function (tx, ty) {
    switch (this.l1d_1) {
      case 7:
        this.i1d_1 = this.i1d_1 + (tx * this.e1d_1 + ty * this.g1d_1);
        this.j1d_1 = this.j1d_1 + (tx * this.f1d_1 + ty * this.h1d_1);
        if (this.i1d_1 === 0.0 && this.j1d_1 === 0.0) {
          this.l1d_1 = 6;
          if (!(this.k1d_1 === -1)) {
            this.k1d_1 = this.k1d_1 - 1 | 0;
          }
        }

        return Unit_instance;
      case 6:
        this.i1d_1 = tx * this.e1d_1 + ty * this.g1d_1;
        this.j1d_1 = tx * this.f1d_1 + ty * this.h1d_1;
        if (!(this.i1d_1 === 0.0) || !(this.j1d_1 === 0.0)) {
          this.l1d_1 = 7;
          this.k1d_1 = this.k1d_1 | 1;
        }

        return Unit_instance;
      case 5:
        this.i1d_1 = this.i1d_1 + ty * this.g1d_1;
        this.j1d_1 = this.j1d_1 + tx * this.f1d_1;
        if (this.i1d_1 === 0.0 && this.j1d_1 === 0.0) {
          this.l1d_1 = 4;
          if (!(this.k1d_1 === -1)) {
            this.k1d_1 = this.k1d_1 - 1 | 0;
          }
        }

        return Unit_instance;
      case 4:
        this.i1d_1 = ty * this.g1d_1;
        this.j1d_1 = tx * this.f1d_1;
        if (!(this.i1d_1 === 0.0) || !(this.j1d_1 === 0.0)) {
          this.l1d_1 = 5;
          this.k1d_1 = this.k1d_1 | 1;
        }

        return Unit_instance;
      case 3:
        this.i1d_1 = this.i1d_1 + tx * this.e1d_1;
        this.j1d_1 = this.j1d_1 + ty * this.h1d_1;
        if (this.i1d_1 === 0.0 && this.j1d_1 === 0.0) {
          this.l1d_1 = 2;
          if (!(this.k1d_1 === -1)) {
            this.k1d_1 = this.k1d_1 - 1 | 0;
          }
        }

        return Unit_instance;
      case 2:
        this.i1d_1 = tx * this.e1d_1;
        this.j1d_1 = ty * this.h1d_1;
        if (!(this.i1d_1 === 0.0) || !(this.j1d_1 === 0.0)) {
          this.l1d_1 = 3;
          this.k1d_1 = this.k1d_1 | 1;
        }

        return Unit_instance;
      case 1:
        this.i1d_1 = this.i1d_1 + tx;
        this.j1d_1 = this.j1d_1 + ty;
        if (this.i1d_1 === 0.0 && this.j1d_1 === 0.0) {
          this.l1d_1 = 0;
          this.k1d_1 = 0;
        }

        return Unit_instance;
      case 0:
        this.i1d_1 = tx;
        this.j1d_1 = ty;
        if (!(tx === 0.0) || !(ty === 0.0)) {
          this.l1d_1 = 1;
          this.k1d_1 = 1;
        }

        return Unit_instance;
    }
  };
  protoOf(AffineTransformImpl).x1c = function (sx, sy) {
    var state = this.l1d_1;
    switch (state) {
      case 7:
      case 6:
        this.e1d_1 = this.e1d_1 * sx;
        this.h1d_1 = this.h1d_1 * sy;
        this.g1d_1 = this.g1d_1 * sy;
        this.f1d_1 = this.f1d_1 * sx;
        if (this.g1d_1 === 0.0 && this.f1d_1 === 0.0) {
          state = state & 1;
          if (this.e1d_1 === 1.0 && this.h1d_1 === 1.0) {
            this.k1d_1 = state === 0 ? 0 : 1;
          } else {
            state = state | 2;
            this.k1d_1 = -1;
          }
          this.l1d_1 = state;
        }

        return Unit_instance;
      case 5:
      case 4:
        this.g1d_1 = this.g1d_1 * sy;
        this.f1d_1 = this.f1d_1 * sx;
        if (this.g1d_1 === 0.0 && this.f1d_1 === 0.0) {
          state = state & 1;
          if (this.e1d_1 === 1.0 && this.h1d_1 === 1.0) {
            this.k1d_1 = state === 0 ? 0 : 1;
          } else {
            state = state | 2;
            this.k1d_1 = -1;
          }
          this.l1d_1 = state;
        }

        return Unit_instance;
      case 3:
      case 2:
        this.e1d_1 = this.e1d_1 * sx;
        this.h1d_1 = this.h1d_1 * sy;
        if (this.e1d_1 === 1.0 && this.h1d_1 === 1.0) {
          state = state & 1;
          this.l1d_1 = state;
          this.k1d_1 = state === 0 ? 0 : 1;
        } else {
          this.k1d_1 = -1;
        }

        return Unit_instance;
      case 1:
      case 0:
        this.e1d_1 = sx;
        this.h1d_1 = sy;
        if (!(sx === 1.0) || !(sy === 1.0)) {
          this.l1d_1 = state | 2;
          this.k1d_1 = -1;
        }

        return Unit_instance;
    }
  };
  protoOf(AffineTransformImpl).y1c = function (theta) {
    // Inline function 'kotlin.math.sin' call
    var sin = Math.sin(theta);
    if (sin === 1.0) {
      rotate90(this);
    } else if (sin === -1.0) {
      rotate270(this);
    } else {
      // Inline function 'kotlin.math.cos' call
      var cos = Math.cos(theta);
      if (cos === -1.0) {
        rotate180(this);
      } else if (!(cos === 1.0)) {
        var M0 = this.e1d_1;
        var M1 = this.g1d_1;
        this.e1d_1 = cos * M0 + sin * M1;
        this.g1d_1 = -sin * M0 + cos * M1;
        M0 = this.f1d_1;
        M1 = this.h1d_1;
        this.f1d_1 = cos * M0 + sin * M1;
        this.h1d_1 = -sin * M0 + cos * M1;
        updateState(this);
      }
    }
  };
  protoOf(AffineTransformImpl).ln = function (ptSrc) {
    var x = ptSrc.in_1;
    var y = ptSrc.jn_1;
    switch (this.l1d_1) {
      case 7:
        return new Point2D(x * this.e1d_1 + y * this.g1d_1 + this.i1d_1, x * this.f1d_1 + y * this.h1d_1 + this.j1d_1);
      case 6:
        return new Point2D(x * this.e1d_1 + y * this.g1d_1, x * this.f1d_1 + y * this.h1d_1);
      case 5:
        return new Point2D(y * this.g1d_1 + this.i1d_1, x * this.f1d_1 + this.j1d_1);
      case 4:
        return new Point2D(y * this.g1d_1, x * this.f1d_1);
      case 3:
        return new Point2D(x * this.e1d_1 + this.i1d_1, y * this.h1d_1 + this.j1d_1);
      case 2:
        return new Point2D(x * this.e1d_1, y * this.h1d_1);
      case 1:
        return new Point2D(x + this.i1d_1, y + this.j1d_1);
      case 0:
        return new Point2D(x, y);
      default:
        return Companion_getInstance_14().g1a_1;
    }
  };
  protoOf(AffineTransformImpl).z1c = function (ptSrc) {
    var x = ptSrc.in_1;
    var y = ptSrc.jn_1;
    var tmp;
    switch (this.l1d_1) {
      case 7:
        x = x - this.i1d_1;
        y = y - this.j1d_1;
        var det = this.e1d_1 * this.h1d_1 - this.g1d_1 * this.f1d_1;
        // Inline function 'kotlin.math.abs' call

        if (Math.abs(det) <= 4.9E-324) {
          throw new NonInvertibleTransformException('Determinant is ' + det);
        }

        tmp = new Point2D((x * this.h1d_1 - y * this.g1d_1) / det, (y * this.e1d_1 - x * this.f1d_1) / det);
        break;
      case 6:
        var det_0 = this.e1d_1 * this.h1d_1 - this.g1d_1 * this.f1d_1;
        // Inline function 'kotlin.math.abs' call

        if (Math.abs(det_0) <= 4.9E-324) {
          throw new NonInvertibleTransformException('Determinant is ' + det_0);
        }

        tmp = new Point2D((x * this.h1d_1 - y * this.g1d_1) / det_0, (y * this.e1d_1 - x * this.f1d_1) / det_0);
        break;
      case 5:
        x = x - this.i1d_1;
        y = y - this.j1d_1;
        if (this.g1d_1 === 0.0 || this.f1d_1 === 0.0) {
          throw new NonInvertibleTransformException('Determinant is 0');
        }

        tmp = new Point2D(y / this.f1d_1, x / this.g1d_1);
        break;
      case 4:
        if (this.g1d_1 === 0.0 || this.f1d_1 === 0.0) {
          throw new NonInvertibleTransformException('Determinant is 0');
        }

        tmp = new Point2D(y / this.f1d_1, x / this.g1d_1);
        break;
      case 3:
        x = x - this.i1d_1;
        y = y - this.j1d_1;
        if (this.e1d_1 === 0.0 || this.h1d_1 === 0.0) {
          throw new NonInvertibleTransformException('Determinant is 0');
        }

        tmp = new Point2D(x / this.e1d_1, y / this.h1d_1);
        break;
      case 2:
        if (this.e1d_1 === 0.0 || this.h1d_1 === 0.0) {
          throw new NonInvertibleTransformException('Determinant is 0');
        }

        tmp = new Point2D(x / this.e1d_1, y / this.h1d_1);
        break;
      case 1:
        tmp = new Point2D(x - this.i1d_1, y - this.j1d_1);
        break;
      case 0:
        tmp = new Point2D(x, y);
        break;
      default:
        return Companion_getInstance_14().g1a_1;
    }
    return tmp;
  };
  protoOf(AffineTransformImpl).a1d = function (Tx) {
    if (!(Tx instanceof AffineTransformImpl)) {
      throw IllegalArgumentException_init_$Create$('unsupported ' + getKClassFromExpression(Tx).l9());
    }
    var M0;
    var M1;
    var T00 = Tx.e1d_1;
    var T01;
    var T10;
    var T11 = Tx.h1d_1;
    var T02 = Tx.i1d_1;
    var T12 = Tx.j1d_1;
    var mystate = this.l1d_1;
    var txstate = Tx.l1d_1;
    switch (txstate << 3 | mystate) {
      case 0:
      case 1:
      case 2:
      case 3:
      case 4:
      case 5:
      case 6:
      case 7:
        return Unit_instance;
      case 56:
        this.g1d_1 = Tx.g1d_1;
        this.f1d_1 = Tx.f1d_1;
        this.e1d_1 = Tx.e1d_1;
        this.h1d_1 = Tx.h1d_1;
        this.i1d_1 = Tx.i1d_1;
        this.j1d_1 = Tx.j1d_1;
        this.l1d_1 = txstate;
        this.k1d_1 = Tx.k1d_1;
        return Unit_instance;
      case 24:
        this.e1d_1 = Tx.e1d_1;
        this.h1d_1 = Tx.h1d_1;
        this.i1d_1 = Tx.i1d_1;
        this.j1d_1 = Tx.j1d_1;
        this.l1d_1 = txstate;
        this.k1d_1 = Tx.k1d_1;
        return Unit_instance;
      case 8:
        this.i1d_1 = Tx.i1d_1;
        this.j1d_1 = Tx.j1d_1;
        this.l1d_1 = txstate;
        this.k1d_1 = Tx.k1d_1;
        return Unit_instance;
      case 48:
        this.g1d_1 = Tx.g1d_1;
        this.f1d_1 = Tx.f1d_1;
        this.e1d_1 = Tx.e1d_1;
        this.h1d_1 = Tx.h1d_1;
        this.l1d_1 = txstate;
        this.k1d_1 = Tx.k1d_1;
        return Unit_instance;
      case 16:
        this.e1d_1 = Tx.e1d_1;
        this.h1d_1 = Tx.h1d_1;
        this.l1d_1 = txstate;
        this.k1d_1 = Tx.k1d_1;
        return Unit_instance;
      case 40:
        this.i1d_1 = Tx.i1d_1;
        this.j1d_1 = Tx.j1d_1;
        this.g1d_1 = Tx.g1d_1;
        this.f1d_1 = Tx.f1d_1;
        this.h1d_1 = 0.0;
        this.e1d_1 = this.h1d_1;
        this.l1d_1 = txstate;
        this.k1d_1 = Tx.k1d_1;
        return Unit_instance;
      case 32:
        this.g1d_1 = Tx.g1d_1;
        this.f1d_1 = Tx.f1d_1;
        this.h1d_1 = 0.0;
        this.e1d_1 = this.h1d_1;
        this.l1d_1 = txstate;
        this.k1d_1 = Tx.k1d_1;
        return Unit_instance;
      case 15:
      case 14:
      case 13:
      case 12:
      case 11:
      case 10:
      case 9:
        this.v1c(Tx.i1d_1, Tx.j1d_1);
        return Unit_instance;
      case 23:
      case 22:
      case 21:
      case 20:
      case 19:
      case 18:
      case 17:
        this.x1c(Tx.e1d_1, Tx.h1d_1);
        return Unit_instance;
      case 39:
      case 38:
        T01 = Tx.g1d_1;
        T10 = Tx.f1d_1;
        M0 = this.e1d_1;
        this.e1d_1 = this.g1d_1 * T10;
        this.g1d_1 = M0 * T01;
        M0 = this.f1d_1;
        this.f1d_1 = this.h1d_1 * T10;
        this.h1d_1 = M0 * T01;
        this.k1d_1 = -1;
        return Unit_instance;
      case 37:
      case 36:
        this.e1d_1 = this.g1d_1 * Tx.f1d_1;
        this.g1d_1 = 0.0;
        this.h1d_1 = this.f1d_1 * Tx.g1d_1;
        this.f1d_1 = 0.0;
        this.l1d_1 = mystate ^ 6;
        this.k1d_1 = -1;
        return Unit_instance;
      case 35:
      case 34:
        this.g1d_1 = this.e1d_1 * Tx.g1d_1;
        this.e1d_1 = 0.0;
        this.f1d_1 = this.h1d_1 * Tx.f1d_1;
        this.h1d_1 = 0.0;
        this.l1d_1 = mystate ^ 6;
        this.k1d_1 = -1;
        return Unit_instance;
      case 33:
        this.e1d_1 = 0.0;
        this.g1d_1 = Tx.g1d_1;
        this.f1d_1 = Tx.f1d_1;
        this.h1d_1 = 0.0;
        this.l1d_1 = 5;
        this.k1d_1 = -1;
        return Unit_instance;
    }
    T01 = Tx.g1d_1;
    T10 = Tx.f1d_1;
    switch (mystate) {
      case 6:
        this.l1d_1 = mystate | txstate;
        M0 = this.e1d_1;
        M1 = this.g1d_1;
        this.e1d_1 = T00 * M0 + T10 * M1;
        this.g1d_1 = T01 * M0 + T11 * M1;
        this.i1d_1 = this.i1d_1 + (T02 * M0 + T12 * M1);
        M0 = this.f1d_1;
        M1 = this.h1d_1;
        this.f1d_1 = T00 * M0 + T10 * M1;
        this.h1d_1 = T01 * M0 + T11 * M1;
        this.j1d_1 = this.j1d_1 + (T02 * M0 + T12 * M1);
        this.k1d_1 = -1;
        return Unit_instance;
      case 7:
        M0 = this.e1d_1;
        M1 = this.g1d_1;
        this.e1d_1 = T00 * M0 + T10 * M1;
        this.g1d_1 = T01 * M0 + T11 * M1;
        this.i1d_1 = this.i1d_1 + (T02 * M0 + T12 * M1);
        M0 = this.f1d_1;
        M1 = this.h1d_1;
        this.f1d_1 = T00 * M0 + T10 * M1;
        this.h1d_1 = T01 * M0 + T11 * M1;
        this.j1d_1 = this.j1d_1 + (T02 * M0 + T12 * M1);
        this.k1d_1 = -1;
        return Unit_instance;
      case 5:
      case 4:
        M0 = this.g1d_1;
        this.e1d_1 = T10 * M0;
        this.g1d_1 = T11 * M0;
        this.i1d_1 = this.i1d_1 + T12 * M0;
        M0 = this.f1d_1;
        this.f1d_1 = T00 * M0;
        this.h1d_1 = T01 * M0;
        this.j1d_1 = this.j1d_1 + T02 * M0;
        break;
      case 3:
      case 2:
        M0 = this.e1d_1;
        this.e1d_1 = T00 * M0;
        this.g1d_1 = T01 * M0;
        this.i1d_1 = this.i1d_1 + T02 * M0;
        M0 = this.h1d_1;
        this.f1d_1 = T10 * M0;
        this.h1d_1 = T11 * M0;
        this.j1d_1 = this.j1d_1 + T12 * M0;
        break;
      case 1:
        this.e1d_1 = T00;
        this.g1d_1 = T01;
        this.i1d_1 = this.i1d_1 + T02;
        this.f1d_1 = T10;
        this.h1d_1 = T11;
        this.j1d_1 = this.j1d_1 + T12;
        this.l1d_1 = txstate | 1;
        this.k1d_1 = -1;
        return Unit_instance;
    }
    updateState(this);
  };
  protoOf(AffineTransformImpl).d1e = function (m00, m10, m01, m11, m02, m12) {
    return new AffineTransformImpl(m00, m10, m01, m11, m02, m12);
  };
  protoOf(AffineTransformImpl).b1e = function (m00, m10, m01, m11, m02, m12, $super) {
    m00 = m00 === VOID ? this.e1d_1 : m00;
    m10 = m10 === VOID ? this.f1d_1 : m10;
    m01 = m01 === VOID ? this.g1d_1 : m01;
    m11 = m11 === VOID ? this.h1d_1 : m11;
    m02 = m02 === VOID ? this.i1d_1 : m02;
    m12 = m12 === VOID ? this.j1d_1 : m12;
    return $super === VOID ? this.d1e(m00, m10, m01, m11, m02, m12) : $super.d1e.call(this, m00, m10, m01, m11, m02, m12);
  };
  protoOf(AffineTransformImpl).toString = function () {
    return 'AffineTransformImpl(m00=' + this.e1d_1 + ', m10=' + this.f1d_1 + ', m01=' + this.g1d_1 + ', m11=' + this.h1d_1 + ', m02=' + this.i1d_1 + ', m12=' + this.j1d_1 + ')';
  };
  protoOf(AffineTransformImpl).hashCode = function () {
    var result = getNumberHashCode(this.e1d_1);
    result = imul(result, 31) + getNumberHashCode(this.f1d_1) | 0;
    result = imul(result, 31) + getNumberHashCode(this.g1d_1) | 0;
    result = imul(result, 31) + getNumberHashCode(this.h1d_1) | 0;
    result = imul(result, 31) + getNumberHashCode(this.i1d_1) | 0;
    result = imul(result, 31) + getNumberHashCode(this.j1d_1) | 0;
    return result;
  };
  protoOf(AffineTransformImpl).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof AffineTransformImpl))
      return false;
    if (!equals(this.e1d_1, other.e1d_1))
      return false;
    if (!equals(this.f1d_1, other.f1d_1))
      return false;
    if (!equals(this.g1d_1, other.g1d_1))
      return false;
    if (!equals(this.h1d_1, other.h1d_1))
      return false;
    if (!equals(this.i1d_1, other.i1d_1))
      return false;
    if (!equals(this.j1d_1, other.j1d_1))
      return false;
    return true;
  };
  function Dimension2D_init_$Init$(width, height, $this) {
    Dimension2D.call($this, width, height);
    return $this;
  }
  function Dimension2D_init_$Create$(width, height) {
    return Dimension2D_init_$Init$(width, height, objectCreate(protoOf(Dimension2D)));
  }
  function Dimension2D(width, height) {
    this.e1e_1 = width;
    this.f1e_1 = height;
    this.g1e_1 = numberToInt(this.e1e_1);
    this.h1e_1 = numberToInt(this.f1e_1);
  }
  protoOf(Dimension2D).toString = function () {
    return 'Dimension2D(width=' + this.e1e_1 + ', height=' + this.f1e_1 + ')';
  };
  protoOf(Dimension2D).hashCode = function () {
    var result = getNumberHashCode(this.e1e_1);
    result = imul(result, 31) + getNumberHashCode(this.f1e_1) | 0;
    return result;
  };
  protoOf(Dimension2D).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof Dimension2D))
      return false;
    if (!equals(this.e1e_1, other.e1e_1))
      return false;
    if (!equals(this.f1e_1, other.f1e_1))
      return false;
    return true;
  };
  var Direction_EAST_instance;
  var Direction_NORTH_instance;
  var Direction_WEST_instance;
  var Direction_SOUTH_instance;
  function Companion_13() {
    Companion_instance_13 = this;
    this.i1e_1 = setOf([Direction_EAST_getInstance(), Direction_NORTH_getInstance(), Direction_WEST_getInstance(), Direction_SOUTH_getInstance()]);
    this.j1e_1 = setOf([Direction_EAST_getInstance(), Direction_WEST_getInstance()]);
    this.k1e_1 = setOf([Direction_NORTH_getInstance(), Direction_SOUTH_getInstance()]);
    this.l1e_1 = setOf([Direction_EAST_getInstance(), Direction_NORTH_getInstance()]);
    this.m1e_1 = setOf([Direction_NORTH_getInstance(), Direction_WEST_getInstance()]);
    this.n1e_1 = setOf([Direction_SOUTH_getInstance(), Direction_EAST_getInstance()]);
    this.o1e_1 = setOf([Direction_SOUTH_getInstance(), Direction_WEST_getInstance()]);
    this.p1e_1 = mapOf([to(Direction_EAST_getInstance(), setOf([Direction_NORTH_getInstance(), Direction_SOUTH_getInstance()])), to(Direction_NORTH_getInstance(), setOf([Direction_EAST_getInstance(), Direction_WEST_getInstance()])), to(Direction_WEST_getInstance(), setOf([Direction_NORTH_getInstance(), Direction_SOUTH_getInstance()])), to(Direction_SOUTH_getInstance(), setOf([Direction_EAST_getInstance(), Direction_WEST_getInstance()]))]);
    this.q1e_1 = mapOf([to(Direction_EAST_getInstance(), setOf([Direction_NORTH_getInstance(), Direction_SOUTH_getInstance(), Direction_WEST_getInstance()])), to(Direction_NORTH_getInstance(), setOf([Direction_EAST_getInstance(), Direction_SOUTH_getInstance(), Direction_WEST_getInstance()])), to(Direction_WEST_getInstance(), setOf([Direction_NORTH_getInstance(), Direction_EAST_getInstance(), Direction_SOUTH_getInstance()])), to(Direction_SOUTH_getInstance(), setOf([Direction_NORTH_getInstance(), Direction_EAST_getInstance(), Direction_WEST_getInstance()]))]);
  }
  protoOf(Companion_13).r1e = function (name) {
    var indexedObject = values_1();
    var inductionVariable = 0;
    var last = indexedObject.length;
    while (inductionVariable < last) {
      var dir = indexedObject[inductionVariable];
      inductionVariable = inductionVariable + 1 | 0;
      if (dir.u1e_1 === name) {
        return dir;
      }
    }
    throw IllegalArgumentException_init_$Create$('unknown Direction ' + name);
  };
  protoOf(Companion_13).y1e = function (dx, dy) {
    var tmp0_elvis_lhs = this.z1e(dx, dy);
    var tmp;
    if (tmp0_elvis_lhs == null) {
      throw IllegalArgumentException_init_$Create$('Cannot determine Direction for (' + dx + ',' + dy + ')');
    } else {
      tmp = tmp0_elvis_lhs;
    }
    return tmp;
  };
  protoOf(Companion_13).z1e = function (dx, dy) {
    var indexedObject = values_1();
    var inductionVariable = 0;
    var last = indexedObject.length;
    while (inductionVariable < last) {
      var dir = indexedObject[inductionVariable];
      inductionVariable = inductionVariable + 1 | 0;
      if (dir.v1e_1 === dx && dir.w1e_1 === dy) {
        return dir;
      }
    }
    return null;
  };
  protoOf(Companion_13).a1f = function (p1, p2) {
    return this.z1e(numberToInt(Geometry_instance.b1f(p2.in_1 - p1.in_1)), numberToInt(Geometry_instance.b1f(p2.jn_1 - p1.jn_1)));
  };
  protoOf(Companion_13).c1f = function (rotation) {
    var indexedObject = values_1();
    var inductionVariable = 0;
    var last = indexedObject.length;
    while (inductionVariable < last) {
      var dir = indexedObject[inductionVariable];
      inductionVariable = inductionVariable + 1 | 0;
      if (dir.x1e_1 === rotation) {
        return dir;
      }
    }
    throw IllegalArgumentException_init_$Create$('Cannot determine Direction for Rotation ' + rotation.toString());
  };
  protoOf(Companion_13).d1f = function (directions) {
    // Inline function 'kotlin.collections.mutableSetOf' call
    var result = LinkedHashSet_init_$Create$();
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = directions.i();
    while (_iterator__ex2g4s.j()) {
      var element = _iterator__ex2g4s.k();
      result.h(element.e1f());
    }
    return result;
  };
  var Companion_instance_13;
  function Companion_getInstance_13() {
    Direction_initEntries();
    if (Companion_instance_13 == null)
      new Companion_13();
    return Companion_instance_13;
  }
  function values_1() {
    return [Direction_EAST_getInstance(), Direction_NORTH_getInstance(), Direction_WEST_getInstance(), Direction_SOUTH_getInstance()];
  }
  var Direction_entriesInitialized;
  function Direction_initEntries() {
    if (Direction_entriesInitialized)
      return Unit_instance;
    Direction_entriesInitialized = true;
    Direction_EAST_instance = new Direction('EAST', 0, 'east', 1, 0, Rotation_R0_getInstance());
    Direction_NORTH_instance = new Direction('NORTH', 1, 'north', 0, -1, Rotation_R90_getInstance());
    Direction_WEST_instance = new Direction('WEST', 2, 'west', -1, 0, Rotation_R180_getInstance());
    Direction_SOUTH_instance = new Direction('SOUTH', 3, 'south', 0, 1, Rotation_R270_getInstance());
    Companion_getInstance_13();
  }
  function Direction(name, ordinal, customName, dx, dy, rotation) {
    Enum.call(this, name, ordinal);
    this.u1e_1 = customName;
    this.v1e_1 = dx;
    this.w1e_1 = dy;
    this.x1e_1 = rotation;
  }
  protoOf(Direction).toString = function () {
    var tmp;
    switch (this.l2_1) {
      case 0:
        tmp = Translations_getInstance().zm('graph.property.direction.east.name', []);
        break;
      case 1:
        tmp = Translations_getInstance().zm('graph.property.direction.north.name', []);
        break;
      case 2:
        tmp = Translations_getInstance().zm('graph.property.direction.west.name', []);
        break;
      case 3:
        tmp = Translations_getInstance().zm('graph.property.direction.south.name', []);
        break;
      default:
        noWhenBranchMatchedException();
        break;
    }
    return tmp;
  };
  protoOf(Direction).k = function () {
    return values_1()[(this.l2_1 + 1 | 0) % 4 | 0];
  };
  protoOf(Direction).o3 = function () {
    return values_1()[(this.l2_1 + 3 | 0) % 4 | 0];
  };
  protoOf(Direction).e1f = function () {
    return values_1()[(this.l2_1 + 2 | 0) % 4 | 0];
  };
  protoOf(Direction).f1f = function () {
    var tmp;
    switch (this.l2_1) {
      case 1:
      case 3:
        tmp = this;
        break;
      case 0:
      case 2:
        tmp = this.e1f();
        break;
      default:
        noWhenBranchMatchedException();
        break;
    }
    return tmp;
  };
  protoOf(Direction).g1f = function () {
    var tmp;
    switch (this.l2_1) {
      case 1:
      case 3:
        tmp = this.e1f();
        break;
      case 0:
      case 2:
        tmp = this;
        break;
      default:
        noWhenBranchMatchedException();
        break;
    }
    return tmp;
  };
  protoOf(Direction).h1f = function () {
    return Companion_getInstance_13().y1e(abs(this.v1e_1), abs(this.w1e_1));
  };
  protoOf(Direction).i1f = function (value) {
    return new Point2D(this.v1e_1 * value, this.w1e_1 * value);
  };
  protoOf(Direction).j1f = function () {
    return this.w1e_1 === 0;
  };
  protoOf(Direction).k1f = function () {
    return this.v1e_1 === 0;
  };
  protoOf(Direction).l1f = function (newDirection) {
    if (newDirection.equals(this)) {
      return Turn_NONE_getInstance();
    }
    if (newDirection.equals(this.e1f())) {
      return Turn_AROUND_getInstance();
    }
    if (newDirection.equals(this.k())) {
      return Turn_LEFT_getInstance();
    }
    return Turn_RIGHT_getInstance();
  };
  protoOf(Direction).m1f = function () {
    return Point2D_init_$Create$_0(this.v1e_1, this.w1e_1);
  };
  protoOf(Direction).n1f = function () {
    return ensureNotNull(Companion_getInstance_13().p1e_1.g2(this));
  };
  protoOf(Direction).o1f = function () {
    return ensureNotNull(Companion_getInstance_13().q1e_1.g2(this));
  };
  function Direction_EAST_getInstance() {
    Direction_initEntries();
    return Direction_EAST_instance;
  }
  function Direction_NORTH_getInstance() {
    Direction_initEntries();
    return Direction_NORTH_instance;
  }
  function Direction_WEST_getInstance() {
    Direction_initEntries();
    return Direction_WEST_instance;
  }
  function Direction_SOUTH_getInstance() {
    Direction_initEntries();
    return Direction_SOUTH_instance;
  }
  function Ellipse2D_init_$Init$(x, y, w, h, $this) {
    Ellipse2D.call($this, x, y, w, h);
    return $this;
  }
  function Ellipse2D_init_$Create$(x, y, w, h) {
    return Ellipse2D_init_$Init$(x, y, w, h, objectCreate(protoOf(Ellipse2D)));
  }
  function Ellipse2D(x, y, width, height) {
    x = x === VOID ? 0.0 : x;
    y = y === VOID ? 0.0 : y;
    width = width === VOID ? 0.0 : width;
    height = height === VOID ? 0.0 : height;
    AbstractRectangularShape.call(this, x, y, width, height);
    this.t1f_1 = x;
    this.u1f_1 = y;
    this.v1f_1 = width;
    this.w1f_1 = height;
  }
  protoOf(Ellipse2D).m1b = function (_set____db54di) {
    this.t1f_1 = _set____db54di;
  };
  protoOf(Ellipse2D).z19 = function () {
    return this.t1f_1;
  };
  protoOf(Ellipse2D).n1b = function (_set____db54di) {
    this.u1f_1 = _set____db54di;
  };
  protoOf(Ellipse2D).a1a = function () {
    return this.u1f_1;
  };
  protoOf(Ellipse2D).o1b = function (_set____db54di) {
    this.v1f_1 = _set____db54di;
  };
  protoOf(Ellipse2D).p1b = function () {
    return this.v1f_1;
  };
  protoOf(Ellipse2D).q1b = function (_set____db54di) {
    this.w1f_1 = _set____db54di;
  };
  protoOf(Ellipse2D).r1b = function () {
    return this.w1f_1;
  };
  protoOf(Ellipse2D).eo = function (x, y) {
    if (this.v1f_1 <= 0.0) {
      return false;
    }
    var xNorm = (x - this.t1f_1) / this.v1f_1 - 0.5;
    if (this.w1f_1 <= 0.0) {
      return false;
    }
    var yNorm = (y - this.u1f_1) / this.w1f_1 - 0.5;
    return xNorm * xNorm + yNorm * yNorm < 0.25;
  };
  protoOf(Ellipse2D).fo = function (x, y, width, height) {
    return this.eo(x, y) && this.eo(x + width, y) && this.eo(x, y + height) && this.eo(x + width, y + height);
  };
  function Geometry() {
  }
  protoOf(Geometry).x1f = function (a, b) {
    // Inline function 'kotlin.math.abs' call
    var x = a - b;
    return Math.abs(x) <= 1.0E-7;
  };
  protoOf(Geometry).b1f = function (value) {
    // Inline function 'kotlin.math.abs' call
    if (Math.abs(value) <= 1.0E-7) {
      return 0.0;
    }
    // Inline function 'kotlin.math.sign' call
    return sign(value);
  };
  protoOf(Geometry).y1f = function (angle) {
    if (angle < 0) {
      // Inline function 'kotlin.math.abs' call
      var x = angle % 6.283185307179586;
      return 6.283185307179586 - Math.abs(x);
    }
    return angle % 6.283185307179586;
  };
  protoOf(Geometry).z1f = function (angle1, angle2) {
    return !(angle1 === angle2) && this.y1f(angle1 - angle2) <= 3.141592653589793;
  };
  protoOf(Geometry).a1g = function (p1, p2) {
    return this.b1g(p1.in_1, p1.jn_1, p2.in_1, p2.jn_1);
  };
  protoOf(Geometry).b1g = function (x1, y1, x2, y2) {
    var fx = x2 > x1 ? 1 : -1;
    var fy = y2 > y1 ? -1 : 1;
    var angle;
    if (x1 === x2 && y1 === y2) {
      return 0.0;
    }
    if (this.x1f(x1, x2)) {
      angle = fy === 1 ? 1.5707963267948966 : 3 * 1.5707963267948966;
    } else {
      // Inline function 'kotlin.math.abs' call
      var x = y2 - y1;
      var tmp = Math.abs(x);
      // Inline function 'kotlin.math.abs' call
      var x_0 = x2 - x1;
      // Inline function 'kotlin.math.atan' call
      var x_1 = tmp / Math.abs(x_0);
      angle = Math.atan(x_1);
      if (fx === 1) {
        if (fy === -1)
          angle = 2 * 3.141592653589793 - angle;
      } else {
        angle = fy === 1 ? 3.141592653589793 - angle : 3.141592653589793 + angle;
      }
    }
    return angle;
  };
  protoOf(Geometry).c1g = function (x1, y1, x2, y2) {
    return new Point2D(-(y2 - y1), x2 - x1);
  };
  protoOf(Geometry).d1g = function (p1, p2) {
    return this.c1g(p1.in_1, p1.jn_1, p2.in_1, p2.jn_1);
  };
  protoOf(Geometry).e1g = function (p1, p2) {
    return new Point2D((p1.in_1 + p2.in_1) / 2, (p1.jn_1 + p2.jn_1) / 2);
  };
  protoOf(Geometry).f1g = function (x, y, angle) {
    // Inline function 'kotlin.math.cos' call
    var tmp = x * Math.cos(angle);
    // Inline function 'kotlin.math.sin' call
    var tmp_0 = tmp - y * Math.sin(angle);
    // Inline function 'kotlin.math.cos' call
    var tmp_1 = y * Math.cos(angle);
    // Inline function 'kotlin.math.sin' call
    var tmp$ret$3 = Math.sin(angle);
    return new Point2D(tmp_0, tmp_1 + x * tmp$ret$3);
  };
  protoOf(Geometry).g1g = function (x, y, center, angle) {
    return center.co(this.f1g(x - center.in_1, y - center.jn_1, angle));
  };
  protoOf(Geometry).h1g = function (p, center, angle) {
    return this.g1g(p.in_1, p.jn_1, center, angle);
  };
  protoOf(Geometry).i1g = function (center, r, p) {
    var angle = this.a1g(center, p);
    // Inline function 'kotlin.math.cos' call
    var tmp$ret$0 = Math.cos(angle);
    var tmp = center.in_1 + r * tmp$ret$0;
    // Inline function 'kotlin.math.sin' call
    var tmp$ret$1 = Math.sin(angle);
    return new Point2D(tmp, center.jn_1 - r * tmp$ret$1);
  };
  protoOf(Geometry).j1g = function (p1, p2, p0) {
    // Inline function 'kotlin.math.pow' call
    var this_0 = p2.jn_1 - p1.jn_1;
    var tmp = Math.pow(this_0, 2);
    // Inline function 'kotlin.math.pow' call
    var this_1 = p2.in_1 - p1.in_1;
    // Inline function 'kotlin.math.sqrt' call
    var x = tmp + Math.pow(this_1, 2);
    var divisor = Math.sqrt(x);
    var tmp_0;
    if (divisor === 0.0) {
      tmp_0 = 0.0;
    } else {
      tmp_0 = ((p2.jn_1 - p1.jn_1) * p0.in_1 - (p2.in_1 - p1.in_1) * p0.jn_1 + p2.in_1 * p1.jn_1 - p2.jn_1 * p1.in_1) / divisor;
    }
    return tmp_0;
  };
  var Geometry_instance;
  function Geometry_getInstance() {
    return Geometry_instance;
  }
  function MutableRectangularShape() {
  }
  function Path() {
  }
  function Companion_14() {
    Companion_instance_14 = this;
    this.g1a_1 = new Point2D();
  }
  protoOf(Companion_14).k1g = function (p1, p2) {
    var tmp0 = p1.in_1;
    // Inline function 'kotlin.math.min' call
    var b = p2.in_1;
    var tmp = Math.min(tmp0, b);
    var tmp0_0 = p1.in_1;
    // Inline function 'kotlin.math.max' call
    var b_0 = p2.in_1;
    var tmp$ret$1 = Math.max(tmp0_0, b_0);
    return rangeTo(tmp, tmp$ret$1);
  };
  protoOf(Companion_14).l1g = function (p1, p2) {
    var tmp0 = p1.jn_1;
    // Inline function 'kotlin.math.min' call
    var b = p2.jn_1;
    var tmp = Math.min(tmp0, b);
    var tmp0_0 = p1.jn_1;
    // Inline function 'kotlin.math.max' call
    var b_0 = p2.jn_1;
    var tmp$ret$1 = Math.max(tmp0_0, b_0);
    return rangeTo(tmp, tmp$ret$1);
  };
  var Companion_instance_14;
  function Companion_getInstance_14() {
    if (Companion_instance_14 == null)
      new Companion_14();
    return Companion_instance_14;
  }
  function Point2D_init_$Init$(p, $this) {
    Point2D.call($this, p.in_1, p.jn_1);
    return $this;
  }
  function Point2D_init_$Create$(p) {
    return Point2D_init_$Init$(p, objectCreate(protoOf(Point2D)));
  }
  function Point2D_init_$Init$_0(x, y, $this) {
    Point2D.call($this, x, y);
    return $this;
  }
  function Point2D_init_$Create$_0(x, y) {
    return Point2D_init_$Init$_0(x, y, objectCreate(protoOf(Point2D)));
  }
  function Point2D(x, y) {
    Companion_getInstance_14();
    x = x === VOID ? 0.0 : x;
    y = y === VOID ? 0.0 : y;
    this.in_1 = x;
    this.jn_1 = y;
  }
  protoOf(Point2D).toString = function () {
    return 'Point2D(' + toDoubleString(this.in_1) + ',' + toDoubleString(this.jn_1) + ')';
  };
  protoOf(Point2D).c1c = function () {
    return numberToInt(this.in_1);
  };
  protoOf(Point2D).d1c = function () {
    return numberToInt(this.jn_1);
  };
  protoOf(Point2D).m1g = function () {
    return new Point2D(-this.in_1, -this.jn_1);
  };
  protoOf(Point2D).n1g = function (x, y) {
    var px = x - this.in_1;
    var py = y - this.jn_1;
    return px * px + py * py;
  };
  protoOf(Point2D).o1g = function (x, y) {
    // Inline function 'kotlin.math.sqrt' call
    var x_0 = this.n1g(x, y);
    return Math.sqrt(x_0);
  };
  protoOf(Point2D).p1g = function (p) {
    return this.o1g(p.in_1, p.jn_1);
  };
  protoOf(Point2D).q1g = function (x) {
    return new Point2D(x + (x - this.in_1), this.jn_1);
  };
  protoOf(Point2D).r1g = function (y) {
    return new Point2D(this.in_1, y + (y - this.jn_1));
  };
  protoOf(Point2D).s1g = function (x, y, area) {
    return this.in_1 >= x - area && this.in_1 <= x + area && this.jn_1 >= y - area && this.jn_1 <= y + area;
  };
  protoOf(Point2D).tn = function (dx, dy) {
    return new Point2D(this.in_1 + dx, this.jn_1 + dy);
  };
  protoOf(Point2D).co = function (p) {
    return this.tn(p.in_1, p.jn_1);
  };
  protoOf(Point2D).t1g = function (p) {
    return new Point2D(this.in_1 - p.in_1, this.jn_1 - p.jn_1);
  };
  protoOf(Point2D).i1f = function (factor) {
    return new Point2D(this.in_1 * factor, this.jn_1 * factor);
  };
  protoOf(Point2D).u1g = function (dividend) {
    return new Point2D(this.in_1 / dividend, this.jn_1 / dividend);
  };
  protoOf(Point2D).v1g = function (dx) {
    return new Point2D(this.in_1 + dx, this.jn_1);
  };
  protoOf(Point2D).w1g = function (dy) {
    return new Point2D(this.in_1, this.jn_1 + dy);
  };
  protoOf(Point2D).x1g = function (halfSize) {
    return new Rectangle2D(this.in_1 - halfSize, this.jn_1 - halfSize, 2 * halfSize, 2 * halfSize);
  };
  protoOf(Point2D).equals = function (other) {
    if (this === other)
      return true;
    if (other == null || !getKClassFromExpression(this).equals(getKClassFromExpression(other)))
      return false;
    if (!(other instanceof Point2D))
      THROW_CCE();
    if (!Geometry_instance.x1f(this.in_1, other.in_1))
      return false;
    if (!Geometry_instance.x1f(this.jn_1, other.jn_1))
      return false;
    return true;
  };
  protoOf(Point2D).hashCode = function () {
    var result = getNumberHashCode(this.in_1);
    result = imul(31, result) + getNumberHashCode(this.jn_1) | 0;
    return result;
  };
  function Rectangle2D_init_$Init$(x, y, w, h, $this) {
    Rectangle2D.call($this, x, y, w, h);
    return $this;
  }
  function Rectangle2D_init_$Create$(x, y, w, h) {
    return Rectangle2D_init_$Init$(x, y, w, h, objectCreate(protoOf(Rectangle2D)));
  }
  function Rectangle2D_init_$Init$_0(rect, $this) {
    Rectangle2D.call($this, rect.z19(), rect.a1a(), rect.p1b(), rect.r1b());
    return $this;
  }
  function Rectangle2D_init_$Create$_0(rect) {
    return Rectangle2D_init_$Init$_0(rect, objectCreate(protoOf(Rectangle2D)));
  }
  function Rectangle2D_init_$Init$_1(location, width, height, $this) {
    Rectangle2D.call($this, location.in_1, location.jn_1, width, height);
    return $this;
  }
  function Rectangle2D_init_$Create$_1(location, width, height) {
    return Rectangle2D_init_$Init$_1(location, width, height, objectCreate(protoOf(Rectangle2D)));
  }
  function Rectangle2D_init_$Init$_2(location, dimension, $this) {
    Rectangle2D.call($this, location.in_1, location.jn_1, dimension.e1e_1, dimension.f1e_1);
    return $this;
  }
  function Rectangle2D_init_$Create$_2(location, dimension) {
    return Rectangle2D_init_$Init$_2(location, dimension, objectCreate(protoOf(Rectangle2D)));
  }
  function Companion_15() {
  }
  protoOf(Companion_15).y1g = function () {
    return Rectangle2D_init_$Create$(0, 0, 0, 0);
  };
  protoOf(Companion_15).uu = function (point) {
    return Rectangle2D_init_$Create$_1(point, 0.0, 0.0);
  };
  protoOf(Companion_15).z1g = function (center, w, h) {
    return new Rectangle2D(center.in_1 - w / 2, center.jn_1 - h / 2, w, h);
  };
  var Companion_instance_15;
  function Companion_getInstance_15() {
    return Companion_instance_15;
  }
  function Rectangle2D(x, y, width, height) {
    x = x === VOID ? 0.0 : x;
    y = y === VOID ? 0.0 : y;
    width = width === VOID ? 0.0 : width;
    height = height === VOID ? 0.0 : height;
    AbstractRectangularShape.call(this, x, y, width, height);
    this.e1h_1 = x;
    this.f1h_1 = y;
    this.g1h_1 = width;
    this.h1h_1 = height;
  }
  protoOf(Rectangle2D).m1b = function (_set____db54di) {
    this.e1h_1 = _set____db54di;
  };
  protoOf(Rectangle2D).z19 = function () {
    return this.e1h_1;
  };
  protoOf(Rectangle2D).n1b = function (_set____db54di) {
    this.f1h_1 = _set____db54di;
  };
  protoOf(Rectangle2D).a1a = function () {
    return this.f1h_1;
  };
  protoOf(Rectangle2D).o1b = function (_set____db54di) {
    this.g1h_1 = _set____db54di;
  };
  protoOf(Rectangle2D).p1b = function () {
    return this.g1h_1;
  };
  protoOf(Rectangle2D).q1b = function (_set____db54di) {
    this.h1h_1 = _set____db54di;
  };
  protoOf(Rectangle2D).r1b = function () {
    return this.h1h_1;
  };
  protoOf(Rectangle2D).i1h = function (x, y, width, height) {
    return new Rectangle2D(x, y, width, height);
  };
  protoOf(Rectangle2D).j1h = function (x, y, width, height, $super) {
    x = x === VOID ? this.e1h_1 : x;
    y = y === VOID ? this.f1h_1 : y;
    width = width === VOID ? this.g1h_1 : width;
    height = height === VOID ? this.h1h_1 : height;
    return $super === VOID ? this.i1h(x, y, width, height) : $super.i1h.call(this, x, y, width, height);
  };
  protoOf(Rectangle2D).toString = function () {
    return 'Rectangle2D(x=' + this.e1h_1 + ', y=' + this.f1h_1 + ', width=' + this.g1h_1 + ', height=' + this.h1h_1 + ')';
  };
  protoOf(Rectangle2D).hashCode = function () {
    var result = getNumberHashCode(this.e1h_1);
    result = imul(result, 31) + getNumberHashCode(this.f1h_1) | 0;
    result = imul(result, 31) + getNumberHashCode(this.g1h_1) | 0;
    result = imul(result, 31) + getNumberHashCode(this.h1h_1) | 0;
    return result;
  };
  protoOf(Rectangle2D).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof Rectangle2D))
      return false;
    if (!equals(this.e1h_1, other.e1h_1))
      return false;
    if (!equals(this.f1h_1, other.f1h_1))
      return false;
    if (!equals(this.g1h_1, other.g1h_1))
      return false;
    if (!equals(this.h1h_1, other.h1h_1))
      return false;
    return true;
  };
  function RectangularShape() {
  }
  function Ring2D(x, y, width, height, thickness) {
    AbstractRectangularShape.call(this, x, y, width, height);
    this.o1h_1 = thickness;
  }
  var Rotation_R0_instance;
  var Rotation_R90_instance;
  var Rotation_R180_instance;
  var Rotation_R270_instance;
  function Companion_16() {
  }
  protoOf(Companion_16).r1e = function (name) {
    var indexedObject = values_2();
    var inductionVariable = 0;
    var last = indexedObject.length;
    while (inductionVariable < last) {
      var value = indexedObject[inductionVariable];
      inductionVariable = inductionVariable + 1 | 0;
      if (value.r1h_1 === name) {
        return value;
      }
    }
    throw IllegalArgumentException_init_$Create$('unknown Rotation ' + name);
  };
  var Companion_instance_16;
  function Companion_getInstance_16() {
    return Companion_instance_16;
  }
  function values_2() {
    return [Rotation_R0_getInstance(), Rotation_R90_getInstance(), Rotation_R180_getInstance(), Rotation_R270_getInstance()];
  }
  var Rotation_entriesInitialized;
  function Rotation_initEntries() {
    if (Rotation_entriesInitialized)
      return Unit_instance;
    Rotation_entriesInitialized = true;
    Rotation_R0_instance = new Rotation('R0', 0, '0', 0.0);
    Rotation_R90_instance = new Rotation('R90', 1, '90', 3 * 3.141592653589793 / 2);
    Rotation_R180_instance = new Rotation('R180', 2, '180', 3.141592653589793);
    Rotation_R270_instance = new Rotation('R270', 3, '270', 3.141592653589793 / 2);
  }
  function Rotation(name, ordinal, customName, angle) {
    Enum.call(this, name, ordinal);
    this.r1h_1 = customName;
    this.s1h_1 = angle;
    this.t1h_1 = AffineTransformImpl_init_$Create$();
    this.t1h_1.y1c(this.s1h_1);
  }
  protoOf(Rotation).u1h = function () {
    var tmp;
    switch (this.l2_1) {
      case 0:
        tmp = Rotation_R0_getInstance();
        break;
      case 1:
        tmp = Rotation_R270_getInstance();
        break;
      case 2:
        tmp = Rotation_R180_getInstance();
        break;
      case 3:
        tmp = Rotation_R90_getInstance();
        break;
      default:
        noWhenBranchMatchedException();
        break;
    }
    return tmp;
  };
  protoOf(Rotation).v1h = function (other) {
    return values_2()[(this.l2_1 + other.l2_1 | 0) % 4 | 0];
  };
  protoOf(Rotation).w1h = function (x, y) {
    var tmp;
    switch (this.l2_1) {
      case 0:
        tmp = new Point2D(x, y);
        break;
      case 1:
        tmp = new Point2D(y, -x);
        break;
      case 2:
        tmp = new Point2D(-x, -y);
        break;
      case 3:
        tmp = new Point2D(-y, x);
        break;
      default:
        noWhenBranchMatchedException();
        break;
    }
    return tmp;
  };
  protoOf(Rotation).x1h = function (pivot, x, y) {
    var p = this.w1h(x - pivot.in_1, y - pivot.jn_1);
    return new Point2D(pivot.in_1 + p.in_1, pivot.jn_1 + p.jn_1);
  };
  protoOf(Rotation).y1h = function (pivot, point) {
    return this.x1h(pivot, point.in_1, point.jn_1);
  };
  protoOf(Rotation).z1h = function (pivot, rect) {
    var p1 = this.w1h(rect.z19() - pivot.in_1, rect.a1a() - pivot.jn_1);
    var p2 = this.w1h(rect.z19() + rect.p1b() - pivot.in_1, rect.a1a() + rect.r1b() - pivot.jn_1);
    var tmp0 = p1.in_1;
    // Inline function 'kotlin.math.min' call
    var b = p2.in_1;
    var tmp = Math.min(tmp0, b);
    var tmp0_0 = p1.jn_1;
    // Inline function 'kotlin.math.min' call
    var b_0 = p2.jn_1;
    var tmp_0 = Math.min(tmp0_0, b_0);
    // Inline function 'kotlin.math.abs' call
    var x = p1.in_1 - p2.in_1;
    var tmp_1 = Math.abs(x);
    // Inline function 'kotlin.math.abs' call
    var x_0 = p1.jn_1 - p2.jn_1;
    var tmp$ret$3 = Math.abs(x_0);
    var newRect = new Rectangle2D(tmp, tmp_0, tmp_1, tmp$ret$3);
    newRect.s1b(newRect.e1h_1 + pivot.in_1, newRect.f1h_1 + pivot.jn_1, newRect.g1h_1, newRect.h1h_1);
    return newRect;
  };
  protoOf(Rotation).a1i = function (dir) {
    var i = 0;
    var result = dir;
    while (i < this.l2_1) {
      result = result.k();
      i = i + 1 | 0;
    }
    return result;
  };
  function Rotation_R0_getInstance() {
    Rotation_initEntries();
    return Rotation_R0_instance;
  }
  function Rotation_R90_getInstance() {
    Rotation_initEntries();
    return Rotation_R90_instance;
  }
  function Rotation_R180_getInstance() {
    Rotation_initEntries();
    return Rotation_R180_instance;
  }
  function Rotation_R270_getInstance() {
    Rotation_initEntries();
    return Rotation_R270_instance;
  }
  function RoundRectangle2D_init_$Init$(location, dimension, arc, $this) {
    RoundRectangle2D.call($this, location.in_1, location.jn_1, dimension.e1e_1, dimension.f1e_1, arc, arc);
    return $this;
  }
  function RoundRectangle2D_init_$Create$(location, dimension, arc) {
    return RoundRectangle2D_init_$Init$(location, dimension, arc, objectCreate(protoOf(RoundRectangle2D)));
  }
  function RoundRectangle2D(x, y, width, height, arcW, arcH) {
    AbstractRectangularShape.call(this, x, y, width, height);
    this.f1i_1 = arcW;
    this.g1i_1 = arcH;
  }
  function Shape() {
  }
  var Turn_LEFT_instance;
  var Turn_NONE_instance;
  var Turn_RIGHT_instance;
  var Turn_AROUND_instance;
  var Turn_entriesInitialized;
  function Turn_initEntries() {
    if (Turn_entriesInitialized)
      return Unit_instance;
    Turn_entriesInitialized = true;
    Turn_LEFT_instance = new Turn('LEFT', 0);
    Turn_NONE_instance = new Turn('NONE', 1);
    Turn_RIGHT_instance = new Turn('RIGHT', 2);
    Turn_AROUND_instance = new Turn('AROUND', 3);
  }
  function Turn(name, ordinal) {
    Enum.call(this, name, ordinal);
  }
  function Turn_LEFT_getInstance() {
    Turn_initEntries();
    return Turn_LEFT_instance;
  }
  function Turn_NONE_getInstance() {
    Turn_initEntries();
    return Turn_NONE_instance;
  }
  function Turn_RIGHT_getInstance() {
    Turn_initEntries();
    return Turn_RIGHT_instance;
  }
  function Turn_AROUND_getInstance() {
    Turn_initEntries();
    return Turn_AROUND_instance;
  }
  function Vector2D_init_$Init$(p, $this) {
    Vector2D.call($this, p.in_1, p.jn_1);
    return $this;
  }
  function Vector2D_init_$Create$(p) {
    return Vector2D_init_$Init$(p, objectCreate(protoOf(Vector2D)));
  }
  function Vector2D(x, y) {
    this.h1i_1 = x;
    this.i1i_1 = y;
    this.j1i_1 = new Point2D(this.h1i_1, this.i1i_1);
  }
  protoOf(Vector2D).k1i = function () {
    // Inline function 'kotlin.math.sqrt' call
    var x = this.h1i_1 * this.h1i_1 + this.i1i_1 * this.i1i_1;
    return Math.sqrt(x);
  };
  protoOf(Vector2D).l1i = function () {
    var mag = this.k1i();
    return new Vector2D(this.h1i_1 / mag, this.i1i_1 / mag);
  };
  protoOf(Vector2D).i1f = function (s) {
    return new Vector2D(this.h1i_1 * s, this.i1i_1 * s);
  };
  function HelpId(id) {
    this.m1i_1 = id;
  }
  protoOf(HelpId).toString = function () {
    return 'HelpId(id=' + this.m1i_1 + ')';
  };
  protoOf(HelpId).hashCode = function () {
    return getStringHashCode(this.m1i_1);
  };
  protoOf(HelpId).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof HelpId))
      return false;
    if (!(this.m1i_1 === other.m1i_1))
      return false;
    return true;
  };
  function _get_LOG__e5r759_4($this) {
    var tmp0 = $this.n1i_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('LOG', 1, tmp, HelpSourceRegistry$_get_LOG_$ref_ujhjnz(), null);
    return tmp0.j2();
  }
  function HelpSourceRegistry$_get_LOG_$ref_ujhjnz() {
    return function (p0) {
      return _get_LOG__e5r759_4(p0);
    };
  }
  function HelpSourceRegistry() {
    HelpSourceRegistry_instance = this;
    this.n1i_1 = logger(getKClass(HelpSourceRegistry));
    var tmp = this;
    // Inline function 'kotlin.collections.mutableMapOf' call
    tmp.o1i_1 = LinkedHashMap_init_$Create$();
  }
  protoOf(HelpSourceRegistry).p1i = function (helpId, source) {
    // Inline function 'kotlin.collections.contains' call
    // Inline function 'kotlin.collections.containsKey' call
    var this_0 = this.o1i_1;
    if ((isInterface(this_0, KtMap) ? this_0 : THROW_CCE()).e2(helpId)) {
      _get_LOG__e5r759_4(this).ll('Replacing existing HelpId ' + helpId.m1i_1);
    }
    // Inline function 'kotlin.collections.set' call
    this.o1i_1.y1(helpId, source);
  };
  var HelpSourceRegistry_instance;
  function HelpSourceRegistry_getInstance() {
    if (HelpSourceRegistry_instance == null)
      new HelpSourceRegistry();
    return HelpSourceRegistry_instance;
  }
  function HelpSource(source) {
    this.q1i_1 = source;
  }
  protoOf(HelpSource).toString = function () {
    return this.q1i_1;
  };
  protoOf(HelpSource).hashCode = function () {
    return getStringHashCode(this.q1i_1);
  };
  protoOf(HelpSource).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof HelpSource))
      return false;
    if (!(this.q1i_1 === other.q1i_1))
      return false;
    return true;
  };
  function Companion_17() {
    Companion_instance_17 = this;
    this.uo_1 = new UnimplementedInvocationHandler();
  }
  protoOf(Companion_17).r1i = function (runnable) {
    this.uo_1.qo(runnable);
  };
  var Companion_instance_17;
  function Companion_getInstance_17() {
    if (Companion_instance_17 == null)
      new Companion_17();
    return Companion_instance_17;
  }
  function InvocationHandler() {
    Companion_getInstance_17();
  }
  function UnimplementedInvocationHandler() {
    InvocationHandler.call(this);
  }
  protoOf(UnimplementedInvocationHandler).qo = function (runnable) {
    throw UnsupportedOperationException_init_$Create$('not implemented');
  };
  function interpolate(_this__u8e3s4, x0, y1, y2) {
    return interpolateInt(x0, _this__u8e3s4.w(), y1, _this__u8e3s4.v(), y2);
  }
  function interpolateInt(x0, x1, y1, x2, y2) {
    var m = (y2 - y1 | 0) / (x2 - x1 | 0);
    return y1 + numberToInt(m * (x0 - x1 | 0)) | 0;
  }
  function toDoubleString(_this__u8e3s4) {
    var s = _this__u8e3s4.toString();
    if (!contains_0(s, '.')) {
      return s + '.0';
    }
    return s;
  }
  function near(_this__u8e3s4, value) {
    // Inline function 'kotlin.math.abs' call
    var x = _this__u8e3s4 - value;
    return Math.abs(x) <= 1.0E-7;
  }
  function formatRounded(_this__u8e3s4, precision) {
    precision = precision === VOID ? 1000.0 : precision;
    return toDoubleString(roundToInt(_this__u8e3s4 * precision) / precision);
  }
  function fillProperties($this, properties) {
    properties.ct('base.language', Language_English_getInstance().om_1);
    properties.ct(LogSystem_getInstance().gl_1, 'Info');
    properties.ct('base.beginnerHelpTooltip', true);
    properties.ct('base.dataLocation', DataLocation_Local_getInstance().ds_1);
    properties.ct('base.network.connectionTimeout', 10);
    properties.ct('jabbah.base.sound.enableSoundEffects', true);
    SoundEffects_instance.u1i($this.zo_1);
  }
  function BaseModule$lexerFactory$lambda(program) {
    return new DslLexer(program);
  }
  function BaseModule$semanticAnalyserFactory$lambda(symbolTable) {
    return new DslSemanticAnalyser(symbolTable);
  }
  function BaseModule$parserFactory$lambda(program, semanticAnalyser) {
    return new DslParser(BaseModule_getInstance().bp_1(program), semanticAnalyser);
  }
  function BaseModule$storingActivationRecordFactory$lambda(name, parent) {
    return new StoringActivationRecord(name, parent);
  }
  function BaseModule$interpreterFactory$lambda(node, memory) {
    return new Interpreter(node, memory);
  }
  function BaseModule() {
    BaseModule_instance = this;
    AbstractModule.call(this);
    this.wo_1 = 'base.network.connectionTimeout';
    this.xo_1 = new Properties();
    this.yo_1 = new Settings();
    this.zo_1 = new EventBusImpl();
    this.ap_1 = new ControlledTimeService();
    var tmp = this;
    tmp.bp_1 = BaseModule$lexerFactory$lambda;
    var tmp_0 = this;
    tmp_0.cp_1 = BaseModule$semanticAnalyserFactory$lambda;
    var tmp_1 = this;
    tmp_1.dp_1 = BaseModule$parserFactory$lambda;
    var tmp_2 = this;
    tmp_2.ep_1 = BaseModule$storingActivationRecordFactory$lambda;
    var tmp_3 = this;
    tmp_3.fp_1 = BaseModule$interpreterFactory$lambda;
    this.gp_1 = new DslGlobalFunctions();
    this.hp_1 = null;
  }
  protoOf(BaseModule).ro = function () {
    Translations_getInstance().um('jabbah-base');
    fillProperties(this, this.xo_1);
  };
  var BaseModule_instance;
  function BaseModule_getInstance() {
    if (BaseModule_instance == null)
      new BaseModule();
    return BaseModule_instance;
  }
  function State($outer) {
    this.sx_1 = $outer;
    this.lx_1 = 0;
    var tmp = this;
    var tmp_0;
    // Inline function 'kotlin.text.isEmpty' call
    var this_0 = this.sx_1.tx_1;
    if (charSequenceLength(this_0) === 0) {
      tmp_0 = null;
    } else {
      tmp_0 = first(this.sx_1.tx_1);
    }
    tmp.mx_1 = tmp_0;
    this.nx_1 = 1;
    this.ox_1 = 1;
    this.px_1 = 0;
    this.qx_1 = 1;
    this.rx_1 = 1;
  }
  protoOf(State).hw = function () {
    return new TextLocation(this.px_1, this.qx_1, this.rx_1);
  };
  protoOf(State).v1i = function (other) {
    this.lx_1 = other.lx_1;
    this.mx_1 = other.mx_1;
    this.px_1 = other.px_1;
    this.nx_1 = other.nx_1;
    this.ox_1 = other.ox_1;
    return this;
  };
  function AbstractLexer(text) {
    this.tx_1 = text;
    this.ux_1 = new State(this);
    this.vx_1 = new State(this);
  }
  protoOf(AbstractLexer).hw = function () {
    return this.vx_1.hw();
  };
  protoOf(AbstractLexer).oy = function () {
    return this.by(this.vx_1);
  };
  protoOf(AbstractLexer).py = function () {
    return this.by(this.ux_1.v1i(this.vx_1));
  };
  protoOf(AbstractLexer).wx = function (state) {
    return this.qy(state, 1);
  };
  protoOf(AbstractLexer).qy = function (state, count) {
    var peekPos = state.lx_1 + count | 0;
    if (peekPos > (this.tx_1.length - 1 | 0)) {
      return null;
    }
    return charCodeAt(this.tx_1, peekPos);
  };
  protoOf(AbstractLexer).dy = function (state) {
    var tmp;
    var tmp_0 = state.mx_1;
    if (!((tmp_0 == null ? null : new Char(tmp_0)) == null)) {
      var tmp_1 = state.mx_1;
      tmp = isWhitespace(ensureNotNull(tmp_1 == null ? null : new Char(tmp_1)).j1_1);
    } else {
      tmp = false;
    }
    return tmp;
  };
  protoOf(AbstractLexer).cy = function (state) {
    while (this.dy(state)) {
      this.xx(state);
    }
  };
  protoOf(AbstractLexer).xx = function (state) {
    var tmp = state.mx_1;
    if (equals(tmp == null ? null : new Char(tmp), new Char(_Char___init__impl__6a9atx(10)))) {
      state.nx_1 = state.nx_1 + 1 | 0;
      state.ox_1 = 0;
    }
    state.ox_1 = state.ox_1 + 1 | 0;
    state.lx_1 = state.lx_1 + 1 | 0;
    state.mx_1 = state.lx_1 > (this.tx_1.length - 1 | 0) ? null : charCodeAt(this.tx_1, state.lx_1);
  };
  protoOf(AbstractLexer).jy = function (state, token) {
    this.xx(state);
    return token;
  };
  protoOf(AbstractLexer).ey = function (state) {
    state.px_1 = state.lx_1;
    state.qx_1 = state.nx_1;
    state.rx_1 = state.ox_1;
  };
  function AbstractParser(lexer) {
    this.f11_1 = lexer;
    this.g11_1 = this.f11_1.oy();
  }
  protoOf(AbstractParser).v11 = function (metaData) {
    var tmp;
    try {
      tmp = this.vy();
    } catch ($p) {
      var tmp_0;
      if ($p instanceof DslError) {
        var e = $p;
        BaseModule_getInstance().zo_1.eu(new IssueImpl(IssueSeverity_Error_getInstance(), Translations_getInstance().zm('base.dsl.scriptError.msg', []), e.message, metaData.aw_1, metaData.bw_1));
        tmp_0 = null;
      } else {
        throw $p;
      }
      tmp = tmp_0;
    }
    return tmp;
  };
  protoOf(AbstractParser).k11 = function (type) {
    if (equals(ensureNotNull(this.g11_1).d11_1, type)) {
      this.g11_1 = this.f11_1.oy();
    } else {
      throw new SyntaxError(this.f11_1.hw(), Translations_getInstance().zm('base.dsl.expectedToken.msg', [type.av()]));
    }
  };
  function Companion_18() {
    Companion_instance_18 = this;
    this.ax_1 = new TextLocation(0, 0, 0);
  }
  var Companion_instance_18;
  function Companion_getInstance_18() {
    if (Companion_instance_18 == null)
      new Companion_18();
    return Companion_instance_18;
  }
  function TextLocation(pos, row, column) {
    Companion_getInstance_18();
    this.w1i_1 = pos;
    this.x1i_1 = row;
    this.y1i_1 = column;
  }
  protoOf(TextLocation).toString = function () {
    return '' + this.x1i_1 + ':' + this.y1i_1;
  };
  protoOf(TextLocation).hashCode = function () {
    var result = this.w1i_1;
    result = imul(result, 31) + this.x1i_1 | 0;
    result = imul(result, 31) + this.y1i_1 | 0;
    return result;
  };
  protoOf(TextLocation).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof TextLocation))
      return false;
    if (!(this.w1i_1 === other.w1i_1))
      return false;
    if (!(this.x1i_1 === other.x1i_1))
      return false;
    if (!(this.y1i_1 === other.y1i_1))
      return false;
    return true;
  };
  function Token(type, value) {
    value = value === VOID ? null : value;
    this.d11_1 = type;
    this.e11_1 = value;
  }
  protoOf(Token).toString = function () {
    var tmp0_safe_receiver = this.e11_1;
    var tmp;
    if (tmp0_safe_receiver == null) {
      tmp = null;
    } else {
      // Inline function 'kotlin.let' call
      tmp = 'Token(' + this.d11_1.m2() + ', ' + toString(tmp0_safe_receiver) + ')';
    }
    var tmp1_elvis_lhs = tmp;
    return tmp1_elvis_lhs == null ? 'Token(' + this.d11_1.m2() + ')' : tmp1_elvis_lhs;
  };
  protoOf(Token).t11 = function () {
    return this instanceof Token ? this : THROW_CCE();
  };
  protoOf(Token).hashCode = function () {
    var result = hashCode(this.d11_1);
    result = imul(result, 31) + (this.e11_1 == null ? 0 : hashCode(this.e11_1)) | 0;
    return result;
  };
  protoOf(Token).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof Token))
      return false;
    if (!equals(this.d11_1, other.d11_1))
      return false;
    if (!equals(this.e11_1, other.e11_1))
      return false;
    return true;
  };
  function Companion_19() {
    Companion_instance_19 = this;
    this.z1i_1 = listOf([new Char(_Char___init__impl__6a9atx(33)), new Char(_Char___init__impl__6a9atx(95)), new Char(_Char___init__impl__6a9atx(94)), new Char(_Char___init__impl__6a9atx(42)), new Char(_Char___init__impl__6a9atx(47)), new Char(_Char___init__impl__6a9atx(40)), new Char(_Char___init__impl__6a9atx(41))]);
    this.a1j_1 = new Token(RichTextTokenType_LPAREN_getInstance());
    this.b1j_1 = new Token(RichTextTokenType_RPAREN_getInstance());
    this.c1j_1 = new Token(RichTextTokenType_OVERLINE_getInstance());
    this.d1j_1 = new Token(RichTextTokenType_SUBSCRIPT_getInstance());
    this.e1j_1 = new Token(RichTextTokenType_SUPERSCRIPT_getInstance());
    this.f1j_1 = new Token(RichTextTokenType_BOLD_getInstance());
    this.g1j_1 = new Token(RichTextTokenType_ITALIC_getInstance());
    this.h1j_1 = new Token(RichTextTokenType_EOF_getInstance());
    this.i1j_1 = listOf([new Char(_Char___init__impl__6a9atx(33)), new Char(_Char___init__impl__6a9atx(95)), new Char(_Char___init__impl__6a9atx(94)), new Char(_Char___init__impl__6a9atx(42)), new Char(_Char___init__impl__6a9atx(47))]);
    this.j1j_1 = _Char___init__impl__6a9atx(92);
  }
  var Companion_instance_19;
  function Companion_getInstance_19() {
    if (Companion_instance_19 == null)
      new Companion_19();
    return Companion_instance_19;
  }
  function advanceByUpdatingSingleCharMode($this, state, token) {
    var tmp = $this;
    var tmp_0 = Companion_getInstance_19().i1j_1;
    var tmp_1 = state.mx_1;
    tmp.n1j_1 = contains(tmp_0, tmp_1 == null ? null : new Char(tmp_1));
    return $this.jy(state, token);
  }
  function text($this) {
    var text = StringBuilder_init_$Create$();
    var escape = false;
    var parenDepth = 0;
    $l$loop: while (true) {
      var tmp;
      var tmp_0 = $this.vx_1.mx_1;
      if (!((tmp_0 == null ? null : new Char(tmp_0)) == null)) {
        var tmp_1;
        if (escape) {
          tmp_1 = true;
        } else {
          var tmp_2 = Companion_getInstance_19().i1j_1;
          var tmp_3 = $this.vx_1.mx_1;
          tmp_1 = !contains(tmp_2, tmp_3 == null ? null : new Char(tmp_3));
        }
        tmp = tmp_1;
      } else {
        tmp = false;
      }
      if (!tmp) {
        break $l$loop;
      }
      var tmp_4;
      if (!escape) {
        var tmp_5 = $this.vx_1.mx_1;
        tmp_4 = equals(tmp_5 == null ? null : new Char(tmp_5), new Char(_Char___init__impl__6a9atx(92)));
      } else {
        tmp_4 = false;
      }
      escape = tmp_4;
      var tmp0_subject = $this.vx_1.mx_1;
      var tmp_6 = tmp0_subject;
      if (equals(tmp_6 == null ? null : new Char(tmp_6), new Char(_Char___init__impl__6a9atx(40)))) {
        parenDepth = parenDepth + 1 | 0;
      } else {
        var tmp_7 = tmp0_subject;
        if (equals(tmp_7 == null ? null : new Char(tmp_7), new Char(_Char___init__impl__6a9atx(41)))) {
          if (parenDepth > 0) {
            parenDepth = parenDepth - 1 | 0;
          } else {
            return text.toString();
          }
        }
      }
      if (!escape) {
        var tmp_8 = $this.vx_1.mx_1;
        text.g7(tmp_8 == null ? null : new Char(tmp_8));
      }
      $this.xx($this.vx_1);
    }
    return text.toString();
  }
  function character($this) {
    var tmp = $this.vx_1.mx_1;
    var escape = equals(tmp == null ? null : new Char(tmp), new Char(_Char___init__impl__6a9atx(92)));
    if (escape) {
      $this.xx($this.vx_1);
    }
    var tmp_0;
    var tmp_1;
    var tmp_2 = $this.vx_1.mx_1;
    if (!((tmp_2 == null ? null : new Char(tmp_2)) == null)) {
      var tmp_3;
      if (escape) {
        tmp_3 = true;
      } else {
        var tmp_4 = Companion_getInstance_19().i1j_1;
        var tmp_5 = $this.vx_1.mx_1;
        tmp_3 = !contains(tmp_4, tmp_5 == null ? null : new Char(tmp_5));
      }
      tmp_1 = tmp_3;
    } else {
      tmp_1 = false;
    }
    if (tmp_1) {
      var tmp_6 = $this.vx_1.mx_1;
      var s = toString_1(ensureNotNull(tmp_6 == null ? null : new Char(tmp_6)).j1_1);
      $this.xx($this.vx_1);
      tmp_0 = s;
    } else {
      tmp_0 = '';
    }
    return tmp_0;
  }
  function RichTextLexer(text) {
    Companion_getInstance_19();
    AbstractLexer.call(this, text);
    this.n1j_1 = false;
    this.o1j_1 = false;
  }
  protoOf(RichTextLexer).by = function (state) {
    this.ey(state);
    var tmp = state.mx_1;
    if ((tmp == null ? null : new Char(tmp)) == null) {
      return Companion_getInstance_19().h1j_1;
    }
    if (!this.o1j_1) {
      var tmp_0 = state.mx_1;
      var tmp0_subject = ensureNotNull(tmp_0 == null ? null : new Char(tmp_0)).j1_1;
      if (tmp0_subject === _Char___init__impl__6a9atx(40))
        return advanceByUpdatingSingleCharMode(this, state, Companion_getInstance_19().a1j_1);
      else if (tmp0_subject === _Char___init__impl__6a9atx(41))
        return advanceByUpdatingSingleCharMode(this, state, Companion_getInstance_19().b1j_1);
      else if (tmp0_subject === _Char___init__impl__6a9atx(33))
        return advanceByUpdatingSingleCharMode(this, state, Companion_getInstance_19().c1j_1);
      else if (tmp0_subject === _Char___init__impl__6a9atx(95))
        return advanceByUpdatingSingleCharMode(this, state, Companion_getInstance_19().d1j_1);
      else if (tmp0_subject === _Char___init__impl__6a9atx(94))
        return advanceByUpdatingSingleCharMode(this, state, Companion_getInstance_19().e1j_1);
      else if (tmp0_subject === _Char___init__impl__6a9atx(42))
        return advanceByUpdatingSingleCharMode(this, state, Companion_getInstance_19().f1j_1);
      else if (tmp0_subject === _Char___init__impl__6a9atx(47))
        return advanceByUpdatingSingleCharMode(this, state, Companion_getInstance_19().g1j_1);
    }
    var tmp_1;
    if (this.n1j_1) {
      // Inline function 'kotlin.also' call
      var this_0 = new Token(RichTextTokenType_TEXT_getInstance(), character(this));
      this.n1j_1 = false;
      tmp_1 = this_0;
    } else {
      tmp_1 = new Token(RichTextTokenType_TEXT_getInstance(), text(this));
    }
    return tmp_1;
  };
  var RichTextTokenType_TEXT_instance;
  var RichTextTokenType_LPAREN_instance;
  var RichTextTokenType_RPAREN_instance;
  var RichTextTokenType_OVERLINE_instance;
  var RichTextTokenType_SUBSCRIPT_instance;
  var RichTextTokenType_SUPERSCRIPT_instance;
  var RichTextTokenType_BOLD_instance;
  var RichTextTokenType_ITALIC_instance;
  var RichTextTokenType_EOF_instance;
  var RichTextTokenType_entriesInitialized;
  function RichTextTokenType_initEntries() {
    if (RichTextTokenType_entriesInitialized)
      return Unit_instance;
    RichTextTokenType_entriesInitialized = true;
    RichTextTokenType_TEXT_instance = new RichTextTokenType('TEXT', 0, 'text');
    RichTextTokenType_LPAREN_instance = new RichTextTokenType('LPAREN', 1, '(');
    RichTextTokenType_RPAREN_instance = new RichTextTokenType('RPAREN', 2, ')');
    RichTextTokenType_OVERLINE_instance = new RichTextTokenType('OVERLINE', 3, '!');
    RichTextTokenType_SUBSCRIPT_instance = new RichTextTokenType('SUBSCRIPT', 4, '_');
    RichTextTokenType_SUPERSCRIPT_instance = new RichTextTokenType('SUPERSCRIPT', 5, '^');
    RichTextTokenType_BOLD_instance = new RichTextTokenType('BOLD', 6, '*');
    RichTextTokenType_ITALIC_instance = new RichTextTokenType('ITALIC', 7, '/');
    RichTextTokenType_EOF_instance = new RichTextTokenType('EOF', 8, 'EOF');
  }
  function RichTextTokenType(name, ordinal, id) {
    Enum.call(this, name, ordinal);
    this.r1j_1 = id;
  }
  protoOf(RichTextTokenType).av = function () {
    return this.r1j_1;
  };
  function RichTextTokenType_TEXT_getInstance() {
    RichTextTokenType_initEntries();
    return RichTextTokenType_TEXT_instance;
  }
  function RichTextTokenType_LPAREN_getInstance() {
    RichTextTokenType_initEntries();
    return RichTextTokenType_LPAREN_instance;
  }
  function RichTextTokenType_RPAREN_getInstance() {
    RichTextTokenType_initEntries();
    return RichTextTokenType_RPAREN_instance;
  }
  function RichTextTokenType_OVERLINE_getInstance() {
    RichTextTokenType_initEntries();
    return RichTextTokenType_OVERLINE_instance;
  }
  function RichTextTokenType_SUBSCRIPT_getInstance() {
    RichTextTokenType_initEntries();
    return RichTextTokenType_SUBSCRIPT_instance;
  }
  function RichTextTokenType_SUPERSCRIPT_getInstance() {
    RichTextTokenType_initEntries();
    return RichTextTokenType_SUPERSCRIPT_instance;
  }
  function RichTextTokenType_BOLD_getInstance() {
    RichTextTokenType_initEntries();
    return RichTextTokenType_BOLD_instance;
  }
  function RichTextTokenType_ITALIC_getInstance() {
    RichTextTokenType_initEntries();
    return RichTextTokenType_ITALIC_instance;
  }
  function RichTextTokenType_EOF_getInstance() {
    RichTextTokenType_initEntries();
    return RichTextTokenType_EOF_instance;
  }
  function Companion_20() {
  }
  protoOf(Companion_20).s1j = function (text) {
    switch (text.length) {
      case 0:
        return '';
      case 1:
        return RichTextTokenType_BOLD_getInstance().r1j_1 + text;
      default:
        return RichTextTokenType_BOLD_getInstance().r1j_1 + RichTextTokenType_LPAREN_getInstance().r1j_1 + text + RichTextTokenType_RPAREN_getInstance().r1j_1;
    }
  };
  var Companion_instance_20;
  function Companion_getInstance_20() {
    return Companion_instance_20;
  }
  function RichTextParser_init_$Init$(text, $this) {
    RichTextParser.call($this, new RichTextLexer(text));
    return $this;
  }
  function RichTextParser_init_$Create$(text) {
    return RichTextParser_init_$Init$(text, objectCreate(protoOf(RichTextParser)));
  }
  function eatParen($this, expr) {
    $this.k11(RichTextTokenType_LPAREN_getInstance());
    var result = expr();
    $this.k11(RichTextTokenType_RPAREN_getInstance());
    return result;
  }
  function richText($this) {
    // Inline function 'kotlin.let' call
    var location = $this.f11_1.hw();
    // Inline function 'kotlin.collections.mutableListOf' call
    var fragments = ArrayList_init_$Create$();
    while (!equals(ensureNotNull($this.g11_1).d11_1, RichTextTokenType_EOF_getInstance()) && !equals(ensureNotNull($this.g11_1).d11_1, RichTextTokenType_RPAREN_getInstance())) {
      fragments.f1(styledFragment($this));
    }
    return new RichText(location, fragments);
  }
  function styledFragment($this) {
    var tmp0_subject = ensureNotNull($this.g11_1).d11_1;
    return equals(tmp0_subject, RichTextTokenType_BOLD_getInstance()) ? boldText($this).sw_1 : equals(tmp0_subject, RichTextTokenType_ITALIC_getInstance()) ? italicText($this).sw_1 : listOf_0(fragment($this));
  }
  function boldText($this) {
    $this.k11(RichTextTokenType_BOLD_getInstance());
    $this.v1j_1 = Companion_getInstance_22().x1j($this.v1j_1);
    var tmp;
    if (equals(ensureNotNull($this.g11_1).d11_1, RichTextTokenType_LPAREN_getInstance())) {
      tmp = eatParen($this, RichTextParser$boldText$lambda($this));
    } else {
      tmp = singleCharRichText($this);
    }
    var richText = tmp;
    $this.v1j_1 = Companion_getInstance_22().y1j($this.v1j_1);
    return richText;
  }
  function italicText($this) {
    $this.k11(RichTextTokenType_ITALIC_getInstance());
    $this.v1j_1 = Companion_getInstance_22().z1j($this.v1j_1);
    var tmp;
    if (equals(ensureNotNull($this.g11_1).d11_1, RichTextTokenType_LPAREN_getInstance())) {
      tmp = eatParen($this, RichTextParser$italicText$lambda($this));
    } else {
      tmp = singleCharRichText($this);
    }
    var richText = tmp;
    $this.v1j_1 = Companion_getInstance_22().a1k($this.v1j_1);
    return richText;
  }
  function singleCharRichText($this) {
    // Inline function 'kotlin.let' call
    var location = $this.f11_1.hw();
    return new RichText(location, listOf_0(new Fragment(location, new FragmentText(location, singleChar($this)))));
  }
  function fragment($this) {
    // Inline function 'kotlin.let' call
    var location = $this.f11_1.hw();
    var text = new FragmentText(location, styledChunk($this));
    var subscript_0 = null;
    var superscript_0 = null;
    if (equals(ensureNotNull($this.g11_1).d11_1, RichTextTokenType_SUBSCRIPT_getInstance())) {
      subscript_0 = subscript($this);
    }
    if (equals(ensureNotNull($this.g11_1).d11_1, RichTextTokenType_SUPERSCRIPT_getInstance())) {
      superscript_0 = superscript($this);
      if (equals(ensureNotNull($this.g11_1).d11_1, RichTextTokenType_SUBSCRIPT_getInstance())) {
        subscript_0 = subscript($this);
      }
    }
    return new Fragment(location, text, subscript_0, superscript_0);
  }
  function styledText($this) {
    // Inline function 'kotlin.let' call
    var location = $this.f11_1.hw();
    // Inline function 'kotlin.collections.mutableListOf' call
    var chunks = ArrayList_init_$Create$();
    while (isStyledChunk($this)) {
      chunks.f1(styledChunk($this).c1k_1);
    }
    return new StyledText(location, chunks);
  }
  function subscript($this) {
    $this.k11(RichTextTokenType_SUBSCRIPT_getInstance());
    var tmp0_subject = ensureNotNull($this.g11_1).d11_1;
    var tmp;
    if (equals(tmp0_subject, RichTextTokenType_LPAREN_getInstance())) {
      tmp = eatParen($this, RichTextParser$subscript$lambda($this));
    } else if (equals(tmp0_subject, RichTextTokenType_OVERLINE_getInstance())) {
      tmp = new Subscript($this.f11_1.hw(), overline($this));
    } else if (equals(tmp0_subject, RichTextTokenType_BOLD_getInstance())) {
      tmp = new Subscript($this.f11_1.hw(), bold($this));
    } else if (equals(tmp0_subject, RichTextTokenType_ITALIC_getInstance())) {
      tmp = new Subscript($this.f11_1.hw(), italic($this));
    } else {
      tmp = new Subscript($this.f11_1.hw(), singleChar($this));
    }
    return tmp;
  }
  function superscript($this) {
    $this.k11(RichTextTokenType_SUPERSCRIPT_getInstance());
    var tmp0_subject = ensureNotNull($this.g11_1).d11_1;
    var tmp;
    if (equals(tmp0_subject, RichTextTokenType_LPAREN_getInstance())) {
      tmp = eatParen($this, RichTextParser$superscript$lambda($this));
    } else if (equals(tmp0_subject, RichTextTokenType_OVERLINE_getInstance())) {
      tmp = new Superscript($this.f11_1.hw(), overline($this));
    } else if (equals(tmp0_subject, RichTextTokenType_BOLD_getInstance())) {
      tmp = new Superscript($this.f11_1.hw(), bold($this));
    } else if (equals(tmp0_subject, RichTextTokenType_ITALIC_getInstance())) {
      tmp = new Superscript($this.f11_1.hw(), italic($this));
    } else {
      tmp = new Superscript($this.f11_1.hw(), singleChar($this));
    }
    return tmp;
  }
  function isStyledChunk($this) {
    var tmp0_subject = ensureNotNull($this.g11_1).d11_1;
    return equals(tmp0_subject, RichTextTokenType_TEXT_getInstance()) ? true : equals(tmp0_subject, RichTextTokenType_OVERLINE_getInstance()) ? true : equals(tmp0_subject, RichTextTokenType_BOLD_getInstance()) ? true : equals(tmp0_subject, RichTextTokenType_ITALIC_getInstance()) ? true : false;
  }
  function styledChunk($this) {
    // Inline function 'kotlin.let' call
    var location = $this.f11_1.hw();
    var token = ensureNotNull($this.g11_1);
    var tmp0_subject = ensureNotNull($this.g11_1).d11_1;
    var tmp;
    if (equals(tmp0_subject, RichTextTokenType_OVERLINE_getInstance())) {
      tmp = overline($this);
    } else if (equals(tmp0_subject, RichTextTokenType_BOLD_getInstance())) {
      tmp = bold($this);
    } else if (equals(tmp0_subject, RichTextTokenType_ITALIC_getInstance())) {
      tmp = italic($this);
    } else if (equals(tmp0_subject, RichTextTokenType_TEXT_getInstance())) {
      tmp = text_0($this);
    } else {
      throw new SyntaxError(location, Translations_getInstance().zm('base.dsl.unexpectedToken.msg', [token.d11_1.av()]));
    }
    return tmp;
  }
  function bold($this) {
    $this.k11(RichTextTokenType_BOLD_getInstance());
    $this.v1j_1 = Companion_getInstance_22().x1j($this.v1j_1);
    var tmp;
    if (equals(ensureNotNull($this.g11_1).d11_1, RichTextTokenType_LPAREN_getInstance())) {
      tmp = eatParen($this, RichTextParser$bold$lambda($this));
    } else {
      tmp = singleChar($this);
    }
    var bold = tmp;
    $this.v1j_1 = Companion_getInstance_22().y1j($this.v1j_1);
    return bold;
  }
  function italic($this) {
    $this.k11(RichTextTokenType_ITALIC_getInstance());
    $this.v1j_1 = Companion_getInstance_22().z1j($this.v1j_1);
    var tmp;
    if (equals(ensureNotNull($this.g11_1).d11_1, RichTextTokenType_LPAREN_getInstance())) {
      tmp = eatParen($this, RichTextParser$italic$lambda($this));
    } else {
      tmp = singleChar($this);
    }
    var italic = tmp;
    $this.v1j_1 = Companion_getInstance_22().a1k($this.v1j_1);
    return italic;
  }
  function overline($this) {
    $this.k11(RichTextTokenType_OVERLINE_getInstance());
    $this.v1j_1 = Companion_getInstance_22().d1k($this.v1j_1);
    var tmp;
    if (equals(ensureNotNull($this.g11_1).d11_1, RichTextTokenType_LPAREN_getInstance())) {
      tmp = eatParen($this, RichTextParser$overline$lambda($this));
    } else {
      tmp = singleChar($this);
    }
    var overline = tmp;
    $this.v1j_1 = Companion_getInstance_22().e1k($this.v1j_1);
    return overline;
  }
  function text_0($this) {
    // Inline function 'kotlin.let' call
    var location = $this.f11_1.hw();
    if (!equals(ensureNotNull($this.g11_1).d11_1, RichTextTokenType_TEXT_getInstance())) {
      throw new SyntaxError(location, Translations_getInstance().zm('base.dsl.unexpectedToken.msg', [ensureNotNull($this.g11_1).d11_1.av()]));
    }
    var tmp = ensureNotNull($this.g11_1).e11_1;
    var text = (!(tmp == null) ? typeof tmp === 'string' : false) ? tmp : THROW_CCE();
    $this.k11(RichTextTokenType_TEXT_getInstance());
    return new StyledText($this.f11_1.hw(), listOf_0(new StyledChunk(location, text, $this.v1j_1)));
  }
  function singleChar($this) {
    return text_0($this);
  }
  function RichTextParser$boldText$lambda(this$0) {
    return function () {
      return richText(this$0);
    };
  }
  function RichTextParser$italicText$lambda(this$0) {
    return function () {
      return richText(this$0);
    };
  }
  function RichTextParser$subscript$lambda(this$0) {
    return function () {
      return new Subscript(this$0.f11_1.hw(), styledText(this$0));
    };
  }
  function RichTextParser$superscript$lambda(this$0) {
    return function () {
      return new Superscript(this$0.f11_1.hw(), styledText(this$0));
    };
  }
  function RichTextParser$bold$lambda(this$0) {
    return function () {
      return styledText(this$0);
    };
  }
  function RichTextParser$italic$lambda(this$0) {
    return function () {
      return styledText(this$0);
    };
  }
  function RichTextParser$overline$lambda(this$0) {
    return function () {
      return styledText(this$0);
    };
  }
  function RichTextParser(lexer) {
    AbstractParser.call(this, lexer);
    this.v1j_1 = Companion_getInstance_22().w1j_1;
  }
  protoOf(RichTextParser).vy = function () {
    return richText(this);
  };
  function Companion_21() {
  }
  protoOf(Companion_21).f1k = function (text) {
    var tmp;
    try {
      var richText = RichTextParser_init_$Create$(text).vy();
      var result = StringBuilder_init_$Create$();
      // Inline function 'kotlin.collections.forEach' call
      var _iterator__ex2g4s = richText.sw_1.i();
      while (_iterator__ex2g4s.j()) {
        var element = _iterator__ex2g4s.k();
        // Inline function 'kotlin.collections.forEach' call
        var _iterator__ex2g4s_0 = element.j1k_1.h1k_1.c1k_1.i();
        while (_iterator__ex2g4s_0.j()) {
          var element_0 = _iterator__ex2g4s_0.k();
          result.h7(replace(element_0.n1k_1, '/', ' '));
        }
      }
      tmp = result.toString();
    } catch ($p) {
      var tmp_0;
      if ($p instanceof Error) {
        var _unused_var__etf5q3 = $p;
        tmp_0 = replace(text, '/', ' ');
      } else {
        throw $p;
      }
      tmp = tmp_0;
    }
    return tmp;
  };
  protoOf(Companion_21).p1k = function (text) {
    return new RichText(Companion_getInstance_18().ax_1, listOf_0(new Fragment(Companion_getInstance_18().ax_1, new FragmentText(Companion_getInstance_18().ax_1, new StyledText(Companion_getInstance_18().ax_1, listOf_0(new StyledChunk(Companion_getInstance_18().ax_1, text)))))));
  };
  var Companion_instance_21;
  function Companion_getInstance_21() {
    return Companion_instance_21;
  }
  function RichText(location, fragments) {
    Compound.call(this, location, fragments);
  }
  protoOf(RichText).s1k = function () {
    var tmp0 = this.sw_1;
    var tmp$ret$0;
    $l$block: {
      // Inline function 'kotlin.collections.maxOfOrNull' call
      var iterator = tmp0.i();
      if (!iterator.j()) {
        tmp$ret$0 = null;
        break $l$block;
      }
      var tmp0_0 = iterator.k().j1k_1.h1k_1.c1k_1;
      var tmp$ret$2;
      $l$block_0: {
        // Inline function 'kotlin.collections.maxOfOrNull' call
        var iterator_0 = tmp0_0.i();
        if (!iterator_0.j()) {
          tmp$ret$2 = null;
          break $l$block_0;
        }
        var maxValue = iterator_0.k().o1k_1.t1k_1;
        while (iterator_0.j()) {
          var v = iterator_0.k().o1k_1.t1k_1;
          if (compareTo(maxValue, v) < 0) {
            maxValue = v;
          }
        }
        tmp$ret$2 = maxValue;
      }
      var tmp0_elvis_lhs = tmp$ret$2;
      var maxValue_0 = tmp0_elvis_lhs == null ? 0 : tmp0_elvis_lhs;
      while (iterator.j()) {
        var tmp0_1 = iterator.k().j1k_1.h1k_1.c1k_1;
        var tmp$ret$6;
        $l$block_1: {
          // Inline function 'kotlin.collections.maxOfOrNull' call
          var iterator_1 = tmp0_1.i();
          if (!iterator_1.j()) {
            tmp$ret$6 = null;
            break $l$block_1;
          }
          var maxValue_1 = iterator_1.k().o1k_1.t1k_1;
          while (iterator_1.j()) {
            var v_0 = iterator_1.k().o1k_1.t1k_1;
            if (compareTo(maxValue_1, v_0) < 0) {
              maxValue_1 = v_0;
            }
          }
          tmp$ret$6 = maxValue_1;
        }
        var tmp0_elvis_lhs_0 = tmp$ret$6;
        var v_1 = tmp0_elvis_lhs_0 == null ? 0 : tmp0_elvis_lhs_0;
        if (compareTo(maxValue_0, v_1) < 0) {
          maxValue_0 = v_1;
        }
      }
      tmp$ret$0 = maxValue_0;
    }
    var tmp0_elvis_lhs_1 = tmp$ret$0;
    return tmp0_elvis_lhs_1 == null ? 0 : tmp0_elvis_lhs_1;
  };
  function Fragment(location, text, subscript, superscript) {
    subscript = subscript === VOID ? null : subscript;
    superscript = superscript === VOID ? null : superscript;
    AbstractNode.call(this, location);
    this.j1k_1 = text;
    this.k1k_1 = subscript;
    this.l1k_1 = superscript;
  }
  protoOf(Fragment).toString = function () {
    return 'Fragment';
  };
  protoOf(Fragment).e13 = function (visitor) {
    if (visitor.fs(this)) {
      this.j1k_1.e13(visitor);
      var tmp0_safe_receiver = this.k1k_1;
      if (tmp0_safe_receiver == null)
        null;
      else
        tmp0_safe_receiver.e13(visitor);
      var tmp1_safe_receiver = this.l1k_1;
      if (tmp1_safe_receiver == null)
        null;
      else
        tmp1_safe_receiver.e13(visitor);
    }
    return visitor.is(this);
  };
  function StyledChunk(location, text, style) {
    style = style === VOID ? Companion_getInstance_22().w1j_1 : style;
    AbstractNode.call(this, location);
    this.n1k_1 = text;
    this.o1k_1 = style;
  }
  protoOf(StyledChunk).toString = function () {
    var s = StringBuilder_init_$Create$();
    if (this.o1k_1.u1k_1) {
      s.h7(RichTextTokenType_BOLD_getInstance().r1j_1);
    }
    if (this.o1k_1.v1k_1) {
      s.h7(RichTextTokenType_ITALIC_getInstance().r1j_1);
    }
    // Inline function 'kotlin.collections.forEach' call
    var progression = numberRangeToNumber(1, this.o1k_1.t1k_1);
    var inductionVariable = progression.y_1;
    var last = progression.z_1;
    if (inductionVariable <= last)
      do {
        var element = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        s.h7(RichTextTokenType_OVERLINE_getInstance().r1j_1);
      }
       while (!(element === last));
    // Inline function 'kotlin.text.isNotEmpty' call
    if (charSequenceLength(s) > 0) {
      s.h7('(' + this.n1k_1 + ')');
    } else {
      s.h7(this.n1k_1);
    }
    return s.toString();
  };
  protoOf(StyledChunk).w1k = function () {
    var words = split(this.n1k_1, charArrayOf([_Char___init__impl__6a9atx(32)]));
    // Inline function 'kotlin.collections.mapIndexed' call
    // Inline function 'kotlin.collections.mapIndexedTo' call
    var destination = ArrayList_init_$Create$_0(collectionSizeOrDefault(words, 10));
    var index = 0;
    var _iterator__ex2g4s = words.i();
    while (_iterator__ex2g4s.j()) {
      var item = _iterator__ex2g4s.k();
      var _unary__edvuaz = index;
      index = _unary__edvuaz + 1 | 0;
      var tmp;
      if (checkIndexOverflow(_unary__edvuaz) === (words.o() - 1 | 0)) {
        tmp = new StyledChunk(this.hw(), item, this.o1k_1);
      } else {
        tmp = new StyledChunk(this.hw(), item + ' ', this.o1k_1);
      }
      var tmp$ret$2 = tmp;
      destination.h(tmp$ret$2);
    }
    return destination;
  };
  function StyledText(location, chunks) {
    AbstractNode.call(this, location);
    this.c1k_1 = chunks;
  }
  protoOf(StyledText).toString = function () {
    return 'StyledText';
  };
  protoOf(StyledText).e13 = function (visitor) {
    if (visitor.fs(this)) {
      // Inline function 'kotlin.collections.forEach' call
      var _iterator__ex2g4s = this.c1k_1.i();
      while (_iterator__ex2g4s.j()) {
        var element = _iterator__ex2g4s.k();
        element.e13(visitor);
      }
    }
    return visitor.is(this);
  };
  function FragmentText(location, styledText) {
    AbstractFragmentPart.call(this, location, styledText);
  }
  protoOf(FragmentText).toString = function () {
    return '-';
  };
  function Companion_22() {
    Companion_instance_22 = this;
    this.w1j_1 = new TextStyle(0, false, false);
  }
  protoOf(Companion_22).d1k = function (style) {
    return new TextStyle(style.t1k_1 + 1 | 0, style.u1k_1, style.v1k_1);
  };
  protoOf(Companion_22).e1k = function (style) {
    // Inline function 'kotlin.math.max' call
    var a = style.t1k_1 - 1 | 0;
    var tmp$ret$0 = Math.max(a, 0);
    return new TextStyle(tmp$ret$0, style.u1k_1, style.v1k_1);
  };
  protoOf(Companion_22).x1j = function (style) {
    return new TextStyle(style.t1k_1, true, style.v1k_1);
  };
  protoOf(Companion_22).y1j = function (style) {
    return new TextStyle(style.t1k_1, false, style.v1k_1);
  };
  protoOf(Companion_22).z1j = function (style) {
    return new TextStyle(style.t1k_1, style.u1k_1, true);
  };
  protoOf(Companion_22).a1k = function (style) {
    return new TextStyle(style.t1k_1, style.u1k_1, false);
  };
  var Companion_instance_22;
  function Companion_getInstance_22() {
    if (Companion_instance_22 == null)
      new Companion_22();
    return Companion_instance_22;
  }
  function TextStyle(overlineLevel, bold, italic) {
    Companion_getInstance_22();
    this.t1k_1 = overlineLevel;
    this.u1k_1 = bold;
    this.v1k_1 = italic;
  }
  protoOf(TextStyle).toString = function () {
    return 'TextStyle(overlineLevel=' + this.t1k_1 + ', bold=' + this.u1k_1 + ', italic=' + this.v1k_1 + ')';
  };
  protoOf(TextStyle).hashCode = function () {
    var result = this.t1k_1;
    result = imul(result, 31) + getBooleanHashCode(this.u1k_1) | 0;
    result = imul(result, 31) + getBooleanHashCode(this.v1k_1) | 0;
    return result;
  };
  protoOf(TextStyle).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof TextStyle))
      return false;
    if (!(this.t1k_1 === other.t1k_1))
      return false;
    if (!(this.u1k_1 === other.u1k_1))
      return false;
    if (!(this.v1k_1 === other.v1k_1))
      return false;
    return true;
  };
  function Subscript(location, styledText) {
    AbstractFragmentPart.call(this, location, styledText);
  }
  protoOf(Subscript).toString = function () {
    return '_';
  };
  function Superscript(location, styledText) {
    AbstractFragmentPart.call(this, location, styledText);
  }
  protoOf(Superscript).toString = function () {
    return '^';
  };
  function AbstractFragmentPart(location, styledText) {
    AbstractNode.call(this, location);
    this.h1k_1 = styledText;
  }
  protoOf(AbstractFragmentPart).e13 = function (visitor) {
    if (visitor.fs(this)) {
      // Inline function 'kotlin.collections.forEach' call
      var _iterator__ex2g4s = this.h1k_1.c1k_1.i();
      while (_iterator__ex2g4s.j()) {
        var element = _iterator__ex2g4s.k();
        element.e13(visitor);
      }
    }
    return visitor.is(this);
  };
  function updateEnableSoundEffects($this) {
    $this.t1i_1 = BaseModule_getInstance().xo_1.ft('jabbah.base.sound.enableSoundEffects');
  }
  function SoundEffects$initialize$lambda(it) {
    updateEnableSoundEffects(SoundEffects_instance);
    return Unit_instance;
  }
  function SoundEffects() {
    this.s1i_1 = 'jabbah.base.sound.enableSoundEffects';
    this.t1i_1 = false;
  }
  protoOf(SoundEffects).u1i = function (eventBus) {
    var tmp = getKClass(PreferencesChangedEvent);
    eventBus.j17(tmp, SoundEffects$initialize$lambda);
    updateEnableSoundEffects(this);
  };
  var SoundEffects_instance;
  function SoundEffects_getInstance() {
    return SoundEffects_instance;
  }
  var WaveformType_Sine_instance;
  var WaveformType_Square_instance;
  var WaveformType_Triangle_instance;
  var WaveformType_Sawtooth_instance;
  var WaveformType_Noise_instance;
  function Companion_23() {
    this.x1k_1 = 'element.property.waveformType';
  }
  protoOf(Companion_23).r1e = function (customName) {
    var tmp0 = values_3();
    var tmp$ret$0;
    $l$block: {
      // Inline function 'kotlin.collections.firstOrNull' call
      var inductionVariable = 0;
      var last = tmp0.length;
      while (inductionVariable < last) {
        var element = tmp0[inductionVariable];
        inductionVariable = inductionVariable + 1 | 0;
        if (element.a1l_1 === customName) {
          tmp$ret$0 = element;
          break $l$block;
        }
      }
      tmp$ret$0 = null;
    }
    var tmp0_elvis_lhs = tmp$ret$0;
    var tmp;
    if (tmp0_elvis_lhs == null) {
      throw IllegalArgumentException_init_$Create$('unknown WaveformType ' + customName);
    } else {
      tmp = tmp0_elvis_lhs;
    }
    return tmp;
  };
  var Companion_instance_23;
  function Companion_getInstance_23() {
    return Companion_instance_23;
  }
  function values_3() {
    return [WaveformType_Sine_getInstance(), WaveformType_Square_getInstance(), WaveformType_Triangle_getInstance(), WaveformType_Sawtooth_getInstance(), WaveformType_Noise_getInstance()];
  }
  var WaveformType_entriesInitialized;
  function WaveformType_initEntries() {
    if (WaveformType_entriesInitialized)
      return Unit_instance;
    WaveformType_entriesInitialized = true;
    WaveformType_Sine_instance = new WaveformType('Sine', 0, 'sine');
    WaveformType_Square_instance = new WaveformType('Square', 1, 'square');
    WaveformType_Triangle_instance = new WaveformType('Triangle', 2, 'triangle');
    WaveformType_Sawtooth_instance = new WaveformType('Sawtooth', 3, 'sawtooth');
    WaveformType_Noise_instance = new WaveformType('Noise', 4, 'noise');
  }
  function WaveformType(name, ordinal, customName) {
    Enum.call(this, name, ordinal);
    this.a1l_1 = customName;
  }
  protoOf(WaveformType).toString = function () {
    return Translations_getInstance().zm('element.property.waveformType.' + this.a1l_1, []);
  };
  function ToneParams(frequency, volume, waveformType, leftChannel, rightChannel, smoothLevel, smoothWidth) {
    waveformType = waveformType === VOID ? WaveformType_Sine_getInstance() : waveformType;
    leftChannel = leftChannel === VOID ? true : leftChannel;
    rightChannel = rightChannel === VOID ? true : rightChannel;
    smoothLevel = smoothLevel === VOID ? 2 : smoothLevel;
    smoothWidth = smoothWidth === VOID ? 2 : smoothWidth;
    this.b1l_1 = frequency;
    this.c1l_1 = volume;
    this.d1l_1 = waveformType;
    this.e1l_1 = leftChannel;
    this.f1l_1 = rightChannel;
    this.g1l_1 = smoothLevel;
    this.h1l_1 = smoothWidth;
  }
  protoOf(ToneParams).toString = function () {
    return 'ToneParams(frequency=' + this.b1l_1 + ', volume=' + this.c1l_1 + ', waveformType=' + this.d1l_1.toString() + ', leftChannel=' + this.e1l_1 + ', rightChannel=' + this.f1l_1 + ', smoothLevel=' + this.g1l_1 + ', smoothWidth=' + this.h1l_1 + ')';
  };
  protoOf(ToneParams).hashCode = function () {
    var result = this.b1l_1;
    result = imul(result, 31) + getNumberHashCode(this.c1l_1) | 0;
    result = imul(result, 31) + this.d1l_1.hashCode() | 0;
    result = imul(result, 31) + getBooleanHashCode(this.e1l_1) | 0;
    result = imul(result, 31) + getBooleanHashCode(this.f1l_1) | 0;
    result = imul(result, 31) + this.g1l_1 | 0;
    result = imul(result, 31) + this.h1l_1 | 0;
    return result;
  };
  protoOf(ToneParams).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof ToneParams))
      return false;
    if (!(this.b1l_1 === other.b1l_1))
      return false;
    if (!equals(this.c1l_1, other.c1l_1))
      return false;
    if (!this.d1l_1.equals(other.d1l_1))
      return false;
    if (!(this.e1l_1 === other.e1l_1))
      return false;
    if (!(this.f1l_1 === other.f1l_1))
      return false;
    if (!(this.g1l_1 === other.g1l_1))
      return false;
    if (!(this.h1l_1 === other.h1l_1))
      return false;
    return true;
  };
  function WaveformType_Sine_getInstance() {
    WaveformType_initEntries();
    return WaveformType_Sine_instance;
  }
  function WaveformType_Square_getInstance() {
    WaveformType_initEntries();
    return WaveformType_Square_instance;
  }
  function WaveformType_Triangle_getInstance() {
    WaveformType_initEntries();
    return WaveformType_Triangle_instance;
  }
  function WaveformType_Sawtooth_getInstance() {
    WaveformType_initEntries();
    return WaveformType_Sawtooth_instance;
  }
  function WaveformType_Noise_getInstance() {
    WaveformType_initEntries();
    return WaveformType_Noise_instance;
  }
  function addTransition($this, transition, init) {
    if (init == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      init(transition);
    }
    $this.j1l_1.h(transition);
    return transition;
  }
  function State$entryAction$lambda(it) {
    return Unit_instance;
  }
  function State$exitAction$lambda(it) {
    return Unit_instance;
  }
  function State$stayOtherwise$lambda(it) {
    return true;
  }
  function State_0(name) {
    this.i1l_1 = name;
    var tmp = this;
    // Inline function 'kotlin.collections.mutableListOf' call
    tmp.j1l_1 = ArrayList_init_$Create$();
    var tmp_0 = this;
    tmp_0.k1l_1 = State$entryAction$lambda;
    var tmp_1 = this;
    tmp_1.l1l_1 = State$exitAction$lambda;
  }
  protoOf(State_0).m1l = function (event) {
    this.k1l_1(event);
  };
  protoOf(State_0).n1l = function (event) {
    this.l1l_1(event);
  };
  protoOf(State_0).o1l = function (event) {
    var tmp0 = this.j1l_1;
    var tmp$ret$0;
    $l$block: {
      // Inline function 'kotlin.collections.firstOrNull' call
      var _iterator__ex2g4s = tmp0.i();
      while (_iterator__ex2g4s.j()) {
        var element = _iterator__ex2g4s.k();
        if (element.s1l()(event)) {
          tmp$ret$0 = element;
          break $l$block;
        }
      }
      tmp$ret$0 = null;
    }
    return tmp$ret$0;
  };
  protoOf(State_0).t1l = function (event) {
    return false;
  };
  protoOf(State_0).u1l = function (action) {
    this.k1l_1 = action;
  };
  protoOf(State_0).v1l = function (action) {
    this.l1l_1 = action;
  };
  protoOf(State_0).w1l = function (condition, init) {
    return addTransition(this, new Transition(this.i1l_1, condition), init);
  };
  protoOf(State_0).x1l = function (condition) {
    return this.w1l(condition, null);
  };
  protoOf(State_0).y1l = function (init) {
    return addTransition(this, new Transition(this.i1l_1, State$stayOtherwise$lambda), init);
  };
  protoOf(State_0).z1l = function (init, $super) {
    init = init === VOID ? null : init;
    return $super === VOID ? this.y1l(init) : $super.y1l.call(this, init);
  };
  protoOf(State_0).a1m = function (destinationStateName, init) {
    return addTransition(this, new Transition(destinationStateName), init);
  };
  function _get_LOG__e5r759_5($this) {
    var tmp0 = $this.b1m_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('LOG', 1, tmp, StateMachine$Companion$_get_LOG_$ref_l8ab1m(), null);
    return tmp0.j2();
  }
  function StateMachine$Companion$_get_LOG_$ref_l8ab1m() {
    return function (p0) {
      return _get_LOG__e5r759_5(p0);
    };
  }
  function Companion_24() {
    Companion_instance_24 = this;
    this.b1m_1 = logger(getKClass(StateMachine));
  }
  var Companion_instance_24;
  function Companion_getInstance_24() {
    if (Companion_instance_24 == null)
      new Companion_24();
    return Companion_instance_24;
  }
  function enter($this, state, event) {
    _get_LOG__e5r759_5(Companion_getInstance_24()).ol("Enter state '" + state.i1l_1 + "'");
    $this.g1m_1 = state;
    state.m1l(event);
  }
  function transferAlong($this, transition, event) {
    var destinationState = stateWithName($this, transition.p1l_1);
    if (destinationState == null && !($this.d1m_1 == null)) {
      var outerDestinationState = stateWithName($this.d1m_1, transition.p1l_1);
      if (!(outerDestinationState == null)) {
        $this.h1m().n1l(event);
        transitAndEnter($this.d1m_1, transition, outerDestinationState, event);
        return Unit_instance;
      }
    }
    if (destinationState == null) {
      throw IllegalArgumentException_init_$Create$("Undefined destination state '" + transition.p1l_1 + "' in " + $this.h1m().i1l_1);
    }
    if (!(destinationState === $this.h1m())) {
      $this.h1m().n1l(event);
    }
    transitAndEnter($this, transition, destinationState, event);
  }
  function transitAndEnter($this, transition, destinationState, event) {
    transition.i1m(event);
    if (!(destinationState === $this.h1m())) {
      _get_LOG__e5r759_5(Companion_getInstance_24()).ol('Transferring to ' + getKClassFromExpression(destinationState).l9() + " '" + destinationState.i1l_1 + "'");
      enter($this, destinationState, event);
    } else {
      if (_get_LOG__e5r759_5(Companion_getInstance_24()).ql()) {
        _get_LOG__e5r759_5(Companion_getInstance_24()).ol('Stay in ' + getKClassFromExpression($this.h1m()).l9() + " '" + destinationState.i1l_1 + "' with event " + toString_0(event));
      }
    }
  }
  function stateWithName($this, name) {
    var tmp0 = $this.e1m_1;
    var tmp$ret$0;
    $l$block: {
      // Inline function 'kotlin.collections.firstOrNull' call
      var _iterator__ex2g4s = tmp0.i();
      while (_iterator__ex2g4s.j()) {
        var element = _iterator__ex2g4s.k();
        if (element.i1l_1 === name) {
          tmp$ret$0 = element;
          break $l$block;
        }
      }
      tmp$ret$0 = null;
    }
    return tmp$ret$0;
  }
  function ensureUniqueStateName($this, name) {
    if (!(stateWithName($this, name) == null)) {
      throw IllegalArgumentException_init_$Create$('State name ' + name + ' must be unique');
    }
  }
  function StateMachine(behaviour, outer) {
    Companion_getInstance_24();
    behaviour = behaviour === VOID ? UnhandledEventBehaviour_Strict_getInstance() : behaviour;
    outer = outer === VOID ? null : outer;
    this.c1m_1 = behaviour;
    this.d1m_1 = outer;
    var tmp = this;
    // Inline function 'kotlin.collections.mutableListOf' call
    tmp.e1m_1 = ArrayList_init_$Create$();
    var tmp_0 = this;
    // Inline function 'kotlin.collections.mutableListOf' call
    tmp_0.f1m_1 = ArrayList_init_$Create$();
  }
  protoOf(StateMachine).h1m = function () {
    var tmp = this.g1m_1;
    if (!(tmp == null))
      return tmp;
    else {
      throwUninitializedPropertyAccessException('currentState');
    }
  };
  protoOf(StateMachine).j1m = function (event) {
    if (this.e1m_1.m()) {
      throw IllegalStateException_init_$Create$('StateMachine must have at least 1 state');
    }
    _get_LOG__e5r759_5(Companion_getInstance_24()).ol("Start in state '" + first_0(this.e1m_1).i1l_1 + "'");
    enter(this, first_0(this.e1m_1), event);
    return this;
  };
  protoOf(StateMachine).t1l = function (event) {
    if (_get_LOG__e5r759_5(Companion_getInstance_24()).ql()) {
      _get_LOG__e5r759_5(Companion_getInstance_24()).ol('Handle event ' + toString_0(event));
    }
    try {
      var transition = this.h1m().o1l(event);
      if (!(transition == null)) {
        transferAlong(this, transition, event);
        return true;
      }
      if (this.h1m().t1l(event)) {
        return true;
      }
    } catch ($p) {
      if ($p instanceof Error) {
        var e = $p;
        _get_LOG__e5r759_5(Companion_getInstance_24()).kl('Error when handling event ' + toString_0(event) + ' in state ' + this.h1m().i1l_1 + ': ' + System_getInstance().wl(e));
        throw e;
      } else {
        throw $p;
      }
    }
    var tmp0 = this.f1m_1;
    var tmp$ret$0;
    $l$block_0: {
      // Inline function 'kotlin.collections.any' call
      var tmp;
      if (isInterface(tmp0, Collection)) {
        tmp = tmp0.m();
      } else {
        tmp = false;
      }
      if (tmp) {
        tmp$ret$0 = false;
        break $l$block_0;
      }
      var _iterator__ex2g4s = tmp0.i();
      while (_iterator__ex2g4s.j()) {
        var element = _iterator__ex2g4s.k();
        if (element(event)) {
          tmp$ret$0 = true;
          break $l$block_0;
        }
      }
      tmp$ret$0 = false;
    }
    if (tmp$ret$0) {
      _get_LOG__e5r759_5(Companion_getInstance_24()).ol('Explicitly ignored event ' + toString_0(event));
      return true;
    }
    _get_LOG__e5r759_5(Companion_getInstance_24()).ol('Unhandled event ' + toString_0(event));
    return this.c1m_1.m1m(!(event == null) ? event : THROW_CCE());
  };
  protoOf(StateMachine).n1m = function (condition) {
    this.f1m_1.h(condition);
  };
  protoOf(StateMachine).o1m = function (name, init) {
    ensureUniqueStateName(this, name);
    var state = new State_0(name);
    if (!(init == null)) {
      init(state);
    }
    this.e1m_1.h(state);
    return state;
  };
  protoOf(StateMachine).p1m = function (name, init) {
    ensureUniqueStateName(this, name);
    var state = new SuperState(name, this);
    if (!(init == null)) {
      init(state);
    }
    this.e1m_1.h(state);
    return state;
  };
  function stateMachine(behaviour, outer, init) {
    behaviour = behaviour === VOID ? UnhandledEventBehaviour_Strict_getInstance() : behaviour;
    outer = outer === VOID ? null : outer;
    var sm = new StateMachine(behaviour, outer);
    init(sm);
    return sm;
  }
  function UnhandledEventBehaviour$Strict() {
    UnhandledEventBehaviour.call(this, 'Strict', 0);
    UnhandledEventBehaviour_Strict_instance = this;
  }
  protoOf(UnhandledEventBehaviour$Strict).m1m = function (event) {
    throw IllegalArgumentException_init_$Create$('Unhandled event ' + toString(event));
  };
  var UnhandledEventBehaviour_Strict_instance;
  function UnhandledEventBehaviour$Unhandled() {
    UnhandledEventBehaviour.call(this, 'Unhandled', 1);
    UnhandledEventBehaviour_Unhandled_instance = this;
  }
  protoOf(UnhandledEventBehaviour$Unhandled).m1m = function (event) {
    return false;
  };
  var UnhandledEventBehaviour_Unhandled_instance;
  var UnhandledEventBehaviour_entriesInitialized;
  function UnhandledEventBehaviour_initEntries() {
    if (UnhandledEventBehaviour_entriesInitialized)
      return Unit_instance;
    UnhandledEventBehaviour_entriesInitialized = true;
    UnhandledEventBehaviour_Strict_instance = new UnhandledEventBehaviour$Strict();
    UnhandledEventBehaviour_Unhandled_instance = new UnhandledEventBehaviour$Unhandled();
  }
  function UnhandledEventBehaviour(name, ordinal) {
    Enum.call(this, name, ordinal);
  }
  function UnhandledEventBehaviour_Strict_getInstance() {
    UnhandledEventBehaviour_initEntries();
    return UnhandledEventBehaviour_Strict_instance;
  }
  function UnhandledEventBehaviour_Unhandled_getInstance() {
    UnhandledEventBehaviour_initEntries();
    return UnhandledEventBehaviour_Unhandled_instance;
  }
  function SuperState(name, outerStateMachine) {
    State_0.call(this, name);
    this.y1m_1 = outerStateMachine;
  }
  protoOf(SuperState).a1n = function () {
    var tmp = this.z1m_1;
    if (!(tmp == null))
      return tmp;
    else {
      throwUninitializedPropertyAccessException('stateMachine');
    }
  };
  protoOf(SuperState).m1l = function (event) {
    protoOf(State_0).m1l.call(this, event);
    this.a1n().j1m(event);
  };
  protoOf(SuperState).t1l = function (event) {
    return this.a1n().t1l(event);
  };
  protoOf(SuperState).b1n = function (behaviour, init) {
    this.z1m_1 = stateMachine(behaviour, this.y1m_1, init);
  };
  function Transition$action$lambda(it) {
    return Unit_instance;
  }
  function Transition(destinationStateName, condition) {
    condition = condition === VOID ? null : condition;
    this.p1l_1 = destinationStateName;
    if (!(condition == null)) {
      this.q1l_1 = condition;
    }
    var tmp = this;
    tmp.r1l_1 = Transition$action$lambda;
  }
  protoOf(Transition).s1l = function () {
    var tmp = this.q1l_1;
    if (!(tmp == null))
      return tmp;
    else {
      throwUninitializedPropertyAccessException('condition');
    }
  };
  protoOf(Transition).i1m = function (event) {
    this.r1l_1(event);
  };
  protoOf(Transition).c1n = function (condition) {
    this.q1l_1 = condition;
  };
  protoOf(Transition).d1n = function (action) {
    this.r1l_1 = action;
  };
  function _get_LOG__e5r759_6($this) {
    var tmp0 = $this.im_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('LOG', 1, tmp, PropertiesFileParser$_get_LOG_$ref_e0dkre(), null);
    return tmp0.j2();
  }
  function PropertiesFileParser$_get_LOG_$ref_e0dkre() {
    return function (p0) {
      return _get_LOG__e5r759_6(p0);
    };
  }
  function PropertiesFileParser() {
    PropertiesFileParser_instance = this;
    this.im_1 = logger(getKClass(PropertiesFileParser));
  }
  protoOf(PropertiesFileParser).jm = function (text) {
    // Inline function 'kotlin.collections.mutableMapOf' call
    var translations = LinkedHashMap_init_$Create$();
    var currentKey = null;
    var currentValue = null;
    // Inline function 'kotlin.collections.filter' call
    var tmp0 = lines(text);
    // Inline function 'kotlin.collections.filterTo' call
    var destination = ArrayList_init_$Create$();
    var _iterator__ex2g4s = tmp0.i();
    while (_iterator__ex2g4s.j()) {
      var element = _iterator__ex2g4s.k();
      var tmp;
      if (!startsWith(element, _Char___init__impl__6a9atx(35))) {
        // Inline function 'kotlin.text.isNotBlank' call
        tmp = !isBlank(element);
      } else {
        tmp = false;
      }
      if (tmp) {
        destination.h(element);
      }
    }
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s_0 = destination.i();
    while (_iterator__ex2g4s_0.j()) {
      var element_0 = _iterator__ex2g4s_0.k();
      try {
        if (currentKey == null) {
          var _destruct__k2r9zo = split(element_0, charArrayOf([_Char___init__impl__6a9atx(61)]));
          // Inline function 'kotlin.collections.component1' call
          var key = _destruct__k2r9zo.l(0);
          // Inline function 'kotlin.collections.component2' call
          var value = _destruct__k2r9zo.l(1);
          // Inline function 'kotlin.text.trim' call
          currentKey = toString(trim(isCharSequence(key) ? key : THROW_CCE()));
          // Inline function 'kotlin.text.trim' call
          currentValue = toString(trim(isCharSequence(value) ? value : THROW_CCE()));
        } else {
          var tmp0_safe_receiver = currentValue;
          var tmp_0;
          if (tmp0_safe_receiver == null) {
            tmp_0 = null;
          } else {
            // Inline function 'kotlin.text.trim' call
            tmp_0 = tmp0_safe_receiver + toString(trim(isCharSequence(element_0) ? element_0 : THROW_CCE()));
          }
          currentValue = tmp_0;
        }
        currentValue = replace(ensureNotNull(currentValue), '\\n', '\n');
        if (endsWith(currentValue, _Char___init__impl__6a9atx(92))) {
          currentValue = removeSuffix(currentValue, '\\');
        } else {
          var tmp2 = currentKey;
          // Inline function 'kotlin.collections.set' call
          var value_0 = currentValue;
          translations.y1(tmp2, value_0);
          currentKey = null;
          currentValue = null;
        }
      } catch ($p) {
        if ($p instanceof Error) {
          var e = $p;
          _get_LOG__e5r759_6(PropertiesFileParser_getInstance()).kl("Error while parsing translation line '" + element_0 + "': " + e.toString());
          throw e;
        } else {
          throw $p;
        }
      }
    }
    if (!(currentKey == null)) {
      var tmp2_0 = currentKey;
      // Inline function 'kotlin.collections.set' call
      var value_1 = ensureNotNull(currentValue);
      translations.y1(tmp2_0, value_1);
    }
    return translations;
  };
  var PropertiesFileParser_instance;
  function PropertiesFileParser_getInstance() {
    if (PropertiesFileParser_instance == null)
      new PropertiesFileParser();
    return PropertiesFileParser_instance;
  }
  function _get_LOG__e5r759_7($this) {
    var tmp0 = $this.e1n_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('LOG', 1, tmp, SystemSpeed$Companion$_get_LOG_$ref_umgkzc(), null);
    return tmp0.j2();
  }
  function SystemSpeed$Companion$_get_LOG_$ref_umgkzc() {
    return function (p0) {
      return _get_LOG__e5r759_7(p0);
    };
  }
  function Companion_25() {
    Companion_instance_25 = this;
    this.e1n_1 = logger(getKClass(SystemSpeed));
    this.f1n_1 = 'jabbah.base.time.SystemSpeed';
    this.g1n_1 = 60;
    this.h1n_1 = 0;
    this.i1n_1 = 100;
  }
  var Companion_instance_25;
  function Companion_getInstance_25() {
    if (Companion_instance_25 == null)
      new Companion_25();
    return Companion_instance_25;
  }
  function SystemSpeed(speed, eventBus) {
    Companion_getInstance_25();
    speed = speed === VOID ? BaseModule_getInstance().yo_1.yt('jabbah.base.time.SystemSpeed', 60) : speed;
    eventBus = eventBus === VOID ? BaseModule_getInstance().zo_1 : eventBus;
    this.j1n_1 = eventBus;
    this.k1n_1 = speed;
    this.l1n_1 = false;
  }
  protoOf(SystemSpeed).m1n = function (value) {
    var containsArg = this.k1n_1;
    // Inline function 'kotlin.require' call
    if (!(0 <= containsArg ? containsArg <= 100 : false)) {
      var message = 'SystemSpeed must be between 0 and 100';
      throw IllegalArgumentException_init_$Create$(toString(message));
    }
    BaseModule_getInstance().yo_1.ct('jabbah.base.time.SystemSpeed', value);
    var oldSpeed = this.k1n_1;
    this.k1n_1 = value;
    this.j1n_1.eu(new SystemSpeedEvent(this, oldSpeed, this.k1n_1));
  };
  protoOf(SystemSpeed).n1n = function () {
    return this.k1n_1 === 100;
  };
  protoOf(SystemSpeed).o1n = function () {
    if (!this.l1n_1) {
      this.l1n_1 = true;
      _get_LOG__e5r759_7(Companion_getInstance_25()).ol('SystemSpeed paused');
      this.j1n_1.eu(new SystemSpeedPauseEvent(this, this.l1n_1));
    }
  };
  protoOf(SystemSpeed).p1n = function () {
    if (this.l1n_1) {
      this.l1n_1 = false;
      _get_LOG__e5r759_7(Companion_getInstance_25()).ol('SystemSpeed resumed');
      this.j1n_1.eu(new SystemSpeedPauseEvent(this, this.l1n_1));
    }
  };
  function SystemSpeedEvent(source, oldSpeed, newSpeed) {
    this.q1n_1 = source;
    this.r1n_1 = oldSpeed;
    this.s1n_1 = newSpeed;
  }
  protoOf(SystemSpeedEvent).toString = function () {
    return 'SystemSpeedEvent(source=' + toString(this.q1n_1) + ', oldSpeed=' + this.r1n_1 + ', newSpeed=' + this.s1n_1 + ')';
  };
  protoOf(SystemSpeedEvent).hashCode = function () {
    var result = hashCode(this.q1n_1);
    result = imul(result, 31) + this.r1n_1 | 0;
    result = imul(result, 31) + this.s1n_1 | 0;
    return result;
  };
  protoOf(SystemSpeedEvent).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof SystemSpeedEvent))
      return false;
    if (!equals(this.q1n_1, other.q1n_1))
      return false;
    if (!(this.r1n_1 === other.r1n_1))
      return false;
    if (!(this.s1n_1 === other.s1n_1))
      return false;
    return true;
  };
  function SystemSpeedPauseEvent(source, isPaused) {
    this.t1n_1 = source;
    this.u1n_1 = isPaused;
  }
  protoOf(SystemSpeedPauseEvent).toString = function () {
    return 'SystemSpeedPauseEvent(source=' + toString(this.t1n_1) + ', isPaused=' + this.u1n_1 + ')';
  };
  protoOf(SystemSpeedPauseEvent).hashCode = function () {
    var result = hashCode(this.t1n_1);
    result = imul(result, 31) + getBooleanHashCode(this.u1n_1) | 0;
    return result;
  };
  protoOf(SystemSpeedPauseEvent).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof SystemSpeedPauseEvent))
      return false;
    if (!equals(this.t1n_1, other.t1n_1))
      return false;
    if (!(this.u1n_1 === other.u1n_1))
      return false;
    return true;
  };
  function Companion_26() {
    Companion_instance_26 = this;
    this.v1n_1 = logger(getKClass(ControlledTimeService));
    this.w1n_1 = 'time';
  }
  var Companion_instance_26;
  function Companion_getInstance_26() {
    if (Companion_instance_26 == null)
      new Companion_26();
    return Companion_instance_26;
  }
  function ControlledTimeService() {
    Companion_getInstance_26();
    this.x1n_1 = new PropertyChangeSupport(this);
    this.y1n_1 = 0n;
  }
  protoOf(ControlledTimeService).mp = function () {
    return this.y1n_1;
  };
  function Timer() {
  }
  function DisplayDuration() {
    this.z1n_1 = 2000;
    this.a1o_1 = 15;
  }
  protoOf(DisplayDuration).b1o = function (text) {
    // Inline function 'kotlin.math.max' call
    var b = imul(text.length / 15 | 0, 1000);
    return Math.max(2000, b);
  };
  var DisplayDuration_instance;
  function DisplayDuration_getInstance() {
    return DisplayDuration_instance;
  }
  function AbstractUIController() {
    this.c1o_1 = null;
  }
  protoOf(AbstractUIController).d1o = function (value) {
    this.c1o_1 = value;
    this.e1o();
  };
  protoOf(AbstractUIController).f1o = function () {
    var tmp0_elvis_lhs = this.c1o_1;
    var tmp;
    if (tmp0_elvis_lhs == null) {
      throw IllegalStateException_init_$Create$('access to uninitialized view property');
    } else {
      tmp = tmp0_elvis_lhs;
    }
    return tmp;
  };
  protoOf(AbstractUIController).e1o = function () {
  };
  function UI() {
    this.g1o_1 = false;
  }
  var UI_instance;
  function UI_getInstance() {
    return UI_instance;
  }
  //region block: post-declaration
  protoOf(Path2DJs).mo = quadTo;
  protoOf(Path2DJs).no = contains_1;
  protoOf(Path2DJs).oo = contains_2;
  protoOf(Path2DJs).po = intersects;
  protoOf(RealTimeTimerJs).up = initialize$default;
  protoOf(AbstractAction).uq = get_requestFocusOnClick;
  defineProp(protoOf(AbstractAction), 'opensDialog', function () {
    return this.tq();
  });
  defineProp(protoOf(AbstractAction), 'name', function () {
    return this.m2();
  }, function (value) {
    this.iq(value);
  });
  defineProp(protoOf(AbstractAction), 'description', function () {
    return this.kq();
  }, function (value) {
    this.jq(value);
  });
  defineProp(protoOf(AbstractAction), 'accelerator', function () {
    return this.mq();
  }, function (value) {
    this.lq(value);
  });
  defineProp(protoOf(AbstractAction), 'enabled', function () {
    return this.oq();
  }, function (value) {
    this.nq(value);
  });
  defineProp(protoOf(AbstractAction), 'selected', function () {
    return this.qq();
  }, function (value) {
    this.pq(value);
  });
  defineProp(protoOf(AbstractAction), 'imagePath', function () {
    return this.sq();
  }, function (value) {
    this.rq(value);
  });
  defineProp(protoOf(AbstractAction), 'requestFocusOnClick', function () {
    return this.uq();
  });
  protoOf(StoringActivationRecord).zw = getValue$default;
  protoOf(StoringActivationRecord).dx = getOptionalValue$default;
  protoOf(ScopedSymbolTable).c13 = hasSymbol$default;
  protoOf(ScopedSymbolTable).w12 = lookup$default;
  protoOf(ActionEvent).d17 = get_isAltDown;
  protoOf(ActionEvent).e17 = get_isControlDown;
  protoOf(ActionEvent).f17 = get_isShiftDown;
  protoOf(ActionEvent).g17 = get_isCtrlDown;
  protoOf(ActionEvent).h17 = get_isAltGraphDown;
  protoOf(ActionEvent).i17 = get_isMetaDown;
  protoOf(ActionEvent).hasModifier = hasModifier;
  defineProp(protoOf(ActionEvent), 'event', function () {
    return this.y16();
  });
  defineProp(protoOf(ActionEvent), 'source', function () {
    return this.z16();
  });
  defineProp(protoOf(ActionEvent), 'modifiers', function () {
    return this.a17();
  });
  defineProp(protoOf(ActionEvent), 'isAltDown', function () {
    return this.d17();
  });
  defineProp(protoOf(ActionEvent), 'isControlDown', function () {
    return this.e17();
  });
  defineProp(protoOf(ActionEvent), 'isShiftDown', function () {
    return this.f17();
  });
  defineProp(protoOf(ActionEvent), 'isCtrlDown', function () {
    return this.g17();
  });
  defineProp(protoOf(ActionEvent), 'isAltGraphDown', function () {
    return this.h17();
  });
  defineProp(protoOf(ActionEvent), 'isMetaDown', function () {
    return this.i17();
  });
  protoOf(EventBusImpl).n17 = postVetoable$default;
  protoOf(EventBusImpl).p17 = postTwoPhase$default;
  defineProp(protoOf(Modifier), 'name', protoOf(Modifier).m2);
  defineProp(protoOf(Modifier), 'ordinal', protoOf(Modifier).n2);
  protoOf(KeyEventImpl).d17 = get_isAltDown;
  protoOf(KeyEventImpl).e17 = get_isControlDown;
  protoOf(KeyEventImpl).f17 = get_isShiftDown;
  protoOf(KeyEventImpl).g17 = get_isCtrlDown;
  protoOf(KeyEventImpl).h17 = get_isAltGraphDown;
  protoOf(KeyEventImpl).i17 = get_isMetaDown;
  protoOf(KeyEventImpl).hasModifier = hasModifier;
  defineProp(protoOf(KeyEventImpl), 'event', function () {
    return this.y16();
  });
  defineProp(protoOf(KeyEventImpl), 'source', function () {
    return this.z16();
  });
  defineProp(protoOf(KeyEventImpl), 'modifiers', function () {
    return this.a17();
  });
  defineProp(protoOf(KeyEventImpl), 'isAltDown', function () {
    return this.d17();
  });
  defineProp(protoOf(KeyEventImpl), 'isControlDown', function () {
    return this.e17();
  });
  defineProp(protoOf(KeyEventImpl), 'isShiftDown', function () {
    return this.f17();
  });
  defineProp(protoOf(KeyEventImpl), 'isCtrlDown', function () {
    return this.g17();
  });
  defineProp(protoOf(KeyEventImpl), 'isAltGraphDown', function () {
    return this.h17();
  });
  defineProp(protoOf(KeyEventImpl), 'isMetaDown', function () {
    return this.i17();
  });
  protoOf(MouseEventImpl).hw = get_location;
  protoOf(MouseEventImpl).d17 = get_isAltDown;
  protoOf(MouseEventImpl).e17 = get_isControlDown;
  protoOf(MouseEventImpl).f17 = get_isShiftDown;
  protoOf(MouseEventImpl).g17 = get_isCtrlDown;
  protoOf(MouseEventImpl).h17 = get_isAltGraphDown;
  protoOf(MouseEventImpl).i17 = get_isMetaDown;
  protoOf(MouseEventImpl).hasModifier = hasModifier;
  defineProp(protoOf(MouseEventImpl), 'event', function () {
    return this.y16();
  });
  defineProp(protoOf(MouseEventImpl), 'source', function () {
    return this.z16();
  });
  defineProp(protoOf(MouseEventImpl), 'modifiers', function () {
    return this.a17();
  });
  defineProp(protoOf(MouseEventImpl), 'isAltDown', function () {
    return this.d17();
  });
  defineProp(protoOf(MouseEventImpl), 'isControlDown', function () {
    return this.e17();
  });
  defineProp(protoOf(MouseEventImpl), 'isShiftDown', function () {
    return this.f17();
  });
  defineProp(protoOf(MouseEventImpl), 'isCtrlDown', function () {
    return this.g17();
  });
  defineProp(protoOf(MouseEventImpl), 'isAltGraphDown', function () {
    return this.h17();
  });
  defineProp(protoOf(MouseEventImpl), 'isMetaDown', function () {
    return this.i17();
  });
  protoOf(AbstractRectangularShape).v1b = moveBy;
  protoOf(AbstractRectangularShape).w1b = setFrame;
  protoOf(AbstractRectangularShape).tn = add_0;
  protoOf(AbstractRectangularShape).co = add_1;
  protoOf(AbstractRectangularShape).x1b = add_2;
  protoOf(AbstractRectangularShape).y1b = expandBy;
  protoOf(AbstractRectangularShape).z1b = expandBy_0;
  protoOf(AbstractRectangularShape).a1c = expandBy_1;
  protoOf(AbstractRectangularShape).b1c = expandLeftBy;
  protoOf(AbstractRectangularShape).eo = contains_3;
  protoOf(AbstractRectangularShape).fo = contains_4;
  protoOf(AbstractRectangularShape).no = contains_1;
  protoOf(AbstractRectangularShape).oo = contains_2;
  protoOf(AbstractRectangularShape).c1c = get_xInt;
  protoOf(AbstractRectangularShape).d1c = get_yInt;
  protoOf(AbstractRectangularShape).e1c = get_widthInt;
  protoOf(AbstractRectangularShape).f1c = get_heightInt;
  protoOf(AbstractRectangularShape).g1c = get_isInitial;
  protoOf(AbstractRectangularShape).ov = get_isEmpty;
  protoOf(AbstractRectangularShape).h1c = get_centerX;
  protoOf(AbstractRectangularShape).i1c = get_centerY;
  protoOf(AbstractRectangularShape).j1c = get_minX;
  protoOf(AbstractRectangularShape).k1c = get_minY;
  protoOf(AbstractRectangularShape).l1c = get_maxX;
  protoOf(AbstractRectangularShape).m1c = get_maxY;
  protoOf(AbstractRectangularShape).n1c = get_center;
  protoOf(AbstractRectangularShape).o1c = get_topLeft;
  protoOf(AbstractRectangularShape).p1c = get_bottomCenter;
  protoOf(AbstractRectangularShape).q1c = get_centerLeft;
  protoOf(AbstractRectangularShape).r1c = get_centerRight;
  protoOf(AbstractRectangularShape).po = intersects;
  protoOf(AffineTransformImpl).t1c = get_uniformScale;
  protoOf(AffineTransformImpl).w1c = translate;
  //endregion
  //region block: init
  TranslationsOutlet_instance = new TranslationsOutlet();
  SoundClipFactory_instance = new SoundClipFactory();
  SoundClipJs_instance = new SoundClipJs();
  ToneFactory_instance = new ToneFactory();
  ActionProperty_instance = new ActionProperty();
  Companion_instance_0 = new Companion_0();
  Companion_instance_1 = new Companion_1();
  UninitializedValue_instance = new UninitializedValue();
  Companion_instance_4 = new Companion_4();
  TopologicalSort_instance = new TopologicalSort();
  Dsl_instance = new Dsl();
  Companion_instance_10 = new Companion_10();
  Companion_instance_11 = new Companion_11();
  Geometry_instance = new Geometry();
  Companion_instance_15 = new Companion_15();
  Companion_instance_16 = new Companion_16();
  Companion_instance_20 = new Companion_20();
  Companion_instance_21 = new Companion_21();
  SoundEffects_instance = new SoundEffects();
  Companion_instance_23 = new Companion_23();
  DisplayDuration_instance = new DisplayDuration();
  UI_instance = new UI();
  //endregion
  //region block: exports
  function $jsExportAll$(_) {
    var io = _.io || (_.io = {});
    var antarescircuit = io.antarescircuit || (io.antarescircuit = {});
    var jabbah = antarescircuit.jabbah || (antarescircuit.jabbah = {});
    var base = jabbah.base || (jabbah.base = {});
    defineProp(base, 'TranslationsOutlet', TranslationsOutlet_getInstance, VOID, true);
    var io_0 = _.io || (_.io = {});
    var antarescircuit_0 = io_0.antarescircuit || (io_0.antarescircuit = {});
    var jabbah_0 = antarescircuit_0.jabbah || (antarescircuit_0.jabbah = {});
    var base_0 = jabbah_0.base || (jabbah_0.base = {});
    var event = base_0.event || (base_0.event = {});
    var io_1 = _.io || (_.io = {});
    var antarescircuit_1 = io_1.antarescircuit || (io_1.antarescircuit = {});
    var jabbah_1 = antarescircuit_1.jabbah || (antarescircuit_1.jabbah = {});
    var base_1 = jabbah_1.base || (jabbah_1.base = {});
    var event_0 = base_1.event || (base_1.event = {});
    event_0.mpListener = mpListener;
    var io_2 = _.io || (_.io = {});
    var antarescircuit_2 = io_2.antarescircuit || (io_2.antarescircuit = {});
    var jabbah_2 = antarescircuit_2.jabbah || (antarescircuit_2.jabbah = {});
    var base_2 = jabbah_2.base || (jabbah_2.base = {});
    defineProp(base_2, 'ActionProperty', ActionProperty_getInstance, VOID, true);
    var io_3 = _.io || (_.io = {});
    var antarescircuit_3 = io_3.antarescircuit || (io_3.antarescircuit = {});
    var jabbah_3 = antarescircuit_3.jabbah || (antarescircuit_3.jabbah = {});
    var base_3 = jabbah_3.base || (jabbah_3.base = {});
    base_3.UUID = UUID;
    var io_4 = _.io || (_.io = {});
    var antarescircuit_4 = io_4.antarescircuit || (io_4.antarescircuit = {});
    var jabbah_4 = antarescircuit_4.jabbah || (antarescircuit_4.jabbah = {});
    var base_4 = jabbah_4.base || (jabbah_4.base = {});
    var event_1 = base_4.event || (base_4.event = {});
    event_1.ActionEvent = ActionEvent;
    var io_5 = _.io || (_.io = {});
    var antarescircuit_5 = io_5.antarescircuit || (io_5.antarescircuit = {});
    var jabbah_5 = antarescircuit_5.jabbah || (antarescircuit_5.jabbah = {});
    var base_5 = jabbah_5.base || (jabbah_5.base = {});
    var event_2 = base_5.event || (base_5.event = {});
    event_2.Modifier = Modifier;
    event_2.Modifier.values = values_0;
    event_2.Modifier.valueOf = valueOf;
    defineProp(event_2.Modifier, 'Shift', Modifier_Shift_getInstance, VOID, true);
    defineProp(event_2.Modifier, 'Ctrl', Modifier_Ctrl_getInstance, VOID, true);
    defineProp(event_2.Modifier, 'Meta', Modifier_Meta_getInstance, VOID, true);
    defineProp(event_2.Modifier, 'Alt', Modifier_Alt_getInstance, VOID, true);
    defineProp(event_2.Modifier, 'AltGraph', Modifier_AltGraph_getInstance, VOID, true);
    var io_6 = _.io || (_.io = {});
    var antarescircuit_6 = io_6.antarescircuit || (io_6.antarescircuit = {});
    var jabbah_6 = antarescircuit_6.jabbah || (antarescircuit_6.jabbah = {});
    var base_6 = jabbah_6.base || (jabbah_6.base = {});
    var event_3 = base_6.event || (base_6.event = {});
    event_3.PropertyChangeEvent = PropertyChangeEvent;
  }
  $jsExportAll$(_);
  _.$jsExportAll$ = $jsExportAll$;
  _.$_$ = _.$_$ || {};
  _.$_$.a = Companion_instance_4;
  _.$_$.b = TopologicalSort_instance;
  _.$_$.c = Companion_getInstance_5;
  _.$_$.d = Dsl_instance;
  _.$_$.e = Companion_instance_10;
  _.$_$.f = Companion_getInstance_13;
  _.$_$.g = Geometry_instance;
  _.$_$.h = Companion_getInstance_14;
  _.$_$.i = Companion_instance_15;
  _.$_$.j = Companion_instance_16;
  _.$_$.k = HelpSourceRegistry_getInstance;
  _.$_$.l = Companion_getInstance_17;
  _.$_$.m = BaseModuleJs_getInstance;
  _.$_$.n = BaseModule_getInstance;
  _.$_$.o = Companion_getInstance_18;
  _.$_$.p = Companion_instance_21;
  _.$_$.q = Companion_instance_20;
  _.$_$.r = SoundClipFactory_instance;
  _.$_$.s = SoundEffects_instance;
  _.$_$.t = ToneFactory_instance;
  _.$_$.u = Companion_instance_23;
  _.$_$.v = DisplayDuration_instance;
  _.$_$.w = UI_instance;
  _.$_$.x = Companion_getInstance_3;
  _.$_$.y = LogSystem_getInstance;
  _.$_$.z = Companion_getInstance_2;
  _.$_$.a1 = Status_getInstance;
  _.$_$.b1 = StringUtils_getInstance;
  _.$_$.c1 = System_getInstance;
  _.$_$.d1 = Translations_getInstance;
  _.$_$.e1 = BaseTokenType_ID_getInstance;
  _.$_$.f1 = BaseTokenType_LITERAL_getInstance;
  _.$_$.g1 = DslTokenType_AND_getInstance;
  _.$_$.h1 = DslTokenType_ASSIGN_getInstance;
  _.$_$.i1 = DslTokenType_AT_getInstance;
  _.$_$.j1 = DslTokenType_CARET_getInstance;
  _.$_$.k1 = DslTokenType_COLON_getInstance;
  _.$_$.l1 = DslTokenType_DIVIDE_getInstance;
  _.$_$.m1 = DslTokenType_DOLLAR_getInstance;
  _.$_$.n1 = DslTokenType_EQUAL_getInstance;
  _.$_$.o1 = DslTokenType_GREATER_getInstance;
  _.$_$.p1 = DslTokenType_HASH_getInstance;
  _.$_$.q1 = DslTokenType_INIT_getInstance;
  _.$_$.r1 = DslTokenType_MINUS_getInstance;
  _.$_$.s1 = DslTokenType_MOD_getInstance;
  _.$_$.t1 = DslTokenType_MULTIPLY_getInstance;
  _.$_$.u1 = DslTokenType_OR_getInstance;
  _.$_$.v1 = DslTokenType_PLUS_getInstance;
  _.$_$.w1 = DslTokenType_SHIFT_LEFT_getInstance;
  _.$_$.x1 = DslTokenType_SHIFT_RIGHT_getInstance;
  _.$_$.y1 = DslTokenType_SMALLER_getInstance;
  _.$_$.z1 = Button_BUTTON1_getInstance;
  _.$_$.a2 = Button_BUTTON2_getInstance;
  _.$_$.b2 = Button_BUTTON3_getInstance;
  _.$_$.c2 = Button_NONE_getInstance;
  _.$_$.d2 = KeyEventType_PRESSED_getInstance;
  _.$_$.e2 = KeyEventType_RELEASED_getInstance;
  _.$_$.f2 = KeyEventType_TYPED_getInstance;
  _.$_$.g2 = Modifier_Alt_getInstance;
  _.$_$.h2 = Modifier_Ctrl_getInstance;
  _.$_$.i2 = Modifier_Meta_getInstance;
  _.$_$.j2 = Modifier_Shift_getInstance;
  _.$_$.k2 = MouseEventType_CLICKED_getInstance;
  _.$_$.l2 = MouseEventType_DRAGGED_getInstance;
  _.$_$.m2 = MouseEventType_ENTERED_getInstance;
  _.$_$.n2 = MouseEventType_EXITED_getInstance;
  _.$_$.o2 = MouseEventType_MOVED_getInstance;
  _.$_$.p2 = MouseEventType_PRESSED_getInstance;
  _.$_$.q2 = MouseEventType_RELEASED_getInstance;
  _.$_$.r2 = MouseEventType_UNKNOWN_getInstance;
  _.$_$.s2 = MouseEventType_WHEEL_ROTATED_getInstance;
  _.$_$.t2 = Direction_EAST_getInstance;
  _.$_$.u2 = Direction_NORTH_getInstance;
  _.$_$.v2 = Direction_SOUTH_getInstance;
  _.$_$.w2 = Direction_WEST_getInstance;
  _.$_$.x2 = Rotation_R0_getInstance;
  _.$_$.y2 = Rotation_R180_getInstance;
  _.$_$.z2 = Rotation_R90_getInstance;
  _.$_$.a3 = Turn_NONE_getInstance;
  _.$_$.b3 = WaveformType_Sine_getInstance;
  _.$_$.c3 = UnhandledEventBehaviour_Strict_getInstance;
  _.$_$.d3 = UnhandledEventBehaviour_Unhandled_getInstance;
  _.$_$.e3 = IssueSeverity_Error_getInstance;
  _.$_$.f3 = IssueSeverity_Warning_getInstance;
  _.$_$.g3 = LogLevel_Info_getInstance;
  _.$_$.h3 = StatusType_Small_getInstance;
  _.$_$.i3 = StatusType_Tool_getInstance;
  _.$_$.j3 = getOptionalValue$default;
  _.$_$.k3 = getValue$default;
  _.$_$.l3 = hasSymbol$default;
  _.$_$.m3 = lookup$default;
  _.$_$.n3 = AffineTransformImpl_init_$Create$_0;
  _.$_$.o3 = Dimension2D_init_$Create$;
  _.$_$.p3 = Ellipse2D_init_$Create$;
  _.$_$.q3 = Point2D_init_$Create$;
  _.$_$.r3 = Point2D_init_$Create$_0;
  _.$_$.s3 = Rectangle2D_init_$Create$_2;
  _.$_$.t3 = Rectangle2D_init_$Create$_0;
  _.$_$.u3 = Rectangle2D_init_$Create$;
  _.$_$.v3 = RoundRectangle2D_init_$Create$;
  _.$_$.w3 = Vector2D_init_$Create$;
  _.$_$.x3 = RichTextParser_init_$Create$;
  _.$_$.y3 = AbstractAction_init_$Init$;
  _.$_$.z3 = Tooltip_init_$Create$;
  _.$_$.a4 = DirectedGraph;
  _.$_$.b4 = EmptyIterator;
  _.$_$.c4 = ImmutableList;
  _.$_$.d4 = PriorityQueue;
  _.$_$.e4 = Stack;
  _.$_$.f4 = toImmutableList;
  _.$_$.g4 = AbstractNode;
  _.$_$.h4 = ActivationRecord;
  _.$_$.i4 = DslError;
  _.$_$.j4 = DslGlobalFunctions;
  _.$_$.k4 = DslLexer;
  _.$_$.l4 = DslParser;
  _.$_$.m4 = Visitor;
  _.$_$.n4 = DslSemanticAnalyser;
  _.$_$.o4 = ExternalFunctionSymbol;
  _.$_$.p4 = ExternalFunction;
  _.$_$.q4 = Interpreter;
  _.$_$.r4 = Memory;
  _.$_$.s4 = RuntimeError;
  _.$_$.t4 = ScopedSymbolTable;
  _.$_$.u4 = ScriptMetaData;
  _.$_$.v4 = SemanticError;
  _.$_$.w4 = StoringActivationRecord;
  _.$_$.x4 = SymbolTable;
  _.$_$.y4 = Symbol;
  _.$_$.z4 = SyntaxError;
  _.$_$.a5 = Variable;
  _.$_$.b5 = anyParam;
  _.$_$.c5 = longParam;
  _.$_$.d5 = stringParam;
  _.$_$.e5 = ActionListener;
  _.$_$.f5 = EventBusImpl;
  _.$_$.g5 = hasModifier;
  _.$_$.h5 = get_isAltDown;
  _.$_$.i5 = get_isAltGraphDown;
  _.$_$.j5 = get_isControlDown;
  _.$_$.k5 = get_isCtrlDown;
  _.$_$.l5 = get_isMetaDown;
  _.$_$.m5 = get_isShiftDown;
  _.$_$.n5 = InputEvent;
  _.$_$.o5 = KeyAdapter;
  _.$_$.p5 = KeyEventImpl;
  _.$_$.q5 = MouseAdapter;
  _.$_$.r5 = MouseEventImpl;
  _.$_$.s5 = MouseEvent;
  _.$_$.t5 = PropertyChangeListener;
  _.$_$.u5 = PropertyChangeSupport;
  _.$_$.v5 = PropertyOwnerImpl;
  _.$_$.w5 = VetoException;
  _.$_$.x5 = AbstractRectangularShape;
  _.$_$.y5 = AffineTransformImpl;
  _.$_$.z5 = Dimension2D;
  _.$_$.a6 = values_1;
  _.$_$.b6 = Ellipse2D;
  _.$_$.c6 = MutableRectangularShape;
  _.$_$.d6 = Path2DJs;
  _.$_$.e6 = Point2D;
  _.$_$.f6 = Rectangle2D;
  _.$_$.g6 = RectangularShape;
  _.$_$.h6 = Ring2D;
  _.$_$.i6 = RoundRectangle2D;
  _.$_$.j6 = contains_1;
  _.$_$.k6 = contains_2;
  _.$_$.l6 = intersects;
  _.$_$.m6 = Shape;
  _.$_$.n6 = Vector2D;
  _.$_$.o6 = HelpId;
  _.$_$.p6 = HelpSource;
  _.$_$.q6 = formatRounded;
  _.$_$.r6 = interpolate;
  _.$_$.s6 = near;
  _.$_$.t6 = Token;
  _.$_$.u6 = ToneParams;
  _.$_$.v6 = stateMachine;
  _.$_$.w6 = ControlledTimeService;
  _.$_$.x6 = SystemSpeedEvent;
  _.$_$.y6 = SystemSpeedPauseEvent;
  _.$_$.z6 = SystemSpeed;
  _.$_$.a7 = AbstractUIController;
  _.$_$.b7 = Throttle;
  _.$_$.c7 = AbstractAction;
  _.$_$.d7 = AbstractModule;
  _.$_$.e7 = Action;
  _.$_$.f7 = Disposable;
  _.$_$.g7 = EmptyHierarchyVisitor;
  _.$_$.h7 = IssueImpl;
  _.$_$.i7 = LongValueImpl;
  _.$_$.j7 = LongValue;
  _.$_$.k7 = PreferencesChangedEvent;
  _.$_$.l7 = PropertiesProxy;
  _.$_$.m7 = Properties;
  _.$_$.n7 = Tooltip;
  _.$_$.o7 = TranslationServiceJsImpl;
  _.$_$.p7 = UUID;
  _.$_$.q7 = logger;
  _.$_$.r7 = resettableLazy;
  //endregion
  return _;
}));

//# sourceMappingURL=jabbah-base.js.map
