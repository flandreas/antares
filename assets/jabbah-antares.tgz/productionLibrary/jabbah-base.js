(function (factory) {
  if (typeof define === 'function' && define.amd)
    define(['exports', './kotlin-kotlin-stdlib.js'], factory);
  else if (typeof exports === 'object')
    factory(module.exports, require('./kotlin-kotlin-stdlib.js'));
  else {
    if (typeof globalThis['kotlin-kotlin-stdlib'] === 'undefined') {
      throw new Error("Error loading module 'jabbah-base'. Its dependency 'kotlin-kotlin-stdlib' was not found. Please, check whether 'kotlin-kotlin-stdlib' is loaded prior to 'jabbah-base'.");
    }
    globalThis['jabbah-base'] = factory(typeof globalThis['jabbah-base'] === 'undefined' ? {} : globalThis['jabbah-base'], globalThis['kotlin-kotlin-stdlib']);
  }
}(function (_, kotlin_kotlin) {
  'use strict';
  //region block: imports
  var imul = Math.imul;
  var log2 = Math.log2;
  var sign = Math.sign;
  var VOID = kotlin_kotlin.$_$.b;
  var protoOf = kotlin_kotlin.$_$.t7;
  var Unit_instance = kotlin_kotlin.$_$.i;
  var initMetadataForClass = kotlin_kotlin.$_$.d7;
  var LinkedHashMap_init_$Create$ = kotlin_kotlin.$_$.q;
  var lazy = kotlin_kotlin.$_$.qb;
  var initMetadataForObject = kotlin_kotlin.$_$.i7;
  var numberToLong = kotlin_kotlin.$_$.e6;
  var ensureNotNull = kotlin_kotlin.$_$.mb;
  var getKClassFromExpression = kotlin_kotlin.$_$.r8;
  var get_js = kotlin_kotlin.$_$.n7;
  var Default_getInstance = kotlin_kotlin.$_$.f;
  var KProperty1 = kotlin_kotlin.$_$.v8;
  var getPropertyCallableRef = kotlin_kotlin.$_$.a7;
  var getKClass = kotlin_kotlin.$_$.s8;
  var initMetadataForCompanion = kotlin_kotlin.$_$.e7;
  var emptyMap = kotlin_kotlin.$_$.d3;
  var ArrayList_init_$Create$ = kotlin_kotlin.$_$.n;
  var toString = kotlin_kotlin.$_$.v7;
  var replace = kotlin_kotlin.$_$.v9;
  var defineProp = kotlin_kotlin.$_$.t6;
  var THROW_CCE = kotlin_kotlin.$_$.fb;
  var hashCode = kotlin_kotlin.$_$.c7;
  var equals = kotlin_kotlin.$_$.u6;
  var UnsupportedOperationException_init_$Create$ = kotlin_kotlin.$_$.m1;
  var multiply = kotlin_kotlin.$_$.c6;
  var IllegalStateException_init_$Create$ = kotlin_kotlin.$_$.d1;
  var initMetadataForInterface = kotlin_kotlin.$_$.g7;
  var ObservableProperty = kotlin_kotlin.$_$.a8;
  var Delegates_instance = kotlin_kotlin.$_$.e;
  var KMutableProperty1 = kotlin_kotlin.$_$.t8;
  var Enum = kotlin_kotlin.$_$.xa;
  var noWhenBranchMatchedException = kotlin_kotlin.$_$.rb;
  var toString_0 = kotlin_kotlin.$_$.tb;
  var getStringHashCode = kotlin_kotlin.$_$.b7;
  var getBigIntHashCode = kotlin_kotlin.$_$.w6;
  var getBooleanHashCode = kotlin_kotlin.$_$.x6;
  var toInt = kotlin_kotlin.$_$.ka;
  var toDouble = kotlin_kotlin.$_$.ia;
  var NoSuchElementException_init_$Create$ = kotlin_kotlin.$_$.h1;
  var _Char___init__impl__6a9atx = kotlin_kotlin.$_$.n1;
  var isBlank = kotlin_kotlin.$_$.l9;
  var charSequenceLength = kotlin_kotlin.$_$.r6;
  var StringBuilder_init_$Create$ = kotlin_kotlin.$_$.v;
  var isCharSequence = kotlin_kotlin.$_$.k7;
  var reversed = kotlin_kotlin.$_$.x9;
  var charCodeAt = kotlin_kotlin.$_$.p6;
  var Char = kotlin_kotlin.$_$.ua;
  var joinToString = kotlin_kotlin.$_$.o3;
  var emptyList = kotlin_kotlin.$_$.c3;
  var dropLast = kotlin_kotlin.$_$.d9;
  var toString_1 = kotlin_kotlin.$_$.q1;
  var last = kotlin_kotlin.$_$.q9;
  var charArrayOf = kotlin_kotlin.$_$.o6;
  var split = kotlin_kotlin.$_$.y9;
  var collectionSizeOrDefault = kotlin_kotlin.$_$.s2;
  var ArrayList_init_$Create$_0 = kotlin_kotlin.$_$.m;
  var replace_0 = kotlin_kotlin.$_$.w9;
  var take = kotlin_kotlin.$_$.ha;
  var charSequenceGet = kotlin_kotlin.$_$.q6;
  var isWhitespace = kotlin_kotlin.$_$.p9;
  var objectCreate = kotlin_kotlin.$_$.s7;
  var IllegalArgumentException_init_$Create$ = kotlin_kotlin.$_$.b1;
  var KtList = kotlin_kotlin.$_$.h2;
  var KtSet = kotlin_kotlin.$_$.l2;
  var LinkedHashSet_init_$Create$ = kotlin_kotlin.$_$.r;
  var sort = kotlin_kotlin.$_$.o4;
  var last_0 = kotlin_kotlin.$_$.r3;
  var isInterface = kotlin_kotlin.$_$.m7;
  var extendThrowable = kotlin_kotlin.$_$.v6;
  var captureStack = kotlin_kotlin.$_$.n6;
  var Exception = kotlin_kotlin.$_$.za;
  var isLetterOrDigit = kotlin_kotlin.$_$.n9;
  var isLetter = kotlin_kotlin.$_$.o9;
  var isDigit = kotlin_kotlin.$_$.m9;
  var toLong = kotlin_kotlin.$_$.ma;
  var NumberFormatException = kotlin_kotlin.$_$.db;
  var toNumber = kotlin_kotlin.$_$.j6;
  var FunctionAdapter = kotlin_kotlin.$_$.k6;
  var to = kotlin_kotlin.$_$.vb;
  var mapOf = kotlin_kotlin.$_$.v3;
  var setOf = kotlin_kotlin.$_$.k4;
  var plus = kotlin_kotlin.$_$.b4;
  var mutableListOf = kotlin_kotlin.$_$.y3;
  var lastOrNull = kotlin_kotlin.$_$.q3;
  var removeLast = kotlin_kotlin.$_$.g4;
  var contains = kotlin_kotlin.$_$.t2;
  var add = kotlin_kotlin.$_$.w5;
  var Collection = kotlin_kotlin.$_$.g2;
  var subtract = kotlin_kotlin.$_$.i6;
  var divide = kotlin_kotlin.$_$.z5;
  var convertToInt = kotlin_kotlin.$_$.y5;
  var shiftLeft = kotlin_kotlin.$_$.f6;
  var shiftRight = kotlin_kotlin.$_$.h6;
  var modulo = kotlin_kotlin.$_$.b6;
  var negate = kotlin_kotlin.$_$.d6;
  var KtMutableMap = kotlin_kotlin.$_$.k2;
  var mutableMapOf = kotlin_kotlin.$_$.z3;
  var KtMap = kotlin_kotlin.$_$.i2;
  var _ULong___init__impl__c78o9k = kotlin_kotlin.$_$.w1;
  var ULong = kotlin_kotlin.$_$.hb;
  var throwUninitializedPropertyAccessException = kotlin_kotlin.$_$.t5;
  var MutableCollection = kotlin_kotlin.$_$.j2;
  var toList = kotlin_kotlin.$_$.s4;
  var THROW_IAE = kotlin_kotlin.$_$.gb;
  var Char__hashCode_impl_otmys = kotlin_kotlin.$_$.o1;
  var getNumberHashCode = kotlin_kotlin.$_$.y6;
  var numberToInt = kotlin_kotlin.$_$.r7;
  var abs = kotlin_kotlin.$_$.w7;
  var rangeTo = kotlin_kotlin.$_$.n8;
  var contains_0 = kotlin_kotlin.$_$.b9;
  var roundToInt = kotlin_kotlin.$_$.y7;
  var first = kotlin_kotlin.$_$.j9;
  var listOf = kotlin_kotlin.$_$.t3;
  var listOf_0 = kotlin_kotlin.$_$.s3;
  var compareTo = kotlin_kotlin.$_$.s6;
  var numberRangeToNumber = kotlin_kotlin.$_$.o7;
  var checkIndexOverflow = kotlin_kotlin.$_$.r2;
  var first_0 = kotlin_kotlin.$_$.h3;
  var lines = kotlin_kotlin.$_$.r9;
  var startsWith = kotlin_kotlin.$_$.ba;
  var trim = kotlin_kotlin.$_$.sa;
  var removeSuffix = kotlin_kotlin.$_$.t9;
  var endsWith = kotlin_kotlin.$_$.g9;
  //endregion
  //region block: pre-declaration
  initMetadataForClass(Logger, 'Logger', Logger);
  initMetadataForObject(LogSystem, 'LogSystem');
  initMetadataForObject(System, 'System');
  initMetadataForCompanion(Companion);
  initMetadataForClass(TranslationServiceJsImpl, 'TranslationServiceJsImpl');
  initMetadataForObject(Translations, 'Translations');
  initMetadataForObject(TranslationsOutlet, 'TranslationsOutlet');
  initMetadataForInterface(PropertyChangeListener, 'PropertyChangeListener');
  initMetadataForClass(mpListener$1, VOID, VOID, VOID, [PropertyChangeListener]);
  initMetadataForClass(MoveTo, 'MoveTo');
  initMetadataForClass(LineTo, 'LineTo');
  initMetadataForClass(QuadTo, 'QuadTo');
  initMetadataForClass(CurveTo, 'CurveTo');
  initMetadataForClass(ClosePath, 'ClosePath', ClosePath);
  initMetadataForClass(Entry, 'Entry');
  function contains_1(p) {
    return this.go(p.kn_1, p.ln_1);
  }
  function contains_2(rect) {
    return this.ho(rect.p1a(), rect.q1a(), rect.f1c(), rect.h1c());
  }
  function intersects(rect) {
    return this.io(rect.p1a(), rect.q1a(), rect.f1c(), rect.h1c());
  }
  initMetadataForInterface(Shape, 'Shape');
  function moveTo(x, y) {
    return this.un(x, y);
  }
  function moveTo_0(x, y) {
    return this.un(x, y);
  }
  function lineTo(x, y) {
    return this.yn(x, y);
  }
  function lineTo_0(x, y) {
    return this.yn(x, y);
  }
  function quadTo(x1, y1, x2, y2) {
    return this.bo(x1, y1, x2, y2);
  }
  initMetadataForInterface(Path, 'Path', VOID, VOID, [Shape]);
  initMetadataForClass(Path2DJs, 'Path2DJs', Path2DJs, VOID, [Path]);
  initMetadataForClass(InvocationHandler, 'InvocationHandler');
  initMetadataForClass(InvocationHandlerJs, 'InvocationHandlerJs', InvocationHandlerJs, InvocationHandler);
  initMetadataForClass(AbstractModule, 'AbstractModule');
  initMetadataForObject(BaseModuleJs, 'BaseModuleJs', VOID, AbstractModule);
  initMetadataForObject(SoundClipFactory, 'SoundClipFactory');
  initMetadataForObject(SoundClipJs, 'SoundClipJs');
  initMetadataForObject(ToneFactory, 'ToneFactory');
  initMetadataForClass(RealTimeServiceJs, 'RealTimeServiceJs', RealTimeServiceJs);
  function initialize$default(interval, repeats, handler, $super) {
    repeats = repeats === VOID ? true : repeats;
    return $super === VOID ? this.vp(interval, repeats, handler) : $super.vp.call(this, interval, repeats, handler);
  }
  initMetadataForInterface(Timer, 'Timer');
  initMetadataForClass(RealTimeTimerJs, 'RealTimeTimerJs', RealTimeTimerJs, VOID, [Timer]);
  initMetadataForClass(Throttle, 'Throttle');
  initMetadataForObject(ActionProperty, 'ActionProperty');
  function get_opensDialog() {
    return false;
  }
  function get_requestFocusOnClick() {
    return false;
  }
  initMetadataForInterface(Action, 'Action');
  initMetadataForCompanion(Companion_0);
  initMetadataForClass(AbstractAction$name$$inlined$observable$1, VOID, VOID, ObservableProperty);
  initMetadataForClass(AbstractAction$description$$inlined$observable$1, VOID, VOID, ObservableProperty);
  initMetadataForClass(AbstractAction$accelerator$$inlined$observable$1, VOID, VOID, ObservableProperty);
  initMetadataForClass(AbstractAction$enabled$$inlined$observable$1, VOID, VOID, ObservableProperty);
  initMetadataForClass(AbstractAction$selected$$inlined$observable$1, VOID, VOID, ObservableProperty);
  initMetadataForClass(AbstractAction$imagePath$$inlined$observable$1, VOID, VOID, ObservableProperty);
  initMetadataForClass(AbstractAction, 'AbstractAction', VOID, VOID, [Action]);
  initMetadataForCompanion(Companion_1);
  initMetadataForClass(DataLocation, 'DataLocation', VOID, Enum);
  initMetadataForInterface(Disposable, 'Disposable');
  initMetadataForClass(EmptyHierarchyVisitor, 'EmptyHierarchyVisitor', EmptyHierarchyVisitor);
  initMetadataForClass(IssueImpl, 'IssueImpl');
  initMetadataForClass(IssueSeverity, 'IssueSeverity', VOID, Enum);
  initMetadataForClass(LogLevel, 'LogLevel', VOID, Enum);
  initMetadataForCompanion(Companion_2);
  initMetadataForInterface(LongValue, 'LongValue');
  initMetadataForClass(LongValueImpl, 'LongValueImpl', VOID, VOID, [LongValue]);
  initMetadataForClass(Entry_0, 'Entry');
  initMetadataForClass(Properties, 'Properties', Properties);
  initMetadataForClass(PropertiesProxy, 'PropertiesProxy', VOID, Properties);
  initMetadataForClass(PreferencesChangedEvent, 'PreferencesChangedEvent');
  initMetadataForClass(Settings, 'Settings', Settings);
  initMetadataForClass(ResettableLazy, 'ResettableLazy');
  initMetadataForObject(UninitializedValue, 'UninitializedValue');
  initMetadataForObject(Status, 'Status');
  initMetadataForClass(StatusType, 'StatusType', VOID, Enum);
  initMetadataForClass(StatusEvent, 'StatusEvent');
  initMetadataForObject(StringUtils, 'StringUtils');
  initMetadataForClass(Tooltip, 'Tooltip');
  initMetadataForCompanion(Companion_3);
  initMetadataForClass(Language, 'Language', VOID, Enum);
  initMetadataForClass(UUID, 'UUID');
  initMetadataForClass(ImmutableList, 'ImmutableList', VOID, VOID, [KtList]);
  initMetadataForClass(EmptyIterator, 'EmptyIterator', EmptyIterator);
  initMetadataForClass(ImmutableSet, 'ImmutableSet', VOID, VOID, [KtSet]);
  initMetadataForClass(DirectedGraph, 'DirectedGraph', DirectedGraph);
  initMetadataForCompanion(Companion_4);
  initMetadataForClass(Pair, 'Pair');
  initMetadataForClass(PriorityQueue, 'PriorityQueue', PriorityQueue);
  initMetadataForClass(Stack, 'Stack', Stack);
  initMetadataForClass(EmptyStackException, 'EmptyStackException', EmptyStackException, Error);
  initMetadataForObject(TopologicalSort, 'TopologicalSort');
  initMetadataForClass(AbstractBaseInterpreter, 'AbstractBaseInterpreter');
  function getValue$default(name, location, $super) {
    location = location === VOID ? Companion_getInstance_18().cx_1 : location;
    return $super === VOID ? this.ax(name, location) : $super.ax.call(this, name, location);
  }
  function getOptionalValue$default(name, location, $super) {
    location = location === VOID ? Companion_getInstance_18().cx_1 : location;
    return $super === VOID ? this.ex(name, location) : $super.ex.call(this, name, location);
  }
  initMetadataForInterface(ActivationRecord, 'ActivationRecord');
  initMetadataForCompanion(Companion_5);
  initMetadataForClass(AbstractLexer, 'AbstractLexer');
  initMetadataForClass(BaseLexer, 'BaseLexer', VOID, AbstractLexer);
  initMetadataForClass(BaseTokenType, 'BaseTokenType', VOID, Enum);
  initMetadataForObject(Dsl, 'Dsl');
  initMetadataForClass(DslError, 'DslError', VOID, Error);
  initMetadataForClass(SyntaxError, 'SyntaxError', VOID, DslError);
  initMetadataForClass(SemanticError, 'SemanticError', VOID, DslError);
  initMetadataForClass(RuntimeError, 'RuntimeError', VOID, DslError);
  initMetadataForInterface(ExternalFunction, 'ExternalFunction');
  initMetadataForClass(sam$io_antarescircuit_jabbah_base_dsl_ExternalFunction$0, 'sam$io_antarescircuit_jabbah_base_dsl_ExternalFunction$0', VOID, VOID, [ExternalFunction, FunctionAdapter]);
  initMetadataForClass(DslGlobalFunctions, 'DslGlobalFunctions', DslGlobalFunctions);
  initMetadataForCompanion(Companion_6);
  initMetadataForClass(DslLexer, 'DslLexer', VOID, BaseLexer);
  initMetadataForCompanion(Companion_7);
  initMetadataForClass(AbstractParser, 'AbstractParser');
  initMetadataForClass(DslParser, 'DslParser', VOID, AbstractParser);
  initMetadataForClass(Visitor, 'Visitor', VOID, EmptyHierarchyVisitor);
  initMetadataForClass(DslSemanticAnalyser, 'DslSemanticAnalyser');
  initMetadataForCompanion(Companion_8);
  initMetadataForClass(Interpreter, 'Interpreter', VOID, AbstractBaseInterpreter);
  initMetadataForClass(Memory, 'Memory', Memory);
  initMetadataForClass(ScriptMetaData, 'ScriptMetaData');
  initMetadataForClass(StoringActivationRecord, 'StoringActivationRecord', VOID, VOID, [ActivationRecord]);
  initMetadataForClass(Symbol, 'Symbol');
  initMetadataForClass(BuiltInTypeSymbol, 'BuiltInTypeSymbol', VOID, Symbol);
  initMetadataForClass(VariableSymbol, 'VariableSymbol', VOID, Symbol);
  initMetadataForClass(ExternalFunctionSymbol, 'ExternalFunctionSymbol', VOID, Symbol);
  function hasSymbol$default(name, currentScopeOnly, $super) {
    currentScopeOnly = currentScopeOnly === VOID ? false : currentScopeOnly;
    return $super === VOID ? this.z12(name, currentScopeOnly) : $super.z12.call(this, name, currentScopeOnly);
  }
  function lookup$default(name, currentScopeOnly, $super) {
    currentScopeOnly = currentScopeOnly === VOID ? false : currentScopeOnly;
    return $super === VOID ? this.c17(name, currentScopeOnly) : $super.c17.call(this, name, currentScopeOnly);
  }
  initMetadataForInterface(SymbolTable, 'SymbolTable');
  initMetadataForClass(ScopedSymbolTable, 'ScopedSymbolTable', VOID, VOID, [SymbolTable]);
  initMetadataForClass(AbstractNode, 'AbstractNode');
  initMetadataForClass(Compound, 'Compound', VOID, AbstractNode);
  initMetadataForClass(Declaration, 'Declaration', VOID, AbstractNode);
  initMetadataForClass(Variable, 'Variable', VOID, AbstractNode);
  initMetadataForClass(Assignment, 'Assignment', VOID, AbstractNode);
  initMetadataForClass(Block, 'Block', VOID, Compound);
  initMetadataForClass(ForStatement, 'ForStatement', VOID, AbstractNode);
  initMetadataForClass(FunctionCall, 'FunctionCall', VOID, AbstractNode);
  initMetadataForClass(NoOp, 'NoOp', VOID, AbstractNode);
  initMetadataForClass(AssocArray, 'AssocArray', VOID, Variable);
  initMetadataForClass(IfStatement, 'IfStatement', VOID, AbstractNode);
  initMetadataForClass(WhenClause, 'WhenClause', VOID, AbstractNode);
  initMetadataForClass(WhenStatement, 'WhenStatement', VOID, AbstractNode);
  initMetadataForClass(ReturnStatement, 'ReturnStatement', VOID, AbstractNode);
  initMetadataForClass(BinaryOperation, 'BinaryOperation', VOID, AbstractNode);
  initMetadataForClass(ListLiteral, 'ListLiteral', VOID, AbstractNode);
  initMetadataForClass(UnaryOperation, 'UnaryOperation', VOID, AbstractNode);
  initMetadataForClass(Literal, 'Literal', VOID, AbstractNode);
  initMetadataForClass(DslTokenType, 'DslTokenType', VOID, Enum);
  function get_isAltDown() {
    return !((this.modifiers & Modifier_Alt_getInstance().mask) === 0);
  }
  function get_isControlDown() {
    return !((this.modifiers & Modifier_Ctrl_getInstance().mask) === 0);
  }
  function get_isShiftDown() {
    return !((this.modifiers & Modifier_Shift_getInstance().mask) === 0);
  }
  function get_isCtrlDown() {
    return !((this.modifiers & Modifier_Ctrl_getInstance().mask) === 0);
  }
  function get_isAltGraphDown() {
    return !((this.modifiers & Modifier_AltGraph_getInstance().mask) === 0);
  }
  function get_isMetaDown() {
    return !((this.modifiers & Modifier_Meta_getInstance().mask) === 0);
  }
  function hasModifier(modifier) {
    return !((this.modifiers & modifier.mask) === 0);
  }
  initMetadataForInterface(InputEvent, 'InputEvent');
  initMetadataForClass(ActionEvent, 'ActionEvent', VOID, VOID, [InputEvent]);
  initMetadataForInterface(ActionListener, 'ActionListener');
  function postVetoable$default(event, undoEvent, thenHandler, elseHandler, $super) {
    var tmp;
    if (thenHandler === VOID) {
      tmp = EventBus$postVetoable$lambda;
    } else {
      tmp = thenHandler;
    }
    thenHandler = tmp;
    var tmp_0;
    if (elseHandler === VOID) {
      tmp_0 = EventBus$postVetoable$lambda_0;
    } else {
      tmp_0 = elseHandler;
    }
    elseHandler = tmp_0;
    var tmp_1;
    if ($super === VOID) {
      this.c18(event, undoEvent, thenHandler, elseHandler);
      tmp_1 = Unit_instance;
    } else {
      tmp_1 = $super.c18.call(this, event, undoEvent, thenHandler, elseHandler);
    }
    return tmp_1;
  }
  function postTwoPhase$default(prepareEvent, execEvent, thenHandler, $super) {
    thenHandler = thenHandler === VOID ? null : thenHandler;
    var tmp;
    if ($super === VOID) {
      this.e18(prepareEvent, execEvent, thenHandler);
      tmp = Unit_instance;
    } else {
      tmp = $super.e18.call(this, prepareEvent, execEvent, thenHandler);
    }
    return tmp;
  }
  initMetadataForInterface(EventBus, 'EventBus');
  initMetadataForClass(VetoException, 'VetoException', VOID, Error);
  initMetadataForCompanion(Companion_9);
  initMetadataForClass(EventBusImpl, 'EventBusImpl', EventBusImpl, VOID, [EventBus]);
  initMetadataForClass(Modifier, 'Modifier', VOID, Enum);
  initMetadataForCompanion(Companion_10);
  initMetadataForClass(KeyEventType, 'KeyEventType', VOID, Enum);
  initMetadataForClass(KeyEventImpl, 'KeyEventImpl', VOID, VOID, [InputEvent]);
  initMetadataForClass(KeyAdapter, 'KeyAdapter', KeyAdapter);
  function get_location() {
    return new Point2D(this.p1a(), this.q1a());
  }
  initMetadataForInterface(MouseEvent, 'MouseEvent', VOID, VOID, [InputEvent]);
  initMetadataForClass(MouseEventType, 'MouseEventType', VOID, Enum);
  initMetadataForClass(Button, 'Button', VOID, Enum);
  initMetadataForClass(MouseEventImpl, 'MouseEventImpl', MouseEventImpl, VOID, [MouseEvent]);
  initMetadataForClass(MouseAdapter, 'MouseAdapter', MouseAdapter);
  initMetadataForClass(PropertyChangeEvent, 'PropertyChangeEvent');
  initMetadataForClass(PropertyOwnerImpl, 'PropertyOwnerImpl', PropertyOwnerImpl);
  initMetadataForClass(sam$io_antarescircuit_jabbah_base_event_PropertyChangeListener$0, 'sam$io_antarescircuit_jabbah_base_event_PropertyChangeListener$0', VOID, VOID, [PropertyChangeListener, FunctionAdapter]);
  initMetadataForClass(PropertyChangeSupport, 'PropertyChangeSupport');
  initMetadataForCompanion(Companion_11);
  function contains_3(x, y) {
    return x >= this.p1a() && x <= this.p1a() + this.f1c() && y >= this.q1a() && y <= this.q1a() + this.h1c();
  }
  function contains_4(x, y, width, height) {
    if (this.qv()) {
      return false;
    }
    return x >= this.p1a() && x + width <= this.b1d() && y >= this.q1a() && y + height <= this.c1d();
  }
  function get_xInt() {
    return numberToInt(this.p1a());
  }
  function get_yInt() {
    return numberToInt(this.q1a());
  }
  function get_widthInt() {
    return numberToInt(this.f1c());
  }
  function get_heightInt() {
    return numberToInt(this.h1c());
  }
  function get_isInitial() {
    return this.qv() && this.p1a() === 0.0 && this.q1a() === 0.0;
  }
  function get_isEmpty() {
    return this.f1c() <= 0 && this.h1c() <= 0;
  }
  function get_centerX() {
    return this.p1a() + this.f1c() / 2.0;
  }
  function get_centerY() {
    return this.q1a() + this.h1c() / 2.0;
  }
  function get_minX() {
    return this.p1a();
  }
  function get_minY() {
    return this.q1a();
  }
  function get_maxX() {
    return this.p1a() + this.f1c();
  }
  function get_maxY() {
    return this.q1a() + this.h1c();
  }
  function get_center() {
    return new Point2D(this.x1c(), this.y1c());
  }
  function get_topLeft() {
    return new Point2D(this.z1c(), this.a1d());
  }
  function get_bottomCenter() {
    return new Point2D(this.x1c(), this.c1d());
  }
  function get_centerLeft() {
    return new Point2D(this.z1c(), this.y1c());
  }
  function get_centerRight() {
    return new Point2D(this.b1d(), this.y1c());
  }
  initMetadataForInterface(RectangularShape, 'RectangularShape', VOID, VOID, [Shape]);
  function moveBy(v) {
    this.i1c(this.p1a() + v.kn_1, this.q1a() + v.ln_1, this.f1c(), this.h1c());
    return this;
  }
  function setFrame(rect) {
    this.i1c(rect.p1a(), rect.q1a(), rect.f1c(), rect.h1c());
  }
  function add_0(x, y) {
    if (this.w1c()) {
      this.i1c(x, y, 0.0, 0.0);
    } else {
      // Inline function 'kotlin.math.min' call
      var a = this.z1c();
      var x1 = Math.min(a, x);
      // Inline function 'kotlin.math.max' call
      var a_0 = this.b1d();
      var x2 = Math.max(a_0, x);
      // Inline function 'kotlin.math.min' call
      var a_1 = this.a1d();
      var y1 = Math.min(a_1, y);
      // Inline function 'kotlin.math.max' call
      var a_2 = this.c1d();
      var y2 = Math.max(a_2, y);
      this.i1c(x1, y1, x2 - x1, y2 - y1);
    }
    return this;
  }
  function add_1(p) {
    return this.vn(p.kn_1, p.ln_1);
  }
  function add_2(rect) {
    if (this.w1c()) {
      this.m1c(rect);
    } else {
      var tmp0 = this.z1c();
      // Inline function 'kotlin.math.min' call
      var b = rect.z1c();
      var x1 = Math.min(tmp0, b);
      var tmp0_0 = this.b1d();
      // Inline function 'kotlin.math.max' call
      var b_0 = rect.b1d();
      var x2 = Math.max(tmp0_0, b_0);
      var tmp0_1 = this.a1d();
      // Inline function 'kotlin.math.min' call
      var b_1 = rect.a1d();
      var y1 = Math.min(tmp0_1, b_1);
      var tmp0_2 = this.c1d();
      // Inline function 'kotlin.math.max' call
      var b_2 = rect.c1d();
      var y2 = Math.max(tmp0_2, b_2);
      this.i1c(x1, y1, x2 - x1, y2 - y1);
    }
    return this;
  }
  function expandBy(deltaX, deltaY) {
    this.i1c(this.p1a() - deltaX, this.q1a() - deltaY, this.f1c() + 2 * deltaX, this.h1c() + 2 * deltaY);
    return this;
  }
  function expandBy_0(delta) {
    return this.o1c(delta, delta);
  }
  function expandBy_1(topY, leftX, bottomY, rightX) {
    this.i1c(this.p1a() - leftX, this.q1a() - topY, this.f1c() + leftX + rightX, this.h1c() + topY + bottomY);
    return this;
  }
  function expandLeftBy(deltaX) {
    this.i1c(this.p1a() - deltaX, this.q1a(), this.f1c() + deltaX, this.h1c());
    return this;
  }
  initMetadataForInterface(MutableRectangularShape, 'MutableRectangularShape', VOID, VOID, [RectangularShape]);
  initMetadataForClass(AbstractRectangularShape, 'AbstractRectangularShape', VOID, VOID, [MutableRectangularShape]);
  function get_uniformScale() {
    // Inline function 'kotlin.math.sqrt' call
    var x = this.i1d();
    return Math.sqrt(x);
  }
  function translate(d) {
    return this.l1d(d.kn_1, d.ln_1);
  }
  initMetadataForInterface(AffineTransform, 'AffineTransform');
  initMetadataForClass(NonInvertibleTransformException, 'NonInvertibleTransformException', VOID, Error);
  initMetadataForCompanion(Companion_12);
  initMetadataForClass(AffineTransformImpl, 'AffineTransformImpl', VOID, VOID, [AffineTransform]);
  initMetadataForClass(Dimension2D, 'Dimension2D');
  initMetadataForCompanion(Companion_13);
  initMetadataForClass(Direction, 'Direction', VOID, Enum);
  initMetadataForClass(Ellipse2D, 'Ellipse2D', Ellipse2D, AbstractRectangularShape);
  initMetadataForObject(Geometry, 'Geometry');
  initMetadataForCompanion(Companion_14);
  initMetadataForClass(Point2D, 'Point2D', Point2D);
  initMetadataForCompanion(Companion_15);
  initMetadataForClass(Rectangle2D, 'Rectangle2D', Rectangle2D, AbstractRectangularShape);
  initMetadataForClass(Ring2D, 'Ring2D', VOID, AbstractRectangularShape);
  initMetadataForCompanion(Companion_16);
  initMetadataForClass(Rotation, 'Rotation', VOID, Enum);
  initMetadataForClass(RoundRectangle2D, 'RoundRectangle2D', VOID, AbstractRectangularShape);
  initMetadataForClass(Turn, 'Turn', VOID, Enum);
  initMetadataForClass(Vector2D, 'Vector2D');
  initMetadataForClass(HelpId, 'HelpId');
  initMetadataForObject(HelpSourceRegistry, 'HelpSourceRegistry');
  initMetadataForClass(HelpSource, 'HelpSource');
  initMetadataForCompanion(Companion_17);
  initMetadataForClass(UnimplementedInvocationHandler, 'UnimplementedInvocationHandler', UnimplementedInvocationHandler, InvocationHandler);
  initMetadataForObject(BaseModule, 'BaseModule', VOID, AbstractModule);
  initMetadataForClass(State, 'State');
  initMetadataForCompanion(Companion_18);
  initMetadataForClass(TextLocation, 'TextLocation');
  initMetadataForClass(Token, 'Token');
  initMetadataForCompanion(Companion_19);
  initMetadataForClass(RichTextLexer, 'RichTextLexer', VOID, AbstractLexer);
  initMetadataForClass(RichTextTokenType, 'RichTextTokenType', VOID, Enum);
  initMetadataForCompanion(Companion_20);
  initMetadataForClass(RichTextParser, 'RichTextParser', VOID, AbstractParser);
  initMetadataForCompanion(Companion_21);
  initMetadataForClass(RichText, 'RichText', VOID, Compound);
  initMetadataForClass(Fragment, 'Fragment', VOID, AbstractNode);
  initMetadataForClass(StyledChunk, 'StyledChunk', VOID, AbstractNode);
  initMetadataForClass(StyledText, 'StyledText', VOID, AbstractNode);
  initMetadataForClass(AbstractFragmentPart, 'AbstractFragmentPart', VOID, AbstractNode);
  initMetadataForClass(FragmentText, 'FragmentText', VOID, AbstractFragmentPart);
  initMetadataForCompanion(Companion_22);
  initMetadataForClass(TextStyle, 'TextStyle');
  initMetadataForClass(Subscript, 'Subscript', VOID, AbstractFragmentPart);
  initMetadataForClass(Superscript, 'Superscript', VOID, AbstractFragmentPart);
  initMetadataForObject(SoundEffects, 'SoundEffects');
  initMetadataForCompanion(Companion_23);
  initMetadataForClass(WaveformType, 'WaveformType', VOID, Enum);
  initMetadataForClass(ToneParams, 'ToneParams');
  initMetadataForClass(State_0, 'State');
  initMetadataForCompanion(Companion_24);
  initMetadataForClass(StateMachine, 'StateMachine', StateMachine);
  initMetadataForClass(UnhandledEventBehaviour, 'UnhandledEventBehaviour', VOID, Enum);
  initMetadataForClass(UnhandledEventBehaviour$Strict, 'Strict', VOID, UnhandledEventBehaviour);
  initMetadataForClass(UnhandledEventBehaviour$Unhandled, 'Unhandled', VOID, UnhandledEventBehaviour);
  initMetadataForClass(SuperState, 'SuperState', VOID, State_0);
  initMetadataForClass(Transition, 'Transition');
  initMetadataForObject(PropertiesFileParser, 'PropertiesFileParser');
  initMetadataForCompanion(Companion_25);
  initMetadataForClass(SystemSpeed, 'SystemSpeed', SystemSpeed);
  initMetadataForClass(SystemSpeedEvent, 'SystemSpeedEvent');
  initMetadataForClass(SystemSpeedPauseEvent, 'SystemSpeedPauseEvent');
  initMetadataForCompanion(Companion_26);
  initMetadataForClass(ControlledTimeService, 'ControlledTimeService', ControlledTimeService);
  initMetadataForObject(DisplayDuration, 'DisplayDuration');
  initMetadataForClass(AbstractUIController, 'AbstractUIController');
  initMetadataForObject(UI, 'UI');
  //endregion
  function effectiveLevel($this) {
    var tmp0_elvis_lhs = $this.gl_1;
    return tmp0_elvis_lhs == null ? LogSystem_getInstance().jl_1 : tmp0_elvis_lhs;
  }
  function Logger(level) {
    level = level === VOID ? null : level;
    this.gl_1 = level;
  }
  protoOf(Logger).kl = function (msg) {
    console.info(msg);
  };
  protoOf(Logger).ll = function (msg, t) {
    if (effectiveLevel(this).l2_1 >= LogLevel_Error_getInstance().l2_1) {
      console.error(msg);
    }
  };
  protoOf(Logger).ml = function (msg, t, $super) {
    t = t === VOID ? null : t;
    var tmp;
    if ($super === VOID) {
      this.ll(msg, t);
      tmp = Unit_instance;
    } else {
      tmp = $super.ll.call(this, msg, t);
    }
    return tmp;
  };
  protoOf(Logger).nl = function (msg) {
    if (effectiveLevel(this).l2_1 >= LogLevel_Warning_getInstance().l2_1) {
      console.warn(msg);
    }
  };
  protoOf(Logger).ol = function (msg) {
    if (effectiveLevel(this).l2_1 >= LogLevel_Info_getInstance().l2_1) {
      console.info(msg);
    }
  };
  protoOf(Logger).pl = function (msg) {
    if (effectiveLevel(this).l2_1 >= LogLevel_Debug_getInstance().l2_1) {
      console.log(msg);
    }
  };
  protoOf(Logger).ql = function (msg) {
    if (effectiveLevel(this).l2_1 >= LogLevel_Trace_getInstance().l2_1) {
      console.log(msg);
    }
  };
  protoOf(Logger).rl = function () {
    return effectiveLevel(this).l2_1 >= LogLevel_Debug_getInstance().l2_1;
  };
  protoOf(Logger).sl = function () {
    return effectiveLevel(this).l2_1 >= LogLevel_Trace_getInstance().l2_1;
  };
  function LogSystem$getLogger$lambda() {
    return new Logger();
  }
  function LogSystem() {
    LogSystem_instance = this;
    var tmp = this;
    // Inline function 'kotlin.collections.mutableMapOf' call
    tmp.hl_1 = LinkedHashMap_init_$Create$();
    this.il_1 = 'base.logLevel';
    this.jl_1 = LogLevel_Warning_getInstance();
  }
  protoOf(LogSystem).tl = function (clazz) {
    // Inline function 'kotlin.collections.getOrPut' call
    var this_0 = this.hl_1;
    var value = this_0.g2(clazz);
    var tmp;
    if (value == null) {
      var answer = lazy(LogSystem$getLogger$lambda);
      this_0.y1(clazz, answer);
      tmp = answer;
    } else {
      tmp = value;
    }
    return tmp;
  };
  var LogSystem_instance;
  function LogSystem_getInstance() {
    if (LogSystem_instance == null)
      new LogSystem();
    return LogSystem_instance;
  }
  function System$invoker$lambda(it) {
    it();
    return Unit_instance;
  }
  function System() {
    System_instance = this;
    var tmp = this;
    tmp.ul_1 = System$invoker$lambda;
  }
  protoOf(System).vl = function () {
    return numberToLong((new Date()).getTime());
  };
  protoOf(System).wl = function () {
    return new RealTimeTimerJs();
  };
  protoOf(System).xl = function (clazz) {
    return ensureNotNull(clazz.m9());
  };
  protoOf(System).yl = function (obj) {
    return ensureNotNull(getKClassFromExpression(obj).m9());
  };
  protoOf(System).zl = function (obj) {
    return getKClassFromExpression(obj);
  };
  protoOf(System).am = function (clazz) {
    return newInstance(get_js(clazz));
  };
  protoOf(System).bm = function () {
    return AffineTransformImpl_init_$Create$();
  };
  protoOf(System).cm = function () {
    return new Path2DJs();
  };
  protoOf(System).dm = function (uuid) {
    var tmp;
    if (uuid == null) {
      tmp = null;
    } else {
      // Inline function 'kotlin.let' call
      tmp = new UUID(uuid);
    }
    var tmp1_elvis_lhs = tmp;
    return tmp1_elvis_lhs == null ? new UUID(Default_getInstance().cg(10000, 99000).toString() + '-TEMP-UUID') : tmp1_elvis_lhs;
  };
  protoOf(System).em = function (uuid, $super) {
    uuid = uuid === VOID ? null : uuid;
    return $super === VOID ? this.dm(uuid) : $super.dm.call(this, uuid);
  };
  protoOf(System).fm = function (invocable) {
    this.ul_1(invocable);
  };
  protoOf(System).gm = function (baseName) {
    return baseName + '.accelerator';
  };
  protoOf(System).hm = function () {
    return Language_English_getInstance();
  };
  protoOf(System).im = function (path) {
    return null;
  };
  var System_instance;
  function System_getInstance() {
    if (System_instance == null)
      new System();
    return System_instance;
  }
  function newInstance(_this__u8e3s4) {
    // Inline function 'kotlin.js.asDynamic' call
    // Inline function 'io.antarescircuit.jabbah.base.newInstance.callCtor' call
    return new _this__u8e3s4();
  }
  function _get_LOG__e5r759($this) {
    var tmp0 = $this.jm_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('LOG', 1, tmp, TranslationServiceJsImpl$Companion$_get_LOG_$ref_nlqk25(), null);
    return tmp0.j2();
  }
  function TranslationServiceJsImpl$Companion$_get_LOG_$ref_nlqk25() {
    return function (p0) {
      return _get_LOG__e5r759(p0);
    };
  }
  function Companion() {
    Companion_instance = this;
    this.jm_1 = logger(getKClass(TranslationServiceJsImpl));
  }
  var Companion_instance;
  function Companion_getInstance() {
    if (Companion_instance == null)
      new Companion();
    return Companion_instance;
  }
  function TranslationServiceJsImpl$load$lambda(it) {
    return it.text();
  }
  function TranslationServiceJsImpl$load$lambda_0(it) {
    return PropertiesFileParser_getInstance().lm(it);
  }
  function TranslationServiceJsImpl$load$lambda_1($url) {
    return function (it) {
      _get_LOG__e5r759(Companion_getInstance()).ml('Error while loading translations from ' + $url + ': ' + it.toString());
      // Inline function 'kotlin.collections.mapOf' call
      return emptyMap();
    };
  }
  function TranslationServiceJsImpl(baseUrl) {
    Companion_getInstance();
    this.mm_1 = baseUrl;
  }
  protoOf(TranslationServiceJsImpl).nm = function (name) {
    var lang = System_getInstance().hm().qm_1;
    var url = this.mm_1 + '/translation/' + name + '/' + lang;
    var tmp = window.fetch(url);
    var tmp0 = tmp.then(TranslationServiceJsImpl$load$lambda);
    // Inline function 'kotlin.js.then' call
    var onFulfilled = TranslationServiceJsImpl$load$lambda_0;
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    var tmp_0 = tmp0.then(onFulfilled);
    return tmp_0.catch(TranslationServiceJsImpl$load$lambda_1(url));
  };
  function _get_LOG__e5r759_0($this) {
    var tmp0 = $this.rm_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('LOG', 1, tmp, Translations$_get_LOG_$ref_o5a43e(), null);
    return tmp0.j2();
  }
  function Translations$_get_LOG_$ref_o5a43e() {
    return function (p0) {
      return _get_LOG__e5r759_0(p0);
    };
  }
  function Translations$addBundleAsync$lambda($name) {
    return function (translation) {
      // Inline function 'kotlin.collections.forEach' call
      // Inline function 'kotlin.collections.iterator' call
      var _iterator__ex2g4s = translation.d2().i();
      while (_iterator__ex2g4s.j()) {
        var element = _iterator__ex2g4s.k();
        Translations_getInstance().vm(element.i2(), element.j2());
      }
      Translations_getInstance().um_1.h($name);
      return Unit_instance;
    };
  }
  function Translations() {
    Translations_instance = this;
    this.rm_1 = logger(getKClass(Translations));
    var tmp = this;
    // Inline function 'kotlin.collections.mutableMapOf' call
    tmp.sm_1 = LinkedHashMap_init_$Create$();
    var tmp_0 = this;
    // Inline function 'kotlin.collections.mutableListOf' call
    tmp_0.tm_1 = ArrayList_init_$Create$();
    var tmp_1 = this;
    // Inline function 'kotlin.collections.mutableListOf' call
    tmp_1.um_1 = ArrayList_init_$Create$();
  }
  protoOf(Translations).wm = function (name) {
    this.xm(name);
  };
  protoOf(Translations).xm = function (name) {
    if (!this.an(name)) {
      _get_LOG__e5r759_0(this).ql("Adding translation bundle '" + name + "'");
      this.tm_1.h(name);
      var tmp = BaseModuleJs_getInstance().zm_1.nm(name);
      return tmp.then(Translations$addBundleAsync$lambda(name));
    }
    return null;
  };
  protoOf(Translations).an = function (name) {
    return this.um_1.n(name);
  };
  protoOf(Translations).vm = function (key, value) {
    // Inline function 'kotlin.collections.set' call
    this.sm_1.y1(key, value);
  };
  protoOf(Translations).bn = function (key, params) {
    // Inline function 'kotlin.collections.getOrElse' call
    var tmp0_elvis_lhs = this.sm_1.g2(key);
    var tmp;
    if (tmp0_elvis_lhs == null) {
      tmp = key;
    } else {
      tmp = tmp0_elvis_lhs;
    }
    var value = tmp;
    // Inline function 'kotlin.collections.forEachIndexed' call
    var index = 0;
    var inductionVariable = 0;
    var last = params.length;
    while (inductionVariable < last) {
      var item = params[inductionVariable];
      inductionVariable = inductionVariable + 1 | 0;
      var _unary__edvuaz = index;
      index = _unary__edvuaz + 1 | 0;
      value = replace(value, '{' + _unary__edvuaz + '}', toString(item));
    }
    return value;
  };
  protoOf(Translations).cn = function (key) {
    return this.sm_1.g2(key);
  };
  var Translations_instance;
  function Translations_getInstance() {
    if (Translations_instance == null)
      new Translations();
    return Translations_instance;
  }
  function TranslationsOutlet() {
  }
  protoOf(TranslationsOutlet).getString = function (key) {
    return Translations_getInstance().bn(key, []);
  };
  protoOf(TranslationsOutlet).getOptionalString = function (key) {
    return Translations_getInstance().cn(key);
  };
  var TranslationsOutlet_instance;
  function TranslationsOutlet_getInstance() {
    return TranslationsOutlet_instance;
  }
  function mpListener(l) {
    return new mpListener$1(l);
  }
  function mpListener$1($l) {
    this.dn_1 = $l;
  }
  protoOf(mpListener$1).propertyChanged = function (e) {
    this.dn_1.propertyChanged(e);
  };
  function lastMoveToEntry($this) {
    var tmp0 = $this.en_1;
    var tmp$ret$0;
    $l$block: {
      // Inline function 'kotlin.collections.lastOrNull' call
      var iterator = tmp0.v1(tmp0.o());
      while (iterator.n3()) {
        var element = iterator.o3();
        var tmp = element.gn_1;
        if (tmp instanceof MoveTo) {
          tmp$ret$0 = element;
          break $l$block;
        }
      }
      tmp$ret$0 = null;
    }
    return tmp$ret$0;
  }
  function MoveTo(p) {
    this.hn_1 = p;
  }
  protoOf(MoveTo).in = function () {
    return new MoveTo(this.hn_1);
  };
  protoOf(MoveTo).jn = function (path, ctx) {
    ctx.moveTo(this.hn_1.kn_1, this.hn_1.ln_1);
  };
  protoOf(MoveTo).mn = function (transform) {
    this.hn_1 = transform.nn(this.hn_1);
  };
  protoOf(MoveTo).toString = function () {
    return 'MoveTo(p=' + this.hn_1.toString() + ')';
  };
  protoOf(MoveTo).hashCode = function () {
    return this.hn_1.hashCode();
  };
  protoOf(MoveTo).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof MoveTo))
      return false;
    if (!this.hn_1.equals(other.hn_1))
      return false;
    return true;
  };
  function LineTo(p) {
    this.on_1 = p;
  }
  protoOf(LineTo).in = function () {
    return new LineTo(this.on_1);
  };
  protoOf(LineTo).jn = function (path, ctx) {
    ctx.lineTo(this.on_1.kn_1, this.on_1.ln_1);
  };
  protoOf(LineTo).mn = function (transform) {
    this.on_1 = transform.nn(this.on_1);
  };
  protoOf(LineTo).toString = function () {
    return 'LineTo(p=' + this.on_1.toString() + ')';
  };
  protoOf(LineTo).hashCode = function () {
    return this.on_1.hashCode();
  };
  protoOf(LineTo).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof LineTo))
      return false;
    if (!this.on_1.equals(other.on_1))
      return false;
    return true;
  };
  function QuadTo(controlPoint, endPoint) {
    this.pn_1 = controlPoint;
    this.qn_1 = endPoint;
  }
  protoOf(QuadTo).in = function () {
    return new QuadTo(this.pn_1, this.qn_1);
  };
  protoOf(QuadTo).jn = function (path, ctx) {
    ctx.quadraticCurveTo(this.pn_1.kn_1, this.pn_1.ln_1, this.qn_1.kn_1, this.qn_1.ln_1);
  };
  protoOf(QuadTo).mn = function (transform) {
    this.pn_1 = transform.nn(this.pn_1);
    this.qn_1 = transform.nn(this.qn_1);
  };
  protoOf(QuadTo).toString = function () {
    return 'QuadTo(controlPoint=' + this.pn_1.toString() + ', endPoint=' + this.qn_1.toString() + ')';
  };
  protoOf(QuadTo).hashCode = function () {
    var result = this.pn_1.hashCode();
    result = imul(result, 31) + this.qn_1.hashCode() | 0;
    return result;
  };
  protoOf(QuadTo).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof QuadTo))
      return false;
    if (!this.pn_1.equals(other.pn_1))
      return false;
    if (!this.qn_1.equals(other.qn_1))
      return false;
    return true;
  };
  function CurveTo(cp1, cp2, endPoint) {
    this.rn_1 = cp1;
    this.sn_1 = cp2;
    this.tn_1 = endPoint;
  }
  protoOf(CurveTo).in = function () {
    return new CurveTo(this.rn_1, this.sn_1, this.tn_1);
  };
  protoOf(CurveTo).jn = function (path, ctx) {
    ctx.bezierCurveTo(this.rn_1.kn_1, this.rn_1.ln_1, this.sn_1.kn_1, this.sn_1.ln_1, this.tn_1.kn_1, this.tn_1.ln_1);
  };
  protoOf(CurveTo).mn = function (transform) {
    this.rn_1 = transform.nn(this.rn_1);
    this.sn_1 = transform.nn(this.sn_1);
    this.tn_1 = transform.nn(this.tn_1);
  };
  protoOf(CurveTo).toString = function () {
    return 'CurveTo(cp1=' + this.rn_1.toString() + ', cp2=' + this.sn_1.toString() + ', endPoint=' + this.tn_1.toString() + ')';
  };
  protoOf(CurveTo).hashCode = function () {
    var result = this.rn_1.hashCode();
    result = imul(result, 31) + this.sn_1.hashCode() | 0;
    result = imul(result, 31) + this.tn_1.hashCode() | 0;
    return result;
  };
  protoOf(CurveTo).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof CurveTo))
      return false;
    if (!this.rn_1.equals(other.rn_1))
      return false;
    if (!this.sn_1.equals(other.sn_1))
      return false;
    if (!this.tn_1.equals(other.tn_1))
      return false;
    return true;
  };
  function ClosePath() {
  }
  protoOf(ClosePath).in = function () {
    return new ClosePath();
  };
  protoOf(ClosePath).jn = function (path, ctx) {
    var tmp0_safe_receiver = lastMoveToEntry(path);
    if (tmp0_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      var tmp = tmp0_safe_receiver.gn_1;
      ctx.lineTo((tmp instanceof MoveTo ? tmp : THROW_CCE()).hn_1.kn_1, tmp0_safe_receiver.gn_1.hn_1.ln_1);
    }
  };
  protoOf(ClosePath).mn = function (transform) {
  };
  function Entry(command) {
    this.gn_1 = command;
  }
  protoOf(Entry).jn = function (path, ctx) {
    this.gn_1.jn(path, ctx);
  };
  protoOf(Entry).mn = function (transform) {
    this.gn_1.mn(transform);
  };
  protoOf(Entry).toString = function () {
    return 'Entry(command=' + toString(this.gn_1) + ')';
  };
  protoOf(Entry).hashCode = function () {
    return hashCode(this.gn_1);
  };
  protoOf(Entry).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof Entry))
      return false;
    if (!equals(this.gn_1, other.gn_1))
      return false;
    return true;
  };
  function Path2DJs(boundingBox) {
    boundingBox = boundingBox === VOID ? new Rectangle2D() : boundingBox;
    var tmp = this;
    // Inline function 'kotlin.collections.mutableListOf' call
    tmp.en_1 = ArrayList_init_$Create$();
    this.fn_1 = boundingBox;
  }
  protoOf(Path2DJs).in = function () {
    var clone = new Path2DJs(Rectangle2D_init_$Create$_0(this.fn_1));
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = this.en_1.i();
    while (_iterator__ex2g4s.j()) {
      var element = _iterator__ex2g4s.k();
      clone.en_1.h(new Entry(element.gn_1.in()));
    }
    return clone;
  };
  protoOf(Path2DJs).un = function (x, y) {
    this.fn_1.vn(x, y);
    this.en_1.h(new Entry(new MoveTo(new Point2D(x, y))));
    return this;
  };
  protoOf(Path2DJs).wn = function (x, y) {
    this.fn_1.vn(x, y);
    this.en_1.h(new Entry(new MoveTo(Point2D_init_$Create$_0(x, y))));
    return this;
  };
  protoOf(Path2DJs).xn = function (x, y) {
    this.fn_1.vn(x, y);
    this.en_1.h(new Entry(new MoveTo(new Point2D(x, y))));
    return this;
  };
  protoOf(Path2DJs).yn = function (x, y) {
    this.fn_1.vn(x, y);
    this.en_1.h(new Entry(new LineTo(new Point2D(x, y))));
    return this;
  };
  protoOf(Path2DJs).zn = function (x, y) {
    this.fn_1.vn(x, y);
    this.en_1.h(new Entry(new LineTo(Point2D_init_$Create$_0(x, y))));
    return this;
  };
  protoOf(Path2DJs).ao = function (x, y) {
    this.fn_1.vn(x, y);
    this.en_1.h(new Entry(new LineTo(new Point2D(x, y))));
    return this;
  };
  protoOf(Path2DJs).bo = function (x1, y1, x2, y2) {
    this.fn_1.vn(x1, y1);
    this.fn_1.vn(x2, y2);
    this.en_1.h(new Entry(new QuadTo(new Point2D(x1, y1), new Point2D(x2, y2))));
    return this;
  };
  protoOf(Path2DJs).co = function (x1, y1, x2, y2, x3, y3) {
    this.fn_1.vn(x1, y1);
    this.fn_1.vn(x2, y2);
    this.fn_1.vn(x3, y3);
    this.en_1.h(new Entry(new CurveTo(new Point2D(x1, y1), new Point2D(x2, y2), new Point2D(x3, y3))));
    return this;
  };
  protoOf(Path2DJs).do = function () {
    var tmp0_safe_receiver = lastMoveToEntry(this);
    if (tmp0_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      var tmp = tmp0_safe_receiver.gn_1;
      this.fn_1.eo((tmp instanceof MoveTo ? tmp : THROW_CCE()).hn_1);
    }
    this.en_1.h(new Entry(new ClosePath()));
    return this;
  };
  protoOf(Path2DJs).mn = function (transform) {
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = this.en_1.i();
    while (_iterator__ex2g4s.j()) {
      var element = _iterator__ex2g4s.k();
      element.mn(transform);
    }
  };
  protoOf(Path2DJs).fo = function () {
    return this.fn_1;
  };
  protoOf(Path2DJs).go = function (x, y) {
    return this.fn_1.go(x, y);
  };
  protoOf(Path2DJs).ho = function (x, y, width, height) {
    return this.fn_1.ho(x, y, width, height);
  };
  protoOf(Path2DJs).io = function (x, y, w, h) {
    return this.fn_1.io(x, y, w, h);
  };
  protoOf(Path2DJs).no = function (ctx) {
    var _iterator__ex2g4s = this.en_1.i();
    while (_iterator__ex2g4s.j()) {
      var entry = _iterator__ex2g4s.k();
      entry.jn(this, ctx);
    }
  };
  function InvocationHandlerJs() {
    InvocationHandler.call(this);
  }
  protoOf(InvocationHandlerJs).so = function (runnable) {
    runnable();
  };
  function BaseModuleJs() {
    BaseModuleJs_instance = this;
    AbstractModule.call(this);
    this.zm_1 = new TranslationServiceJsImpl('http://localhost:8080/api');
  }
  protoOf(BaseModuleJs).to = function () {
    BaseModule_getInstance().vo();
    Companion_getInstance_17().wo_1 = new InvocationHandlerJs();
    BaseModule_getInstance().cp_1 = new RealTimeServiceJs();
  };
  var BaseModuleJs_instance;
  function BaseModuleJs_getInstance() {
    if (BaseModuleJs_instance == null)
      new BaseModuleJs();
    return BaseModuleJs_instance;
  }
  function SoundClipFactory() {
  }
  protoOf(SoundClipFactory).kp = function (path) {
    return SoundClipJs_instance;
  };
  var SoundClipFactory_instance;
  function SoundClipFactory_getInstance() {
    return SoundClipFactory_instance;
  }
  function SoundClipJs() {
  }
  protoOf(SoundClipJs).lp = function () {
  };
  var SoundClipJs_instance;
  function SoundClipJs_getInstance() {
    return SoundClipJs_instance;
  }
  function ToneFactory() {
  }
  protoOf(ToneFactory).mp = function (params) {
    throw UnsupportedOperationException_init_$Create$('not implemented');
  };
  var ToneFactory_instance;
  function ToneFactory_getInstance() {
    return ToneFactory_instance;
  }
  function RealTimeServiceJs() {
  }
  protoOf(RealTimeServiceJs).np = function () {
    return numberToLong(Date.now());
  };
  protoOf(RealTimeServiceJs).op = function () {
    return multiply(numberToLong(1000000), this.np());
  };
  function RealTimeTimerJs$start$lambda(this$0) {
    return function () {
      ensureNotNull(this$0.rp_1)(new ActionEvent(null, window, 0, 'timer', numberToLong((new Date()).getTime())));
      return Unit_instance;
    };
  }
  function RealTimeTimerJs$start$lambda_0(this$0) {
    return function () {
      ensureNotNull(this$0.rp_1)(new ActionEvent(null, window, 0, 'timer', numberToLong((new Date()).getTime())));
      return Unit_instance;
    };
  }
  function RealTimeTimerJs() {
    this.pp_1 = null;
    this.qp_1 = 0;
    this.rp_1 = null;
    this.sp_1 = true;
  }
  protoOf(RealTimeTimerJs).tp = function (_set____db54di) {
    this.qp_1 = _set____db54di;
  };
  protoOf(RealTimeTimerJs).up = function () {
    return this.qp_1;
  };
  protoOf(RealTimeTimerJs).vp = function (interval, repeats, handler) {
    if (this.qp_1 > 0) {
      throw IllegalStateException_init_$Create$('already initialized');
    }
    this.qp_1 = interval;
    this.rp_1 = handler;
    this.sp_1 = repeats;
    return this;
  };
  protoOf(RealTimeTimerJs).xp = function () {
    if (this.qp_1 === 0) {
      throw IllegalStateException_init_$Create$('not yet initialized');
    }
    if (!(this.pp_1 == null)) {
      return Unit_instance;
    }
    var tmp = this;
    var tmp_0;
    if (this.sp_1) {
      var tmp_1 = window;
      tmp_0 = tmp_1.setInterval(RealTimeTimerJs$start$lambda(this), this.qp_1);
    } else {
      var tmp_2 = window;
      tmp_0 = tmp_2.setTimeout(RealTimeTimerJs$start$lambda_0(this), this.qp_1);
    }
    tmp.pp_1 = tmp_0;
  };
  protoOf(RealTimeTimerJs).yp = function () {
    if (this.qp_1 === 0) {
      throw IllegalStateException_init_$Create$('not yet initialized');
    }
    var tmp0_safe_receiver = this.pp_1;
    if (tmp0_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      if (this.sp_1) {
        window.clearInterval(tmp0_safe_receiver);
      } else {
        window.clearTimeout(tmp0_safe_receiver);
      }
      this.pp_1 = null;
    }
  };
  protoOf(RealTimeTimerJs).zp = function () {
    return !(this.pp_1 == null);
  };
  function Throttle$invokeLast$lambda(this$0) {
    return function () {
      this$0.aq_1();
      this$0.cq_1 = null;
      return Unit_instance;
    };
  }
  function Throttle(function_0, interval) {
    this.aq_1 = function_0;
    this.bq_1 = interval;
    this.cq_1 = null;
  }
  protoOf(Throttle).dq = function () {
    if (this.cq_1 == null) {
      var tmp = this;
      var tmp_0 = window;
      tmp.cq_1 = tmp_0.setTimeout(Throttle$invokeLast$lambda(this), this.bq_1);
    }
  };
  function ActionProperty() {
    this.PROP_NAME = 'name';
    this.PROP_DESCRIPTION = 'description';
    this.PROP_ACCELERATOR = 'accelerator';
    this.PROP_ENABLED = 'enabled';
    this.PROP_SELECTED = 'selected';
    this.PROP_IMAGE_PATH = 'imagePath';
  }
  protoOf(ActionProperty).eq = function () {
    return this.PROP_NAME;
  };
  protoOf(ActionProperty).fq = function () {
    return this.PROP_DESCRIPTION;
  };
  protoOf(ActionProperty).gq = function () {
    return this.PROP_ACCELERATOR;
  };
  protoOf(ActionProperty).hq = function () {
    return this.PROP_ENABLED;
  };
  protoOf(ActionProperty).iq = function () {
    return this.PROP_SELECTED;
  };
  protoOf(ActionProperty).jq = function () {
    return this.PROP_IMAGE_PATH;
  };
  var ActionProperty_instance;
  function ActionProperty_getInstance() {
    return ActionProperty_instance;
  }
  function Action() {
  }
  function Companion_0() {
  }
  protoOf(Companion_0).xq = function (baseName) {
    return Translations_getInstance().bn(baseName + '.name', []);
  };
  protoOf(Companion_0).yq = function (baseName) {
    return Translations_getInstance().cn(baseName + '.desc');
  };
  protoOf(Companion_0).zq = function (baseName) {
    return Translations_getInstance().cn(System_getInstance().gm(baseName));
  };
  var Companion_instance_0;
  function Companion_getInstance_0() {
    return Companion_instance_0;
  }
  function AbstractAction_init_$Init$(baseName, imagePath, opensDialog, $this) {
    imagePath = imagePath === VOID ? null : imagePath;
    opensDialog = opensDialog === VOID ? false : opensDialog;
    AbstractAction.call($this, Companion_instance_0.xq(baseName), Companion_instance_0.yq(baseName), Companion_instance_0.zq(baseName), VOID, VOID, imagePath, opensDialog);
    return $this;
  }
  function AbstractAction$name$$inlined$observable$1($initialValue, this$0) {
    this.br_1 = this$0;
    ObservableProperty.call(this, $initialValue);
  }
  protoOf(AbstractAction$name$$inlined$observable$1).cr = function (property, oldValue, newValue) {
    this.br_1.kr_1.nr('name', oldValue, newValue);
    return Unit_instance;
  };
  protoOf(AbstractAction$name$$inlined$observable$1).uf = function (property, oldValue, newValue) {
    return this.cr(property, oldValue, newValue);
  };
  function AbstractAction$_get_name_$ref_109b17() {
    return function (p0) {
      return p0.name;
    };
  }
  function AbstractAction$_set_name_$ref_dt5mhz() {
    return function (p0, p1) {
      p0.kq(p1);
      return Unit_instance;
    };
  }
  function AbstractAction$_get_name_$ref_109b17_0() {
    return function (p0) {
      return p0.name;
    };
  }
  function AbstractAction$_set_name_$ref_dt5mhz_0() {
    return function (p0, p1) {
      p0.kq(p1);
      return Unit_instance;
    };
  }
  function AbstractAction$description$$inlined$observable$1($initialValue, this$0) {
    this.pr_1 = this$0;
    ObservableProperty.call(this, $initialValue);
  }
  protoOf(AbstractAction$description$$inlined$observable$1).cr = function (property, oldValue, newValue) {
    this.pr_1.kr_1.nr('description', oldValue, newValue);
    return Unit_instance;
  };
  protoOf(AbstractAction$description$$inlined$observable$1).uf = function (property, oldValue, newValue) {
    return this.cr(property, oldValue, newValue);
  };
  function AbstractAction$_get_description_$ref_3mhoo() {
    return function (p0) {
      return p0.description;
    };
  }
  function AbstractAction$_set_description_$ref_a7cp78() {
    return function (p0, p1) {
      p0.lq(p1);
      return Unit_instance;
    };
  }
  function AbstractAction$_get_description_$ref_3mhoo_0() {
    return function (p0) {
      return p0.description;
    };
  }
  function AbstractAction$_set_description_$ref_a7cp78_0() {
    return function (p0, p1) {
      p0.lq(p1);
      return Unit_instance;
    };
  }
  function AbstractAction$accelerator$$inlined$observable$1($initialValue, this$0) {
    this.rr_1 = this$0;
    ObservableProperty.call(this, $initialValue);
  }
  protoOf(AbstractAction$accelerator$$inlined$observable$1).cr = function (property, oldValue, newValue) {
    this.rr_1.kr_1.nr('accelerator', oldValue, newValue);
    return Unit_instance;
  };
  protoOf(AbstractAction$accelerator$$inlined$observable$1).uf = function (property, oldValue, newValue) {
    return this.cr(property, oldValue, newValue);
  };
  function AbstractAction$_get_accelerator_$ref_kfihnt() {
    return function (p0) {
      return p0.accelerator;
    };
  }
  function AbstractAction$_set_accelerator_$ref_absa59() {
    return function (p0, p1) {
      p0.nq(p1);
      return Unit_instance;
    };
  }
  function AbstractAction$_get_accelerator_$ref_kfihnt_0() {
    return function (p0) {
      return p0.accelerator;
    };
  }
  function AbstractAction$_set_accelerator_$ref_absa59_0() {
    return function (p0, p1) {
      p0.nq(p1);
      return Unit_instance;
    };
  }
  function AbstractAction$enabled$$inlined$observable$1($initialValue, this$0) {
    this.tr_1 = this$0;
    ObservableProperty.call(this, $initialValue);
  }
  protoOf(AbstractAction$enabled$$inlined$observable$1).cr = function (property, oldValue, newValue) {
    this.tr_1.kr_1.nr('enabled', oldValue, newValue);
    return Unit_instance;
  };
  protoOf(AbstractAction$enabled$$inlined$observable$1).uf = function (property, oldValue, newValue) {
    return this.cr(property, oldValue, newValue);
  };
  function AbstractAction$_get_enabled_$ref_y8lxv1() {
    return function (p0) {
      return p0.enabled;
    };
  }
  function AbstractAction$_set_enabled_$ref_6i3xs7() {
    return function (p0, p1) {
      p0.pq(p1);
      return Unit_instance;
    };
  }
  function AbstractAction$_get_enabled_$ref_y8lxv1_0() {
    return function (p0) {
      return p0.enabled;
    };
  }
  function AbstractAction$_set_enabled_$ref_6i3xs7_0() {
    return function (p0, p1) {
      p0.pq(p1);
      return Unit_instance;
    };
  }
  function AbstractAction$selected$$inlined$observable$1($initialValue, this$0) {
    this.vr_1 = this$0;
    ObservableProperty.call(this, $initialValue);
  }
  protoOf(AbstractAction$selected$$inlined$observable$1).cr = function (property, oldValue, newValue) {
    this.vr_1.kr_1.nr('selected', oldValue, newValue);
    return Unit_instance;
  };
  protoOf(AbstractAction$selected$$inlined$observable$1).uf = function (property, oldValue, newValue) {
    return this.cr(property, oldValue, newValue);
  };
  function AbstractAction$_get_selected_$ref_uj1pcb() {
    return function (p0) {
      return p0.selected;
    };
  }
  function AbstractAction$_set_selected_$ref_ezays7() {
    return function (p0, p1) {
      p0.rq(p1);
      return Unit_instance;
    };
  }
  function AbstractAction$_get_selected_$ref_uj1pcb_0() {
    return function (p0) {
      return p0.selected;
    };
  }
  function AbstractAction$_set_selected_$ref_ezays7_0() {
    return function (p0, p1) {
      p0.rq(p1);
      return Unit_instance;
    };
  }
  function AbstractAction$imagePath$$inlined$observable$1($initialValue, this$0) {
    this.xr_1 = this$0;
    ObservableProperty.call(this, $initialValue);
  }
  protoOf(AbstractAction$imagePath$$inlined$observable$1).cr = function (property, oldValue, newValue) {
    this.xr_1.kr_1.nr('imagePath', oldValue, newValue);
    return Unit_instance;
  };
  protoOf(AbstractAction$imagePath$$inlined$observable$1).uf = function (property, oldValue, newValue) {
    return this.cr(property, oldValue, newValue);
  };
  function AbstractAction$_get_imagePath_$ref_d8tvqk() {
    return function (p0) {
      return p0.imagePath;
    };
  }
  function AbstractAction$_set_imagePath_$ref_1yxmrs() {
    return function (p0, p1) {
      p0.tq(p1);
      return Unit_instance;
    };
  }
  function AbstractAction$_get_imagePath_$ref_d8tvqk_0() {
    return function (p0) {
      return p0.imagePath;
    };
  }
  function AbstractAction$_set_imagePath_$ref_1yxmrs_0() {
    return function (p0, p1) {
      p0.tq(p1);
      return Unit_instance;
    };
  }
  function AbstractAction(name, description, accelerator, enabled, selected, imagePath, opensDialog) {
    enabled = enabled === VOID ? true : enabled;
    selected = selected === VOID ? false : selected;
    imagePath = imagePath === VOID ? null : imagePath;
    opensDialog = opensDialog === VOID ? false : opensDialog;
    this.dr_1 = opensDialog;
    var tmp = this;
    // Inline function 'kotlin.properties.Delegates.observable' call
    tmp.er_1 = new AbstractAction$name$$inlined$observable$1(name, this);
    var tmp_0 = this;
    // Inline function 'kotlin.properties.Delegates.observable' call
    tmp_0.fr_1 = new AbstractAction$description$$inlined$observable$1(description, this);
    var tmp_1 = this;
    // Inline function 'kotlin.properties.Delegates.observable' call
    tmp_1.gr_1 = new AbstractAction$accelerator$$inlined$observable$1(accelerator, this);
    var tmp_2 = this;
    // Inline function 'kotlin.properties.Delegates.observable' call
    tmp_2.hr_1 = new AbstractAction$enabled$$inlined$observable$1(enabled, this);
    var tmp_3 = this;
    // Inline function 'kotlin.properties.Delegates.observable' call
    tmp_3.ir_1 = new AbstractAction$selected$$inlined$observable$1(selected, this);
    var tmp_4 = this;
    // Inline function 'kotlin.properties.Delegates.observable' call
    tmp_4.jr_1 = new AbstractAction$imagePath$$inlined$observable$1(imagePath, this);
    this.kr_1 = new PropertyChangeSupport(this);
  }
  protoOf(AbstractAction).vq = function () {
    return this.dr_1;
  };
  protoOf(AbstractAction).yr = function () {
    return true;
  };
  protoOf(AbstractAction).kq = function (_set____db54di) {
    var tmp = KMutableProperty1;
    var tmp_0 = AbstractAction$_get_name_$ref_109b17_0();
    return this.er_1.yf(this, getPropertyCallableRef('name', 1, tmp, tmp_0, AbstractAction$_set_name_$ref_dt5mhz_0()), _set____db54di);
  };
  protoOf(AbstractAction).m2 = function () {
    var tmp = KMutableProperty1;
    var tmp_0 = AbstractAction$_get_name_$ref_109b17();
    return this.er_1.wf(this, getPropertyCallableRef('name', 1, tmp, tmp_0, AbstractAction$_set_name_$ref_dt5mhz()));
  };
  protoOf(AbstractAction).lq = function (_set____db54di) {
    var tmp = KMutableProperty1;
    var tmp_0 = AbstractAction$_get_description_$ref_3mhoo_0();
    return this.fr_1.yf(this, getPropertyCallableRef('description', 1, tmp, tmp_0, AbstractAction$_set_description_$ref_a7cp78_0()), _set____db54di);
  };
  protoOf(AbstractAction).mq = function () {
    var tmp = KMutableProperty1;
    var tmp_0 = AbstractAction$_get_description_$ref_3mhoo();
    return this.fr_1.wf(this, getPropertyCallableRef('description', 1, tmp, tmp_0, AbstractAction$_set_description_$ref_a7cp78()));
  };
  protoOf(AbstractAction).nq = function (_set____db54di) {
    var tmp = KMutableProperty1;
    var tmp_0 = AbstractAction$_get_accelerator_$ref_kfihnt_0();
    return this.gr_1.yf(this, getPropertyCallableRef('accelerator', 1, tmp, tmp_0, AbstractAction$_set_accelerator_$ref_absa59_0()), _set____db54di);
  };
  protoOf(AbstractAction).oq = function () {
    var tmp = KMutableProperty1;
    var tmp_0 = AbstractAction$_get_accelerator_$ref_kfihnt();
    return this.gr_1.wf(this, getPropertyCallableRef('accelerator', 1, tmp, tmp_0, AbstractAction$_set_accelerator_$ref_absa59()));
  };
  protoOf(AbstractAction).pq = function (_set____db54di) {
    var tmp = KMutableProperty1;
    var tmp_0 = AbstractAction$_get_enabled_$ref_y8lxv1_0();
    return this.hr_1.yf(this, getPropertyCallableRef('enabled', 1, tmp, tmp_0, AbstractAction$_set_enabled_$ref_6i3xs7_0()), _set____db54di);
  };
  protoOf(AbstractAction).qq = function () {
    var tmp = KMutableProperty1;
    var tmp_0 = AbstractAction$_get_enabled_$ref_y8lxv1();
    return this.hr_1.wf(this, getPropertyCallableRef('enabled', 1, tmp, tmp_0, AbstractAction$_set_enabled_$ref_6i3xs7()));
  };
  protoOf(AbstractAction).rq = function (_set____db54di) {
    var tmp = KMutableProperty1;
    var tmp_0 = AbstractAction$_get_selected_$ref_uj1pcb_0();
    return this.ir_1.yf(this, getPropertyCallableRef('selected', 1, tmp, tmp_0, AbstractAction$_set_selected_$ref_ezays7_0()), _set____db54di);
  };
  protoOf(AbstractAction).sq = function () {
    var tmp = KMutableProperty1;
    var tmp_0 = AbstractAction$_get_selected_$ref_uj1pcb();
    return this.ir_1.wf(this, getPropertyCallableRef('selected', 1, tmp, tmp_0, AbstractAction$_set_selected_$ref_ezays7()));
  };
  protoOf(AbstractAction).tq = function (_set____db54di) {
    var tmp = KMutableProperty1;
    var tmp_0 = AbstractAction$_get_imagePath_$ref_d8tvqk_0();
    return this.jr_1.yf(this, getPropertyCallableRef('imagePath', 1, tmp, tmp_0, AbstractAction$_set_imagePath_$ref_1yxmrs_0()), _set____db54di);
  };
  protoOf(AbstractAction).uq = function () {
    var tmp = KMutableProperty1;
    var tmp_0 = AbstractAction$_get_imagePath_$ref_d8tvqk();
    return this.jr_1.wf(this, getPropertyCallableRef('imagePath', 1, tmp, tmp_0, AbstractAction$_set_imagePath_$ref_1yxmrs()));
  };
  protoOf(AbstractAction).dispose = function () {
  };
  protoOf(AbstractAction).updateEnabled = function () {
    this.pq(this.yr());
  };
  protoOf(AbstractAction).addPropertyChangeListener = function (l) {
    this.kr_1.zr(l);
  };
  protoOf(AbstractAction).removePropertyChangeListener = function (l) {
    this.kr_1.as(l);
  };
  var DataLocation_Local_instance;
  var DataLocation_Remote_instance;
  function Companion_1() {
    this.bs_1 = 'base.dataLocation';
    this.cs_1 = 'base.serverUrl';
  }
  var Companion_instance_1;
  function Companion_getInstance_1() {
    return Companion_instance_1;
  }
  var DataLocation_entriesInitialized;
  function DataLocation_initEntries() {
    if (DataLocation_entriesInitialized)
      return Unit_instance;
    DataLocation_entriesInitialized = true;
    DataLocation_Local_instance = new DataLocation('Local', 0, 'local');
    DataLocation_Remote_instance = new DataLocation('Remote', 1, 'remote');
  }
  function DataLocation(name, ordinal, customName) {
    Enum.call(this, name, ordinal);
    this.fs_1 = customName;
  }
  protoOf(DataLocation).toString = function () {
    var tmp;
    switch (this.l2_1) {
      case 0:
        tmp = Translations_getInstance().bn('base.dataLocation.local.name', []);
        break;
      case 1:
        tmp = Translations_getInstance().bn('base.dataLocation.remote.name', []);
        break;
      default:
        noWhenBranchMatchedException();
        break;
    }
    return tmp;
  };
  function DataLocation_Local_getInstance() {
    DataLocation_initEntries();
    return DataLocation_Local_instance;
  }
  function Disposable() {
  }
  function EmptyHierarchyVisitor() {
  }
  protoOf(EmptyHierarchyVisitor).hs = function (node) {
    return true;
  };
  protoOf(EmptyHierarchyVisitor).is = function (node) {
    return true;
  };
  protoOf(EmptyHierarchyVisitor).js = function (node, child) {
    return true;
  };
  protoOf(EmptyHierarchyVisitor).ks = function (node) {
    return true;
  };
  function IssueImpl(severity, name, description, origin, context, data, actionHandler) {
    data = data === VOID ? null : data;
    actionHandler = actionHandler === VOID ? null : actionHandler;
    this.ls_1 = severity;
    this.ms_1 = name;
    this.ns_1 = description;
    this.os_1 = origin;
    this.ps_1 = context;
    this.qs_1 = data;
    this.rs_1 = actionHandler;
  }
  protoOf(IssueImpl).ss = function () {
    return this.ls_1;
  };
  protoOf(IssueImpl).m2 = function () {
    return this.ms_1;
  };
  protoOf(IssueImpl).toString = function () {
    return 'IssueImpl(severity=' + this.ls_1.toString() + ', name=' + this.ms_1 + ', description=' + this.ns_1 + ', origin=' + this.os_1 + ', context=' + this.ps_1 + ', data=' + toString_0(this.qs_1) + ', actionHandler=' + toString_0(this.rs_1) + ')';
  };
  protoOf(IssueImpl).hashCode = function () {
    var result = this.ls_1.hashCode();
    result = imul(result, 31) + getStringHashCode(this.ms_1) | 0;
    result = imul(result, 31) + (this.ns_1 == null ? 0 : getStringHashCode(this.ns_1)) | 0;
    result = imul(result, 31) + getStringHashCode(this.os_1) | 0;
    result = imul(result, 31) + (this.ps_1 == null ? 0 : getStringHashCode(this.ps_1)) | 0;
    result = imul(result, 31) + (this.qs_1 == null ? 0 : hashCode(this.qs_1)) | 0;
    result = imul(result, 31) + (this.rs_1 == null ? 0 : hashCode(this.rs_1)) | 0;
    return result;
  };
  protoOf(IssueImpl).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof IssueImpl))
      return false;
    if (!this.ls_1.equals(other.ls_1))
      return false;
    if (!(this.ms_1 === other.ms_1))
      return false;
    if (!(this.ns_1 == other.ns_1))
      return false;
    if (!(this.os_1 === other.os_1))
      return false;
    if (!(this.ps_1 == other.ps_1))
      return false;
    if (!equals(this.qs_1, other.qs_1))
      return false;
    if (!equals(this.rs_1, other.rs_1))
      return false;
    return true;
  };
  var IssueSeverity_Warning_instance;
  var IssueSeverity_Error_instance;
  var IssueSeverity_entriesInitialized;
  function IssueSeverity_initEntries() {
    if (IssueSeverity_entriesInitialized)
      return Unit_instance;
    IssueSeverity_entriesInitialized = true;
    IssueSeverity_Warning_instance = new IssueSeverity('Warning', 0);
    IssueSeverity_Error_instance = new IssueSeverity('Error', 1);
  }
  function IssueSeverity(name, ordinal) {
    Enum.call(this, name, ordinal);
  }
  protoOf(IssueSeverity).toString = function () {
    var tmp;
    switch (this.l2_1) {
      case 0:
        tmp = Translations_getInstance().bn('issue.severity.warning.name', []);
        break;
      case 1:
        tmp = Translations_getInstance().bn('issue.severity.error.name', []);
        break;
      default:
        noWhenBranchMatchedException();
        break;
    }
    return tmp;
  };
  function IssueSeverity_Warning_getInstance() {
    IssueSeverity_initEntries();
    return IssueSeverity_Warning_instance;
  }
  function IssueSeverity_Error_getInstance() {
    IssueSeverity_initEntries();
    return IssueSeverity_Error_instance;
  }
  function logger(origin) {
    return LogSystem_getInstance().tl(origin);
  }
  var LogLevel_Error_instance;
  var LogLevel_Warning_instance;
  var LogLevel_Info_instance;
  var LogLevel_Debug_instance;
  var LogLevel_Trace_instance;
  var LogLevel_entriesInitialized;
  function LogLevel_initEntries() {
    if (LogLevel_entriesInitialized)
      return Unit_instance;
    LogLevel_entriesInitialized = true;
    LogLevel_Error_instance = new LogLevel('Error', 0);
    LogLevel_Warning_instance = new LogLevel('Warning', 1);
    LogLevel_Info_instance = new LogLevel('Info', 2);
    LogLevel_Debug_instance = new LogLevel('Debug', 3);
    LogLevel_Trace_instance = new LogLevel('Trace', 4);
  }
  function LogLevel(name, ordinal) {
    Enum.call(this, name, ordinal);
  }
  function LogLevel_Error_getInstance() {
    LogLevel_initEntries();
    return LogLevel_Error_instance;
  }
  function LogLevel_Warning_getInstance() {
    LogLevel_initEntries();
    return LogLevel_Warning_instance;
  }
  function LogLevel_Info_getInstance() {
    LogLevel_initEntries();
    return LogLevel_Info_instance;
  }
  function LogLevel_Debug_getInstance() {
    LogLevel_initEntries();
    return LogLevel_Debug_instance;
  }
  function LogLevel_Trace_getInstance() {
    LogLevel_initEntries();
    return LogLevel_Trace_instance;
  }
  function Companion_2() {
    Companion_instance_2 = this;
    this.ts_1 = new LongValueImpl(0n);
    this.us_1 = new LongValueImpl(1n);
  }
  var Companion_instance_2;
  function Companion_getInstance_2() {
    if (Companion_instance_2 == null)
      new Companion_2();
    return Companion_instance_2;
  }
  function LongValueImpl(value) {
    Companion_getInstance_2();
    this.vs_1 = value;
  }
  protoOf(LongValueImpl).j2 = function () {
    return this.vs_1;
  };
  protoOf(LongValueImpl).toString = function () {
    return this.vs_1.toString();
  };
  protoOf(LongValueImpl).equals = function (other) {
    if (this === other)
      return true;
    if (other == null || !getKClassFromExpression(this).equals(getKClassFromExpression(other)))
      return false;
    if (!(other instanceof LongValueImpl))
      THROW_CCE();
    return this.vs_1 === other.vs_1;
  };
  protoOf(LongValueImpl).hashCode = function () {
    return getBigIntHashCode(this.vs_1);
  };
  function LongValue() {
  }
  function AbstractModule() {
    this.uo_1 = false;
  }
  protoOf(AbstractModule).vo = function () {
    if (!this.uo_1) {
      this.to();
      this.uo_1 = true;
    }
  };
  function Entry_0(stringValue, objValue, customized) {
    this.ws_1 = stringValue;
    this.xs_1 = objValue;
    this.ys_1 = customized;
  }
  protoOf(Entry_0).zs = function (stringValue, objValue, customized) {
    return new Entry_0(stringValue, objValue, customized);
  };
  protoOf(Entry_0).at = function (stringValue, objValue, customized, $super) {
    stringValue = stringValue === VOID ? this.ws_1 : stringValue;
    objValue = objValue === VOID ? this.xs_1 : objValue;
    customized = customized === VOID ? this.ys_1 : customized;
    return $super === VOID ? this.zs(stringValue, objValue, customized) : $super.zs.call(this, stringValue, objValue, customized);
  };
  protoOf(Entry_0).toString = function () {
    return 'Entry(stringValue=' + this.ws_1 + ', objValue=' + toString_0(this.xs_1) + ', customized=' + this.ys_1 + ')';
  };
  protoOf(Entry_0).hashCode = function () {
    var result = getStringHashCode(this.ws_1);
    result = imul(result, 31) + (this.xs_1 == null ? 0 : hashCode(this.xs_1)) | 0;
    result = imul(result, 31) + getBooleanHashCode(this.ys_1) | 0;
    return result;
  };
  protoOf(Entry_0).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof Entry_0))
      return false;
    if (!(this.ws_1 === other.ws_1))
      return false;
    if (!equals(this.xs_1, other.xs_1))
      return false;
    if (!(this.ys_1 === other.ys_1))
      return false;
    return true;
  };
  function Properties$entries$delegate$lambda() {
    // Inline function 'kotlin.collections.mutableMapOf' call
    return LinkedHashMap_init_$Create$();
  }
  function Properties$_get_entries_$ref_evzvvl() {
    return function (p0) {
      return p0.d2();
    };
  }
  function Properties() {
    var tmp = this;
    tmp.bt_1 = lazy(Properties$entries$delegate$lambda);
  }
  protoOf(Properties).o = function () {
    return this.d2().o();
  };
  protoOf(Properties).d2 = function () {
    var tmp0 = this.bt_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('entries', 1, tmp, Properties$_get_entries_$ref_evzvvl(), null);
    return tmp0.j2();
  };
  protoOf(Properties).ct = function () {
    return this.d2().b2().i();
  };
  protoOf(Properties).dt = function (name) {
    return this.d2().e2(name);
  };
  protoOf(Properties).a2 = function () {
    this.d2().a2();
  };
  protoOf(Properties).et = function (name, value) {
    var tmp0 = this.d2();
    // Inline function 'kotlin.collections.set' call
    var value_0 = new Entry_0(toString(value), value, false);
    tmp0.y1(name, value_0);
  };
  protoOf(Properties).ft = function (name, value) {
    var tmp0_safe_receiver = this.d2().g2(name);
    if (!equals(value, tmp0_safe_receiver == null ? null : tmp0_safe_receiver.xs_1)) {
      var tmp0 = this.d2();
      // Inline function 'kotlin.collections.set' call
      var value_0 = new Entry_0(toString(value), value, true);
      tmp0.y1(name, value_0);
    }
  };
  protoOf(Properties).gt = function (name, value) {
    var tmp0 = this.d2();
    // Inline function 'kotlin.collections.set' call
    var value_0 = new Entry_0(value, null, true);
    tmp0.y1(name, value_0);
  };
  protoOf(Properties).ht = function (name) {
    var entry = this.it(name);
    if (entry.xs_1 == null) {
      var tmp = entry;
      // Inline function 'kotlin.text.uppercase' call
      // Inline function 'kotlin.js.asDynamic' call
      var tmp$ret$0 = entry.ws_1.toUpperCase();
      entry = tmp.at(VOID, tmp$ret$0 === 'TRUE');
      var tmp0 = this.d2();
      // Inline function 'kotlin.collections.set' call
      var value = entry;
      tmp0.y1(name, value);
    }
    var tmp_0 = entry.xs_1;
    return (!(tmp_0 == null) ? typeof tmp_0 === 'boolean' : false) ? tmp_0 : THROW_CCE();
  };
  protoOf(Properties).jt = function (name) {
    var entry = this.it(name);
    if (entry.xs_1 == null) {
      entry = entry.at(VOID, entry.ws_1);
      var tmp0 = this.d2();
      // Inline function 'kotlin.collections.set' call
      var value = entry;
      tmp0.y1(name, value);
    }
    var tmp = entry.xs_1;
    return (!(tmp == null) ? typeof tmp === 'string' : false) ? tmp : THROW_CCE();
  };
  protoOf(Properties).kt = function (name) {
    var entry = this.it(name);
    if (entry.xs_1 == null) {
      entry = entry.at(VOID, toInt(entry.ws_1));
      var tmp0 = this.d2();
      // Inline function 'kotlin.collections.set' call
      var value = entry;
      tmp0.y1(name, value);
    }
    var tmp = entry.xs_1;
    return (!(tmp == null) ? typeof tmp === 'number' : false) ? tmp : THROW_CCE();
  };
  protoOf(Properties).lt = function (name) {
    var entry = this.it(name);
    if (entry.xs_1 == null) {
      var tmp = entry;
      // Inline function 'kotlin.text.toFloat' call
      var this_0 = entry.ws_1;
      // Inline function 'kotlin.js.unsafeCast' call
      // Inline function 'kotlin.js.asDynamic' call
      var tmp$ret$0 = toDouble(this_0);
      entry = tmp.at(VOID, tmp$ret$0);
      var tmp0 = this.d2();
      // Inline function 'kotlin.collections.set' call
      var value = entry;
      tmp0.y1(name, value);
    }
    var tmp_0 = entry.xs_1;
    return (!(tmp_0 == null) ? typeof tmp_0 === 'number' : false) ? tmp_0 : THROW_CCE();
  };
  protoOf(Properties).it = function (name) {
    var tmp0_elvis_lhs = this.mt(name);
    var tmp;
    if (tmp0_elvis_lhs == null) {
      throw NoSuchElementException_init_$Create$("no property '" + name + "'");
    } else {
      tmp = tmp0_elvis_lhs;
    }
    return tmp;
  };
  protoOf(Properties).mt = function (name) {
    return this.d2().g2(name);
  };
  protoOf(Properties).nt = function (name) {
    return this.it(name).xs_1;
  };
  protoOf(Properties).ot = function (name) {
    var tmp0_safe_receiver = this.mt(name);
    return tmp0_safe_receiver == null ? null : tmp0_safe_receiver.xs_1;
  };
  function PropertiesProxy(target) {
    Properties.call(this);
    this.qt_1 = target;
  }
  protoOf(PropertiesProxy).mt = function (name) {
    return this.qt_1.mt(name);
  };
  protoOf(PropertiesProxy).et = function (name, value) {
    this.qt_1.et(name, value);
  };
  protoOf(PropertiesProxy).ft = function (name, value) {
    this.qt_1.et(name, value);
  };
  function PreferencesChangedEvent(properties) {
    this.rt_1 = properties;
  }
  protoOf(PreferencesChangedEvent).toString = function () {
    return 'PreferencesChangedEvent(properties=' + toString(this.rt_1) + ')';
  };
  protoOf(PreferencesChangedEvent).hashCode = function () {
    return hashCode(this.rt_1);
  };
  protoOf(PreferencesChangedEvent).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof PreferencesChangedEvent))
      return false;
    if (!equals(this.rt_1, other.rt_1))
      return false;
    return true;
  };
  function _get_values__tel787($this) {
    var tmp0 = $this.st_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('values', 1, tmp, Settings$_get_values_$ref_qucteh(), null);
    return tmp0.j2();
  }
  function getOptional($this, name) {
    return _get_values__tel787($this).g2(name);
  }
  function Settings$values$delegate$lambda() {
    // Inline function 'kotlin.collections.mutableMapOf' call
    return LinkedHashMap_init_$Create$();
  }
  function Settings$_get_values_$ref_qucteh() {
    return function (p0) {
      return _get_values__tel787(p0);
    };
  }
  function Settings() {
    var tmp = this;
    tmp.st_1 = lazy(Settings$values$delegate$lambda);
  }
  protoOf(Settings).tt = function (name, defaultValue) {
    var tmp0_elvis_lhs = getOptional(this, name);
    return tmp0_elvis_lhs == null ? defaultValue : tmp0_elvis_lhs;
  };
  protoOf(Settings).ut = function (name, defaultValue) {
    var setting = getOptional(this, name);
    if (StringUtils_getInstance().zt(setting)) {
      return defaultValue;
    }
    var tmp;
    if (setting == null) {
      tmp = null;
    } else {
      // Inline function 'kotlin.text.uppercase' call
      // Inline function 'kotlin.js.asDynamic' call
      tmp = setting.toUpperCase();
    }
    return tmp === 'TRUE';
  };
  protoOf(Settings).au = function (name, defaultValue) {
    var tmp0_safe_receiver = getOptional(this, name);
    var tmp1_elvis_lhs = tmp0_safe_receiver == null ? null : toInt(tmp0_safe_receiver);
    return tmp1_elvis_lhs == null ? defaultValue : tmp1_elvis_lhs;
  };
  protoOf(Settings).et = function (name, value) {
    var tmp0 = _get_values__tel787(this);
    // Inline function 'kotlin.collections.set' call
    var value_0 = toString(value);
    tmp0.y1(name, value_0);
  };
  function ResettableLazy(initializer) {
    this.bu_1 = initializer;
    this.cu_1 = UninitializedValue_instance;
  }
  protoOf(ResettableLazy).j2 = function () {
    if (this.cu_1 === UninitializedValue_instance) {
      this.cu_1 = this.bu_1();
    }
    return this.cu_1;
  };
  protoOf(ResettableLazy).du = function () {
    this.cu_1 = UninitializedValue_instance;
  };
  function resettableLazy(initializer) {
    return new ResettableLazy(initializer);
  }
  function UninitializedValue() {
  }
  var UninitializedValue_instance;
  function UninitializedValue_getInstance() {
    return UninitializedValue_instance;
  }
  function Status() {
    Status_instance = this;
    var tmp = this;
    // Inline function 'kotlin.collections.mutableMapOf' call
    tmp.eu_1 = LinkedHashMap_init_$Create$();
  }
  protoOf(Status).fu = function (type, value) {
    var oldValue = this.eu_1.g2(type);
    if (!((value == null ? null : equals(value, oldValue)) === true)) {
      BaseModule_getInstance().bp_1.gu(new StatusEvent(type, value));
      // Inline function 'kotlin.collections.set' call
      this.eu_1.y1(type, value);
    }
  };
  protoOf(Status).hu = function (type, value) {
    var oldValue = this.eu_1.g2(type);
    this.fu(type, value);
    return oldValue;
  };
  var Status_instance;
  function Status_getInstance() {
    if (Status_instance == null)
      new Status();
    return Status_instance;
  }
  var StatusType_Large_instance;
  var StatusType_Small_instance;
  var StatusType_Tool_instance;
  var StatusType_entriesInitialized;
  function StatusType_initEntries() {
    if (StatusType_entriesInitialized)
      return Unit_instance;
    StatusType_entriesInitialized = true;
    StatusType_Large_instance = new StatusType('Large', 0);
    StatusType_Small_instance = new StatusType('Small', 1);
    StatusType_Tool_instance = new StatusType('Tool', 2);
  }
  function StatusType(name, ordinal) {
    Enum.call(this, name, ordinal);
  }
  function StatusEvent(type, status) {
    this.iu_1 = type;
    this.ju_1 = status;
  }
  protoOf(StatusEvent).toString = function () {
    return 'StatusEvent(type=' + this.iu_1.toString() + ', status=' + this.ju_1 + ')';
  };
  protoOf(StatusEvent).hashCode = function () {
    var result = this.iu_1.hashCode();
    result = imul(result, 31) + (this.ju_1 == null ? 0 : getStringHashCode(this.ju_1)) | 0;
    return result;
  };
  protoOf(StatusEvent).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof StatusEvent))
      return false;
    if (!this.iu_1.equals(other.iu_1))
      return false;
    if (!(this.ju_1 == other.ju_1))
      return false;
    return true;
  };
  function StatusType_Small_getInstance() {
    StatusType_initEntries();
    return StatusType_Small_instance;
  }
  function StatusType_Tool_getInstance() {
    StatusType_initEntries();
    return StatusType_Tool_instance;
  }
  function StringUtils$fromList$lambda(it) {
    return replace(replace(it, '\\', '\\\\'), ',', '\\,');
  }
  function StringUtils() {
    StringUtils_instance = this;
    this.vt_1 = _Char___init__impl__6a9atx(44);
    this.wt_1 = _Char___init__impl__6a9atx(92);
    this.xt_1 = _Char___init__impl__6a9atx(65534);
    this.yt_1 = _Char___init__impl__6a9atx(65535);
  }
  protoOf(StringUtils).ku = function (s) {
    return s == null || isBlank(s);
  };
  protoOf(StringUtils).zt = function (s) {
    var tmp;
    if (s == null) {
      tmp = true;
    } else {
      // Inline function 'kotlin.text.isEmpty' call
      tmp = charSequenceLength(s) === 0;
    }
    return tmp;
  };
  protoOf(StringUtils).lu = function (s) {
    return !this.zt(s);
  };
  protoOf(StringUtils).mu = function (s) {
    return !this.ku(s);
  };
  protoOf(StringUtils).nu = function (s) {
    if (s == null) {
      return '';
    }
    return s;
  };
  protoOf(StringUtils).ou = function (s, alternative) {
    var tmp;
    if (!this.ku(s)) {
      tmp = ensureNotNull(s);
    } else {
      tmp = alternative;
    }
    return tmp;
  };
  protoOf(StringUtils).pu = function (l, separator) {
    var s = l.toString();
    var result = StringBuilder_init_$Create$();
    var i = 0;
    // Inline function 'kotlin.text.reversed' call
    var indexedObject = toString(reversed(isCharSequence(s) ? s : THROW_CCE()));
    var inductionVariable = 0;
    var last = indexedObject.length;
    while (inductionVariable < last) {
      var c = charCodeAt(indexedObject, inductionVariable);
      inductionVariable = inductionVariable + 1 | 0;
      result.j7(c);
      i = i + 1 | 0;
      if ((i % 3 | 0) === 0 && i < s.length) {
        result.j7(separator);
      }
    }
    // Inline function 'kotlin.text.reversed' call
    var this_0 = result.toString();
    return toString(reversed(isCharSequence(this_0) ? this_0 : THROW_CCE()));
  };
  protoOf(StringUtils).qu = function (l, separator, $super) {
    separator = separator === VOID ? _Char___init__impl__6a9atx(95) : separator;
    return $super === VOID ? this.pu(l, separator) : $super.pu.call(this, l, new Char(separator));
  };
  protoOf(StringUtils).ru = function (list) {
    return joinToString(list, ',', VOID, VOID, VOID, VOID, StringUtils$fromList$lambda);
  };
  protoOf(StringUtils).su = function (listString) {
    // Inline function 'kotlin.text.isEmpty' call
    if (charSequenceLength(listString) === 0) {
      // Inline function 'kotlin.collections.listOf' call
      return emptyList();
    }
    var s = replace(replace(listString, '\\\\', '\uFFFE'), '\\,', '\uFFFF');
    s = last(s) === _Char___init__impl__6a9atx(92) ? replace(dropLast(s, 1), '\\', '') + toString_1(_Char___init__impl__6a9atx(92)) : replace(s, '\\', '');
    // Inline function 'kotlin.collections.map' call
    var this_0 = split(s, charArrayOf([_Char___init__impl__6a9atx(44)]));
    // Inline function 'kotlin.collections.mapTo' call
    var destination = ArrayList_init_$Create$_0(collectionSizeOrDefault(this_0, 10));
    var _iterator__ex2g4s = this_0.i();
    while (_iterator__ex2g4s.j()) {
      var item = _iterator__ex2g4s.k();
      var tmp$ret$4 = replace_0(replace_0(item, _Char___init__impl__6a9atx(65534), _Char___init__impl__6a9atx(92)), _Char___init__impl__6a9atx(65535), _Char___init__impl__6a9atx(44));
      destination.h(tmp$ret$4);
    }
    return destination;
  };
  protoOf(StringUtils).tu = function (s, length, moreIndicator) {
    var tmp;
    if (s.length > length) {
      tmp = take(s, length) + moreIndicator;
    } else {
      tmp = s;
    }
    return tmp;
  };
  protoOf(StringUtils).uu = function (s, length, moreIndicator, $super) {
    moreIndicator = moreIndicator === VOID ? '..' : moreIndicator;
    return $super === VOID ? this.tu(s, length, moreIndicator) : $super.tu.call(this, s, length, moreIndicator);
  };
  protoOf(StringUtils).vu = function (s) {
    // Inline function 'kotlin.text.filter' call
    // Inline function 'kotlin.text.filterTo' call
    var destination = StringBuilder_init_$Create$();
    var inductionVariable = 0;
    var last = charSequenceLength(s);
    if (inductionVariable < last)
      do {
        var index = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        var element = charSequenceGet(s, index);
        if (!isWhitespace(element)) {
          destination.j7(element);
        }
      }
       while (inductionVariable < last);
    return destination.toString();
  };
  var StringUtils_instance;
  function StringUtils_getInstance() {
    if (StringUtils_instance == null)
      new StringUtils();
    return StringUtils_instance;
  }
  function Tooltip_init_$Init$(text, x, y, $this) {
    Tooltip.call($this, text, Companion_instance_15.wu(new Point2D(x, y)));
    return $this;
  }
  function Tooltip_init_$Create$(text, x, y) {
    return Tooltip_init_$Init$(text, x, y, objectCreate(protoOf(Tooltip)));
  }
  function Tooltip(text, sourceRect) {
    this.xu_1 = text;
    this.yu_1 = sourceRect;
  }
  protoOf(Tooltip).toString = function () {
    return 'Tooltip(text=' + this.xu_1 + ', sourceRect=' + toString(this.yu_1) + ')';
  };
  protoOf(Tooltip).hashCode = function () {
    var result = getStringHashCode(this.xu_1);
    result = imul(result, 31) + hashCode(this.yu_1) | 0;
    return result;
  };
  protoOf(Tooltip).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof Tooltip))
      return false;
    if (!(this.xu_1 === other.xu_1))
      return false;
    if (!equals(this.yu_1, other.yu_1))
      return false;
    return true;
  };
  function getLanguage($this, code) {
    var indexedObject = values();
    var inductionVariable = 0;
    var last = indexedObject.length;
    while (inductionVariable < last) {
      var lang = indexedObject[inductionVariable];
      inductionVariable = inductionVariable + 1 | 0;
      if (lang.qm_1 === code) {
        return lang;
      }
    }
    return null;
  }
  var Language_English_instance;
  var Language_German_instance;
  function Companion_3() {
    Companion_instance_3 = this;
    this.zu_1 = Language_English_getInstance();
    this.av_1 = 'base.language';
  }
  protoOf(Companion_3).bv = function (code) {
    var tmp0_elvis_lhs = getLanguage(this, code);
    var tmp;
    if (tmp0_elvis_lhs == null) {
      throw IllegalArgumentException_init_$Create$('unknown Language ' + code);
    } else {
      tmp = tmp0_elvis_lhs;
    }
    return tmp;
  };
  var Companion_instance_3;
  function Companion_getInstance_3() {
    Language_initEntries();
    if (Companion_instance_3 == null)
      new Companion_3();
    return Companion_instance_3;
  }
  function values() {
    return [Language_English_getInstance(), Language_German_getInstance()];
  }
  var Language_entriesInitialized;
  function Language_initEntries() {
    if (Language_entriesInitialized)
      return Unit_instance;
    Language_entriesInitialized = true;
    Language_English_instance = new Language('English', 0, 'en');
    Language_German_instance = new Language('German', 1, 'de');
    Companion_getInstance_3();
  }
  function Language(name, ordinal, code) {
    Enum.call(this, name, ordinal);
    this.qm_1 = code;
  }
  protoOf(Language).toString = function () {
    var tmp;
    switch (this.l2_1) {
      case 0:
        tmp = Translations_getInstance().bn('base.language.en.name', []);
        break;
      case 1:
        tmp = Translations_getInstance().bn('base.language.de.name', []);
        break;
      default:
        noWhenBranchMatchedException();
        break;
    }
    return tmp;
  };
  function Language_English_getInstance() {
    Language_initEntries();
    return Language_English_instance;
  }
  function Language_German_getInstance() {
    Language_initEntries();
    return Language_German_instance;
  }
  function UUID(id) {
    this.id = id;
  }
  protoOf(UUID).cv = function () {
    return this.id;
  };
  protoOf(UUID).toString = function () {
    return this.id;
  };
  protoOf(UUID).yd = function () {
    return this.id;
  };
  protoOf(UUID).dv = function (id) {
    return new UUID(id);
  };
  protoOf(UUID).copy = function (id, $super) {
    id = id === VOID ? this.id : id;
    return $super === VOID ? this.dv(id) : $super.dv.call(this, id);
  };
  protoOf(UUID).hashCode = function () {
    return getStringHashCode(this.id);
  };
  protoOf(UUID).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof UUID))
      return false;
    if (!(this.id === other.id))
      return false;
    return true;
  };
  function ImmutableList(inner) {
    this.ev_1 = inner;
  }
  protoOf(ImmutableList).m = function () {
    return this.ev_1.m();
  };
  protoOf(ImmutableList).ud = function (element) {
    return this.ev_1.n(element);
  };
  protoOf(ImmutableList).n = function (element) {
    if (!true)
      return false;
    return this.ud(element);
  };
  protoOf(ImmutableList).i = function () {
    return this.ev_1.i();
  };
  protoOf(ImmutableList).l = function (index) {
    return this.ev_1.l(index);
  };
  protoOf(ImmutableList).fv = function (element) {
    return this.ev_1.p(element);
  };
  protoOf(ImmutableList).p = function (element) {
    if (!true)
      return -1;
    return this.fv(element);
  };
  protoOf(ImmutableList).v1 = function (index) {
    return this.ev_1.v1(index);
  };
  protoOf(ImmutableList).w1 = function (fromIndex, toIndex) {
    return this.ev_1.w1(fromIndex, toIndex);
  };
  protoOf(ImmutableList).o = function () {
    return this.ev_1.o();
  };
  function toImmutableList(_this__u8e3s4) {
    if (_this__u8e3s4 instanceof ImmutableList) {
      return _this__u8e3s4;
    } else {
      return new ImmutableList(_this__u8e3s4);
    }
  }
  function EmptyIterator() {
  }
  protoOf(EmptyIterator).j = function () {
    return false;
  };
  protoOf(EmptyIterator).k = function () {
    throw UnsupportedOperationException_init_$Create$('not implemented');
  };
  function ImmutableSet(inner) {
    this.gv_1 = inner;
  }
  protoOf(ImmutableSet).m = function () {
    return this.gv_1.m();
  };
  protoOf(ImmutableSet).ud = function (element) {
    return this.gv_1.n(element);
  };
  protoOf(ImmutableSet).n = function (element) {
    if (!true)
      return false;
    return this.ud(element);
  };
  protoOf(ImmutableSet).i = function () {
    return this.gv_1.i();
  };
  protoOf(ImmutableSet).hv = function (elements) {
    return this.gv_1.x1(elements);
  };
  protoOf(ImmutableSet).x1 = function (elements) {
    return this.hv(elements);
  };
  protoOf(ImmutableSet).o = function () {
    return this.gv_1.o();
  };
  function DirectedGraph() {
    var tmp = this;
    // Inline function 'kotlin.collections.mutableMapOf' call
    tmp.iv_1 = LinkedHashMap_init_$Create$();
  }
  protoOf(DirectedGraph).i = function () {
    return this.iv_1.b2().i();
  };
  protoOf(DirectedGraph).jv = function (node) {
    if (this.iv_1.e2(node))
      return false;
    var tmp0 = this.iv_1;
    // Inline function 'kotlin.collections.mutableSetOf' call
    // Inline function 'kotlin.collections.set' call
    var value = LinkedHashSet_init_$Create$();
    tmp0.y1(node, value);
    return true;
  };
  protoOf(DirectedGraph).kv = function (start, dest) {
    if (!this.iv_1.e2(start) || !this.iv_1.e2(dest))
      throw NoSuchElementException_init_$Create$('Both nodes must be in the graph.');
    var tmp0_safe_receiver = this.iv_1.g2(start);
    if (tmp0_safe_receiver == null)
      null;
    else
      tmp0_safe_receiver.h(dest);
  };
  protoOf(DirectedGraph).lv = function (node) {
    var tmp0_elvis_lhs = this.iv_1.g2(node);
    var tmp;
    if (tmp0_elvis_lhs == null) {
      throw NoSuchElementException_init_$Create$('Source node does not exist.');
    } else {
      tmp = tmp0_elvis_lhs;
    }
    var arcs = tmp;
    return new ImmutableSet(arcs);
  };
  function Companion_4() {
  }
  protoOf(Companion_4).mv = function (a, b) {
    // Inline function 'kotlin.collections.mutableSetOf' call
    var product = LinkedHashSet_init_$Create$();
    var _iterator__ex2g4s = a.i();
    while (_iterator__ex2g4s.j()) {
      var first = _iterator__ex2g4s.k();
      var _iterator__ex2g4s_0 = b.i();
      while (_iterator__ex2g4s_0.j()) {
        var second = _iterator__ex2g4s_0.k();
        product.h(new Pair(first, second));
      }
    }
    return product;
  };
  var Companion_instance_4;
  function Companion_getInstance_4() {
    return Companion_instance_4;
  }
  function Pair(first, second) {
    this.nv_1 = first;
    this.ov_1 = second;
  }
  protoOf(Pair).toString = function () {
    return 'Pair(first=' + toString_0(this.nv_1) + ', second=' + toString_0(this.ov_1) + ')';
  };
  protoOf(Pair).hashCode = function () {
    var result = this.nv_1 == null ? 0 : hashCode(this.nv_1);
    result = imul(result, 31) + (this.ov_1 == null ? 0 : hashCode(this.ov_1)) | 0;
    return result;
  };
  protoOf(Pair).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof Pair))
      return false;
    if (!equals(this.nv_1, other.nv_1))
      return false;
    if (!equals(this.ov_1, other.ov_1))
      return false;
    return true;
  };
  function PriorityQueue() {
    var tmp = this;
    // Inline function 'kotlin.collections.mutableListOf' call
    tmp.pv_1 = ArrayList_init_$Create$();
  }
  protoOf(PriorityQueue).o = function () {
    return this.pv_1.o();
  };
  protoOf(PriorityQueue).qv = function () {
    return this.pv_1.m();
  };
  protoOf(PriorityQueue).rv = function () {
    if (this.o() > 0) {
      return this.pv_1.l(0);
    }
    return null;
  };
  protoOf(PriorityQueue).sv = function (elem) {
    this.pv_1.h(elem);
    sort(this.pv_1);
  };
  protoOf(PriorityQueue).tv = function (elem) {
    this.pv_1.h2(elem);
  };
  protoOf(PriorityQueue).uv = function () {
    return toImmutableList(this.pv_1);
  };
  protoOf(PriorityQueue).a2 = function () {
    this.pv_1.a2();
  };
  function Stack() {
    var tmp = this;
    // Inline function 'kotlin.collections.mutableListOf' call
    tmp.vv_1 = ArrayList_init_$Create$();
  }
  protoOf(Stack).o = function () {
    return this.vv_1.o();
  };
  protoOf(Stack).wv = function () {
    return this.vv_1.m();
  };
  protoOf(Stack).xv = function (index) {
    return this.vv_1.l(index);
  };
  protoOf(Stack).yv = function (item) {
    this.vv_1.h(item);
  };
  protoOf(Stack).zv = function () {
    if (this.vv_1.m()) {
      throw new EmptyStackException();
    }
    var obj = this.rv();
    this.vv_1.h3(this.vv_1.o() - 1 | 0);
    return obj;
  };
  protoOf(Stack).rv = function () {
    if (this.vv_1.m()) {
      throw new EmptyStackException();
    }
    return last_0(this.vv_1);
  };
  protoOf(Stack).aw = function () {
    return this.wv() ? null : last_0(this.vv_1);
  };
  protoOf(Stack).a2 = function () {
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = this.vv_1.i();
    while (_iterator__ex2g4s.j()) {
      var element = _iterator__ex2g4s.k();
      if (!(element == null) ? isInterface(element, Disposable) : false) {
        element.gs();
      }
    }
    this.vv_1.a2();
  };
  protoOf(Stack).ud = function (item) {
    return this.vv_1.n(item);
  };
  function EmptyStackException() {
    extendThrowable(this, 'empty stack');
    captureStack(this, EmptyStackException);
  }
  function explore($this, node, g, ordering, visited, expanded) {
    if (visited.n(node)) {
      if (expanded.n(node)) {
        return Unit_instance;
      }
      throw IllegalArgumentException_init_$Create$('Graph contains a cycle: ' + toString_0(node));
    }
    visited.h(node);
    var _iterator__ex2g4s = g.lv(node).i();
    while (_iterator__ex2g4s.j()) {
      var predecessor = _iterator__ex2g4s.k();
      explore($this, predecessor, g, ordering, visited, expanded);
    }
    ordering.h(node);
    expanded.h(node);
  }
  function reverseGraph($this, g) {
    var result = new DirectedGraph();
    var _iterator__ex2g4s = g.i();
    while (_iterator__ex2g4s.j()) {
      var node = _iterator__ex2g4s.k();
      result.jv(node);
    }
    var _iterator__ex2g4s_0 = g.i();
    while (_iterator__ex2g4s_0.j()) {
      var node_0 = _iterator__ex2g4s_0.k();
      var _iterator__ex2g4s_1 = g.lv(node_0).i();
      while (_iterator__ex2g4s_1.j()) {
        var endpoint = _iterator__ex2g4s_1.k();
        result.kv(endpoint, node_0);
      }
    }
    return result;
  }
  function TopologicalSort() {
  }
  protoOf(TopologicalSort).bw = function (g) {
    var gRev = reverseGraph(this, g);
    // Inline function 'kotlin.collections.mutableListOf' call
    var result = ArrayList_init_$Create$();
    // Inline function 'kotlin.collections.mutableSetOf' call
    var visited = LinkedHashSet_init_$Create$();
    // Inline function 'kotlin.collections.mutableSetOf' call
    var expanded = LinkedHashSet_init_$Create$();
    var _iterator__ex2g4s = gRev.i();
    while (_iterator__ex2g4s.j()) {
      var node = _iterator__ex2g4s.k();
      explore(this, node, gRev, result, visited, expanded);
    }
    return result;
  };
  var TopologicalSort_instance;
  function TopologicalSort_getInstance() {
    return TopologicalSort_instance;
  }
  function postError($this, metaData, msgKey, e) {
    BaseModule_getInstance().bp_1.gu(new IssueImpl(IssueSeverity_Error_getInstance(), Translations_getInstance().bn('base.dsl.scriptError.msg', []), e.toString(), metaData.cw_1, metaData.dw_1));
  }
  function AbstractBaseInterpreter(rootNode, memory) {
    memory = memory === VOID ? new Memory() : memory;
    this.ew_1 = rootNode;
    this.fw_1 = memory;
    this.gw_1 = null;
    this.hw_1 = null;
  }
  protoOf(AbstractBaseInterpreter).iw = function (node) {
    var tmp;
    if (node instanceof Compound) {
      tmp = this.kw(node);
    } else {
      throw new SyntaxError(node.jw(), Translations_getInstance().bn('base.dsl.unknownASTNode.msg', ['' + getKClassFromExpression(node).m9()]));
    }
    return tmp;
  };
  protoOf(AbstractBaseInterpreter).lw = function (params, keepMemory) {
    this.gw_1 = null;
    this.hw_1 = params;
    try {
      return this.iw(this.ew_1);
    }finally {
      if (!keepMemory) {
        this.fw_1.a2();
      }
    }
  };
  protoOf(AbstractBaseInterpreter).qw = function (params, keepMemory, $super) {
    params = params === VOID ? null : params;
    keepMemory = keepMemory === VOID ? false : keepMemory;
    return $super === VOID ? this.lw(params, keepMemory) : $super.lw.call(this, params, keepMemory);
  };
  protoOf(AbstractBaseInterpreter).rw = function (metaData, params, rethrow) {
    var tmp;
    try {
      tmp = this.qw(params);
    } catch ($p) {
      var tmp_0;
      if ($p instanceof DslError) {
        var e = $p;
        postError(this, metaData, 'base.dsl.scriptError.msg', e);
        if (rethrow) {
          throw e;
        }
        tmp_0 = Unit_instance;
      } else {
        if ($p instanceof Exception) {
          var e_0 = $p;
          postError(this, metaData, 'base.dsl.systemError.msg', e_0);
          if (rethrow) {
            throw e_0;
          }
          tmp_0 = Unit_instance;
        } else {
          throw $p;
        }
      }
      tmp = tmp_0;
    }
    return tmp;
  };
  protoOf(AbstractBaseInterpreter).sw = function (metaData, params, rethrow, $super) {
    params = params === VOID ? null : params;
    rethrow = rethrow === VOID ? false : rethrow;
    return $super === VOID ? this.rw(metaData, params, rethrow) : $super.rw.call(this, metaData, params, rethrow);
  };
  protoOf(AbstractBaseInterpreter).kw = function (node) {
    var result = 0n;
    var inductionVariable = 0;
    var last = node.uw_1.o();
    if (inductionVariable < last)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        result = this.iw(node.uw_1.l(i));
        if (!(this.gw_1 == null)) {
          return ensureNotNull(this.gw_1);
        }
      }
       while (inductionVariable < last);
    return result;
  };
  function ActivationRecord() {
  }
  function _get_LOG__e5r759_1($this) {
    var tmp0 = $this.gx_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('LOG', 1, tmp, BaseLexer$Companion$_get_LOG_$ref_95yvtn(), null);
    return tmp0.j2();
  }
  function BaseLexer$Companion$_get_LOG_$ref_95yvtn() {
    return function (p0) {
      return _get_LOG__e5r759_1(p0);
    };
  }
  function Companion_5() {
    Companion_instance_5 = this;
    this.gx_1 = logger(getKClass(BaseLexer));
    var tmp = this;
    // Inline function 'kotlin.collections.mapOf' call
    tmp.hx_1 = emptyMap();
    this.ix_1 = new Token(BaseTokenType_EOF_getInstance());
    this.jx_1 = new Token(BaseTokenType_EOL_getInstance());
    this.kx_1 = new Token(BaseTokenType_DOUBLE_QUOTE_getInstance());
  }
  protoOf(Companion_5).lx = function (value) {
    return new Token(BaseTokenType_ID_getInstance(), value);
  };
  protoOf(Companion_5).mx = function (value) {
    return new Token(BaseTokenType_LITERAL_getInstance(), value);
  };
  var Companion_instance_5;
  function Companion_getInstance_5() {
    if (Companion_instance_5 == null)
      new Companion_5();
    return Companion_instance_5;
  }
  function isComment($this, state) {
    var tmp;
    var tmp_0 = state.ox_1;
    if (equals(tmp_0 == null ? null : new Char(tmp_0), new Char(_Char___init__impl__6a9atx(47)))) {
      var tmp_1 = $this.yx(state);
      tmp = equals(tmp_1 == null ? null : new Char(tmp_1), new Char(_Char___init__impl__6a9atx(47)));
    } else {
      tmp = false;
    }
    return tmp;
  }
  function skipComment($this, state) {
    $l$loop: while (true) {
      var tmp;
      var tmp_0 = state.ox_1;
      if (!((tmp_0 == null ? null : new Char(tmp_0)) == null)) {
        var tmp_1 = state.ox_1;
        tmp = !equals(tmp_1 == null ? null : new Char(tmp_1), new Char(_Char___init__impl__6a9atx(10)));
      } else {
        tmp = false;
      }
      if (!tmp) {
        break $l$loop;
      }
      $this.zx(state);
    }
    $this.zx(state);
  }
  function isIdChar($this, c) {
    return isLetterOrDigit(c) || c === _Char___init__impl__6a9atx(95);
  }
  function quotedId($this, state) {
    var result = StringBuilder_init_$Create$();
    $this.zx(state);
    $l$loop: while (true) {
      var tmp;
      var tmp_0 = state.ox_1;
      if (!((tmp_0 == null ? null : new Char(tmp_0)) == null)) {
        var tmp_1 = state.ox_1;
        tmp = !equals(tmp_1 == null ? null : new Char(tmp_1), new Char(_Char___init__impl__6a9atx(39)));
      } else {
        tmp = false;
      }
      if (!tmp) {
        break $l$loop;
      }
      var tmp_2 = state.ox_1;
      result.h7(tmp_2 == null ? null : new Char(tmp_2));
      $this.zx(state);
    }
    var tmp_3 = state.ox_1;
    if (equals(tmp_3 == null ? null : new Char(tmp_3), new Char(_Char___init__impl__6a9atx(39)))) {
      $this.zx(state);
    } else {
      throw new SyntaxError(state.jw(), Translations_getInstance().bn('base.dsl.expectedSingleQuote.msg', []));
    }
    var id = result.toString();
    if (isBlank(id)) {
      throw new SyntaxError(state.jw(), Translations_getInstance().bn('base.dsl.emptyIdentifier.msg', []));
    }
    return Companion_getInstance_5().lx(id);
  }
  function isString($this, state) {
    var tmp = state.ox_1;
    return ensureNotNull(tmp == null ? null : new Char(tmp)).equals(new Char(_Char___init__impl__6a9atx(34)));
  }
  function string($this, state) {
    var result = StringBuilder_init_$Create$();
    $this.zx(state);
    $l$loop: while (true) {
      var tmp;
      var tmp_0 = state.ox_1;
      if (!((tmp_0 == null ? null : new Char(tmp_0)) == null)) {
        var tmp_1 = state.ox_1;
        tmp = !equals(tmp_1 == null ? null : new Char(tmp_1), new Char(_Char___init__impl__6a9atx(34)));
      } else {
        tmp = false;
      }
      if (!tmp) {
        break $l$loop;
      }
      var tmp_2 = state.ox_1;
      result.h7(tmp_2 == null ? null : new Char(tmp_2));
      $this.zx(state);
    }
    var tmp_3 = state.ox_1;
    if (equals(tmp_3 == null ? null : new Char(tmp_3), new Char(_Char___init__impl__6a9atx(34)))) {
      $this.zx(state);
    } else {
      throw new SyntaxError(state.jw(), Translations_getInstance().bn('base.dsl.expectedDoubleQuote.msg', []));
    }
    return result.toString();
  }
  function BaseLexer(text) {
    Companion_getInstance_5();
    AbstractLexer.call(this, text);
  }
  protoOf(BaseLexer).dy = function (state) {
    $l$loop_1: while (true) {
      var tmp = state.ox_1;
      if (!!((tmp == null ? null : new Char(tmp)) == null)) {
        break $l$loop_1;
      }
      if (this.fy(state)) {
        this.ey(state);
        continue $l$loop_1;
      }
      if (isComment(this, state)) {
        this.zx(state);
        this.zx(state);
        skipComment(this, state);
        continue $l$loop_1;
      }
      this.gy(state);
      var token = this.hy(state);
      if (_get_LOG__e5r759_1(Companion_getInstance_5()).sl() && state === this.xx_1) {
        _get_LOG__e5r759_1(Companion_getInstance_5()).ql(token.toString());
      }
      return token;
    }
    return Companion_getInstance_5().ix_1;
  };
  protoOf(BaseLexer).hy = function (state) {
    if (this.jy(state)) {
      return this.iy(state);
    }
    var tmp = state.ox_1;
    if (ensureNotNull(tmp == null ? null : new Char(tmp)).equals(new Char(_Char___init__impl__6a9atx(39)))) {
      return quotedId(this, state);
    }
    var tmp_0 = state.ox_1;
    if (isLetter(ensureNotNull(tmp_0 == null ? null : new Char(tmp_0)).j1_1)) {
      return this.ky(state);
    }
    var tmp_1 = state.ox_1;
    if (ensureNotNull(tmp_1 == null ? null : new Char(tmp_1)).j1_1 === _Char___init__impl__6a9atx(34))
      return this.ly(state, Companion_getInstance_5().kx_1);
    var tmp_2 = state.jw();
    var tmp_3 = Translations_getInstance();
    var tmp_4 = state.ox_1;
    throw new SyntaxError(tmp_2, tmp_3.bn('base.dsl.invalidCharacter.msg', [toString_0(tmp_4 == null ? null : new Char(tmp_4))]));
  };
  protoOf(BaseLexer).my = function (name) {
    return Companion_getInstance_5().hx_1.g2(name);
  };
  protoOf(BaseLexer).jy = function (state) {
    return this.ny(state) || isString(this, state);
  };
  protoOf(BaseLexer).iy = function (state) {
    var tmp;
    if (this.ny(state)) {
      tmp = this.oy(state);
    } else if (isString(this, state)) {
      tmp = Companion_getInstance_5().mx(string(this, state));
    } else {
      throw new SyntaxError(state.jw(), Translations_getInstance().bn('base.dsl.unknownLiteral.msg', []));
    }
    return tmp;
  };
  protoOf(BaseLexer).ny = function (state) {
    var tmp = state.ox_1;
    return isDigit(ensureNotNull(tmp == null ? null : new Char(tmp)).j1_1);
  };
  protoOf(BaseLexer).oy = function (state) {
    var result = StringBuilder_init_$Create$();
    $l$loop: while (true) {
      var tmp;
      var tmp_0 = state.ox_1;
      if (!((tmp_0 == null ? null : new Char(tmp_0)) == null)) {
        var tmp_1 = state.ox_1;
        tmp = isDigit(ensureNotNull(tmp_1 == null ? null : new Char(tmp_1)).j1_1);
      } else {
        tmp = false;
      }
      if (!tmp) {
        break $l$loop;
      }
      var tmp_2 = state.ox_1;
      result.h7(tmp_2 == null ? null : new Char(tmp_2));
      this.zx(state);
    }
    var tmp_3 = state.ox_1;
    if (equals(tmp_3 == null ? null : new Char(tmp_3), new Char(_Char___init__impl__6a9atx(46)))) {
      var tmp_4 = state.ox_1;
      result.h7(tmp_4 == null ? null : new Char(tmp_4));
      this.zx(state);
      $l$loop_0: while (true) {
        var tmp_5;
        var tmp_6 = state.ox_1;
        if (!((tmp_6 == null ? null : new Char(tmp_6)) == null)) {
          var tmp_7 = state.ox_1;
          tmp_5 = isDigit(ensureNotNull(tmp_7 == null ? null : new Char(tmp_7)).j1_1);
        } else {
          tmp_5 = false;
        }
        if (!tmp_5) {
          break $l$loop_0;
        }
        var tmp_8 = state.ox_1;
        result.h7(tmp_8 == null ? null : new Char(tmp_8));
        this.zx(state);
      }
      var tmp_9 = Companion_getInstance_5();
      // Inline function 'kotlin.text.toFloat' call
      var this_0 = result.toString();
      // Inline function 'kotlin.js.unsafeCast' call
      // Inline function 'kotlin.js.asDynamic' call
      var tmp$ret$0 = toDouble(this_0);
      return tmp_9.mx(tmp$ret$0);
    } else {
      return Companion_getInstance_5().mx(toLong(result.toString()));
    }
  };
  protoOf(BaseLexer).py = function (state) {
    var result = StringBuilder_init_$Create$();
    $l$loop: while (true) {
      var tmp;
      var tmp_0 = state.ox_1;
      if (!((tmp_0 == null ? null : new Char(tmp_0)) == null)) {
        var tmp_1 = state.ox_1;
        tmp = isDigit(ensureNotNull(tmp_1 == null ? null : new Char(tmp_1)).j1_1);
      } else {
        tmp = false;
      }
      if (!tmp) {
        break $l$loop;
      }
      var tmp_2 = state.ox_1;
      result.j7(ensureNotNull(tmp_2 == null ? null : new Char(tmp_2)).j1_1);
      this.zx(state);
    }
    try {
      return toLong(result.toString());
    } catch ($p) {
      if ($p instanceof NumberFormatException) {
        var e = $p;
        var tmp_3 = state.jw();
        var tmp_4 = Translations_getInstance();
        // Inline function 'kotlin.text.ifEmpty' call
        var tmp_5;
        // Inline function 'kotlin.text.isEmpty' call
        if (charSequenceLength(result) === 0) {
          var tmp_6 = state.ox_1;
          tmp_5 = tmp_6 == null ? null : new Char(tmp_6);
        } else {
          tmp_5 = result;
        }
        var tmp$ret$0 = tmp_5;
        throw new SyntaxError(tmp_3, tmp_4.bn('base.dsl.illegalNumber.msg', [toString_0(tmp$ret$0)]));
      } else {
        throw $p;
      }
    }
  };
  protoOf(BaseLexer).ky = function (state) {
    var result = StringBuilder_init_$Create$();
    $l$loop: while (true) {
      var tmp;
      var tmp_0 = state.ox_1;
      if (!((tmp_0 == null ? null : new Char(tmp_0)) == null)) {
        var tmp_1 = state.ox_1;
        tmp = isIdChar(this, ensureNotNull(tmp_1 == null ? null : new Char(tmp_1)).j1_1);
      } else {
        tmp = false;
      }
      if (!tmp) {
        break $l$loop;
      }
      var tmp_2 = state.ox_1;
      result.h7(tmp_2 == null ? null : new Char(tmp_2));
      this.zx(state);
    }
    var name = result.toString();
    var tmp0_elvis_lhs = this.my(name);
    return tmp0_elvis_lhs == null ? Companion_getInstance_5().lx(name) : tmp0_elvis_lhs;
  };
  var BaseTokenType_ID_instance;
  var BaseTokenType_LITERAL_instance;
  var BaseTokenType_EOF_instance;
  var BaseTokenType_EOL_instance;
  var BaseTokenType_DOUBLE_QUOTE_instance;
  var BaseTokenType_SINGLE_QUOTE_instance;
  var BaseTokenType_entriesInitialized;
  function BaseTokenType_initEntries() {
    if (BaseTokenType_entriesInitialized)
      return Unit_instance;
    BaseTokenType_entriesInitialized = true;
    BaseTokenType_ID_instance = new BaseTokenType('ID', 0, 'ID');
    BaseTokenType_LITERAL_instance = new BaseTokenType('LITERAL', 1, 'literal');
    BaseTokenType_EOF_instance = new BaseTokenType('EOF', 2, 'EOF');
    BaseTokenType_EOL_instance = new BaseTokenType('EOL', 3, 'EOL');
    BaseTokenType_DOUBLE_QUOTE_instance = new BaseTokenType('DOUBLE_QUOTE', 4, '"');
    BaseTokenType_SINGLE_QUOTE_instance = new BaseTokenType('SINGLE_QUOTE', 5, "'");
  }
  function BaseTokenType(name, ordinal, id) {
    Enum.call(this, name, ordinal);
    this.vy_1 = id;
  }
  protoOf(BaseTokenType).cv = function () {
    return this.vy_1;
  };
  function BaseTokenType_ID_getInstance() {
    BaseTokenType_initEntries();
    return BaseTokenType_ID_instance;
  }
  function BaseTokenType_LITERAL_getInstance() {
    BaseTokenType_initEntries();
    return BaseTokenType_LITERAL_instance;
  }
  function BaseTokenType_EOF_getInstance() {
    BaseTokenType_initEntries();
    return BaseTokenType_EOF_instance;
  }
  function BaseTokenType_EOL_getInstance() {
    BaseTokenType_initEntries();
    return BaseTokenType_EOL_instance;
  }
  function BaseTokenType_DOUBLE_QUOTE_getInstance() {
    BaseTokenType_initEntries();
    return BaseTokenType_DOUBLE_QUOTE_instance;
  }
  function Dsl() {
  }
  protoOf(Dsl).wy = function (script, symbolTable, memory) {
    var parser = BaseModule_getInstance().fp_1(script, BaseModule_getInstance().ep_1(symbolTable));
    var interpreter = BaseModule_getInstance().hp_1(parser.xy(), memory);
    return interpreter.qw();
  };
  var Dsl_instance;
  function Dsl_getInstance() {
    return Dsl_instance;
  }
  function SyntaxError(location, msg) {
    DslError.call(this, location, msg);
    captureStack(this, SyntaxError);
  }
  function DslError(location, msg) {
    extendThrowable(this, msg);
    captureStack(this, DslError);
    this.yy_1 = location;
  }
  protoOf(DslError).toString = function () {
    return Translations_getInstance().bn('base.dsl.error.msg', [ensureNotNull(this.message), this.yy_1]);
  };
  function SemanticError(location, msg) {
    DslError.call(this, location, msg);
    captureStack(this, SemanticError);
  }
  function RuntimeError(location, msg) {
    DslError.call(this, location, msg);
    captureStack(this, RuntimeError);
  }
  function longParam(index, params) {
    if (index >= params.o()) {
      throw new RuntimeError(Companion_getInstance_18().cx_1, Translations_getInstance().bn('base.dsl.notEnoughParameters.msg', []));
    }
    var param = params.l(index);
    if (!(typeof param === 'bigint')) {
      throw new RuntimeError(Companion_getInstance_18().cx_1, Translations_getInstance().bn('base.dsl.expectedNumberParameter.msg', [index + 1 | 0]));
    }
    return param;
  }
  function stringParam(index, params) {
    if (index >= params.o()) {
      throw new RuntimeError(Companion_getInstance_18().cx_1, Translations_getInstance().bn('base.dsl.notEnoughParameters.msg', []));
    }
    var param = params.l(index);
    if (!(typeof param === 'string')) {
      throw new RuntimeError(Companion_getInstance_18().cx_1, Translations_getInstance().bn('base.dsl.expectedStringParameter.msg', [index + 1 | 0]));
    }
    return param;
  }
  function anyParam(index, params) {
    if (index >= params.o()) {
      throw new RuntimeError(Companion_getInstance_18().cx_1, Translations_getInstance().bn('base.dsl.notEnoughParameters.msg', []));
    }
    return params.l(index);
  }
  function log2Impl($this, params, context) {
    context = context === VOID ? null : context;
    return log2_0($this, longParam(0, params));
  }
  function log2_0($this, value) {
    // Inline function 'kotlin.math.log2' call
    var x = toNumber(value);
    // Inline function 'kotlin.math.ceil' call
    var x_0 = log2(x);
    var tmp$ret$1 = Math.ceil(x_0);
    return numberToLong(tmp$ret$1);
  }
  function sam$io_antarescircuit_jabbah_base_dsl_ExternalFunction$0(function_0) {
    this.zy_1 = function_0;
  }
  protoOf(sam$io_antarescircuit_jabbah_base_dsl_ExternalFunction$0).az = function (params, context) {
    return this.zy_1(params, context);
  };
  protoOf(sam$io_antarescircuit_jabbah_base_dsl_ExternalFunction$0).p2 = function () {
    return this.zy_1;
  };
  protoOf(sam$io_antarescircuit_jabbah_base_dsl_ExternalFunction$0).equals = function (other) {
    var tmp;
    if (!(other == null) ? isInterface(other, ExternalFunction) : false) {
      var tmp_0;
      if (!(other == null) ? isInterface(other, FunctionAdapter) : false) {
        tmp_0 = equals(this.p2(), other.p2());
      } else {
        tmp_0 = false;
      }
      tmp = tmp_0;
    } else {
      tmp = false;
    }
    return tmp;
  };
  protoOf(sam$io_antarescircuit_jabbah_base_dsl_ExternalFunction$0).hashCode = function () {
    return hashCode(this.p2());
  };
  function DslGlobalFunctions$log2Impl$ref(p0) {
    var l = function (_this__u8e3s4, p0_0) {
      var tmp0 = p0;
      return log2Impl(tmp0, _this__u8e3s4, p0_0);
    };
    l.callableName = 'log2Impl';
    return l;
  }
  function DslGlobalFunctions() {
    var tmp = this;
    // Inline function 'kotlin.collections.mutableListOf' call
    tmp.bz_1 = ArrayList_init_$Create$();
    // Inline function 'kotlin.with' call
    this.bz_1.h('log2');
  }
  protoOf(DslGlobalFunctions).cz = function (symbolTable) {
    // Inline function 'kotlin.with' call
    var tmp = DslGlobalFunctions$log2Impl$ref(this);
    symbolTable.dz(new ExternalFunctionSymbol('log2', 1, new sam$io_antarescircuit_jabbah_base_dsl_ExternalFunction$0(tmp)));
  };
  function Companion_6() {
    Companion_instance_6 = this;
    this.ez_1 = new Token(DslTokenType_PLUS_getInstance());
    this.fz_1 = new Token(DslTokenType_MINUS_getInstance());
    this.gz_1 = new Token(DslTokenType_MULTIPLY_getInstance());
    this.hz_1 = new Token(DslTokenType_DIVIDE_getInstance());
    this.iz_1 = new Token(DslTokenType_LPAREN_getInstance());
    this.jz_1 = new Token(DslTokenType_RPAREN_getInstance());
    this.kz_1 = new Token(DslTokenType_ASSIGN_getInstance());
    this.lz_1 = new Token(DslTokenType_LCURLEY_getInstance());
    this.mz_1 = new Token(DslTokenType_RCURLEY_getInstance());
    this.nz_1 = new Token(DslTokenType_VAR_getInstance());
    this.oz_1 = new Token(DslTokenType_STORE_getInstance());
    this.pz_1 = new Token(DslTokenType_EQUAL_getInstance());
    this.qz_1 = new Token(DslTokenType_DIFF_getInstance());
    this.rz_1 = new Token(DslTokenType_IF_getInstance());
    this.sz_1 = new Token(DslTokenType_ELSE_getInstance());
    this.tz_1 = new Token(DslTokenType_AND_getInstance());
    this.uz_1 = new Token(DslTokenType_NAND_getInstance());
    this.vz_1 = new Token(DslTokenType_XOR_getInstance());
    this.wz_1 = new Token(DslTokenType_XNOR_getInstance());
    this.xz_1 = new Token(DslTokenType_OR_getInstance());
    this.yz_1 = new Token(DslTokenType_NOR_getInstance());
    this.zz_1 = new Token(DslTokenType_NOT_getInstance());
    this.a10_1 = new Token(DslTokenType_GREATER_getInstance());
    this.b10_1 = new Token(DslTokenType_GREATER_EQUAL_getInstance());
    this.c10_1 = new Token(DslTokenType_SMALLER_getInstance());
    this.d10_1 = new Token(DslTokenType_SMALLER_EQUAL_getInstance());
    this.e10_1 = new Token(DslTokenType_SHIFT_LEFT_getInstance());
    this.f10_1 = new Token(DslTokenType_SHIFT_RIGHT_getInstance());
    this.g10_1 = new Token(DslTokenType_MOD_getInstance());
    this.h10_1 = new Token(DslTokenType_WHEN_getInstance());
    this.i10_1 = new Token(DslTokenType_COLON_getInstance());
    this.j10_1 = new Token(DslTokenType_FOR_getInstance());
    this.k10_1 = new Token(DslTokenType_IN_getInstance());
    this.l10_1 = new Token(DslTokenType_TO_getInstance());
    this.m10_1 = new Token(DslTokenType_CARET_getInstance());
    this.n10_1 = new Token(DslTokenType_LEFT_BRACKET_getInstance());
    this.o10_1 = new Token(DslTokenType_RIGHT_BRACKET_getInstance());
    this.p10_1 = new Token(DslTokenType_QUESTION_MARK_getInstance());
    this.q10_1 = new Token(DslTokenType_RETURN_getInstance());
    this.r10_1 = new Token(DslTokenType_INIT_getInstance());
    this.s10_1 = new Token(DslTokenType_AT_getInstance());
    this.t10_1 = new Token(DslTokenType_HASH_getInstance());
    this.u10_1 = new Token(DslTokenType_DOT_getInstance());
    this.v10_1 = new Token(DslTokenType_COMMA_getInstance());
    this.w10_1 = mapOf([to('var', this.nz_1), to('store', this.oz_1), to('if', this.rz_1), to('else', this.sz_1), to('and', this.tz_1), to('nand', this.uz_1), to('xor', this.vz_1), to('xnor', this.wz_1), to('or', this.xz_1), to('nor', this.yz_1), to('not', this.zz_1), to('when', this.h10_1), to('for', this.j10_1), to('in', this.k10_1), to('to', this.l10_1), to('return', this.q10_1), to('init', this.r10_1)]);
  }
  protoOf(Companion_6).x10 = function () {
    return this.w10_1.b2();
  };
  var Companion_instance_6;
  function Companion_getInstance_6() {
    if (Companion_instance_6 == null)
      new Companion_6();
    return Companion_instance_6;
  }
  function isEqual($this, state) {
    var tmp;
    var tmp_0 = state.ox_1;
    if (equals(tmp_0 == null ? null : new Char(tmp_0), new Char(_Char___init__impl__6a9atx(61)))) {
      var tmp_1 = $this.yx(state);
      tmp = equals(tmp_1 == null ? null : new Char(tmp_1), new Char(_Char___init__impl__6a9atx(61)));
    } else {
      tmp = false;
    }
    return tmp;
  }
  function isDifferent($this, state) {
    var tmp;
    var tmp_0 = state.ox_1;
    if (equals(tmp_0 == null ? null : new Char(tmp_0), new Char(_Char___init__impl__6a9atx(33)))) {
      var tmp_1 = $this.yx(state);
      tmp = equals(tmp_1 == null ? null : new Char(tmp_1), new Char(_Char___init__impl__6a9atx(61)));
    } else {
      tmp = false;
    }
    return tmp;
  }
  function isSmallerEqual($this, state) {
    var tmp;
    var tmp_0 = state.ox_1;
    if (equals(tmp_0 == null ? null : new Char(tmp_0), new Char(_Char___init__impl__6a9atx(60)))) {
      var tmp_1 = $this.yx(state);
      tmp = equals(tmp_1 == null ? null : new Char(tmp_1), new Char(_Char___init__impl__6a9atx(61)));
    } else {
      tmp = false;
    }
    return tmp;
  }
  function isGreaterEqual($this, state) {
    var tmp;
    var tmp_0 = state.ox_1;
    if (equals(tmp_0 == null ? null : new Char(tmp_0), new Char(_Char___init__impl__6a9atx(62)))) {
      var tmp_1 = $this.yx(state);
      tmp = equals(tmp_1 == null ? null : new Char(tmp_1), new Char(_Char___init__impl__6a9atx(61)));
    } else {
      tmp = false;
    }
    return tmp;
  }
  function isShiftLeft($this, state) {
    var tmp;
    var tmp_0 = state.ox_1;
    if (equals(tmp_0 == null ? null : new Char(tmp_0), new Char(_Char___init__impl__6a9atx(60)))) {
      var tmp_1 = $this.yx(state);
      tmp = equals(tmp_1 == null ? null : new Char(tmp_1), new Char(_Char___init__impl__6a9atx(60)));
    } else {
      tmp = false;
    }
    return tmp;
  }
  function isShiftRight($this, state) {
    var tmp;
    var tmp_0 = state.ox_1;
    if (equals(tmp_0 == null ? null : new Char(tmp_0), new Char(_Char___init__impl__6a9atx(62)))) {
      var tmp_1 = $this.yx(state);
      tmp = equals(tmp_1 == null ? null : new Char(tmp_1), new Char(_Char___init__impl__6a9atx(62)));
    } else {
      tmp = false;
    }
    return tmp;
  }
  function equal($this, state) {
    $this.zx(state);
    $this.zx(state);
    return Companion_getInstance_6().pz_1;
  }
  function diff($this, state) {
    $this.zx(state);
    $this.zx(state);
    return Companion_getInstance_6().qz_1;
  }
  function smallerEqual($this, state) {
    $this.zx(state);
    $this.zx(state);
    return Companion_getInstance_6().d10_1;
  }
  function greaterEqual($this, state) {
    $this.zx(state);
    $this.zx(state);
    return Companion_getInstance_6().b10_1;
  }
  function shiftLeft_0($this, state) {
    $this.zx(state);
    $this.zx(state);
    return Companion_getInstance_6().e10_1;
  }
  function shiftRight_0($this, state) {
    $this.zx(state);
    $this.zx(state);
    return Companion_getInstance_6().f10_1;
  }
  function DslLexer(text) {
    Companion_getInstance_6();
    BaseLexer.call(this, text);
  }
  protoOf(DslLexer).my = function (name) {
    var tmp0_elvis_lhs = Companion_getInstance_6().w10_1.g2(name);
    return tmp0_elvis_lhs == null ? protoOf(BaseLexer).my.call(this, name) : tmp0_elvis_lhs;
  };
  protoOf(DslLexer).hy = function (state) {
    if (isEqual(this, state)) {
      return equal(this, state);
    }
    if (isDifferent(this, state)) {
      return diff(this, state);
    }
    if (isSmallerEqual(this, state)) {
      return smallerEqual(this, state);
    }
    if (isGreaterEqual(this, state)) {
      return greaterEqual(this, state);
    }
    if (isShiftLeft(this, state)) {
      return shiftLeft_0(this, state);
    }
    if (isShiftRight(this, state)) {
      return shiftRight_0(this, state);
    }
    var tmp = state.ox_1;
    var tmp0_subject = ensureNotNull(tmp == null ? null : new Char(tmp)).j1_1;
    if (tmp0_subject === _Char___init__impl__6a9atx(47))
      return this.ly(state, Companion_getInstance_6().hz_1);
    else if (tmp0_subject === _Char___init__impl__6a9atx(43))
      return this.ly(state, Companion_getInstance_6().ez_1);
    else if (tmp0_subject === _Char___init__impl__6a9atx(45))
      return this.ly(state, Companion_getInstance_6().fz_1);
    else if (tmp0_subject === _Char___init__impl__6a9atx(42))
      return this.ly(state, Companion_getInstance_6().gz_1);
    else if (tmp0_subject === _Char___init__impl__6a9atx(40))
      return this.ly(state, Companion_getInstance_6().iz_1);
    else if (tmp0_subject === _Char___init__impl__6a9atx(41))
      return this.ly(state, Companion_getInstance_6().jz_1);
    else if (tmp0_subject === _Char___init__impl__6a9atx(61))
      return this.ly(state, Companion_getInstance_6().kz_1);
    else if (tmp0_subject === _Char___init__impl__6a9atx(123))
      return this.ly(state, Companion_getInstance_6().lz_1);
    else if (tmp0_subject === _Char___init__impl__6a9atx(125))
      return this.ly(state, Companion_getInstance_6().mz_1);
    else if (tmp0_subject === _Char___init__impl__6a9atx(60))
      return this.ly(state, Companion_getInstance_6().c10_1);
    else if (tmp0_subject === _Char___init__impl__6a9atx(62))
      return this.ly(state, Companion_getInstance_6().a10_1);
    else if (tmp0_subject === _Char___init__impl__6a9atx(37))
      return this.ly(state, Companion_getInstance_6().g10_1);
    else if (tmp0_subject === _Char___init__impl__6a9atx(58))
      return this.ly(state, Companion_getInstance_6().i10_1);
    else if (tmp0_subject === _Char___init__impl__6a9atx(94))
      return this.ly(state, Companion_getInstance_6().m10_1);
    else if (tmp0_subject === _Char___init__impl__6a9atx(91))
      return this.ly(state, Companion_getInstance_6().n10_1);
    else if (tmp0_subject === _Char___init__impl__6a9atx(93))
      return this.ly(state, Companion_getInstance_6().o10_1);
    else if (tmp0_subject === _Char___init__impl__6a9atx(63))
      return this.ly(state, Companion_getInstance_6().p10_1);
    else if (tmp0_subject === _Char___init__impl__6a9atx(64))
      return this.ly(state, Companion_getInstance_6().s10_1);
    else if (tmp0_subject === _Char___init__impl__6a9atx(35))
      return this.ly(state, Companion_getInstance_6().t10_1);
    else if (tmp0_subject === _Char___init__impl__6a9atx(46))
      return this.ly(state, Companion_getInstance_6().u10_1);
    else if (tmp0_subject === _Char___init__impl__6a9atx(44))
      return this.ly(state, Companion_getInstance_6().v10_1);
    return protoOf(BaseLexer).hy.call(this, state);
  };
  function Companion_7() {
    Companion_instance_7 = this;
    this.b11_1 = setOf([DslTokenType_OR_getInstance(), DslTokenType_NOR_getInstance()]);
    this.c11_1 = setOf([DslTokenType_XOR_getInstance(), DslTokenType_XNOR_getInstance()]);
    this.d11_1 = setOf([DslTokenType_AND_getInstance(), DslTokenType_NAND_getInstance()]);
    this.e11_1 = setOf([DslTokenType_EQUAL_getInstance(), DslTokenType_DIFF_getInstance(), DslTokenType_SMALLER_getInstance(), DslTokenType_GREATER_getInstance(), DslTokenType_SMALLER_EQUAL_getInstance(), DslTokenType_GREATER_EQUAL_getInstance()]);
    this.f11_1 = setOf([DslTokenType_SHIFT_LEFT_getInstance(), DslTokenType_SHIFT_RIGHT_getInstance()]);
    this.g11_1 = plus(setOf([DslTokenType_MULTIPLY_getInstance(), DslTokenType_DIVIDE_getInstance(), DslTokenType_MOD_getInstance(), DslTokenType_CARET_getInstance()]), this.f11_1);
    this.h11_1 = setOf([DslTokenType_PLUS_getInstance(), DslTokenType_MINUS_getInstance()]);
  }
  var Companion_instance_7;
  function Companion_getInstance_7() {
    if (Companion_instance_7 == null)
      new Companion_7();
    return Companion_instance_7;
  }
  function statementList($this) {
    var node = $this.l11();
    var list = mutableListOf([node]);
    while (!equals(ensureNotNull($this.p11_1).m11_1, BaseTokenType_EOF_getInstance()) && !equals(ensureNotNull($this.p11_1).m11_1, DslTokenType_RCURLEY_getInstance())) {
      list.h($this.l11());
    }
    var tmp0_safe_receiver = lastOrNull(list);
    if (tmp0_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      if (tmp0_safe_receiver instanceof NoOp) {
        removeLast(list);
      }
    }
    return list;
  }
  function lookAheadFromLeftBracket($this) {
    var assocArray_0 = assocArray($this);
    var tmp;
    if (equals(ensureNotNull($this.p11_1).m11_1, DslTokenType_ASSIGN_getInstance())) {
      tmp = $this.q11(assocArray_0);
    } else {
      tmp = assocArray_0;
    }
    return tmp;
  }
  function assignment($this) {
    return $this.q11($this.r11());
  }
  function assocArray($this) {
    // Inline function 'kotlin.let' call
    var location = $this.o11_1.jw();
    var variable = $this.s11();
    $this.t11(DslTokenType_LEFT_BRACKET_getInstance());
    var expr_0 = expr($this);
    $this.t11(DslTokenType_RIGHT_BRACKET_getInstance());
    return new AssocArray(location, variable, expr_0);
  }
  function varDeclaration($this) {
    return declaration($this, DslTokenType_VAR_getInstance(), false);
  }
  function storeDeclaration($this) {
    return declaration($this, DslTokenType_STORE_getInstance(), true);
  }
  function declaration($this, tokenType, store) {
    // Inline function 'kotlin.let' call
    var location = $this.o11_1.jw();
    $this.t11(tokenType);
    var tmp;
    if (equals($this.o11_1.ry().m11_1, DslTokenType_ASSIGN_getInstance())) {
      var assignment_0 = assignment($this);
      tmp = new Declaration(location, assignment_0.v11_1, assignment_0.w11_1, store);
    } else {
      tmp = new Declaration(location, $this.r11(), null, store);
    }
    return tmp;
  }
  function ifStatement($this) {
    // Inline function 'kotlin.let' call
    var location = $this.o11_1.jw();
    $this.t11(DslTokenType_IF_getInstance());
    $this.t11(DslTokenType_LPAREN_getInstance());
    var condition = expr($this);
    $this.t11(DslTokenType_RPAREN_getInstance());
    var thenStatement = $this.l11();
    var elseStatement = null;
    if (equals(ensureNotNull($this.p11_1).m11_1, DslTokenType_ELSE_getInstance())) {
      $this.t11(DslTokenType_ELSE_getInstance());
      elseStatement = $this.l11();
    }
    return new IfStatement(location, condition, thenStatement, elseStatement);
  }
  function whenStatement($this) {
    // Inline function 'kotlin.let' call
    var location = $this.o11_1.jw();
    // Inline function 'kotlin.collections.mutableListOf' call
    var clauses = ArrayList_init_$Create$();
    $this.t11(DslTokenType_WHEN_getInstance());
    $this.t11(DslTokenType_LPAREN_getInstance());
    var expr_0 = expr($this);
    $this.t11(DslTokenType_RPAREN_getInstance());
    $this.t11(DslTokenType_LCURLEY_getInstance());
    $l$loop: while (!equals(ensureNotNull($this.p11_1).m11_1, BaseTokenType_EOF_getInstance()) && !equals(ensureNotNull($this.p11_1).m11_1, DslTokenType_RCURLEY_getInstance())) {
      if (equals(ensureNotNull($this.p11_1).m11_1, DslTokenType_ELSE_getInstance())) {
        clauses.h(whenElse($this));
        break $l$loop;
      } else {
        clauses.h(whenThen($this));
      }
    }
    $this.t11(DslTokenType_RCURLEY_getInstance());
    return new WhenStatement(location, expr_0, clauses);
  }
  function whenThen($this) {
    // Inline function 'kotlin.let' call
    var location = $this.o11_1.jw();
    var condition = expr($this);
    $this.t11(DslTokenType_COLON_getInstance());
    return new WhenClause(location, condition, $this.l11());
  }
  function whenElse($this) {
    // Inline function 'kotlin.let' call
    var location = $this.o11_1.jw();
    $this.t11(DslTokenType_ELSE_getInstance());
    $this.t11(DslTokenType_COLON_getInstance());
    return new WhenClause(location, null, $this.l11());
  }
  function forStatement($this) {
    // Inline function 'kotlin.let' call
    var location = $this.o11_1.jw();
    $this.t11(DslTokenType_FOR_getInstance());
    $this.t11(DslTokenType_LPAREN_getInstance());
    var variable = $this.r11();
    $this.t11(DslTokenType_IN_getInstance());
    var inExpr = expr($this);
    $this.t11(DslTokenType_TO_getInstance());
    var toExpr = expr($this);
    $this.t11(DslTokenType_RPAREN_getInstance());
    var statement = $this.l11();
    return new ForStatement(location, variable, inExpr, toExpr, statement);
  }
  function returnStatement($this) {
    // Inline function 'kotlin.let' call
    var location = $this.o11_1.jw();
    $this.t11(DslTokenType_RETURN_getInstance());
    return new ReturnStatement(location, isExpr($this) ? expr($this) : null);
  }
  function functionCall($this) {
    // Inline function 'kotlin.let' call
    var location = $this.o11_1.jw();
    var name = $this.s11();
    // Inline function 'kotlin.collections.mutableListOf' call
    var params = ArrayList_init_$Create$();
    $this.t11(DslTokenType_LPAREN_getInstance());
    if (!equals(ensureNotNull($this.p11_1).m11_1, DslTokenType_RPAREN_getInstance())) {
      params.h(expr($this));
    }
    while (equals(ensureNotNull($this.p11_1).m11_1, DslTokenType_COMMA_getInstance())) {
      $this.t11(DslTokenType_COMMA_getInstance());
      params.h(expr($this));
    }
    $this.t11(DslTokenType_RPAREN_getInstance());
    return new FunctionCall(location, name, params);
  }
  function empty($this) {
    return new NoOp($this.o11_1.jw());
  }
  function expr($this) {
    var node = expr1($this);
    while (contains(Companion_getInstance_7().b11_1, ensureNotNull($this.p11_1).m11_1)) {
      // Inline function 'kotlin.let' call
      var location = $this.o11_1.jw();
      var token = ensureNotNull($this.p11_1);
      if (contains(Companion_getInstance_7().b11_1, token.m11_1)) {
        $this.t11(token.m11_1);
      } else {
        throw new SyntaxError(location, Translations_getInstance().bn('base.dsl.unexpectedToken.msg', [token.m11_1.cv()]));
      }
      node = new BinaryOperation(location, node, token, expr1($this));
    }
    return node;
  }
  function isExpr($this) {
    return isTerm($this);
  }
  function expr1($this) {
    var node = expr1a($this);
    while (contains(Companion_getInstance_7().c11_1, ensureNotNull($this.p11_1).m11_1)) {
      // Inline function 'kotlin.let' call
      var location = $this.o11_1.jw();
      var token = ensureNotNull($this.p11_1);
      if (contains(Companion_getInstance_7().c11_1, token.m11_1)) {
        $this.t11(token.m11_1);
      } else {
        throw new SyntaxError(location, Translations_getInstance().bn('base.dsl.unexpectedToken.msg', [token.m11_1.cv()]));
      }
      node = new BinaryOperation(location, node, token, expr1a($this));
    }
    return node;
  }
  function expr1a($this) {
    var node = expr2($this);
    while (contains(Companion_getInstance_7().d11_1, ensureNotNull($this.p11_1).m11_1)) {
      // Inline function 'kotlin.let' call
      var location = $this.o11_1.jw();
      var token = ensureNotNull($this.p11_1);
      $this.t11(token.m11_1);
      node = new BinaryOperation(location, node, token, expr2($this));
    }
    return node;
  }
  function expr2($this) {
    var node = expr3($this);
    while (contains(Companion_getInstance_7().e11_1, ensureNotNull($this.p11_1).m11_1) || equals(ensureNotNull($this.p11_1).m11_1, DslTokenType_IN_getInstance())) {
      // Inline function 'kotlin.let' call
      var location = $this.o11_1.jw();
      var token = ensureNotNull($this.p11_1);
      if (equals(token.m11_1, DslTokenType_IN_getInstance())) {
        $this.t11(DslTokenType_IN_getInstance());
        node = new BinaryOperation(location, node, token, list($this));
      } else if (contains(Companion_getInstance_7().e11_1, token.m11_1)) {
        $this.t11(token.m11_1);
        node = new BinaryOperation(location, node, token, expr3($this));
      } else {
        throw new SyntaxError(location, Translations_getInstance().bn('base.dsl.unexpectedToken.msg', [token.m11_1.cv()]));
      }
    }
    return node;
  }
  function list($this) {
    // Inline function 'kotlin.let' call
    var location = $this.o11_1.jw();
    $this.t11(DslTokenType_LPAREN_getInstance());
    // Inline function 'kotlin.collections.mutableListOf' call
    var items = ArrayList_init_$Create$();
    if (!equals(ensureNotNull($this.p11_1).m11_1, DslTokenType_RPAREN_getInstance())) {
      items.h(expr($this));
      while (equals(ensureNotNull($this.p11_1).m11_1, DslTokenType_COMMA_getInstance())) {
        $this.t11(DslTokenType_COMMA_getInstance());
        items.h(expr($this));
      }
    }
    $this.t11(DslTokenType_RPAREN_getInstance());
    return new ListLiteral(location, items);
  }
  function expr3($this) {
    var node = term($this);
    while (contains(Companion_getInstance_7().h11_1, ensureNotNull($this.p11_1).m11_1)) {
      // Inline function 'kotlin.let' call
      var location = $this.o11_1.jw();
      var token = ensureNotNull($this.p11_1);
      if (contains(Companion_getInstance_7().h11_1, token.m11_1)) {
        $this.t11(token.m11_1);
      } else {
        throw new SyntaxError(location, Translations_getInstance().bn('base.dsl.unexpectedToken.msg', [token.m11_1.cv()]));
      }
      node = new BinaryOperation(location, node, token, term($this));
    }
    return node;
  }
  function term($this) {
    var node = $this.x11();
    while (contains(Companion_getInstance_7().g11_1, ensureNotNull($this.p11_1).m11_1)) {
      // Inline function 'kotlin.let' call
      var location = $this.o11_1.jw();
      var token = ensureNotNull($this.p11_1);
      if (contains(Companion_getInstance_7().g11_1, token.m11_1)) {
        $this.t11(token.m11_1);
      } else {
        throw new SyntaxError(location, Translations_getInstance().bn('base.dsl.unexpectedToken.msg', [token.m11_1.cv()]));
      }
      node = new BinaryOperation(location, node, token, $this.x11());
    }
    return node;
  }
  function isTerm($this) {
    return $this.y11();
  }
  function number($this) {
    var literal = new Literal($this.o11_1.jw(), ensureNotNull($this.p11_1));
    $this.t11(BaseTokenType_LITERAL_getInstance());
    return literal;
  }
  function string_0($this) {
    $this.t11(BaseTokenType_DOUBLE_QUOTE_getInstance());
    var string = new Literal($this.o11_1.jw(), ensureNotNull($this.p11_1));
    $this.t11(BaseTokenType_ID_getInstance());
    $this.t11(BaseTokenType_DOUBLE_QUOTE_getInstance());
    return string;
  }
  function DslParser(lexer, semanticAnalyser) {
    Companion_getInstance_7();
    semanticAnalyser = semanticAnalyser === VOID ? BaseModule_getInstance().ep_1(null) : semanticAnalyser;
    AbstractParser.call(this, lexer);
    this.k11_1 = semanticAnalyser;
  }
  protoOf(DslParser).xy = function () {
    // Inline function 'kotlin.also' call
    var this_0 = new Compound(this.o11_1.jw(), statementList(this));
    var tmp0_safe_receiver = this.k11_1;
    if (tmp0_safe_receiver == null)
      null;
    else {
      tmp0_safe_receiver.z11(this_0);
    }
    return this_0;
  };
  protoOf(DslParser).l11 = function () {
    var tmp0_subject = ensureNotNull(this.p11_1).m11_1;
    return equals(tmp0_subject, BaseTokenType_EOF_getInstance()) ? empty(this) : equals(tmp0_subject, BaseTokenType_ID_getInstance()) ? this.b12() : equals(tmp0_subject, DslTokenType_LCURLEY_getInstance()) ? this.a12() : equals(tmp0_subject, DslTokenType_RCURLEY_getInstance()) ? empty(this) : equals(tmp0_subject, DslTokenType_IF_getInstance()) ? ifStatement(this) : equals(tmp0_subject, DslTokenType_WHEN_getInstance()) ? whenStatement(this) : equals(tmp0_subject, DslTokenType_FOR_getInstance()) ? forStatement(this) : equals(tmp0_subject, DslTokenType_RETURN_getInstance()) ? returnStatement(this) : equals(tmp0_subject, DslTokenType_VAR_getInstance()) ? varDeclaration(this) : equals(tmp0_subject, DslTokenType_STORE_getInstance()) ? storeDeclaration(this) : expr(this);
  };
  protoOf(DslParser).b12 = function () {
    var tmp0_subject = this.o11_1.ry().m11_1;
    return equals(tmp0_subject, DslTokenType_ASSIGN_getInstance()) ? assignment(this) : equals(tmp0_subject, DslTokenType_LEFT_BRACKET_getInstance()) ? lookAheadFromLeftBracket(this) : expr(this);
  };
  protoOf(DslParser).q11 = function (variable) {
    // Inline function 'kotlin.let' call
    var location = this.o11_1.jw();
    this.t11(DslTokenType_ASSIGN_getInstance());
    var right = expr(this);
    return new Assignment(location, variable, right);
  };
  protoOf(DslParser).s11 = function () {
    var identifier = ensureNotNull(this.p11_1).c12();
    this.t11(BaseTokenType_ID_getInstance());
    return identifier;
  };
  protoOf(DslParser).r11 = function () {
    var tmp0_subject = this.o11_1.ry().m11_1;
    return equals(tmp0_subject, DslTokenType_LEFT_BRACKET_getInstance()) ? assocArray(this) : new Variable(this.o11_1.jw(), this.s11());
  };
  protoOf(DslParser).a12 = function () {
    // Inline function 'kotlin.let' call
    var location = this.o11_1.jw();
    this.t11(DslTokenType_LCURLEY_getInstance());
    var statementList_0 = statementList(this);
    this.t11(DslTokenType_RCURLEY_getInstance());
    return new Block(location, statementList_0);
  };
  protoOf(DslParser).x11 = function () {
    // Inline function 'kotlin.let' call
    var location = this.o11_1.jw();
    var token = ensureNotNull(this.p11_1);
    var tmp0_subject = token.m11_1;
    var tmp;
    if (equals(tmp0_subject, DslTokenType_PLUS_getInstance())) {
      this.t11(DslTokenType_PLUS_getInstance());
      return new UnaryOperation(location, token, this.x11());
    } else if (equals(tmp0_subject, DslTokenType_MINUS_getInstance())) {
      this.t11(DslTokenType_MINUS_getInstance());
      return new UnaryOperation(location, token, this.x11());
    } else if (equals(tmp0_subject, DslTokenType_NOT_getInstance())) {
      this.t11(DslTokenType_NOT_getInstance());
      return new UnaryOperation(location, token, this.x11());
    } else if (equals(tmp0_subject, BaseTokenType_LITERAL_getInstance()) || equals(tmp0_subject, BaseTokenType_DOUBLE_QUOTE_getInstance())) {
      tmp = this.d12();
    } else if (equals(tmp0_subject, DslTokenType_LPAREN_getInstance())) {
      this.t11(DslTokenType_LPAREN_getInstance());
      var node = expr(this);
      this.t11(DslTokenType_RPAREN_getInstance());
      tmp = node;
    } else if (equals(tmp0_subject, BaseTokenType_ID_getInstance())) {
      var tmp_0;
      if (equals(this.o11_1.ry().m11_1, DslTokenType_LPAREN_getInstance())) {
        tmp_0 = functionCall(this);
      } else {
        tmp_0 = this.r11();
      }
      tmp = tmp_0;
    } else {
      throw new SyntaxError(location, Translations_getInstance().bn('base.dsl.unexpectedToken.msg', [token.m11_1.cv()]));
    }
    return tmp;
  };
  protoOf(DslParser).y11 = function () {
    var tmp0_subject = ensureNotNull(this.p11_1).m11_1;
    return equals(tmp0_subject, DslTokenType_PLUS_getInstance()) ? true : equals(tmp0_subject, DslTokenType_MINUS_getInstance()) ? true : equals(tmp0_subject, DslTokenType_NOT_getInstance()) ? true : equals(tmp0_subject, BaseTokenType_LITERAL_getInstance()) ? true : equals(tmp0_subject, DslTokenType_LPAREN_getInstance()) ? true : equals(tmp0_subject, BaseTokenType_ID_getInstance()) ? true : false;
  };
  protoOf(DslParser).d12 = function () {
    var tmp0_subject = ensureNotNull(this.p11_1).m11_1;
    return equals(tmp0_subject, BaseTokenType_DOUBLE_QUOTE_getInstance()) ? string_0(this) : number(this);
  };
  function Visitor($outer) {
    this.f12_1 = $outer;
    EmptyHierarchyVisitor.call(this);
  }
  protoOf(Visitor).hs = function (node) {
    if (node instanceof Declaration) {
      this.f12_1.j12_1 = node.u12_1.l12_1.n11_1;
      enterDeclaration(this.f12_1, node);
    } else {
      if (node instanceof Assignment) {
        this.f12_1.j12_1 = node.v11_1.l12_1.n11_1;
        this.f12_1.s12(node);
      } else {
        if (node instanceof Block) {
          enterBlock(this.f12_1);
        } else {
          if (node instanceof ForStatement) {
            this.f12_1.j12_1 = node.o12_1.l12_1.n11_1;
            enterForStatement(this.f12_1, node);
          } else {
            if (node instanceof FunctionCall) {
              enterFunctionCall(this.f12_1, node);
            }
          }
        }
      }
    }
    return true;
  };
  protoOf(Visitor).is = function (node) {
    if (node instanceof Variable) {
      variable(this.f12_1, node);
    }
    return true;
  };
  protoOf(Visitor).ks = function (node) {
    if (node instanceof Declaration)
      this.f12_1.j12_1 = null;
    else {
      if (node instanceof Assignment)
        this.f12_1.j12_1 = null;
      else {
        if (node instanceof Block) {
          leaveBlock(this.f12_1);
        } else {
          if (node instanceof ForStatement)
            this.f12_1.j12_1 = null;
        }
      }
    }
    return true;
  };
  function enterDeclaration($this, declaration) {
    if (declaration.w12_1 && !$this.y12()) {
      throw new SemanticError(declaration.jw(), Translations_getInstance().bn('base.dsl.unexpectedStore.msg', []));
    }
    if (declaration.w12_1) {
      var tmp = declaration.u12_1.l12_1.n11_1;
      declareVariableInGlobalScope($this, (!(tmp == null) ? typeof tmp === 'string' : false) ? tmp : THROW_CCE(), declaration.jw());
    } else {
      var tmp_0 = declaration.u12_1.l12_1.n11_1;
      declareVariableInLocalScope($this, (!(tmp_0 == null) ? typeof tmp_0 === 'string' : false) ? tmp_0 : THROW_CCE(), declaration.jw());
    }
  }
  function declareVariableInLocalScope($this, name, location) {
    declareVariable($this, name, $this.h12_1, location);
  }
  function declareVariableInGlobalScope($this, name, location) {
    declareVariable($this, name, $this.g12_1, location);
  }
  function declareVariable($this, name, destinationScope, location) {
    var typeSymbol = (null == null ? true : null instanceof BuiltInTypeSymbol) ? null : THROW_CCE();
    var varSymbol = new VariableSymbol(name, typeSymbol);
    if (destinationScope.z12(name, true)) {
      throw new SemanticError(location, Translations_getInstance().bn('base.dsl.variableAlreadyDeclared.msg', [name]));
    }
    destinationScope.dz(varSymbol);
  }
  function enterForStatement($this, forStatement) {
    var tmp = forStatement.o12_1.l12_1.n11_1;
    declareVariableInLocalScope($this, (!(tmp == null) ? typeof tmp === 'string' : false) ? tmp : THROW_CCE(), forStatement.jw());
  }
  function enterBlock($this) {
    $this.h12_1 = new ScopedSymbolTable('block', $this.h12_1.a13() + 1 | 0, $this.h12_1);
  }
  function enterFunctionCall($this, functionCall) {
    var name = ensureNotNull(functionCall.c13_1.n11_1);
    var tmp0_elvis_lhs = $this.h12_1.f13(name);
    var tmp;
    if (tmp0_elvis_lhs == null) {
      throw new SemanticError(functionCall.jw(), Translations_getInstance().bn('base.dsl.functionNotDefined.msg', [name]));
    } else {
      tmp = tmp0_elvis_lhs;
    }
    var functionSymbol = tmp;
    if (!(functionSymbol instanceof ExternalFunctionSymbol)) {
      throw new SemanticError(functionCall.jw(), Translations_getInstance().bn('base.dsl.expectedFunction.msg', [name]));
    }
    if (!(functionCall.d13_1.o() === functionSymbol.i13_1)) {
      throw new SemanticError(functionCall.jw(), Translations_getInstance().bn('base.dsl.functionParamCount.msg', [name, functionSymbol.i13_1]));
    }
    functionCall.e13_1 = functionSymbol;
  }
  function leaveBlock($this) {
    var tmp0_safe_receiver = $this.h12_1.k13();
    if (tmp0_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      $this.h12_1 = tmp0_safe_receiver;
    }
  }
  function variable($this, variable) {
    var tmp = variable.l12_1.n11_1;
    var name = (!(tmp == null) ? typeof tmp === 'string' : false) ? tmp : THROW_CCE();
    if (!$this.h12_1.l13(name) && !($this.j12_1 === name)) {
      throw new SemanticError(variable.jw(), Translations_getInstance().bn('base.dsl.variableNotDefined.msg', [name]));
    }
  }
  function DslSemanticAnalyser(context) {
    this.g12_1 = new ScopedSymbolTable('global', 1, context);
    this.h12_1 = this.g12_1;
    this.i12_1 = this.m13();
    this.j12_1 = null;
  }
  protoOf(DslSemanticAnalyser).z11 = function (program) {
    program.n13(this.i12_1);
  };
  protoOf(DslSemanticAnalyser).m13 = function () {
    return new Visitor(this);
  };
  protoOf(DslSemanticAnalyser).y12 = function () {
    return this.h12_1.a13() <= 1;
  };
  protoOf(DslSemanticAnalyser).s12 = function (assignment) {
    var tmp = assignment.v11_1.l12_1.n11_1;
    var varName = (!(tmp == null) ? typeof tmp === 'string' : false) ? tmp : THROW_CCE();
    if (!this.h12_1.l13(varName)) {
      throw new SemanticError(assignment.v11_1.jw(), Translations_getInstance().bn('base.dsl.variableNotDefined.msg', [varName]));
    }
  };
  function _get_LOG__e5r759_2($this) {
    var tmp0 = $this.o13_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('LOG', 1, tmp, Interpreter$Companion$_get_LOG_$ref_rm1oyu(), null);
    return tmp0.j2();
  }
  function Interpreter$Companion$_get_LOG_$ref_rm1oyu() {
    return function (p0) {
      return _get_LOG__e5r759_2(p0);
    };
  }
  function Companion_8() {
    Companion_instance_8 = this;
    this.o13_1 = logger(getKClass(Interpreter));
  }
  var Companion_instance_8;
  function Companion_getInstance_8() {
    if (Companion_instance_8 == null)
      new Companion_8();
    return Companion_instance_8;
  }
  function interpretAsLong($this, node) {
    var result = $this.iw(node);
    if (!(typeof result === 'bigint')) {
      throw new RuntimeError(node.jw(), Translations_getInstance().bn('base.dsl.expectedNumber.msg', []));
    }
    return result;
  }
  function block($this, node) {
    $this.fw_1.t13('block');
    var result = $this.kw(node);
    $this.fw_1.u13(node);
    return result;
  }
  function literal($this, node) {
    return ensureNotNull(node.w13_1.n11_1);
  }
  function unaryOperation($this, node) {
    return unaryOpInterpreted($this, node.jw(), node.y13_1.m11_1, $this.iw(node.z13_1));
  }
  function unaryOpInterpreted($this, l, type, value) {
    var tmp;
    if (equals(type, DslTokenType_PLUS_getInstance())) {
      tmp = $this.c14(value, l);
    } else if (equals(type, DslTokenType_MINUS_getInstance())) {
      tmp = $this.b14(value, l);
    } else if (equals(type, DslTokenType_NOT_getInstance())) {
      tmp = $this.a14(value, l);
    } else {
      throw new SyntaxError(l, Translations_getInstance().bn('base.dsl.unknownUnaryOperation.msg', [type.cv()]));
    }
    return tmp;
  }
  function assignment_0($this, node) {
    if (!$this.fw_1.d14(node.v11_1)) {
      throw new RuntimeError(node.v11_1.jw(), Translations_getInstance().bn('base.dsl.variableNotDefined.msg', [ensureNotNull(node.v11_1.l12_1.n11_1)]));
    }
    return $this.e14(node.v11_1, $this.iw(node.w11_1));
  }
  function variable_0($this, node) {
    return $this.f14(node);
  }
  function declaration_0($this, node) {
    var tmp;
    if (node.w12_1) {
      tmp = declarationInStore($this, node);
    } else {
      tmp = declarationInScope($this, node);
    }
    return tmp;
  }
  function declarationInStore($this, node) {
    $this.fw_1.g14(node.u12_1, true);
    var tmp0_safe_receiver = node.v12_1;
    var tmp;
    if (tmp0_safe_receiver == null) {
      tmp = null;
    } else {
      // Inline function 'kotlin.let' call
      tmp = $this.iw(tmp0_safe_receiver);
    }
    var value = tmp;
    if (value == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      $this.e14(node.u12_1, value);
    }
    return value == null ? 0n : value;
  }
  function declarationInScope($this, node) {
    if (!$this.fw_1.h14(node.u12_1)) {
      $this.fw_1.g14(node.u12_1, false);
    }
    var tmp0_safe_receiver = node.v12_1;
    var tmp;
    if (tmp0_safe_receiver == null) {
      tmp = null;
    } else {
      // Inline function 'kotlin.let' call
      tmp = $this.iw(tmp0_safe_receiver);
    }
    var value = tmp;
    if (value == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      $this.e14(node.u12_1, value);
    }
    return value == null ? 0n : value;
  }
  function ifStatement_0($this, node) {
    if ($this.m14($this.iw(node.j14_1))) {
      return $this.iw(node.k14_1);
    }
    var tmp0_safe_receiver = node.l14_1;
    var tmp;
    if (tmp0_safe_receiver == null) {
      tmp = null;
    } else {
      // Inline function 'kotlin.let' call
      tmp = $this.iw(tmp0_safe_receiver);
    }
    var tmp1_elvis_lhs = tmp;
    return tmp1_elvis_lhs == null ? 0n : tmp1_elvis_lhs;
  }
  function whenStatement_0($this, node) {
    var expr = $this.iw(node.o14_1);
    var _iterator__ex2g4s = node.p14_1.i();
    while (_iterator__ex2g4s.j()) {
      var clause = _iterator__ex2g4s.k();
      if (clause.r14_1 == null || $this.m14($this.t14(expr, $this.iw(clause.r14_1), clause.jw()))) {
        return $this.iw(clause.s14_1);
      }
    }
    return 0n;
  }
  function forStatement_0($this, node) {
    var startValue = interpretAsLong($this, node.p12_1);
    var endValue = interpretAsLong($this, node.q12_1);
    $this.fw_1.t13('for');
    $this.fw_1.g14(node.o12_1, false);
    if (startValue <= endValue) {
      var inductionVariable = startValue;
      if (inductionVariable <= endValue)
        do {
          var value = inductionVariable;
          inductionVariable = add(inductionVariable, 1n);
          $this.fw_1.yw(node.o12_1, value);
          $this.iw(node.r12_1);
          var tmp0_safe_receiver = $this.gw_1;
          if (tmp0_safe_receiver == null)
            null;
          else {
            // Inline function 'kotlin.let' call
            return tmp0_safe_receiver;
          }
        }
         while (!(value === endValue));
    } else {
      var inductionVariable_0 = startValue;
      if (endValue <= inductionVariable_0)
        do {
          var value_0 = inductionVariable_0;
          inductionVariable_0 = add(inductionVariable_0, -1n);
          $this.fw_1.yw(node.o12_1, value_0);
          $this.iw(node.r12_1);
          var tmp1_safe_receiver = $this.gw_1;
          if (tmp1_safe_receiver == null)
            null;
          else {
            // Inline function 'kotlin.let' call
            return tmp1_safe_receiver;
          }
        }
         while (!(value_0 === endValue));
    }
    $this.fw_1.u13(node);
    return 0n;
  }
  function returnStatement_0($this, node) {
    var tmp = $this;
    var tmp0_safe_receiver = node.v14_1;
    var tmp_0;
    if (tmp0_safe_receiver == null) {
      tmp_0 = null;
    } else {
      // Inline function 'kotlin.let' call
      tmp_0 = $this.iw(tmp0_safe_receiver);
    }
    var tmp1_elvis_lhs = tmp_0;
    tmp.gw_1 = tmp1_elvis_lhs == null ? 0 : tmp1_elvis_lhs;
    return ensureNotNull($this.gw_1);
  }
  function functionCall_0($this, node, context) {
    if (node.e13_1 == null) {
      throw new RuntimeError(node.jw(), Translations_getInstance().bn('base.dsl.noImplementationOfFunction.msg', [ensureNotNull(node.c13_1.n11_1)]));
    }
    try {
      var tmp = ensureNotNull(node.e13_1).j13_1;
      // Inline function 'kotlin.collections.map' call
      var this_0 = node.d13_1;
      // Inline function 'kotlin.collections.mapTo' call
      var destination = ArrayList_init_$Create$_0(collectionSizeOrDefault(this_0, 10));
      var _iterator__ex2g4s = this_0.i();
      while (_iterator__ex2g4s.j()) {
        var item = _iterator__ex2g4s.k();
        var tmp$ret$2 = $this.iw(item);
        destination.h(tmp$ret$2);
      }
      return tmp.az(destination, context);
    } catch ($p) {
      if ($p instanceof RuntimeError) {
        var e = $p;
        throw new RuntimeError(node.jw(), ensureNotNull(e.message));
      } else {
        throw $p;
      }
    }
  }
  function Interpreter(rootNode, memory) {
    Companion_getInstance_8();
    memory = memory === VOID ? new Memory() : memory;
    AbstractBaseInterpreter.call(this, rootNode, memory);
  }
  protoOf(Interpreter).iw = function (node) {
    try {
      var tmp;
      if (node instanceof Block) {
        tmp = block(this, node);
      } else {
        if (node instanceof NoOp) {
          tmp = 0n;
        } else {
          if (node instanceof UnaryOperation) {
            tmp = unaryOperation(this, node);
          } else {
            if (node instanceof BinaryOperation) {
              tmp = this.y14(node);
            } else {
              if (node instanceof Literal) {
                tmp = literal(this, node);
              } else {
                if (node instanceof ListLiteral) {
                  // Inline function 'kotlin.collections.map' call
                  var this_0 = node.x14_1;
                  // Inline function 'kotlin.collections.mapTo' call
                  var destination = ArrayList_init_$Create$_0(collectionSizeOrDefault(this_0, 10));
                  var _iterator__ex2g4s = this_0.i();
                  while (_iterator__ex2g4s.j()) {
                    var item = _iterator__ex2g4s.k();
                    var tmp$ret$2 = this.iw(item);
                    destination.h(tmp$ret$2);
                  }
                  tmp = destination;
                } else {
                  if (node instanceof Assignment) {
                    tmp = assignment_0(this, node);
                  } else {
                    if (node instanceof Variable) {
                      tmp = variable_0(this, node);
                    } else {
                      if (node instanceof Declaration) {
                        tmp = declaration_0(this, node);
                      } else {
                        if (node instanceof IfStatement) {
                          tmp = ifStatement_0(this, node);
                        } else {
                          if (node instanceof WhenStatement) {
                            tmp = whenStatement_0(this, node);
                          } else {
                            if (node instanceof ForStatement) {
                              tmp = forStatement_0(this, node);
                            } else {
                              if (node instanceof ReturnStatement) {
                                tmp = returnStatement_0(this, node);
                              } else {
                                if (node instanceof FunctionCall) {
                                  tmp = functionCall_0(this, node, this.hw_1);
                                } else {
                                  tmp = protoOf(AbstractBaseInterpreter).iw.call(this, node);
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
      return tmp;
    } catch ($p) {
      if ($p instanceof DslError) {
        var e = $p;
        throw e;
      } else {
        if ($p instanceof Error) {
          var e_0 = $p;
          _get_LOG__e5r759_2(Companion_getInstance_8()).ll('Unexpected error in script interpretation', e_0);
          throw new RuntimeError(node.jw(), Translations_getInstance().bn('base.dsl.systemError.msg', []));
        } else {
          throw $p;
        }
      }
    }
  };
  protoOf(Interpreter).z14 = function (l, type) {
    throw new RuntimeError(l, Translations_getInstance().bn('base.dsl.incompatibleTypes.msg', [type.cv()]));
  };
  protoOf(Interpreter).y14 = function (node) {
    return this.e15(node.jw(), node.c15_1.m11_1, this.iw(node.b15_1), this.iw(node.d15_1));
  };
  protoOf(Interpreter).e15 = function (l, type, left, right) {
    var tmp;
    if (equals(type, DslTokenType_PLUS_getInstance())) {
      tmp = this.v15(left, right, l);
    } else if (equals(type, DslTokenType_MINUS_getInstance())) {
      tmp = this.u15(left, right, l);
    } else if (equals(type, DslTokenType_MULTIPLY_getInstance())) {
      tmp = this.t15(left, right, l);
    } else if (equals(type, DslTokenType_DIVIDE_getInstance())) {
      tmp = this.s15(left, right, l);
    } else if (equals(type, DslTokenType_CARET_getInstance())) {
      tmp = this.r15(left, right, l);
    } else if (equals(type, DslTokenType_EQUAL_getInstance())) {
      tmp = this.t14(left, right, l);
    } else if (equals(type, DslTokenType_DIFF_getInstance())) {
      tmp = equals(this.t14(left, right, l), 1n) ? 0n : 1n;
    } else if (equals(type, DslTokenType_IN_getInstance())) {
      tmp = this.q15(left, right, l);
    } else if (equals(type, DslTokenType_SMALLER_getInstance())) {
      tmp = this.p15(left, right, l);
    } else if (equals(type, DslTokenType_SMALLER_EQUAL_getInstance())) {
      tmp = equals(this.p15(left, right, l), 1n) || equals(this.t14(left, right, l), 1n) ? 1n : 0n;
    } else if (equals(type, DslTokenType_GREATER_getInstance())) {
      tmp = this.o15(left, right, l);
    } else if (equals(type, DslTokenType_GREATER_EQUAL_getInstance())) {
      tmp = equals(this.o15(left, right, l), 1n) || equals(this.t14(left, right, l), 1n) ? 1n : 0n;
    } else if (equals(type, DslTokenType_AND_getInstance())) {
      tmp = this.n15(left, right, l);
    } else if (equals(type, DslTokenType_NAND_getInstance())) {
      tmp = this.m15(left, right, l);
    } else if (equals(type, DslTokenType_XOR_getInstance())) {
      tmp = this.l15(left, right, l);
    } else if (equals(type, DslTokenType_XNOR_getInstance())) {
      tmp = this.k15(left, right, l);
    } else if (equals(type, DslTokenType_OR_getInstance())) {
      tmp = this.j15(left, right, l);
    } else if (equals(type, DslTokenType_NOR_getInstance())) {
      tmp = this.i15(left, right, l);
    } else if (equals(type, DslTokenType_SHIFT_LEFT_getInstance())) {
      tmp = this.h15(left, right, l);
    } else if (equals(type, DslTokenType_SHIFT_RIGHT_getInstance())) {
      tmp = this.g15(left, right, l);
    } else if (equals(type, DslTokenType_MOD_getInstance())) {
      tmp = this.f15(left, right, l);
    } else {
      throw new SyntaxError(l, Translations_getInstance().bn('base.dsl.unknownBinaryOperation.msg', [type.cv()]));
    }
    return tmp;
  };
  protoOf(Interpreter).q15 = function (value, list, loc) {
    if (!isInterface(list, KtList)) {
      this.z14(loc, DslTokenType_IN_getInstance());
    }
    var tmp;
    var tmp$ret$0;
    $l$block_0: {
      // Inline function 'kotlin.collections.any' call
      var tmp_0;
      if (isInterface(list, Collection)) {
        tmp_0 = list.m();
      } else {
        tmp_0 = false;
      }
      if (tmp_0) {
        tmp$ret$0 = false;
        break $l$block_0;
      }
      var _iterator__ex2g4s = list.i();
      while (_iterator__ex2g4s.j()) {
        var element = _iterator__ex2g4s.k();
        if (!(element == null) && equals(this.t14(value, element, loc), 1n)) {
          tmp$ret$0 = true;
          break $l$block_0;
        }
      }
      tmp$ret$0 = false;
    }
    if (tmp$ret$0) {
      tmp = 1n;
    } else {
      tmp = 0n;
    }
    return tmp;
  };
  protoOf(Interpreter).v15 = function (l, r, loc) {
    var tmp;
    if (typeof l === 'bigint') {
      tmp = this.x15(l, r, loc);
    } else {
      if (typeof l === 'number') {
        tmp = this.w15(l, r, loc);
      } else {
        this.z14(loc, DslTokenType_PLUS_getInstance());
      }
    }
    return tmp;
  };
  protoOf(Interpreter).x15 = function (l, r, loc) {
    var tmp;
    if (typeof r === 'bigint') {
      tmp = add(l, r);
    } else {
      if (typeof r === 'number') {
        // Inline function 'kotlin.Long.plus' call
        tmp = toNumber(l) + r;
      } else {
        this.z14(loc, DslTokenType_PLUS_getInstance());
      }
    }
    return tmp;
  };
  protoOf(Interpreter).w15 = function (l, r, loc) {
    var tmp;
    if (typeof r === 'bigint') {
      tmp = l + toNumber(r);
    } else {
      if (typeof r === 'number') {
        tmp = l + r;
      } else {
        this.z14(loc, DslTokenType_PLUS_getInstance());
      }
    }
    return tmp;
  };
  protoOf(Interpreter).u15 = function (l, r, loc) {
    var tmp;
    if (typeof l === 'bigint') {
      tmp = this.z15(l, r, loc);
    } else {
      if (typeof l === 'number') {
        tmp = this.y15(l, r, loc);
      } else {
        this.z14(loc, DslTokenType_MINUS_getInstance());
      }
    }
    return tmp;
  };
  protoOf(Interpreter).z15 = function (l, r, loc) {
    var tmp;
    if (typeof r === 'bigint') {
      tmp = subtract(l, r);
    } else {
      if (typeof r === 'number') {
        // Inline function 'kotlin.Long.minus' call
        tmp = toNumber(l) - r;
      } else {
        this.z14(loc, DslTokenType_MINUS_getInstance());
      }
    }
    return tmp;
  };
  protoOf(Interpreter).y15 = function (l, r, loc) {
    var tmp;
    if (typeof r === 'bigint') {
      tmp = l - toNumber(r);
    } else {
      if (typeof r === 'number') {
        tmp = l - r;
      } else {
        this.z14(loc, DslTokenType_MINUS_getInstance());
      }
    }
    return tmp;
  };
  protoOf(Interpreter).t15 = function (l, r, loc) {
    var tmp;
    if (typeof l === 'bigint') {
      tmp = this.b16(l, r, loc);
    } else {
      if (typeof l === 'number') {
        tmp = this.a16(l, r, loc);
      } else {
        this.z14(loc, DslTokenType_MULTIPLY_getInstance());
      }
    }
    return tmp;
  };
  protoOf(Interpreter).b16 = function (l, r, loc) {
    var tmp;
    if (typeof r === 'bigint') {
      tmp = multiply(l, r);
    } else {
      if (typeof r === 'number') {
        // Inline function 'kotlin.Long.times' call
        tmp = toNumber(l) * r;
      } else {
        this.z14(loc, DslTokenType_MULTIPLY_getInstance());
      }
    }
    return tmp;
  };
  protoOf(Interpreter).a16 = function (l, r, loc) {
    var tmp;
    if (typeof r === 'bigint') {
      tmp = l * toNumber(r);
    } else {
      if (typeof r === 'number') {
        tmp = l * r;
      } else {
        this.z14(loc, DslTokenType_MULTIPLY_getInstance());
      }
    }
    return tmp;
  };
  protoOf(Interpreter).s15 = function (l, r, loc) {
    var tmp;
    if (typeof l === 'bigint') {
      tmp = this.d16(l, r, loc);
    } else {
      if (typeof l === 'number') {
        tmp = this.c16(l, r, loc);
      } else {
        this.z14(loc, DslTokenType_DIVIDE_getInstance());
      }
    }
    return tmp;
  };
  protoOf(Interpreter).d16 = function (l, r, loc) {
    var tmp;
    if (typeof r === 'bigint') {
      tmp = divide(l, r);
    } else {
      if (typeof r === 'number') {
        // Inline function 'kotlin.Long.div' call
        tmp = toNumber(l) / r;
      } else {
        this.z14(loc, DslTokenType_DIVIDE_getInstance());
      }
    }
    return tmp;
  };
  protoOf(Interpreter).c16 = function (l, r, loc) {
    var tmp;
    if (typeof r === 'bigint') {
      tmp = l / toNumber(r);
    } else {
      if (typeof r === 'number') {
        tmp = l / r;
      } else {
        this.z14(loc, DslTokenType_DIVIDE_getInstance());
      }
    }
    return tmp;
  };
  protoOf(Interpreter).r15 = function (l, r, loc) {
    var tmp;
    if (typeof l === 'bigint') {
      tmp = this.f16(l, r, loc);
    } else {
      if (typeof l === 'number') {
        tmp = this.e16(l, r, loc);
      } else {
        this.z14(loc, DslTokenType_CARET_getInstance());
      }
    }
    return tmp;
  };
  protoOf(Interpreter).f16 = function (l, r, loc) {
    var tmp;
    if (typeof r === 'bigint') {
      var tmp0 = toNumber(l);
      // Inline function 'kotlin.math.pow' call
      var n = convertToInt(r);
      var tmp$ret$0 = Math.pow(tmp0, n);
      tmp = numberToLong(tmp$ret$0);
    } else {
      if (typeof r === 'number') {
        // Inline function 'kotlin.math.pow' call
        var this_0 = toNumber(l);
        tmp = Math.pow(this_0, r);
      } else {
        this.z14(loc, DslTokenType_CARET_getInstance());
      }
    }
    return tmp;
  };
  protoOf(Interpreter).e16 = function (l, r, loc) {
    var tmp;
    if (typeof r === 'bigint') {
      // Inline function 'kotlin.math.pow' call
      var n = convertToInt(r);
      tmp = Math.pow(l, n);
    } else {
      if (typeof r === 'number') {
        // Inline function 'kotlin.math.pow' call
        tmp = Math.pow(l, r);
      } else {
        this.z14(loc, DslTokenType_CARET_getInstance());
      }
    }
    return tmp;
  };
  protoOf(Interpreter).t14 = function (l, r, loc) {
    var tmp;
    if (typeof l === 'bigint') {
      tmp = this.h16(l, r, loc);
    } else {
      if (typeof l === 'number') {
        tmp = this.g16(l, r, loc);
      } else {
        this.z14(loc, DslTokenType_EQUAL_getInstance());
      }
    }
    return tmp;
  };
  protoOf(Interpreter).h16 = function (l, r, loc) {
    var tmp;
    if (typeof r === 'bigint') {
      tmp = equals(l, r) ? 1n : 0n;
    } else {
      if (typeof r === 'number') {
        tmp = toNumber(l) === r ? 1n : 0n;
      } else {
        this.z14(loc, DslTokenType_EQUAL_getInstance());
      }
    }
    return tmp;
  };
  protoOf(Interpreter).g16 = function (l, r, loc) {
    var tmp;
    if (typeof r === 'bigint') {
      tmp = l === toNumber(r) ? 1n : 0n;
    } else {
      if (typeof r === 'number') {
        tmp = l === r ? 1n : 0n;
      } else {
        this.z14(loc, DslTokenType_EQUAL_getInstance());
      }
    }
    return tmp;
  };
  protoOf(Interpreter).p15 = function (l, r, loc) {
    var tmp;
    if (typeof l === 'bigint') {
      tmp = this.j16(l, r, loc);
    } else {
      if (typeof l === 'number') {
        tmp = this.i16(l, r, loc);
      } else {
        this.z14(loc, DslTokenType_SMALLER_getInstance());
      }
    }
    return tmp;
  };
  protoOf(Interpreter).j16 = function (l, r, loc) {
    var tmp;
    if (typeof r === 'bigint') {
      tmp = l < r ? 1n : 0n;
    } else {
      if (typeof r === 'number') {
        tmp = toNumber(l) < r ? 1n : 0n;
      } else {
        this.z14(loc, DslTokenType_SMALLER_getInstance());
      }
    }
    return tmp;
  };
  protoOf(Interpreter).i16 = function (l, r, loc) {
    var tmp;
    if (typeof r === 'bigint') {
      tmp = l < toNumber(r) ? 1n : 0n;
    } else {
      if (typeof r === 'number') {
        tmp = l < r ? 1n : 0n;
      } else {
        this.z14(loc, DslTokenType_SMALLER_getInstance());
      }
    }
    return tmp;
  };
  protoOf(Interpreter).o15 = function (l, r, loc) {
    var tmp;
    if (typeof l === 'bigint') {
      tmp = this.l16(l, r, loc);
    } else {
      if (typeof l === 'number') {
        tmp = this.k16(l, r, loc);
      } else {
        this.z14(loc, DslTokenType_GREATER_getInstance());
      }
    }
    return tmp;
  };
  protoOf(Interpreter).l16 = function (l, r, loc) {
    var tmp;
    if (typeof r === 'bigint') {
      tmp = l > r ? 1n : 0n;
    } else {
      if (typeof r === 'number') {
        tmp = toNumber(l) > r ? 1n : 0n;
      } else {
        this.z14(loc, DslTokenType_GREATER_getInstance());
      }
    }
    return tmp;
  };
  protoOf(Interpreter).k16 = function (l, r, loc) {
    var tmp;
    if (typeof r === 'bigint') {
      tmp = l > toNumber(r) ? 1n : 0n;
    } else {
      if (typeof r === 'number') {
        tmp = l > r ? 1n : 0n;
      } else {
        this.z14(loc, DslTokenType_GREATER_getInstance());
      }
    }
    return tmp;
  };
  protoOf(Interpreter).n15 = function (l, r, loc) {
    var tmp;
    if (typeof l === 'bigint') {
      tmp = this.m16(l, r, loc);
    } else {
      this.z14(loc, DslTokenType_AND_getInstance());
    }
    return tmp;
  };
  protoOf(Interpreter).m16 = function (l, r, loc) {
    var tmp;
    if (typeof r === 'bigint') {
      tmp = l & r;
    } else {
      this.z14(loc, DslTokenType_AND_getInstance());
    }
    return tmp;
  };
  protoOf(Interpreter).j15 = function (l, r, loc) {
    var tmp;
    if (typeof l === 'bigint') {
      tmp = this.n16(l, r, loc);
    } else {
      this.z14(loc, DslTokenType_OR_getInstance());
    }
    return tmp;
  };
  protoOf(Interpreter).n16 = function (l, r, loc) {
    var tmp;
    if (typeof r === 'bigint') {
      tmp = l | r;
    } else {
      this.z14(loc, DslTokenType_OR_getInstance());
    }
    return tmp;
  };
  protoOf(Interpreter).m15 = function (l, r, loc) {
    return this.a14(this.n15(l, r, loc), loc);
  };
  protoOf(Interpreter).l15 = function (l, r, loc) {
    return this.n15(this.j15(l, r, loc), this.a14(this.n15(l, r, loc), loc), loc);
  };
  protoOf(Interpreter).k15 = function (l, r, loc) {
    return this.a14(this.l15(l, r, loc), loc);
  };
  protoOf(Interpreter).i15 = function (l, r, loc) {
    return this.a14(this.j15(l, r, loc), loc);
  };
  protoOf(Interpreter).h15 = function (l, r, loc) {
    var tmp;
    if (typeof l === 'bigint') {
      tmp = this.o16(l, r, loc);
    } else {
      this.z14(loc, DslTokenType_SHIFT_LEFT_getInstance());
    }
    return tmp;
  };
  protoOf(Interpreter).o16 = function (l, r, loc) {
    var tmp;
    if (typeof r === 'bigint') {
      tmp = shiftLeft(l, convertToInt(r));
    } else {
      this.z14(loc, DslTokenType_SHIFT_LEFT_getInstance());
    }
    return tmp;
  };
  protoOf(Interpreter).g15 = function (l, r, loc) {
    var tmp;
    if (typeof l === 'bigint') {
      tmp = this.p16(l, r, loc);
    } else {
      this.z14(loc, DslTokenType_SHIFT_RIGHT_getInstance());
    }
    return tmp;
  };
  protoOf(Interpreter).p16 = function (l, r, loc) {
    var tmp;
    if (typeof r === 'bigint') {
      tmp = shiftRight(l, convertToInt(r));
    } else {
      this.z14(loc, DslTokenType_SHIFT_RIGHT_getInstance());
    }
    return tmp;
  };
  protoOf(Interpreter).f15 = function (l, r, loc) {
    var tmp;
    if (typeof l === 'bigint') {
      tmp = this.q16(l, r, loc);
    } else {
      this.z14(loc, DslTokenType_MOD_getInstance());
    }
    return tmp;
  };
  protoOf(Interpreter).q16 = function (l, r, loc) {
    var tmp;
    if (typeof r === 'bigint') {
      // Inline function 'kotlin.mod' call
      var r_0 = modulo(l, r);
      tmp = add(r_0, r & shiftRight((r_0 ^ r) & (r_0 | negate(r_0)), 63));
    } else {
      this.z14(loc, DslTokenType_MOD_getInstance());
    }
    return tmp;
  };
  protoOf(Interpreter).c14 = function (value, loc) {
    var tmp;
    if (typeof value === 'bigint') {
      tmp = value;
    } else {
      if (typeof value === 'number') {
        tmp = value;
      } else {
        this.z14(loc, DslTokenType_PLUS_getInstance());
      }
    }
    return tmp;
  };
  protoOf(Interpreter).b14 = function (value, loc) {
    var tmp;
    if (typeof value === 'bigint') {
      tmp = negate(value);
    } else {
      if (typeof value === 'number') {
        tmp = -value;
      } else {
        this.z14(loc, DslTokenType_MINUS_getInstance());
      }
    }
    return tmp;
  };
  protoOf(Interpreter).a14 = function (value, loc) {
    var tmp;
    if (typeof value === 'bigint') {
      tmp = ~value;
    } else {
      this.z14(loc, DslTokenType_NOT_getInstance());
    }
    return tmp;
  };
  protoOf(Interpreter).e14 = function (variable, value) {
    if (variable instanceof AssocArray) {
      var assocArray = this.fw_1.dx(variable);
      var key = this.r16(variable);
      if (assocArray == null) {
        this.fw_1.yw(variable, mutableMapOf([to(key, value)]));
      } else {
        if (!isInterface(assocArray, KtMutableMap)) {
          throw new RuntimeError(this.ew_1.jw(), Translations_getInstance().bn('base.dsl.expectedArray.msg', [ensureNotNull(variable.l12_1.n11_1)]));
        }
        // Inline function 'kotlin.collections.set' call
        (isInterface(assocArray, KtMutableMap) ? assocArray : THROW_CCE()).y1(key, value);
      }
    } else {
      this.fw_1.yw(variable, value);
    }
    return value;
  };
  protoOf(Interpreter).f14 = function (variable) {
    var tmp;
    if (variable instanceof AssocArray) {
      var assocArray = this.fw_1.zw(variable);
      if (!isInterface(assocArray, KtMutableMap)) {
        throw new RuntimeError(this.ew_1.jw(), Translations_getInstance().bn('base.dsl.expectedArray.msg', [ensureNotNull(variable.l12_1.n11_1)]));
      }
      var key = this.r16(variable);
      // Inline function 'kotlin.collections.get' call
      var tmp0_elvis_lhs = (isInterface(assocArray, KtMap) ? assocArray : THROW_CCE()).g2(key);
      var tmp_0;
      if (tmp0_elvis_lhs == null) {
        throw new RuntimeError(this.ew_1.jw(), Translations_getInstance().bn('base.dsl.noArrayKeyValue.msg', []));
      } else {
        tmp_0 = tmp0_elvis_lhs;
      }
      tmp = tmp_0;
    } else {
      tmp = this.fw_1.zw(variable);
    }
    return tmp;
  };
  protoOf(Interpreter).r16 = function (variable) {
    var key = this.iw(variable.v16_1);
    if (!(typeof key === 'bigint')) {
      throw new RuntimeError(variable.jw(), Translations_getInstance().bn('base.dsl.arrayIndexMustBeNumeric.msg', []));
    }
    return key;
  };
  protoOf(Interpreter).m14 = function (value) {
    var tmp;
    if (typeof value === 'bigint') {
      tmp = !equals(value, 0n);
    } else {
      if (value instanceof ULong) {
        tmp = !equals(value, new ULong(_ULong___init__impl__c78o9k(0n)));
      } else {
        tmp = !equals(value, 0n);
      }
    }
    return tmp;
  };
  function _get_store__b8qga8($this) {
    var tmp = $this.nw_1;
    if (!(tmp == null))
      return tmp;
    else {
      throwUninitializedPropertyAccessException('store');
    }
  }
  function _get_global__v8eaew($this) {
    var tmp = $this.ow_1;
    if (!(tmp == null))
      return tmp;
    else {
      throwUninitializedPropertyAccessException('global');
    }
  }
  function Memory(context) {
    context = context === VOID ? null : context;
    this.mw_1 = context;
    this.pw_1 = new Stack();
    this.du();
  }
  protoOf(Memory).du = function () {
    this.pw_1.a2();
    this.nw_1 = BaseModule_getInstance().gp_1('Store', this.mw_1);
    this.ow_1 = BaseModule_getInstance().gp_1('Global', _get_store__b8qga8(this));
    var tmp0_safe_receiver = this.mw_1;
    if (tmp0_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      this.pw_1.yv(tmp0_safe_receiver);
    }
    this.pw_1.yv(_get_store__b8qga8(this));
    this.pw_1.yv(_get_global__v8eaew(this));
  };
  protoOf(Memory).a2 = function () {
    _get_global__v8eaew(this).a2();
    this.pw_1.a2();
    var tmp0_safe_receiver = this.mw_1;
    if (tmp0_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      this.pw_1.yv(tmp0_safe_receiver);
    }
    this.pw_1.yv(_get_global__v8eaew(this));
  };
  protoOf(Memory).t13 = function (name) {
    this.pw_1.yv(BaseModule_getInstance().gp_1(name, this.pw_1.aw()));
  };
  protoOf(Memory).u13 = function (node) {
    if (this.pw_1.rv() === _get_global__v8eaew(this)) {
      throw new RuntimeError(node.jw(), Translations_getInstance().bn('base.dsl.cannotExitGlobalScope.msg', []));
    }
    this.pw_1.zv();
  };
  protoOf(Memory).g14 = function (variable, inStore) {
    if (inStore) {
      if (!_get_store__b8qga8(this).ww(ensureNotNull(variable.l12_1.n11_1))) {
        _get_store__b8qga8(this).xw(variable);
      }
    } else {
      this.pw_1.rv().xw(variable);
    }
  };
  protoOf(Memory).d14 = function (variable) {
    return this.pw_1.rv().ww(ensureNotNull(variable.l12_1.n11_1));
  };
  protoOf(Memory).h14 = function (variable) {
    return this.pw_1.rv().vw(ensureNotNull(variable.l12_1.n11_1));
  };
  protoOf(Memory).yw = function (variable, value) {
    this.pw_1.rv().yw(variable, value);
  };
  protoOf(Memory).zw = function (variable) {
    return this.pw_1.rv().zw(variable);
  };
  protoOf(Memory).dx = function (variable) {
    return this.pw_1.rv().dx(variable);
  };
  function ScriptMetaData(origin, context) {
    this.cw_1 = origin;
    this.dw_1 = context;
  }
  protoOf(ScriptMetaData).toString = function () {
    return 'ScriptMetaData(origin=' + this.cw_1 + ', context=' + this.dw_1 + ')';
  };
  protoOf(ScriptMetaData).hashCode = function () {
    var result = getStringHashCode(this.cw_1);
    result = imul(result, 31) + getStringHashCode(this.dw_1) | 0;
    return result;
  };
  protoOf(ScriptMetaData).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof ScriptMetaData))
      return false;
    if (!(this.cw_1 === other.cw_1))
      return false;
    if (!(this.dw_1 === other.dw_1))
      return false;
    return true;
  };
  function StoringActivationRecord(name, parent) {
    this.w16_1 = name;
    this.x16_1 = parent;
    var tmp = this;
    // Inline function 'kotlin.collections.mutableMapOf' call
    tmp.y16_1 = LinkedHashMap_init_$Create$();
  }
  protoOf(StoringActivationRecord).a2 = function () {
    this.y16_1.a2();
  };
  protoOf(StoringActivationRecord).vw = function (name) {
    return this.y16_1.e2(name);
  };
  protoOf(StoringActivationRecord).ww = function (name) {
    var tmp;
    if (this.vw(name)) {
      tmp = true;
    } else {
      var tmp0_safe_receiver = this.x16_1;
      tmp = (tmp0_safe_receiver == null ? null : tmp0_safe_receiver.ww(name)) === true;
    }
    return tmp;
  };
  protoOf(StoringActivationRecord).xw = function (variable) {
    if (this.vw(ensureNotNull(variable.l12_1.n11_1))) {
      throw new RuntimeError(variable.jw(), Translations_getInstance().bn('base.dsl.variableAlreadyDeclared.msg', [variable.l12_1.n11_1]));
    }
    var tmp0 = this.y16_1;
    // Inline function 'kotlin.collections.set' call
    var key = variable.l12_1.n11_1;
    tmp0.y1(key, null);
  };
  protoOf(StoringActivationRecord).yw = function (variable, value) {
    if (this.vw(ensureNotNull(variable.l12_1.n11_1))) {
      this.z16(variable, value);
    } else if (!(this.x16_1 == null)) {
      this.x16_1.yw(variable, value);
    } else
      throw new RuntimeError(variable.jw(), Translations_getInstance().bn('base.dsl.variableNotDefined.msg', [variable.l12_1.n11_1]));
  };
  protoOf(StoringActivationRecord).z16 = function (variable, value) {
    var tmp0 = this.y16_1;
    // Inline function 'kotlin.collections.set' call
    var key = ensureNotNull(variable.l12_1.n11_1);
    tmp0.y1(key, value);
  };
  protoOf(StoringActivationRecord).zw = function (variable) {
    return this.ax(ensureNotNull(variable.l12_1.n11_1), variable.jw());
  };
  protoOf(StoringActivationRecord).ax = function (name, location) {
    var tmp;
    if (this.vw(name)) {
      var tmp0_elvis_lhs = this.y16_1.g2(name);
      var tmp_0;
      if (tmp0_elvis_lhs == null) {
        throw new RuntimeError(Companion_getInstance_18().cx_1, Translations_getInstance().bn('base.dsl.noValueForVariable.msg', [name]));
      } else {
        tmp_0 = tmp0_elvis_lhs;
      }
      tmp = tmp_0;
    } else if (!(this.x16_1 == null)) {
      tmp = this.x16_1.bx(name);
    } else {
      throw new RuntimeError(Companion_getInstance_18().cx_1, Translations_getInstance().bn('base.dsl.variableNotDefined.msg', [name]));
    }
    return tmp;
  };
  protoOf(StoringActivationRecord).dx = function (variable) {
    return this.ex(ensureNotNull(variable.l12_1.n11_1), variable.jw());
  };
  protoOf(StoringActivationRecord).ex = function (name, location) {
    var tmp;
    if (this.vw(name)) {
      tmp = this.y16_1.g2(name);
    } else {
      var tmp0_safe_receiver = this.x16_1;
      tmp = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.ex(name, location);
    }
    return tmp;
  };
  function Symbol(name, type) {
    type = type === VOID ? null : type;
    this.a17_1 = name;
    this.b17_1 = type;
  }
  function BuiltInTypeSymbol(name) {
    Symbol.call(this, name);
  }
  function VariableSymbol(name, type) {
    Symbol.call(this, name, type);
  }
  function ExternalFunctionSymbol(name, paramsCount, function_0) {
    Symbol.call(this, name);
    this.i13_1 = paramsCount;
    this.j13_1 = function_0;
  }
  function ExternalFunction() {
  }
  function SymbolTable() {
  }
  function ScopedSymbolTable(name, scopeLevel, enclosingScope) {
    this.e17_1 = name;
    this.f17_1 = scopeLevel;
    this.g17_1 = enclosingScope;
    var tmp = this;
    // Inline function 'kotlin.collections.mutableMapOf' call
    tmp.h17_1 = LinkedHashMap_init_$Create$();
    if (this.f17_1 <= 1) {
      // Inline function 'kotlin.collections.forEach' call
      var _iterator__ex2g4s = Companion_getInstance_6().x10().i();
      while (_iterator__ex2g4s.j()) {
        var element = _iterator__ex2g4s.k();
        this.dz(new BuiltInTypeSymbol(element));
      }
      BaseModule_getInstance().ip_1.cz(this);
    }
  }
  protoOf(ScopedSymbolTable).a13 = function () {
    return this.f17_1;
  };
  protoOf(ScopedSymbolTable).k13 = function () {
    return this.g17_1;
  };
  protoOf(ScopedSymbolTable).toString = function () {
    return 'Scope ' + this.e17_1 + ' at level ' + this.f17_1;
  };
  protoOf(ScopedSymbolTable).dz = function (symbol) {
    var tmp0 = this.h17_1;
    // Inline function 'kotlin.collections.set' call
    var key = symbol.a17_1;
    tmp0.y1(key, symbol);
  };
  protoOf(ScopedSymbolTable).z12 = function (name, currentScopeOnly) {
    if (currentScopeOnly) {
      return this.h17_1.e2(name);
    }
    var tmp;
    if (this.h17_1.e2(name)) {
      tmp = true;
    } else {
      var tmp0_safe_receiver = this.g17_1;
      tmp = (tmp0_safe_receiver == null ? null : tmp0_safe_receiver.l13(name)) === true;
    }
    return tmp;
  };
  protoOf(ScopedSymbolTable).c17 = function (name, currentScopeOnly) {
    if (currentScopeOnly) {
      return this.h17_1.g2(name);
    }
    var tmp0_elvis_lhs = this.h17_1.g2(name);
    var tmp;
    if (tmp0_elvis_lhs == null) {
      var tmp1_safe_receiver = this.g17_1;
      tmp = tmp1_safe_receiver == null ? null : tmp1_safe_receiver.f13(name);
    } else {
      tmp = tmp0_elvis_lhs;
    }
    return tmp;
  };
  protoOf(ScopedSymbolTable).d17 = function (name) {
    if (this.z12(name, true)) {
      return true;
    }
    var tmp0_safe_receiver = this.g17_1;
    var tmp1_elvis_lhs = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.d17(name);
    return tmp1_elvis_lhs == null ? false : tmp1_elvis_lhs;
  };
  function Compound(location, children) {
    AbstractNode.call(this, location);
    this.uw_1 = children;
  }
  protoOf(Compound).toString = function () {
    return 'Compound';
  };
  protoOf(Compound).n13 = function (visitor) {
    if (visitor.hs(this)) {
      var _iterator__ex2g4s = this.uw_1.i();
      $l$loop: while (_iterator__ex2g4s.j()) {
        var child = _iterator__ex2g4s.k();
        if (!child.n13(visitor)) {
          break $l$loop;
        }
      }
    }
    return visitor.ks(this);
  };
  function AbstractNode(location) {
    this.x12_1 = location;
  }
  protoOf(AbstractNode).jw = function () {
    return this.x12_1;
  };
  protoOf(AbstractNode).n13 = function (visitor) {
    return visitor.is(this);
  };
  function Declaration(location, left, right, store) {
    AbstractNode.call(this, location);
    this.u12_1 = left;
    this.v12_1 = right;
    this.w12_1 = store;
  }
  protoOf(Declaration).toString = function () {
    return this.w12_1 ? 'store' : 'var';
  };
  protoOf(Declaration).n13 = function (visitor) {
    if (visitor.hs(this)) {
      this.u12_1.n13(visitor);
      var tmp0_safe_receiver = this.v12_1;
      if (tmp0_safe_receiver == null)
        null;
      else
        tmp0_safe_receiver.n13(visitor);
    }
    return visitor.ks(this);
  };
  function Variable(location, token, negated) {
    negated = negated === VOID ? false : negated;
    AbstractNode.call(this, location);
    this.l12_1 = token;
    this.m12_1 = negated;
  }
  protoOf(Variable).toString = function () {
    return ensureNotNull(this.l12_1.n11_1);
  };
  protoOf(Variable).n13 = function (visitor) {
    return visitor.is(this);
  };
  function Assignment(location, left, right) {
    AbstractNode.call(this, location);
    this.v11_1 = left;
    this.w11_1 = right;
  }
  protoOf(Assignment).toString = function () {
    return '=';
  };
  protoOf(Assignment).n13 = function (visitor) {
    if (visitor.hs(this)) {
      this.v11_1.n13(visitor);
      this.w11_1.n13(visitor);
    }
    return visitor.ks(this);
  };
  function Block(location, children) {
    Compound.call(this, location, children);
  }
  protoOf(Block).toString = function () {
    return 'Block';
  };
  function ForStatement(location, variable, inExpr, toExpr, statement) {
    AbstractNode.call(this, location);
    this.o12_1 = variable;
    this.p12_1 = inExpr;
    this.q12_1 = toExpr;
    this.r12_1 = statement;
  }
  protoOf(ForStatement).toString = function () {
    return 'for';
  };
  protoOf(ForStatement).n13 = function (visitor) {
    if (visitor.hs(this)) {
      this.o12_1.n13(visitor);
      this.p12_1.n13(visitor);
      this.q12_1.n13(visitor);
      this.r12_1.n13(visitor);
    }
    return visitor.ks(this);
  };
  function FunctionCall(location, name, params, function_0) {
    function_0 = function_0 === VOID ? null : function_0;
    AbstractNode.call(this, location);
    this.c13_1 = name;
    this.d13_1 = params;
    this.e13_1 = function_0;
  }
  protoOf(FunctionCall).toString = function () {
    return '' + this.c13_1.n11_1 + '()';
  };
  protoOf(FunctionCall).n13 = function (visitor) {
    if (visitor.hs(this)) {
      var _iterator__ex2g4s = this.d13_1.i();
      $l$loop: while (_iterator__ex2g4s.j()) {
        var param = _iterator__ex2g4s.k();
        if (!param.n13(visitor)) {
          break $l$loop;
        }
      }
    }
    return visitor.ks(this);
  };
  function NoOp(location) {
    AbstractNode.call(this, location);
  }
  protoOf(NoOp).toString = function () {
    return 'NoOp';
  };
  function AssocArray(location, token, key) {
    Variable.call(this, location, token);
    this.v16_1 = key;
  }
  protoOf(AssocArray).toString = function () {
    return protoOf(Variable).toString.call(this) + '[]';
  };
  protoOf(AssocArray).n13 = function (visitor) {
    if (visitor.hs(this)) {
      this.v16_1.n13(visitor);
    }
    return visitor.ks(this);
  };
  function IfStatement(location, condition, thenStatement, elseStatement) {
    AbstractNode.call(this, location);
    this.j14_1 = condition;
    this.k14_1 = thenStatement;
    this.l14_1 = elseStatement;
  }
  protoOf(IfStatement).toString = function () {
    return 'if';
  };
  protoOf(IfStatement).n13 = function (visitor) {
    if (visitor.hs(this)) {
      this.j14_1.n13(visitor);
      this.k14_1.n13(visitor);
      var tmp0_safe_receiver = this.l14_1;
      if (tmp0_safe_receiver == null)
        null;
      else
        tmp0_safe_receiver.n13(visitor);
    }
    return visitor.ks(this);
  };
  function WhenClause(location, condition, then) {
    AbstractNode.call(this, location);
    this.r14_1 = condition;
    this.s14_1 = then;
  }
  protoOf(WhenClause).toString = function () {
    var tmp;
    if (this.r14_1 == null) {
      tmp = null;
    } else {
      // Inline function 'kotlin.let' call
      tmp = ':';
    }
    var tmp1_elvis_lhs = tmp;
    return tmp1_elvis_lhs == null ? 'else' : tmp1_elvis_lhs;
  };
  protoOf(WhenClause).n13 = function (visitor) {
    if (visitor.hs(this)) {
      var tmp0_safe_receiver = this.r14_1;
      if (tmp0_safe_receiver == null)
        null;
      else
        tmp0_safe_receiver.n13(visitor);
      this.s14_1.n13(visitor);
    }
    return visitor.ks(this);
  };
  function WhenStatement(location, expression, clauses) {
    AbstractNode.call(this, location);
    this.o14_1 = expression;
    this.p14_1 = clauses;
  }
  protoOf(WhenStatement).toString = function () {
    return 'when';
  };
  protoOf(WhenStatement).n13 = function (visitor) {
    if (visitor.hs(this)) {
      this.o14_1.n13(visitor);
      var _iterator__ex2g4s = this.p14_1.i();
      $l$loop: while (_iterator__ex2g4s.j()) {
        var clause = _iterator__ex2g4s.k();
        if (!clause.n13(visitor)) {
          break $l$loop;
        }
      }
    }
    return visitor.ks(this);
  };
  function ReturnStatement(location, expr) {
    AbstractNode.call(this, location);
    this.v14_1 = expr;
  }
  protoOf(ReturnStatement).toString = function () {
    return 'return';
  };
  protoOf(ReturnStatement).n13 = function (visitor) {
    if (visitor.hs(this)) {
      var tmp0_safe_receiver = this.v14_1;
      if (tmp0_safe_receiver == null)
        null;
      else
        tmp0_safe_receiver.n13(visitor);
    }
    return visitor.ks(this);
  };
  function BinaryOperation(location, left, op, right) {
    AbstractNode.call(this, location);
    this.b15_1 = left;
    this.c15_1 = op;
    this.d15_1 = right;
  }
  protoOf(BinaryOperation).toString = function () {
    return this.c15_1.m11_1.cv();
  };
  protoOf(BinaryOperation).n13 = function (visitor) {
    if (visitor.hs(this)) {
      this.b15_1.n13(visitor);
      visitor.js(this, this.b15_1);
      this.d15_1.n13(visitor);
    }
    return visitor.ks(this);
  };
  function ListLiteral(location, items) {
    AbstractNode.call(this, location);
    this.x14_1 = items;
  }
  protoOf(ListLiteral).toString = function () {
    return 'list';
  };
  protoOf(ListLiteral).n13 = function (visitor) {
    if (visitor.hs(this)) {
      var _iterator__ex2g4s = this.x14_1.i();
      $l$loop: while (_iterator__ex2g4s.j()) {
        var item = _iterator__ex2g4s.k();
        if (!item.n13(visitor)) {
          break $l$loop;
        }
      }
    }
    return visitor.ks(this);
  };
  function UnaryOperation(location, op, expr) {
    AbstractNode.call(this, location);
    this.y13_1 = op;
    this.z13_1 = expr;
  }
  protoOf(UnaryOperation).toString = function () {
    var tmp0_subject = this.y13_1.m11_1;
    var tmp;
    if (equals(tmp0_subject, DslTokenType_PLUS_getInstance())) {
      tmp = 'Unary +';
    } else if (equals(tmp0_subject, DslTokenType_MINUS_getInstance())) {
      tmp = 'Unary -';
    } else if (equals(tmp0_subject, DslTokenType_NOT_getInstance())) {
      tmp = 'not';
    } else {
      throw IllegalStateException_init_$Create$('unsupported unary op ' + toString(this.y13_1.m11_1));
    }
    return tmp;
  };
  protoOf(UnaryOperation).n13 = function (visitor) {
    if (visitor.hs(this)) {
      this.z13_1.n13(visitor);
    }
    return visitor.ks(this);
  };
  function Literal(location, token) {
    AbstractNode.call(this, location);
    this.w13_1 = token;
  }
  protoOf(Literal).toString = function () {
    return toString(ensureNotNull(this.w13_1.n11_1));
  };
  var DslTokenType_PLUS_instance;
  var DslTokenType_MINUS_instance;
  var DslTokenType_MULTIPLY_instance;
  var DslTokenType_DIVIDE_instance;
  var DslTokenType_CARET_instance;
  var DslTokenType_LPAREN_instance;
  var DslTokenType_RPAREN_instance;
  var DslTokenType_ASSIGN_instance;
  var DslTokenType_LCURLEY_instance;
  var DslTokenType_RCURLEY_instance;
  var DslTokenType_VAR_instance;
  var DslTokenType_STORE_instance;
  var DslTokenType_EQUAL_instance;
  var DslTokenType_DIFF_instance;
  var DslTokenType_SMALLER_instance;
  var DslTokenType_SMALLER_EQUAL_instance;
  var DslTokenType_GREATER_instance;
  var DslTokenType_GREATER_EQUAL_instance;
  var DslTokenType_IF_instance;
  var DslTokenType_ELSE_instance;
  var DslTokenType_AND_instance;
  var DslTokenType_NAND_instance;
  var DslTokenType_XOR_instance;
  var DslTokenType_XNOR_instance;
  var DslTokenType_OR_instance;
  var DslTokenType_NOR_instance;
  var DslTokenType_NOT_instance;
  var DslTokenType_SHIFT_LEFT_instance;
  var DslTokenType_SHIFT_RIGHT_instance;
  var DslTokenType_MOD_instance;
  var DslTokenType_WHEN_instance;
  var DslTokenType_COLON_instance;
  var DslTokenType_FOR_instance;
  var DslTokenType_IN_instance;
  var DslTokenType_TO_instance;
  var DslTokenType_LEFT_BRACKET_instance;
  var DslTokenType_RIGHT_BRACKET_instance;
  var DslTokenType_QUESTION_MARK_instance;
  var DslTokenType_RETURN_instance;
  var DslTokenType_AMPERSAND_instance;
  var DslTokenType_VERTICAL_BAR_instance;
  var DslTokenType_DOLLAR_instance;
  var DslTokenType_INIT_instance;
  var DslTokenType_AT_instance;
  var DslTokenType_HASH_instance;
  var DslTokenType_DOT_instance;
  var DslTokenType_COMMA_instance;
  var DslTokenType_LOGIC_AND_instance;
  var DslTokenType_LOGIC_OR_instance;
  var DslTokenType_LOGIC_NOT_instance;
  var DslTokenType_PROGRAMMING_AND_instance;
  var DslTokenType_PROGRAMMING_OR_instance;
  var DslTokenType_PROGRAMMING_NOT_instance;
  var DslTokenType_entriesInitialized;
  function DslTokenType_initEntries() {
    if (DslTokenType_entriesInitialized)
      return Unit_instance;
    DslTokenType_entriesInitialized = true;
    DslTokenType_PLUS_instance = new DslTokenType('PLUS', 0, '+');
    DslTokenType_MINUS_instance = new DslTokenType('MINUS', 1, '-');
    DslTokenType_MULTIPLY_instance = new DslTokenType('MULTIPLY', 2, '*');
    DslTokenType_DIVIDE_instance = new DslTokenType('DIVIDE', 3, '/');
    DslTokenType_CARET_instance = new DslTokenType('CARET', 4, '^');
    DslTokenType_LPAREN_instance = new DslTokenType('LPAREN', 5, '(');
    DslTokenType_RPAREN_instance = new DslTokenType('RPAREN', 6, ')');
    DslTokenType_ASSIGN_instance = new DslTokenType('ASSIGN', 7, '=');
    DslTokenType_LCURLEY_instance = new DslTokenType('LCURLEY', 8, '{');
    DslTokenType_RCURLEY_instance = new DslTokenType('RCURLEY', 9, '}');
    DslTokenType_VAR_instance = new DslTokenType('VAR', 10, 'var');
    DslTokenType_STORE_instance = new DslTokenType('STORE', 11, 'store');
    DslTokenType_EQUAL_instance = new DslTokenType('EQUAL', 12, '==');
    DslTokenType_DIFF_instance = new DslTokenType('DIFF', 13, '!=');
    DslTokenType_SMALLER_instance = new DslTokenType('SMALLER', 14, '<');
    DslTokenType_SMALLER_EQUAL_instance = new DslTokenType('SMALLER_EQUAL', 15, '<=');
    DslTokenType_GREATER_instance = new DslTokenType('GREATER', 16, '>');
    DslTokenType_GREATER_EQUAL_instance = new DslTokenType('GREATER_EQUAL', 17, '>=');
    DslTokenType_IF_instance = new DslTokenType('IF', 18, 'if');
    DslTokenType_ELSE_instance = new DslTokenType('ELSE', 19, 'else');
    DslTokenType_AND_instance = new DslTokenType('AND', 20, 'and');
    DslTokenType_NAND_instance = new DslTokenType('NAND', 21, 'nand');
    DslTokenType_XOR_instance = new DslTokenType('XOR', 22, 'xor');
    DslTokenType_XNOR_instance = new DslTokenType('XNOR', 23, 'xnor');
    DslTokenType_OR_instance = new DslTokenType('OR', 24, 'or');
    DslTokenType_NOR_instance = new DslTokenType('NOR', 25, 'nor');
    DslTokenType_NOT_instance = new DslTokenType('NOT', 26, 'not');
    DslTokenType_SHIFT_LEFT_instance = new DslTokenType('SHIFT_LEFT', 27, '<<');
    DslTokenType_SHIFT_RIGHT_instance = new DslTokenType('SHIFT_RIGHT', 28, '>>');
    DslTokenType_MOD_instance = new DslTokenType('MOD', 29, '%');
    DslTokenType_WHEN_instance = new DslTokenType('WHEN', 30, 'when');
    DslTokenType_COLON_instance = new DslTokenType('COLON', 31, ':');
    DslTokenType_FOR_instance = new DslTokenType('FOR', 32, 'for');
    DslTokenType_IN_instance = new DslTokenType('IN', 33, 'in');
    DslTokenType_TO_instance = new DslTokenType('TO', 34, 'to');
    DslTokenType_LEFT_BRACKET_instance = new DslTokenType('LEFT_BRACKET', 35, '[');
    DslTokenType_RIGHT_BRACKET_instance = new DslTokenType('RIGHT_BRACKET', 36, ']');
    DslTokenType_QUESTION_MARK_instance = new DslTokenType('QUESTION_MARK', 37, '?');
    DslTokenType_RETURN_instance = new DslTokenType('RETURN', 38, 'return');
    DslTokenType_AMPERSAND_instance = new DslTokenType('AMPERSAND', 39, '&');
    DslTokenType_VERTICAL_BAR_instance = new DslTokenType('VERTICAL_BAR', 40, '|');
    DslTokenType_DOLLAR_instance = new DslTokenType('DOLLAR', 41, '$');
    DslTokenType_INIT_instance = new DslTokenType('INIT', 42, 'init');
    DslTokenType_AT_instance = new DslTokenType('AT', 43, '@');
    DslTokenType_HASH_instance = new DslTokenType('HASH', 44, '#');
    DslTokenType_DOT_instance = new DslTokenType('DOT', 45, '.');
    DslTokenType_COMMA_instance = new DslTokenType('COMMA', 46, ',');
    DslTokenType_LOGIC_AND_instance = new DslTokenType('LOGIC_AND', 47, '\u2227');
    DslTokenType_LOGIC_OR_instance = new DslTokenType('LOGIC_OR', 48, '\u2228');
    DslTokenType_LOGIC_NOT_instance = new DslTokenType('LOGIC_NOT', 49, '\xAC');
    DslTokenType_PROGRAMMING_AND_instance = new DslTokenType('PROGRAMMING_AND', 50, '&&');
    DslTokenType_PROGRAMMING_OR_instance = new DslTokenType('PROGRAMMING_OR', 51, '||');
    DslTokenType_PROGRAMMING_NOT_instance = new DslTokenType('PROGRAMMING_NOT', 52, '!');
  }
  function DslTokenType(name, ordinal, id) {
    Enum.call(this, name, ordinal);
    this.k17_1 = id;
  }
  protoOf(DslTokenType).cv = function () {
    return this.k17_1;
  };
  function DslTokenType_PLUS_getInstance() {
    DslTokenType_initEntries();
    return DslTokenType_PLUS_instance;
  }
  function DslTokenType_MINUS_getInstance() {
    DslTokenType_initEntries();
    return DslTokenType_MINUS_instance;
  }
  function DslTokenType_MULTIPLY_getInstance() {
    DslTokenType_initEntries();
    return DslTokenType_MULTIPLY_instance;
  }
  function DslTokenType_DIVIDE_getInstance() {
    DslTokenType_initEntries();
    return DslTokenType_DIVIDE_instance;
  }
  function DslTokenType_CARET_getInstance() {
    DslTokenType_initEntries();
    return DslTokenType_CARET_instance;
  }
  function DslTokenType_LPAREN_getInstance() {
    DslTokenType_initEntries();
    return DslTokenType_LPAREN_instance;
  }
  function DslTokenType_RPAREN_getInstance() {
    DslTokenType_initEntries();
    return DslTokenType_RPAREN_instance;
  }
  function DslTokenType_ASSIGN_getInstance() {
    DslTokenType_initEntries();
    return DslTokenType_ASSIGN_instance;
  }
  function DslTokenType_LCURLEY_getInstance() {
    DslTokenType_initEntries();
    return DslTokenType_LCURLEY_instance;
  }
  function DslTokenType_RCURLEY_getInstance() {
    DslTokenType_initEntries();
    return DslTokenType_RCURLEY_instance;
  }
  function DslTokenType_VAR_getInstance() {
    DslTokenType_initEntries();
    return DslTokenType_VAR_instance;
  }
  function DslTokenType_STORE_getInstance() {
    DslTokenType_initEntries();
    return DslTokenType_STORE_instance;
  }
  function DslTokenType_EQUAL_getInstance() {
    DslTokenType_initEntries();
    return DslTokenType_EQUAL_instance;
  }
  function DslTokenType_DIFF_getInstance() {
    DslTokenType_initEntries();
    return DslTokenType_DIFF_instance;
  }
  function DslTokenType_SMALLER_getInstance() {
    DslTokenType_initEntries();
    return DslTokenType_SMALLER_instance;
  }
  function DslTokenType_SMALLER_EQUAL_getInstance() {
    DslTokenType_initEntries();
    return DslTokenType_SMALLER_EQUAL_instance;
  }
  function DslTokenType_GREATER_getInstance() {
    DslTokenType_initEntries();
    return DslTokenType_GREATER_instance;
  }
  function DslTokenType_GREATER_EQUAL_getInstance() {
    DslTokenType_initEntries();
    return DslTokenType_GREATER_EQUAL_instance;
  }
  function DslTokenType_IF_getInstance() {
    DslTokenType_initEntries();
    return DslTokenType_IF_instance;
  }
  function DslTokenType_ELSE_getInstance() {
    DslTokenType_initEntries();
    return DslTokenType_ELSE_instance;
  }
  function DslTokenType_AND_getInstance() {
    DslTokenType_initEntries();
    return DslTokenType_AND_instance;
  }
  function DslTokenType_NAND_getInstance() {
    DslTokenType_initEntries();
    return DslTokenType_NAND_instance;
  }
  function DslTokenType_XOR_getInstance() {
    DslTokenType_initEntries();
    return DslTokenType_XOR_instance;
  }
  function DslTokenType_XNOR_getInstance() {
    DslTokenType_initEntries();
    return DslTokenType_XNOR_instance;
  }
  function DslTokenType_OR_getInstance() {
    DslTokenType_initEntries();
    return DslTokenType_OR_instance;
  }
  function DslTokenType_NOR_getInstance() {
    DslTokenType_initEntries();
    return DslTokenType_NOR_instance;
  }
  function DslTokenType_NOT_getInstance() {
    DslTokenType_initEntries();
    return DslTokenType_NOT_instance;
  }
  function DslTokenType_SHIFT_LEFT_getInstance() {
    DslTokenType_initEntries();
    return DslTokenType_SHIFT_LEFT_instance;
  }
  function DslTokenType_SHIFT_RIGHT_getInstance() {
    DslTokenType_initEntries();
    return DslTokenType_SHIFT_RIGHT_instance;
  }
  function DslTokenType_MOD_getInstance() {
    DslTokenType_initEntries();
    return DslTokenType_MOD_instance;
  }
  function DslTokenType_WHEN_getInstance() {
    DslTokenType_initEntries();
    return DslTokenType_WHEN_instance;
  }
  function DslTokenType_COLON_getInstance() {
    DslTokenType_initEntries();
    return DslTokenType_COLON_instance;
  }
  function DslTokenType_FOR_getInstance() {
    DslTokenType_initEntries();
    return DslTokenType_FOR_instance;
  }
  function DslTokenType_IN_getInstance() {
    DslTokenType_initEntries();
    return DslTokenType_IN_instance;
  }
  function DslTokenType_TO_getInstance() {
    DslTokenType_initEntries();
    return DslTokenType_TO_instance;
  }
  function DslTokenType_LEFT_BRACKET_getInstance() {
    DslTokenType_initEntries();
    return DslTokenType_LEFT_BRACKET_instance;
  }
  function DslTokenType_RIGHT_BRACKET_getInstance() {
    DslTokenType_initEntries();
    return DslTokenType_RIGHT_BRACKET_instance;
  }
  function DslTokenType_QUESTION_MARK_getInstance() {
    DslTokenType_initEntries();
    return DslTokenType_QUESTION_MARK_instance;
  }
  function DslTokenType_RETURN_getInstance() {
    DslTokenType_initEntries();
    return DslTokenType_RETURN_instance;
  }
  function DslTokenType_DOLLAR_getInstance() {
    DslTokenType_initEntries();
    return DslTokenType_DOLLAR_instance;
  }
  function DslTokenType_INIT_getInstance() {
    DslTokenType_initEntries();
    return DslTokenType_INIT_instance;
  }
  function DslTokenType_AT_getInstance() {
    DslTokenType_initEntries();
    return DslTokenType_AT_instance;
  }
  function DslTokenType_HASH_getInstance() {
    DslTokenType_initEntries();
    return DslTokenType_HASH_instance;
  }
  function DslTokenType_DOT_getInstance() {
    DslTokenType_initEntries();
    return DslTokenType_DOT_instance;
  }
  function DslTokenType_COMMA_getInstance() {
    DslTokenType_initEntries();
    return DslTokenType_COMMA_instance;
  }
  function ActionEvent(event, source, modifiers, action, time) {
    this.l17_1 = event;
    this.m17_1 = source;
    this.n17_1 = modifiers;
    this.action = action;
    this.time = time;
  }
  protoOf(ActionEvent).o17 = function () {
    return this.l17_1;
  };
  protoOf(ActionEvent).p17 = function () {
    return this.m17_1;
  };
  protoOf(ActionEvent).q17 = function () {
    return this.n17_1;
  };
  protoOf(ActionEvent).r17 = function () {
    return this.action;
  };
  protoOf(ActionEvent).s17 = function () {
    return this.time;
  };
  protoOf(ActionEvent).consumeEvent = function () {
  };
  protoOf(ActionEvent).isEventConsumed = function () {
    return false;
  };
  function ActionListener() {
  }
  function EventBus$postVetoable$lambda(it) {
    return Unit_instance;
  }
  function EventBus$postVetoable$lambda_0(it) {
    return Unit_instance;
  }
  function EventBus() {
  }
  function VetoException(msg, source) {
    source = source === VOID ? null : source;
    extendThrowable(this, msg);
    captureStack(this, VetoException);
    this.g18_1 = source;
  }
  function _get_LOG__e5r759_3($this) {
    var tmp0 = $this.h18_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('LOG', 1, tmp, EventBusImpl$Companion$_get_LOG_$ref_ghr206(), null);
    return tmp0.j2();
  }
  function EventBusImpl$Companion$_get_LOG_$ref_ghr206() {
    return function (p0) {
      return _get_LOG__e5r759_3(p0);
    };
  }
  function Companion_9() {
    Companion_instance_9 = this;
    this.h18_1 = logger(getKClass(EventBusImpl));
  }
  var Companion_instance_9;
  function Companion_getInstance_9() {
    if (Companion_instance_9 == null)
      new Companion_9();
    return Companion_instance_9;
  }
  function unregister($this, eventClassName, handler) {
    _get_LOG__e5r759_3(Companion_getInstance_9()).pl('Unregister ' + eventClassName);
    var tmp0_safe_receiver = $this.i18_1.g2(eventClassName);
    if (tmp0_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.collections.remove' call
      (isInterface(tmp0_safe_receiver, MutableCollection) ? tmp0_safe_receiver : THROW_CCE()).h2(handler);
    }
  }
  function getEventClassName($this, eventClass) {
    return System_getInstance().xl(eventClass);
  }
  function getEventClassName_0($this, event) {
    return System_getInstance().yl(event);
  }
  function EventBusImpl() {
    Companion_getInstance_9();
    var tmp = this;
    // Inline function 'kotlin.collections.mutableMapOf' call
    tmp.i18_1 = LinkedHashMap_init_$Create$();
  }
  protoOf(EventBusImpl).z17 = function (eventClass, handler) {
    var eventName = getEventClassName(this, eventClass);
    _get_LOG__e5r759_3(Companion_getInstance_9()).ql('EventBus ' + hashCode(this) + ': Register ' + toString(eventClass));
    // Inline function 'kotlin.collections.getOrPut' call
    var this_0 = this.i18_1;
    var value = this_0.g2(eventName);
    var tmp;
    if (value == null) {
      // Inline function 'kotlin.collections.mutableListOf' call
      var answer = ArrayList_init_$Create$();
      this_0.y1(eventName, answer);
      tmp = answer;
    } else {
      tmp = value;
    }
    var list = tmp;
    if (!contains(list, handler)) {
      list.h(typeof handler === 'function' ? handler : THROW_CCE());
    }
  };
  protoOf(EventBusImpl).a18 = function (eventClass, handler) {
    var eventName = getEventClassName(this, eventClass);
    unregister(this, eventName, typeof handler === 'function' ? handler : THROW_CCE());
  };
  protoOf(EventBusImpl).b18 = function (handler) {
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = this.i18_1.b2().i();
    while (_iterator__ex2g4s.j()) {
      var element = _iterator__ex2g4s.k();
      unregister(this, element, handler);
    }
  };
  protoOf(EventBusImpl).gu = function (event) {
    var tmp0_safe_receiver = this.i18_1.g2(getEventClassName_0(this, event));
    var tmp1_safe_receiver = tmp0_safe_receiver == null ? null : toList(tmp0_safe_receiver);
    if (tmp1_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.collections.forEach' call
      var _iterator__ex2g4s = tmp1_safe_receiver.i();
      while (_iterator__ex2g4s.j()) {
        var element = _iterator__ex2g4s.k();
        element(event);
      }
    }
  };
  protoOf(EventBusImpl).c18 = function (event, undoEvent, thenHandler, elseHandler) {
    // Inline function 'kotlin.collections.mutableListOf' call
    var successHandlers = ArrayList_init_$Create$();
    try {
      var tmp0_safe_receiver = this.i18_1.g2(getEventClassName_0(this, event));
      if (tmp0_safe_receiver == null)
        null;
      else {
        // Inline function 'kotlin.collections.forEach' call
        var _iterator__ex2g4s = tmp0_safe_receiver.i();
        while (_iterator__ex2g4s.j()) {
          var element = _iterator__ex2g4s.k();
          element(event);
          successHandlers.h(element);
        }
      }
      thenHandler(event);
    } catch ($p) {
      if ($p instanceof VetoException) {
        var x = $p;
        // Inline function 'kotlin.collections.forEach' call
        var _iterator__ex2g4s_0 = successHandlers.i();
        while (_iterator__ex2g4s_0.j()) {
          var element_0 = _iterator__ex2g4s_0.k();
          element_0(undoEvent);
        }
        elseHandler(x);
      } else {
        throw $p;
      }
    }
  };
  protoOf(EventBusImpl).e18 = function (prepareEvent, execEvent, thenHandler) {
    try {
      var tmp0_safe_receiver = this.i18_1.g2(getEventClassName_0(this, prepareEvent));
      if (tmp0_safe_receiver == null)
        null;
      else {
        // Inline function 'kotlin.collections.forEach' call
        var _iterator__ex2g4s = tmp0_safe_receiver.i();
        while (_iterator__ex2g4s.j()) {
          var element = _iterator__ex2g4s.k();
          element(prepareEvent);
        }
      }
      var tmp1_safe_receiver = this.i18_1.g2(getEventClassName_0(this, execEvent));
      if (tmp1_safe_receiver == null)
        null;
      else {
        // Inline function 'kotlin.collections.forEach' call
        var _iterator__ex2g4s_0 = tmp1_safe_receiver.i();
        while (_iterator__ex2g4s_0.j()) {
          var element_0 = _iterator__ex2g4s_0.k();
          element_0(execEvent);
        }
      }
      if (thenHandler == null)
        null;
      else
        thenHandler();
    } catch ($p) {
      if ($p instanceof VetoException) {
        var e = $p;
      } else {
        throw $p;
      }
    }
  };
  var Modifier_Shift_instance;
  var Modifier_Ctrl_instance;
  var Modifier_Meta_instance;
  var Modifier_Alt_instance;
  var Modifier_AltGraph_instance;
  function values_0() {
    return [Modifier_Shift_getInstance(), Modifier_Ctrl_getInstance(), Modifier_Meta_getInstance(), Modifier_Alt_getInstance(), Modifier_AltGraph_getInstance()];
  }
  function valueOf(value) {
    switch (value) {
      case 'Shift':
        return Modifier_Shift_getInstance();
      case 'Ctrl':
        return Modifier_Ctrl_getInstance();
      case 'Meta':
        return Modifier_Meta_getInstance();
      case 'Alt':
        return Modifier_Alt_getInstance();
      case 'AltGraph':
        return Modifier_AltGraph_getInstance();
      default:
        Modifier_initEntries();
        THROW_IAE('No enum constant io.antarescircuit.jabbah.base.event.Modifier.' + value);
        break;
    }
  }
  var Modifier_entriesInitialized;
  function Modifier_initEntries() {
    if (Modifier_entriesInitialized)
      return Unit_instance;
    Modifier_entriesInitialized = true;
    Modifier_Shift_instance = new Modifier('Shift', 0, 'Shift', 64);
    Modifier_Ctrl_instance = new Modifier('Ctrl', 1, 'Ctrl', 128);
    Modifier_Meta_instance = new Modifier('Meta', 2, 'Meta', 256);
    Modifier_Alt_instance = new Modifier('Alt', 3, 'Alt', 512);
    Modifier_AltGraph_instance = new Modifier('AltGraph', 4, 'AltGr', 8192);
  }
  function Modifier(name, ordinal, label, mask) {
    Enum.call(this, name, ordinal);
    this.label = label;
    this.mask = mask;
  }
  protoOf(Modifier).l18 = function () {
    return this.label;
  };
  protoOf(Modifier).m18 = function (_set____db54di) {
    this.mask = _set____db54di;
  };
  protoOf(Modifier).n18 = function () {
    return this.mask;
  };
  function InputEvent() {
  }
  function Modifier_Shift_getInstance() {
    Modifier_initEntries();
    return Modifier_Shift_instance;
  }
  function Modifier_Ctrl_getInstance() {
    Modifier_initEntries();
    return Modifier_Ctrl_instance;
  }
  function Modifier_Meta_getInstance() {
    Modifier_initEntries();
    return Modifier_Meta_instance;
  }
  function Modifier_Alt_getInstance() {
    Modifier_initEntries();
    return Modifier_Alt_instance;
  }
  function Modifier_AltGraph_getInstance() {
    Modifier_initEntries();
    return Modifier_AltGraph_instance;
  }
  function Companion_10() {
    this.o18_1 = 1;
    this.p18_1 = 2;
    this.q18_1 = 3;
    this.r18_1 = 4;
    this.s18_1 = 5;
    this.t18_1 = 6;
    this.u18_1 = 7;
    this.v18_1 = 8;
    this.w18_1 = 9;
    this.x18_1 = 10;
    this.y18_1 = 11;
    this.z18_1 = 12;
    this.a19_1 = 13;
    this.b19_1 = 48;
    this.c19_1 = 49;
    this.d19_1 = 50;
    this.e19_1 = 51;
    this.f19_1 = 52;
    this.g19_1 = 53;
    this.h19_1 = 54;
    this.i19_1 = 55;
    this.j19_1 = 56;
    this.k19_1 = 57;
    this.l19_1 = 65;
    this.m19_1 = 66;
    this.n19_1 = 67;
    this.o19_1 = 68;
    this.p19_1 = 69;
    this.q19_1 = 70;
    this.r19_1 = 88;
    this.s19_1 = 90;
    this.t19_1 = 96;
    this.u19_1 = 97;
    this.v19_1 = 98;
    this.w19_1 = 99;
    this.x19_1 = 100;
    this.y19_1 = 101;
    this.z19_1 = 102;
    this.a1a_1 = 103;
    this.b1a_1 = 104;
    this.c1a_1 = 105;
  }
  var Companion_instance_10;
  function Companion_getInstance_10() {
    return Companion_instance_10;
  }
  var KeyEventType_TYPED_instance;
  var KeyEventType_PRESSED_instance;
  var KeyEventType_RELEASED_instance;
  var KeyEventType_UNKNOWN_instance;
  var KeyEventType_entriesInitialized;
  function KeyEventType_initEntries() {
    if (KeyEventType_entriesInitialized)
      return Unit_instance;
    KeyEventType_entriesInitialized = true;
    KeyEventType_TYPED_instance = new KeyEventType('TYPED', 0);
    KeyEventType_PRESSED_instance = new KeyEventType('PRESSED', 1);
    KeyEventType_RELEASED_instance = new KeyEventType('RELEASED', 2);
    KeyEventType_UNKNOWN_instance = new KeyEventType('UNKNOWN', 3);
  }
  function KeyEventType(name, ordinal) {
    Enum.call(this, name, ordinal);
  }
  function KeyEventImpl(type, event, key, keyChar, source, modifiers) {
    event = event === VOID ? '' : event;
    source = source === VOID ? '' : source;
    modifiers = modifiers === VOID ? 0 : modifiers;
    this.d1a_1 = type;
    this.e1a_1 = event;
    this.f1a_1 = key;
    this.g1a_1 = keyChar;
    this.h1a_1 = source;
    this.i1a_1 = modifiers;
    this.j1a_1 = false;
  }
  protoOf(KeyEventImpl).k1a = function () {
    return this.d1a_1;
  };
  protoOf(KeyEventImpl).o17 = function () {
    return this.e1a_1;
  };
  protoOf(KeyEventImpl).i2 = function () {
    return this.f1a_1;
  };
  protoOf(KeyEventImpl).l1a = function () {
    return this.g1a_1;
  };
  protoOf(KeyEventImpl).p17 = function () {
    return this.h1a_1;
  };
  protoOf(KeyEventImpl).q17 = function () {
    return this.i1a_1;
  };
  protoOf(KeyEventImpl).consumeEvent = function () {
    this.j1a_1 = true;
  };
  protoOf(KeyEventImpl).isEventConsumed = function () {
    return this.j1a_1;
  };
  protoOf(KeyEventImpl).toString = function () {
    return 'KeyEventImpl(type=' + this.d1a_1.toString() + ', event=' + toString(this.e1a_1) + ', key=' + this.f1a_1 + ', keyChar=' + toString_1(this.g1a_1) + ', source=' + toString(this.h1a_1) + ', modifiers=' + this.i1a_1 + ')';
  };
  protoOf(KeyEventImpl).hashCode = function () {
    var result = this.d1a_1.hashCode();
    result = imul(result, 31) + hashCode(this.e1a_1) | 0;
    result = imul(result, 31) + this.f1a_1 | 0;
    result = imul(result, 31) + Char__hashCode_impl_otmys(this.g1a_1) | 0;
    result = imul(result, 31) + hashCode(this.h1a_1) | 0;
    result = imul(result, 31) + this.i1a_1 | 0;
    return result;
  };
  protoOf(KeyEventImpl).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof KeyEventImpl))
      return false;
    if (!this.d1a_1.equals(other.d1a_1))
      return false;
    if (!equals(this.e1a_1, other.e1a_1))
      return false;
    if (!(this.f1a_1 === other.f1a_1))
      return false;
    if (!(this.g1a_1 === other.g1a_1))
      return false;
    if (!equals(this.h1a_1, other.h1a_1))
      return false;
    if (!(this.i1a_1 === other.i1a_1))
      return false;
    return true;
  };
  function KeyAdapter() {
  }
  protoOf(KeyAdapter).m1a = function (e) {
  };
  protoOf(KeyAdapter).n1a = function (e) {
  };
  protoOf(KeyAdapter).o1a = function (e) {
  };
  function KeyEventType_TYPED_getInstance() {
    KeyEventType_initEntries();
    return KeyEventType_TYPED_instance;
  }
  function KeyEventType_PRESSED_getInstance() {
    KeyEventType_initEntries();
    return KeyEventType_PRESSED_instance;
  }
  function KeyEventType_RELEASED_getInstance() {
    KeyEventType_initEntries();
    return KeyEventType_RELEASED_instance;
  }
  function MouseEvent() {
  }
  var MouseEventType_CLICKED_instance;
  var MouseEventType_PRESSED_instance;
  var MouseEventType_RELEASED_instance;
  var MouseEventType_ENTERED_instance;
  var MouseEventType_EXITED_instance;
  var MouseEventType_MOVED_instance;
  var MouseEventType_DRAGGED_instance;
  var MouseEventType_WHEEL_ROTATED_instance;
  var MouseEventType_UNKNOWN_instance;
  var MouseEventType_entriesInitialized;
  function MouseEventType_initEntries() {
    if (MouseEventType_entriesInitialized)
      return Unit_instance;
    MouseEventType_entriesInitialized = true;
    MouseEventType_CLICKED_instance = new MouseEventType('CLICKED', 0);
    MouseEventType_PRESSED_instance = new MouseEventType('PRESSED', 1);
    MouseEventType_RELEASED_instance = new MouseEventType('RELEASED', 2);
    MouseEventType_ENTERED_instance = new MouseEventType('ENTERED', 3);
    MouseEventType_EXITED_instance = new MouseEventType('EXITED', 4);
    MouseEventType_MOVED_instance = new MouseEventType('MOVED', 5);
    MouseEventType_DRAGGED_instance = new MouseEventType('DRAGGED', 6);
    MouseEventType_WHEEL_ROTATED_instance = new MouseEventType('WHEEL_ROTATED', 7);
    MouseEventType_UNKNOWN_instance = new MouseEventType('UNKNOWN', 8);
  }
  function MouseEventType(name, ordinal) {
    Enum.call(this, name, ordinal);
  }
  var Button_NONE_instance;
  var Button_BUTTON1_instance;
  var Button_BUTTON2_instance;
  var Button_BUTTON3_instance;
  var Button_UNKNOWN_instance;
  var Button_entriesInitialized;
  function Button_initEntries() {
    if (Button_entriesInitialized)
      return Unit_instance;
    Button_entriesInitialized = true;
    Button_NONE_instance = new Button('NONE', 0);
    Button_BUTTON1_instance = new Button('BUTTON1', 1);
    Button_BUTTON2_instance = new Button('BUTTON2', 2);
    Button_BUTTON3_instance = new Button('BUTTON3', 3);
    Button_UNKNOWN_instance = new Button('UNKNOWN', 4);
  }
  function Button(name, ordinal) {
    Enum.call(this, name, ordinal);
  }
  function MouseEventImpl(type, event, x, y, button, clickCount, wheelRotation, source, modifiers) {
    type = type === VOID ? MouseEventType_PRESSED_getInstance() : type;
    event = event === VOID ? '' : event;
    x = x === VOID ? 0 : x;
    y = y === VOID ? 0 : y;
    button = button === VOID ? Button_NONE_getInstance() : button;
    clickCount = clickCount === VOID ? 0 : clickCount;
    wheelRotation = wheelRotation === VOID ? Companion_getInstance_14().w1a_1 : wheelRotation;
    source = source === VOID ? '' : source;
    modifiers = modifiers === VOID ? 0 : modifiers;
    this.x1a_1 = type;
    this.y1a_1 = event;
    this.z1a_1 = x;
    this.a1b_1 = y;
    this.b1b_1 = button;
    this.c1b_1 = clickCount;
    this.d1b_1 = wheelRotation;
    this.e1b_1 = source;
    this.f1b_1 = modifiers;
    this.g1b_1 = false;
  }
  protoOf(MouseEventImpl).k1a = function () {
    return this.x1a_1;
  };
  protoOf(MouseEventImpl).o17 = function () {
    return this.y1a_1;
  };
  protoOf(MouseEventImpl).p1a = function () {
    return this.z1a_1;
  };
  protoOf(MouseEventImpl).q1a = function () {
    return this.a1b_1;
  };
  protoOf(MouseEventImpl).r1a = function () {
    return this.b1b_1;
  };
  protoOf(MouseEventImpl).s1a = function () {
    return this.c1b_1;
  };
  protoOf(MouseEventImpl).t1a = function () {
    return this.d1b_1;
  };
  protoOf(MouseEventImpl).p17 = function () {
    return this.e1b_1;
  };
  protoOf(MouseEventImpl).q17 = function () {
    return this.f1b_1;
  };
  protoOf(MouseEventImpl).consumeEvent = function () {
    this.g1b_1 = true;
  };
  protoOf(MouseEventImpl).isEventConsumed = function () {
    return this.g1b_1;
  };
  protoOf(MouseEventImpl).toString = function () {
    return 'Mouse.' + this.x1a_1.toString() + ' at ' + this.z1a_1 + ',' + this.a1b_1;
  };
  protoOf(MouseEventImpl).u1a = function () {
    return this.b1b_1.equals(Button_BUTTON1_getInstance());
  };
  protoOf(MouseEventImpl).v1a = function () {
    return this.b1b_1.equals(Button_BUTTON2_getInstance());
  };
  protoOf(MouseEventImpl).hashCode = function () {
    var result = this.x1a_1.hashCode();
    result = imul(result, 31) + hashCode(this.y1a_1) | 0;
    result = imul(result, 31) + this.z1a_1 | 0;
    result = imul(result, 31) + this.a1b_1 | 0;
    result = imul(result, 31) + this.b1b_1.hashCode() | 0;
    result = imul(result, 31) + this.c1b_1 | 0;
    result = imul(result, 31) + this.d1b_1.hashCode() | 0;
    result = imul(result, 31) + hashCode(this.e1b_1) | 0;
    result = imul(result, 31) + this.f1b_1 | 0;
    return result;
  };
  protoOf(MouseEventImpl).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof MouseEventImpl))
      return false;
    if (!this.x1a_1.equals(other.x1a_1))
      return false;
    if (!equals(this.y1a_1, other.y1a_1))
      return false;
    if (!(this.z1a_1 === other.z1a_1))
      return false;
    if (!(this.a1b_1 === other.a1b_1))
      return false;
    if (!this.b1b_1.equals(other.b1b_1))
      return false;
    if (!(this.c1b_1 === other.c1b_1))
      return false;
    if (!this.d1b_1.equals(other.d1b_1))
      return false;
    if (!equals(this.e1b_1, other.e1b_1))
      return false;
    if (!(this.f1b_1 === other.f1b_1))
      return false;
    return true;
  };
  function MouseAdapter() {
  }
  protoOf(MouseAdapter).h1b = function (e) {
  };
  protoOf(MouseAdapter).i1b = function (e) {
  };
  protoOf(MouseAdapter).j1b = function (e) {
  };
  protoOf(MouseAdapter).k1b = function (e) {
  };
  protoOf(MouseAdapter).l1b = function (e) {
  };
  protoOf(MouseAdapter).m1b = function (e) {
  };
  function MouseEventType_CLICKED_getInstance() {
    MouseEventType_initEntries();
    return MouseEventType_CLICKED_instance;
  }
  function MouseEventType_PRESSED_getInstance() {
    MouseEventType_initEntries();
    return MouseEventType_PRESSED_instance;
  }
  function MouseEventType_RELEASED_getInstance() {
    MouseEventType_initEntries();
    return MouseEventType_RELEASED_instance;
  }
  function MouseEventType_ENTERED_getInstance() {
    MouseEventType_initEntries();
    return MouseEventType_ENTERED_instance;
  }
  function MouseEventType_EXITED_getInstance() {
    MouseEventType_initEntries();
    return MouseEventType_EXITED_instance;
  }
  function MouseEventType_MOVED_getInstance() {
    MouseEventType_initEntries();
    return MouseEventType_MOVED_instance;
  }
  function MouseEventType_DRAGGED_getInstance() {
    MouseEventType_initEntries();
    return MouseEventType_DRAGGED_instance;
  }
  function MouseEventType_WHEEL_ROTATED_getInstance() {
    MouseEventType_initEntries();
    return MouseEventType_WHEEL_ROTATED_instance;
  }
  function MouseEventType_UNKNOWN_getInstance() {
    MouseEventType_initEntries();
    return MouseEventType_UNKNOWN_instance;
  }
  function Button_NONE_getInstance() {
    Button_initEntries();
    return Button_NONE_instance;
  }
  function Button_BUTTON1_getInstance() {
    Button_initEntries();
    return Button_BUTTON1_instance;
  }
  function Button_BUTTON2_getInstance() {
    Button_initEntries();
    return Button_BUTTON2_instance;
  }
  function Button_BUTTON3_getInstance() {
    Button_initEntries();
    return Button_BUTTON3_instance;
  }
  function PropertyChangeEvent(source, name, oldValue, newValue) {
    this.source = source;
    this.name = name;
    this.oldValue = oldValue;
    this.newValue = newValue;
  }
  protoOf(PropertyChangeEvent).p17 = function () {
    return this.source;
  };
  protoOf(PropertyChangeEvent).m2 = function () {
    return this.name;
  };
  protoOf(PropertyChangeEvent).n1b = function () {
    return this.oldValue;
  };
  protoOf(PropertyChangeEvent).o1b = function () {
    return this.newValue;
  };
  protoOf(PropertyChangeEvent).yd = function () {
    return this.source;
  };
  protoOf(PropertyChangeEvent).zd = function () {
    return this.name;
  };
  protoOf(PropertyChangeEvent).p1b = function () {
    return this.oldValue;
  };
  protoOf(PropertyChangeEvent).q1b = function () {
    return this.newValue;
  };
  protoOf(PropertyChangeEvent).r1b = function (source, name, oldValue, newValue) {
    return new PropertyChangeEvent(source, name, oldValue, newValue);
  };
  protoOf(PropertyChangeEvent).copy = function (source, name, oldValue, newValue, $super) {
    source = source === VOID ? this.source : source;
    name = name === VOID ? this.name : name;
    oldValue = oldValue === VOID ? this.oldValue : oldValue;
    newValue = newValue === VOID ? this.newValue : newValue;
    return $super === VOID ? this.r1b(source, name, oldValue, newValue) : $super.r1b.call(this, source, name, oldValue, newValue);
  };
  protoOf(PropertyChangeEvent).toString = function () {
    return 'PropertyChangeEvent(source=' + toString(this.source) + ', name=' + this.name + ', oldValue=' + toString_0(this.oldValue) + ', newValue=' + toString_0(this.newValue) + ')';
  };
  protoOf(PropertyChangeEvent).hashCode = function () {
    var result = hashCode(this.source);
    result = imul(result, 31) + getStringHashCode(this.name) | 0;
    result = imul(result, 31) + (this.oldValue == null ? 0 : hashCode(this.oldValue)) | 0;
    result = imul(result, 31) + (this.newValue == null ? 0 : hashCode(this.newValue)) | 0;
    return result;
  };
  protoOf(PropertyChangeEvent).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof PropertyChangeEvent))
      return false;
    if (!equals(this.source, other.source))
      return false;
    if (!(this.name === other.name))
      return false;
    if (!equals(this.oldValue, other.oldValue))
      return false;
    if (!equals(this.newValue, other.newValue))
      return false;
    return true;
  };
  function PropertyChangeListener() {
  }
  function _get_pcSupport__wx0pzf($this) {
    var tmp = $this.s1b_1;
    if (!(tmp == null))
      return tmp;
    else {
      throwUninitializedPropertyAccessException('pcSupport');
    }
  }
  function PropertyOwnerImpl() {
  }
  protoOf(PropertyOwnerImpl).t1b = function (value) {
    this.s1b_1 = new PropertyChangeSupport(value);
  };
  protoOf(PropertyOwnerImpl).u1b = function (l) {
    _get_pcSupport__wx0pzf(this).zr(l);
  };
  protoOf(PropertyOwnerImpl).v1b = function (l) {
    _get_pcSupport__wx0pzf(this).as(l);
  };
  protoOf(PropertyOwnerImpl).nr = function (name, oldValue, newValue) {
    _get_pcSupport__wx0pzf(this).nr(name, oldValue, newValue);
  };
  function _get_listeners__760gzy($this) {
    var tmp0 = $this.mr_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('listeners', 1, tmp, PropertyChangeSupport$_get_listeners_$ref_24o3ev(), null);
    return tmp0.j2();
  }
  function fire($this, event) {
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = toList(_get_listeners__760gzy($this)).i();
    while (_iterator__ex2g4s.j()) {
      var element = _iterator__ex2g4s.k();
      element.propertyChanged(event);
    }
    return Unit_instance;
  }
  function sam$io_antarescircuit_jabbah_base_event_PropertyChangeListener$0(function_0) {
    this.w1b_1 = function_0;
  }
  protoOf(sam$io_antarescircuit_jabbah_base_event_PropertyChangeListener$0).propertyChanged = function (e) {
    return this.w1b_1(e);
  };
  protoOf(sam$io_antarescircuit_jabbah_base_event_PropertyChangeListener$0).p2 = function () {
    return this.w1b_1;
  };
  protoOf(sam$io_antarescircuit_jabbah_base_event_PropertyChangeListener$0).equals = function (other) {
    var tmp;
    if (!(other == null) ? isInterface(other, PropertyChangeListener) : false) {
      var tmp_0;
      if (!(other == null) ? isInterface(other, FunctionAdapter) : false) {
        tmp_0 = equals(this.p2(), other.p2());
      } else {
        tmp_0 = false;
      }
      tmp = tmp_0;
    } else {
      tmp = false;
    }
    return tmp;
  };
  protoOf(sam$io_antarescircuit_jabbah_base_event_PropertyChangeListener$0).hashCode = function () {
    return hashCode(this.p2());
  };
  function PropertyChangeSupport$listeners$delegate$lambda() {
    // Inline function 'kotlin.collections.mutableListOf' call
    return ArrayList_init_$Create$();
  }
  function PropertyChangeSupport$_get_listeners_$ref_24o3ev() {
    return function (p0) {
      return _get_listeners__760gzy(p0);
    };
  }
  function PropertyChangeSupport$add$lambda($handler) {
    return function (e) {
      $handler(e);
      return Unit_instance;
    };
  }
  function PropertyChangeSupport(source) {
    this.lr_1 = source;
    var tmp = this;
    tmp.mr_1 = lazy(PropertyChangeSupport$listeners$delegate$lambda);
  }
  protoOf(PropertyChangeSupport).zr = function (l) {
    if (!_get_listeners__760gzy(this).n(l)) {
      _get_listeners__760gzy(this).h(l);
    }
  };
  protoOf(PropertyChangeSupport).x1b = function (handler) {
    var tmp = PropertyChangeSupport$add$lambda(handler);
    var listener = new sam$io_antarescircuit_jabbah_base_event_PropertyChangeListener$0(tmp);
    this.zr(listener);
    return listener;
  };
  protoOf(PropertyChangeSupport).as = function (l) {
    return _get_listeners__760gzy(this).h2(l);
  };
  protoOf(PropertyChangeSupport).nr = function (name, oldValue, newValue) {
    return fire(this, new PropertyChangeEvent(this.lr_1, name, oldValue, newValue));
  };
  function Companion_11() {
    this.y1b_1 = 1;
    this.z1b_1 = 2;
    this.a1c_1 = 4;
    this.b1c_1 = 8;
  }
  var Companion_instance_11;
  function Companion_getInstance_11() {
    return Companion_instance_11;
  }
  function AbstractRectangularShape(x, y, width, height) {
    this.jo_1 = x;
    this.ko_1 = y;
    this.lo_1 = width;
    this.mo_1 = height;
  }
  protoOf(AbstractRectangularShape).c1c = function (_set____db54di) {
    this.jo_1 = _set____db54di;
  };
  protoOf(AbstractRectangularShape).p1a = function () {
    return this.jo_1;
  };
  protoOf(AbstractRectangularShape).d1c = function (_set____db54di) {
    this.ko_1 = _set____db54di;
  };
  protoOf(AbstractRectangularShape).q1a = function () {
    return this.ko_1;
  };
  protoOf(AbstractRectangularShape).e1c = function (_set____db54di) {
    this.lo_1 = _set____db54di;
  };
  protoOf(AbstractRectangularShape).f1c = function () {
    return this.lo_1;
  };
  protoOf(AbstractRectangularShape).g1c = function (_set____db54di) {
    this.mo_1 = _set____db54di;
  };
  protoOf(AbstractRectangularShape).h1c = function () {
    return this.mo_1;
  };
  protoOf(AbstractRectangularShape).fo = function () {
    return this;
  };
  protoOf(AbstractRectangularShape).i1c = function (x, y, width, height) {
    this.c1c(x);
    this.d1c(y);
    this.e1c(width);
    this.g1c(height);
  };
  protoOf(AbstractRectangularShape).io = function (x, y, w, h) {
    if (this.qv() || w <= 0 || h <= 0) {
      return false;
    }
    return x + w > this.p1a() && y + h > this.q1a() && x < this.p1a() + this.f1c() && y < this.q1a() + this.h1c();
  };
  protoOf(AbstractRectangularShape).j1c = function (x, y) {
    var out = 0;
    if (this.f1c() <= 0) {
      out = out | 5;
    } else if (x < this.p1a()) {
      out = out | 1;
    } else if (x > this.p1a() + this.f1c()) {
      out = out | 4;
    }
    if (this.h1c() <= 0) {
      out = out | 10;
    } else if (y < this.q1a()) {
      out = out | 2;
    } else if (y > this.q1a() + this.h1c()) {
      out = out | 8;
    }
    return out;
  };
  protoOf(AbstractRectangularShape).k1c = function (xx1, yy1, x2, y2) {
    var x1 = xx1;
    var y1 = yy1;
    var out2 = this.j1c(x2, y2);
    if (out2 === 0) {
      return true;
    }
    var out1 = this.j1c(x1, y1);
    while (!(out1 === 0)) {
      if (!((out1 & out2) === 0)) {
        return false;
      }
      if (!((out1 & 5) === 0)) {
        var x = this.p1a();
        if (!((out1 & 4) === 0)) {
          x = x + this.f1c();
        }
        y1 = y1 + (x - x1) * (y2 - y1) / (x2 - x1);
        x1 = x;
      } else {
        var y = this.q1a();
        if (!((out1 & 8) === 0)) {
          y = y + this.h1c();
        }
        x1 = x1 + (y - y1) * (x2 - x1) / (y2 - y1);
        y1 = y;
      }
      out1 = this.j1c(x1, y1);
    }
    return true;
  };
  function AffineTransform() {
  }
  function NonInvertibleTransformException(msg) {
    extendThrowable(this, msg);
    captureStack(this, NonInvertibleTransformException);
  }
  function AffineTransformImpl_init_$Init$($this) {
    AffineTransformImpl.call($this, 1.0, VOID, VOID, 1.0);
    return $this;
  }
  function AffineTransformImpl_init_$Create$() {
    return AffineTransformImpl_init_$Init$(objectCreate(protoOf(AffineTransformImpl)));
  }
  function AffineTransformImpl_init_$Init$_0(t, $this) {
    AffineTransformImpl.call($this, t.u1d_1, t.v1d_1, t.w1d_1, t.x1d_1, t.y1d_1, t.z1d_1);
    return $this;
  }
  function AffineTransformImpl_init_$Create$_0(t) {
    return AffineTransformImpl_init_$Init$_0(t, objectCreate(protoOf(AffineTransformImpl)));
  }
  function Companion_12() {
    Companion_instance_12 = this;
    this.c1e_1 = -1;
    this.d1e_1 = 0;
    this.e1e_1 = 1;
    this.f1e_1 = 8;
    this.g1e_1 = 16;
    this.h1e_1 = 0;
    this.i1e_1 = 1;
    this.j1e_1 = 2;
    this.k1e_1 = 4;
    this.l1e_1 = 3;
    this.m1e_1 = 0;
    this.n1e_1 = 8;
    this.o1e_1 = 16;
    this.p1e_1 = 32;
    var tmp = this;
    // Inline function 'kotlin.intArrayOf' call
    tmp.q1e_1 = new Int32Array([4, 5, 4, 5, 2, 3, 6, 7]);
  }
  var Companion_instance_12;
  function Companion_getInstance_12() {
    if (Companion_instance_12 == null)
      new Companion_12();
    return Companion_instance_12;
  }
  function updateState($this) {
    if ($this.w1d_1 === 0.0 && $this.v1d_1 === 0.0) {
      if ($this.u1d_1 === 1.0 && $this.x1d_1 === 1.0) {
        if ($this.y1d_1 === 0.0 && $this.z1d_1 === 0.0) {
          $this.b1e_1 = 0;
          $this.a1e_1 = 0;
        } else {
          $this.b1e_1 = 1;
          $this.a1e_1 = 1;
        }
      } else {
        if ($this.y1d_1 === 0.0 && $this.z1d_1 === 0.0) {
          $this.b1e_1 = 2;
          $this.a1e_1 = -1;
        } else {
          $this.b1e_1 = 3;
          $this.a1e_1 = -1;
        }
      }
    } else {
      if ($this.u1d_1 === 0.0 && $this.x1d_1 === 0.0) {
        if ($this.y1d_1 === 0.0 && $this.z1d_1 === 0.0) {
          $this.b1e_1 = 4;
          $this.a1e_1 = -1;
        } else {
          $this.b1e_1 = 5;
          $this.a1e_1 = -1;
        }
      } else {
        if ($this.y1d_1 === 0.0 && $this.z1d_1 === 0.0) {
          $this.b1e_1 = 6;
          $this.a1e_1 = -1;
        } else {
          $this.b1e_1 = 7;
          $this.a1e_1 = -1;
        }
      }
    }
  }
  function rotate90($this) {
    var M0 = $this.u1d_1;
    $this.u1d_1 = $this.w1d_1;
    $this.w1d_1 = -M0;
    M0 = $this.v1d_1;
    $this.v1d_1 = $this.x1d_1;
    $this.x1d_1 = -M0;
    var state = Companion_getInstance_12().q1e_1[$this.b1e_1];
    if ((state & 6) === 2 && $this.u1d_1 === 1.0 && $this.x1d_1 === 1.0) {
      state = state - 2 | 0;
    }
    $this.b1e_1 = state;
    $this.a1e_1 = -1;
  }
  function rotate180($this) {
    $this.u1d_1 = -$this.u1d_1;
    $this.x1d_1 = -$this.x1d_1;
    var state = $this.b1e_1;
    if (!((state & 4) === 0)) {
      $this.w1d_1 = -$this.w1d_1;
      $this.v1d_1 = -$this.v1d_1;
    } else {
      if ($this.u1d_1 === 1.0 && $this.x1d_1 === 1.0) {
        $this.b1e_1 = state & -3;
      } else {
        $this.b1e_1 = state | 2;
      }
    }
    $this.a1e_1 = -1;
  }
  function rotate270($this) {
    var M0 = $this.u1d_1;
    $this.u1d_1 = -$this.w1d_1;
    $this.w1d_1 = M0;
    M0 = $this.v1d_1;
    $this.v1d_1 = -$this.x1d_1;
    $this.x1d_1 = M0;
    var state = Companion_getInstance_12().q1e_1[$this.b1e_1];
    if ((state & 6) === 2 && $this.u1d_1 === 1.0 && $this.x1d_1 === 1.0) {
      state = state - 2 | 0;
    }
    $this.b1e_1 = state;
    $this.a1e_1 = -1;
  }
  function AffineTransformImpl(m00, m10, m01, m11, m02, m12) {
    Companion_getInstance_12();
    m00 = m00 === VOID ? 0.0 : m00;
    m10 = m10 === VOID ? 0.0 : m10;
    m01 = m01 === VOID ? 0.0 : m01;
    m11 = m11 === VOID ? 0.0 : m11;
    m02 = m02 === VOID ? 0.0 : m02;
    m12 = m12 === VOID ? 0.0 : m12;
    this.u1d_1 = m00;
    this.v1d_1 = m10;
    this.w1d_1 = m01;
    this.x1d_1 = m11;
    this.y1d_1 = m02;
    this.z1d_1 = m12;
    this.a1e_1 = -1;
    this.b1e_1 = 0;
    updateState(this);
  }
  protoOf(AffineTransformImpl).k1d = function () {
    // Inline function 'kotlin.doubleArrayOf' call
    return new Float64Array([this.u1d_1, this.v1d_1, this.w1d_1, this.x1d_1, this.y1d_1, this.z1d_1]);
  };
  protoOf(AffineTransformImpl).in = function () {
    return this.r1e();
  };
  protoOf(AffineTransformImpl).i1d = function () {
    return this.u1d_1 * this.x1d_1 - this.w1d_1 * this.v1d_1;
  };
  protoOf(AffineTransformImpl).r1d = function () {
    this.u1d_1 = 1.0;
    this.x1d_1 = 1.0;
    this.v1d_1 = 0.0;
    this.w1d_1 = 0.0;
    this.y1d_1 = 0.0;
    this.z1d_1 = 0.0;
    this.b1e_1 = 0;
    this.a1e_1 = 0;
  };
  protoOf(AffineTransformImpl).s1d = function (tx, ty) {
    this.u1d_1 = 1.0;
    this.v1d_1 = 0.0;
    this.w1d_1 = 0.0;
    this.x1d_1 = 1.0;
    this.y1d_1 = tx;
    this.z1d_1 = ty;
    if (!(tx === 0.0) || !(ty === 0.0)) {
      this.b1e_1 = 1;
      this.a1e_1 = 1;
    } else {
      this.b1e_1 = 0;
      this.a1e_1 = 0;
    }
  };
  protoOf(AffineTransformImpl).t1d = function (theta, anchorX, anchorY) {
    this.s1e(theta);
    var sin = this.v1d_1;
    var oneMinusCos = 1.0 - this.u1d_1;
    this.y1d_1 = anchorX * oneMinusCos + anchorY * sin;
    this.z1d_1 = anchorY * oneMinusCos - anchorX * sin;
    if (!(this.y1d_1 === 0.0) || !(this.z1d_1 === 0.0)) {
      this.b1e_1 = this.b1e_1 | 1;
      this.a1e_1 = this.a1e_1 | 1;
    }
  };
  protoOf(AffineTransformImpl).s1e = function (theta) {
    // Inline function 'kotlin.math.sin' call
    var sin = Math.sin(theta);
    var cos;
    if (sin === 1.0 || sin === -1.0) {
      cos = 0.0;
      this.b1e_1 = 4;
      this.a1e_1 = 8;
    } else {
      // Inline function 'kotlin.math.cos' call
      cos = Math.cos(theta);
      var tmp0_subject = cos;
      if (tmp0_subject === -1.0) {
        sin = 0.0;
        this.b1e_1 = 2;
        this.a1e_1 = 8;
      } else if (tmp0_subject === 1.0) {
        sin = 0.0;
        this.b1e_1 = 0;
        this.a1e_1 = 0;
      } else {
        this.b1e_1 = 6;
        this.a1e_1 = 16;
      }
    }
    this.u1d_1 = cos;
    this.v1d_1 = sin;
    this.w1d_1 = -sin;
    this.x1d_1 = cos;
    this.y1d_1 = 0.0;
    this.z1d_1 = 0.0;
  };
  protoOf(AffineTransformImpl).l1d = function (tx, ty) {
    switch (this.b1e_1) {
      case 7:
        this.y1d_1 = this.y1d_1 + (tx * this.u1d_1 + ty * this.w1d_1);
        this.z1d_1 = this.z1d_1 + (tx * this.v1d_1 + ty * this.x1d_1);
        if (this.y1d_1 === 0.0 && this.z1d_1 === 0.0) {
          this.b1e_1 = 6;
          if (!(this.a1e_1 === -1)) {
            this.a1e_1 = this.a1e_1 - 1 | 0;
          }
        }

        return Unit_instance;
      case 6:
        this.y1d_1 = tx * this.u1d_1 + ty * this.w1d_1;
        this.z1d_1 = tx * this.v1d_1 + ty * this.x1d_1;
        if (!(this.y1d_1 === 0.0) || !(this.z1d_1 === 0.0)) {
          this.b1e_1 = 7;
          this.a1e_1 = this.a1e_1 | 1;
        }

        return Unit_instance;
      case 5:
        this.y1d_1 = this.y1d_1 + ty * this.w1d_1;
        this.z1d_1 = this.z1d_1 + tx * this.v1d_1;
        if (this.y1d_1 === 0.0 && this.z1d_1 === 0.0) {
          this.b1e_1 = 4;
          if (!(this.a1e_1 === -1)) {
            this.a1e_1 = this.a1e_1 - 1 | 0;
          }
        }

        return Unit_instance;
      case 4:
        this.y1d_1 = ty * this.w1d_1;
        this.z1d_1 = tx * this.v1d_1;
        if (!(this.y1d_1 === 0.0) || !(this.z1d_1 === 0.0)) {
          this.b1e_1 = 5;
          this.a1e_1 = this.a1e_1 | 1;
        }

        return Unit_instance;
      case 3:
        this.y1d_1 = this.y1d_1 + tx * this.u1d_1;
        this.z1d_1 = this.z1d_1 + ty * this.x1d_1;
        if (this.y1d_1 === 0.0 && this.z1d_1 === 0.0) {
          this.b1e_1 = 2;
          if (!(this.a1e_1 === -1)) {
            this.a1e_1 = this.a1e_1 - 1 | 0;
          }
        }

        return Unit_instance;
      case 2:
        this.y1d_1 = tx * this.u1d_1;
        this.z1d_1 = ty * this.x1d_1;
        if (!(this.y1d_1 === 0.0) || !(this.z1d_1 === 0.0)) {
          this.b1e_1 = 3;
          this.a1e_1 = this.a1e_1 | 1;
        }

        return Unit_instance;
      case 1:
        this.y1d_1 = this.y1d_1 + tx;
        this.z1d_1 = this.z1d_1 + ty;
        if (this.y1d_1 === 0.0 && this.z1d_1 === 0.0) {
          this.b1e_1 = 0;
          this.a1e_1 = 0;
        }

        return Unit_instance;
      case 0:
        this.y1d_1 = tx;
        this.z1d_1 = ty;
        if (!(tx === 0.0) || !(ty === 0.0)) {
          this.b1e_1 = 1;
          this.a1e_1 = 1;
        }

        return Unit_instance;
    }
  };
  protoOf(AffineTransformImpl).n1d = function (sx, sy) {
    var state = this.b1e_1;
    switch (state) {
      case 7:
      case 6:
        this.u1d_1 = this.u1d_1 * sx;
        this.x1d_1 = this.x1d_1 * sy;
        this.w1d_1 = this.w1d_1 * sy;
        this.v1d_1 = this.v1d_1 * sx;
        if (this.w1d_1 === 0.0 && this.v1d_1 === 0.0) {
          state = state & 1;
          if (this.u1d_1 === 1.0 && this.x1d_1 === 1.0) {
            this.a1e_1 = state === 0 ? 0 : 1;
          } else {
            state = state | 2;
            this.a1e_1 = -1;
          }
          this.b1e_1 = state;
        }

        return Unit_instance;
      case 5:
      case 4:
        this.w1d_1 = this.w1d_1 * sy;
        this.v1d_1 = this.v1d_1 * sx;
        if (this.w1d_1 === 0.0 && this.v1d_1 === 0.0) {
          state = state & 1;
          if (this.u1d_1 === 1.0 && this.x1d_1 === 1.0) {
            this.a1e_1 = state === 0 ? 0 : 1;
          } else {
            state = state | 2;
            this.a1e_1 = -1;
          }
          this.b1e_1 = state;
        }

        return Unit_instance;
      case 3:
      case 2:
        this.u1d_1 = this.u1d_1 * sx;
        this.x1d_1 = this.x1d_1 * sy;
        if (this.u1d_1 === 1.0 && this.x1d_1 === 1.0) {
          state = state & 1;
          this.b1e_1 = state;
          this.a1e_1 = state === 0 ? 0 : 1;
        } else {
          this.a1e_1 = -1;
        }

        return Unit_instance;
      case 1:
      case 0:
        this.u1d_1 = sx;
        this.x1d_1 = sy;
        if (!(sx === 1.0) || !(sy === 1.0)) {
          this.b1e_1 = state | 2;
          this.a1e_1 = -1;
        }

        return Unit_instance;
    }
  };
  protoOf(AffineTransformImpl).o1d = function (theta) {
    // Inline function 'kotlin.math.sin' call
    var sin = Math.sin(theta);
    if (sin === 1.0) {
      rotate90(this);
    } else if (sin === -1.0) {
      rotate270(this);
    } else {
      // Inline function 'kotlin.math.cos' call
      var cos = Math.cos(theta);
      if (cos === -1.0) {
        rotate180(this);
      } else if (!(cos === 1.0)) {
        var M0 = this.u1d_1;
        var M1 = this.w1d_1;
        this.u1d_1 = cos * M0 + sin * M1;
        this.w1d_1 = -sin * M0 + cos * M1;
        M0 = this.v1d_1;
        M1 = this.x1d_1;
        this.v1d_1 = cos * M0 + sin * M1;
        this.x1d_1 = -sin * M0 + cos * M1;
        updateState(this);
      }
    }
  };
  protoOf(AffineTransformImpl).nn = function (ptSrc) {
    var x = ptSrc.kn_1;
    var y = ptSrc.ln_1;
    switch (this.b1e_1) {
      case 7:
        return new Point2D(x * this.u1d_1 + y * this.w1d_1 + this.y1d_1, x * this.v1d_1 + y * this.x1d_1 + this.z1d_1);
      case 6:
        return new Point2D(x * this.u1d_1 + y * this.w1d_1, x * this.v1d_1 + y * this.x1d_1);
      case 5:
        return new Point2D(y * this.w1d_1 + this.y1d_1, x * this.v1d_1 + this.z1d_1);
      case 4:
        return new Point2D(y * this.w1d_1, x * this.v1d_1);
      case 3:
        return new Point2D(x * this.u1d_1 + this.y1d_1, y * this.x1d_1 + this.z1d_1);
      case 2:
        return new Point2D(x * this.u1d_1, y * this.x1d_1);
      case 1:
        return new Point2D(x + this.y1d_1, y + this.z1d_1);
      case 0:
        return new Point2D(x, y);
      default:
        return Companion_getInstance_14().w1a_1;
    }
  };
  protoOf(AffineTransformImpl).p1d = function (ptSrc) {
    var x = ptSrc.kn_1;
    var y = ptSrc.ln_1;
    var tmp;
    switch (this.b1e_1) {
      case 7:
        x = x - this.y1d_1;
        y = y - this.z1d_1;
        var det = this.u1d_1 * this.x1d_1 - this.w1d_1 * this.v1d_1;
        // Inline function 'kotlin.math.abs' call

        if (Math.abs(det) <= 4.9E-324) {
          throw new NonInvertibleTransformException('Determinant is ' + det);
        }

        tmp = new Point2D((x * this.x1d_1 - y * this.w1d_1) / det, (y * this.u1d_1 - x * this.v1d_1) / det);
        break;
      case 6:
        var det_0 = this.u1d_1 * this.x1d_1 - this.w1d_1 * this.v1d_1;
        // Inline function 'kotlin.math.abs' call

        if (Math.abs(det_0) <= 4.9E-324) {
          throw new NonInvertibleTransformException('Determinant is ' + det_0);
        }

        tmp = new Point2D((x * this.x1d_1 - y * this.w1d_1) / det_0, (y * this.u1d_1 - x * this.v1d_1) / det_0);
        break;
      case 5:
        x = x - this.y1d_1;
        y = y - this.z1d_1;
        if (this.w1d_1 === 0.0 || this.v1d_1 === 0.0) {
          throw new NonInvertibleTransformException('Determinant is 0');
        }

        tmp = new Point2D(y / this.v1d_1, x / this.w1d_1);
        break;
      case 4:
        if (this.w1d_1 === 0.0 || this.v1d_1 === 0.0) {
          throw new NonInvertibleTransformException('Determinant is 0');
        }

        tmp = new Point2D(y / this.v1d_1, x / this.w1d_1);
        break;
      case 3:
        x = x - this.y1d_1;
        y = y - this.z1d_1;
        if (this.u1d_1 === 0.0 || this.x1d_1 === 0.0) {
          throw new NonInvertibleTransformException('Determinant is 0');
        }

        tmp = new Point2D(x / this.u1d_1, y / this.x1d_1);
        break;
      case 2:
        if (this.u1d_1 === 0.0 || this.x1d_1 === 0.0) {
          throw new NonInvertibleTransformException('Determinant is 0');
        }

        tmp = new Point2D(x / this.u1d_1, y / this.x1d_1);
        break;
      case 1:
        tmp = new Point2D(x - this.y1d_1, y - this.z1d_1);
        break;
      case 0:
        tmp = new Point2D(x, y);
        break;
      default:
        return Companion_getInstance_14().w1a_1;
    }
    return tmp;
  };
  protoOf(AffineTransformImpl).q1d = function (Tx) {
    if (!(Tx instanceof AffineTransformImpl)) {
      throw IllegalArgumentException_init_$Create$('unsupported ' + getKClassFromExpression(Tx).m9());
    }
    var M0;
    var M1;
    var T00 = Tx.u1d_1;
    var T01;
    var T10;
    var T11 = Tx.x1d_1;
    var T02 = Tx.y1d_1;
    var T12 = Tx.z1d_1;
    var mystate = this.b1e_1;
    var txstate = Tx.b1e_1;
    switch (txstate << 3 | mystate) {
      case 0:
      case 1:
      case 2:
      case 3:
      case 4:
      case 5:
      case 6:
      case 7:
        return Unit_instance;
      case 56:
        this.w1d_1 = Tx.w1d_1;
        this.v1d_1 = Tx.v1d_1;
        this.u1d_1 = Tx.u1d_1;
        this.x1d_1 = Tx.x1d_1;
        this.y1d_1 = Tx.y1d_1;
        this.z1d_1 = Tx.z1d_1;
        this.b1e_1 = txstate;
        this.a1e_1 = Tx.a1e_1;
        return Unit_instance;
      case 24:
        this.u1d_1 = Tx.u1d_1;
        this.x1d_1 = Tx.x1d_1;
        this.y1d_1 = Tx.y1d_1;
        this.z1d_1 = Tx.z1d_1;
        this.b1e_1 = txstate;
        this.a1e_1 = Tx.a1e_1;
        return Unit_instance;
      case 8:
        this.y1d_1 = Tx.y1d_1;
        this.z1d_1 = Tx.z1d_1;
        this.b1e_1 = txstate;
        this.a1e_1 = Tx.a1e_1;
        return Unit_instance;
      case 48:
        this.w1d_1 = Tx.w1d_1;
        this.v1d_1 = Tx.v1d_1;
        this.u1d_1 = Tx.u1d_1;
        this.x1d_1 = Tx.x1d_1;
        this.b1e_1 = txstate;
        this.a1e_1 = Tx.a1e_1;
        return Unit_instance;
      case 16:
        this.u1d_1 = Tx.u1d_1;
        this.x1d_1 = Tx.x1d_1;
        this.b1e_1 = txstate;
        this.a1e_1 = Tx.a1e_1;
        return Unit_instance;
      case 40:
        this.y1d_1 = Tx.y1d_1;
        this.z1d_1 = Tx.z1d_1;
        this.w1d_1 = Tx.w1d_1;
        this.v1d_1 = Tx.v1d_1;
        this.x1d_1 = 0.0;
        this.u1d_1 = this.x1d_1;
        this.b1e_1 = txstate;
        this.a1e_1 = Tx.a1e_1;
        return Unit_instance;
      case 32:
        this.w1d_1 = Tx.w1d_1;
        this.v1d_1 = Tx.v1d_1;
        this.x1d_1 = 0.0;
        this.u1d_1 = this.x1d_1;
        this.b1e_1 = txstate;
        this.a1e_1 = Tx.a1e_1;
        return Unit_instance;
      case 15:
      case 14:
      case 13:
      case 12:
      case 11:
      case 10:
      case 9:
        this.l1d(Tx.y1d_1, Tx.z1d_1);
        return Unit_instance;
      case 23:
      case 22:
      case 21:
      case 20:
      case 19:
      case 18:
      case 17:
        this.n1d(Tx.u1d_1, Tx.x1d_1);
        return Unit_instance;
      case 39:
      case 38:
        T01 = Tx.w1d_1;
        T10 = Tx.v1d_1;
        M0 = this.u1d_1;
        this.u1d_1 = this.w1d_1 * T10;
        this.w1d_1 = M0 * T01;
        M0 = this.v1d_1;
        this.v1d_1 = this.x1d_1 * T10;
        this.x1d_1 = M0 * T01;
        this.a1e_1 = -1;
        return Unit_instance;
      case 37:
      case 36:
        this.u1d_1 = this.w1d_1 * Tx.v1d_1;
        this.w1d_1 = 0.0;
        this.x1d_1 = this.v1d_1 * Tx.w1d_1;
        this.v1d_1 = 0.0;
        this.b1e_1 = mystate ^ 6;
        this.a1e_1 = -1;
        return Unit_instance;
      case 35:
      case 34:
        this.w1d_1 = this.u1d_1 * Tx.w1d_1;
        this.u1d_1 = 0.0;
        this.v1d_1 = this.x1d_1 * Tx.v1d_1;
        this.x1d_1 = 0.0;
        this.b1e_1 = mystate ^ 6;
        this.a1e_1 = -1;
        return Unit_instance;
      case 33:
        this.u1d_1 = 0.0;
        this.w1d_1 = Tx.w1d_1;
        this.v1d_1 = Tx.v1d_1;
        this.x1d_1 = 0.0;
        this.b1e_1 = 5;
        this.a1e_1 = -1;
        return Unit_instance;
    }
    T01 = Tx.w1d_1;
    T10 = Tx.v1d_1;
    switch (mystate) {
      case 6:
        this.b1e_1 = mystate | txstate;
        M0 = this.u1d_1;
        M1 = this.w1d_1;
        this.u1d_1 = T00 * M0 + T10 * M1;
        this.w1d_1 = T01 * M0 + T11 * M1;
        this.y1d_1 = this.y1d_1 + (T02 * M0 + T12 * M1);
        M0 = this.v1d_1;
        M1 = this.x1d_1;
        this.v1d_1 = T00 * M0 + T10 * M1;
        this.x1d_1 = T01 * M0 + T11 * M1;
        this.z1d_1 = this.z1d_1 + (T02 * M0 + T12 * M1);
        this.a1e_1 = -1;
        return Unit_instance;
      case 7:
        M0 = this.u1d_1;
        M1 = this.w1d_1;
        this.u1d_1 = T00 * M0 + T10 * M1;
        this.w1d_1 = T01 * M0 + T11 * M1;
        this.y1d_1 = this.y1d_1 + (T02 * M0 + T12 * M1);
        M0 = this.v1d_1;
        M1 = this.x1d_1;
        this.v1d_1 = T00 * M0 + T10 * M1;
        this.x1d_1 = T01 * M0 + T11 * M1;
        this.z1d_1 = this.z1d_1 + (T02 * M0 + T12 * M1);
        this.a1e_1 = -1;
        return Unit_instance;
      case 5:
      case 4:
        M0 = this.w1d_1;
        this.u1d_1 = T10 * M0;
        this.w1d_1 = T11 * M0;
        this.y1d_1 = this.y1d_1 + T12 * M0;
        M0 = this.v1d_1;
        this.v1d_1 = T00 * M0;
        this.x1d_1 = T01 * M0;
        this.z1d_1 = this.z1d_1 + T02 * M0;
        break;
      case 3:
      case 2:
        M0 = this.u1d_1;
        this.u1d_1 = T00 * M0;
        this.w1d_1 = T01 * M0;
        this.y1d_1 = this.y1d_1 + T02 * M0;
        M0 = this.x1d_1;
        this.v1d_1 = T10 * M0;
        this.x1d_1 = T11 * M0;
        this.z1d_1 = this.z1d_1 + T12 * M0;
        break;
      case 1:
        this.u1d_1 = T00;
        this.w1d_1 = T01;
        this.y1d_1 = this.y1d_1 + T02;
        this.v1d_1 = T10;
        this.x1d_1 = T11;
        this.z1d_1 = this.z1d_1 + T12;
        this.b1e_1 = txstate | 1;
        this.a1e_1 = -1;
        return Unit_instance;
    }
    updateState(this);
  };
  protoOf(AffineTransformImpl).t1e = function (m00, m10, m01, m11, m02, m12) {
    return new AffineTransformImpl(m00, m10, m01, m11, m02, m12);
  };
  protoOf(AffineTransformImpl).r1e = function (m00, m10, m01, m11, m02, m12, $super) {
    m00 = m00 === VOID ? this.u1d_1 : m00;
    m10 = m10 === VOID ? this.v1d_1 : m10;
    m01 = m01 === VOID ? this.w1d_1 : m01;
    m11 = m11 === VOID ? this.x1d_1 : m11;
    m02 = m02 === VOID ? this.y1d_1 : m02;
    m12 = m12 === VOID ? this.z1d_1 : m12;
    return $super === VOID ? this.t1e(m00, m10, m01, m11, m02, m12) : $super.t1e.call(this, m00, m10, m01, m11, m02, m12);
  };
  protoOf(AffineTransformImpl).toString = function () {
    return 'AffineTransformImpl(m00=' + this.u1d_1 + ', m10=' + this.v1d_1 + ', m01=' + this.w1d_1 + ', m11=' + this.x1d_1 + ', m02=' + this.y1d_1 + ', m12=' + this.z1d_1 + ')';
  };
  protoOf(AffineTransformImpl).hashCode = function () {
    var result = getNumberHashCode(this.u1d_1);
    result = imul(result, 31) + getNumberHashCode(this.v1d_1) | 0;
    result = imul(result, 31) + getNumberHashCode(this.w1d_1) | 0;
    result = imul(result, 31) + getNumberHashCode(this.x1d_1) | 0;
    result = imul(result, 31) + getNumberHashCode(this.y1d_1) | 0;
    result = imul(result, 31) + getNumberHashCode(this.z1d_1) | 0;
    return result;
  };
  protoOf(AffineTransformImpl).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof AffineTransformImpl))
      return false;
    if (!equals(this.u1d_1, other.u1d_1))
      return false;
    if (!equals(this.v1d_1, other.v1d_1))
      return false;
    if (!equals(this.w1d_1, other.w1d_1))
      return false;
    if (!equals(this.x1d_1, other.x1d_1))
      return false;
    if (!equals(this.y1d_1, other.y1d_1))
      return false;
    if (!equals(this.z1d_1, other.z1d_1))
      return false;
    return true;
  };
  function Dimension2D_init_$Init$(width, height, $this) {
    Dimension2D.call($this, width, height);
    return $this;
  }
  function Dimension2D_init_$Create$(width, height) {
    return Dimension2D_init_$Init$(width, height, objectCreate(protoOf(Dimension2D)));
  }
  function Dimension2D(width, height) {
    this.u1e_1 = width;
    this.v1e_1 = height;
    this.w1e_1 = numberToInt(this.u1e_1);
    this.x1e_1 = numberToInt(this.v1e_1);
  }
  protoOf(Dimension2D).toString = function () {
    return 'Dimension2D(width=' + this.u1e_1 + ', height=' + this.v1e_1 + ')';
  };
  protoOf(Dimension2D).hashCode = function () {
    var result = getNumberHashCode(this.u1e_1);
    result = imul(result, 31) + getNumberHashCode(this.v1e_1) | 0;
    return result;
  };
  protoOf(Dimension2D).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof Dimension2D))
      return false;
    if (!equals(this.u1e_1, other.u1e_1))
      return false;
    if (!equals(this.v1e_1, other.v1e_1))
      return false;
    return true;
  };
  var Direction_EAST_instance;
  var Direction_NORTH_instance;
  var Direction_WEST_instance;
  var Direction_SOUTH_instance;
  function Companion_13() {
    Companion_instance_13 = this;
    this.y1e_1 = setOf([Direction_EAST_getInstance(), Direction_NORTH_getInstance(), Direction_WEST_getInstance(), Direction_SOUTH_getInstance()]);
    this.z1e_1 = setOf([Direction_EAST_getInstance(), Direction_WEST_getInstance()]);
    this.a1f_1 = setOf([Direction_NORTH_getInstance(), Direction_SOUTH_getInstance()]);
    this.b1f_1 = setOf([Direction_EAST_getInstance(), Direction_NORTH_getInstance()]);
    this.c1f_1 = setOf([Direction_NORTH_getInstance(), Direction_WEST_getInstance()]);
    this.d1f_1 = setOf([Direction_SOUTH_getInstance(), Direction_EAST_getInstance()]);
    this.e1f_1 = setOf([Direction_SOUTH_getInstance(), Direction_WEST_getInstance()]);
    this.f1f_1 = mapOf([to(Direction_EAST_getInstance(), setOf([Direction_NORTH_getInstance(), Direction_SOUTH_getInstance()])), to(Direction_NORTH_getInstance(), setOf([Direction_EAST_getInstance(), Direction_WEST_getInstance()])), to(Direction_WEST_getInstance(), setOf([Direction_NORTH_getInstance(), Direction_SOUTH_getInstance()])), to(Direction_SOUTH_getInstance(), setOf([Direction_EAST_getInstance(), Direction_WEST_getInstance()]))]);
    this.g1f_1 = mapOf([to(Direction_EAST_getInstance(), setOf([Direction_NORTH_getInstance(), Direction_SOUTH_getInstance(), Direction_WEST_getInstance()])), to(Direction_NORTH_getInstance(), setOf([Direction_EAST_getInstance(), Direction_SOUTH_getInstance(), Direction_WEST_getInstance()])), to(Direction_WEST_getInstance(), setOf([Direction_NORTH_getInstance(), Direction_EAST_getInstance(), Direction_SOUTH_getInstance()])), to(Direction_SOUTH_getInstance(), setOf([Direction_NORTH_getInstance(), Direction_EAST_getInstance(), Direction_WEST_getInstance()]))]);
  }
  protoOf(Companion_13).h1f = function (name) {
    var indexedObject = values_1();
    var inductionVariable = 0;
    var last = indexedObject.length;
    while (inductionVariable < last) {
      var dir = indexedObject[inductionVariable];
      inductionVariable = inductionVariable + 1 | 0;
      if (dir.k1f_1 === name) {
        return dir;
      }
    }
    throw IllegalArgumentException_init_$Create$('unknown Direction ' + name);
  };
  protoOf(Companion_13).o1f = function (dx, dy) {
    var tmp0_elvis_lhs = this.p1f(dx, dy);
    var tmp;
    if (tmp0_elvis_lhs == null) {
      throw IllegalArgumentException_init_$Create$('Cannot determine Direction for (' + dx + ',' + dy + ')');
    } else {
      tmp = tmp0_elvis_lhs;
    }
    return tmp;
  };
  protoOf(Companion_13).p1f = function (dx, dy) {
    var indexedObject = values_1();
    var inductionVariable = 0;
    var last = indexedObject.length;
    while (inductionVariable < last) {
      var dir = indexedObject[inductionVariable];
      inductionVariable = inductionVariable + 1 | 0;
      if (dir.l1f_1 === dx && dir.m1f_1 === dy) {
        return dir;
      }
    }
    return null;
  };
  protoOf(Companion_13).q1f = function (p1, p2) {
    return this.p1f(numberToInt(Geometry_instance.r1f(p2.kn_1 - p1.kn_1)), numberToInt(Geometry_instance.r1f(p2.ln_1 - p1.ln_1)));
  };
  protoOf(Companion_13).s1f = function (rotation) {
    var indexedObject = values_1();
    var inductionVariable = 0;
    var last = indexedObject.length;
    while (inductionVariable < last) {
      var dir = indexedObject[inductionVariable];
      inductionVariable = inductionVariable + 1 | 0;
      if (dir.n1f_1 === rotation) {
        return dir;
      }
    }
    throw IllegalArgumentException_init_$Create$('Cannot determine Direction for Rotation ' + rotation.toString());
  };
  protoOf(Companion_13).t1f = function (directions) {
    // Inline function 'kotlin.collections.mutableSetOf' call
    var result = LinkedHashSet_init_$Create$();
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = directions.i();
    while (_iterator__ex2g4s.j()) {
      var element = _iterator__ex2g4s.k();
      result.h(element.u1f());
    }
    return result;
  };
  var Companion_instance_13;
  function Companion_getInstance_13() {
    Direction_initEntries();
    if (Companion_instance_13 == null)
      new Companion_13();
    return Companion_instance_13;
  }
  function values_1() {
    return [Direction_EAST_getInstance(), Direction_NORTH_getInstance(), Direction_WEST_getInstance(), Direction_SOUTH_getInstance()];
  }
  var Direction_entriesInitialized;
  function Direction_initEntries() {
    if (Direction_entriesInitialized)
      return Unit_instance;
    Direction_entriesInitialized = true;
    Direction_EAST_instance = new Direction('EAST', 0, 'east', 1, 0, Rotation_R0_getInstance());
    Direction_NORTH_instance = new Direction('NORTH', 1, 'north', 0, -1, Rotation_R90_getInstance());
    Direction_WEST_instance = new Direction('WEST', 2, 'west', -1, 0, Rotation_R180_getInstance());
    Direction_SOUTH_instance = new Direction('SOUTH', 3, 'south', 0, 1, Rotation_R270_getInstance());
    Companion_getInstance_13();
  }
  function Direction(name, ordinal, customName, dx, dy, rotation) {
    Enum.call(this, name, ordinal);
    this.k1f_1 = customName;
    this.l1f_1 = dx;
    this.m1f_1 = dy;
    this.n1f_1 = rotation;
  }
  protoOf(Direction).toString = function () {
    var tmp;
    switch (this.l2_1) {
      case 0:
        tmp = Translations_getInstance().bn('graph.property.direction.east.name', []);
        break;
      case 1:
        tmp = Translations_getInstance().bn('graph.property.direction.north.name', []);
        break;
      case 2:
        tmp = Translations_getInstance().bn('graph.property.direction.west.name', []);
        break;
      case 3:
        tmp = Translations_getInstance().bn('graph.property.direction.south.name', []);
        break;
      default:
        noWhenBranchMatchedException();
        break;
    }
    return tmp;
  };
  protoOf(Direction).k = function () {
    return values_1()[(this.l2_1 + 1 | 0) % 4 | 0];
  };
  protoOf(Direction).o3 = function () {
    return values_1()[(this.l2_1 + 3 | 0) % 4 | 0];
  };
  protoOf(Direction).u1f = function () {
    return values_1()[(this.l2_1 + 2 | 0) % 4 | 0];
  };
  protoOf(Direction).v1f = function () {
    var tmp;
    switch (this.l2_1) {
      case 1:
      case 3:
        tmp = this;
        break;
      case 0:
      case 2:
        tmp = this.u1f();
        break;
      default:
        noWhenBranchMatchedException();
        break;
    }
    return tmp;
  };
  protoOf(Direction).w1f = function () {
    var tmp;
    switch (this.l2_1) {
      case 1:
      case 3:
        tmp = this.u1f();
        break;
      case 0:
      case 2:
        tmp = this;
        break;
      default:
        noWhenBranchMatchedException();
        break;
    }
    return tmp;
  };
  protoOf(Direction).x1f = function () {
    return Companion_getInstance_13().o1f(abs(this.l1f_1), abs(this.m1f_1));
  };
  protoOf(Direction).y1f = function (value) {
    return new Point2D(this.l1f_1 * value, this.m1f_1 * value);
  };
  protoOf(Direction).z1f = function () {
    return this.m1f_1 === 0;
  };
  protoOf(Direction).a1g = function () {
    return this.l1f_1 === 0;
  };
  protoOf(Direction).b1g = function (newDirection) {
    if (newDirection.equals(this)) {
      return Turn_NONE_getInstance();
    }
    if (newDirection.equals(this.u1f())) {
      return Turn_AROUND_getInstance();
    }
    if (newDirection.equals(this.k())) {
      return Turn_LEFT_getInstance();
    }
    return Turn_RIGHT_getInstance();
  };
  protoOf(Direction).c1g = function () {
    return Point2D_init_$Create$_0(this.l1f_1, this.m1f_1);
  };
  protoOf(Direction).d1g = function () {
    return ensureNotNull(Companion_getInstance_13().f1f_1.g2(this));
  };
  protoOf(Direction).e1g = function () {
    return ensureNotNull(Companion_getInstance_13().g1f_1.g2(this));
  };
  function Direction_EAST_getInstance() {
    Direction_initEntries();
    return Direction_EAST_instance;
  }
  function Direction_NORTH_getInstance() {
    Direction_initEntries();
    return Direction_NORTH_instance;
  }
  function Direction_WEST_getInstance() {
    Direction_initEntries();
    return Direction_WEST_instance;
  }
  function Direction_SOUTH_getInstance() {
    Direction_initEntries();
    return Direction_SOUTH_instance;
  }
  function Ellipse2D_init_$Init$(x, y, w, h, $this) {
    Ellipse2D.call($this, x, y, w, h);
    return $this;
  }
  function Ellipse2D_init_$Create$(x, y, w, h) {
    return Ellipse2D_init_$Init$(x, y, w, h, objectCreate(protoOf(Ellipse2D)));
  }
  function Ellipse2D(x, y, width, height) {
    x = x === VOID ? 0.0 : x;
    y = y === VOID ? 0.0 : y;
    width = width === VOID ? 0.0 : width;
    height = height === VOID ? 0.0 : height;
    AbstractRectangularShape.call(this, x, y, width, height);
    this.j1g_1 = x;
    this.k1g_1 = y;
    this.l1g_1 = width;
    this.m1g_1 = height;
  }
  protoOf(Ellipse2D).c1c = function (_set____db54di) {
    this.j1g_1 = _set____db54di;
  };
  protoOf(Ellipse2D).p1a = function () {
    return this.j1g_1;
  };
  protoOf(Ellipse2D).d1c = function (_set____db54di) {
    this.k1g_1 = _set____db54di;
  };
  protoOf(Ellipse2D).q1a = function () {
    return this.k1g_1;
  };
  protoOf(Ellipse2D).e1c = function (_set____db54di) {
    this.l1g_1 = _set____db54di;
  };
  protoOf(Ellipse2D).f1c = function () {
    return this.l1g_1;
  };
  protoOf(Ellipse2D).g1c = function (_set____db54di) {
    this.m1g_1 = _set____db54di;
  };
  protoOf(Ellipse2D).h1c = function () {
    return this.m1g_1;
  };
  protoOf(Ellipse2D).go = function (x, y) {
    if (this.l1g_1 <= 0.0) {
      return false;
    }
    var xNorm = (x - this.j1g_1) / this.l1g_1 - 0.5;
    if (this.m1g_1 <= 0.0) {
      return false;
    }
    var yNorm = (y - this.k1g_1) / this.m1g_1 - 0.5;
    return xNorm * xNorm + yNorm * yNorm < 0.25;
  };
  protoOf(Ellipse2D).ho = function (x, y, width, height) {
    return this.go(x, y) && this.go(x + width, y) && this.go(x, y + height) && this.go(x + width, y + height);
  };
  function Geometry() {
  }
  protoOf(Geometry).n1g = function (a, b) {
    // Inline function 'kotlin.math.abs' call
    var x = a - b;
    return Math.abs(x) <= 1.0E-7;
  };
  protoOf(Geometry).r1f = function (value) {
    // Inline function 'kotlin.math.abs' call
    if (Math.abs(value) <= 1.0E-7) {
      return 0.0;
    }
    // Inline function 'kotlin.math.sign' call
    return sign(value);
  };
  protoOf(Geometry).o1g = function (angle) {
    if (angle < 0) {
      // Inline function 'kotlin.math.abs' call
      var x = angle % 6.283185307179586;
      return 6.283185307179586 - Math.abs(x);
    }
    return angle % 6.283185307179586;
  };
  protoOf(Geometry).p1g = function (angle1, angle2) {
    return !(angle1 === angle2) && this.o1g(angle1 - angle2) <= 3.141592653589793;
  };
  protoOf(Geometry).q1g = function (p1, p2) {
    return this.r1g(p1.kn_1, p1.ln_1, p2.kn_1, p2.ln_1);
  };
  protoOf(Geometry).r1g = function (x1, y1, x2, y2) {
    var fx = x2 > x1 ? 1 : -1;
    var fy = y2 > y1 ? -1 : 1;
    var angle;
    if (x1 === x2 && y1 === y2) {
      return 0.0;
    }
    if (this.n1g(x1, x2)) {
      angle = fy === 1 ? 1.5707963267948966 : 3 * 1.5707963267948966;
    } else {
      // Inline function 'kotlin.math.abs' call
      var x = y2 - y1;
      var tmp = Math.abs(x);
      // Inline function 'kotlin.math.abs' call
      var x_0 = x2 - x1;
      // Inline function 'kotlin.math.atan' call
      var x_1 = tmp / Math.abs(x_0);
      angle = Math.atan(x_1);
      if (fx === 1) {
        if (fy === -1)
          angle = 2 * 3.141592653589793 - angle;
      } else {
        angle = fy === 1 ? 3.141592653589793 - angle : 3.141592653589793 + angle;
      }
    }
    return angle;
  };
  protoOf(Geometry).s1g = function (x1, y1, x2, y2) {
    return new Point2D(-(y2 - y1), x2 - x1);
  };
  protoOf(Geometry).t1g = function (p1, p2) {
    return this.s1g(p1.kn_1, p1.ln_1, p2.kn_1, p2.ln_1);
  };
  protoOf(Geometry).u1g = function (p1, p2) {
    return new Point2D((p1.kn_1 + p2.kn_1) / 2, (p1.ln_1 + p2.ln_1) / 2);
  };
  protoOf(Geometry).v1g = function (x, y, angle) {
    // Inline function 'kotlin.math.cos' call
    var tmp = x * Math.cos(angle);
    // Inline function 'kotlin.math.sin' call
    var tmp_0 = tmp - y * Math.sin(angle);
    // Inline function 'kotlin.math.cos' call
    var tmp_1 = y * Math.cos(angle);
    // Inline function 'kotlin.math.sin' call
    var tmp$ret$3 = Math.sin(angle);
    return new Point2D(tmp_0, tmp_1 + x * tmp$ret$3);
  };
  protoOf(Geometry).w1g = function (x, y, center, angle) {
    return center.eo(this.v1g(x - center.kn_1, y - center.ln_1, angle));
  };
  protoOf(Geometry).x1g = function (p, center, angle) {
    return this.w1g(p.kn_1, p.ln_1, center, angle);
  };
  protoOf(Geometry).y1g = function (center, r, p) {
    var angle = this.q1g(center, p);
    // Inline function 'kotlin.math.cos' call
    var tmp$ret$0 = Math.cos(angle);
    var tmp = center.kn_1 + r * tmp$ret$0;
    // Inline function 'kotlin.math.sin' call
    var tmp$ret$1 = Math.sin(angle);
    return new Point2D(tmp, center.ln_1 - r * tmp$ret$1);
  };
  protoOf(Geometry).z1g = function (p1, p2, p0) {
    // Inline function 'kotlin.math.pow' call
    var this_0 = p2.ln_1 - p1.ln_1;
    var tmp = Math.pow(this_0, 2);
    // Inline function 'kotlin.math.pow' call
    var this_1 = p2.kn_1 - p1.kn_1;
    // Inline function 'kotlin.math.sqrt' call
    var x = tmp + Math.pow(this_1, 2);
    var divisor = Math.sqrt(x);
    var tmp_0;
    if (divisor === 0.0) {
      tmp_0 = 0.0;
    } else {
      tmp_0 = ((p2.ln_1 - p1.ln_1) * p0.kn_1 - (p2.kn_1 - p1.kn_1) * p0.ln_1 + p2.kn_1 * p1.ln_1 - p2.ln_1 * p1.kn_1) / divisor;
    }
    return tmp_0;
  };
  var Geometry_instance;
  function Geometry_getInstance() {
    return Geometry_instance;
  }
  function MutableRectangularShape() {
  }
  function Path() {
  }
  function Companion_14() {
    Companion_instance_14 = this;
    this.w1a_1 = new Point2D();
  }
  protoOf(Companion_14).a1h = function (p1, p2) {
    var tmp0 = p1.kn_1;
    // Inline function 'kotlin.math.min' call
    var b = p2.kn_1;
    var tmp = Math.min(tmp0, b);
    var tmp0_0 = p1.kn_1;
    // Inline function 'kotlin.math.max' call
    var b_0 = p2.kn_1;
    var tmp$ret$1 = Math.max(tmp0_0, b_0);
    return rangeTo(tmp, tmp$ret$1);
  };
  protoOf(Companion_14).b1h = function (p1, p2) {
    var tmp0 = p1.ln_1;
    // Inline function 'kotlin.math.min' call
    var b = p2.ln_1;
    var tmp = Math.min(tmp0, b);
    var tmp0_0 = p1.ln_1;
    // Inline function 'kotlin.math.max' call
    var b_0 = p2.ln_1;
    var tmp$ret$1 = Math.max(tmp0_0, b_0);
    return rangeTo(tmp, tmp$ret$1);
  };
  var Companion_instance_14;
  function Companion_getInstance_14() {
    if (Companion_instance_14 == null)
      new Companion_14();
    return Companion_instance_14;
  }
  function Point2D_init_$Init$(p, $this) {
    Point2D.call($this, p.kn_1, p.ln_1);
    return $this;
  }
  function Point2D_init_$Create$(p) {
    return Point2D_init_$Init$(p, objectCreate(protoOf(Point2D)));
  }
  function Point2D_init_$Init$_0(x, y, $this) {
    Point2D.call($this, x, y);
    return $this;
  }
  function Point2D_init_$Create$_0(x, y) {
    return Point2D_init_$Init$_0(x, y, objectCreate(protoOf(Point2D)));
  }
  function Point2D(x, y) {
    Companion_getInstance_14();
    x = x === VOID ? 0.0 : x;
    y = y === VOID ? 0.0 : y;
    this.kn_1 = x;
    this.ln_1 = y;
  }
  protoOf(Point2D).toString = function () {
    return 'Point2D(' + toDoubleString(this.kn_1) + ',' + toDoubleString(this.ln_1) + ')';
  };
  protoOf(Point2D).s1c = function () {
    return numberToInt(this.kn_1);
  };
  protoOf(Point2D).t1c = function () {
    return numberToInt(this.ln_1);
  };
  protoOf(Point2D).c1h = function () {
    return new Point2D(-this.kn_1, -this.ln_1);
  };
  protoOf(Point2D).d1h = function (x, y) {
    var px = x - this.kn_1;
    var py = y - this.ln_1;
    return px * px + py * py;
  };
  protoOf(Point2D).e1h = function (x, y) {
    // Inline function 'kotlin.math.sqrt' call
    var x_0 = this.d1h(x, y);
    return Math.sqrt(x_0);
  };
  protoOf(Point2D).f1h = function (p) {
    return this.e1h(p.kn_1, p.ln_1);
  };
  protoOf(Point2D).g1h = function (x) {
    return new Point2D(x + (x - this.kn_1), this.ln_1);
  };
  protoOf(Point2D).h1h = function (y) {
    return new Point2D(this.kn_1, y + (y - this.ln_1));
  };
  protoOf(Point2D).i1h = function (x, y, area) {
    return this.kn_1 >= x - area && this.kn_1 <= x + area && this.ln_1 >= y - area && this.ln_1 <= y + area;
  };
  protoOf(Point2D).vn = function (dx, dy) {
    return new Point2D(this.kn_1 + dx, this.ln_1 + dy);
  };
  protoOf(Point2D).eo = function (p) {
    return this.vn(p.kn_1, p.ln_1);
  };
  protoOf(Point2D).j1h = function (p) {
    return new Point2D(this.kn_1 - p.kn_1, this.ln_1 - p.ln_1);
  };
  protoOf(Point2D).y1f = function (factor) {
    return new Point2D(this.kn_1 * factor, this.ln_1 * factor);
  };
  protoOf(Point2D).k1h = function (dividend) {
    return new Point2D(this.kn_1 / dividend, this.ln_1 / dividend);
  };
  protoOf(Point2D).l1h = function (dx) {
    return new Point2D(this.kn_1 + dx, this.ln_1);
  };
  protoOf(Point2D).m1h = function (dy) {
    return new Point2D(this.kn_1, this.ln_1 + dy);
  };
  protoOf(Point2D).n1h = function (halfSize) {
    return new Rectangle2D(this.kn_1 - halfSize, this.ln_1 - halfSize, 2 * halfSize, 2 * halfSize);
  };
  protoOf(Point2D).equals = function (other) {
    if (this === other)
      return true;
    if (other == null || !getKClassFromExpression(this).equals(getKClassFromExpression(other)))
      return false;
    if (!(other instanceof Point2D))
      THROW_CCE();
    if (!Geometry_instance.n1g(this.kn_1, other.kn_1))
      return false;
    if (!Geometry_instance.n1g(this.ln_1, other.ln_1))
      return false;
    return true;
  };
  protoOf(Point2D).hashCode = function () {
    var result = getNumberHashCode(this.kn_1);
    result = imul(31, result) + getNumberHashCode(this.ln_1) | 0;
    return result;
  };
  function Rectangle2D_init_$Init$(x, y, w, h, $this) {
    Rectangle2D.call($this, x, y, w, h);
    return $this;
  }
  function Rectangle2D_init_$Create$(x, y, w, h) {
    return Rectangle2D_init_$Init$(x, y, w, h, objectCreate(protoOf(Rectangle2D)));
  }
  function Rectangle2D_init_$Init$_0(rect, $this) {
    Rectangle2D.call($this, rect.p1a(), rect.q1a(), rect.f1c(), rect.h1c());
    return $this;
  }
  function Rectangle2D_init_$Create$_0(rect) {
    return Rectangle2D_init_$Init$_0(rect, objectCreate(protoOf(Rectangle2D)));
  }
  function Rectangle2D_init_$Init$_1(location, width, height, $this) {
    Rectangle2D.call($this, location.kn_1, location.ln_1, width, height);
    return $this;
  }
  function Rectangle2D_init_$Create$_1(location, width, height) {
    return Rectangle2D_init_$Init$_1(location, width, height, objectCreate(protoOf(Rectangle2D)));
  }
  function Rectangle2D_init_$Init$_2(location, dimension, $this) {
    Rectangle2D.call($this, location.kn_1, location.ln_1, dimension.u1e_1, dimension.v1e_1);
    return $this;
  }
  function Rectangle2D_init_$Create$_2(location, dimension) {
    return Rectangle2D_init_$Init$_2(location, dimension, objectCreate(protoOf(Rectangle2D)));
  }
  function Companion_15() {
  }
  protoOf(Companion_15).o1h = function () {
    return Rectangle2D_init_$Create$(0, 0, 0, 0);
  };
  protoOf(Companion_15).wu = function (point) {
    return Rectangle2D_init_$Create$_1(point, 0.0, 0.0);
  };
  protoOf(Companion_15).p1h = function (center, w, h) {
    return new Rectangle2D(center.kn_1 - w / 2, center.ln_1 - h / 2, w, h);
  };
  var Companion_instance_15;
  function Companion_getInstance_15() {
    return Companion_instance_15;
  }
  function Rectangle2D(x, y, width, height) {
    x = x === VOID ? 0.0 : x;
    y = y === VOID ? 0.0 : y;
    width = width === VOID ? 0.0 : width;
    height = height === VOID ? 0.0 : height;
    AbstractRectangularShape.call(this, x, y, width, height);
    this.u1h_1 = x;
    this.v1h_1 = y;
    this.w1h_1 = width;
    this.x1h_1 = height;
  }
  protoOf(Rectangle2D).c1c = function (_set____db54di) {
    this.u1h_1 = _set____db54di;
  };
  protoOf(Rectangle2D).p1a = function () {
    return this.u1h_1;
  };
  protoOf(Rectangle2D).d1c = function (_set____db54di) {
    this.v1h_1 = _set____db54di;
  };
  protoOf(Rectangle2D).q1a = function () {
    return this.v1h_1;
  };
  protoOf(Rectangle2D).e1c = function (_set____db54di) {
    this.w1h_1 = _set____db54di;
  };
  protoOf(Rectangle2D).f1c = function () {
    return this.w1h_1;
  };
  protoOf(Rectangle2D).g1c = function (_set____db54di) {
    this.x1h_1 = _set____db54di;
  };
  protoOf(Rectangle2D).h1c = function () {
    return this.x1h_1;
  };
  protoOf(Rectangle2D).y1h = function (x, y, width, height) {
    return new Rectangle2D(x, y, width, height);
  };
  protoOf(Rectangle2D).z1h = function (x, y, width, height, $super) {
    x = x === VOID ? this.u1h_1 : x;
    y = y === VOID ? this.v1h_1 : y;
    width = width === VOID ? this.w1h_1 : width;
    height = height === VOID ? this.x1h_1 : height;
    return $super === VOID ? this.y1h(x, y, width, height) : $super.y1h.call(this, x, y, width, height);
  };
  protoOf(Rectangle2D).toString = function () {
    return 'Rectangle2D(x=' + this.u1h_1 + ', y=' + this.v1h_1 + ', width=' + this.w1h_1 + ', height=' + this.x1h_1 + ')';
  };
  protoOf(Rectangle2D).hashCode = function () {
    var result = getNumberHashCode(this.u1h_1);
    result = imul(result, 31) + getNumberHashCode(this.v1h_1) | 0;
    result = imul(result, 31) + getNumberHashCode(this.w1h_1) | 0;
    result = imul(result, 31) + getNumberHashCode(this.x1h_1) | 0;
    return result;
  };
  protoOf(Rectangle2D).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof Rectangle2D))
      return false;
    if (!equals(this.u1h_1, other.u1h_1))
      return false;
    if (!equals(this.v1h_1, other.v1h_1))
      return false;
    if (!equals(this.w1h_1, other.w1h_1))
      return false;
    if (!equals(this.x1h_1, other.x1h_1))
      return false;
    return true;
  };
  function RectangularShape() {
  }
  function Ring2D(x, y, width, height, thickness) {
    AbstractRectangularShape.call(this, x, y, width, height);
    this.e1i_1 = thickness;
  }
  var Rotation_R0_instance;
  var Rotation_R90_instance;
  var Rotation_R180_instance;
  var Rotation_R270_instance;
  function Companion_16() {
  }
  protoOf(Companion_16).h1f = function (name) {
    var indexedObject = values_2();
    var inductionVariable = 0;
    var last = indexedObject.length;
    while (inductionVariable < last) {
      var value = indexedObject[inductionVariable];
      inductionVariable = inductionVariable + 1 | 0;
      if (value.h1i_1 === name) {
        return value;
      }
    }
    throw IllegalArgumentException_init_$Create$('unknown Rotation ' + name);
  };
  var Companion_instance_16;
  function Companion_getInstance_16() {
    return Companion_instance_16;
  }
  function values_2() {
    return [Rotation_R0_getInstance(), Rotation_R90_getInstance(), Rotation_R180_getInstance(), Rotation_R270_getInstance()];
  }
  var Rotation_entriesInitialized;
  function Rotation_initEntries() {
    if (Rotation_entriesInitialized)
      return Unit_instance;
    Rotation_entriesInitialized = true;
    Rotation_R0_instance = new Rotation('R0', 0, '0', 0.0);
    Rotation_R90_instance = new Rotation('R90', 1, '90', 3 * 3.141592653589793 / 2);
    Rotation_R180_instance = new Rotation('R180', 2, '180', 3.141592653589793);
    Rotation_R270_instance = new Rotation('R270', 3, '270', 3.141592653589793 / 2);
  }
  function Rotation(name, ordinal, customName, angle) {
    Enum.call(this, name, ordinal);
    this.h1i_1 = customName;
    this.i1i_1 = angle;
    this.j1i_1 = AffineTransformImpl_init_$Create$();
    this.j1i_1.o1d(this.i1i_1);
  }
  protoOf(Rotation).k1i = function () {
    var tmp;
    switch (this.l2_1) {
      case 0:
        tmp = Rotation_R0_getInstance();
        break;
      case 1:
        tmp = Rotation_R270_getInstance();
        break;
      case 2:
        tmp = Rotation_R180_getInstance();
        break;
      case 3:
        tmp = Rotation_R90_getInstance();
        break;
      default:
        noWhenBranchMatchedException();
        break;
    }
    return tmp;
  };
  protoOf(Rotation).l1i = function (other) {
    return values_2()[(this.l2_1 + other.l2_1 | 0) % 4 | 0];
  };
  protoOf(Rotation).m1i = function (x, y) {
    var tmp;
    switch (this.l2_1) {
      case 0:
        tmp = new Point2D(x, y);
        break;
      case 1:
        tmp = new Point2D(y, -x);
        break;
      case 2:
        tmp = new Point2D(-x, -y);
        break;
      case 3:
        tmp = new Point2D(-y, x);
        break;
      default:
        noWhenBranchMatchedException();
        break;
    }
    return tmp;
  };
  protoOf(Rotation).n1i = function (pivot, x, y) {
    var p = this.m1i(x - pivot.kn_1, y - pivot.ln_1);
    return new Point2D(pivot.kn_1 + p.kn_1, pivot.ln_1 + p.ln_1);
  };
  protoOf(Rotation).o1i = function (pivot, point) {
    return this.n1i(pivot, point.kn_1, point.ln_1);
  };
  protoOf(Rotation).p1i = function (pivot, rect) {
    var p1 = this.m1i(rect.p1a() - pivot.kn_1, rect.q1a() - pivot.ln_1);
    var p2 = this.m1i(rect.p1a() + rect.f1c() - pivot.kn_1, rect.q1a() + rect.h1c() - pivot.ln_1);
    var tmp0 = p1.kn_1;
    // Inline function 'kotlin.math.min' call
    var b = p2.kn_1;
    var tmp = Math.min(tmp0, b);
    var tmp0_0 = p1.ln_1;
    // Inline function 'kotlin.math.min' call
    var b_0 = p2.ln_1;
    var tmp_0 = Math.min(tmp0_0, b_0);
    // Inline function 'kotlin.math.abs' call
    var x = p1.kn_1 - p2.kn_1;
    var tmp_1 = Math.abs(x);
    // Inline function 'kotlin.math.abs' call
    var x_0 = p1.ln_1 - p2.ln_1;
    var tmp$ret$3 = Math.abs(x_0);
    var newRect = new Rectangle2D(tmp, tmp_0, tmp_1, tmp$ret$3);
    newRect.i1c(newRect.u1h_1 + pivot.kn_1, newRect.v1h_1 + pivot.ln_1, newRect.w1h_1, newRect.x1h_1);
    return newRect;
  };
  protoOf(Rotation).q1i = function (dir) {
    var i = 0;
    var result = dir;
    while (i < this.l2_1) {
      result = result.k();
      i = i + 1 | 0;
    }
    return result;
  };
  function Rotation_R0_getInstance() {
    Rotation_initEntries();
    return Rotation_R0_instance;
  }
  function Rotation_R90_getInstance() {
    Rotation_initEntries();
    return Rotation_R90_instance;
  }
  function Rotation_R180_getInstance() {
    Rotation_initEntries();
    return Rotation_R180_instance;
  }
  function Rotation_R270_getInstance() {
    Rotation_initEntries();
    return Rotation_R270_instance;
  }
  function RoundRectangle2D_init_$Init$(location, dimension, arc, $this) {
    RoundRectangle2D.call($this, location.kn_1, location.ln_1, dimension.u1e_1, dimension.v1e_1, arc, arc);
    return $this;
  }
  function RoundRectangle2D_init_$Create$(location, dimension, arc) {
    return RoundRectangle2D_init_$Init$(location, dimension, arc, objectCreate(protoOf(RoundRectangle2D)));
  }
  function RoundRectangle2D(x, y, width, height, arcW, arcH) {
    AbstractRectangularShape.call(this, x, y, width, height);
    this.v1i_1 = arcW;
    this.w1i_1 = arcH;
  }
  function Shape() {
  }
  var Turn_LEFT_instance;
  var Turn_NONE_instance;
  var Turn_RIGHT_instance;
  var Turn_AROUND_instance;
  var Turn_entriesInitialized;
  function Turn_initEntries() {
    if (Turn_entriesInitialized)
      return Unit_instance;
    Turn_entriesInitialized = true;
    Turn_LEFT_instance = new Turn('LEFT', 0);
    Turn_NONE_instance = new Turn('NONE', 1);
    Turn_RIGHT_instance = new Turn('RIGHT', 2);
    Turn_AROUND_instance = new Turn('AROUND', 3);
  }
  function Turn(name, ordinal) {
    Enum.call(this, name, ordinal);
  }
  function Turn_LEFT_getInstance() {
    Turn_initEntries();
    return Turn_LEFT_instance;
  }
  function Turn_NONE_getInstance() {
    Turn_initEntries();
    return Turn_NONE_instance;
  }
  function Turn_RIGHT_getInstance() {
    Turn_initEntries();
    return Turn_RIGHT_instance;
  }
  function Turn_AROUND_getInstance() {
    Turn_initEntries();
    return Turn_AROUND_instance;
  }
  function Vector2D_init_$Init$(p, $this) {
    Vector2D.call($this, p.kn_1, p.ln_1);
    return $this;
  }
  function Vector2D_init_$Create$(p) {
    return Vector2D_init_$Init$(p, objectCreate(protoOf(Vector2D)));
  }
  function Vector2D(x, y) {
    this.x1i_1 = x;
    this.y1i_1 = y;
    this.z1i_1 = new Point2D(this.x1i_1, this.y1i_1);
  }
  protoOf(Vector2D).a1j = function () {
    // Inline function 'kotlin.math.sqrt' call
    var x = this.x1i_1 * this.x1i_1 + this.y1i_1 * this.y1i_1;
    return Math.sqrt(x);
  };
  protoOf(Vector2D).b1j = function () {
    var mag = this.a1j();
    return new Vector2D(this.x1i_1 / mag, this.y1i_1 / mag);
  };
  protoOf(Vector2D).y1f = function (s) {
    return new Vector2D(this.x1i_1 * s, this.y1i_1 * s);
  };
  function HelpId(id) {
    this.c1j_1 = id;
  }
  protoOf(HelpId).toString = function () {
    return 'HelpId(id=' + this.c1j_1 + ')';
  };
  protoOf(HelpId).hashCode = function () {
    return getStringHashCode(this.c1j_1);
  };
  protoOf(HelpId).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof HelpId))
      return false;
    if (!(this.c1j_1 === other.c1j_1))
      return false;
    return true;
  };
  function _get_LOG__e5r759_4($this) {
    var tmp0 = $this.d1j_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('LOG', 1, tmp, HelpSourceRegistry$_get_LOG_$ref_ujhjnz(), null);
    return tmp0.j2();
  }
  function HelpSourceRegistry$_get_LOG_$ref_ujhjnz() {
    return function (p0) {
      return _get_LOG__e5r759_4(p0);
    };
  }
  function HelpSourceRegistry() {
    HelpSourceRegistry_instance = this;
    this.d1j_1 = logger(getKClass(HelpSourceRegistry));
    var tmp = this;
    // Inline function 'kotlin.collections.mutableMapOf' call
    tmp.e1j_1 = LinkedHashMap_init_$Create$();
  }
  protoOf(HelpSourceRegistry).f1j = function (helpId, source) {
    // Inline function 'kotlin.collections.contains' call
    // Inline function 'kotlin.collections.containsKey' call
    var this_0 = this.e1j_1;
    if ((isInterface(this_0, KtMap) ? this_0 : THROW_CCE()).e2(helpId)) {
      _get_LOG__e5r759_4(this).nl('Replacing existing HelpId ' + helpId.c1j_1);
    }
    // Inline function 'kotlin.collections.set' call
    this.e1j_1.y1(helpId, source);
  };
  var HelpSourceRegistry_instance;
  function HelpSourceRegistry_getInstance() {
    if (HelpSourceRegistry_instance == null)
      new HelpSourceRegistry();
    return HelpSourceRegistry_instance;
  }
  function HelpSource(source) {
    this.g1j_1 = source;
  }
  protoOf(HelpSource).toString = function () {
    return this.g1j_1;
  };
  protoOf(HelpSource).hashCode = function () {
    return getStringHashCode(this.g1j_1);
  };
  protoOf(HelpSource).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof HelpSource))
      return false;
    if (!(this.g1j_1 === other.g1j_1))
      return false;
    return true;
  };
  function Companion_17() {
    Companion_instance_17 = this;
    this.wo_1 = new UnimplementedInvocationHandler();
  }
  protoOf(Companion_17).h1j = function (runnable) {
    this.wo_1.so(runnable);
  };
  var Companion_instance_17;
  function Companion_getInstance_17() {
    if (Companion_instance_17 == null)
      new Companion_17();
    return Companion_instance_17;
  }
  function InvocationHandler() {
    Companion_getInstance_17();
  }
  function UnimplementedInvocationHandler() {
    InvocationHandler.call(this);
  }
  protoOf(UnimplementedInvocationHandler).so = function (runnable) {
    throw UnsupportedOperationException_init_$Create$('not implemented');
  };
  function interpolate(_this__u8e3s4, x0, y1, y2) {
    return interpolateInt(x0, _this__u8e3s4.w(), y1, _this__u8e3s4.v(), y2);
  }
  function interpolateInt(x0, x1, y1, x2, y2) {
    var m = (y2 - y1 | 0) / (x2 - x1 | 0);
    return y1 + numberToInt(m * (x0 - x1 | 0)) | 0;
  }
  function toDoubleString(_this__u8e3s4) {
    var s = _this__u8e3s4.toString();
    if (!contains_0(s, '.')) {
      return s + '.0';
    }
    return s;
  }
  function near(_this__u8e3s4, value) {
    // Inline function 'kotlin.math.abs' call
    var x = _this__u8e3s4 - value;
    return Math.abs(x) <= 1.0E-7;
  }
  function formatRounded(_this__u8e3s4, precision) {
    precision = precision === VOID ? 1000.0 : precision;
    return toDoubleString(roundToInt(_this__u8e3s4 * precision) / precision);
  }
  function fillProperties($this, properties) {
    properties.et('base.language', Language_English_getInstance().qm_1);
    properties.et(LogSystem_getInstance().il_1, 'Info');
    properties.et('base.beginnerHelpTooltip', true);
    properties.et('base.dataLocation', DataLocation_Local_getInstance().fs_1);
    properties.et('base.network.connectionTimeout', 10);
    properties.et('jabbah.base.sound.enableSoundEffects', true);
    SoundEffects_instance.k1j($this.bp_1);
  }
  function BaseModule$lexerFactory$lambda(program) {
    return new DslLexer(program);
  }
  function BaseModule$semanticAnalyserFactory$lambda(symbolTable) {
    return new DslSemanticAnalyser(symbolTable);
  }
  function BaseModule$parserFactory$lambda(program, semanticAnalyser) {
    return new DslParser(BaseModule_getInstance().dp_1(program), semanticAnalyser);
  }
  function BaseModule$storingActivationRecordFactory$lambda(name, parent) {
    return new StoringActivationRecord(name, parent);
  }
  function BaseModule$interpreterFactory$lambda(node, memory) {
    return new Interpreter(node, memory);
  }
  function BaseModule() {
    BaseModule_instance = this;
    AbstractModule.call(this);
    this.yo_1 = 'base.network.connectionTimeout';
    this.zo_1 = new Properties();
    this.ap_1 = new Settings();
    this.bp_1 = new EventBusImpl();
    this.cp_1 = new ControlledTimeService();
    var tmp = this;
    tmp.dp_1 = BaseModule$lexerFactory$lambda;
    var tmp_0 = this;
    tmp_0.ep_1 = BaseModule$semanticAnalyserFactory$lambda;
    var tmp_1 = this;
    tmp_1.fp_1 = BaseModule$parserFactory$lambda;
    var tmp_2 = this;
    tmp_2.gp_1 = BaseModule$storingActivationRecordFactory$lambda;
    var tmp_3 = this;
    tmp_3.hp_1 = BaseModule$interpreterFactory$lambda;
    this.ip_1 = new DslGlobalFunctions();
    this.jp_1 = null;
  }
  protoOf(BaseModule).to = function () {
    Translations_getInstance().wm('jabbah-base');
    fillProperties(this, this.zo_1);
  };
  var BaseModule_instance;
  function BaseModule_getInstance() {
    if (BaseModule_instance == null)
      new BaseModule();
    return BaseModule_instance;
  }
  function State($outer) {
    this.ux_1 = $outer;
    this.nx_1 = 0;
    var tmp = this;
    var tmp_0;
    // Inline function 'kotlin.text.isEmpty' call
    var this_0 = this.ux_1.vx_1;
    if (charSequenceLength(this_0) === 0) {
      tmp_0 = null;
    } else {
      tmp_0 = first(this.ux_1.vx_1);
    }
    tmp.ox_1 = tmp_0;
    this.px_1 = 1;
    this.qx_1 = 1;
    this.rx_1 = 0;
    this.sx_1 = 1;
    this.tx_1 = 1;
  }
  protoOf(State).jw = function () {
    return new TextLocation(this.rx_1, this.sx_1, this.tx_1);
  };
  protoOf(State).l1j = function (other) {
    this.nx_1 = other.nx_1;
    this.ox_1 = other.ox_1;
    this.rx_1 = other.rx_1;
    this.px_1 = other.px_1;
    this.qx_1 = other.qx_1;
    return this;
  };
  function AbstractLexer(text) {
    this.vx_1 = text;
    this.wx_1 = new State(this);
    this.xx_1 = new State(this);
  }
  protoOf(AbstractLexer).jw = function () {
    return this.xx_1.jw();
  };
  protoOf(AbstractLexer).qy = function () {
    return this.dy(this.xx_1);
  };
  protoOf(AbstractLexer).ry = function () {
    return this.dy(this.wx_1.l1j(this.xx_1));
  };
  protoOf(AbstractLexer).yx = function (state) {
    return this.sy(state, 1);
  };
  protoOf(AbstractLexer).sy = function (state, count) {
    var peekPos = state.nx_1 + count | 0;
    if (peekPos > (this.vx_1.length - 1 | 0)) {
      return null;
    }
    return charCodeAt(this.vx_1, peekPos);
  };
  protoOf(AbstractLexer).fy = function (state) {
    var tmp;
    var tmp_0 = state.ox_1;
    if (!((tmp_0 == null ? null : new Char(tmp_0)) == null)) {
      var tmp_1 = state.ox_1;
      tmp = isWhitespace(ensureNotNull(tmp_1 == null ? null : new Char(tmp_1)).j1_1);
    } else {
      tmp = false;
    }
    return tmp;
  };
  protoOf(AbstractLexer).ey = function (state) {
    while (this.fy(state)) {
      this.zx(state);
    }
  };
  protoOf(AbstractLexer).zx = function (state) {
    var tmp = state.ox_1;
    if (equals(tmp == null ? null : new Char(tmp), new Char(_Char___init__impl__6a9atx(10)))) {
      state.px_1 = state.px_1 + 1 | 0;
      state.qx_1 = 0;
    }
    state.qx_1 = state.qx_1 + 1 | 0;
    state.nx_1 = state.nx_1 + 1 | 0;
    state.ox_1 = state.nx_1 > (this.vx_1.length - 1 | 0) ? null : charCodeAt(this.vx_1, state.nx_1);
  };
  protoOf(AbstractLexer).ly = function (state, token) {
    this.zx(state);
    return token;
  };
  protoOf(AbstractLexer).gy = function (state) {
    state.rx_1 = state.nx_1;
    state.sx_1 = state.px_1;
    state.tx_1 = state.qx_1;
  };
  function AbstractParser(lexer) {
    this.o11_1 = lexer;
    this.p11_1 = this.o11_1.qy();
  }
  protoOf(AbstractParser).e12 = function (metaData) {
    var tmp;
    try {
      tmp = this.xy();
    } catch ($p) {
      var tmp_0;
      if ($p instanceof DslError) {
        var e = $p;
        BaseModule_getInstance().bp_1.gu(new IssueImpl(IssueSeverity_Error_getInstance(), Translations_getInstance().bn('base.dsl.scriptError.msg', []), e.message, metaData.cw_1, metaData.dw_1));
        tmp_0 = null;
      } else {
        throw $p;
      }
      tmp = tmp_0;
    }
    return tmp;
  };
  protoOf(AbstractParser).t11 = function (type) {
    if (equals(ensureNotNull(this.p11_1).m11_1, type)) {
      this.p11_1 = this.o11_1.qy();
    } else {
      throw new SyntaxError(this.o11_1.jw(), Translations_getInstance().bn('base.dsl.expectedToken.msg', [type.cv()]));
    }
  };
  function Companion_18() {
    Companion_instance_18 = this;
    this.cx_1 = new TextLocation(0, 0, 0);
  }
  var Companion_instance_18;
  function Companion_getInstance_18() {
    if (Companion_instance_18 == null)
      new Companion_18();
    return Companion_instance_18;
  }
  function TextLocation(pos, row, column) {
    Companion_getInstance_18();
    this.m1j_1 = pos;
    this.n1j_1 = row;
    this.o1j_1 = column;
  }
  protoOf(TextLocation).toString = function () {
    return '' + this.n1j_1 + ':' + this.o1j_1;
  };
  protoOf(TextLocation).hashCode = function () {
    var result = this.m1j_1;
    result = imul(result, 31) + this.n1j_1 | 0;
    result = imul(result, 31) + this.o1j_1 | 0;
    return result;
  };
  protoOf(TextLocation).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof TextLocation))
      return false;
    if (!(this.m1j_1 === other.m1j_1))
      return false;
    if (!(this.n1j_1 === other.n1j_1))
      return false;
    if (!(this.o1j_1 === other.o1j_1))
      return false;
    return true;
  };
  function Token(type, value) {
    value = value === VOID ? null : value;
    this.m11_1 = type;
    this.n11_1 = value;
  }
  protoOf(Token).toString = function () {
    var tmp0_safe_receiver = this.n11_1;
    var tmp;
    if (tmp0_safe_receiver == null) {
      tmp = null;
    } else {
      // Inline function 'kotlin.let' call
      tmp = 'Token(' + this.m11_1.m2() + ', ' + toString(tmp0_safe_receiver) + ')';
    }
    var tmp1_elvis_lhs = tmp;
    return tmp1_elvis_lhs == null ? 'Token(' + this.m11_1.m2() + ')' : tmp1_elvis_lhs;
  };
  protoOf(Token).c12 = function () {
    return this instanceof Token ? this : THROW_CCE();
  };
  protoOf(Token).hashCode = function () {
    var result = hashCode(this.m11_1);
    result = imul(result, 31) + (this.n11_1 == null ? 0 : hashCode(this.n11_1)) | 0;
    return result;
  };
  protoOf(Token).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof Token))
      return false;
    if (!equals(this.m11_1, other.m11_1))
      return false;
    if (!equals(this.n11_1, other.n11_1))
      return false;
    return true;
  };
  function Companion_19() {
    Companion_instance_19 = this;
    this.p1j_1 = listOf([new Char(_Char___init__impl__6a9atx(33)), new Char(_Char___init__impl__6a9atx(95)), new Char(_Char___init__impl__6a9atx(94)), new Char(_Char___init__impl__6a9atx(42)), new Char(_Char___init__impl__6a9atx(47)), new Char(_Char___init__impl__6a9atx(40)), new Char(_Char___init__impl__6a9atx(41))]);
    this.q1j_1 = new Token(RichTextTokenType_LPAREN_getInstance());
    this.r1j_1 = new Token(RichTextTokenType_RPAREN_getInstance());
    this.s1j_1 = new Token(RichTextTokenType_OVERLINE_getInstance());
    this.t1j_1 = new Token(RichTextTokenType_SUBSCRIPT_getInstance());
    this.u1j_1 = new Token(RichTextTokenType_SUPERSCRIPT_getInstance());
    this.v1j_1 = new Token(RichTextTokenType_BOLD_getInstance());
    this.w1j_1 = new Token(RichTextTokenType_ITALIC_getInstance());
    this.x1j_1 = new Token(RichTextTokenType_EOF_getInstance());
    this.y1j_1 = listOf([new Char(_Char___init__impl__6a9atx(33)), new Char(_Char___init__impl__6a9atx(95)), new Char(_Char___init__impl__6a9atx(94)), new Char(_Char___init__impl__6a9atx(42)), new Char(_Char___init__impl__6a9atx(47))]);
    this.z1j_1 = _Char___init__impl__6a9atx(92);
  }
  var Companion_instance_19;
  function Companion_getInstance_19() {
    if (Companion_instance_19 == null)
      new Companion_19();
    return Companion_instance_19;
  }
  function advanceByUpdatingSingleCharMode($this, state, token) {
    var tmp = $this;
    var tmp_0 = Companion_getInstance_19().y1j_1;
    var tmp_1 = state.ox_1;
    tmp.d1k_1 = contains(tmp_0, tmp_1 == null ? null : new Char(tmp_1));
    return $this.ly(state, token);
  }
  function text($this) {
    var text = StringBuilder_init_$Create$();
    var escape = false;
    var parenDepth = 0;
    $l$loop: while (true) {
      var tmp;
      var tmp_0 = $this.xx_1.ox_1;
      if (!((tmp_0 == null ? null : new Char(tmp_0)) == null)) {
        var tmp_1;
        if (escape) {
          tmp_1 = true;
        } else {
          var tmp_2 = Companion_getInstance_19().y1j_1;
          var tmp_3 = $this.xx_1.ox_1;
          tmp_1 = !contains(tmp_2, tmp_3 == null ? null : new Char(tmp_3));
        }
        tmp = tmp_1;
      } else {
        tmp = false;
      }
      if (!tmp) {
        break $l$loop;
      }
      var tmp_4;
      if (!escape) {
        var tmp_5 = $this.xx_1.ox_1;
        tmp_4 = equals(tmp_5 == null ? null : new Char(tmp_5), new Char(_Char___init__impl__6a9atx(92)));
      } else {
        tmp_4 = false;
      }
      escape = tmp_4;
      var tmp0_subject = $this.xx_1.ox_1;
      var tmp_6 = tmp0_subject;
      if (equals(tmp_6 == null ? null : new Char(tmp_6), new Char(_Char___init__impl__6a9atx(40)))) {
        parenDepth = parenDepth + 1 | 0;
      } else {
        var tmp_7 = tmp0_subject;
        if (equals(tmp_7 == null ? null : new Char(tmp_7), new Char(_Char___init__impl__6a9atx(41)))) {
          if (parenDepth > 0) {
            parenDepth = parenDepth - 1 | 0;
          } else {
            return text.toString();
          }
        }
      }
      if (!escape) {
        var tmp_8 = $this.xx_1.ox_1;
        text.h7(tmp_8 == null ? null : new Char(tmp_8));
      }
      $this.zx($this.xx_1);
    }
    return text.toString();
  }
  function character($this) {
    var tmp = $this.xx_1.ox_1;
    var escape = equals(tmp == null ? null : new Char(tmp), new Char(_Char___init__impl__6a9atx(92)));
    if (escape) {
      $this.zx($this.xx_1);
    }
    var tmp_0;
    var tmp_1;
    var tmp_2 = $this.xx_1.ox_1;
    if (!((tmp_2 == null ? null : new Char(tmp_2)) == null)) {
      var tmp_3;
      if (escape) {
        tmp_3 = true;
      } else {
        var tmp_4 = Companion_getInstance_19().y1j_1;
        var tmp_5 = $this.xx_1.ox_1;
        tmp_3 = !contains(tmp_4, tmp_5 == null ? null : new Char(tmp_5));
      }
      tmp_1 = tmp_3;
    } else {
      tmp_1 = false;
    }
    if (tmp_1) {
      var tmp_6 = $this.xx_1.ox_1;
      var s = toString_1(ensureNotNull(tmp_6 == null ? null : new Char(tmp_6)).j1_1);
      $this.zx($this.xx_1);
      tmp_0 = s;
    } else {
      tmp_0 = '';
    }
    return tmp_0;
  }
  function RichTextLexer(text) {
    Companion_getInstance_19();
    AbstractLexer.call(this, text);
    this.d1k_1 = false;
    this.e1k_1 = false;
  }
  protoOf(RichTextLexer).dy = function (state) {
    this.gy(state);
    var tmp = state.ox_1;
    if ((tmp == null ? null : new Char(tmp)) == null) {
      return Companion_getInstance_19().x1j_1;
    }
    if (!this.e1k_1) {
      var tmp_0 = state.ox_1;
      var tmp0_subject = ensureNotNull(tmp_0 == null ? null : new Char(tmp_0)).j1_1;
      if (tmp0_subject === _Char___init__impl__6a9atx(40))
        return advanceByUpdatingSingleCharMode(this, state, Companion_getInstance_19().q1j_1);
      else if (tmp0_subject === _Char___init__impl__6a9atx(41))
        return advanceByUpdatingSingleCharMode(this, state, Companion_getInstance_19().r1j_1);
      else if (tmp0_subject === _Char___init__impl__6a9atx(33))
        return advanceByUpdatingSingleCharMode(this, state, Companion_getInstance_19().s1j_1);
      else if (tmp0_subject === _Char___init__impl__6a9atx(95))
        return advanceByUpdatingSingleCharMode(this, state, Companion_getInstance_19().t1j_1);
      else if (tmp0_subject === _Char___init__impl__6a9atx(94))
        return advanceByUpdatingSingleCharMode(this, state, Companion_getInstance_19().u1j_1);
      else if (tmp0_subject === _Char___init__impl__6a9atx(42))
        return advanceByUpdatingSingleCharMode(this, state, Companion_getInstance_19().v1j_1);
      else if (tmp0_subject === _Char___init__impl__6a9atx(47))
        return advanceByUpdatingSingleCharMode(this, state, Companion_getInstance_19().w1j_1);
    }
    var tmp_1;
    if (this.d1k_1) {
      // Inline function 'kotlin.also' call
      var this_0 = new Token(RichTextTokenType_TEXT_getInstance(), character(this));
      this.d1k_1 = false;
      tmp_1 = this_0;
    } else {
      tmp_1 = new Token(RichTextTokenType_TEXT_getInstance(), text(this));
    }
    return tmp_1;
  };
  var RichTextTokenType_TEXT_instance;
  var RichTextTokenType_LPAREN_instance;
  var RichTextTokenType_RPAREN_instance;
  var RichTextTokenType_OVERLINE_instance;
  var RichTextTokenType_SUBSCRIPT_instance;
  var RichTextTokenType_SUPERSCRIPT_instance;
  var RichTextTokenType_BOLD_instance;
  var RichTextTokenType_ITALIC_instance;
  var RichTextTokenType_EOF_instance;
  var RichTextTokenType_entriesInitialized;
  function RichTextTokenType_initEntries() {
    if (RichTextTokenType_entriesInitialized)
      return Unit_instance;
    RichTextTokenType_entriesInitialized = true;
    RichTextTokenType_TEXT_instance = new RichTextTokenType('TEXT', 0, 'text');
    RichTextTokenType_LPAREN_instance = new RichTextTokenType('LPAREN', 1, '(');
    RichTextTokenType_RPAREN_instance = new RichTextTokenType('RPAREN', 2, ')');
    RichTextTokenType_OVERLINE_instance = new RichTextTokenType('OVERLINE', 3, '!');
    RichTextTokenType_SUBSCRIPT_instance = new RichTextTokenType('SUBSCRIPT', 4, '_');
    RichTextTokenType_SUPERSCRIPT_instance = new RichTextTokenType('SUPERSCRIPT', 5, '^');
    RichTextTokenType_BOLD_instance = new RichTextTokenType('BOLD', 6, '*');
    RichTextTokenType_ITALIC_instance = new RichTextTokenType('ITALIC', 7, '/');
    RichTextTokenType_EOF_instance = new RichTextTokenType('EOF', 8, 'EOF');
  }
  function RichTextTokenType(name, ordinal, id) {
    Enum.call(this, name, ordinal);
    this.h1k_1 = id;
  }
  protoOf(RichTextTokenType).cv = function () {
    return this.h1k_1;
  };
  function RichTextTokenType_TEXT_getInstance() {
    RichTextTokenType_initEntries();
    return RichTextTokenType_TEXT_instance;
  }
  function RichTextTokenType_LPAREN_getInstance() {
    RichTextTokenType_initEntries();
    return RichTextTokenType_LPAREN_instance;
  }
  function RichTextTokenType_RPAREN_getInstance() {
    RichTextTokenType_initEntries();
    return RichTextTokenType_RPAREN_instance;
  }
  function RichTextTokenType_OVERLINE_getInstance() {
    RichTextTokenType_initEntries();
    return RichTextTokenType_OVERLINE_instance;
  }
  function RichTextTokenType_SUBSCRIPT_getInstance() {
    RichTextTokenType_initEntries();
    return RichTextTokenType_SUBSCRIPT_instance;
  }
  function RichTextTokenType_SUPERSCRIPT_getInstance() {
    RichTextTokenType_initEntries();
    return RichTextTokenType_SUPERSCRIPT_instance;
  }
  function RichTextTokenType_BOLD_getInstance() {
    RichTextTokenType_initEntries();
    return RichTextTokenType_BOLD_instance;
  }
  function RichTextTokenType_ITALIC_getInstance() {
    RichTextTokenType_initEntries();
    return RichTextTokenType_ITALIC_instance;
  }
  function RichTextTokenType_EOF_getInstance() {
    RichTextTokenType_initEntries();
    return RichTextTokenType_EOF_instance;
  }
  function Companion_20() {
  }
  protoOf(Companion_20).i1k = function (text) {
    switch (text.length) {
      case 0:
        return '';
      case 1:
        return RichTextTokenType_BOLD_getInstance().h1k_1 + text;
      default:
        return RichTextTokenType_BOLD_getInstance().h1k_1 + RichTextTokenType_LPAREN_getInstance().h1k_1 + text + RichTextTokenType_RPAREN_getInstance().h1k_1;
    }
  };
  var Companion_instance_20;
  function Companion_getInstance_20() {
    return Companion_instance_20;
  }
  function RichTextParser_init_$Init$(text, $this) {
    RichTextParser.call($this, new RichTextLexer(text));
    return $this;
  }
  function RichTextParser_init_$Create$(text) {
    return RichTextParser_init_$Init$(text, objectCreate(protoOf(RichTextParser)));
  }
  function eatParen($this, expr) {
    $this.t11(RichTextTokenType_LPAREN_getInstance());
    var result = expr();
    $this.t11(RichTextTokenType_RPAREN_getInstance());
    return result;
  }
  function richText($this) {
    // Inline function 'kotlin.let' call
    var location = $this.o11_1.jw();
    // Inline function 'kotlin.collections.mutableListOf' call
    var fragments = ArrayList_init_$Create$();
    while (!equals(ensureNotNull($this.p11_1).m11_1, RichTextTokenType_EOF_getInstance()) && !equals(ensureNotNull($this.p11_1).m11_1, RichTextTokenType_RPAREN_getInstance())) {
      fragments.f1(styledFragment($this));
    }
    return new RichText(location, fragments);
  }
  function styledFragment($this) {
    var tmp0_subject = ensureNotNull($this.p11_1).m11_1;
    return equals(tmp0_subject, RichTextTokenType_BOLD_getInstance()) ? boldText($this).uw_1 : equals(tmp0_subject, RichTextTokenType_ITALIC_getInstance()) ? italicText($this).uw_1 : listOf_0(fragment($this));
  }
  function boldText($this) {
    $this.t11(RichTextTokenType_BOLD_getInstance());
    $this.l1k_1 = Companion_getInstance_22().n1k($this.l1k_1);
    var tmp;
    if (equals(ensureNotNull($this.p11_1).m11_1, RichTextTokenType_LPAREN_getInstance())) {
      tmp = eatParen($this, RichTextParser$boldText$lambda($this));
    } else {
      tmp = singleCharRichText($this);
    }
    var richText = tmp;
    $this.l1k_1 = Companion_getInstance_22().o1k($this.l1k_1);
    return richText;
  }
  function italicText($this) {
    $this.t11(RichTextTokenType_ITALIC_getInstance());
    $this.l1k_1 = Companion_getInstance_22().p1k($this.l1k_1);
    var tmp;
    if (equals(ensureNotNull($this.p11_1).m11_1, RichTextTokenType_LPAREN_getInstance())) {
      tmp = eatParen($this, RichTextParser$italicText$lambda($this));
    } else {
      tmp = singleCharRichText($this);
    }
    var richText = tmp;
    $this.l1k_1 = Companion_getInstance_22().q1k($this.l1k_1);
    return richText;
  }
  function singleCharRichText($this) {
    // Inline function 'kotlin.let' call
    var location = $this.o11_1.jw();
    return new RichText(location, listOf_0(new Fragment(location, new FragmentText(location, singleChar($this)))));
  }
  function fragment($this) {
    // Inline function 'kotlin.let' call
    var location = $this.o11_1.jw();
    var text = new FragmentText(location, styledChunk($this));
    var subscript_0 = null;
    var superscript_0 = null;
    if (equals(ensureNotNull($this.p11_1).m11_1, RichTextTokenType_SUBSCRIPT_getInstance())) {
      subscript_0 = subscript($this);
    }
    if (equals(ensureNotNull($this.p11_1).m11_1, RichTextTokenType_SUPERSCRIPT_getInstance())) {
      superscript_0 = superscript($this);
      if (equals(ensureNotNull($this.p11_1).m11_1, RichTextTokenType_SUBSCRIPT_getInstance())) {
        subscript_0 = subscript($this);
      }
    }
    return new Fragment(location, text, subscript_0, superscript_0);
  }
  function styledText($this) {
    // Inline function 'kotlin.let' call
    var location = $this.o11_1.jw();
    // Inline function 'kotlin.collections.mutableListOf' call
    var chunks = ArrayList_init_$Create$();
    while (isStyledChunk($this)) {
      chunks.f1(styledChunk($this).s1k_1);
    }
    return new StyledText(location, chunks);
  }
  function subscript($this) {
    $this.t11(RichTextTokenType_SUBSCRIPT_getInstance());
    var tmp0_subject = ensureNotNull($this.p11_1).m11_1;
    var tmp;
    if (equals(tmp0_subject, RichTextTokenType_LPAREN_getInstance())) {
      tmp = eatParen($this, RichTextParser$subscript$lambda($this));
    } else if (equals(tmp0_subject, RichTextTokenType_OVERLINE_getInstance())) {
      tmp = new Subscript($this.o11_1.jw(), overline($this));
    } else if (equals(tmp0_subject, RichTextTokenType_BOLD_getInstance())) {
      tmp = new Subscript($this.o11_1.jw(), bold($this));
    } else if (equals(tmp0_subject, RichTextTokenType_ITALIC_getInstance())) {
      tmp = new Subscript($this.o11_1.jw(), italic($this));
    } else {
      tmp = new Subscript($this.o11_1.jw(), singleChar($this));
    }
    return tmp;
  }
  function superscript($this) {
    $this.t11(RichTextTokenType_SUPERSCRIPT_getInstance());
    var tmp0_subject = ensureNotNull($this.p11_1).m11_1;
    var tmp;
    if (equals(tmp0_subject, RichTextTokenType_LPAREN_getInstance())) {
      tmp = eatParen($this, RichTextParser$superscript$lambda($this));
    } else if (equals(tmp0_subject, RichTextTokenType_OVERLINE_getInstance())) {
      tmp = new Superscript($this.o11_1.jw(), overline($this));
    } else if (equals(tmp0_subject, RichTextTokenType_BOLD_getInstance())) {
      tmp = new Superscript($this.o11_1.jw(), bold($this));
    } else if (equals(tmp0_subject, RichTextTokenType_ITALIC_getInstance())) {
      tmp = new Superscript($this.o11_1.jw(), italic($this));
    } else {
      tmp = new Superscript($this.o11_1.jw(), singleChar($this));
    }
    return tmp;
  }
  function isStyledChunk($this) {
    var tmp0_subject = ensureNotNull($this.p11_1).m11_1;
    return equals(tmp0_subject, RichTextTokenType_TEXT_getInstance()) ? true : equals(tmp0_subject, RichTextTokenType_OVERLINE_getInstance()) ? true : equals(tmp0_subject, RichTextTokenType_BOLD_getInstance()) ? true : equals(tmp0_subject, RichTextTokenType_ITALIC_getInstance()) ? true : false;
  }
  function styledChunk($this) {
    // Inline function 'kotlin.let' call
    var location = $this.o11_1.jw();
    var token = ensureNotNull($this.p11_1);
    var tmp0_subject = ensureNotNull($this.p11_1).m11_1;
    var tmp;
    if (equals(tmp0_subject, RichTextTokenType_OVERLINE_getInstance())) {
      tmp = overline($this);
    } else if (equals(tmp0_subject, RichTextTokenType_BOLD_getInstance())) {
      tmp = bold($this);
    } else if (equals(tmp0_subject, RichTextTokenType_ITALIC_getInstance())) {
      tmp = italic($this);
    } else if (equals(tmp0_subject, RichTextTokenType_TEXT_getInstance())) {
      tmp = text_0($this);
    } else {
      throw new SyntaxError(location, Translations_getInstance().bn('base.dsl.unexpectedToken.msg', [token.m11_1.cv()]));
    }
    return tmp;
  }
  function bold($this) {
    $this.t11(RichTextTokenType_BOLD_getInstance());
    $this.l1k_1 = Companion_getInstance_22().n1k($this.l1k_1);
    var tmp;
    if (equals(ensureNotNull($this.p11_1).m11_1, RichTextTokenType_LPAREN_getInstance())) {
      tmp = eatParen($this, RichTextParser$bold$lambda($this));
    } else {
      tmp = singleChar($this);
    }
    var bold = tmp;
    $this.l1k_1 = Companion_getInstance_22().o1k($this.l1k_1);
    return bold;
  }
  function italic($this) {
    $this.t11(RichTextTokenType_ITALIC_getInstance());
    $this.l1k_1 = Companion_getInstance_22().p1k($this.l1k_1);
    var tmp;
    if (equals(ensureNotNull($this.p11_1).m11_1, RichTextTokenType_LPAREN_getInstance())) {
      tmp = eatParen($this, RichTextParser$italic$lambda($this));
    } else {
      tmp = singleChar($this);
    }
    var italic = tmp;
    $this.l1k_1 = Companion_getInstance_22().q1k($this.l1k_1);
    return italic;
  }
  function overline($this) {
    $this.t11(RichTextTokenType_OVERLINE_getInstance());
    $this.l1k_1 = Companion_getInstance_22().t1k($this.l1k_1);
    var tmp;
    if (equals(ensureNotNull($this.p11_1).m11_1, RichTextTokenType_LPAREN_getInstance())) {
      tmp = eatParen($this, RichTextParser$overline$lambda($this));
    } else {
      tmp = singleChar($this);
    }
    var overline = tmp;
    $this.l1k_1 = Companion_getInstance_22().u1k($this.l1k_1);
    return overline;
  }
  function text_0($this) {
    // Inline function 'kotlin.let' call
    var location = $this.o11_1.jw();
    if (!equals(ensureNotNull($this.p11_1).m11_1, RichTextTokenType_TEXT_getInstance())) {
      throw new SyntaxError(location, Translations_getInstance().bn('base.dsl.unexpectedToken.msg', [ensureNotNull($this.p11_1).m11_1.cv()]));
    }
    var tmp = ensureNotNull($this.p11_1).n11_1;
    var text = (!(tmp == null) ? typeof tmp === 'string' : false) ? tmp : THROW_CCE();
    $this.t11(RichTextTokenType_TEXT_getInstance());
    return new StyledText($this.o11_1.jw(), listOf_0(new StyledChunk(location, text, $this.l1k_1)));
  }
  function singleChar($this) {
    return text_0($this);
  }
  function RichTextParser$boldText$lambda(this$0) {
    return function () {
      return richText(this$0);
    };
  }
  function RichTextParser$italicText$lambda(this$0) {
    return function () {
      return richText(this$0);
    };
  }
  function RichTextParser$subscript$lambda(this$0) {
    return function () {
      return new Subscript(this$0.o11_1.jw(), styledText(this$0));
    };
  }
  function RichTextParser$superscript$lambda(this$0) {
    return function () {
      return new Superscript(this$0.o11_1.jw(), styledText(this$0));
    };
  }
  function RichTextParser$bold$lambda(this$0) {
    return function () {
      return styledText(this$0);
    };
  }
  function RichTextParser$italic$lambda(this$0) {
    return function () {
      return styledText(this$0);
    };
  }
  function RichTextParser$overline$lambda(this$0) {
    return function () {
      return styledText(this$0);
    };
  }
  function RichTextParser(lexer) {
    AbstractParser.call(this, lexer);
    this.l1k_1 = Companion_getInstance_22().m1k_1;
  }
  protoOf(RichTextParser).xy = function () {
    return richText(this);
  };
  function Companion_21() {
  }
  protoOf(Companion_21).v1k = function (text) {
    var tmp;
    try {
      var richText = RichTextParser_init_$Create$(text).xy();
      var result = StringBuilder_init_$Create$();
      // Inline function 'kotlin.collections.forEach' call
      var _iterator__ex2g4s = richText.uw_1.i();
      while (_iterator__ex2g4s.j()) {
        var element = _iterator__ex2g4s.k();
        // Inline function 'kotlin.collections.forEach' call
        var _iterator__ex2g4s_0 = element.z1k_1.x1k_1.s1k_1.i();
        while (_iterator__ex2g4s_0.j()) {
          var element_0 = _iterator__ex2g4s_0.k();
          result.i7(replace(element_0.d1l_1, '/', ' '));
        }
      }
      tmp = result.toString();
    } catch ($p) {
      var tmp_0;
      if ($p instanceof Error) {
        var _unused_var__etf5q3 = $p;
        tmp_0 = replace(text, '/', ' ');
      } else {
        throw $p;
      }
      tmp = tmp_0;
    }
    return tmp;
  };
  protoOf(Companion_21).f1l = function (text) {
    return new RichText(Companion_getInstance_18().cx_1, listOf_0(new Fragment(Companion_getInstance_18().cx_1, new FragmentText(Companion_getInstance_18().cx_1, new StyledText(Companion_getInstance_18().cx_1, listOf_0(new StyledChunk(Companion_getInstance_18().cx_1, text)))))));
  };
  var Companion_instance_21;
  function Companion_getInstance_21() {
    return Companion_instance_21;
  }
  function RichText(location, fragments) {
    Compound.call(this, location, fragments);
  }
  protoOf(RichText).i1l = function () {
    var tmp0 = this.uw_1;
    var tmp$ret$0;
    $l$block: {
      // Inline function 'kotlin.collections.maxOfOrNull' call
      var iterator = tmp0.i();
      if (!iterator.j()) {
        tmp$ret$0 = null;
        break $l$block;
      }
      var tmp0_0 = iterator.k().z1k_1.x1k_1.s1k_1;
      var tmp$ret$2;
      $l$block_0: {
        // Inline function 'kotlin.collections.maxOfOrNull' call
        var iterator_0 = tmp0_0.i();
        if (!iterator_0.j()) {
          tmp$ret$2 = null;
          break $l$block_0;
        }
        var maxValue = iterator_0.k().e1l_1.j1l_1;
        while (iterator_0.j()) {
          var v = iterator_0.k().e1l_1.j1l_1;
          if (compareTo(maxValue, v) < 0) {
            maxValue = v;
          }
        }
        tmp$ret$2 = maxValue;
      }
      var tmp0_elvis_lhs = tmp$ret$2;
      var maxValue_0 = tmp0_elvis_lhs == null ? 0 : tmp0_elvis_lhs;
      while (iterator.j()) {
        var tmp0_1 = iterator.k().z1k_1.x1k_1.s1k_1;
        var tmp$ret$6;
        $l$block_1: {
          // Inline function 'kotlin.collections.maxOfOrNull' call
          var iterator_1 = tmp0_1.i();
          if (!iterator_1.j()) {
            tmp$ret$6 = null;
            break $l$block_1;
          }
          var maxValue_1 = iterator_1.k().e1l_1.j1l_1;
          while (iterator_1.j()) {
            var v_0 = iterator_1.k().e1l_1.j1l_1;
            if (compareTo(maxValue_1, v_0) < 0) {
              maxValue_1 = v_0;
            }
          }
          tmp$ret$6 = maxValue_1;
        }
        var tmp0_elvis_lhs_0 = tmp$ret$6;
        var v_1 = tmp0_elvis_lhs_0 == null ? 0 : tmp0_elvis_lhs_0;
        if (compareTo(maxValue_0, v_1) < 0) {
          maxValue_0 = v_1;
        }
      }
      tmp$ret$0 = maxValue_0;
    }
    var tmp0_elvis_lhs_1 = tmp$ret$0;
    return tmp0_elvis_lhs_1 == null ? 0 : tmp0_elvis_lhs_1;
  };
  function Fragment(location, text, subscript, superscript) {
    subscript = subscript === VOID ? null : subscript;
    superscript = superscript === VOID ? null : superscript;
    AbstractNode.call(this, location);
    this.z1k_1 = text;
    this.a1l_1 = subscript;
    this.b1l_1 = superscript;
  }
  protoOf(Fragment).toString = function () {
    return 'Fragment';
  };
  protoOf(Fragment).n13 = function (visitor) {
    if (visitor.hs(this)) {
      this.z1k_1.n13(visitor);
      var tmp0_safe_receiver = this.a1l_1;
      if (tmp0_safe_receiver == null)
        null;
      else
        tmp0_safe_receiver.n13(visitor);
      var tmp1_safe_receiver = this.b1l_1;
      if (tmp1_safe_receiver == null)
        null;
      else
        tmp1_safe_receiver.n13(visitor);
    }
    return visitor.ks(this);
  };
  function StyledChunk(location, text, style) {
    style = style === VOID ? Companion_getInstance_22().m1k_1 : style;
    AbstractNode.call(this, location);
    this.d1l_1 = text;
    this.e1l_1 = style;
  }
  protoOf(StyledChunk).toString = function () {
    var s = StringBuilder_init_$Create$();
    if (this.e1l_1.k1l_1) {
      s.i7(RichTextTokenType_BOLD_getInstance().h1k_1);
    }
    if (this.e1l_1.l1l_1) {
      s.i7(RichTextTokenType_ITALIC_getInstance().h1k_1);
    }
    // Inline function 'kotlin.collections.forEach' call
    var progression = numberRangeToNumber(1, this.e1l_1.j1l_1);
    var inductionVariable = progression.y_1;
    var last = progression.z_1;
    if (inductionVariable <= last)
      do {
        var element = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        s.i7(RichTextTokenType_OVERLINE_getInstance().h1k_1);
      }
       while (!(element === last));
    // Inline function 'kotlin.text.isNotEmpty' call
    if (charSequenceLength(s) > 0) {
      s.i7('(' + this.d1l_1 + ')');
    } else {
      s.i7(this.d1l_1);
    }
    return s.toString();
  };
  protoOf(StyledChunk).m1l = function () {
    var words = split(this.d1l_1, charArrayOf([_Char___init__impl__6a9atx(32)]));
    // Inline function 'kotlin.collections.mapIndexed' call
    // Inline function 'kotlin.collections.mapIndexedTo' call
    var destination = ArrayList_init_$Create$_0(collectionSizeOrDefault(words, 10));
    var index = 0;
    var _iterator__ex2g4s = words.i();
    while (_iterator__ex2g4s.j()) {
      var item = _iterator__ex2g4s.k();
      var _unary__edvuaz = index;
      index = _unary__edvuaz + 1 | 0;
      var tmp;
      if (checkIndexOverflow(_unary__edvuaz) === (words.o() - 1 | 0)) {
        tmp = new StyledChunk(this.jw(), item, this.e1l_1);
      } else {
        tmp = new StyledChunk(this.jw(), item + ' ', this.e1l_1);
      }
      var tmp$ret$2 = tmp;
      destination.h(tmp$ret$2);
    }
    return destination;
  };
  function StyledText(location, chunks) {
    AbstractNode.call(this, location);
    this.s1k_1 = chunks;
  }
  protoOf(StyledText).toString = function () {
    return 'StyledText';
  };
  protoOf(StyledText).n13 = function (visitor) {
    if (visitor.hs(this)) {
      // Inline function 'kotlin.collections.forEach' call
      var _iterator__ex2g4s = this.s1k_1.i();
      while (_iterator__ex2g4s.j()) {
        var element = _iterator__ex2g4s.k();
        element.n13(visitor);
      }
    }
    return visitor.ks(this);
  };
  function FragmentText(location, styledText) {
    AbstractFragmentPart.call(this, location, styledText);
  }
  protoOf(FragmentText).toString = function () {
    return '-';
  };
  function Companion_22() {
    Companion_instance_22 = this;
    this.m1k_1 = new TextStyle(0, false, false);
  }
  protoOf(Companion_22).t1k = function (style) {
    return new TextStyle(style.j1l_1 + 1 | 0, style.k1l_1, style.l1l_1);
  };
  protoOf(Companion_22).u1k = function (style) {
    // Inline function 'kotlin.math.max' call
    var a = style.j1l_1 - 1 | 0;
    var tmp$ret$0 = Math.max(a, 0);
    return new TextStyle(tmp$ret$0, style.k1l_1, style.l1l_1);
  };
  protoOf(Companion_22).n1k = function (style) {
    return new TextStyle(style.j1l_1, true, style.l1l_1);
  };
  protoOf(Companion_22).o1k = function (style) {
    return new TextStyle(style.j1l_1, false, style.l1l_1);
  };
  protoOf(Companion_22).p1k = function (style) {
    return new TextStyle(style.j1l_1, style.k1l_1, true);
  };
  protoOf(Companion_22).q1k = function (style) {
    return new TextStyle(style.j1l_1, style.k1l_1, false);
  };
  var Companion_instance_22;
  function Companion_getInstance_22() {
    if (Companion_instance_22 == null)
      new Companion_22();
    return Companion_instance_22;
  }
  function TextStyle(overlineLevel, bold, italic) {
    Companion_getInstance_22();
    this.j1l_1 = overlineLevel;
    this.k1l_1 = bold;
    this.l1l_1 = italic;
  }
  protoOf(TextStyle).toString = function () {
    return 'TextStyle(overlineLevel=' + this.j1l_1 + ', bold=' + this.k1l_1 + ', italic=' + this.l1l_1 + ')';
  };
  protoOf(TextStyle).hashCode = function () {
    var result = this.j1l_1;
    result = imul(result, 31) + getBooleanHashCode(this.k1l_1) | 0;
    result = imul(result, 31) + getBooleanHashCode(this.l1l_1) | 0;
    return result;
  };
  protoOf(TextStyle).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof TextStyle))
      return false;
    if (!(this.j1l_1 === other.j1l_1))
      return false;
    if (!(this.k1l_1 === other.k1l_1))
      return false;
    if (!(this.l1l_1 === other.l1l_1))
      return false;
    return true;
  };
  function Subscript(location, styledText) {
    AbstractFragmentPart.call(this, location, styledText);
  }
  protoOf(Subscript).toString = function () {
    return '_';
  };
  function Superscript(location, styledText) {
    AbstractFragmentPart.call(this, location, styledText);
  }
  protoOf(Superscript).toString = function () {
    return '^';
  };
  function AbstractFragmentPart(location, styledText) {
    AbstractNode.call(this, location);
    this.x1k_1 = styledText;
  }
  protoOf(AbstractFragmentPart).n13 = function (visitor) {
    if (visitor.hs(this)) {
      // Inline function 'kotlin.collections.forEach' call
      var _iterator__ex2g4s = this.x1k_1.s1k_1.i();
      while (_iterator__ex2g4s.j()) {
        var element = _iterator__ex2g4s.k();
        element.n13(visitor);
      }
    }
    return visitor.ks(this);
  };
  function updateEnableSoundEffects($this) {
    $this.j1j_1 = BaseModule_getInstance().zo_1.ht('jabbah.base.sound.enableSoundEffects');
  }
  function SoundEffects$initialize$lambda(it) {
    updateEnableSoundEffects(SoundEffects_instance);
    return Unit_instance;
  }
  function SoundEffects() {
    this.i1j_1 = 'jabbah.base.sound.enableSoundEffects';
    this.j1j_1 = false;
  }
  protoOf(SoundEffects).k1j = function (eventBus) {
    var tmp = getKClass(PreferencesChangedEvent);
    eventBus.z17(tmp, SoundEffects$initialize$lambda);
    updateEnableSoundEffects(this);
  };
  var SoundEffects_instance;
  function SoundEffects_getInstance() {
    return SoundEffects_instance;
  }
  var WaveformType_Sine_instance;
  var WaveformType_Square_instance;
  var WaveformType_Triangle_instance;
  var WaveformType_Sawtooth_instance;
  var WaveformType_Noise_instance;
  function Companion_23() {
    this.n1l_1 = 'element.property.waveformType';
  }
  protoOf(Companion_23).h1f = function (customName) {
    var tmp0 = values_3();
    var tmp$ret$0;
    $l$block: {
      // Inline function 'kotlin.collections.firstOrNull' call
      var inductionVariable = 0;
      var last = tmp0.length;
      while (inductionVariable < last) {
        var element = tmp0[inductionVariable];
        inductionVariable = inductionVariable + 1 | 0;
        if (element.q1l_1 === customName) {
          tmp$ret$0 = element;
          break $l$block;
        }
      }
      tmp$ret$0 = null;
    }
    var tmp0_elvis_lhs = tmp$ret$0;
    var tmp;
    if (tmp0_elvis_lhs == null) {
      throw IllegalArgumentException_init_$Create$('unknown WaveformType ' + customName);
    } else {
      tmp = tmp0_elvis_lhs;
    }
    return tmp;
  };
  var Companion_instance_23;
  function Companion_getInstance_23() {
    return Companion_instance_23;
  }
  function values_3() {
    return [WaveformType_Sine_getInstance(), WaveformType_Square_getInstance(), WaveformType_Triangle_getInstance(), WaveformType_Sawtooth_getInstance(), WaveformType_Noise_getInstance()];
  }
  var WaveformType_entriesInitialized;
  function WaveformType_initEntries() {
    if (WaveformType_entriesInitialized)
      return Unit_instance;
    WaveformType_entriesInitialized = true;
    WaveformType_Sine_instance = new WaveformType('Sine', 0, 'sine');
    WaveformType_Square_instance = new WaveformType('Square', 1, 'square');
    WaveformType_Triangle_instance = new WaveformType('Triangle', 2, 'triangle');
    WaveformType_Sawtooth_instance = new WaveformType('Sawtooth', 3, 'sawtooth');
    WaveformType_Noise_instance = new WaveformType('Noise', 4, 'noise');
  }
  function WaveformType(name, ordinal, customName) {
    Enum.call(this, name, ordinal);
    this.q1l_1 = customName;
  }
  protoOf(WaveformType).toString = function () {
    return Translations_getInstance().bn('element.property.waveformType.' + this.q1l_1, []);
  };
  function ToneParams(frequency, volume, waveformType, leftChannel, rightChannel, smoothLevel, smoothWidth) {
    waveformType = waveformType === VOID ? WaveformType_Sine_getInstance() : waveformType;
    leftChannel = leftChannel === VOID ? true : leftChannel;
    rightChannel = rightChannel === VOID ? true : rightChannel;
    smoothLevel = smoothLevel === VOID ? 2 : smoothLevel;
    smoothWidth = smoothWidth === VOID ? 2 : smoothWidth;
    this.r1l_1 = frequency;
    this.s1l_1 = volume;
    this.t1l_1 = waveformType;
    this.u1l_1 = leftChannel;
    this.v1l_1 = rightChannel;
    this.w1l_1 = smoothLevel;
    this.x1l_1 = smoothWidth;
  }
  protoOf(ToneParams).toString = function () {
    return 'ToneParams(frequency=' + this.r1l_1 + ', volume=' + this.s1l_1 + ', waveformType=' + this.t1l_1.toString() + ', leftChannel=' + this.u1l_1 + ', rightChannel=' + this.v1l_1 + ', smoothLevel=' + this.w1l_1 + ', smoothWidth=' + this.x1l_1 + ')';
  };
  protoOf(ToneParams).hashCode = function () {
    var result = this.r1l_1;
    result = imul(result, 31) + getNumberHashCode(this.s1l_1) | 0;
    result = imul(result, 31) + this.t1l_1.hashCode() | 0;
    result = imul(result, 31) + getBooleanHashCode(this.u1l_1) | 0;
    result = imul(result, 31) + getBooleanHashCode(this.v1l_1) | 0;
    result = imul(result, 31) + this.w1l_1 | 0;
    result = imul(result, 31) + this.x1l_1 | 0;
    return result;
  };
  protoOf(ToneParams).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof ToneParams))
      return false;
    if (!(this.r1l_1 === other.r1l_1))
      return false;
    if (!equals(this.s1l_1, other.s1l_1))
      return false;
    if (!this.t1l_1.equals(other.t1l_1))
      return false;
    if (!(this.u1l_1 === other.u1l_1))
      return false;
    if (!(this.v1l_1 === other.v1l_1))
      return false;
    if (!(this.w1l_1 === other.w1l_1))
      return false;
    if (!(this.x1l_1 === other.x1l_1))
      return false;
    return true;
  };
  function WaveformType_Sine_getInstance() {
    WaveformType_initEntries();
    return WaveformType_Sine_instance;
  }
  function WaveformType_Square_getInstance() {
    WaveformType_initEntries();
    return WaveformType_Square_instance;
  }
  function WaveformType_Triangle_getInstance() {
    WaveformType_initEntries();
    return WaveformType_Triangle_instance;
  }
  function WaveformType_Sawtooth_getInstance() {
    WaveformType_initEntries();
    return WaveformType_Sawtooth_instance;
  }
  function WaveformType_Noise_getInstance() {
    WaveformType_initEntries();
    return WaveformType_Noise_instance;
  }
  function addTransition($this, transition, init) {
    if (init == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      init(transition);
    }
    $this.z1l_1.h(transition);
    return transition;
  }
  function State$entryAction$lambda(it) {
    return Unit_instance;
  }
  function State$exitAction$lambda(it) {
    return Unit_instance;
  }
  function State$stayOtherwise$lambda(it) {
    return true;
  }
  function State_0(name) {
    this.y1l_1 = name;
    var tmp = this;
    // Inline function 'kotlin.collections.mutableListOf' call
    tmp.z1l_1 = ArrayList_init_$Create$();
    var tmp_0 = this;
    tmp_0.a1m_1 = State$entryAction$lambda;
    var tmp_1 = this;
    tmp_1.b1m_1 = State$exitAction$lambda;
  }
  protoOf(State_0).c1m = function (event) {
    this.a1m_1(event);
  };
  protoOf(State_0).d1m = function (event) {
    this.b1m_1(event);
  };
  protoOf(State_0).e1m = function (event) {
    var tmp0 = this.z1l_1;
    var tmp$ret$0;
    $l$block: {
      // Inline function 'kotlin.collections.firstOrNull' call
      var _iterator__ex2g4s = tmp0.i();
      while (_iterator__ex2g4s.j()) {
        var element = _iterator__ex2g4s.k();
        if (element.i1m()(event)) {
          tmp$ret$0 = element;
          break $l$block;
        }
      }
      tmp$ret$0 = null;
    }
    return tmp$ret$0;
  };
  protoOf(State_0).j1m = function (event) {
    return false;
  };
  protoOf(State_0).k1m = function (action) {
    this.a1m_1 = action;
  };
  protoOf(State_0).l1m = function (action) {
    this.b1m_1 = action;
  };
  protoOf(State_0).m1m = function (condition, init) {
    return addTransition(this, new Transition(this.y1l_1, condition), init);
  };
  protoOf(State_0).n1m = function (condition) {
    return this.m1m(condition, null);
  };
  protoOf(State_0).o1m = function (init) {
    return addTransition(this, new Transition(this.y1l_1, State$stayOtherwise$lambda), init);
  };
  protoOf(State_0).p1m = function (init, $super) {
    init = init === VOID ? null : init;
    return $super === VOID ? this.o1m(init) : $super.o1m.call(this, init);
  };
  protoOf(State_0).q1m = function (destinationStateName, init) {
    return addTransition(this, new Transition(destinationStateName), init);
  };
  function _get_LOG__e5r759_5($this) {
    var tmp0 = $this.r1m_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('LOG', 1, tmp, StateMachine$Companion$_get_LOG_$ref_l8ab1m(), null);
    return tmp0.j2();
  }
  function StateMachine$Companion$_get_LOG_$ref_l8ab1m() {
    return function (p0) {
      return _get_LOG__e5r759_5(p0);
    };
  }
  function Companion_24() {
    Companion_instance_24 = this;
    this.r1m_1 = logger(getKClass(StateMachine));
  }
  var Companion_instance_24;
  function Companion_getInstance_24() {
    if (Companion_instance_24 == null)
      new Companion_24();
    return Companion_instance_24;
  }
  function enter($this, state, event) {
    _get_LOG__e5r759_5(Companion_getInstance_24()).ql("Enter state '" + state.y1l_1 + "'");
    $this.w1m_1 = state;
    state.c1m(event);
  }
  function transferAlong($this, transition, event) {
    var destinationState = stateWithName($this, transition.f1m_1);
    if (destinationState == null && !($this.t1m_1 == null)) {
      var outerDestinationState = stateWithName($this.t1m_1, transition.f1m_1);
      if (!(outerDestinationState == null)) {
        $this.x1m().d1m(event);
        transitAndEnter($this.t1m_1, transition, outerDestinationState, event);
        return Unit_instance;
      }
    }
    if (destinationState == null) {
      throw IllegalArgumentException_init_$Create$("Undefined destination state '" + transition.f1m_1 + "' in " + $this.x1m().y1l_1);
    }
    if (!(destinationState === $this.x1m())) {
      $this.x1m().d1m(event);
    }
    transitAndEnter($this, transition, destinationState, event);
  }
  function transitAndEnter($this, transition, destinationState, event) {
    transition.y1m(event);
    if (!(destinationState === $this.x1m())) {
      _get_LOG__e5r759_5(Companion_getInstance_24()).ql('Transferring to ' + getKClassFromExpression(destinationState).m9() + " '" + destinationState.y1l_1 + "'");
      enter($this, destinationState, event);
    } else {
      if (_get_LOG__e5r759_5(Companion_getInstance_24()).sl()) {
        _get_LOG__e5r759_5(Companion_getInstance_24()).ql('Stay in ' + getKClassFromExpression($this.x1m()).m9() + " '" + destinationState.y1l_1 + "' with event " + toString_0(event));
      }
    }
  }
  function stateWithName($this, name) {
    var tmp0 = $this.u1m_1;
    var tmp$ret$0;
    $l$block: {
      // Inline function 'kotlin.collections.firstOrNull' call
      var _iterator__ex2g4s = tmp0.i();
      while (_iterator__ex2g4s.j()) {
        var element = _iterator__ex2g4s.k();
        if (element.y1l_1 === name) {
          tmp$ret$0 = element;
          break $l$block;
        }
      }
      tmp$ret$0 = null;
    }
    return tmp$ret$0;
  }
  function ensureUniqueStateName($this, name) {
    if (!(stateWithName($this, name) == null)) {
      throw IllegalArgumentException_init_$Create$('State name ' + name + ' must be unique');
    }
  }
  function StateMachine(behaviour, outer) {
    Companion_getInstance_24();
    behaviour = behaviour === VOID ? UnhandledEventBehaviour_Strict_getInstance() : behaviour;
    outer = outer === VOID ? null : outer;
    this.s1m_1 = behaviour;
    this.t1m_1 = outer;
    var tmp = this;
    // Inline function 'kotlin.collections.mutableListOf' call
    tmp.u1m_1 = ArrayList_init_$Create$();
    var tmp_0 = this;
    // Inline function 'kotlin.collections.mutableListOf' call
    tmp_0.v1m_1 = ArrayList_init_$Create$();
  }
  protoOf(StateMachine).x1m = function () {
    var tmp = this.w1m_1;
    if (!(tmp == null))
      return tmp;
    else {
      throwUninitializedPropertyAccessException('currentState');
    }
  };
  protoOf(StateMachine).z1m = function (event) {
    if (this.u1m_1.m()) {
      throw IllegalStateException_init_$Create$('StateMachine must have at least 1 state');
    }
    _get_LOG__e5r759_5(Companion_getInstance_24()).ql("Start in state '" + first_0(this.u1m_1).y1l_1 + "'");
    enter(this, first_0(this.u1m_1), event);
    return this;
  };
  protoOf(StateMachine).j1m = function (event) {
    if (_get_LOG__e5r759_5(Companion_getInstance_24()).sl()) {
      _get_LOG__e5r759_5(Companion_getInstance_24()).ql('Handle event ' + toString_0(event));
    }
    try {
      var transition = this.x1m().e1m(event);
      if (!(transition == null)) {
        transferAlong(this, transition, event);
        return true;
      }
      if (this.x1m().j1m(event)) {
        return true;
      }
    } catch ($p) {
      if ($p instanceof Error) {
        var e = $p;
        _get_LOG__e5r759_5(Companion_getInstance_24()).ml('Error when handling event ' + toString_0(event) + ' in state ' + this.x1m().y1l_1 + ': ' + System_getInstance().yl(e));
        throw e;
      } else {
        throw $p;
      }
    }
    var tmp0 = this.v1m_1;
    var tmp$ret$0;
    $l$block_0: {
      // Inline function 'kotlin.collections.any' call
      var tmp;
      if (isInterface(tmp0, Collection)) {
        tmp = tmp0.m();
      } else {
        tmp = false;
      }
      if (tmp) {
        tmp$ret$0 = false;
        break $l$block_0;
      }
      var _iterator__ex2g4s = tmp0.i();
      while (_iterator__ex2g4s.j()) {
        var element = _iterator__ex2g4s.k();
        if (element(event)) {
          tmp$ret$0 = true;
          break $l$block_0;
        }
      }
      tmp$ret$0 = false;
    }
    if (tmp$ret$0) {
      _get_LOG__e5r759_5(Companion_getInstance_24()).ql('Explicitly ignored event ' + toString_0(event));
      return true;
    }
    _get_LOG__e5r759_5(Companion_getInstance_24()).ql('Unhandled event ' + toString_0(event));
    return this.s1m_1.c1n(!(event == null) ? event : THROW_CCE());
  };
  protoOf(StateMachine).d1n = function (condition) {
    this.v1m_1.h(condition);
  };
  protoOf(StateMachine).e1n = function (name, init) {
    ensureUniqueStateName(this, name);
    var state = new State_0(name);
    if (!(init == null)) {
      init(state);
    }
    this.u1m_1.h(state);
    return state;
  };
  protoOf(StateMachine).f1n = function (name, init) {
    ensureUniqueStateName(this, name);
    var state = new SuperState(name, this);
    if (!(init == null)) {
      init(state);
    }
    this.u1m_1.h(state);
    return state;
  };
  function stateMachine(behaviour, outer, init) {
    behaviour = behaviour === VOID ? UnhandledEventBehaviour_Strict_getInstance() : behaviour;
    outer = outer === VOID ? null : outer;
    var sm = new StateMachine(behaviour, outer);
    init(sm);
    return sm;
  }
  function UnhandledEventBehaviour$Strict() {
    UnhandledEventBehaviour.call(this, 'Strict', 0);
    UnhandledEventBehaviour_Strict_instance = this;
  }
  protoOf(UnhandledEventBehaviour$Strict).c1n = function (event) {
    throw IllegalArgumentException_init_$Create$('Unhandled event ' + toString(event));
  };
  var UnhandledEventBehaviour_Strict_instance;
  function UnhandledEventBehaviour$Unhandled() {
    UnhandledEventBehaviour.call(this, 'Unhandled', 1);
    UnhandledEventBehaviour_Unhandled_instance = this;
  }
  protoOf(UnhandledEventBehaviour$Unhandled).c1n = function (event) {
    return false;
  };
  var UnhandledEventBehaviour_Unhandled_instance;
  var UnhandledEventBehaviour_entriesInitialized;
  function UnhandledEventBehaviour_initEntries() {
    if (UnhandledEventBehaviour_entriesInitialized)
      return Unit_instance;
    UnhandledEventBehaviour_entriesInitialized = true;
    UnhandledEventBehaviour_Strict_instance = new UnhandledEventBehaviour$Strict();
    UnhandledEventBehaviour_Unhandled_instance = new UnhandledEventBehaviour$Unhandled();
  }
  function UnhandledEventBehaviour(name, ordinal) {
    Enum.call(this, name, ordinal);
  }
  function UnhandledEventBehaviour_Strict_getInstance() {
    UnhandledEventBehaviour_initEntries();
    return UnhandledEventBehaviour_Strict_instance;
  }
  function UnhandledEventBehaviour_Unhandled_getInstance() {
    UnhandledEventBehaviour_initEntries();
    return UnhandledEventBehaviour_Unhandled_instance;
  }
  function SuperState(name, outerStateMachine) {
    State_0.call(this, name);
    this.o1n_1 = outerStateMachine;
  }
  protoOf(SuperState).q1n = function () {
    var tmp = this.p1n_1;
    if (!(tmp == null))
      return tmp;
    else {
      throwUninitializedPropertyAccessException('stateMachine');
    }
  };
  protoOf(SuperState).c1m = function (event) {
    protoOf(State_0).c1m.call(this, event);
    this.q1n().z1m(event);
  };
  protoOf(SuperState).j1m = function (event) {
    return this.q1n().j1m(event);
  };
  protoOf(SuperState).r1n = function (behaviour, init) {
    this.p1n_1 = stateMachine(behaviour, this.o1n_1, init);
  };
  function Transition$action$lambda(it) {
    return Unit_instance;
  }
  function Transition(destinationStateName, condition) {
    condition = condition === VOID ? null : condition;
    this.f1m_1 = destinationStateName;
    if (!(condition == null)) {
      this.g1m_1 = condition;
    }
    var tmp = this;
    tmp.h1m_1 = Transition$action$lambda;
  }
  protoOf(Transition).i1m = function () {
    var tmp = this.g1m_1;
    if (!(tmp == null))
      return tmp;
    else {
      throwUninitializedPropertyAccessException('condition');
    }
  };
  protoOf(Transition).y1m = function (event) {
    this.h1m_1(event);
  };
  protoOf(Transition).s1n = function (condition) {
    this.g1m_1 = condition;
  };
  protoOf(Transition).t1n = function (action) {
    this.h1m_1 = action;
  };
  function _get_LOG__e5r759_6($this) {
    var tmp0 = $this.km_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('LOG', 1, tmp, PropertiesFileParser$_get_LOG_$ref_e0dkre(), null);
    return tmp0.j2();
  }
  function PropertiesFileParser$_get_LOG_$ref_e0dkre() {
    return function (p0) {
      return _get_LOG__e5r759_6(p0);
    };
  }
  function PropertiesFileParser() {
    PropertiesFileParser_instance = this;
    this.km_1 = logger(getKClass(PropertiesFileParser));
  }
  protoOf(PropertiesFileParser).lm = function (text) {
    // Inline function 'kotlin.collections.mutableMapOf' call
    var translations = LinkedHashMap_init_$Create$();
    var currentKey = null;
    var currentValue = null;
    // Inline function 'kotlin.collections.filter' call
    var tmp0 = lines(text);
    // Inline function 'kotlin.collections.filterTo' call
    var destination = ArrayList_init_$Create$();
    var _iterator__ex2g4s = tmp0.i();
    while (_iterator__ex2g4s.j()) {
      var element = _iterator__ex2g4s.k();
      var tmp;
      if (!startsWith(element, _Char___init__impl__6a9atx(35))) {
        // Inline function 'kotlin.text.isNotBlank' call
        tmp = !isBlank(element);
      } else {
        tmp = false;
      }
      if (tmp) {
        destination.h(element);
      }
    }
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s_0 = destination.i();
    while (_iterator__ex2g4s_0.j()) {
      var element_0 = _iterator__ex2g4s_0.k();
      try {
        if (currentKey == null) {
          var _destruct__k2r9zo = split(element_0, charArrayOf([_Char___init__impl__6a9atx(61)]));
          // Inline function 'kotlin.collections.component1' call
          var key = _destruct__k2r9zo.l(0);
          // Inline function 'kotlin.collections.component2' call
          var value = _destruct__k2r9zo.l(1);
          // Inline function 'kotlin.text.trim' call
          currentKey = toString(trim(isCharSequence(key) ? key : THROW_CCE()));
          // Inline function 'kotlin.text.trim' call
          currentValue = toString(trim(isCharSequence(value) ? value : THROW_CCE()));
        } else {
          var tmp0_safe_receiver = currentValue;
          var tmp_0;
          if (tmp0_safe_receiver == null) {
            tmp_0 = null;
          } else {
            // Inline function 'kotlin.text.trim' call
            tmp_0 = tmp0_safe_receiver + toString(trim(isCharSequence(element_0) ? element_0 : THROW_CCE()));
          }
          currentValue = tmp_0;
        }
        currentValue = replace(ensureNotNull(currentValue), '\\n', '\n');
        if (endsWith(currentValue, _Char___init__impl__6a9atx(92))) {
          currentValue = removeSuffix(currentValue, '\\');
        } else {
          var tmp2 = currentKey;
          // Inline function 'kotlin.collections.set' call
          var value_0 = currentValue;
          translations.y1(tmp2, value_0);
          currentKey = null;
          currentValue = null;
        }
      } catch ($p) {
        if ($p instanceof Error) {
          var e = $p;
          _get_LOG__e5r759_6(PropertiesFileParser_getInstance()).ml("Error while parsing translation line '" + element_0 + "': " + e.toString());
          throw e;
        } else {
          throw $p;
        }
      }
    }
    if (!(currentKey == null)) {
      var tmp2_0 = currentKey;
      // Inline function 'kotlin.collections.set' call
      var value_1 = ensureNotNull(currentValue);
      translations.y1(tmp2_0, value_1);
    }
    return translations;
  };
  var PropertiesFileParser_instance;
  function PropertiesFileParser_getInstance() {
    if (PropertiesFileParser_instance == null)
      new PropertiesFileParser();
    return PropertiesFileParser_instance;
  }
  function _get_LOG__e5r759_7($this) {
    var tmp0 = $this.u1n_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('LOG', 1, tmp, SystemSpeed$Companion$_get_LOG_$ref_umgkzc(), null);
    return tmp0.j2();
  }
  function SystemSpeed$Companion$_get_LOG_$ref_umgkzc() {
    return function (p0) {
      return _get_LOG__e5r759_7(p0);
    };
  }
  function Companion_25() {
    Companion_instance_25 = this;
    this.u1n_1 = logger(getKClass(SystemSpeed));
    this.v1n_1 = 'jabbah.base.time.SystemSpeed';
    this.w1n_1 = 60;
    this.x1n_1 = 0;
    this.y1n_1 = 100;
  }
  var Companion_instance_25;
  function Companion_getInstance_25() {
    if (Companion_instance_25 == null)
      new Companion_25();
    return Companion_instance_25;
  }
  function SystemSpeed(speed, eventBus) {
    Companion_getInstance_25();
    speed = speed === VOID ? BaseModule_getInstance().ap_1.au('jabbah.base.time.SystemSpeed', 60) : speed;
    eventBus = eventBus === VOID ? BaseModule_getInstance().bp_1 : eventBus;
    this.z1n_1 = eventBus;
    this.a1o_1 = speed;
    this.b1o_1 = false;
  }
  protoOf(SystemSpeed).c1o = function (value) {
    var containsArg = this.a1o_1;
    // Inline function 'kotlin.require' call
    if (!(0 <= containsArg ? containsArg <= 100 : false)) {
      var message = 'SystemSpeed must be between 0 and 100';
      throw IllegalArgumentException_init_$Create$(toString(message));
    }
    BaseModule_getInstance().ap_1.et('jabbah.base.time.SystemSpeed', value);
    var oldSpeed = this.a1o_1;
    this.a1o_1 = value;
    this.z1n_1.gu(new SystemSpeedEvent(this, oldSpeed, this.a1o_1));
  };
  protoOf(SystemSpeed).d1o = function () {
    return this.a1o_1 === 100;
  };
  protoOf(SystemSpeed).e1o = function () {
    if (!this.b1o_1) {
      this.b1o_1 = true;
      _get_LOG__e5r759_7(Companion_getInstance_25()).ql('SystemSpeed paused');
      this.z1n_1.gu(new SystemSpeedPauseEvent(this, this.b1o_1));
    }
  };
  protoOf(SystemSpeed).f1o = function () {
    if (this.b1o_1) {
      this.b1o_1 = false;
      _get_LOG__e5r759_7(Companion_getInstance_25()).ql('SystemSpeed resumed');
      this.z1n_1.gu(new SystemSpeedPauseEvent(this, this.b1o_1));
    }
  };
  function SystemSpeedEvent(source, oldSpeed, newSpeed) {
    this.g1o_1 = source;
    this.h1o_1 = oldSpeed;
    this.i1o_1 = newSpeed;
  }
  protoOf(SystemSpeedEvent).toString = function () {
    return 'SystemSpeedEvent(source=' + toString(this.g1o_1) + ', oldSpeed=' + this.h1o_1 + ', newSpeed=' + this.i1o_1 + ')';
  };
  protoOf(SystemSpeedEvent).hashCode = function () {
    var result = hashCode(this.g1o_1);
    result = imul(result, 31) + this.h1o_1 | 0;
    result = imul(result, 31) + this.i1o_1 | 0;
    return result;
  };
  protoOf(SystemSpeedEvent).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof SystemSpeedEvent))
      return false;
    if (!equals(this.g1o_1, other.g1o_1))
      return false;
    if (!(this.h1o_1 === other.h1o_1))
      return false;
    if (!(this.i1o_1 === other.i1o_1))
      return false;
    return true;
  };
  function SystemSpeedPauseEvent(source, isPaused) {
    this.j1o_1 = source;
    this.k1o_1 = isPaused;
  }
  protoOf(SystemSpeedPauseEvent).toString = function () {
    return 'SystemSpeedPauseEvent(source=' + toString(this.j1o_1) + ', isPaused=' + this.k1o_1 + ')';
  };
  protoOf(SystemSpeedPauseEvent).hashCode = function () {
    var result = hashCode(this.j1o_1);
    result = imul(result, 31) + getBooleanHashCode(this.k1o_1) | 0;
    return result;
  };
  protoOf(SystemSpeedPauseEvent).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof SystemSpeedPauseEvent))
      return false;
    if (!equals(this.j1o_1, other.j1o_1))
      return false;
    if (!(this.k1o_1 === other.k1o_1))
      return false;
    return true;
  };
  function Companion_26() {
    Companion_instance_26 = this;
    this.l1o_1 = logger(getKClass(ControlledTimeService));
    this.m1o_1 = 'time';
  }
  var Companion_instance_26;
  function Companion_getInstance_26() {
    if (Companion_instance_26 == null)
      new Companion_26();
    return Companion_instance_26;
  }
  function ControlledTimeService() {
    Companion_getInstance_26();
    this.n1o_1 = new PropertyChangeSupport(this);
    this.o1o_1 = 0n;
  }
  protoOf(ControlledTimeService).op = function () {
    return this.o1o_1;
  };
  function Timer() {
  }
  function DisplayDuration() {
    this.p1o_1 = 2000;
    this.q1o_1 = 15;
  }
  protoOf(DisplayDuration).r1o = function (text) {
    // Inline function 'kotlin.math.max' call
    var b = imul(text.length / 15 | 0, 1000);
    return Math.max(2000, b);
  };
  var DisplayDuration_instance;
  function DisplayDuration_getInstance() {
    return DisplayDuration_instance;
  }
  function AbstractUIController() {
    this.s1o_1 = null;
  }
  protoOf(AbstractUIController).t1o = function (value) {
    this.s1o_1 = value;
    this.u1o();
  };
  protoOf(AbstractUIController).v1o = function () {
    var tmp0_elvis_lhs = this.s1o_1;
    var tmp;
    if (tmp0_elvis_lhs == null) {
      throw IllegalStateException_init_$Create$('access to uninitialized view property');
    } else {
      tmp = tmp0_elvis_lhs;
    }
    return tmp;
  };
  protoOf(AbstractUIController).u1o = function () {
  };
  function UI() {
    this.w1o_1 = false;
  }
  var UI_instance;
  function UI_getInstance() {
    return UI_instance;
  }
  //region block: post-declaration
  protoOf(Path2DJs).oo = quadTo;
  protoOf(Path2DJs).po = contains_1;
  protoOf(Path2DJs).qo = contains_2;
  protoOf(Path2DJs).ro = intersects;
  protoOf(RealTimeTimerJs).wp = initialize$default;
  protoOf(AbstractAction).wq = get_requestFocusOnClick;
  defineProp(protoOf(AbstractAction), 'opensDialog', function () {
    return this.vq();
  });
  defineProp(protoOf(AbstractAction), 'name', function () {
    return this.m2();
  }, function (value) {
    this.kq(value);
  });
  defineProp(protoOf(AbstractAction), 'description', function () {
    return this.mq();
  }, function (value) {
    this.lq(value);
  });
  defineProp(protoOf(AbstractAction), 'accelerator', function () {
    return this.oq();
  }, function (value) {
    this.nq(value);
  });
  defineProp(protoOf(AbstractAction), 'enabled', function () {
    return this.qq();
  }, function (value) {
    this.pq(value);
  });
  defineProp(protoOf(AbstractAction), 'selected', function () {
    return this.sq();
  }, function (value) {
    this.rq(value);
  });
  defineProp(protoOf(AbstractAction), 'imagePath', function () {
    return this.uq();
  }, function (value) {
    this.tq(value);
  });
  defineProp(protoOf(AbstractAction), 'requestFocusOnClick', function () {
    return this.wq();
  });
  protoOf(StoringActivationRecord).bx = getValue$default;
  protoOf(StoringActivationRecord).fx = getOptionalValue$default;
  protoOf(ScopedSymbolTable).l13 = hasSymbol$default;
  protoOf(ScopedSymbolTable).f13 = lookup$default;
  protoOf(ActionEvent).t17 = get_isAltDown;
  protoOf(ActionEvent).u17 = get_isControlDown;
  protoOf(ActionEvent).v17 = get_isShiftDown;
  protoOf(ActionEvent).w17 = get_isCtrlDown;
  protoOf(ActionEvent).x17 = get_isAltGraphDown;
  protoOf(ActionEvent).y17 = get_isMetaDown;
  protoOf(ActionEvent).hasModifier = hasModifier;
  defineProp(protoOf(ActionEvent), 'event', function () {
    return this.o17();
  });
  defineProp(protoOf(ActionEvent), 'source', function () {
    return this.p17();
  });
  defineProp(protoOf(ActionEvent), 'modifiers', function () {
    return this.q17();
  });
  defineProp(protoOf(ActionEvent), 'isAltDown', function () {
    return this.t17();
  });
  defineProp(protoOf(ActionEvent), 'isControlDown', function () {
    return this.u17();
  });
  defineProp(protoOf(ActionEvent), 'isShiftDown', function () {
    return this.v17();
  });
  defineProp(protoOf(ActionEvent), 'isCtrlDown', function () {
    return this.w17();
  });
  defineProp(protoOf(ActionEvent), 'isAltGraphDown', function () {
    return this.x17();
  });
  defineProp(protoOf(ActionEvent), 'isMetaDown', function () {
    return this.y17();
  });
  protoOf(EventBusImpl).d18 = postVetoable$default;
  protoOf(EventBusImpl).f18 = postTwoPhase$default;
  defineProp(protoOf(Modifier), 'name', protoOf(Modifier).m2);
  defineProp(protoOf(Modifier), 'ordinal', protoOf(Modifier).n2);
  protoOf(KeyEventImpl).t17 = get_isAltDown;
  protoOf(KeyEventImpl).u17 = get_isControlDown;
  protoOf(KeyEventImpl).v17 = get_isShiftDown;
  protoOf(KeyEventImpl).w17 = get_isCtrlDown;
  protoOf(KeyEventImpl).x17 = get_isAltGraphDown;
  protoOf(KeyEventImpl).y17 = get_isMetaDown;
  protoOf(KeyEventImpl).hasModifier = hasModifier;
  defineProp(protoOf(KeyEventImpl), 'event', function () {
    return this.o17();
  });
  defineProp(protoOf(KeyEventImpl), 'source', function () {
    return this.p17();
  });
  defineProp(protoOf(KeyEventImpl), 'modifiers', function () {
    return this.q17();
  });
  defineProp(protoOf(KeyEventImpl), 'isAltDown', function () {
    return this.t17();
  });
  defineProp(protoOf(KeyEventImpl), 'isControlDown', function () {
    return this.u17();
  });
  defineProp(protoOf(KeyEventImpl), 'isShiftDown', function () {
    return this.v17();
  });
  defineProp(protoOf(KeyEventImpl), 'isCtrlDown', function () {
    return this.w17();
  });
  defineProp(protoOf(KeyEventImpl), 'isAltGraphDown', function () {
    return this.x17();
  });
  defineProp(protoOf(KeyEventImpl), 'isMetaDown', function () {
    return this.y17();
  });
  protoOf(MouseEventImpl).jw = get_location;
  protoOf(MouseEventImpl).t17 = get_isAltDown;
  protoOf(MouseEventImpl).u17 = get_isControlDown;
  protoOf(MouseEventImpl).v17 = get_isShiftDown;
  protoOf(MouseEventImpl).w17 = get_isCtrlDown;
  protoOf(MouseEventImpl).x17 = get_isAltGraphDown;
  protoOf(MouseEventImpl).y17 = get_isMetaDown;
  protoOf(MouseEventImpl).hasModifier = hasModifier;
  defineProp(protoOf(MouseEventImpl), 'event', function () {
    return this.o17();
  });
  defineProp(protoOf(MouseEventImpl), 'source', function () {
    return this.p17();
  });
  defineProp(protoOf(MouseEventImpl), 'modifiers', function () {
    return this.q17();
  });
  defineProp(protoOf(MouseEventImpl), 'isAltDown', function () {
    return this.t17();
  });
  defineProp(protoOf(MouseEventImpl), 'isControlDown', function () {
    return this.u17();
  });
  defineProp(protoOf(MouseEventImpl), 'isShiftDown', function () {
    return this.v17();
  });
  defineProp(protoOf(MouseEventImpl), 'isCtrlDown', function () {
    return this.w17();
  });
  defineProp(protoOf(MouseEventImpl), 'isAltGraphDown', function () {
    return this.x17();
  });
  defineProp(protoOf(MouseEventImpl), 'isMetaDown', function () {
    return this.y17();
  });
  protoOf(AbstractRectangularShape).l1c = moveBy;
  protoOf(AbstractRectangularShape).m1c = setFrame;
  protoOf(AbstractRectangularShape).vn = add_0;
  protoOf(AbstractRectangularShape).eo = add_1;
  protoOf(AbstractRectangularShape).n1c = add_2;
  protoOf(AbstractRectangularShape).o1c = expandBy;
  protoOf(AbstractRectangularShape).p1c = expandBy_0;
  protoOf(AbstractRectangularShape).q1c = expandBy_1;
  protoOf(AbstractRectangularShape).r1c = expandLeftBy;
  protoOf(AbstractRectangularShape).go = contains_3;
  protoOf(AbstractRectangularShape).ho = contains_4;
  protoOf(AbstractRectangularShape).po = contains_1;
  protoOf(AbstractRectangularShape).qo = contains_2;
  protoOf(AbstractRectangularShape).s1c = get_xInt;
  protoOf(AbstractRectangularShape).t1c = get_yInt;
  protoOf(AbstractRectangularShape).u1c = get_widthInt;
  protoOf(AbstractRectangularShape).v1c = get_heightInt;
  protoOf(AbstractRectangularShape).w1c = get_isInitial;
  protoOf(AbstractRectangularShape).qv = get_isEmpty;
  protoOf(AbstractRectangularShape).x1c = get_centerX;
  protoOf(AbstractRectangularShape).y1c = get_centerY;
  protoOf(AbstractRectangularShape).z1c = get_minX;
  protoOf(AbstractRectangularShape).a1d = get_minY;
  protoOf(AbstractRectangularShape).b1d = get_maxX;
  protoOf(AbstractRectangularShape).c1d = get_maxY;
  protoOf(AbstractRectangularShape).d1d = get_center;
  protoOf(AbstractRectangularShape).e1d = get_topLeft;
  protoOf(AbstractRectangularShape).f1d = get_bottomCenter;
  protoOf(AbstractRectangularShape).g1d = get_centerLeft;
  protoOf(AbstractRectangularShape).h1d = get_centerRight;
  protoOf(AbstractRectangularShape).ro = intersects;
  protoOf(AffineTransformImpl).j1d = get_uniformScale;
  protoOf(AffineTransformImpl).m1d = translate;
  //endregion
  //region block: init
  TranslationsOutlet_instance = new TranslationsOutlet();
  SoundClipFactory_instance = new SoundClipFactory();
  SoundClipJs_instance = new SoundClipJs();
  ToneFactory_instance = new ToneFactory();
  ActionProperty_instance = new ActionProperty();
  Companion_instance_0 = new Companion_0();
  Companion_instance_1 = new Companion_1();
  UninitializedValue_instance = new UninitializedValue();
  Companion_instance_4 = new Companion_4();
  TopologicalSort_instance = new TopologicalSort();
  Dsl_instance = new Dsl();
  Companion_instance_10 = new Companion_10();
  Companion_instance_11 = new Companion_11();
  Geometry_instance = new Geometry();
  Companion_instance_15 = new Companion_15();
  Companion_instance_16 = new Companion_16();
  Companion_instance_20 = new Companion_20();
  Companion_instance_21 = new Companion_21();
  SoundEffects_instance = new SoundEffects();
  Companion_instance_23 = new Companion_23();
  DisplayDuration_instance = new DisplayDuration();
  UI_instance = new UI();
  //endregion
  //region block: exports
  function $jsExportAll$(_) {
    var io = _.io || (_.io = {});
    var antarescircuit = io.antarescircuit || (io.antarescircuit = {});
    var jabbah = antarescircuit.jabbah || (antarescircuit.jabbah = {});
    var base = jabbah.base || (jabbah.base = {});
    defineProp(base, 'TranslationsOutlet', TranslationsOutlet_getInstance, VOID, true);
    var io_0 = _.io || (_.io = {});
    var antarescircuit_0 = io_0.antarescircuit || (io_0.antarescircuit = {});
    var jabbah_0 = antarescircuit_0.jabbah || (antarescircuit_0.jabbah = {});
    var base_0 = jabbah_0.base || (jabbah_0.base = {});
    var event = base_0.event || (base_0.event = {});
    var io_1 = _.io || (_.io = {});
    var antarescircuit_1 = io_1.antarescircuit || (io_1.antarescircuit = {});
    var jabbah_1 = antarescircuit_1.jabbah || (antarescircuit_1.jabbah = {});
    var base_1 = jabbah_1.base || (jabbah_1.base = {});
    var event_0 = base_1.event || (base_1.event = {});
    event_0.mpListener = mpListener;
    var io_2 = _.io || (_.io = {});
    var antarescircuit_2 = io_2.antarescircuit || (io_2.antarescircuit = {});
    var jabbah_2 = antarescircuit_2.jabbah || (antarescircuit_2.jabbah = {});
    var base_2 = jabbah_2.base || (jabbah_2.base = {});
    defineProp(base_2, 'ActionProperty', ActionProperty_getInstance, VOID, true);
    var io_3 = _.io || (_.io = {});
    var antarescircuit_3 = io_3.antarescircuit || (io_3.antarescircuit = {});
    var jabbah_3 = antarescircuit_3.jabbah || (antarescircuit_3.jabbah = {});
    var base_3 = jabbah_3.base || (jabbah_3.base = {});
    base_3.UUID = UUID;
    var io_4 = _.io || (_.io = {});
    var antarescircuit_4 = io_4.antarescircuit || (io_4.antarescircuit = {});
    var jabbah_4 = antarescircuit_4.jabbah || (antarescircuit_4.jabbah = {});
    var base_4 = jabbah_4.base || (jabbah_4.base = {});
    var event_1 = base_4.event || (base_4.event = {});
    event_1.ActionEvent = ActionEvent;
    var io_5 = _.io || (_.io = {});
    var antarescircuit_5 = io_5.antarescircuit || (io_5.antarescircuit = {});
    var jabbah_5 = antarescircuit_5.jabbah || (antarescircuit_5.jabbah = {});
    var base_5 = jabbah_5.base || (jabbah_5.base = {});
    var event_2 = base_5.event || (base_5.event = {});
    event_2.Modifier = Modifier;
    event_2.Modifier.values = values_0;
    event_2.Modifier.valueOf = valueOf;
    defineProp(event_2.Modifier, 'Shift', Modifier_Shift_getInstance, VOID, true);
    defineProp(event_2.Modifier, 'Ctrl', Modifier_Ctrl_getInstance, VOID, true);
    defineProp(event_2.Modifier, 'Meta', Modifier_Meta_getInstance, VOID, true);
    defineProp(event_2.Modifier, 'Alt', Modifier_Alt_getInstance, VOID, true);
    defineProp(event_2.Modifier, 'AltGraph', Modifier_AltGraph_getInstance, VOID, true);
    var io_6 = _.io || (_.io = {});
    var antarescircuit_6 = io_6.antarescircuit || (io_6.antarescircuit = {});
    var jabbah_6 = antarescircuit_6.jabbah || (antarescircuit_6.jabbah = {});
    var base_6 = jabbah_6.base || (jabbah_6.base = {});
    var event_3 = base_6.event || (base_6.event = {});
    event_3.PropertyChangeEvent = PropertyChangeEvent;
  }
  $jsExportAll$(_);
  _.$jsExportAll$ = $jsExportAll$;
  _.$_$ = _.$_$ || {};
  _.$_$.a = Companion_instance_4;
  _.$_$.b = TopologicalSort_instance;
  _.$_$.c = Companion_getInstance_5;
  _.$_$.d = Dsl_instance;
  _.$_$.e = Companion_instance_10;
  _.$_$.f = Companion_getInstance_13;
  _.$_$.g = Geometry_instance;
  _.$_$.h = Companion_getInstance_14;
  _.$_$.i = Companion_instance_15;
  _.$_$.j = Companion_instance_16;
  _.$_$.k = HelpSourceRegistry_getInstance;
  _.$_$.l = Companion_getInstance_17;
  _.$_$.m = BaseModuleJs_getInstance;
  _.$_$.n = BaseModule_getInstance;
  _.$_$.o = Companion_getInstance_18;
  _.$_$.p = Companion_instance_21;
  _.$_$.q = Companion_instance_20;
  _.$_$.r = SoundClipFactory_instance;
  _.$_$.s = SoundEffects_instance;
  _.$_$.t = ToneFactory_instance;
  _.$_$.u = Companion_instance_23;
  _.$_$.v = DisplayDuration_instance;
  _.$_$.w = UI_instance;
  _.$_$.x = Companion_getInstance_3;
  _.$_$.y = LogSystem_getInstance;
  _.$_$.z = Companion_getInstance_2;
  _.$_$.a1 = Status_getInstance;
  _.$_$.b1 = StringUtils_getInstance;
  _.$_$.c1 = System_getInstance;
  _.$_$.d1 = Translations_getInstance;
  _.$_$.e1 = BaseTokenType_ID_getInstance;
  _.$_$.f1 = BaseTokenType_LITERAL_getInstance;
  _.$_$.g1 = DslTokenType_AND_getInstance;
  _.$_$.h1 = DslTokenType_ASSIGN_getInstance;
  _.$_$.i1 = DslTokenType_AT_getInstance;
  _.$_$.j1 = DslTokenType_CARET_getInstance;
  _.$_$.k1 = DslTokenType_COLON_getInstance;
  _.$_$.l1 = DslTokenType_DIVIDE_getInstance;
  _.$_$.m1 = DslTokenType_DOLLAR_getInstance;
  _.$_$.n1 = DslTokenType_EQUAL_getInstance;
  _.$_$.o1 = DslTokenType_GREATER_getInstance;
  _.$_$.p1 = DslTokenType_HASH_getInstance;
  _.$_$.q1 = DslTokenType_INIT_getInstance;
  _.$_$.r1 = DslTokenType_MINUS_getInstance;
  _.$_$.s1 = DslTokenType_MOD_getInstance;
  _.$_$.t1 = DslTokenType_MULTIPLY_getInstance;
  _.$_$.u1 = DslTokenType_OR_getInstance;
  _.$_$.v1 = DslTokenType_PLUS_getInstance;
  _.$_$.w1 = DslTokenType_SHIFT_LEFT_getInstance;
  _.$_$.x1 = DslTokenType_SHIFT_RIGHT_getInstance;
  _.$_$.y1 = DslTokenType_SMALLER_getInstance;
  _.$_$.z1 = Button_BUTTON1_getInstance;
  _.$_$.a2 = Button_BUTTON2_getInstance;
  _.$_$.b2 = Button_BUTTON3_getInstance;
  _.$_$.c2 = Button_NONE_getInstance;
  _.$_$.d2 = KeyEventType_PRESSED_getInstance;
  _.$_$.e2 = KeyEventType_RELEASED_getInstance;
  _.$_$.f2 = KeyEventType_TYPED_getInstance;
  _.$_$.g2 = Modifier_Alt_getInstance;
  _.$_$.h2 = Modifier_Ctrl_getInstance;
  _.$_$.i2 = Modifier_Meta_getInstance;
  _.$_$.j2 = Modifier_Shift_getInstance;
  _.$_$.k2 = MouseEventType_CLICKED_getInstance;
  _.$_$.l2 = MouseEventType_DRAGGED_getInstance;
  _.$_$.m2 = MouseEventType_ENTERED_getInstance;
  _.$_$.n2 = MouseEventType_EXITED_getInstance;
  _.$_$.o2 = MouseEventType_MOVED_getInstance;
  _.$_$.p2 = MouseEventType_PRESSED_getInstance;
  _.$_$.q2 = MouseEventType_RELEASED_getInstance;
  _.$_$.r2 = MouseEventType_UNKNOWN_getInstance;
  _.$_$.s2 = MouseEventType_WHEEL_ROTATED_getInstance;
  _.$_$.t2 = Direction_EAST_getInstance;
  _.$_$.u2 = Direction_NORTH_getInstance;
  _.$_$.v2 = Direction_SOUTH_getInstance;
  _.$_$.w2 = Direction_WEST_getInstance;
  _.$_$.x2 = Rotation_R0_getInstance;
  _.$_$.y2 = Rotation_R180_getInstance;
  _.$_$.z2 = Rotation_R90_getInstance;
  _.$_$.a3 = Turn_NONE_getInstance;
  _.$_$.b3 = WaveformType_Sine_getInstance;
  _.$_$.c3 = UnhandledEventBehaviour_Strict_getInstance;
  _.$_$.d3 = UnhandledEventBehaviour_Unhandled_getInstance;
  _.$_$.e3 = IssueSeverity_Error_getInstance;
  _.$_$.f3 = IssueSeverity_Warning_getInstance;
  _.$_$.g3 = LogLevel_Info_getInstance;
  _.$_$.h3 = StatusType_Small_getInstance;
  _.$_$.i3 = StatusType_Tool_getInstance;
  _.$_$.j3 = getOptionalValue$default;
  _.$_$.k3 = getValue$default;
  _.$_$.l3 = hasSymbol$default;
  _.$_$.m3 = lookup$default;
  _.$_$.n3 = AffineTransformImpl_init_$Create$_0;
  _.$_$.o3 = Dimension2D_init_$Create$;
  _.$_$.p3 = Ellipse2D_init_$Create$;
  _.$_$.q3 = Point2D_init_$Create$;
  _.$_$.r3 = Point2D_init_$Create$_0;
  _.$_$.s3 = Rectangle2D_init_$Create$_2;
  _.$_$.t3 = Rectangle2D_init_$Create$_0;
  _.$_$.u3 = Rectangle2D_init_$Create$;
  _.$_$.v3 = RoundRectangle2D_init_$Create$;
  _.$_$.w3 = Vector2D_init_$Create$;
  _.$_$.x3 = RichTextParser_init_$Create$;
  _.$_$.y3 = AbstractAction_init_$Init$;
  _.$_$.z3 = Tooltip_init_$Create$;
  _.$_$.a4 = DirectedGraph;
  _.$_$.b4 = EmptyIterator;
  _.$_$.c4 = ImmutableList;
  _.$_$.d4 = PriorityQueue;
  _.$_$.e4 = Stack;
  _.$_$.f4 = toImmutableList;
  _.$_$.g4 = AbstractNode;
  _.$_$.h4 = ActivationRecord;
  _.$_$.i4 = DslError;
  _.$_$.j4 = DslGlobalFunctions;
  _.$_$.k4 = DslLexer;
  _.$_$.l4 = DslParser;
  _.$_$.m4 = Visitor;
  _.$_$.n4 = DslSemanticAnalyser;
  _.$_$.o4 = ExternalFunctionSymbol;
  _.$_$.p4 = ExternalFunction;
  _.$_$.q4 = Interpreter;
  _.$_$.r4 = Memory;
  _.$_$.s4 = RuntimeError;
  _.$_$.t4 = ScopedSymbolTable;
  _.$_$.u4 = ScriptMetaData;
  _.$_$.v4 = SemanticError;
  _.$_$.w4 = StoringActivationRecord;
  _.$_$.x4 = SymbolTable;
  _.$_$.y4 = Symbol;
  _.$_$.z4 = SyntaxError;
  _.$_$.a5 = Variable;
  _.$_$.b5 = anyParam;
  _.$_$.c5 = longParam;
  _.$_$.d5 = stringParam;
  _.$_$.e5 = ActionListener;
  _.$_$.f5 = EventBusImpl;
  _.$_$.g5 = hasModifier;
  _.$_$.h5 = get_isAltDown;
  _.$_$.i5 = get_isAltGraphDown;
  _.$_$.j5 = get_isControlDown;
  _.$_$.k5 = get_isCtrlDown;
  _.$_$.l5 = get_isMetaDown;
  _.$_$.m5 = get_isShiftDown;
  _.$_$.n5 = InputEvent;
  _.$_$.o5 = KeyAdapter;
  _.$_$.p5 = KeyEventImpl;
  _.$_$.q5 = MouseAdapter;
  _.$_$.r5 = MouseEventImpl;
  _.$_$.s5 = MouseEvent;
  _.$_$.t5 = PropertyChangeListener;
  _.$_$.u5 = PropertyChangeSupport;
  _.$_$.v5 = PropertyOwnerImpl;
  _.$_$.w5 = VetoException;
  _.$_$.x5 = AbstractRectangularShape;
  _.$_$.y5 = AffineTransformImpl;
  _.$_$.z5 = Dimension2D;
  _.$_$.a6 = values_1;
  _.$_$.b6 = Ellipse2D;
  _.$_$.c6 = MutableRectangularShape;
  _.$_$.d6 = Path2DJs;
  _.$_$.e6 = Point2D;
  _.$_$.f6 = Rectangle2D;
  _.$_$.g6 = RectangularShape;
  _.$_$.h6 = Ring2D;
  _.$_$.i6 = RoundRectangle2D;
  _.$_$.j6 = contains_1;
  _.$_$.k6 = contains_2;
  _.$_$.l6 = intersects;
  _.$_$.m6 = Shape;
  _.$_$.n6 = Vector2D;
  _.$_$.o6 = HelpId;
  _.$_$.p6 = HelpSource;
  _.$_$.q6 = formatRounded;
  _.$_$.r6 = interpolate;
  _.$_$.s6 = near;
  _.$_$.t6 = Token;
  _.$_$.u6 = ToneParams;
  _.$_$.v6 = stateMachine;
  _.$_$.w6 = ControlledTimeService;
  _.$_$.x6 = SystemSpeedEvent;
  _.$_$.y6 = SystemSpeedPauseEvent;
  _.$_$.z6 = SystemSpeed;
  _.$_$.a7 = AbstractUIController;
  _.$_$.b7 = Throttle;
  _.$_$.c7 = AbstractAction;
  _.$_$.d7 = AbstractModule;
  _.$_$.e7 = Action;
  _.$_$.f7 = Disposable;
  _.$_$.g7 = EmptyHierarchyVisitor;
  _.$_$.h7 = IssueImpl;
  _.$_$.i7 = LongValueImpl;
  _.$_$.j7 = LongValue;
  _.$_$.k7 = PreferencesChangedEvent;
  _.$_$.l7 = PropertiesProxy;
  _.$_$.m7 = Properties;
  _.$_$.n7 = Tooltip;
  _.$_$.o7 = TranslationServiceJsImpl;
  _.$_$.p7 = UUID;
  _.$_$.q7 = logger;
  _.$_$.r7 = resettableLazy;
  //endregion
  return _;
}));

//# sourceMappingURL=jabbah-base.js.map
