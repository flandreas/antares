(function (factory) {
  if (typeof define === 'function' && define.amd)
    define(['exports'], factory);
  else if (typeof exports === 'object')
    factory(module.exports);
  else
    globalThis['ktor-ktor-io'] = factory(typeof globalThis['ktor-ktor-io'] === 'undefined' ? {} : globalThis['ktor-ktor-io']);
}(function (_) {
  'use strict';
  //region block: pre-declaration
  //endregion
  var PACKET_MAX_COPY_SIZE;
  //region block: init
  PACKET_MAX_COPY_SIZE = 200;
  //endregion
  return _;
}));

//# sourceMappingURL=ktor-ktor-io.js.map
