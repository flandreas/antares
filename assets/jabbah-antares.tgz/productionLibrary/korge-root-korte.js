(function (factory) {
  if (typeof define === 'function' && define.amd)
    define(['exports'], factory);
  else if (typeof exports === 'object')
    factory(module.exports);
  else
    globalThis['korge-root-korte'] = factory(typeof globalThis['korge-root-korte'] === 'undefined' ? {} : globalThis['korge-root-korte']);
}(function (_) {
  'use strict';
  //region block: pre-declaration
  //endregion
  return _;
}));

//# sourceMappingURL=korge-root-korte.js.map
