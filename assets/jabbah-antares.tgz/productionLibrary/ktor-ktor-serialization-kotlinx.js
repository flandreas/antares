(function (factory) {
  if (typeof define === 'function' && define.amd)
    define(['exports'], factory);
  else if (typeof exports === 'object')
    factory(module.exports);
  else
    globalThis['ktor-ktor-serialization-kotlinx'] = factory(typeof globalThis['ktor-ktor-serialization-kotlinx'] === 'undefined' ? {} : globalThis['ktor-ktor-serialization-kotlinx']);
}(function (_) {
  'use strict';
  //region block: pre-declaration
  //endregion
  return _;
}));

//# sourceMappingURL=ktor-ktor-serialization-kotlinx.js.map
