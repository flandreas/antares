(function (factory) {
  if (typeof define === 'function' && define.amd)
    define(['exports', './kotlin-kotlin-stdlib.js', './jabbah-base.js', './jabbah-edit.js'], factory);
  else if (typeof exports === 'object')
    factory(module.exports, require('./kotlin-kotlin-stdlib.js'), require('./jabbah-base.js'), require('./jabbah-edit.js'));
  else {
    if (typeof globalThis['kotlin-kotlin-stdlib'] === 'undefined') {
      throw new Error("Error loading module 'jabbah-app'. Its dependency 'kotlin-kotlin-stdlib' was not found. Please, check whether 'kotlin-kotlin-stdlib' is loaded prior to 'jabbah-app'.");
    }
    if (typeof globalThis['jabbah-base'] === 'undefined') {
      throw new Error("Error loading module 'jabbah-app'. Its dependency 'jabbah-base' was not found. Please, check whether 'jabbah-base' is loaded prior to 'jabbah-app'.");
    }
    if (typeof globalThis['jabbah-edit'] === 'undefined') {
      throw new Error("Error loading module 'jabbah-app'. Its dependency 'jabbah-edit' was not found. Please, check whether 'jabbah-edit' is loaded prior to 'jabbah-app'.");
    }
    globalThis['jabbah-app'] = factory(typeof globalThis['jabbah-app'] === 'undefined' ? {} : globalThis['jabbah-app'], globalThis['kotlin-kotlin-stdlib'], globalThis['jabbah-base'], globalThis['jabbah-edit']);
  }
}(function (_, kotlin_kotlin, kotlin_jabbah_base, kotlin_jabbah_edit) {
  'use strict';
  //region block: imports
  var imul = Math.imul;
  var toString = kotlin_kotlin.$_$.tb;
  var protoOf = kotlin_kotlin.$_$.t7;
  var hashCode = kotlin_kotlin.$_$.c7;
  var equals = kotlin_kotlin.$_$.u6;
  var initMetadataForClass = kotlin_kotlin.$_$.d7;
  var toInt = kotlin_kotlin.$_$.ka;
  var NumberFormatException = kotlin_kotlin.$_$.db;
  var IllegalArgumentException_init_$Create$ = kotlin_kotlin.$_$.b1;
  var objectCreate = kotlin_kotlin.$_$.s7;
  var _Char___init__impl__6a9atx = kotlin_kotlin.$_$.n1;
  var THROW_CCE = kotlin_kotlin.$_$.fb;
  var isCharSequence = kotlin_kotlin.$_$.k7;
  var trim = kotlin_kotlin.$_$.sa;
  var toString_0 = kotlin_kotlin.$_$.v7;
  var substringBefore = kotlin_kotlin.$_$.da;
  var substringAfter = kotlin_kotlin.$_$.ca;
  var charArrayOf = kotlin_kotlin.$_$.o6;
  var split = kotlin_kotlin.$_$.y9;
  var charSequenceLength = kotlin_kotlin.$_$.r6;
  var initMetadataForCompanion = kotlin_kotlin.$_$.e7;
  var VOID = kotlin_kotlin.$_$.b;
  var compareTo = kotlin_kotlin.$_$.s6;
  var Unit_instance = kotlin_kotlin.$_$.i;
  var getStringHashCode = kotlin_kotlin.$_$.b7;
  var Comparable = kotlin_kotlin.$_$.va;
  var initMetadataForObject = kotlin_kotlin.$_$.i7;
  var RuntimeException = kotlin_kotlin.$_$.eb;
  var Translations_getInstance = kotlin_jabbah_base.$_$.d1;
  var RuntimeException_init_$Init$ = kotlin_kotlin.$_$.i1;
  var captureStack = kotlin_kotlin.$_$.n6;
  var THROW_IAE = kotlin_kotlin.$_$.gb;
  var setOf = kotlin_kotlin.$_$.k4;
  var Enum = kotlin_kotlin.$_$.xa;
  var defineProp = kotlin_kotlin.$_$.t6;
  var getBooleanHashCode = kotlin_kotlin.$_$.x6;
  var AbstractModule = kotlin_jabbah_base.$_$.d7;
  var EditModule_getInstance = kotlin_jabbah_edit.$_$.p;
  //endregion
  //region block: pre-declaration
  initMetadataForClass(ApplicationDataEvent, 'ApplicationDataEvent');
  initMetadataForCompanion(Companion);
  initMetadataForClass(ApplicationVersion, 'ApplicationVersion', VOID, VOID, [Comparable]);
  initMetadataForObject(CurrentApplicationVersion, 'CurrentApplicationVersion');
  initMetadataForClass(ApplicationTooOldException, 'ApplicationTooOldException', VOID, RuntimeException);
  initMetadataForCompanion(Companion_0);
  initMetadataForClass(Environment, 'Environment', VOID, Enum);
  initMetadataForClass(CurrentSavableEvent, 'CurrentSavableEvent');
  initMetadataForClass(SystemMalfunctionEvent, 'SystemMalfunctionEvent');
  initMetadataForClass(CurrentWorkspaceEvent, 'CurrentWorkspaceEvent');
  initMetadataForClass(Workspace, 'Workspace');
  initMetadataForObject(AppModule, 'AppModule', VOID, AbstractModule);
  initMetadataForClass(NopTipOfTheDayProvider, 'NopTipOfTheDayProvider', NopTipOfTheDayProvider);
  //endregion
  function ApplicationDataEvent(oldData, newData) {
    this.j4s_1 = oldData;
    this.k4s_1 = newData;
  }
  protoOf(ApplicationDataEvent).toString = function () {
    return 'ApplicationDataEvent(oldData=' + toString(this.j4s_1) + ', newData=' + toString(this.k4s_1) + ')';
  };
  protoOf(ApplicationDataEvent).hashCode = function () {
    var result = this.j4s_1 == null ? 0 : hashCode(this.j4s_1);
    result = imul(result, 31) + (this.k4s_1 == null ? 0 : hashCode(this.k4s_1)) | 0;
    return result;
  };
  protoOf(ApplicationDataEvent).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof ApplicationDataEvent))
      return false;
    if (!equals(this.j4s_1, other.j4s_1))
      return false;
    if (!equals(this.k4s_1, other.k4s_1))
      return false;
    return true;
  };
  function parsePart($this, version, partValue, partName) {
    try {
      return toInt(partValue);
    } catch ($p) {
      if ($p instanceof NumberFormatException) {
        var e = $p;
        formatError($this, version, 'illegal ' + partName + " '" + partValue + "'");
      } else {
        throw $p;
      }
    }
  }
  function formatError($this, version, reason) {
    throw IllegalArgumentException_init_$Create$("Illegal format of version string '" + version + "': " + reason);
  }
  function ApplicationVersion_init_$Init$(version, $this) {
    ApplicationVersion.call($this, version.l4s_1, version.m4s_1, version.n4s_1, version.o4s_1);
    return $this;
  }
  function ApplicationVersion_init_$Init$_0(version, $this) {
    ApplicationVersion_init_$Init$(Companion_getInstance().lm(version), $this);
    return $this;
  }
  function ApplicationVersion_init_$Create$(version) {
    return ApplicationVersion_init_$Init$_0(version, objectCreate(protoOf(ApplicationVersion)));
  }
  function Companion() {
    Companion_instance = this;
    this.p4s_1 = _Char___init__impl__6a9atx(46);
    this.q4s_1 = _Char___init__impl__6a9atx(45);
    this.r4s_1 = '0.0.0';
  }
  protoOf(Companion).lm = function (version) {
    // Inline function 'kotlin.text.trim' call
    var trimmedVersion = toString_0(trim(isCharSequence(version) ? version : THROW_CCE()));
    var normalVersion = substringBefore(trimmedVersion, _Char___init__impl__6a9atx(45));
    var additionalLabel = substringAfter(trimmedVersion, _Char___init__impl__6a9atx(45), '');
    var normalParts = split(normalVersion, charArrayOf([_Char___init__impl__6a9atx(46)]));
    if (normalParts.o() < 3) {
      formatError(this, normalVersion, 'expecting at least 3 parts');
    }
    var tmp = parsePart(this, normalVersion, normalParts.l(0), 'major');
    var tmp_0 = parsePart(this, normalVersion, normalParts.l(1), 'minor');
    var tmp_1 = parsePart(this, normalVersion, normalParts.l(2), 'patch');
    var tmp_2;
    // Inline function 'kotlin.text.isEmpty' call
    if (charSequenceLength(additionalLabel) === 0) {
      tmp_2 = null;
    } else {
      tmp_2 = additionalLabel;
    }
    return new ApplicationVersion(tmp, tmp_0, tmp_1, tmp_2);
  };
  var Companion_instance;
  function Companion_getInstance() {
    if (Companion_instance == null)
      new Companion();
    return Companion_instance;
  }
  function ApplicationVersion(major, minor, patch, additionalLabel) {
    Companion_getInstance();
    additionalLabel = additionalLabel === VOID ? null : additionalLabel;
    this.l4s_1 = major;
    this.m4s_1 = minor;
    this.n4s_1 = patch;
    this.o4s_1 = additionalLabel;
  }
  protoOf(ApplicationVersion).toString = function () {
    var normalVersion = '' + this.l4s_1 + '.' + this.m4s_1 + '.' + this.n4s_1;
    var tmp;
    if (!(this.o4s_1 == null)) {
      tmp = normalVersion + '-' + this.o4s_1;
    } else {
      tmp = normalVersion;
    }
    return tmp;
  };
  protoOf(ApplicationVersion).s4s = function (other) {
    // Inline function 'kotlin.let' call
    var it = compareTo(this.l4s_1, other.l4s_1);
    if (!(it === 0)) {
      return it;
    }
    // Inline function 'kotlin.let' call
    var it_0 = compareTo(this.m4s_1, other.m4s_1);
    if (!(it_0 === 0)) {
      return it_0;
    }
    // Inline function 'kotlin.let' call
    var it_1 = compareTo(this.n4s_1, other.n4s_1);
    if (!(it_1 === 0)) {
      return it_1;
    }
    if (this.o4s_1 == null && !(other.o4s_1 == null)) {
      return 1;
    }
    if (!(this.o4s_1 == null) && other.o4s_1 == null) {
      return -1;
    }
    if (!(this.o4s_1 == null) && !(other.o4s_1 == null)) {
      return compareTo(this.o4s_1, other.o4s_1);
    }
    return 0;
  };
  protoOf(ApplicationVersion).d = function (other) {
    return this.s4s(other instanceof ApplicationVersion ? other : THROW_CCE());
  };
  protoOf(ApplicationVersion).hashCode = function () {
    var result = this.l4s_1;
    result = imul(result, 31) + this.m4s_1 | 0;
    result = imul(result, 31) + this.n4s_1 | 0;
    result = imul(result, 31) + (this.o4s_1 == null ? 0 : getStringHashCode(this.o4s_1)) | 0;
    return result;
  };
  protoOf(ApplicationVersion).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof ApplicationVersion))
      return false;
    if (!(this.l4s_1 === other.l4s_1))
      return false;
    if (!(this.m4s_1 === other.m4s_1))
      return false;
    if (!(this.n4s_1 === other.n4s_1))
      return false;
    if (!(this.o4s_1 == other.o4s_1))
      return false;
    return true;
  };
  function check($this, dataVersion) {
    if (dataVersion.s4s($this.x4s_1) > 0) {
      throw new ApplicationTooOldException(dataVersion);
    }
  }
  function CurrentApplicationVersion() {
    CurrentApplicationVersion_instance = this;
    this.t4s_1 = 'appVersion';
    this.u4s_1 = 'dataVersion';
    this.v4s_1 = ApplicationVersion_init_$Create$(Companion_getInstance().r4s_1);
    this.w4s_1 = this.v4s_1;
    this.x4s_1 = this.v4s_1;
  }
  protoOf(CurrentApplicationVersion).h38 = function (writer) {
    writer.m39('dataVersion', this.x4s_1.toString());
  };
  protoOf(CurrentApplicationVersion).y4s = function (reader) {
    if (reader.t35('dataVersion')) {
      check(this, Companion_getInstance().lm(reader.r38('dataVersion')));
    } else if (reader.t35('appVersion')) {
      check(this, Companion_getInstance().lm(reader.r38('appVersion')));
    }
  };
  var CurrentApplicationVersion_instance;
  function CurrentApplicationVersion_getInstance() {
    if (CurrentApplicationVersion_instance == null)
      new CurrentApplicationVersion();
    return CurrentApplicationVersion_instance;
  }
  function ApplicationTooOldException(dataVersion) {
    RuntimeException_init_$Init$(Translations_getInstance().bn('application.tooOld.text', [CurrentApplicationVersion_getInstance().w4s_1.toString(), dataVersion.toString()]), this);
    captureStack(this, ApplicationTooOldException);
  }
  var Environment_Development_instance;
  var Environment_Production_instance;
  function Companion_0() {
  }
  protoOf(Companion_0).withName = function (name) {
    var tmp0 = values();
    var tmp$ret$0;
    $l$block: {
      // Inline function 'kotlin.collections.firstOrNull' call
      var inductionVariable = 0;
      var last = tmp0.length;
      while (inductionVariable < last) {
        var element = tmp0[inductionVariable];
        inductionVariable = inductionVariable + 1 | 0;
        // Inline function 'kotlin.text.lowercase' call
        // Inline function 'kotlin.js.asDynamic' call
        var tmp$ret$2 = name.toLowerCase();
        if (element.b4t_1.n(tmp$ret$2)) {
          tmp$ret$0 = element;
          break $l$block;
        }
      }
      tmp$ret$0 = null;
    }
    var tmp0_elvis_lhs = tmp$ret$0;
    var tmp;
    if (tmp0_elvis_lhs == null) {
      throw IllegalArgumentException_init_$Create$('unknown environment ' + name);
    } else {
      tmp = tmp0_elvis_lhs;
    }
    return tmp;
  };
  var Companion_instance_0;
  function Companion_getInstance_0() {
    return Companion_instance_0;
  }
  function values() {
    return [Environment_Development_getInstance(), Environment_Production_getInstance()];
  }
  function valueOf(value) {
    switch (value) {
      case 'Development':
        return Environment_Development_getInstance();
      case 'Production':
        return Environment_Production_getInstance();
      default:
        Environment_initEntries();
        THROW_IAE('No enum constant io.antarescircuit.jabbah.app.Environment.' + value);
        break;
    }
  }
  var Environment_entriesInitialized;
  function Environment_initEntries() {
    if (Environment_entriesInitialized)
      return Unit_instance;
    Environment_entriesInitialized = true;
    Environment_Development_instance = new Environment('Development', 0, setOf(['development', 'dev']));
    Environment_Production_instance = new Environment('Production', 1, setOf(['production', 'prod']));
  }
  function Environment(name, ordinal, names) {
    Enum.call(this, name, ordinal);
    this.b4t_1 = names;
  }
  function Environment_Development_getInstance() {
    Environment_initEntries();
    return Environment_Development_instance;
  }
  function Environment_Production_getInstance() {
    Environment_initEntries();
    return Environment_Production_instance;
  }
  function CurrentSavableEvent(savable) {
    this.c4t_1 = savable;
  }
  protoOf(CurrentSavableEvent).toString = function () {
    return 'CurrentSavableEvent(savable=' + toString(this.c4t_1) + ')';
  };
  protoOf(CurrentSavableEvent).hashCode = function () {
    return this.c4t_1 == null ? 0 : hashCode(this.c4t_1);
  };
  protoOf(CurrentSavableEvent).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof CurrentSavableEvent))
      return false;
    if (!equals(this.c4t_1, other.c4t_1))
      return false;
    return true;
  };
  function SystemMalfunctionEvent(description) {
    this.d4t_1 = description;
  }
  protoOf(SystemMalfunctionEvent).toString = function () {
    return 'SystemMalfunctionEvent(description=' + this.d4t_1 + ')';
  };
  protoOf(SystemMalfunctionEvent).hashCode = function () {
    return getStringHashCode(this.d4t_1);
  };
  protoOf(SystemMalfunctionEvent).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof SystemMalfunctionEvent))
      return false;
    if (!(this.d4t_1 === other.d4t_1))
      return false;
    return true;
  };
  function CurrentWorkspaceEvent(workspace, isPrepare) {
    this.e4t_1 = workspace;
    this.f4t_1 = isPrepare;
  }
  protoOf(CurrentWorkspaceEvent).toString = function () {
    return 'CurrentWorkspaceEvent(workspace=' + this.e4t_1.toString() + ', isPrepare=' + this.f4t_1 + ')';
  };
  protoOf(CurrentWorkspaceEvent).hashCode = function () {
    var result = this.e4t_1.hashCode();
    result = imul(result, 31) + getBooleanHashCode(this.f4t_1) | 0;
    return result;
  };
  protoOf(CurrentWorkspaceEvent).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof CurrentWorkspaceEvent))
      return false;
    if (!this.e4t_1.equals(other.e4t_1))
      return false;
    if (!(this.f4t_1 === other.f4t_1))
      return false;
    return true;
  };
  function Workspace() {
  }
  protoOf(Workspace).toString = function () {
    return 'Workspace(userDataDirectoryPath=' + this.g4t_1 + ')';
  };
  protoOf(Workspace).hashCode = function () {
    return getStringHashCode(this.g4t_1);
  };
  protoOf(Workspace).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof Workspace))
      return false;
    if (!(this.g4t_1 === other.g4t_1))
      return false;
    return true;
  };
  function AppModule() {
    AppModule_instance = this;
    AbstractModule.call(this);
    this.i4t_1 = new NopTipOfTheDayProvider();
  }
  protoOf(AppModule).to = function () {
    Translations_getInstance().wm('jabbah-app');
    EditModule_getInstance().vo();
  };
  var AppModule_instance;
  function AppModule_getInstance() {
    if (AppModule_instance == null)
      new AppModule();
    return AppModule_instance;
  }
  function NopTipOfTheDayProvider() {
    this.j4t_1 = false;
  }
  //region block: post-declaration
  defineProp(protoOf(Environment), 'name', protoOf(Environment).m2);
  defineProp(protoOf(Environment), 'ordinal', protoOf(Environment).n2);
  //endregion
  //region block: init
  Companion_instance_0 = new Companion_0();
  //endregion
  //region block: exports
  function $jsExportAll$(_) {
    var io = _.io || (_.io = {});
    var antarescircuit = io.antarescircuit || (io.antarescircuit = {});
    var jabbah = antarescircuit.jabbah || (antarescircuit.jabbah = {});
    var app = jabbah.app || (jabbah.app = {});
    app.Environment = Environment;
    app.Environment.values = values;
    app.Environment.valueOf = valueOf;
    defineProp(app.Environment, 'Development', Environment_Development_getInstance, VOID, true);
    defineProp(app.Environment, 'Production', Environment_Production_getInstance, VOID, true);
    defineProp(app.Environment, 'Companion', Companion_getInstance_0, VOID, true);
  }
  $jsExportAll$(_);
  _.$jsExportAll$ = $jsExportAll$;
  _.$_$ = _.$_$ || {};
  _.$_$.a = AppModule_getInstance;
  _.$_$.b = CurrentApplicationVersion_getInstance;
  _.$_$.c = ApplicationVersion_init_$Create$;
  _.$_$.d = ApplicationDataEvent;
  _.$_$.e = CurrentSavableEvent;
  _.$_$.f = CurrentWorkspaceEvent;
  _.$_$.g = SystemMalfunctionEvent;
  //endregion
  return _;
}));

//# sourceMappingURL=jabbah-app.js.map
