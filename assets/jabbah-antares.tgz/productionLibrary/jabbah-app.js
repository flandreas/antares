(function (factory) {
  if (typeof define === 'function' && define.amd)
    define(['exports', './kotlin-kotlin-stdlib.js', './jabbah-base.js', './jabbah-edit.js'], factory);
  else if (typeof exports === 'object')
    factory(module.exports, require('./kotlin-kotlin-stdlib.js'), require('./jabbah-base.js'), require('./jabbah-edit.js'));
  else {
    if (typeof globalThis['kotlin-kotlin-stdlib'] === 'undefined') {
      throw new Error("Error loading module 'jabbah-app'. Its dependency 'kotlin-kotlin-stdlib' was not found. Please, check whether 'kotlin-kotlin-stdlib' is loaded prior to 'jabbah-app'.");
    }
    if (typeof globalThis['jabbah-base'] === 'undefined') {
      throw new Error("Error loading module 'jabbah-app'. Its dependency 'jabbah-base' was not found. Please, check whether 'jabbah-base' is loaded prior to 'jabbah-app'.");
    }
    if (typeof globalThis['jabbah-edit'] === 'undefined') {
      throw new Error("Error loading module 'jabbah-app'. Its dependency 'jabbah-edit' was not found. Please, check whether 'jabbah-edit' is loaded prior to 'jabbah-app'.");
    }
    globalThis['jabbah-app'] = factory(typeof globalThis['jabbah-app'] === 'undefined' ? {} : globalThis['jabbah-app'], globalThis['kotlin-kotlin-stdlib'], globalThis['jabbah-base'], globalThis['jabbah-edit']);
  }
}(function (_, kotlin_kotlin, kotlin_jabbah_base, kotlin_jabbah_edit) {
  'use strict';
  //region block: imports
  var imul = Math.imul;
  var toString = kotlin_kotlin.$_$.rb;
  var protoOf = kotlin_kotlin.$_$.t7;
  var hashCode = kotlin_kotlin.$_$.c7;
  var equals = kotlin_kotlin.$_$.u6;
  var initMetadataForClass = kotlin_kotlin.$_$.d7;
  var toInt = kotlin_kotlin.$_$.ia;
  var NumberFormatException = kotlin_kotlin.$_$.bb;
  var IllegalArgumentException_init_$Create$ = kotlin_kotlin.$_$.b1;
  var objectCreate = kotlin_kotlin.$_$.s7;
  var _Char___init__impl__6a9atx = kotlin_kotlin.$_$.n1;
  var THROW_CCE = kotlin_kotlin.$_$.db;
  var isCharSequence = kotlin_kotlin.$_$.k7;
  var trim = kotlin_kotlin.$_$.qa;
  var toString_0 = kotlin_kotlin.$_$.v7;
  var substringBefore = kotlin_kotlin.$_$.ba;
  var substringAfter = kotlin_kotlin.$_$.aa;
  var charArrayOf = kotlin_kotlin.$_$.o6;
  var split = kotlin_kotlin.$_$.w9;
  var charSequenceLength = kotlin_kotlin.$_$.r6;
  var initMetadataForCompanion = kotlin_kotlin.$_$.e7;
  var VOID = kotlin_kotlin.$_$.b;
  var compareTo = kotlin_kotlin.$_$.s6;
  var Unit_instance = kotlin_kotlin.$_$.i;
  var getStringHashCode = kotlin_kotlin.$_$.b7;
  var Comparable = kotlin_kotlin.$_$.ta;
  var initMetadataForObject = kotlin_kotlin.$_$.i7;
  var RuntimeException = kotlin_kotlin.$_$.cb;
  var Translations_getInstance = kotlin_jabbah_base.$_$.d1;
  var RuntimeException_init_$Init$ = kotlin_kotlin.$_$.i1;
  var captureStack = kotlin_kotlin.$_$.n6;
  var THROW_IAE = kotlin_kotlin.$_$.eb;
  var setOf = kotlin_kotlin.$_$.k4;
  var Enum = kotlin_kotlin.$_$.va;
  var defineProp = kotlin_kotlin.$_$.t6;
  var getBooleanHashCode = kotlin_kotlin.$_$.x6;
  var AbstractModule = kotlin_jabbah_base.$_$.d7;
  var EditModule_getInstance = kotlin_jabbah_edit.$_$.p;
  //endregion
  //region block: pre-declaration
  initMetadataForClass(ApplicationDataEvent, 'ApplicationDataEvent');
  initMetadataForCompanion(Companion);
  initMetadataForClass(ApplicationVersion, 'ApplicationVersion', VOID, VOID, [Comparable]);
  initMetadataForObject(CurrentApplicationVersion, 'CurrentApplicationVersion');
  initMetadataForClass(ApplicationTooOldException, 'ApplicationTooOldException', VOID, RuntimeException);
  initMetadataForCompanion(Companion_0);
  initMetadataForClass(Environment, 'Environment', VOID, Enum);
  initMetadataForClass(CurrentSavableEvent, 'CurrentSavableEvent');
  initMetadataForClass(SystemMalfunctionEvent, 'SystemMalfunctionEvent');
  initMetadataForClass(CurrentWorkspaceEvent, 'CurrentWorkspaceEvent');
  initMetadataForClass(Workspace, 'Workspace');
  initMetadataForObject(AppModule, 'AppModule', VOID, AbstractModule);
  //endregion
  function ApplicationDataEvent(oldData, newData) {
    this.r4r_1 = oldData;
    this.s4r_1 = newData;
  }
  protoOf(ApplicationDataEvent).toString = function () {
    return 'ApplicationDataEvent(oldData=' + toString(this.r4r_1) + ', newData=' + toString(this.s4r_1) + ')';
  };
  protoOf(ApplicationDataEvent).hashCode = function () {
    var result = this.r4r_1 == null ? 0 : hashCode(this.r4r_1);
    result = imul(result, 31) + (this.s4r_1 == null ? 0 : hashCode(this.s4r_1)) | 0;
    return result;
  };
  protoOf(ApplicationDataEvent).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof ApplicationDataEvent))
      return false;
    if (!equals(this.r4r_1, other.r4r_1))
      return false;
    if (!equals(this.s4r_1, other.s4r_1))
      return false;
    return true;
  };
  function parsePart($this, version, partValue, partName) {
    try {
      return toInt(partValue);
    } catch ($p) {
      if ($p instanceof NumberFormatException) {
        var e = $p;
        formatError($this, version, 'illegal ' + partName + " '" + partValue + "'");
      } else {
        throw $p;
      }
    }
  }
  function formatError($this, version, reason) {
    throw IllegalArgumentException_init_$Create$("Illegal format of version string '" + version + "': " + reason);
  }
  function ApplicationVersion_init_$Init$(version, $this) {
    ApplicationVersion.call($this, version.t4r_1, version.u4r_1, version.v4r_1, version.w4r_1);
    return $this;
  }
  function ApplicationVersion_init_$Init$_0(version, $this) {
    ApplicationVersion_init_$Init$(Companion_getInstance().jm(version), $this);
    return $this;
  }
  function ApplicationVersion_init_$Create$(version) {
    return ApplicationVersion_init_$Init$_0(version, objectCreate(protoOf(ApplicationVersion)));
  }
  function Companion() {
    Companion_instance = this;
    this.x4r_1 = _Char___init__impl__6a9atx(46);
    this.y4r_1 = _Char___init__impl__6a9atx(45);
    this.z4r_1 = '0.0.0';
  }
  protoOf(Companion).jm = function (version) {
    // Inline function 'kotlin.text.trim' call
    var trimmedVersion = toString_0(trim(isCharSequence(version) ? version : THROW_CCE()));
    var normalVersion = substringBefore(trimmedVersion, _Char___init__impl__6a9atx(45));
    var additionalLabel = substringAfter(trimmedVersion, _Char___init__impl__6a9atx(45), '');
    var normalParts = split(normalVersion, charArrayOf([_Char___init__impl__6a9atx(46)]));
    if (normalParts.o() < 3) {
      formatError(this, normalVersion, 'expecting at least 3 parts');
    }
    var tmp = parsePart(this, normalVersion, normalParts.l(0), 'major');
    var tmp_0 = parsePart(this, normalVersion, normalParts.l(1), 'minor');
    var tmp_1 = parsePart(this, normalVersion, normalParts.l(2), 'patch');
    var tmp_2;
    // Inline function 'kotlin.text.isEmpty' call
    if (charSequenceLength(additionalLabel) === 0) {
      tmp_2 = null;
    } else {
      tmp_2 = additionalLabel;
    }
    return new ApplicationVersion(tmp, tmp_0, tmp_1, tmp_2);
  };
  var Companion_instance;
  function Companion_getInstance() {
    if (Companion_instance == null)
      new Companion();
    return Companion_instance;
  }
  function ApplicationVersion(major, minor, patch, additionalLabel) {
    Companion_getInstance();
    additionalLabel = additionalLabel === VOID ? null : additionalLabel;
    this.t4r_1 = major;
    this.u4r_1 = minor;
    this.v4r_1 = patch;
    this.w4r_1 = additionalLabel;
  }
  protoOf(ApplicationVersion).toString = function () {
    var normalVersion = '' + this.t4r_1 + '.' + this.u4r_1 + '.' + this.v4r_1;
    var tmp;
    if (!(this.w4r_1 == null)) {
      tmp = normalVersion + '-' + this.w4r_1;
    } else {
      tmp = normalVersion;
    }
    return tmp;
  };
  protoOf(ApplicationVersion).a4s = function (other) {
    // Inline function 'kotlin.let' call
    var it = compareTo(this.t4r_1, other.t4r_1);
    if (!(it === 0)) {
      return it;
    }
    // Inline function 'kotlin.let' call
    var it_0 = compareTo(this.u4r_1, other.u4r_1);
    if (!(it_0 === 0)) {
      return it_0;
    }
    // Inline function 'kotlin.let' call
    var it_1 = compareTo(this.v4r_1, other.v4r_1);
    if (!(it_1 === 0)) {
      return it_1;
    }
    if (this.w4r_1 == null && !(other.w4r_1 == null)) {
      return 1;
    }
    if (!(this.w4r_1 == null) && other.w4r_1 == null) {
      return -1;
    }
    if (!(this.w4r_1 == null) && !(other.w4r_1 == null)) {
      return compareTo(this.w4r_1, other.w4r_1);
    }
    return 0;
  };
  protoOf(ApplicationVersion).d = function (other) {
    return this.a4s(other instanceof ApplicationVersion ? other : THROW_CCE());
  };
  protoOf(ApplicationVersion).hashCode = function () {
    var result = this.t4r_1;
    result = imul(result, 31) + this.u4r_1 | 0;
    result = imul(result, 31) + this.v4r_1 | 0;
    result = imul(result, 31) + (this.w4r_1 == null ? 0 : getStringHashCode(this.w4r_1)) | 0;
    return result;
  };
  protoOf(ApplicationVersion).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof ApplicationVersion))
      return false;
    if (!(this.t4r_1 === other.t4r_1))
      return false;
    if (!(this.u4r_1 === other.u4r_1))
      return false;
    if (!(this.v4r_1 === other.v4r_1))
      return false;
    if (!(this.w4r_1 == other.w4r_1))
      return false;
    return true;
  };
  function check($this, dataVersion) {
    if (dataVersion.a4s($this.f4s_1) > 0) {
      throw new ApplicationTooOldException(dataVersion);
    }
  }
  function CurrentApplicationVersion() {
    CurrentApplicationVersion_instance = this;
    this.b4s_1 = 'appVersion';
    this.c4s_1 = 'dataVersion';
    this.d4s_1 = ApplicationVersion_init_$Create$(Companion_getInstance().z4r_1);
    this.e4s_1 = this.d4s_1;
    this.f4s_1 = this.d4s_1;
  }
  protoOf(CurrentApplicationVersion).r37 = function (writer) {
    writer.w38('dataVersion', this.f4s_1.toString());
  };
  protoOf(CurrentApplicationVersion).g4s = function (reader) {
    if (reader.d35('dataVersion')) {
      check(this, Companion_getInstance().jm(reader.b38('dataVersion')));
    } else if (reader.d35('appVersion')) {
      check(this, Companion_getInstance().jm(reader.b38('appVersion')));
    }
  };
  var CurrentApplicationVersion_instance;
  function CurrentApplicationVersion_getInstance() {
    if (CurrentApplicationVersion_instance == null)
      new CurrentApplicationVersion();
    return CurrentApplicationVersion_instance;
  }
  function ApplicationTooOldException(dataVersion) {
    RuntimeException_init_$Init$(Translations_getInstance().zm('application.tooOld.text', [CurrentApplicationVersion_getInstance().e4s_1.toString(), dataVersion.toString()]), this);
    captureStack(this, ApplicationTooOldException);
  }
  var Environment_Development_instance;
  var Environment_Production_instance;
  function Companion_0() {
  }
  protoOf(Companion_0).withName = function (name) {
    var tmp0 = values();
    var tmp$ret$0;
    $l$block: {
      // Inline function 'kotlin.collections.firstOrNull' call
      var inductionVariable = 0;
      var last = tmp0.length;
      while (inductionVariable < last) {
        var element = tmp0[inductionVariable];
        inductionVariable = inductionVariable + 1 | 0;
        // Inline function 'kotlin.text.lowercase' call
        // Inline function 'kotlin.js.asDynamic' call
        var tmp$ret$2 = name.toLowerCase();
        if (element.j4s_1.n(tmp$ret$2)) {
          tmp$ret$0 = element;
          break $l$block;
        }
      }
      tmp$ret$0 = null;
    }
    var tmp0_elvis_lhs = tmp$ret$0;
    var tmp;
    if (tmp0_elvis_lhs == null) {
      throw IllegalArgumentException_init_$Create$('unknown environment ' + name);
    } else {
      tmp = tmp0_elvis_lhs;
    }
    return tmp;
  };
  var Companion_instance_0;
  function Companion_getInstance_0() {
    return Companion_instance_0;
  }
  function values() {
    return [Environment_Development_getInstance(), Environment_Production_getInstance()];
  }
  function valueOf(value) {
    switch (value) {
      case 'Development':
        return Environment_Development_getInstance();
      case 'Production':
        return Environment_Production_getInstance();
      default:
        Environment_initEntries();
        THROW_IAE('No enum constant io.antarescircuit.jabbah.app.Environment.' + value);
        break;
    }
  }
  var Environment_entriesInitialized;
  function Environment_initEntries() {
    if (Environment_entriesInitialized)
      return Unit_instance;
    Environment_entriesInitialized = true;
    Environment_Development_instance = new Environment('Development', 0, setOf(['development', 'dev']));
    Environment_Production_instance = new Environment('Production', 1, setOf(['production', 'prod']));
  }
  function Environment(name, ordinal, names) {
    Enum.call(this, name, ordinal);
    this.j4s_1 = names;
  }
  function Environment_Development_getInstance() {
    Environment_initEntries();
    return Environment_Development_instance;
  }
  function Environment_Production_getInstance() {
    Environment_initEntries();
    return Environment_Production_instance;
  }
  function CurrentSavableEvent(savable) {
    this.k4s_1 = savable;
  }
  protoOf(CurrentSavableEvent).toString = function () {
    return 'CurrentSavableEvent(savable=' + toString(this.k4s_1) + ')';
  };
  protoOf(CurrentSavableEvent).hashCode = function () {
    return this.k4s_1 == null ? 0 : hashCode(this.k4s_1);
  };
  protoOf(CurrentSavableEvent).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof CurrentSavableEvent))
      return false;
    if (!equals(this.k4s_1, other.k4s_1))
      return false;
    return true;
  };
  function SystemMalfunctionEvent(description) {
    this.l4s_1 = description;
  }
  protoOf(SystemMalfunctionEvent).toString = function () {
    return 'SystemMalfunctionEvent(description=' + this.l4s_1 + ')';
  };
  protoOf(SystemMalfunctionEvent).hashCode = function () {
    return getStringHashCode(this.l4s_1);
  };
  protoOf(SystemMalfunctionEvent).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof SystemMalfunctionEvent))
      return false;
    if (!(this.l4s_1 === other.l4s_1))
      return false;
    return true;
  };
  function CurrentWorkspaceEvent(workspace, isPrepare) {
    this.m4s_1 = workspace;
    this.n4s_1 = isPrepare;
  }
  protoOf(CurrentWorkspaceEvent).toString = function () {
    return 'CurrentWorkspaceEvent(workspace=' + this.m4s_1.toString() + ', isPrepare=' + this.n4s_1 + ')';
  };
  protoOf(CurrentWorkspaceEvent).hashCode = function () {
    var result = this.m4s_1.hashCode();
    result = imul(result, 31) + getBooleanHashCode(this.n4s_1) | 0;
    return result;
  };
  protoOf(CurrentWorkspaceEvent).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof CurrentWorkspaceEvent))
      return false;
    if (!this.m4s_1.equals(other.m4s_1))
      return false;
    if (!(this.n4s_1 === other.n4s_1))
      return false;
    return true;
  };
  function Workspace() {
  }
  protoOf(Workspace).toString = function () {
    return 'Workspace(userDataDirectoryPath=' + this.o4s_1 + ')';
  };
  protoOf(Workspace).hashCode = function () {
    return getStringHashCode(this.o4s_1);
  };
  protoOf(Workspace).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof Workspace))
      return false;
    if (!(this.o4s_1 === other.o4s_1))
      return false;
    return true;
  };
  function AppModule() {
    AppModule_instance = this;
    AbstractModule.call(this);
  }
  protoOf(AppModule).ro = function () {
    Translations_getInstance().um('jabbah-app');
    EditModule_getInstance().to();
  };
  var AppModule_instance;
  function AppModule_getInstance() {
    if (AppModule_instance == null)
      new AppModule();
    return AppModule_instance;
  }
  //region block: post-declaration
  defineProp(protoOf(Environment), 'name', protoOf(Environment).m2);
  defineProp(protoOf(Environment), 'ordinal', protoOf(Environment).n2);
  //endregion
  //region block: init
  Companion_instance_0 = new Companion_0();
  //endregion
  //region block: exports
  function $jsExportAll$(_) {
    var io = _.io || (_.io = {});
    var antarescircuit = io.antarescircuit || (io.antarescircuit = {});
    var jabbah = antarescircuit.jabbah || (antarescircuit.jabbah = {});
    var app = jabbah.app || (jabbah.app = {});
    app.Environment = Environment;
    app.Environment.values = values;
    app.Environment.valueOf = valueOf;
    defineProp(app.Environment, 'Development', Environment_Development_getInstance, VOID, true);
    defineProp(app.Environment, 'Production', Environment_Production_getInstance, VOID, true);
    defineProp(app.Environment, 'Companion', Companion_getInstance_0, VOID, true);
  }
  $jsExportAll$(_);
  _.$jsExportAll$ = $jsExportAll$;
  _.$_$ = _.$_$ || {};
  _.$_$.a = AppModule_getInstance;
  _.$_$.b = CurrentApplicationVersion_getInstance;
  _.$_$.c = ApplicationVersion_init_$Create$;
  _.$_$.d = ApplicationDataEvent;
  _.$_$.e = CurrentSavableEvent;
  _.$_$.f = CurrentWorkspaceEvent;
  _.$_$.g = SystemMalfunctionEvent;
  //endregion
  return _;
}));

//# sourceMappingURL=jabbah-app.js.map
