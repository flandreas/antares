(function (factory) {
  if (typeof define === 'function' && define.amd)
    define(['exports', './kotlin-kotlin-stdlib.js', './jabbah-base.js', './jabbah-draw.js'], factory);
  else if (typeof exports === 'object')
    factory(module.exports, require('./kotlin-kotlin-stdlib.js'), require('./jabbah-base.js'), require('./jabbah-draw.js'));
  else {
    if (typeof globalThis['kotlin-kotlin-stdlib'] === 'undefined') {
      throw new Error("Error loading module 'jabbah-execution'. Its dependency 'kotlin-kotlin-stdlib' was not found. Please, check whether 'kotlin-kotlin-stdlib' is loaded prior to 'jabbah-execution'.");
    }
    if (typeof globalThis['jabbah-base'] === 'undefined') {
      throw new Error("Error loading module 'jabbah-execution'. Its dependency 'jabbah-base' was not found. Please, check whether 'jabbah-base' is loaded prior to 'jabbah-execution'.");
    }
    if (typeof globalThis['jabbah-draw'] === 'undefined') {
      throw new Error("Error loading module 'jabbah-execution'. Its dependency 'jabbah-draw' was not found. Please, check whether 'jabbah-draw' is loaded prior to 'jabbah-execution'.");
    }
    globalThis['jabbah-execution'] = factory(typeof globalThis['jabbah-execution'] === 'undefined' ? {} : globalThis['jabbah-execution'], globalThis['kotlin-kotlin-stdlib'], globalThis['jabbah-base'], globalThis['jabbah-draw']);
  }
}(function (_, kotlin_kotlin, kotlin_jabbah_base, kotlin_jabbah_draw) {
  'use strict';
  //region block: imports
  var imul = Math.imul;
  var protoOf = kotlin_kotlin.$_$.t7;
  var initMetadataForInterface = kotlin_kotlin.$_$.g7;
  var subtract = kotlin_kotlin.$_$.i6;
  var VOID = kotlin_kotlin.$_$.b;
  var fromInt = kotlin_kotlin.$_$.a6;
  var initMetadataForClass = kotlin_kotlin.$_$.d7;
  var Action = kotlin_jabbah_base.$_$.e7;
  var KMutableProperty1 = kotlin_kotlin.$_$.r8;
  var getPropertyCallableRef = kotlin_kotlin.$_$.a7;
  var Translations_getInstance = kotlin_jabbah_base.$_$.d1;
  var Unit_instance = kotlin_kotlin.$_$.i;
  var ObservableProperty = kotlin_kotlin.$_$.z7;
  var BaseModule_getInstance = kotlin_jabbah_base.$_$.n;
  var Delegates_instance = kotlin_kotlin.$_$.e;
  var SystemSpeedPauseEvent = kotlin_jabbah_base.$_$.y6;
  var getKClass = kotlin_kotlin.$_$.q8;
  var defineProp = kotlin_kotlin.$_$.t6;
  var initMetadataForCompanion = kotlin_kotlin.$_$.e7;
  var AbstractAction = kotlin_jabbah_base.$_$.c7;
  var AbstractAction_init_$Init$ = kotlin_jabbah_base.$_$.y3;
  var Enum = kotlin_kotlin.$_$.va;
  var Companion_getInstance = kotlin_jabbah_draw.$_$.v;
  var DrawStyleModule_getInstance = kotlin_jabbah_draw.$_$.s;
  var StylableImpl = kotlin_jabbah_draw.$_$.h5;
  var objectCreate = kotlin_kotlin.$_$.s7;
  var InputEventHandlerAdapter = kotlin_jabbah_draw.$_$.f6;
  var THROW_CCE = kotlin_kotlin.$_$.db;
  var equals = kotlin_kotlin.$_$.u6;
  var FunctionAdapter = kotlin_kotlin.$_$.k6;
  var isInterface = kotlin_kotlin.$_$.m7;
  var ButtonAction = kotlin_jabbah_draw.$_$.f3;
  var hashCode = kotlin_kotlin.$_$.c7;
  var DrawableButton = kotlin_jabbah_draw.$_$.i3;
  var Companion_getInstance_0 = kotlin_jabbah_base.$_$.h;
  var KProperty1 = kotlin_kotlin.$_$.t8;
  var lazy = kotlin_kotlin.$_$.ob;
  var LongValueImpl = kotlin_jabbah_base.$_$.i7;
  var toString = kotlin_kotlin.$_$.v7;
  var IllegalArgumentException_init_$Create$ = kotlin_kotlin.$_$.b1;
  var LinkedHashMap_init_$Create$ = kotlin_kotlin.$_$.q;
  var ensureNotNull = kotlin_kotlin.$_$.kb;
  var Collection = kotlin_kotlin.$_$.g2;
  var getBooleanHashCode = kotlin_kotlin.$_$.x6;
  var InputEventContext = kotlin_jabbah_draw.$_$.e6;
  var Cursor_CLICK_getInstance = kotlin_jabbah_draw.$_$.d1;
  var DrawableBagInputEventHandler = kotlin_jabbah_draw.$_$.r2;
  var Drawable = kotlin_jabbah_draw.$_$.y5;
  var DrawableBagImpl = kotlin_jabbah_draw.$_$.q2;
  var DrawableContainerImpl = kotlin_jabbah_draw.$_$.u2;
  var ArrayList_init_$Create$ = kotlin_kotlin.$_$.n;
  var toString_0 = kotlin_kotlin.$_$.rb;
  var IssueSeverity_Warning_getInstance = kotlin_jabbah_base.$_$.f3;
  var IssueSeverity_Error_getInstance = kotlin_jabbah_base.$_$.e3;
  var IssueImpl = kotlin_jabbah_base.$_$.h7;
  var AbstractModule = kotlin_jabbah_base.$_$.d7;
  var initMetadataForObject = kotlin_kotlin.$_$.i7;
  var Default_getInstance = kotlin_kotlin.$_$.f;
  var logger = kotlin_jabbah_base.$_$.q7;
  var add = kotlin_kotlin.$_$.w5;
  var Status_getInstance = kotlin_jabbah_base.$_$.a1;
  var StatusType_Small_getInstance = kotlin_jabbah_base.$_$.h3;
  var StringUtils_getInstance = kotlin_jabbah_base.$_$.b1;
  var compareTo = kotlin_kotlin.$_$.s6;
  var Comparable = kotlin_kotlin.$_$.ta;
  var System_getInstance = kotlin_jabbah_base.$_$.c1;
  var PriorityQueue = kotlin_jabbah_base.$_$.d4;
  var throwUninitializedPropertyAccessException = kotlin_kotlin.$_$.t5;
  var interpolate = kotlin_jabbah_base.$_$.r6;
  var numberToInt = kotlin_kotlin.$_$.r7;
  var numberRangeToNumber = kotlin_kotlin.$_$.o7;
  var to = kotlin_kotlin.$_$.tb;
  var mapOf = kotlin_kotlin.$_$.v3;
  var downTo = kotlin_kotlin.$_$.j8;
  var SystemSpeedEvent = kotlin_jabbah_base.$_$.x6;
  var ActionListener = kotlin_jabbah_base.$_$.e5;
  var NoSuchElementException_init_$Create$ = kotlin_kotlin.$_$.h1;
  var enumEntries = kotlin_kotlin.$_$.s5;
  var noWhenBranchMatchedException = kotlin_kotlin.$_$.pb;
  //endregion
  //region block: pre-declaration
  initMetadataForInterface(ExecutionControlOutlet, 'ExecutionControlOutlet');
  initMetadataForClass(AbstractExecutionError, 'AbstractExecutionError');
  initMetadataForInterface(PauseOrResumeAction, 'PauseOrResumeAction', VOID, VOID, [Action]);
  initMetadataForClass(PauseOrResumeActionImpl$inBreakpoint$$inlined$observable$1, VOID, VOID, ObservableProperty);
  initMetadataForClass(AbstractSchedulerAction, 'AbstractSchedulerAction', VOID, AbstractAction);
  initMetadataForClass(PauseOrResumeActionImpl, 'PauseOrResumeActionImpl', VOID, AbstractSchedulerAction, [PauseOrResumeAction]);
  initMetadataForInterface(SchedulerActions, 'SchedulerActions');
  initMetadataForCompanion(Companion);
  initMetadataForClass(ExecutionDepthAction, 'ExecutionDepthAction', VOID, AbstractSchedulerAction);
  initMetadataForClass(SingleStepModeAction, 'SingleStepModeAction', VOID, AbstractSchedulerAction);
  function get_waiting() {
    return this.n4v().equals(ActorState_Waiting_getInstance());
  }
  initMetadataForInterface(Actor, 'Actor');
  initMetadataForClass(ActorState, 'ActorState', VOID, Enum);
  initMetadataForClass(SimpleActorData, 'SimpleActorData', SimpleActorData);
  initMetadataForClass(ActorHandler, 'ActorHandler', VOID, InputEventHandlerAdapter);
  initMetadataForClass(sam$io_antarescircuit_jabbah_draw_drawable_ButtonAction$0, 'sam$io_antarescircuit_jabbah_draw_drawable_ButtonAction$0', VOID, VOID, [ButtonAction, FunctionAdapter]);
  function getExecutionTooltip(context) {
    return null;
  }
  function executionStarted(signalHandler) {
  }
  function executionStartDone(signalHandler) {
  }
  function executionStopped(signalHandler) {
  }
  initMetadataForInterface(ActorView, 'ActorView');
  initMetadataForClass(ActorDrawableButton, 'ActorDrawableButton', VOID, DrawableButton, [ActorView]);
  initMetadataForClass(ActorImpl, 'ActorImpl', ActorImpl, VOID, [Actor]);
  initMetadataForClass(Entry, 'Entry');
  initMetadataForClass(ActorSupport, 'ActorSupport');
  initMetadataForClass(ActorInteractionContext, 'ActorInteractionContext', VOID, InputEventContext);
  initMetadataForClass(ClickableActorInteractionHandlerAdapter, 'ClickableActorInteractionHandlerAdapter', ClickableActorInteractionHandlerAdapter, InputEventHandlerAdapter);
  initMetadataForClass(Handler, 'Handler', VOID, DrawableBagInputEventHandler);
  initMetadataForClass(ActorViewBag, 'ActorViewBag', ActorViewBag, DrawableBagImpl, [ActorView]);
  initMetadataForClass(Handler_0, 'Handler', VOID, DrawableBagInputEventHandler);
  initMetadataForClass(ActorViewContainer, 'ActorViewContainer', ActorViewContainer, DrawableContainerImpl, [ActorView]);
  initMetadataForClass(IssueCollectorEvent, 'IssueCollectorEvent');
  initMetadataForCompanion(Companion_0);
  initMetadataForClass(IssueCollector, 'IssueCollector', IssueCollector);
  initMetadataForObject(ExecutionModule, 'ExecutionModule', VOID, AbstractModule);
  initMetadataForClass(NoiseGeneratorHolder, 'NoiseGeneratorHolder');
  initMetadataForClass(AbstractNoiseGenerator, 'AbstractNoiseGenerator');
  initMetadataForClass(NoNoiseGenerator, 'NoNoiseGenerator', NoNoiseGenerator, AbstractNoiseGenerator);
  initMetadataForClass(RandomNoiseGenerator, 'RandomNoiseGenerator', RandomNoiseGenerator, AbstractNoiseGenerator);
  initMetadataForClass(ExecutionErrorHandlerImpl, 'ExecutionErrorHandlerImpl', ExecutionErrorHandlerImpl);
  initMetadataForClass(AbstractSchedulerTask, 'AbstractSchedulerTask');
  initMetadataForClass(ManualSchedulerTask, 'ManualSchedulerTask', ManualSchedulerTask, AbstractSchedulerTask);
  initMetadataForInterface(Scheduler, 'Scheduler');
  initMetadataForCompanion(Companion_1);
  initMetadataForClass(ExecutionStepResult, 'ExecutionStepResult');
  initMetadataForClass(BreakEvent, 'BreakEvent', BreakEvent);
  initMetadataForClass(SchedulerEvent, 'SchedulerEvent');
  initMetadataForClass(SchedulerSingleStepModeEvent, 'SchedulerSingleStepModeEvent');
  initMetadataForClass(ExecutionStoppedOnIssueEvent, 'ExecutionStoppedOnIssueEvent');
  initMetadataForClass(BreakpointEvent, 'BreakpointEvent');
  initMetadataForClass(SchedulerActivationStateEvent, 'SchedulerActivationStateEvent');
  initMetadataForClass(SchedulerActivationState, 'SchedulerActivationState', VOID, Enum);
  initMetadataForClass(SchedulerActivationStatePreparationEvent, 'SchedulerActivationStatePreparationEvent');
  initMetadataForCompanion(Companion_2);
  initMetadataForClass(Slot, 'Slot', VOID, VOID, [Comparable]);
  initMetadataForClass(Request, 'Request');
  initMetadataForClass(SchedulerImpl, 'SchedulerImpl', VOID, VOID, [Scheduler]);
  initMetadataForCompanion(Companion_3);
  initMetadataForClass(TimedSchedulerTask, 'TimedSchedulerTask', VOID, AbstractSchedulerTask, [ActionListener]);
  initMetadataForCompanion(Companion_4);
  initMetadataForClass(CurrentSystemSpeedCategory, 'CurrentSystemSpeedCategory');
  initMetadataForCompanion(Companion_5);
  initMetadataForClass(SystemSpeedCategory, 'SystemSpeedCategory', VOID, Enum);
  initMetadataForClass(SystemSpeedCategoryEvent, 'SystemSpeedCategoryEvent');
  //endregion
  function ExecutionControlOutlet() {
  }
  function getAge($this, executionTime) {
    return subtract(executionTime, $this.y4s());
  }
  function AbstractExecutionError(creationTime, gracePeriod) {
    gracePeriod = gracePeriod === VOID ? 0 : gracePeriod;
    this.w4s_1 = creationTime;
    this.x4s_1 = gracePeriod;
  }
  protoOf(AbstractExecutionError).y4s = function () {
    return this.w4s_1;
  };
  protoOf(AbstractExecutionError).z4s = function (executionTime) {
    return getAge(this, executionTime) > fromInt(this.x4s_1);
  };
  function PauseOrResumeAction() {
  }
  function get_PROP_PAUSE_OR_RESUME_ACTION_IN_BREAKPOINT() {
    return PROP_PAUSE_OR_RESUME_ACTION_IN_BREAKPOINT;
  }
  var PROP_PAUSE_OR_RESUME_ACTION_IN_BREAKPOINT;
  function _set_inBreakpoint__gvmw2n($this, _set____db54di) {
    var tmp = KMutableProperty1;
    var tmp_0 = PauseOrResumeActionImpl$_get_inBreakpoint_$ref_9loc0k_0();
    return $this.q4t_1.xf($this, getPropertyCallableRef('inBreakpoint', 1, tmp, tmp_0, PauseOrResumeActionImpl$_set_inBreakpoint_$ref_wcbgvs_0()), _set____db54di);
  }
  function updateSelected($this) {
    $this.pq($this.m4t_1.r4t() && $this.m4t_1.w4t().s4t_1.l1n_1);
    updateDescription($this);
  }
  function updateDescription($this) {
    var tmp;
    if ($this.selected) {
      var tmp_0;
      if ($this.inBreakpoint) {
        tmp_0 = Translations_getInstance().zm('execution.action.resumeFromBreakpoint.desc', []);
      } else {
        tmp_0 = Translations_getInstance().zm('execution.action.resume.desc', []);
      }
      tmp = tmp_0;
    } else {
      tmp = Translations_getInstance().zm('execution.action.pause.desc', []);
    }
    $this.jq(tmp);
  }
  function updateState($this) {
    $this.nq($this.m4t_1.r4t());
  }
  function updateInBreakpoint($this) {
    _set_inBreakpoint__gvmw2n($this, $this.m4t_1.x4t());
    updateDescription($this);
  }
  function PauseOrResumeActionImpl$pausedHandler$lambda(this$0) {
    return function (it) {
      var tmp;
      if (it.t1n_1 === this$0.m4t_1.w4t().s4t_1) {
        updateSelected(this$0);
        tmp = Unit_instance;
      }
      return Unit_instance;
    };
  }
  function PauseOrResumeActionImpl$schedulerActivationStateHandler$lambda(this$0) {
    return function (it) {
      var tmp;
      if (it.y4t_1 === this$0.m4t_1) {
        updateState(this$0);
        updateSelected(this$0);
        tmp = Unit_instance;
      }
      return Unit_instance;
    };
  }
  function PauseOrResumeActionImpl$breakpointHandler$lambda(this$0) {
    return function (it) {
      var tmp;
      if (it.z4t_1 === this$0.m4t_1) {
        updateInBreakpoint(this$0);
        tmp = Unit_instance;
      }
      return Unit_instance;
    };
  }
  function PauseOrResumeActionImpl$inBreakpoint$$inlined$observable$1($initialValue, this$0) {
    this.b4u_1 = this$0;
    ObservableProperty.call(this, $initialValue);
  }
  protoOf(PauseOrResumeActionImpl$inBreakpoint$$inlined$observable$1).ar = function (property, oldValue, newValue) {
    this.b4u_1.ir_1.lr('inBreakpoint', oldValue, newValue);
    return Unit_instance;
  };
  protoOf(PauseOrResumeActionImpl$inBreakpoint$$inlined$observable$1).tf = function (property, oldValue, newValue) {
    return this.ar(property, oldValue, newValue);
  };
  function PauseOrResumeActionImpl$_get_inBreakpoint_$ref_9loc0k() {
    return function (p0) {
      return p0.inBreakpoint;
    };
  }
  function PauseOrResumeActionImpl$_set_inBreakpoint_$ref_wcbgvs() {
    return function (p0, p1) {
      _set_inBreakpoint__gvmw2n(p0, p1);
      return Unit_instance;
    };
  }
  function PauseOrResumeActionImpl$_get_inBreakpoint_$ref_9loc0k_0() {
    return function (p0) {
      return p0.inBreakpoint;
    };
  }
  function PauseOrResumeActionImpl$_set_inBreakpoint_$ref_wcbgvs_0() {
    return function (p0, p1) {
      _set_inBreakpoint__gvmw2n(p0, p1);
      return Unit_instance;
    };
  }
  function PauseOrResumeActionImpl(scheduler, eventBus) {
    eventBus = eventBus === VOID ? BaseModule_getInstance().zo_1 : eventBus;
    AbstractSchedulerAction.call(this, 'execution.action.pause', eventBus);
    this.m4t_1 = scheduler;
    var tmp = this;
    tmp.n4t_1 = PauseOrResumeActionImpl$pausedHandler$lambda(this);
    var tmp_0 = this;
    tmp_0.o4t_1 = PauseOrResumeActionImpl$schedulerActivationStateHandler$lambda(this);
    var tmp_1 = this;
    tmp_1.p4t_1 = PauseOrResumeActionImpl$breakpointHandler$lambda(this);
    var tmp_2 = this;
    // Inline function 'kotlin.properties.Delegates.observable' call
    tmp_2.q4t_1 = new PauseOrResumeActionImpl$inBreakpoint$$inlined$observable$1(false, this);
    eventBus.j17(getKClass(SystemSpeedPauseEvent), this.n4t_1);
    eventBus.j17(getKClass(SchedulerActivationStateEvent), this.o4t_1);
    eventBus.j17(getKClass(BreakpointEvent), this.p4t_1);
    updateState(this);
    updateSelected(this);
    updateInBreakpoint(this);
  }
  protoOf(PauseOrResumeActionImpl).c4t = function () {
    var tmp = KMutableProperty1;
    var tmp_0 = PauseOrResumeActionImpl$_get_inBreakpoint_$ref_9loc0k();
    return this.q4t_1.vf(this, getPropertyCallableRef('inBreakpoint', 1, tmp, tmp_0, PauseOrResumeActionImpl$_set_inBreakpoint_$ref_wcbgvs()));
  };
  protoOf(PauseOrResumeActionImpl).dispose = function () {
    protoOf(AbstractSchedulerAction).dispose.call(this);
    this.k4u_1.l17(this.n4t_1);
    this.k4u_1.l17(this.o4t_1);
    this.k4u_1.l17(this.p4t_1);
  };
  protoOf(PauseOrResumeActionImpl).execute = function (event) {
    if (this.m4t_1.w4t().s4t_1.l1n_1) {
      this.m4t_1.w4t().s4t_1.p1n();
    } else {
      this.m4t_1.w4t().s4t_1.o1n();
    }
  };
  function SchedulerActions() {
  }
  function Companion() {
    this.m4u_1 = 'execution.scheduler.deepExecution';
  }
  var Companion_instance;
  function Companion_getInstance_1() {
    return Companion_instance;
  }
  function updateState_0($this) {
    $this.pq($this.w4u_1.y4u());
    $this.nq(!$this.w4u_1.r4t());
  }
  function ExecutionDepthAction$schedulerActivationStateHandler$lambda(this$0) {
    return function (it) {
      var tmp;
      if (it.y4t_1 === this$0.w4u_1) {
        updateState_0(this$0);
        tmp = Unit_instance;
      }
      return Unit_instance;
    };
  }
  function ExecutionDepthAction(scheduler, eventBus) {
    eventBus = eventBus === VOID ? BaseModule_getInstance().zo_1 : eventBus;
    AbstractSchedulerAction.call(this, 'execution.action.deepSimulation', eventBus);
    this.w4u_1 = scheduler;
    var tmp = this;
    tmp.x4u_1 = ExecutionDepthAction$schedulerActivationStateHandler$lambda(this);
    this.w4u_1.z4u(BaseModule_getInstance().yo_1.st('execution.scheduler.deepExecution', true));
    eventBus.j17(getKClass(SchedulerActivationStateEvent), this.x4u_1);
    updateState_0(this);
  }
  protoOf(ExecutionDepthAction).dispose = function () {
    protoOf(AbstractSchedulerAction).dispose.call(this);
    this.k4u_1.l17(this.x4u_1);
    BaseModule_getInstance().yo_1.ct('execution.scheduler.deepExecution', this.w4u_1.y4u());
  };
  protoOf(ExecutionDepthAction).execute = function (event) {
    this.w4u_1.z4u(this.selected);
  };
  function updateState_1($this) {
    $this.pq($this.j4v_1.l4v());
  }
  function SingleStepModeAction$schedulerSingleStepModeHandler$lambda(this$0) {
    return function (it) {
      updateState_1(this$0);
      return Unit_instance;
    };
  }
  function SingleStepModeAction(scheduler, eventBus) {
    eventBus = eventBus === VOID ? BaseModule_getInstance().zo_1 : eventBus;
    AbstractSchedulerAction.call(this, 'execution.action.singleStepMode', eventBus);
    this.j4v_1 = scheduler;
    var tmp = this;
    tmp.k4v_1 = SingleStepModeAction$schedulerSingleStepModeHandler$lambda(this);
    eventBus.j17(getKClass(SchedulerSingleStepModeEvent), this.k4v_1);
    updateState_1(this);
  }
  protoOf(SingleStepModeAction).dispose = function () {
    protoOf(AbstractSchedulerAction).dispose.call(this);
    this.k4u_1.l17(this.k4v_1);
  };
  protoOf(SingleStepModeAction).execute = function (event) {
    this.j4v_1.m4v(!this.j4v_1.l4v());
  };
  function AbstractSchedulerAction(name, eventBus) {
    AbstractAction_init_$Init$(name, VOID, VOID, this);
    this.k4u_1 = eventBus;
  }
  function Actor() {
  }
  var ActorState_NonExecuting_instance;
  var ActorState_Idle_instance;
  var ActorState_Waiting_instance;
  var ActorState_Acting_instance;
  var ActorState_entriesInitialized;
  function ActorState_initEntries() {
    if (ActorState_entriesInitialized)
      return Unit_instance;
    ActorState_entriesInitialized = true;
    ActorState_NonExecuting_instance = new ActorState('NonExecuting', 0);
    ActorState_Idle_instance = new ActorState('Idle', 1);
    ActorState_Waiting_instance = new ActorState('Waiting', 2);
    ActorState_Acting_instance = new ActorState('Acting', 3);
  }
  function ActorState(name, ordinal) {
    Enum.call(this, name, ordinal);
  }
  function ActorState_NonExecuting_getInstance() {
    ActorState_initEntries();
    return ActorState_NonExecuting_instance;
  }
  function ActorState_Idle_getInstance() {
    ActorState_initEntries();
    return ActorState_Idle_instance;
  }
  function ActorState_Waiting_getInstance() {
    ActorState_initEntries();
    return ActorState_Waiting_instance;
  }
  function ActorState_Acting_getInstance() {
    ActorState_initEntries();
    return ActorState_Acting_instance;
  }
  function SimpleActorData(data) {
    data = data === VOID ? null : data;
    this.c4w_1 = data;
  }
  protoOf(SimpleActorData).d4w = function () {
    return this.c4w_1;
  };
  function ActorDrawableButton_init_$Init$(location, tooltipKey, styleType, styleProvider, actorAction, renderer, round, $this) {
    tooltipKey = tooltipKey === VOID ? null : tooltipKey;
    styleType = styleType === VOID ? Companion_getInstance().m1x_1 : styleType;
    styleProvider = styleProvider === VOID ? DrawStyleModule_getInstance().g1x_1 : styleProvider;
    round = round === VOID ? false : round;
    ActorDrawableButton.call($this, location, tooltipKey, new StylableImpl(VOID, styleType, styleProvider), actorAction, renderer, round);
    return $this;
  }
  function ActorDrawableButton_init_$Create$(location, tooltipKey, styleType, styleProvider, actorAction, renderer, round) {
    return ActorDrawableButton_init_$Init$(location, tooltipKey, styleType, styleProvider, actorAction, renderer, round, objectCreate(protoOf(ActorDrawableButton)));
  }
  function ActorHandler($outer) {
    this.f4w_1 = $outer;
    InputEventHandlerAdapter.call(this);
  }
  protoOf(ActorHandler).g4w = function (context) {
    return this.f4w_1.s2e(context.d22_1) ? this : null;
  };
  protoOf(ActorHandler).j22 = function (context) {
    return this.g4w(context instanceof ActorInteractionContext ? context : THROW_CCE());
  };
  protoOf(ActorHandler).h4w = function (context) {
    if (this.f4w_1.p2e_1) {
      this.f4w_1.u4w_1.b2e(context);
    }
    return null;
  };
  protoOf(ActorHandler).k22 = function (context) {
    return this.h4w(context instanceof ActorInteractionContext ? context : THROW_CCE());
  };
  function sam$io_antarescircuit_jabbah_draw_drawable_ButtonAction$0(function_0) {
    this.w4w_1 = function_0;
  }
  protoOf(sam$io_antarescircuit_jabbah_draw_drawable_ButtonAction$0).b2e = function (context) {
    return this.w4w_1(context);
  };
  protoOf(sam$io_antarescircuit_jabbah_draw_drawable_ButtonAction$0).p2 = function () {
    return this.w4w_1;
  };
  protoOf(sam$io_antarescircuit_jabbah_draw_drawable_ButtonAction$0).equals = function (other) {
    var tmp;
    if (!(other == null) ? isInterface(other, ButtonAction) : false) {
      var tmp_0;
      if (!(other == null) ? isInterface(other, FunctionAdapter) : false) {
        tmp_0 = equals(this.p2(), other.p2());
      } else {
        tmp_0 = false;
      }
      tmp = tmp_0;
    } else {
      tmp = false;
    }
    return tmp;
  };
  protoOf(sam$io_antarescircuit_jabbah_draw_drawable_ButtonAction$0).hashCode = function () {
    return hashCode(this.p2());
  };
  function ActorDrawableButton$_init_$lambda_l5d9iy(it) {
    return Unit_instance;
  }
  function ActorDrawableButton(location, tooltipKey, stylable, actorAction, renderer, round) {
    location = location === VOID ? Companion_getInstance_0().g1a_1 : location;
    tooltipKey = tooltipKey === VOID ? null : tooltipKey;
    round = round === VOID ? false : round;
    var tmp = ActorDrawableButton$_init_$lambda_l5d9iy;
    DrawableButton.call(this, location, tooltipKey, stylable, new sam$io_antarescircuit_jabbah_draw_drawable_ButtonAction$0(tmp), renderer, VOID, round);
    this.u4w_1 = actorAction;
    this.v4w_1 = this.x4w();
  }
  protoOf(ActorDrawableButton).y4w = function (context) {
    return this.v4w_1;
  };
  protoOf(ActorDrawableButton).z4w = function (context) {
    return this.y1z(context);
  };
  protoOf(ActorDrawableButton).x4w = function () {
    return new ActorHandler(this);
  };
  function _get_actorSupport__ng3drl($this) {
    var tmp0 = $this.d4x_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('actorSupport', 1, tmp, ActorImpl$_get_actorSupport_$ref_7khzjl(), null);
    return tmp0.j2();
  }
  function ActorImpl$actorSupport$delegate$lambda(this$0) {
    return function () {
      return new ActorSupport(this$0);
    };
  }
  function ActorImpl$_get_actorSupport_$ref_7khzjl() {
    return function (p0) {
      return _get_actorSupport__ng3drl(p0);
    };
  }
  function ActorImpl(id, propagationDelay) {
    id = id === VOID ? 0 : id;
    propagationDelay = propagationDelay === VOID ? 0n : propagationDelay;
    this.c4x_1 = id;
    var tmp = this;
    tmp.d4x_1 = lazy(ActorImpl$actorSupport$delegate$lambda(this));
    this.e4x_1 = false;
    this.f4x_1 = ActorState_NonExecuting_getInstance();
    this.g4x_1 = new LongValueImpl(propagationDelay);
    this.h4x_1 = null;
  }
  protoOf(ActorImpl).av = function () {
    return this.c4x_1;
  };
  protoOf(ActorImpl).r4v = function (value) {
    // Inline function 'kotlin.require' call
    if (!(value.j2() >= 0n)) {
      var message = 'Propagation delay must be greater than 0';
      throw IllegalArgumentException_init_$Create$(toString(message));
    }
    this.g4x_1 = value;
  };
  protoOf(ActorImpl).s4v = function () {
    return this.g4x_1;
  };
  protoOf(ActorImpl).p4v = function (_set____db54di) {
    this.h4x_1 = _set____db54di;
  };
  protoOf(ActorImpl).q4v = function () {
    return this.h4x_1;
  };
  protoOf(ActorImpl).n4v = function () {
    return this.f4x_1;
  };
  protoOf(ActorImpl).t4v = function () {
    return _get_actorSupport__ng3drl(this).k4x();
  };
  protoOf(ActorImpl).u4v = function (l) {
    _get_actorSupport__ng3drl(this).l4x(l);
  };
  protoOf(ActorImpl).v4v = function (l) {
    _get_actorSupport__ng3drl(this).m4x(l);
  };
  protoOf(ActorImpl).w4v = function (signalHandler) {
    this.e4x_1 = true;
  };
  protoOf(ActorImpl).x4v = function (signalHandler) {
    this.f4x_1 = ActorState_Idle_getInstance();
    this.p4v(null);
  };
  protoOf(ActorImpl).y4v = function (signalHandler, data) {
    this.f4x_1 = ActorState_Acting_getInstance();
    _get_actorSupport__ng3drl(this).n4x(signalHandler, data);
  };
  protoOf(ActorImpl).z4v = function (signalHandler, l, data) {
    _get_actorSupport__ng3drl(this).z4v(signalHandler, l, data);
  };
  protoOf(ActorImpl).a4w = function (signalHandler, data) {
    this.f4x_1 = ActorState_Idle_getInstance();
  };
  protoOf(ActorImpl).b4w = function (signalHandler) {
    this.p4v(null);
    this.f4x_1 = ActorState_NonExecuting_getInstance();
    this.e4x_1 = false;
  };
  protoOf(ActorImpl).o4x = function (signalHandler, delay, data) {
    this.f4x_1 = ActorState_Waiting_getInstance();
    _get_actorSupport__ng3drl(this).o4x(signalHandler, delay, data);
  };
  function ensureEntry($this, l) {
    if ($this.j4x_1 == null) {
      var tmp = $this;
      // Inline function 'kotlin.collections.mutableMapOf' call
      tmp.j4x_1 = LinkedHashMap_init_$Create$();
    }
    // Inline function 'kotlin.collections.getOrPut' call
    var this_0 = ensureNotNull($this.j4x_1);
    var value = this_0.g2(l);
    var tmp_0;
    if (value == null) {
      var answer = new Entry(l);
      this_0.y1(l, answer);
      tmp_0 = answer;
    } else {
      tmp_0 = value;
    }
    return tmp_0;
  }
  function allDone($this) {
    if ($this.j4x_1 == null) {
      return true;
    }
    var tmp0 = ensureNotNull($this.j4x_1).c2();
    var tmp$ret$0;
    $l$block_0: {
      // Inline function 'kotlin.collections.all' call
      var tmp;
      if (isInterface(tmp0, Collection)) {
        tmp = tmp0.m();
      } else {
        tmp = false;
      }
      if (tmp) {
        tmp$ret$0 = true;
        break $l$block_0;
      }
      var _iterator__ex2g4s = tmp0.i();
      while (_iterator__ex2g4s.j()) {
        var element = _iterator__ex2g4s.k();
        if (!!element.q4x_1) {
          tmp$ret$0 = false;
          break $l$block_0;
        }
      }
      tmp$ret$0 = true;
    }
    return tmp$ret$0;
  }
  function notifyActingRequested($this, signalHandler, data) {
    var tmp0_safe_receiver = $this.j4x_1;
    if (tmp0_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.collections.forEach' call
      // Inline function 'kotlin.collections.iterator' call
      var _iterator__ex2g4s = tmp0_safe_receiver.d2().i();
      while (_iterator__ex2g4s.j()) {
        var element = _iterator__ex2g4s.k();
        element.j2().q4x_1 = false;
        element.i2().r4x($this.i4x_1, signalHandler, data);
      }
    }
  }
  function Entry(listener, isPending) {
    isPending = isPending === VOID ? false : isPending;
    this.p4x_1 = listener;
    this.q4x_1 = isPending;
  }
  protoOf(Entry).toString = function () {
    return 'Entry(listener=' + toString(this.p4x_1) + ', isPending=' + this.q4x_1 + ')';
  };
  protoOf(Entry).hashCode = function () {
    var result = hashCode(this.p4x_1);
    result = imul(result, 31) + getBooleanHashCode(this.q4x_1) | 0;
    return result;
  };
  protoOf(Entry).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof Entry))
      return false;
    if (!equals(this.p4x_1, other.p4x_1))
      return false;
    if (!(this.q4x_1 === other.q4x_1))
      return false;
    return true;
  };
  function ActorSupport(actor) {
    this.i4x_1 = actor;
    this.j4x_1 = null;
  }
  protoOf(ActorSupport).k4x = function () {
    var tmp;
    if (!(this.j4x_1 == null)) {
      // Inline function 'kotlin.collections.isNotEmpty' call
      tmp = !ensureNotNull(this.j4x_1).m();
    } else {
      tmp = false;
    }
    return tmp;
  };
  protoOf(ActorSupport).l4x = function (l) {
    ensureEntry(this, l);
  };
  protoOf(ActorSupport).m4x = function (l) {
    var tmp0_safe_receiver = this.j4x_1;
    if (tmp0_safe_receiver == null)
      null;
    else
      tmp0_safe_receiver.z1(l);
  };
  protoOf(ActorSupport).o4x = function (signalHandler, delay, data) {
    signalHandler.s4x(this.i4x_1, delay, data);
    notifyActingRequested(this, signalHandler, data);
  };
  protoOf(ActorSupport).n4x = function (signalHandler, data) {
    var tmp;
    if (!(this.j4x_1 == null)) {
      // Inline function 'kotlin.collections.isNotEmpty' call
      tmp = !ensureNotNull(this.j4x_1).m();
    } else {
      tmp = false;
    }
    if (tmp) {
      var tmp0_safe_receiver = this.j4x_1;
      if (tmp0_safe_receiver == null)
        null;
      else {
        // Inline function 'kotlin.collections.forEach' call
        // Inline function 'kotlin.collections.iterator' call
        var _iterator__ex2g4s = tmp0_safe_receiver.d2().i();
        while (_iterator__ex2g4s.j()) {
          var element = _iterator__ex2g4s.k();
          element.j2().q4x_1 = true;
          element.i2().u4x(this.i4x_1, signalHandler, data);
        }
      }
    } else {
      signalHandler.t4x(this.i4x_1, data);
    }
  };
  protoOf(ActorSupport).z4v = function (signalHandler, l, data) {
    if (!(this.j4x_1 == null)) {
      ensureEntry(this, l).q4x_1 = false;
    }
    if (allDone(this)) {
      signalHandler.t4x(this.i4x_1, data);
    }
  };
  function ActorInteractionContext(signalHandler, view, mouseEvent, keyEvent, x, y) {
    mouseEvent = mouseEvent === VOID ? null : mouseEvent;
    keyEvent = keyEvent === VOID ? null : keyEvent;
    x = x === VOID ? 0.0 : x;
    y = y === VOID ? 0.0 : y;
    InputEventContext.call(this, view, mouseEvent, keyEvent, x, y);
    this.c4y_1 = signalHandler;
  }
  protoOf(ActorInteractionContext).f22 = function (x, y) {
    return new ActorInteractionContext(this.c4y_1, this.x21_1, this.y21_1, this.z21_1, x, y);
  };
  function ClickableActorInteractionHandlerAdapter() {
    InputEventHandlerAdapter.call(this);
  }
  protoOf(ClickableActorInteractionHandlerAdapter).g4w = function (context) {
    context.x21_1.v1x(Cursor_CLICK_getInstance());
    return null;
  };
  protoOf(ClickableActorInteractionHandlerAdapter).j22 = function (context) {
    return this.g4w(context instanceof ActorInteractionContext ? context : THROW_CCE());
  };
  function ActorView() {
  }
  function Handler($outer) {
    this.h4y_1 = $outer;
    DrawableBagInputEventHandler.call(this);
  }
  protoOf(Handler).t20 = function (location) {
    var tmp = this.h4y_1.o4y(location);
    return (tmp == null ? true : isInterface(tmp, Drawable)) ? tmp : THROW_CCE();
  };
  protoOf(Handler).p4y = function (drawable, context) {
    var tmp;
    if (isInterface(drawable, ActorView)) {
      tmp = drawable.y4w(context);
    } else {
      tmp = protoOf(DrawableBagInputEventHandler).b28.call(this, drawable, context);
    }
    return tmp;
  };
  protoOf(Handler).b28 = function (drawable, context) {
    return this.p4y(drawable, context instanceof ActorInteractionContext ? context : THROW_CCE());
  };
  function ActorViewBag$getActorViewAt$lambda(it) {
    return isInterface(it, ActorView);
  }
  function ActorViewBag(location, useLocation) {
    location = location === VOID ? Companion_getInstance_0().g1a_1 : location;
    useLocation = useLocation === VOID ? false : useLocation;
    DrawableBagImpl.call(this, location, useLocation);
    this.m4y_1 = useLocation;
    this.n4y_1 = this.q4y();
  }
  protoOf(ActorViewBag).d20 = function () {
    return this.m4y_1;
  };
  protoOf(ActorViewBag).y4w = function (context) {
    this.n4y_1.h28(this);
    return this.n4y_1;
  };
  protoOf(ActorViewBag).z4w = function (context) {
    var p = context.d22_1;
    if (this.d20()) {
      var tmp0_safe_receiver = this.o4y(p);
      return tmp0_safe_receiver == null ? null : tmp0_safe_receiver.z4w(context.e22(p.t1g(this.hw())));
    }
    var tmp1_safe_receiver = this.o4y(p);
    return tmp1_safe_receiver == null ? null : tmp1_safe_receiver.z4w(context);
  };
  protoOf(ActorViewBag).a4x = function (signalHandler) {
  };
  protoOf(ActorViewBag).b4w = function (signalHandler) {
  };
  protoOf(ActorViewBag).q4y = function () {
    return new Handler(this);
  };
  protoOf(ActorViewBag).o4y = function (pos) {
    var tmp = this.p20(pos.in_1, pos.jn_1, ActorViewBag$getActorViewAt$lambda);
    return (tmp == null ? true : isInterface(tmp, ActorView)) ? tmp : THROW_CCE();
  };
  function getActorViewAt($this, pos) {
    var tmp = $this.p20(pos.in_1, pos.jn_1, ActorViewContainer$getActorViewAt$lambda);
    return (tmp == null ? true : isInterface(tmp, ActorView)) ? tmp : THROW_CCE();
  }
  function Handler_0($outer) {
    this.u4y_1 = $outer;
    DrawableBagInputEventHandler.call(this);
  }
  protoOf(Handler_0).t20 = function (location) {
    var tmp = getActorViewAt(this.u4y_1, location);
    return (tmp == null ? true : isInterface(tmp, Drawable)) ? tmp : THROW_CCE();
  };
  protoOf(Handler_0).p4y = function (drawable, context) {
    var tmp;
    if (isInterface(drawable, ActorView)) {
      tmp = drawable.y4w(context);
    } else {
      tmp = protoOf(DrawableBagInputEventHandler).b28.call(this, drawable, context);
    }
    return tmp;
  };
  protoOf(Handler_0).b28 = function (drawable, context) {
    return this.p4y(drawable, context instanceof ActorInteractionContext ? context : THROW_CCE());
  };
  function ActorViewContainer$getActorViewAt$lambda(it) {
    return isInterface(it, ActorView);
  }
  function ActorViewContainer(location, useLocation) {
    location = location === VOID ? Companion_getInstance_0().g1a_1 : location;
    useLocation = useLocation === VOID ? false : useLocation;
    DrawableContainerImpl.call(this, location, useLocation);
    this.i4z_1 = new Handler_0(this);
  }
  protoOf(ActorViewContainer).y4w = function (context) {
    this.i4z_1.h28(this);
    return this.i4z_1;
  };
  protoOf(ActorViewContainer).z4w = function (context) {
    var p = context.d22_1;
    if (this.d20()) {
      var tmp0_safe_receiver = getActorViewAt(this, p);
      return tmp0_safe_receiver == null ? null : tmp0_safe_receiver.z4w(context.e22(p.t1g(this.hw())));
    }
    var tmp1_safe_receiver = getActorViewAt(this, p);
    return tmp1_safe_receiver == null ? null : tmp1_safe_receiver.z4w(context);
  };
  protoOf(ActorViewContainer).a4x = function (signalHandler) {
    // Inline function 'kotlin.collections.filterIsInstance' call
    var tmp0 = this.e20();
    // Inline function 'kotlin.collections.filterIsInstanceTo' call
    var destination = ArrayList_init_$Create$();
    var _iterator__ex2g4s = tmp0.i();
    while (_iterator__ex2g4s.j()) {
      var element = _iterator__ex2g4s.k();
      if (!(element == null) ? isInterface(element, ActorView) : false) {
        destination.h(element);
      }
    }
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s_0 = destination.i();
    while (_iterator__ex2g4s_0.j()) {
      var element_0 = _iterator__ex2g4s_0.k();
      element_0.a4x(signalHandler);
    }
  };
  protoOf(ActorViewContainer).b4w = function (signalHandler) {
    // Inline function 'kotlin.collections.filterIsInstance' call
    var tmp0 = this.e20();
    // Inline function 'kotlin.collections.filterIsInstanceTo' call
    var destination = ArrayList_init_$Create$();
    var _iterator__ex2g4s = tmp0.i();
    while (_iterator__ex2g4s.j()) {
      var element = _iterator__ex2g4s.k();
      if (!(element == null) ? isInterface(element, ActorView) : false) {
        destination.h(element);
      }
    }
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s_0 = destination.i();
    while (_iterator__ex2g4s_0.j()) {
      var element_0 = _iterator__ex2g4s_0.k();
      element_0.b4w(signalHandler);
    }
  };
  function IssueCollectorEvent(issueCollector, issue) {
    this.j4z_1 = issueCollector;
    this.k4z_1 = issue;
  }
  protoOf(IssueCollectorEvent).toString = function () {
    return 'IssueCollectorEvent(issueCollector=' + toString(this.j4z_1) + ', issue=' + toString_0(this.k4z_1) + ')';
  };
  protoOf(IssueCollectorEvent).hashCode = function () {
    var result = hashCode(this.j4z_1);
    result = imul(result, 31) + (this.k4z_1 == null ? 0 : hashCode(this.k4z_1)) | 0;
    return result;
  };
  protoOf(IssueCollectorEvent).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof IssueCollectorEvent))
      return false;
    if (!equals(this.j4z_1, other.j4z_1))
      return false;
    if (!equals(this.k4z_1, other.k4z_1))
      return false;
    return true;
  };
  function Companion_0() {
    this.l4z_1 = 'execution.issues.maxCount';
  }
  var Companion_instance_0;
  function Companion_getInstance_2() {
    return Companion_instance_0;
  }
  function _get_maxIssuesCount__godqyi($this) {
    return BaseModule_getInstance().xo_1.it('execution.issues.maxCount');
  }
  function hasIssueWithSeverity($this, severity) {
    var tmp0 = $this.p4z();
    var tmp$ret$0;
    $l$block_0: {
      // Inline function 'kotlin.collections.any' call
      var tmp;
      if (isInterface(tmp0, Collection)) {
        tmp = tmp0.m();
      } else {
        tmp = false;
      }
      if (tmp) {
        tmp$ret$0 = false;
        break $l$block_0;
      }
      var _iterator__ex2g4s = tmp0.i();
      while (_iterator__ex2g4s.j()) {
        var element = _iterator__ex2g4s.k();
        if (element.qs().equals(severity)) {
          tmp$ret$0 = true;
          break $l$block_0;
        }
      }
      tmp$ret$0 = false;
    }
    return tmp$ret$0;
  }
  function handleNewIssue($this, issue) {
    if ($this.o() < _get_maxIssuesCount__godqyi($this)) {
      $this.n4z_1.h(issue);
      updateMaximumSeverity($this);
    }
    $this.m4z_1.eu(new IssueCollectorEvent($this, issue));
  }
  function updateMaximumSeverity($this) {
    $this.o4z_1 = $this.p4z().m() ? null : hasIssueWithSeverity($this, IssueSeverity_Error_getInstance()) ? IssueSeverity_Error_getInstance() : IssueSeverity_Warning_getInstance();
  }
  function IssueCollector$lambda(this$0) {
    return function (it) {
      var tmp;
      if (it.y4t_1.r4t()) {
        this$0.a2();
        tmp = Unit_instance;
      }
      return Unit_instance;
    };
  }
  function IssueCollector$lambda_0(this$0) {
    return function (it) {
      handleNewIssue(this$0, it);
      return Unit_instance;
    };
  }
  function IssueCollector(clearOnExecutionStart, eventBus) {
    clearOnExecutionStart = clearOnExecutionStart === VOID ? true : clearOnExecutionStart;
    eventBus = eventBus === VOID ? BaseModule_getInstance().zo_1 : eventBus;
    this.m4z_1 = eventBus;
    if (clearOnExecutionStart) {
      var tmp = getKClass(SchedulerActivationStateEvent);
      this.m4z_1.j17(tmp, IssueCollector$lambda(this));
    }
    var tmp_0 = getKClass(IssueImpl);
    this.m4z_1.j17(tmp_0, IssueCollector$lambda_0(this));
    var tmp_1 = this;
    // Inline function 'kotlin.collections.mutableListOf' call
    tmp_1.n4z_1 = ArrayList_init_$Create$();
    this.o4z_1 = null;
  }
  protoOf(IssueCollector).o = function () {
    return this.n4z_1.o();
  };
  protoOf(IssueCollector).p4z = function () {
    return this.n4z_1;
  };
  protoOf(IssueCollector).a2 = function () {
    this.n4z_1.a2();
    updateMaximumSeverity(this);
    this.m4z_1.eu(new IssueCollectorEvent(this, null));
  };
  function fillProperties($this, properties) {
    properties.ct('execution.scheduler.eventSystemSpeedLimit', SystemSpeedCategory_Observe_getInstance().s4z_1);
    properties.ct('execution.issues.maxCount', 100);
    properties.ct('TimedSchedulerTask.slowDownFactor', 4.0);
  }
  function ExecutionModule$noiseGeneratorHolder$delegate$lambda() {
    return new NoiseGeneratorHolder(ExecutionModule_getInstance().v4z_1);
  }
  function ExecutionModule$_get_noiseGeneratorHolder_$ref_4lmy23() {
    return function (p0) {
      return p0.a50();
    };
  }
  function ExecutionModule$schedulerTaskFactory$lambda(speedCategory, eventBus) {
    return new TimedSchedulerTask(speedCategory, VOID, eventBus);
  }
  function ExecutionModule() {
    ExecutionModule_instance = this;
    AbstractModule.call(this);
    this.v4z_1 = new NoNoiseGenerator();
    this.w4z_1 = new RandomNoiseGenerator();
    var tmp = this;
    tmp.x4z_1 = lazy(ExecutionModule$noiseGeneratorHolder$delegate$lambda);
    var tmp_0 = this;
    tmp_0.y4z_1 = ExecutionModule$schedulerTaskFactory$lambda;
    var tmp_1 = this;
    var tmp0_eventBus = BaseModule_getInstance().zo_1;
    tmp_1.z4z_1 = new IssueCollector(true, tmp0_eventBus);
  }
  protoOf(ExecutionModule).a50 = function () {
    var tmp0 = this.x4z_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('noiseGeneratorHolder', 1, tmp, ExecutionModule$_get_noiseGeneratorHolder_$ref_4lmy23(), null);
    return tmp0.j2();
  };
  protoOf(ExecutionModule).ro = function () {
    BaseModule_getInstance().to();
    fillProperties(this, BaseModule_getInstance().xo_1);
    Translations_getInstance().um('jabbah-execution');
  };
  var ExecutionModule_instance;
  function ExecutionModule_getInstance() {
    if (ExecutionModule_instance == null)
      new ExecutionModule();
    return ExecutionModule_instance;
  }
  function NoiseGeneratorHolder(current, eventBus) {
    eventBus = eventBus === VOID ? BaseModule_getInstance().zo_1 : eventBus;
    this.b50_1 = eventBus;
    this.c50_1 = current;
  }
  function NoNoiseGenerator() {
    AbstractNoiseGenerator.call(this, 'execution.noiseGenerator.none');
  }
  protoOf(NoNoiseGenerator).e50 = function (bound) {
    return 0;
  };
  function AbstractNoiseGenerator(nameKey) {
    this.f50_1 = nameKey;
  }
  function RandomNoiseGenerator() {
    AbstractNoiseGenerator.call(this, 'execution.noiseGenerator.random');
  }
  protoOf(RandomNoiseGenerator).e50 = function (bound) {
    return Default_getInstance().ag(0, bound);
  };
  function ExecutionErrorHandlerImpl() {
    var tmp = this;
    // Inline function 'kotlin.collections.mutableListOf' call
    tmp.h50_1 = ArrayList_init_$Create$();
  }
  protoOf(ExecutionErrorHandlerImpl).i50 = function (error) {
    this.h50_1.h(error);
  };
  protoOf(ExecutionErrorHandlerImpl).bu = function () {
    this.h50_1.a2();
  };
  protoOf(ExecutionErrorHandlerImpl).j50 = function (force, signalHandler) {
    if (this.h50_1.m()) {
      return Unit_instance;
    }
    // Inline function 'kotlin.collections.mutableListOf' call
    var toRemove = ArrayList_init_$Create$();
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = this.h50_1.i();
    while (_iterator__ex2g4s.j()) {
      var element = _iterator__ex2g4s.k();
      if (element.b4t(force, signalHandler)) {
        toRemove.h(element);
      }
    }
    this.h50_1.c3(toRemove);
  };
  function ManualSchedulerTask() {
    AbstractSchedulerTask.call(this, 'execution.task.manual');
  }
  protoOf(ManualSchedulerTask).n50 = function (scheduler) {
    this.m50_1 = scheduler;
  };
  protoOf(ManualSchedulerTask).o50 = function () {
  };
  protoOf(ManualSchedulerTask).wp = function () {
  };
  function Scheduler() {
  }
  function Companion_1() {
    Companion_instance_1 = this;
    this.x50_1 = new ExecutionStepResult(false, false);
    this.y50_1 = new ExecutionStepResult(false, true);
    this.z50_1 = new ExecutionStepResult(true, false);
  }
  var Companion_instance_1;
  function Companion_getInstance_3() {
    if (Companion_instance_1 == null)
      new Companion_1();
    return Companion_instance_1;
  }
  function ExecutionStepResult(recalculated, breakpoint) {
    Companion_getInstance_3();
    this.a51_1 = recalculated;
    this.b51_1 = breakpoint;
  }
  protoOf(ExecutionStepResult).toString = function () {
    return 'ExecutionStepResult(recalculated=' + this.a51_1 + ', breakpoint=' + this.b51_1 + ')';
  };
  protoOf(ExecutionStepResult).hashCode = function () {
    var result = getBooleanHashCode(this.a51_1);
    result = imul(result, 31) + getBooleanHashCode(this.b51_1) | 0;
    return result;
  };
  protoOf(ExecutionStepResult).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof ExecutionStepResult))
      return false;
    if (!(this.a51_1 === other.a51_1))
      return false;
    if (!(this.b51_1 === other.b51_1))
      return false;
    return true;
  };
  function BreakEvent() {
  }
  function SchedulerEvent(scheduler, source) {
    this.c51_1 = scheduler;
    this.d51_1 = source;
  }
  function SchedulerSingleStepModeEvent(scheduler) {
    this.e51_1 = scheduler;
  }
  protoOf(SchedulerSingleStepModeEvent).toString = function () {
    return 'SchedulerSingleStepModeEvent(scheduler=' + toString(this.e51_1) + ')';
  };
  protoOf(SchedulerSingleStepModeEvent).hashCode = function () {
    return hashCode(this.e51_1);
  };
  protoOf(SchedulerSingleStepModeEvent).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof SchedulerSingleStepModeEvent))
      return false;
    if (!equals(this.e51_1, other.e51_1))
      return false;
    return true;
  };
  function ExecutionStoppedOnIssueEvent(issue, scheduler) {
    this.f51_1 = issue;
    this.g51_1 = scheduler;
  }
  protoOf(ExecutionStoppedOnIssueEvent).toString = function () {
    return 'ExecutionStoppedOnIssueEvent(issue=' + toString(this.f51_1) + ', scheduler=' + toString(this.g51_1) + ')';
  };
  protoOf(ExecutionStoppedOnIssueEvent).hashCode = function () {
    var result = hashCode(this.f51_1);
    result = imul(result, 31) + hashCode(this.g51_1) | 0;
    return result;
  };
  protoOf(ExecutionStoppedOnIssueEvent).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof ExecutionStoppedOnIssueEvent))
      return false;
    if (!equals(this.f51_1, other.f51_1))
      return false;
    if (!equals(this.g51_1, other.g51_1))
      return false;
    return true;
  };
  function BreakpointEvent(scheduler) {
    this.z4t_1 = scheduler;
  }
  protoOf(BreakpointEvent).toString = function () {
    return 'BreakpointEvent(scheduler=' + toString(this.z4t_1) + ')';
  };
  protoOf(BreakpointEvent).hashCode = function () {
    return hashCode(this.z4t_1);
  };
  protoOf(BreakpointEvent).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof BreakpointEvent))
      return false;
    if (!equals(this.z4t_1, other.z4t_1))
      return false;
    return true;
  };
  function SchedulerActivationStateEvent(scheduler) {
    this.y4t_1 = scheduler;
  }
  protoOf(SchedulerActivationStateEvent).toString = function () {
    return 'SchedulerActivationStateEvent(scheduler=' + toString(this.y4t_1) + ')';
  };
  protoOf(SchedulerActivationStateEvent).hashCode = function () {
    return hashCode(this.y4t_1);
  };
  protoOf(SchedulerActivationStateEvent).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof SchedulerActivationStateEvent))
      return false;
    if (!equals(this.y4t_1, other.y4t_1))
      return false;
    return true;
  };
  var SchedulerActivationState_ACTIVE_instance;
  var SchedulerActivationState_PASSIVE_instance;
  var SchedulerActivationState_entriesInitialized;
  function SchedulerActivationState_initEntries() {
    if (SchedulerActivationState_entriesInitialized)
      return Unit_instance;
    SchedulerActivationState_entriesInitialized = true;
    SchedulerActivationState_ACTIVE_instance = new SchedulerActivationState('ACTIVE', 0);
    SchedulerActivationState_PASSIVE_instance = new SchedulerActivationState('PASSIVE', 1);
  }
  function SchedulerActivationState(name, ordinal) {
    Enum.call(this, name, ordinal);
  }
  function SchedulerActivationStatePreparationEvent(scheduler) {
    this.h51_1 = scheduler;
  }
  protoOf(SchedulerActivationStatePreparationEvent).toString = function () {
    return 'SchedulerActivationStatePreparationEvent(scheduler=' + toString(this.h51_1) + ')';
  };
  protoOf(SchedulerActivationStatePreparationEvent).hashCode = function () {
    return hashCode(this.h51_1);
  };
  protoOf(SchedulerActivationStatePreparationEvent).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof SchedulerActivationStatePreparationEvent))
      return false;
    if (!equals(this.h51_1, other.h51_1))
      return false;
    return true;
  };
  function SchedulerActivationState_ACTIVE_getInstance() {
    SchedulerActivationState_initEntries();
    return SchedulerActivationState_ACTIVE_instance;
  }
  function SchedulerActivationState_PASSIVE_getInstance() {
    SchedulerActivationState_initEntries();
    return SchedulerActivationState_PASSIVE_instance;
  }
  function _get_LOG__e5r759($this) {
    var tmp0 = $this.i51_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('LOG', 1, tmp, SchedulerImpl$Companion$_get_LOG_$ref_vpagyj(), null);
    return tmp0.j2();
  }
  function SchedulerImpl$Companion$_get_LOG_$ref_vpagyj() {
    return function (p0) {
      return _get_LOG__e5r759(p0);
    };
  }
  function addRequest($this, request) {
    var tmp0 = $this.n51_1;
    // Inline function 'kotlin.collections.set' call
    var key = request.p51_1;
    tmp0.y1(key, request);
  }
  function SchedulerImpl$Slot$actingDone$lambda() {
    return 'Actor is done ';
  }
  function SchedulerImpl$Request$act$lambda() {
    return 'Actor starts acting';
  }
  function Companion_2() {
    Companion_instance_2 = this;
    this.i51_1 = logger(getKClass(SchedulerImpl));
    this.j51_1 = 'execution.scheduler.stopOnIssue';
    this.k51_1 = 'execution.scheduler.enableSoftBreakpoints';
    this.l51_1 = 'execution.scheduler.enableSimulationTimeStatusBar';
  }
  var Companion_instance_2;
  function Companion_getInstance_4() {
    if (Companion_instance_2 == null)
      new Companion_2();
    return Companion_instance_2;
  }
  function _get_displaySimulationTime__8co2bf($this) {
    return $this.k52_1 || ($this.p52_1 && $this.t51_1.v4t_1.o2(SystemSpeedCategory_Observe_getInstance()) >= 0);
  }
  function _set_isInBreakpoint__1hzh2h($this, value) {
    if ($this.m52_1 === value) {
      return Unit_instance;
    }
    $this.m52_1 = value;
    if ($this.m52_1) {
      $this.l52_1 = false;
      $this.t51_1.s4t_1.o1n();
    }
    _get_LOG__e5r759(Companion_getInstance_4()).ol('isInBreakpoint is ' + $this.m52_1);
    $this.v51_1.eu(new BreakpointEvent($this));
  }
  function requestActingImpl($this, actor, delay, data) {
    if (!$this.r4t()) {
      return Unit_instance;
    }
    if (_get_LOG__e5r759(Companion_getInstance_4()).ql()) {
      $this.w50(actor, SchedulerImpl$requestActingImpl$lambda(delay));
    }
    var tmp0 = add($this.v50(), delay);
    // Inline function 'kotlin.Long.plus' call
    var other = $this.w51_1.c50_1.e50(10);
    var schedulingTime = add(tmp0, fromInt(other));
    var slot = getSlotAt($this, schedulingTime);
    if (!(slot == null)) {
      slot.u52(actor, data);
    } else {
      addSlot($this, new Slot($this, schedulingTime, actor, data));
      postSchedulerStateEvent($this);
    }
    startTaskIfNeeded($this);
  }
  function handlePaused($this) {
    $this.x51_1.wp();
    $this.d52_1 = $this.u51_1.mp();
  }
  function handleResumed($this) {
    if (!$this.r4t()) {
      return Unit_instance;
    }
    $this.e52_1 = add($this.e52_1, subtract($this.u51_1.mp(), $this.d52_1));
    executeImpl($this, true);
    $this.n52_1 = false;
    _set_isInBreakpoint__1hzh2h($this, false);
    startTaskIfNeeded($this);
  }
  function postSchedulerEvent($this, actor) {
    if ($this.r4t()) {
      $this.v52(actor);
    }
  }
  function postSchedulerStateEvent($this) {
    if (_get_displaySimulationTime__8co2bf($this)) {
      publishSimulationTimeStatus($this);
    }
  }
  function publishSimulationTimeStatus($this) {
    Status_getInstance().du(StatusType_Small_getInstance(), StringUtils_getInstance().ou($this.b52_1) + ' ns');
  }
  function clearSimulationTimeStatus($this) {
    Status_getInstance().du(StatusType_Small_getInstance(), null);
  }
  function addSlot($this, slot) {
    if (_get_LOG__e5r759(Companion_getInstance_4()).ql()) {
      _get_LOG__e5r759(Companion_getInstance_4()).ol('Add slot ' + StringUtils_getInstance().ou(slot.m51_1));
    }
    $this.z51_1.qv(slot);
  }
  function removeSlot($this, slot) {
    if (!$this.z51_1.ov()) {
      if (_get_LOG__e5r759(Companion_getInstance_4()).ql()) {
        _get_LOG__e5r759(Companion_getInstance_4()).ol('Remove slot ' + StringUtils_getInstance().ou(slot.m51_1));
      }
      $this.z51_1.rv(slot);
      if ($this.z51_1.ov()) {
        $this.x51_1.wp();
      }
    }
    $this.y51_1.j50($this.z51_1.ov(), $this);
  }
  function getSlotAt($this, relativeTime) {
    // Inline function 'kotlin.collections.find' call
    var tmp0 = $this.z51_1.sv();
    var tmp$ret$1;
    $l$block: {
      // Inline function 'kotlin.collections.firstOrNull' call
      var _iterator__ex2g4s = tmp0.i();
      while (_iterator__ex2g4s.j()) {
        var element = _iterator__ex2g4s.k();
        if (element.m51_1 === relativeTime) {
          tmp$ret$1 = element;
          break $l$block;
        }
      }
      tmp$ret$1 = null;
    }
    return tmp$ret$1;
  }
  function getSlotWithRequestForActor($this, actor) {
    var tmp0 = $this.z51_1.sv();
    var tmp$ret$0;
    $l$block: {
      // Inline function 'kotlin.collections.firstOrNull' call
      var _iterator__ex2g4s = tmp0.i();
      while (_iterator__ex2g4s.j()) {
        var element = _iterator__ex2g4s.k();
        if (!(element.w52(actor) == null)) {
          tmp$ret$0 = element;
          break $l$block;
        }
      }
      tmp$ret$0 = null;
    }
    return tmp$ret$0;
  }
  function reset($this) {
    $this.b52_1 = 0n;
    $this.r52_1 = 0n;
    $this.z51_1.a2();
    $this.y51_1.bu();
  }
  function start($this) {
    $this.v51_1.eu(new SchedulerActivationStatePreparationEvent($this));
    _get_LOG__e5r759(Companion_getInstance_4()).ol('Scheduler started');
    reset($this);
    $this.c52_1 = $this.u51_1.mp();
    $this.d52_1 = 0n;
    $this.e52_1 = 0n;
    $this.t51_1.s4t_1.p1n();
    _set_isInBreakpoint__1hzh2h($this, false);
    $this.l52_1 = false;
    $this.n52_1 = false;
    $this.a52_1 = SchedulerActivationState_ACTIVE_getInstance();
    startTaskIfNeeded($this);
    $this.v51_1.eu(new SchedulerActivationStateEvent($this));
  }
  function startTaskIfNeeded($this) {
    if (!$this.t51_1.s4t_1.l1n_1) {
      $this.x51_1.o50();
    }
  }
  function stop($this) {
    _get_LOG__e5r759(Companion_getInstance_4()).ol('Scheduler stopped');
    $this.x51_1.wp();
    $this.a52_1 = SchedulerActivationState_PASSIVE_getInstance();
    _set_isInBreakpoint__1hzh2h($this, false);
    $this.v51_1.eu(new SchedulerActivationStateEvent($this));
    reset($this);
    $this.v51_1.eu(new SchedulerActivationStatePreparationEvent($this));
  }
  function updateRelativeTime($this, relativeTime) {
    // Inline function 'kotlin.math.max' call
    var b = $this.b52_1;
    var newRelativeTime = relativeTime >= b ? relativeTime : b;
    if (newRelativeTime > $this.b52_1) {
      $this.b52_1 = newRelativeTime;
      if (_get_LOG__e5r759(Companion_getInstance_4()).ql()) {
        _get_LOG__e5r759(Companion_getInstance_4()).ol(StringUtils_getInstance().ou($this.v50()) + ' ns Updated relative time');
      }
      $this.y51_1.j50($this.z51_1.ov(), $this);
    }
  }
  function getRelativeRealTime($this) {
    return subtract(subtract($this.u51_1.mp(), $this.c52_1), $this.e52_1);
  }
  function executeImpl($this, resume) {
    var optionalSlot = $this.z51_1.pv();
    if (optionalSlot == null) {
      updateRelativeTime($this, getRelativeRealTime($this));
      return Companion_getInstance_3().x50_1;
    }
    var slot = optionalSlot;
    if (!slot.x52()) {
      updateRelativeTime($this, slot.m51_1);
      return Companion_getInstance_3().x50_1;
    }
    var tmp0 = slot.m51_1;
    // Inline function 'kotlin.math.min' call
    var b = getRelativeRealTime($this);
    var tmp$ret$0 = tmp0 <= b ? tmp0 : b;
    updateRelativeTime($this, tmp$ret$0);
    var recalculated = false;
    if ($this.k52_1 || slot.m51_1 <= $this.b52_1) {
      updateRelativeTime($this, slot.m51_1);
      if (!resume && checkForBreakpoint($this, slot)) {
        $this.x51_1.wp();
        if (slot.y52()) {
          $this.l52_1 = true;
        } else {
          _set_isInBreakpoint__1hzh2h($this, true);
        }
        return Companion_getInstance_3().y50_1;
      }
      _set_isInBreakpoint__1hzh2h($this, false);
      // Inline function 'kotlin.collections.filter' call
      var tmp0_0 = slot.z52();
      // Inline function 'kotlin.collections.filterTo' call
      var destination = ArrayList_init_$Create$();
      var _iterator__ex2g4s = tmp0_0.i();
      while (_iterator__ex2g4s.j()) {
        var element = _iterator__ex2g4s.k();
        if (element.a53()) {
          destination.h(element);
        }
      }
      // Inline function 'kotlin.collections.forEach' call
      var _iterator__ex2g4s_0 = destination.i();
      while (_iterator__ex2g4s_0.j()) {
        var element_0 = _iterator__ex2g4s_0.k();
        element_0.b53();
      }
      if (slot.uv()) {
        removeSlot($this, slot);
      }
      recalculated = true;
    } else {
      var tmp0_1 = getRelativeRealTime($this);
      // Inline function 'kotlin.math.min' call
      var b_0 = slot.m51_1;
      var tmp$ret$6 = tmp0_1 <= b_0 ? tmp0_1 : b_0;
      updateRelativeTime($this, tmp$ret$6);
    }
    postSchedulerStateEvent($this);
    return recalculated ? Companion_getInstance_3().z50_1 : Companion_getInstance_3().x50_1;
  }
  function checkForBreakpoint($this, slot) {
    var tmp;
    if ($this.k52_1 && $this.v50() > $this.r52_1) {
      var tmp_0;
      if ($this.n52_1) {
        tmp_0 = true;
      } else {
        var tmp_1;
        if ($this.q52_1) {
          var tmp0 = slot.z52();
          var tmp$ret$0;
          $l$block_0: {
            // Inline function 'kotlin.collections.any' call
            var tmp_2;
            if (isInterface(tmp0, Collection)) {
              tmp_2 = tmp0.m();
            } else {
              tmp_2 = false;
            }
            if (tmp_2) {
              tmp$ret$0 = false;
              break $l$block_0;
            }
            var _iterator__ex2g4s = tmp0.i();
            while (_iterator__ex2g4s.j()) {
              var element = _iterator__ex2g4s.k();
              if (element.a53() && element.p51_1.t4v()) {
                tmp$ret$0 = true;
                break $l$block_0;
              }
            }
            tmp$ret$0 = false;
          }
          tmp_1 = tmp$ret$0;
        } else {
          tmp_1 = false;
        }
        tmp_0 = tmp_1;
      }
      tmp = tmp_0;
    } else {
      tmp = false;
    }
    return tmp;
  }
  function Slot($outer, relativeTime, actor, data) {
    this.o51_1 = $outer;
    this.m51_1 = relativeTime;
    var tmp = this;
    // Inline function 'kotlin.collections.mutableMapOf' call
    tmp.n51_1 = LinkedHashMap_init_$Create$();
    addRequest(this, new Request(this.o51_1, actor, data));
  }
  protoOf(Slot).x52 = function () {
    var tmp0 = this.n51_1.c2();
    var tmp$ret$0;
    $l$block_0: {
      // Inline function 'kotlin.collections.any' call
      var tmp;
      if (isInterface(tmp0, Collection)) {
        tmp = tmp0.m();
      } else {
        tmp = false;
      }
      if (tmp) {
        tmp$ret$0 = false;
        break $l$block_0;
      }
      var _iterator__ex2g4s = tmp0.i();
      while (_iterator__ex2g4s.j()) {
        var element = _iterator__ex2g4s.k();
        if (element.a53()) {
          tmp$ret$0 = true;
          break $l$block_0;
        }
      }
      tmp$ret$0 = false;
    }
    return tmp$ret$0;
  };
  protoOf(Slot).y52 = function () {
    var tmp0 = this.n51_1.c2();
    var tmp$ret$0;
    $l$block_0: {
      // Inline function 'kotlin.collections.any' call
      var tmp;
      if (isInterface(tmp0, Collection)) {
        tmp = tmp0.m();
      } else {
        tmp = false;
      }
      if (tmp) {
        tmp$ret$0 = false;
        break $l$block_0;
      }
      var _iterator__ex2g4s = tmp0.i();
      while (_iterator__ex2g4s.j()) {
        var element = _iterator__ex2g4s.k();
        if (element.y52()) {
          tmp$ret$0 = true;
          break $l$block_0;
        }
      }
      tmp$ret$0 = false;
    }
    return tmp$ret$0;
  };
  protoOf(Slot).uv = function () {
    return this.n51_1.m();
  };
  protoOf(Slot).c53 = function (other) {
    return compareTo(this.m51_1, other.m51_1);
  };
  protoOf(Slot).d = function (other) {
    return this.c53(other instanceof Slot ? other : THROW_CCE());
  };
  protoOf(Slot).z52 = function () {
    return this.n51_1.c2();
  };
  protoOf(Slot).u52 = function (actor, data) {
    var request = this.w52(actor);
    if (!(request == null)) {
      request.d53(data);
    } else {
      addRequest(this, new Request(this.o51_1, actor, data));
    }
  };
  protoOf(Slot).e53 = function (actor, request) {
    if (request == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      this.o51_1.w50(actor, SchedulerImpl$Slot$actingDone$lambda);
      this.n51_1.z1(request.p51_1);
      postSchedulerEvent(this.o51_1, actor);
    }
  };
  protoOf(Slot).w52 = function (actor) {
    return this.n51_1.g2(actor);
  };
  function Request($outer, actor, actorData) {
    this.s51_1 = $outer;
    this.p51_1 = actor;
    this.q51_1 = false;
    this.r51_1 = actorData;
  }
  protoOf(Request).y52 = function () {
    return this.q51_1;
  };
  protoOf(Request).a53 = function () {
    return !this.y52();
  };
  protoOf(Request).d53 = function (actorData) {
    this.r51_1 = actorData;
    this.q51_1 = false;
  };
  protoOf(Request).b53 = function () {
    if (!this.q51_1) {
      this.s51_1.w50(this.p51_1, SchedulerImpl$Request$act$lambda);
      this.q51_1 = true;
      this.p51_1.y4v(this.s51_1, this.r51_1);
    }
  };
  function SchedulerImpl$issueCollectorListener$lambda$lambda($it, this$0) {
    return function () {
      _get_LOG__e5r759(Companion_getInstance_4()).ol("execution stopped due to Issue '" + $it.k4z_1.m2() + "'");
      this$0.v51_1.eu(new ExecutionStoppedOnIssueEvent($it.k4z_1, this$0));
      return Unit_instance;
    };
  }
  function SchedulerImpl$issueCollectorListener$lambda(this$0) {
    return function (it) {
      var tmp;
      if (this$0.r4t() && this$0.o52_1 && !(it.k4z_1 == null)) {
        this$0.w4t().s4t_1.o1n();
        var tmp_0 = System_getInstance();
        tmp_0.dm(SchedulerImpl$issueCollectorListener$lambda$lambda(it, this$0));
        tmp = Unit_instance;
      }
      return Unit_instance;
    };
  }
  function SchedulerImpl$breakListener$lambda(this$0) {
    return function (it) {
      this$0.n52_1 = true;
      var tmp;
      if (this$0.k52_1) {
        _set_isInBreakpoint__1hzh2h(this$0, true);
        tmp = Unit_instance;
      }
      return Unit_instance;
    };
  }
  function SchedulerImpl$pauseEventListener$lambda(this$0) {
    return function (it) {
      var tmp;
      if (this$0.r4t() && it.t1n_1 === this$0.t51_1.s4t_1) {
        var tmp_0;
        if (it.u1n_1) {
          handlePaused(this$0);
          tmp_0 = Unit_instance;
        } else {
          handleResumed(this$0);
          tmp_0 = Unit_instance;
        }
        tmp = tmp_0;
      }
      return Unit_instance;
    };
  }
  function SchedulerImpl$systemSpeedCategoryHandler$lambda(this$0) {
    return function (it) {
      var tmp;
      if (it.f53_1 === this$0.t51_1) {
        _get_LOG__e5r759(Companion_getInstance_4()).ol(StringUtils_getInstance().ou(this$0.v50()) + " ns: SpeedCategory changed to '" + this$0.t51_1.v4t_1.s4z_1 + "'");
        var tmp_0;
        if (!_get_displaySimulationTime__8co2bf(this$0)) {
          clearSimulationTimeStatus(this$0);
          tmp_0 = Unit_instance;
        } else {
          publishSimulationTimeStatus(this$0);
          tmp_0 = Unit_instance;
        }
        tmp = tmp_0;
      }
      return Unit_instance;
    };
  }
  function SchedulerImpl$actPrematurely$lambda() {
    return 'Executing prematurely';
  }
  function SchedulerImpl$requestActingImpl$lambda($delay) {
    return function () {
      return 'Request to act after ' + StringUtils_getInstance().ou($delay) + ' ns';
    };
  }
  function SchedulerImpl(currentSystemSpeedCategory, timeService, eventBus, noiseGeneratorHolder, task, executionErrorHandler, isDeepExecution) {
    Companion_getInstance_4();
    timeService = timeService === VOID ? BaseModule_getInstance().ap_1 : timeService;
    eventBus = eventBus === VOID ? BaseModule_getInstance().zo_1 : eventBus;
    noiseGeneratorHolder = noiseGeneratorHolder === VOID ? ExecutionModule_getInstance().a50() : noiseGeneratorHolder;
    task = task === VOID ? ExecutionModule_getInstance().y4z_1(currentSystemSpeedCategory, eventBus) : task;
    executionErrorHandler = executionErrorHandler === VOID ? new ExecutionErrorHandlerImpl() : executionErrorHandler;
    isDeepExecution = isDeepExecution === VOID ? true : isDeepExecution;
    this.t51_1 = currentSystemSpeedCategory;
    this.u51_1 = timeService;
    this.v51_1 = eventBus;
    this.w51_1 = noiseGeneratorHolder;
    this.x51_1 = task;
    this.y51_1 = executionErrorHandler;
    this.z51_1 = new PriorityQueue();
    this.a52_1 = SchedulerActivationState_PASSIVE_getInstance();
    this.b52_1 = 0n;
    this.c52_1 = 0n;
    this.d52_1 = 0n;
    this.e52_1 = 0n;
    var tmp = this;
    tmp.f52_1 = SchedulerImpl$issueCollectorListener$lambda(this);
    var tmp_0 = this;
    tmp_0.g52_1 = SchedulerImpl$breakListener$lambda(this);
    var tmp_1 = this;
    tmp_1.h52_1 = SchedulerImpl$pauseEventListener$lambda(this);
    var tmp_2 = this;
    tmp_2.i52_1 = SchedulerImpl$systemSpeedCategoryHandler$lambda(this);
    var tmp_3 = this;
    // Inline function 'kotlin.collections.mutableListOf' call
    tmp_3.j52_1 = ArrayList_init_$Create$();
    this.x51_1.n50(this);
    this.v51_1.j17(getKClass(IssueCollectorEvent), this.f52_1);
    this.v51_1.j17(getKClass(BreakEvent), this.g52_1);
    this.v51_1.j17(getKClass(SystemSpeedPauseEvent), this.h52_1);
    this.v51_1.j17(getKClass(SystemSpeedCategoryEvent), this.i52_1);
    this.k52_1 = false;
    this.l52_1 = false;
    this.m52_1 = false;
    this.n52_1 = false;
    this.o52_1 = BaseModule_getInstance().yo_1.st('execution.scheduler.stopOnIssue', true);
    this.p52_1 = BaseModule_getInstance().yo_1.st('execution.scheduler.enableSimulationTimeStatusBar', false);
    this.q52_1 = BaseModule_getInstance().yo_1.st('execution.scheduler.enableSoftBreakpoints', false);
    this.r52_1 = 0n;
    this.s52_1 = isDeepExecution;
    this.t52_1 = null;
  }
  protoOf(SchedulerImpl).i53 = function () {
    return this.v51_1;
  };
  protoOf(SchedulerImpl).w4t = function () {
    return this.t51_1;
  };
  protoOf(SchedulerImpl).q50 = function () {
    return this.z51_1.ov();
  };
  protoOf(SchedulerImpl).p50 = function (value) {
    if (value === this.r4t()) {
      return Unit_instance;
    }
    if (value) {
      start(this);
    } else {
      stop(this);
    }
    Status_getInstance().du(StatusType_Small_getInstance(), null);
  };
  protoOf(SchedulerImpl).r4t = function () {
    return this.a52_1.equals(SchedulerActivationState_ACTIVE_getInstance());
  };
  protoOf(SchedulerImpl).m4v = function (value) {
    if (!(value === this.k52_1)) {
      this.k52_1 = value;
      this.v51_1.eu(new SchedulerSingleStepModeEvent(this));
      startTaskIfNeeded(this);
    }
  };
  protoOf(SchedulerImpl).l4v = function () {
    return this.k52_1;
  };
  protoOf(SchedulerImpl).x4t = function () {
    return this.m52_1;
  };
  protoOf(SchedulerImpl).r50 = function (_set____db54di) {
    this.r52_1 = _set____db54di;
  };
  protoOf(SchedulerImpl).s50 = function (listener) {
    if (!this.j52_1.n(listener)) {
      this.j52_1.h(listener);
    }
  };
  protoOf(SchedulerImpl).t50 = function (listener) {
    this.j52_1.h2(listener);
  };
  protoOf(SchedulerImpl).v52 = function (source) {
    var event = new SchedulerEvent(this, source);
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = this.j52_1.i();
    while (_iterator__ex2g4s.j()) {
      var element = _iterator__ex2g4s.k();
      element.j53(event);
    }
  };
  protoOf(SchedulerImpl).u50 = function () {
    return executeImpl(this, false);
  };
  protoOf(SchedulerImpl).z4u = function (_set____db54di) {
    this.s52_1 = _set____db54di;
  };
  protoOf(SchedulerImpl).y4u = function () {
    return this.s52_1;
  };
  protoOf(SchedulerImpl).v50 = function () {
    return this.b52_1;
  };
  protoOf(SchedulerImpl).k53 = function (_set____db54di) {
    this.t52_1 = _set____db54di;
  };
  protoOf(SchedulerImpl).l53 = function () {
    return this.t52_1;
  };
  protoOf(SchedulerImpl).m53 = function () {
    return _get_LOG__e5r759(Companion_getInstance_4()).ql();
  };
  protoOf(SchedulerImpl).n53 = function (clazz, id, msg) {
    if (_get_LOG__e5r759(Companion_getInstance_4()).ql()) {
      _get_LOG__e5r759(Companion_getInstance_4()).ol(StringUtils_getInstance().ou(this.v50()) + ' ns [' + clazz.l9() + ' (' + id + ')]: ' + msg());
    }
  };
  protoOf(SchedulerImpl).w50 = function (actor, msg) {
    if (_get_LOG__e5r759(Companion_getInstance_4()).ql()) {
      _get_LOG__e5r759(Companion_getInstance_4()).ol(StringUtils_getInstance().ou(this.v50()) + ' ns [' + System_getInstance().xl(actor).l9() + ' (' + actor.av() + ')]: ' + msg());
    }
  };
  protoOf(SchedulerImpl).s4x = function (actor, delay, data) {
    requestActingImpl(this, actor, delay, data);
  };
  protoOf(SchedulerImpl).o53 = function (actor, data) {
    var slot = getSlotWithRequestForActor(this, actor);
    if (!(slot == null)) {
      var request = ensureNotNull(slot.w52(actor));
      if (request.a53()) {
        this.w50(request.p51_1, SchedulerImpl$actPrematurely$lambda);
        request.b53();
      }
    }
  };
  protoOf(SchedulerImpl).t4x = function (actor, data) {
    var slot = this.z51_1.pv();
    if (!(slot == null)) {
      var request = slot.w52(actor);
      if (request == null) {
        slot = getSlotWithRequestForActor(this, actor);
        if (!(slot == null)) {
          request = slot.w52(actor);
        }
      }
      if (!(slot == null)) {
        if (!(request == null) && request.y52()) {
          actor.a4w(this, request.r51_1);
        }
        slot.e53(actor, request);
        if (this.l52_1 && !slot.y52()) {
          _set_isInBreakpoint__1hzh2h(this, true);
        }
        if (slot.uv()) {
          removeSlot(this, slot);
          postSchedulerStateEvent(this);
        }
      } else {
        actor.a4w(this, data);
      }
    } else {
      actor.a4w(this, data);
    }
  };
  protoOf(SchedulerImpl).i50 = function (error) {
    this.y51_1.i50(error);
  };
  function AbstractSchedulerTask(nameKey) {
    this.p53_1 = nameKey;
  }
  protoOf(AbstractSchedulerTask).n50 = function (scheduler) {
    this.q53_1 = scheduler;
  };
  function _get_LOG__e5r759_0($this) {
    var tmp0 = $this.r53_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('LOG', 1, tmp, TimedSchedulerTask$Companion$_get_LOG_$ref_96mk21(), null);
    return tmp0.j2();
  }
  function TimedSchedulerTask$Companion$_get_LOG_$ref_96mk21() {
    return function (p0) {
      return _get_LOG__e5r759_0(p0);
    };
  }
  function Companion_3() {
    Companion_instance_3 = this;
    this.r53_1 = logger(getKClass(TimedSchedulerTask));
    this.s53_1 = 10000;
    this.t53_1 = 'TimedSchedulerTask.slowDownFactor';
    this.u53_1 = 4.0;
  }
  var Companion_instance_3;
  function Companion_getInstance_5() {
    if (Companion_instance_3 == null)
      new Companion_3();
    return Companion_instance_3;
  }
  function _get_slowDownFactor__sg5jc7($this) {
    var tmp0 = $this.d54_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('slowDownFactor', 1, tmp, TimedSchedulerTask$_get_slowDownFactor_$ref_ff46mb(), null);
    return tmp0.j2();
  }
  function _get_scheduler__wzo5xm($this) {
    var tmp = $this.e54_1;
    if (!(tmp == null))
      return tmp;
    else {
      throwUninitializedPropertyAccessException('scheduler');
    }
  }
  function calculateTimerInterval($this) {
    var category = $this.x53_1.v4t_1;
    var speed = $this.x53_1.s4t_1.k1n_1;
    var tmp;
    if ($this.x53_1.s4t_1.n1n()) {
      tmp = 1;
    } else {
      var intervals = ensureNotNull($this.b54_1.g2(category));
      tmp = numberToInt(_get_slowDownFactor__sg5jc7($this) * interpolate(category.t4z_1, speed, intervals.y_1, intervals.z_1));
    }
    return tmp;
  }
  function calculateNumberOfSteps($this) {
    var category = $this.x53_1.v4t_1;
    var speed = $this.x53_1.s4t_1.k1n_1;
    var tmp;
    if ($this.x53_1.s4t_1.n1n()) {
      tmp = 10000;
    } else {
      var steps = ensureNotNull($this.a54_1.g2(category));
      tmp = interpolate(category.t4z_1, speed, steps.y_1, steps.z_1);
    }
    return tmp;
  }
  function adaptToSystemSpeed($this) {
    $this.f54_1 = calculateNumberOfSteps($this);
    $this.g54_1 = calculateTimerInterval($this);
    if (_get_LOG__e5r759_0(Companion_getInstance_5()).ql()) {
      _get_LOG__e5r759_0(Companion_getInstance_5()).ol('number of steps: ' + $this.f54_1 + ', interval: ' + $this.g54_1);
    }
    var needRestart = $this.y53_1.sp() === 2147483647 && !($this.g54_1 === 2147483647) && $this.y53_1.xp();
    $this.y53_1.rp($this.g54_1);
    if (needRestart) {
      $this.y53_1.wp();
      $this.y53_1.vp();
    }
  }
  function executeNumberOfSteps($this, number) {
    var effNumber = number + Default_getInstance().ag(0, 3) | 0;
    var count = 0;
    var result = null;
    $l$1: do {
      $l$0: do {
        result = _get_scheduler__wzo5xm($this).u50();
        count = count + 1 | 0;
      }
       while (false);
      var tmp;
      var tmp_0;
      var tmp_1;
      var tmp_2;
      if (result == null) {
        throwUninitializedPropertyAccessException('result');
      } else {
        tmp_2 = result;
      }
      if (!tmp_2.b51_1) {
        tmp_1 = count < effNumber;
      } else {
        tmp_1 = false;
      }
      if (tmp_1) {
        tmp_0 = !_get_scheduler__wzo5xm($this).q50();
      } else {
        tmp_0 = false;
      }
      if (tmp_0) {
        var tmp_3;
        if (result == null) {
          throwUninitializedPropertyAccessException('result');
        } else {
          tmp_3 = result;
        }
        tmp = tmp_3.a51_1;
      } else {
        tmp = false;
      }
    }
     while (tmp);
  }
  function TimedSchedulerTask$systemSpeedHandler$lambda(this$0) {
    return function (it) {
      var tmp;
      if (equals(it.q1n_1, this$0.x53_1.s4t_1)) {
        adaptToSystemSpeed(this$0);
        tmp = Unit_instance;
      }
      return Unit_instance;
    };
  }
  function TimedSchedulerTask$slowDownFactor$delegate$lambda() {
    return BaseModule_getInstance().xo_1.jt('TimedSchedulerTask.slowDownFactor');
  }
  function TimedSchedulerTask$_get_slowDownFactor_$ref_ff46mb() {
    return function (p0) {
      return _get_slowDownFactor__sg5jc7(p0);
    };
  }
  function TimedSchedulerTask$lambda(this$0) {
    return function (it) {
      this$0.actionPerformed(it);
      return Unit_instance;
    };
  }
  function TimedSchedulerTask(currentSystemSpeedCategory, timer, eventBus) {
    Companion_getInstance_5();
    timer = timer === VOID ? System_getInstance().ul() : timer;
    eventBus = eventBus === VOID ? BaseModule_getInstance().zo_1 : eventBus;
    AbstractSchedulerTask.call(this, 'execution.task.timed');
    this.x53_1 = currentSystemSpeedCategory;
    this.y53_1 = timer;
    this.z53_1 = eventBus;
    this.a54_1 = mapOf([to(SystemSpeedCategory_Use_getInstance(), numberRangeToNumber(100, 10000)), to(SystemSpeedCategory_Observe_getInstance(), numberRangeToNumber(3, 100)), to(SystemSpeedCategory_Explore_getInstance(), numberRangeToNumber(1, 3))]);
    this.b54_1 = mapOf([to(SystemSpeedCategory_Use_getInstance(), downTo(5, 1)), to(SystemSpeedCategory_Observe_getInstance(), downTo(10, 5)), to(SystemSpeedCategory_Explore_getInstance(), downTo(30, 10))]);
    var tmp = this;
    tmp.c54_1 = TimedSchedulerTask$systemSpeedHandler$lambda(this);
    var tmp_0 = this;
    tmp_0.d54_1 = lazy(TimedSchedulerTask$slowDownFactor$delegate$lambda);
    this.z53_1.j17(getKClass(SystemSpeedEvent), this.c54_1);
    this.f54_1 = calculateNumberOfSteps(this);
    this.g54_1 = calculateTimerInterval(this);
    var tmp_1 = this.g54_1;
    this.y53_1.up(tmp_1, VOID, TimedSchedulerTask$lambda(this));
  }
  protoOf(TimedSchedulerTask).n50 = function (scheduler) {
    this.e54_1 = scheduler;
  };
  protoOf(TimedSchedulerTask).o50 = function () {
    if (!_get_scheduler__wzo5xm(this).q50() && !this.y53_1.xp()) {
      _get_LOG__e5r759_0(Companion_getInstance_5()).ol('Starting timer');
      adaptToSystemSpeed(this);
      this.y53_1.vp();
    }
  };
  protoOf(TimedSchedulerTask).wp = function () {
    this.y53_1.wp();
  };
  protoOf(TimedSchedulerTask).actionPerformed = function (event) {
    executeNumberOfSteps(this, this.f54_1);
  };
  function _get_LOG__e5r759_1($this) {
    var tmp0 = $this.h54_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('LOG', 1, tmp, CurrentSystemSpeedCategory$Companion$_get_LOG_$ref_flvtjx(), null);
    return tmp0.j2();
  }
  function CurrentSystemSpeedCategory$Companion$_get_LOG_$ref_flvtjx() {
    return function (p0) {
      return _get_LOG__e5r759_1(p0);
    };
  }
  function Companion_4() {
    Companion_instance_4 = this;
    this.h54_1 = logger(getKClass(CurrentSystemSpeedCategory));
  }
  var Companion_instance_4;
  function Companion_getInstance_6() {
    if (Companion_instance_4 == null)
      new Companion_4();
    return Companion_instance_4;
  }
  function update($this) {
    var oldValue = $this.v4t_1;
    $this.v4t_1 = calculate($this);
    if (!oldValue.equals($this.v4t_1)) {
      _get_LOG__e5r759_1(Companion_getInstance_6()).ol("CurrentSystemSpeedCategory changed to '" + $this.v4t_1.toString() + "'");
      $this.t4t_1.eu(new SystemSpeedCategoryEvent($this, oldValue, $this.v4t_1));
    }
  }
  function calculate($this) {
    var tmp0 = get_entries();
    var tmp$ret$0;
    $l$block: {
      // Inline function 'kotlin.collections.first' call
      var _iterator__ex2g4s = tmp0.i();
      while (_iterator__ex2g4s.j()) {
        var element = _iterator__ex2g4s.k();
        if ($this.s4t_1.k1n_1 >= element.t4z_1.y_1) {
          tmp$ret$0 = element;
          break $l$block;
        }
      }
      throw NoSuchElementException_init_$Create$('Collection contains no element matching the predicate.');
    }
    return tmp$ret$0;
  }
  function CurrentSystemSpeedCategory$systemSpeedHandler$lambda(this$0) {
    return function (it) {
      var tmp;
      if (it.q1n_1 === this$0.s4t_1) {
        update(this$0);
        tmp = Unit_instance;
      }
      return Unit_instance;
    };
  }
  function CurrentSystemSpeedCategory(systemSpeed, eventBus) {
    Companion_getInstance_6();
    eventBus = eventBus === VOID ? BaseModule_getInstance().zo_1 : eventBus;
    this.s4t_1 = systemSpeed;
    this.t4t_1 = eventBus;
    var tmp = this;
    tmp.u4t_1 = CurrentSystemSpeedCategory$systemSpeedHandler$lambda(this);
    this.t4t_1.j17(getKClass(SystemSpeedEvent), this.u4t_1);
    this.v4t_1 = calculate(this);
  }
  var SystemSpeedCategory_Use_instance;
  var SystemSpeedCategory_Observe_instance;
  var SystemSpeedCategory_Explore_instance;
  function Companion_5() {
  }
  protoOf(Companion_5).r1e = function (customName) {
    var tmp0 = values();
    var tmp$ret$0;
    $l$block: {
      // Inline function 'kotlin.collections.firstOrNull' call
      var inductionVariable = 0;
      var last = tmp0.length;
      while (inductionVariable < last) {
        var element = tmp0[inductionVariable];
        inductionVariable = inductionVariable + 1 | 0;
        if (element.s4z_1 === customName) {
          tmp$ret$0 = element;
          break $l$block;
        }
      }
      tmp$ret$0 = null;
    }
    var tmp0_elvis_lhs = tmp$ret$0;
    var tmp;
    if (tmp0_elvis_lhs == null) {
      throw IllegalArgumentException_init_$Create$('Unknown SystemSpeedCategory');
    } else {
      tmp = tmp0_elvis_lhs;
    }
    return tmp;
  };
  var Companion_instance_5;
  function Companion_getInstance_7() {
    return Companion_instance_5;
  }
  function values() {
    return [SystemSpeedCategory_Use_getInstance(), SystemSpeedCategory_Observe_getInstance(), SystemSpeedCategory_Explore_getInstance()];
  }
  function get_entries() {
    if ($ENTRIES == null)
      $ENTRIES = enumEntries(values());
    return $ENTRIES;
  }
  var SystemSpeedCategory_entriesInitialized;
  function SystemSpeedCategory_initEntries() {
    if (SystemSpeedCategory_entriesInitialized)
      return Unit_instance;
    SystemSpeedCategory_entriesInitialized = true;
    SystemSpeedCategory_Use_instance = new SystemSpeedCategory('Use', 0, 'use', numberRangeToNumber(67, 100));
    SystemSpeedCategory_Observe_instance = new SystemSpeedCategory('Observe', 1, 'observer', numberRangeToNumber(34, 66));
    SystemSpeedCategory_Explore_instance = new SystemSpeedCategory('Explore', 2, 'explore', numberRangeToNumber(0, 33));
  }
  var $ENTRIES;
  function SystemSpeedCategory(name, ordinal, customName, speedRange) {
    Enum.call(this, name, ordinal);
    this.s4z_1 = customName;
    this.t4z_1 = speedRange;
  }
  protoOf(SystemSpeedCategory).toString = function () {
    var tmp;
    switch (this.l2_1) {
      case 0:
        tmp = Translations_getInstance().zm('execution.systemSpeedCategory.use', []);
        break;
      case 1:
        tmp = Translations_getInstance().zm('execution.systemSpeedCategory.observe', []);
        break;
      case 2:
        tmp = Translations_getInstance().zm('execution.systemSpeedCategory.explore', []);
        break;
      default:
        noWhenBranchMatchedException();
        break;
    }
    return tmp;
  };
  function SystemSpeedCategoryEvent(source, oldValue, newValue) {
    this.f53_1 = source;
    this.g53_1 = oldValue;
    this.h53_1 = newValue;
  }
  protoOf(SystemSpeedCategoryEvent).toString = function () {
    return 'SystemSpeedCategoryEvent(source=' + toString(this.f53_1) + ', oldValue=' + this.g53_1.toString() + ', newValue=' + this.h53_1.toString() + ')';
  };
  protoOf(SystemSpeedCategoryEvent).hashCode = function () {
    var result = hashCode(this.f53_1);
    result = imul(result, 31) + this.g53_1.hashCode() | 0;
    result = imul(result, 31) + this.h53_1.hashCode() | 0;
    return result;
  };
  protoOf(SystemSpeedCategoryEvent).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof SystemSpeedCategoryEvent))
      return false;
    if (!equals(this.f53_1, other.f53_1))
      return false;
    if (!this.g53_1.equals(other.g53_1))
      return false;
    if (!this.h53_1.equals(other.h53_1))
      return false;
    return true;
  };
  function SystemSpeedCategory_Use_getInstance() {
    SystemSpeedCategory_initEntries();
    return SystemSpeedCategory_Use_instance;
  }
  function SystemSpeedCategory_Observe_getInstance() {
    SystemSpeedCategory_initEntries();
    return SystemSpeedCategory_Observe_instance;
  }
  function SystemSpeedCategory_Explore_getInstance() {
    SystemSpeedCategory_initEntries();
    return SystemSpeedCategory_Explore_instance;
  }
  //region block: post-declaration
  defineProp(protoOf(AbstractSchedulerAction), 'requestFocusOnClick', function () {
    return this.uq();
  });
  defineProp(protoOf(PauseOrResumeActionImpl), 'inBreakpoint', function () {
    return this.c4t();
  });
  defineProp(protoOf(PauseOrResumeActionImpl), 'opensDialog', function () {
    return this.tq();
  });
  defineProp(protoOf(PauseOrResumeActionImpl), 'name', function () {
    return this.m2();
  }, function (value) {
    this.iq(value);
  });
  defineProp(protoOf(PauseOrResumeActionImpl), 'description', function () {
    return this.kq();
  }, function (value) {
    this.jq(value);
  });
  defineProp(protoOf(PauseOrResumeActionImpl), 'accelerator', function () {
    return this.mq();
  }, function (value) {
    this.lq(value);
  });
  defineProp(protoOf(PauseOrResumeActionImpl), 'enabled', function () {
    return this.oq();
  }, function (value) {
    this.nq(value);
  });
  defineProp(protoOf(PauseOrResumeActionImpl), 'selected', function () {
    return this.qq();
  }, function (value) {
    this.pq(value);
  });
  defineProp(protoOf(PauseOrResumeActionImpl), 'imagePath', function () {
    return this.sq();
  }, function (value) {
    this.rq(value);
  });
  defineProp(protoOf(PauseOrResumeActionImpl), 'requestFocusOnClick', function () {
    return this.uq();
  });
  defineProp(protoOf(ExecutionDepthAction), 'requestFocusOnClick', function () {
    return this.uq();
  });
  defineProp(protoOf(SingleStepModeAction), 'requestFocusOnClick', function () {
    return this.uq();
  });
  protoOf(ActorDrawableButton).a4x = executionStarted;
  protoOf(ActorDrawableButton).b4x = executionStartDone;
  protoOf(ActorDrawableButton).b4w = executionStopped;
  protoOf(ActorImpl).o4v = get_waiting;
  protoOf(ActorViewBag).b4x = executionStartDone;
  protoOf(ActorViewContainer).b4x = executionStartDone;
  //endregion
  //region block: init
  PROP_PAUSE_OR_RESUME_ACTION_IN_BREAKPOINT = 'inBreakpoint';
  Companion_instance = new Companion();
  Companion_instance_0 = new Companion_0();
  Companion_instance_5 = new Companion_5();
  //endregion
  //region block: exports
  function $jsExportAll$(_) {
    var io = _.io || (_.io = {});
    var antarescircuit = io.antarescircuit || (io.antarescircuit = {});
    var jabbah = antarescircuit.jabbah || (antarescircuit.jabbah = {});
    var execution = jabbah.execution || (jabbah.execution = {});
    var io_0 = _.io || (_.io = {});
    var antarescircuit_0 = io_0.antarescircuit || (io_0.antarescircuit = {});
    var jabbah_0 = antarescircuit_0.jabbah || (antarescircuit_0.jabbah = {});
    var execution_0 = jabbah_0.execution || (jabbah_0.execution = {});
    defineProp(execution_0, 'PROP_PAUSE_OR_RESUME_ACTION_IN_BREAKPOINT', get_PROP_PAUSE_OR_RESUME_ACTION_IN_BREAKPOINT, VOID, true);
    var io_1 = _.io || (_.io = {});
    var antarescircuit_1 = io_1.antarescircuit || (io_1.antarescircuit = {});
    var jabbah_1 = antarescircuit_1.jabbah || (antarescircuit_1.jabbah = {});
    var execution_1 = jabbah_1.execution || (jabbah_1.execution = {});
  }
  $jsExportAll$(_);
  _.$jsExportAll$ = $jsExportAll$;
  _.$_$ = _.$_$ || {};
  _.$_$.a = ExecutionModule_getInstance;
  _.$_$.b = Companion_instance_5;
  _.$_$.c = ActorState_Idle_getInstance;
  _.$_$.d = ActorState_NonExecuting_getInstance;
  _.$_$.e = ActorState_Waiting_getInstance;
  _.$_$.f = SystemSpeedCategory_Explore_getInstance;
  _.$_$.g = SystemSpeedCategory_Observe_getInstance;
  _.$_$.h = SystemSpeedCategory_Use_getInstance;
  _.$_$.i = ActorDrawableButton_init_$Init$;
  _.$_$.j = ActorDrawableButton_init_$Create$;
  _.$_$.k = ActorHandler;
  _.$_$.l = ActorDrawableButton;
  _.$_$.m = ActorImpl;
  _.$_$.n = ActorInteractionContext;
  _.$_$.o = executionStartDone;
  _.$_$.p = getExecutionTooltip;
  _.$_$.q = Handler;
  _.$_$.r = ActorViewBag;
  _.$_$.s = ActorViewContainer;
  _.$_$.t = ActorView;
  _.$_$.u = Actor;
  _.$_$.v = ClickableActorInteractionHandlerAdapter;
  _.$_$.w = SimpleActorData;
  _.$_$.x = NoNoiseGenerator;
  _.$_$.y = NoiseGeneratorHolder;
  _.$_$.z = BreakEvent;
  _.$_$.a1 = ManualSchedulerTask;
  _.$_$.b1 = SchedulerActivationStateEvent;
  _.$_$.c1 = SchedulerEvent;
  _.$_$.d1 = SchedulerImpl;
  _.$_$.e1 = SchedulerSingleStepModeEvent;
  _.$_$.f1 = Scheduler;
  _.$_$.g1 = CurrentSystemSpeedCategory;
  _.$_$.h1 = SystemSpeedCategoryEvent;
  _.$_$.i1 = AbstractExecutionError;
  _.$_$.j1 = ExecutionControlOutlet;
  _.$_$.k1 = ExecutionDepthAction;
  _.$_$.l1 = PauseOrResumeActionImpl;
  _.$_$.m1 = SchedulerActions;
  _.$_$.n1 = SingleStepModeAction;
  //endregion
  return _;
}));

//# sourceMappingURL=jabbah-execution.js.map
