(function (factory) {
  if (typeof define === 'function' && define.amd)
    define(['exports', './kotlin-kotlin-stdlib.js', './jabbah-base.js', './jabbah-draw.js'], factory);
  else if (typeof exports === 'object')
    factory(module.exports, require('./kotlin-kotlin-stdlib.js'), require('./jabbah-base.js'), require('./jabbah-draw.js'));
  else {
    if (typeof globalThis['kotlin-kotlin-stdlib'] === 'undefined') {
      throw new Error("Error loading module 'jabbah-execution'. Its dependency 'kotlin-kotlin-stdlib' was not found. Please, check whether 'kotlin-kotlin-stdlib' is loaded prior to 'jabbah-execution'.");
    }
    if (typeof globalThis['jabbah-base'] === 'undefined') {
      throw new Error("Error loading module 'jabbah-execution'. Its dependency 'jabbah-base' was not found. Please, check whether 'jabbah-base' is loaded prior to 'jabbah-execution'.");
    }
    if (typeof globalThis['jabbah-draw'] === 'undefined') {
      throw new Error("Error loading module 'jabbah-execution'. Its dependency 'jabbah-draw' was not found. Please, check whether 'jabbah-draw' is loaded prior to 'jabbah-execution'.");
    }
    globalThis['jabbah-execution'] = factory(typeof globalThis['jabbah-execution'] === 'undefined' ? {} : globalThis['jabbah-execution'], globalThis['kotlin-kotlin-stdlib'], globalThis['jabbah-base'], globalThis['jabbah-draw']);
  }
}(function (_, kotlin_kotlin, kotlin_jabbah_base, kotlin_jabbah_draw) {
  'use strict';
  //region block: imports
  var imul = Math.imul;
  var protoOf = kotlin_kotlin.$_$.t7;
  var initMetadataForInterface = kotlin_kotlin.$_$.g7;
  var subtract = kotlin_kotlin.$_$.i6;
  var VOID = kotlin_kotlin.$_$.b;
  var fromInt = kotlin_kotlin.$_$.a6;
  var initMetadataForClass = kotlin_kotlin.$_$.d7;
  var Action = kotlin_jabbah_base.$_$.e7;
  var KMutableProperty1 = kotlin_kotlin.$_$.t8;
  var getPropertyCallableRef = kotlin_kotlin.$_$.a7;
  var Translations_getInstance = kotlin_jabbah_base.$_$.d1;
  var Unit_instance = kotlin_kotlin.$_$.i;
  var ObservableProperty = kotlin_kotlin.$_$.a8;
  var BaseModule_getInstance = kotlin_jabbah_base.$_$.n;
  var Delegates_instance = kotlin_kotlin.$_$.e;
  var SystemSpeedPauseEvent = kotlin_jabbah_base.$_$.y6;
  var getKClass = kotlin_kotlin.$_$.s8;
  var defineProp = kotlin_kotlin.$_$.t6;
  var initMetadataForCompanion = kotlin_kotlin.$_$.e7;
  var AbstractAction = kotlin_jabbah_base.$_$.c7;
  var AbstractAction_init_$Init$ = kotlin_jabbah_base.$_$.y3;
  var Enum = kotlin_kotlin.$_$.xa;
  var Companion_getInstance = kotlin_jabbah_draw.$_$.v;
  var DrawStyleModule_getInstance = kotlin_jabbah_draw.$_$.s;
  var StylableImpl = kotlin_jabbah_draw.$_$.h5;
  var objectCreate = kotlin_kotlin.$_$.s7;
  var InputEventHandlerAdapter = kotlin_jabbah_draw.$_$.f6;
  var THROW_CCE = kotlin_kotlin.$_$.fb;
  var equals = kotlin_kotlin.$_$.u6;
  var FunctionAdapter = kotlin_kotlin.$_$.k6;
  var isInterface = kotlin_kotlin.$_$.m7;
  var ButtonAction = kotlin_jabbah_draw.$_$.f3;
  var hashCode = kotlin_kotlin.$_$.c7;
  var DrawableButton = kotlin_jabbah_draw.$_$.i3;
  var Companion_getInstance_0 = kotlin_jabbah_base.$_$.h;
  var KProperty1 = kotlin_kotlin.$_$.v8;
  var lazy = kotlin_kotlin.$_$.qb;
  var LongValueImpl = kotlin_jabbah_base.$_$.i7;
  var toString = kotlin_kotlin.$_$.v7;
  var IllegalArgumentException_init_$Create$ = kotlin_kotlin.$_$.b1;
  var LinkedHashMap_init_$Create$ = kotlin_kotlin.$_$.q;
  var ensureNotNull = kotlin_kotlin.$_$.mb;
  var Collection = kotlin_kotlin.$_$.g2;
  var getBooleanHashCode = kotlin_kotlin.$_$.x6;
  var InputEventContext = kotlin_jabbah_draw.$_$.e6;
  var Cursor_CLICK_getInstance = kotlin_jabbah_draw.$_$.d1;
  var DrawableBagInputEventHandler = kotlin_jabbah_draw.$_$.r2;
  var Drawable = kotlin_jabbah_draw.$_$.y5;
  var DrawableBagImpl = kotlin_jabbah_draw.$_$.q2;
  var DrawableContainerImpl = kotlin_jabbah_draw.$_$.u2;
  var ArrayList_init_$Create$ = kotlin_kotlin.$_$.n;
  var toString_0 = kotlin_kotlin.$_$.tb;
  var IssueSeverity_Warning_getInstance = kotlin_jabbah_base.$_$.f3;
  var IssueSeverity_Error_getInstance = kotlin_jabbah_base.$_$.e3;
  var IssueImpl = kotlin_jabbah_base.$_$.h7;
  var AbstractModule = kotlin_jabbah_base.$_$.d7;
  var initMetadataForObject = kotlin_kotlin.$_$.i7;
  var Default_getInstance = kotlin_kotlin.$_$.f;
  var logger = kotlin_jabbah_base.$_$.q7;
  var add = kotlin_kotlin.$_$.w5;
  var Status_getInstance = kotlin_jabbah_base.$_$.a1;
  var StatusType_Small_getInstance = kotlin_jabbah_base.$_$.h3;
  var StringUtils_getInstance = kotlin_jabbah_base.$_$.b1;
  var compareTo = kotlin_kotlin.$_$.s6;
  var Comparable = kotlin_kotlin.$_$.va;
  var System_getInstance = kotlin_jabbah_base.$_$.c1;
  var PriorityQueue = kotlin_jabbah_base.$_$.d4;
  var throwUninitializedPropertyAccessException = kotlin_kotlin.$_$.t5;
  var interpolate = kotlin_jabbah_base.$_$.r6;
  var numberToInt = kotlin_kotlin.$_$.r7;
  var numberRangeToNumber = kotlin_kotlin.$_$.o7;
  var to = kotlin_kotlin.$_$.vb;
  var mapOf = kotlin_kotlin.$_$.v3;
  var downTo = kotlin_kotlin.$_$.l8;
  var SystemSpeedEvent = kotlin_jabbah_base.$_$.x6;
  var ActionListener = kotlin_jabbah_base.$_$.e5;
  var NoSuchElementException_init_$Create$ = kotlin_kotlin.$_$.h1;
  var enumEntries = kotlin_kotlin.$_$.s5;
  var noWhenBranchMatchedException = kotlin_kotlin.$_$.rb;
  //endregion
  //region block: pre-declaration
  initMetadataForInterface(ExecutionControlOutlet, 'ExecutionControlOutlet');
  initMetadataForClass(AbstractExecutionError, 'AbstractExecutionError');
  initMetadataForInterface(PauseOrResumeAction, 'PauseOrResumeAction', VOID, VOID, [Action]);
  initMetadataForClass(PauseOrResumeActionImpl$inBreakpoint$$inlined$observable$1, VOID, VOID, ObservableProperty);
  initMetadataForClass(AbstractSchedulerAction, 'AbstractSchedulerAction', VOID, AbstractAction);
  initMetadataForClass(PauseOrResumeActionImpl, 'PauseOrResumeActionImpl', VOID, AbstractSchedulerAction, [PauseOrResumeAction]);
  initMetadataForInterface(SchedulerActions, 'SchedulerActions');
  initMetadataForCompanion(Companion);
  initMetadataForClass(ExecutionDepthAction, 'ExecutionDepthAction', VOID, AbstractSchedulerAction);
  initMetadataForClass(SingleStepModeAction, 'SingleStepModeAction', VOID, AbstractSchedulerAction);
  function get_waiting() {
    return this.h4w().equals(ActorState_Waiting_getInstance());
  }
  initMetadataForInterface(Actor, 'Actor');
  initMetadataForClass(ActorState, 'ActorState', VOID, Enum);
  initMetadataForClass(SimpleActorData, 'SimpleActorData', SimpleActorData);
  initMetadataForClass(ActorHandler, 'ActorHandler', VOID, InputEventHandlerAdapter);
  initMetadataForClass(sam$io_antarescircuit_jabbah_draw_drawable_ButtonAction$0, 'sam$io_antarescircuit_jabbah_draw_drawable_ButtonAction$0', VOID, VOID, [ButtonAction, FunctionAdapter]);
  function getExecutionTooltip(context) {
    return null;
  }
  function executionStarted(signalHandler) {
  }
  function executionStartDone(signalHandler) {
  }
  function executionStopped(signalHandler) {
  }
  initMetadataForInterface(ActorView, 'ActorView');
  initMetadataForClass(ActorDrawableButton, 'ActorDrawableButton', VOID, DrawableButton, [ActorView]);
  initMetadataForClass(ActorImpl, 'ActorImpl', ActorImpl, VOID, [Actor]);
  initMetadataForClass(Entry, 'Entry');
  initMetadataForClass(ActorSupport, 'ActorSupport');
  initMetadataForClass(ActorInteractionContext, 'ActorInteractionContext', VOID, InputEventContext);
  initMetadataForClass(ClickableActorInteractionHandlerAdapter, 'ClickableActorInteractionHandlerAdapter', ClickableActorInteractionHandlerAdapter, InputEventHandlerAdapter);
  initMetadataForClass(Handler, 'Handler', VOID, DrawableBagInputEventHandler);
  initMetadataForClass(ActorViewBag, 'ActorViewBag', ActorViewBag, DrawableBagImpl, [ActorView]);
  initMetadataForClass(Handler_0, 'Handler', VOID, DrawableBagInputEventHandler);
  initMetadataForClass(ActorViewContainer, 'ActorViewContainer', ActorViewContainer, DrawableContainerImpl, [ActorView]);
  initMetadataForClass(IssueCollectorEvent, 'IssueCollectorEvent');
  initMetadataForCompanion(Companion_0);
  initMetadataForClass(IssueCollector, 'IssueCollector', IssueCollector);
  initMetadataForObject(ExecutionModule, 'ExecutionModule', VOID, AbstractModule);
  initMetadataForClass(NoiseGeneratorHolder, 'NoiseGeneratorHolder');
  initMetadataForClass(AbstractNoiseGenerator, 'AbstractNoiseGenerator');
  initMetadataForClass(NoNoiseGenerator, 'NoNoiseGenerator', NoNoiseGenerator, AbstractNoiseGenerator);
  initMetadataForClass(RandomNoiseGenerator, 'RandomNoiseGenerator', RandomNoiseGenerator, AbstractNoiseGenerator);
  initMetadataForClass(ExecutionErrorHandlerImpl, 'ExecutionErrorHandlerImpl', ExecutionErrorHandlerImpl);
  initMetadataForClass(AbstractSchedulerTask, 'AbstractSchedulerTask');
  initMetadataForClass(ManualSchedulerTask, 'ManualSchedulerTask', ManualSchedulerTask, AbstractSchedulerTask);
  initMetadataForInterface(Scheduler, 'Scheduler');
  initMetadataForCompanion(Companion_1);
  initMetadataForClass(ExecutionStepResult, 'ExecutionStepResult');
  initMetadataForClass(BreakEvent, 'BreakEvent', BreakEvent);
  initMetadataForClass(SchedulerEvent, 'SchedulerEvent');
  initMetadataForClass(SchedulerSingleStepModeEvent, 'SchedulerSingleStepModeEvent');
  initMetadataForClass(ExecutionStoppedOnIssueEvent, 'ExecutionStoppedOnIssueEvent');
  initMetadataForClass(BreakpointEvent, 'BreakpointEvent');
  initMetadataForClass(SchedulerActivationStateEvent, 'SchedulerActivationStateEvent');
  initMetadataForClass(SchedulerActivationState, 'SchedulerActivationState', VOID, Enum);
  initMetadataForClass(SchedulerActivationStatePreparationEvent, 'SchedulerActivationStatePreparationEvent');
  initMetadataForCompanion(Companion_2);
  initMetadataForClass(Slot, 'Slot', VOID, VOID, [Comparable]);
  initMetadataForClass(Request, 'Request');
  initMetadataForClass(SchedulerImpl, 'SchedulerImpl', VOID, VOID, [Scheduler]);
  initMetadataForCompanion(Companion_3);
  initMetadataForClass(TimedSchedulerTask, 'TimedSchedulerTask', VOID, AbstractSchedulerTask, [ActionListener]);
  initMetadataForCompanion(Companion_4);
  initMetadataForClass(CurrentSystemSpeedCategory, 'CurrentSystemSpeedCategory');
  initMetadataForCompanion(Companion_5);
  initMetadataForClass(SystemSpeedCategory, 'SystemSpeedCategory', VOID, Enum);
  initMetadataForClass(SystemSpeedCategoryEvent, 'SystemSpeedCategoryEvent');
  //endregion
  function ExecutionControlOutlet() {
  }
  function getAge($this, executionTime) {
    return subtract(executionTime, $this.s4t());
  }
  function AbstractExecutionError(creationTime, gracePeriod) {
    gracePeriod = gracePeriod === VOID ? 0 : gracePeriod;
    this.q4t_1 = creationTime;
    this.r4t_1 = gracePeriod;
  }
  protoOf(AbstractExecutionError).s4t = function () {
    return this.q4t_1;
  };
  protoOf(AbstractExecutionError).t4t = function (executionTime) {
    return getAge(this, executionTime) > fromInt(this.r4t_1);
  };
  function PauseOrResumeAction() {
  }
  function get_PROP_PAUSE_OR_RESUME_ACTION_IN_BREAKPOINT() {
    return PROP_PAUSE_OR_RESUME_ACTION_IN_BREAKPOINT;
  }
  var PROP_PAUSE_OR_RESUME_ACTION_IN_BREAKPOINT;
  function _set_inBreakpoint__gvmw2n($this, _set____db54di) {
    var tmp = KMutableProperty1;
    var tmp_0 = PauseOrResumeActionImpl$_get_inBreakpoint_$ref_9loc0k_0();
    return $this.k4u_1.yf($this, getPropertyCallableRef('inBreakpoint', 1, tmp, tmp_0, PauseOrResumeActionImpl$_set_inBreakpoint_$ref_wcbgvs_0()), _set____db54di);
  }
  function updateSelected($this) {
    $this.rq($this.g4u_1.l4u() && $this.g4u_1.q4u().m4u_1.b1o_1);
    updateDescription($this);
  }
  function updateDescription($this) {
    var tmp;
    if ($this.selected) {
      var tmp_0;
      if ($this.inBreakpoint) {
        tmp_0 = 'execution.action.resumeFromBreakpoint';
      } else {
        tmp_0 = 'execution.action.resume';
      }
      tmp = tmp_0;
    } else {
      tmp = 'execution.action.pause';
    }
    var baseName = tmp;
    $this.kq(Translations_getInstance().bn(baseName + '.name', []));
    $this.lq(Translations_getInstance().bn(baseName + '.desc', []));
  }
  function updateState($this) {
    $this.pq($this.g4u_1.l4u());
  }
  function updateInBreakpoint($this) {
    _set_inBreakpoint__gvmw2n($this, $this.g4u_1.r4u());
    updateDescription($this);
  }
  function PauseOrResumeActionImpl$pausedHandler$lambda(this$0) {
    return function (it) {
      var tmp;
      if (it.j1o_1 === this$0.g4u_1.q4u().m4u_1) {
        updateSelected(this$0);
        tmp = Unit_instance;
      }
      return Unit_instance;
    };
  }
  function PauseOrResumeActionImpl$schedulerActivationStateHandler$lambda(this$0) {
    return function (it) {
      var tmp;
      if (it.s4u_1 === this$0.g4u_1) {
        updateState(this$0);
        updateSelected(this$0);
        tmp = Unit_instance;
      }
      return Unit_instance;
    };
  }
  function PauseOrResumeActionImpl$breakpointHandler$lambda(this$0) {
    return function (it) {
      var tmp;
      if (it.t4u_1 === this$0.g4u_1) {
        updateInBreakpoint(this$0);
        tmp = Unit_instance;
      }
      return Unit_instance;
    };
  }
  function PauseOrResumeActionImpl$inBreakpoint$$inlined$observable$1($initialValue, this$0) {
    this.v4u_1 = this$0;
    ObservableProperty.call(this, $initialValue);
  }
  protoOf(PauseOrResumeActionImpl$inBreakpoint$$inlined$observable$1).cr = function (property, oldValue, newValue) {
    this.v4u_1.kr_1.nr('inBreakpoint', oldValue, newValue);
    return Unit_instance;
  };
  protoOf(PauseOrResumeActionImpl$inBreakpoint$$inlined$observable$1).uf = function (property, oldValue, newValue) {
    return this.cr(property, oldValue, newValue);
  };
  function PauseOrResumeActionImpl$_get_inBreakpoint_$ref_9loc0k() {
    return function (p0) {
      return p0.inBreakpoint;
    };
  }
  function PauseOrResumeActionImpl$_set_inBreakpoint_$ref_wcbgvs() {
    return function (p0, p1) {
      _set_inBreakpoint__gvmw2n(p0, p1);
      return Unit_instance;
    };
  }
  function PauseOrResumeActionImpl$_get_inBreakpoint_$ref_9loc0k_0() {
    return function (p0) {
      return p0.inBreakpoint;
    };
  }
  function PauseOrResumeActionImpl$_set_inBreakpoint_$ref_wcbgvs_0() {
    return function (p0, p1) {
      _set_inBreakpoint__gvmw2n(p0, p1);
      return Unit_instance;
    };
  }
  function PauseOrResumeActionImpl(scheduler, eventBus) {
    eventBus = eventBus === VOID ? BaseModule_getInstance().bp_1 : eventBus;
    AbstractSchedulerAction.call(this, 'execution.action.pause', eventBus);
    this.g4u_1 = scheduler;
    var tmp = this;
    tmp.h4u_1 = PauseOrResumeActionImpl$pausedHandler$lambda(this);
    var tmp_0 = this;
    tmp_0.i4u_1 = PauseOrResumeActionImpl$schedulerActivationStateHandler$lambda(this);
    var tmp_1 = this;
    tmp_1.j4u_1 = PauseOrResumeActionImpl$breakpointHandler$lambda(this);
    var tmp_2 = this;
    // Inline function 'kotlin.properties.Delegates.observable' call
    tmp_2.k4u_1 = new PauseOrResumeActionImpl$inBreakpoint$$inlined$observable$1(false, this);
    eventBus.z17(getKClass(SystemSpeedPauseEvent), this.h4u_1);
    eventBus.z17(getKClass(SchedulerActivationStateEvent), this.i4u_1);
    eventBus.z17(getKClass(BreakpointEvent), this.j4u_1);
    updateState(this);
    updateSelected(this);
    updateInBreakpoint(this);
  }
  protoOf(PauseOrResumeActionImpl).w4t = function () {
    var tmp = KMutableProperty1;
    var tmp_0 = PauseOrResumeActionImpl$_get_inBreakpoint_$ref_9loc0k();
    return this.k4u_1.wf(this, getPropertyCallableRef('inBreakpoint', 1, tmp, tmp_0, PauseOrResumeActionImpl$_set_inBreakpoint_$ref_wcbgvs()));
  };
  protoOf(PauseOrResumeActionImpl).dispose = function () {
    protoOf(AbstractSchedulerAction).dispose.call(this);
    this.e4v_1.b18(this.h4u_1);
    this.e4v_1.b18(this.i4u_1);
    this.e4v_1.b18(this.j4u_1);
  };
  protoOf(PauseOrResumeActionImpl).execute = function (event) {
    if (this.g4u_1.q4u().m4u_1.b1o_1) {
      this.g4u_1.q4u().m4u_1.f1o();
    } else {
      this.g4u_1.q4u().m4u_1.e1o();
    }
  };
  function SchedulerActions() {
  }
  function Companion() {
    this.g4v_1 = 'execution.scheduler.deepExecution';
  }
  var Companion_instance;
  function Companion_getInstance_1() {
    return Companion_instance;
  }
  function updateState_0($this) {
    $this.rq($this.q4v_1.s4v());
    $this.pq(!$this.q4v_1.l4u());
  }
  function ExecutionDepthAction$schedulerActivationStateHandler$lambda(this$0) {
    return function (it) {
      var tmp;
      if (it.s4u_1 === this$0.q4v_1) {
        updateState_0(this$0);
        tmp = Unit_instance;
      }
      return Unit_instance;
    };
  }
  function ExecutionDepthAction(scheduler, eventBus) {
    eventBus = eventBus === VOID ? BaseModule_getInstance().bp_1 : eventBus;
    AbstractSchedulerAction.call(this, 'execution.action.deepSimulation', eventBus);
    this.q4v_1 = scheduler;
    var tmp = this;
    tmp.r4v_1 = ExecutionDepthAction$schedulerActivationStateHandler$lambda(this);
    this.q4v_1.t4v(BaseModule_getInstance().ap_1.ut('execution.scheduler.deepExecution', true));
    eventBus.z17(getKClass(SchedulerActivationStateEvent), this.r4v_1);
    updateState_0(this);
  }
  protoOf(ExecutionDepthAction).dispose = function () {
    protoOf(AbstractSchedulerAction).dispose.call(this);
    this.e4v_1.b18(this.r4v_1);
    BaseModule_getInstance().ap_1.et('execution.scheduler.deepExecution', this.q4v_1.s4v());
  };
  protoOf(ExecutionDepthAction).execute = function (event) {
    this.q4v_1.t4v(this.selected);
  };
  function updateState_1($this) {
    $this.rq($this.d4w_1.f4w());
  }
  function SingleStepModeAction$schedulerSingleStepModeHandler$lambda(this$0) {
    return function (it) {
      updateState_1(this$0);
      return Unit_instance;
    };
  }
  function SingleStepModeAction(scheduler, eventBus) {
    eventBus = eventBus === VOID ? BaseModule_getInstance().bp_1 : eventBus;
    AbstractSchedulerAction.call(this, 'execution.action.singleStepMode', eventBus);
    this.d4w_1 = scheduler;
    var tmp = this;
    tmp.e4w_1 = SingleStepModeAction$schedulerSingleStepModeHandler$lambda(this);
    eventBus.z17(getKClass(SchedulerSingleStepModeEvent), this.e4w_1);
    updateState_1(this);
  }
  protoOf(SingleStepModeAction).dispose = function () {
    protoOf(AbstractSchedulerAction).dispose.call(this);
    this.e4v_1.b18(this.e4w_1);
  };
  protoOf(SingleStepModeAction).execute = function (event) {
    this.d4w_1.g4w(!this.d4w_1.f4w());
  };
  function AbstractSchedulerAction(name, eventBus) {
    AbstractAction_init_$Init$(name, VOID, VOID, this);
    this.e4v_1 = eventBus;
  }
  function Actor() {
  }
  var ActorState_NonExecuting_instance;
  var ActorState_Idle_instance;
  var ActorState_Waiting_instance;
  var ActorState_Acting_instance;
  var ActorState_entriesInitialized;
  function ActorState_initEntries() {
    if (ActorState_entriesInitialized)
      return Unit_instance;
    ActorState_entriesInitialized = true;
    ActorState_NonExecuting_instance = new ActorState('NonExecuting', 0);
    ActorState_Idle_instance = new ActorState('Idle', 1);
    ActorState_Waiting_instance = new ActorState('Waiting', 2);
    ActorState_Acting_instance = new ActorState('Acting', 3);
  }
  function ActorState(name, ordinal) {
    Enum.call(this, name, ordinal);
  }
  function ActorState_NonExecuting_getInstance() {
    ActorState_initEntries();
    return ActorState_NonExecuting_instance;
  }
  function ActorState_Idle_getInstance() {
    ActorState_initEntries();
    return ActorState_Idle_instance;
  }
  function ActorState_Waiting_getInstance() {
    ActorState_initEntries();
    return ActorState_Waiting_instance;
  }
  function ActorState_Acting_getInstance() {
    ActorState_initEntries();
    return ActorState_Acting_instance;
  }
  function SimpleActorData(data) {
    data = data === VOID ? null : data;
    this.w4w_1 = data;
  }
  protoOf(SimpleActorData).x4w = function () {
    return this.w4w_1;
  };
  function ActorDrawableButton_init_$Init$(location, tooltipKey, styleType, styleProvider, actorAction, renderer, round, $this) {
    tooltipKey = tooltipKey === VOID ? null : tooltipKey;
    styleType = styleType === VOID ? Companion_getInstance().c1y_1 : styleType;
    styleProvider = styleProvider === VOID ? DrawStyleModule_getInstance().w1x_1 : styleProvider;
    round = round === VOID ? false : round;
    ActorDrawableButton.call($this, location, tooltipKey, new StylableImpl(VOID, styleType, styleProvider), actorAction, renderer, round);
    return $this;
  }
  function ActorDrawableButton_init_$Create$(location, tooltipKey, styleType, styleProvider, actorAction, renderer, round) {
    return ActorDrawableButton_init_$Init$(location, tooltipKey, styleType, styleProvider, actorAction, renderer, round, objectCreate(protoOf(ActorDrawableButton)));
  }
  function ActorHandler($outer) {
    this.z4w_1 = $outer;
    InputEventHandlerAdapter.call(this);
  }
  protoOf(ActorHandler).a4x = function (context) {
    return this.z4w_1.i2f(context.t22_1) ? this : null;
  };
  protoOf(ActorHandler).z22 = function (context) {
    return this.a4x(context instanceof ActorInteractionContext ? context : THROW_CCE());
  };
  protoOf(ActorHandler).b4x = function (context) {
    if (this.z4w_1.f2f_1) {
      this.z4w_1.o4x_1.r2e(context);
    }
    return null;
  };
  protoOf(ActorHandler).a23 = function (context) {
    return this.b4x(context instanceof ActorInteractionContext ? context : THROW_CCE());
  };
  function sam$io_antarescircuit_jabbah_draw_drawable_ButtonAction$0(function_0) {
    this.q4x_1 = function_0;
  }
  protoOf(sam$io_antarescircuit_jabbah_draw_drawable_ButtonAction$0).r2e = function (context) {
    return this.q4x_1(context);
  };
  protoOf(sam$io_antarescircuit_jabbah_draw_drawable_ButtonAction$0).p2 = function () {
    return this.q4x_1;
  };
  protoOf(sam$io_antarescircuit_jabbah_draw_drawable_ButtonAction$0).equals = function (other) {
    var tmp;
    if (!(other == null) ? isInterface(other, ButtonAction) : false) {
      var tmp_0;
      if (!(other == null) ? isInterface(other, FunctionAdapter) : false) {
        tmp_0 = equals(this.p2(), other.p2());
      } else {
        tmp_0 = false;
      }
      tmp = tmp_0;
    } else {
      tmp = false;
    }
    return tmp;
  };
  protoOf(sam$io_antarescircuit_jabbah_draw_drawable_ButtonAction$0).hashCode = function () {
    return hashCode(this.p2());
  };
  function ActorDrawableButton$_init_$lambda_l5d9iy(it) {
    return Unit_instance;
  }
  function ActorDrawableButton(location, tooltipKey, stylable, actorAction, renderer, round) {
    location = location === VOID ? Companion_getInstance_0().w1a_1 : location;
    tooltipKey = tooltipKey === VOID ? null : tooltipKey;
    round = round === VOID ? false : round;
    var tmp = ActorDrawableButton$_init_$lambda_l5d9iy;
    DrawableButton.call(this, location, tooltipKey, stylable, new sam$io_antarescircuit_jabbah_draw_drawable_ButtonAction$0(tmp), renderer, VOID, round);
    this.o4x_1 = actorAction;
    this.p4x_1 = this.r4x();
  }
  protoOf(ActorDrawableButton).s4x = function (context) {
    return this.p4x_1;
  };
  protoOf(ActorDrawableButton).t4x = function (context) {
    return this.o20(context);
  };
  protoOf(ActorDrawableButton).r4x = function () {
    return new ActorHandler(this);
  };
  function _get_actorSupport__ng3drl($this) {
    var tmp0 = $this.x4x_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('actorSupport', 1, tmp, ActorImpl$_get_actorSupport_$ref_7khzjl(), null);
    return tmp0.j2();
  }
  function ActorImpl$actorSupport$delegate$lambda(this$0) {
    return function () {
      return new ActorSupport(this$0);
    };
  }
  function ActorImpl$_get_actorSupport_$ref_7khzjl() {
    return function (p0) {
      return _get_actorSupport__ng3drl(p0);
    };
  }
  function ActorImpl(id, propagationDelay) {
    id = id === VOID ? 0 : id;
    propagationDelay = propagationDelay === VOID ? 0n : propagationDelay;
    this.w4x_1 = id;
    var tmp = this;
    tmp.x4x_1 = lazy(ActorImpl$actorSupport$delegate$lambda(this));
    this.y4x_1 = false;
    this.z4x_1 = ActorState_NonExecuting_getInstance();
    this.a4y_1 = new LongValueImpl(propagationDelay);
    this.b4y_1 = null;
  }
  protoOf(ActorImpl).cv = function () {
    return this.w4x_1;
  };
  protoOf(ActorImpl).l4w = function (value) {
    // Inline function 'kotlin.require' call
    if (!(value.j2() >= 0n)) {
      var message = 'Propagation delay must be greater than 0';
      throw IllegalArgumentException_init_$Create$(toString(message));
    }
    this.a4y_1 = value;
  };
  protoOf(ActorImpl).m4w = function () {
    return this.a4y_1;
  };
  protoOf(ActorImpl).j4w = function (_set____db54di) {
    this.b4y_1 = _set____db54di;
  };
  protoOf(ActorImpl).k4w = function () {
    return this.b4y_1;
  };
  protoOf(ActorImpl).h4w = function () {
    return this.z4x_1;
  };
  protoOf(ActorImpl).n4w = function () {
    return _get_actorSupport__ng3drl(this).e4y();
  };
  protoOf(ActorImpl).o4w = function (l) {
    _get_actorSupport__ng3drl(this).f4y(l);
  };
  protoOf(ActorImpl).p4w = function (l) {
    _get_actorSupport__ng3drl(this).g4y(l);
  };
  protoOf(ActorImpl).q4w = function (signalHandler) {
    this.y4x_1 = true;
  };
  protoOf(ActorImpl).r4w = function (signalHandler) {
    this.z4x_1 = ActorState_Idle_getInstance();
    this.j4w(null);
  };
  protoOf(ActorImpl).s4w = function (signalHandler, data) {
    this.z4x_1 = ActorState_Acting_getInstance();
    _get_actorSupport__ng3drl(this).h4y(signalHandler, data);
  };
  protoOf(ActorImpl).t4w = function (signalHandler, l, data) {
    _get_actorSupport__ng3drl(this).t4w(signalHandler, l, data);
  };
  protoOf(ActorImpl).u4w = function (signalHandler, data) {
    this.z4x_1 = ActorState_Idle_getInstance();
  };
  protoOf(ActorImpl).v4w = function (signalHandler) {
    this.j4w(null);
    this.z4x_1 = ActorState_NonExecuting_getInstance();
    this.y4x_1 = false;
  };
  protoOf(ActorImpl).i4y = function (signalHandler, delay, data) {
    this.z4x_1 = ActorState_Waiting_getInstance();
    _get_actorSupport__ng3drl(this).i4y(signalHandler, delay, data);
  };
  function ensureEntry($this, l) {
    if ($this.d4y_1 == null) {
      var tmp = $this;
      // Inline function 'kotlin.collections.mutableMapOf' call
      tmp.d4y_1 = LinkedHashMap_init_$Create$();
    }
    // Inline function 'kotlin.collections.getOrPut' call
    var this_0 = ensureNotNull($this.d4y_1);
    var value = this_0.g2(l);
    var tmp_0;
    if (value == null) {
      var answer = new Entry(l);
      this_0.y1(l, answer);
      tmp_0 = answer;
    } else {
      tmp_0 = value;
    }
    return tmp_0;
  }
  function allDone($this) {
    if ($this.d4y_1 == null) {
      return true;
    }
    var tmp0 = ensureNotNull($this.d4y_1).c2();
    var tmp$ret$0;
    $l$block_0: {
      // Inline function 'kotlin.collections.all' call
      var tmp;
      if (isInterface(tmp0, Collection)) {
        tmp = tmp0.m();
      } else {
        tmp = false;
      }
      if (tmp) {
        tmp$ret$0 = true;
        break $l$block_0;
      }
      var _iterator__ex2g4s = tmp0.i();
      while (_iterator__ex2g4s.j()) {
        var element = _iterator__ex2g4s.k();
        if (!!element.k4y_1) {
          tmp$ret$0 = false;
          break $l$block_0;
        }
      }
      tmp$ret$0 = true;
    }
    return tmp$ret$0;
  }
  function notifyActingRequested($this, signalHandler, data) {
    var tmp0_safe_receiver = $this.d4y_1;
    if (tmp0_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.collections.forEach' call
      // Inline function 'kotlin.collections.iterator' call
      var _iterator__ex2g4s = tmp0_safe_receiver.d2().i();
      while (_iterator__ex2g4s.j()) {
        var element = _iterator__ex2g4s.k();
        element.j2().k4y_1 = false;
        element.i2().l4y($this.c4y_1, signalHandler, data);
      }
    }
  }
  function Entry(listener, isPending) {
    isPending = isPending === VOID ? false : isPending;
    this.j4y_1 = listener;
    this.k4y_1 = isPending;
  }
  protoOf(Entry).toString = function () {
    return 'Entry(listener=' + toString(this.j4y_1) + ', isPending=' + this.k4y_1 + ')';
  };
  protoOf(Entry).hashCode = function () {
    var result = hashCode(this.j4y_1);
    result = imul(result, 31) + getBooleanHashCode(this.k4y_1) | 0;
    return result;
  };
  protoOf(Entry).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof Entry))
      return false;
    if (!equals(this.j4y_1, other.j4y_1))
      return false;
    if (!(this.k4y_1 === other.k4y_1))
      return false;
    return true;
  };
  function ActorSupport(actor) {
    this.c4y_1 = actor;
    this.d4y_1 = null;
  }
  protoOf(ActorSupport).e4y = function () {
    var tmp;
    if (!(this.d4y_1 == null)) {
      // Inline function 'kotlin.collections.isNotEmpty' call
      tmp = !ensureNotNull(this.d4y_1).m();
    } else {
      tmp = false;
    }
    return tmp;
  };
  protoOf(ActorSupport).f4y = function (l) {
    ensureEntry(this, l);
  };
  protoOf(ActorSupport).g4y = function (l) {
    var tmp0_safe_receiver = this.d4y_1;
    if (tmp0_safe_receiver == null)
      null;
    else
      tmp0_safe_receiver.z1(l);
  };
  protoOf(ActorSupport).i4y = function (signalHandler, delay, data) {
    signalHandler.m4y(this.c4y_1, delay, data);
    notifyActingRequested(this, signalHandler, data);
  };
  protoOf(ActorSupport).h4y = function (signalHandler, data) {
    var tmp;
    if (!(this.d4y_1 == null)) {
      // Inline function 'kotlin.collections.isNotEmpty' call
      tmp = !ensureNotNull(this.d4y_1).m();
    } else {
      tmp = false;
    }
    if (tmp) {
      var tmp0_safe_receiver = this.d4y_1;
      if (tmp0_safe_receiver == null)
        null;
      else {
        // Inline function 'kotlin.collections.forEach' call
        // Inline function 'kotlin.collections.iterator' call
        var _iterator__ex2g4s = tmp0_safe_receiver.d2().i();
        while (_iterator__ex2g4s.j()) {
          var element = _iterator__ex2g4s.k();
          element.j2().k4y_1 = true;
          element.i2().o4y(this.c4y_1, signalHandler, data);
        }
      }
    } else {
      signalHandler.n4y(this.c4y_1, data);
    }
  };
  protoOf(ActorSupport).t4w = function (signalHandler, l, data) {
    if (!(this.d4y_1 == null)) {
      ensureEntry(this, l).k4y_1 = false;
    }
    if (allDone(this)) {
      signalHandler.n4y(this.c4y_1, data);
    }
  };
  function ActorInteractionContext(signalHandler, view, mouseEvent, keyEvent, x, y) {
    mouseEvent = mouseEvent === VOID ? null : mouseEvent;
    keyEvent = keyEvent === VOID ? null : keyEvent;
    x = x === VOID ? 0.0 : x;
    y = y === VOID ? 0.0 : y;
    InputEventContext.call(this, view, mouseEvent, keyEvent, x, y);
    this.w4y_1 = signalHandler;
  }
  protoOf(ActorInteractionContext).v22 = function (x, y) {
    return new ActorInteractionContext(this.w4y_1, this.n22_1, this.o22_1, this.p22_1, x, y);
  };
  function ClickableActorInteractionHandlerAdapter() {
    InputEventHandlerAdapter.call(this);
  }
  protoOf(ClickableActorInteractionHandlerAdapter).a4x = function (context) {
    context.n22_1.l1y(Cursor_CLICK_getInstance());
    return null;
  };
  protoOf(ClickableActorInteractionHandlerAdapter).z22 = function (context) {
    return this.a4x(context instanceof ActorInteractionContext ? context : THROW_CCE());
  };
  function ActorView() {
  }
  function Handler($outer) {
    this.b4z_1 = $outer;
    DrawableBagInputEventHandler.call(this);
  }
  protoOf(Handler).j21 = function (location) {
    var tmp = this.b4z_1.i4z(location);
    return (tmp == null ? true : isInterface(tmp, Drawable)) ? tmp : THROW_CCE();
  };
  protoOf(Handler).j4z = function (drawable, context) {
    var tmp;
    if (isInterface(drawable, ActorView)) {
      tmp = drawable.s4x(context);
    } else {
      tmp = protoOf(DrawableBagInputEventHandler).r28.call(this, drawable, context);
    }
    return tmp;
  };
  protoOf(Handler).r28 = function (drawable, context) {
    return this.j4z(drawable, context instanceof ActorInteractionContext ? context : THROW_CCE());
  };
  function ActorViewBag$getActorViewAt$lambda(it) {
    return isInterface(it, ActorView);
  }
  function ActorViewBag(location, useLocation) {
    location = location === VOID ? Companion_getInstance_0().w1a_1 : location;
    useLocation = useLocation === VOID ? false : useLocation;
    DrawableBagImpl.call(this, location, useLocation);
    this.g4z_1 = useLocation;
    this.h4z_1 = this.k4z();
  }
  protoOf(ActorViewBag).t20 = function () {
    return this.g4z_1;
  };
  protoOf(ActorViewBag).s4x = function (context) {
    this.h4z_1.x28(this);
    return this.h4z_1;
  };
  protoOf(ActorViewBag).t4x = function (context) {
    var p = context.t22_1;
    if (this.t20()) {
      var tmp0_safe_receiver = this.i4z(p);
      return tmp0_safe_receiver == null ? null : tmp0_safe_receiver.t4x(context.u22(p.j1h(this.jw())));
    }
    var tmp1_safe_receiver = this.i4z(p);
    return tmp1_safe_receiver == null ? null : tmp1_safe_receiver.t4x(context);
  };
  protoOf(ActorViewBag).u4x = function (signalHandler) {
  };
  protoOf(ActorViewBag).v4w = function (signalHandler) {
  };
  protoOf(ActorViewBag).k4z = function () {
    return new Handler(this);
  };
  protoOf(ActorViewBag).i4z = function (pos) {
    var tmp = this.f21(pos.kn_1, pos.ln_1, ActorViewBag$getActorViewAt$lambda);
    return (tmp == null ? true : isInterface(tmp, ActorView)) ? tmp : THROW_CCE();
  };
  function getActorViewAt($this, pos) {
    var tmp = $this.f21(pos.kn_1, pos.ln_1, ActorViewContainer$getActorViewAt$lambda);
    return (tmp == null ? true : isInterface(tmp, ActorView)) ? tmp : THROW_CCE();
  }
  function Handler_0($outer) {
    this.o4z_1 = $outer;
    DrawableBagInputEventHandler.call(this);
  }
  protoOf(Handler_0).j21 = function (location) {
    var tmp = getActorViewAt(this.o4z_1, location);
    return (tmp == null ? true : isInterface(tmp, Drawable)) ? tmp : THROW_CCE();
  };
  protoOf(Handler_0).j4z = function (drawable, context) {
    var tmp;
    if (isInterface(drawable, ActorView)) {
      tmp = drawable.s4x(context);
    } else {
      tmp = protoOf(DrawableBagInputEventHandler).r28.call(this, drawable, context);
    }
    return tmp;
  };
  protoOf(Handler_0).r28 = function (drawable, context) {
    return this.j4z(drawable, context instanceof ActorInteractionContext ? context : THROW_CCE());
  };
  function ActorViewContainer$getActorViewAt$lambda(it) {
    return isInterface(it, ActorView);
  }
  function ActorViewContainer(location, useLocation) {
    location = location === VOID ? Companion_getInstance_0().w1a_1 : location;
    useLocation = useLocation === VOID ? false : useLocation;
    DrawableContainerImpl.call(this, location, useLocation);
    this.c50_1 = new Handler_0(this);
  }
  protoOf(ActorViewContainer).s4x = function (context) {
    this.c50_1.x28(this);
    return this.c50_1;
  };
  protoOf(ActorViewContainer).t4x = function (context) {
    var p = context.t22_1;
    if (this.t20()) {
      var tmp0_safe_receiver = getActorViewAt(this, p);
      return tmp0_safe_receiver == null ? null : tmp0_safe_receiver.t4x(context.u22(p.j1h(this.jw())));
    }
    var tmp1_safe_receiver = getActorViewAt(this, p);
    return tmp1_safe_receiver == null ? null : tmp1_safe_receiver.t4x(context);
  };
  protoOf(ActorViewContainer).u4x = function (signalHandler) {
    // Inline function 'kotlin.collections.filterIsInstance' call
    var tmp0 = this.u20();
    // Inline function 'kotlin.collections.filterIsInstanceTo' call
    var destination = ArrayList_init_$Create$();
    var _iterator__ex2g4s = tmp0.i();
    while (_iterator__ex2g4s.j()) {
      var element = _iterator__ex2g4s.k();
      if (!(element == null) ? isInterface(element, ActorView) : false) {
        destination.h(element);
      }
    }
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s_0 = destination.i();
    while (_iterator__ex2g4s_0.j()) {
      var element_0 = _iterator__ex2g4s_0.k();
      element_0.u4x(signalHandler);
    }
  };
  protoOf(ActorViewContainer).v4w = function (signalHandler) {
    // Inline function 'kotlin.collections.filterIsInstance' call
    var tmp0 = this.u20();
    // Inline function 'kotlin.collections.filterIsInstanceTo' call
    var destination = ArrayList_init_$Create$();
    var _iterator__ex2g4s = tmp0.i();
    while (_iterator__ex2g4s.j()) {
      var element = _iterator__ex2g4s.k();
      if (!(element == null) ? isInterface(element, ActorView) : false) {
        destination.h(element);
      }
    }
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s_0 = destination.i();
    while (_iterator__ex2g4s_0.j()) {
      var element_0 = _iterator__ex2g4s_0.k();
      element_0.v4w(signalHandler);
    }
  };
  function IssueCollectorEvent(issueCollector, issue) {
    this.d50_1 = issueCollector;
    this.e50_1 = issue;
  }
  protoOf(IssueCollectorEvent).toString = function () {
    return 'IssueCollectorEvent(issueCollector=' + toString(this.d50_1) + ', issue=' + toString_0(this.e50_1) + ')';
  };
  protoOf(IssueCollectorEvent).hashCode = function () {
    var result = hashCode(this.d50_1);
    result = imul(result, 31) + (this.e50_1 == null ? 0 : hashCode(this.e50_1)) | 0;
    return result;
  };
  protoOf(IssueCollectorEvent).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof IssueCollectorEvent))
      return false;
    if (!equals(this.d50_1, other.d50_1))
      return false;
    if (!equals(this.e50_1, other.e50_1))
      return false;
    return true;
  };
  function Companion_0() {
    this.f50_1 = 'execution.issues.maxCount';
  }
  var Companion_instance_0;
  function Companion_getInstance_2() {
    return Companion_instance_0;
  }
  function _get_maxIssuesCount__godqyi($this) {
    return BaseModule_getInstance().zo_1.kt('execution.issues.maxCount');
  }
  function hasIssueWithSeverity($this, severity) {
    var tmp0 = $this.j50();
    var tmp$ret$0;
    $l$block_0: {
      // Inline function 'kotlin.collections.any' call
      var tmp;
      if (isInterface(tmp0, Collection)) {
        tmp = tmp0.m();
      } else {
        tmp = false;
      }
      if (tmp) {
        tmp$ret$0 = false;
        break $l$block_0;
      }
      var _iterator__ex2g4s = tmp0.i();
      while (_iterator__ex2g4s.j()) {
        var element = _iterator__ex2g4s.k();
        if (element.ss().equals(severity)) {
          tmp$ret$0 = true;
          break $l$block_0;
        }
      }
      tmp$ret$0 = false;
    }
    return tmp$ret$0;
  }
  function handleNewIssue($this, issue) {
    if ($this.o() < _get_maxIssuesCount__godqyi($this)) {
      $this.h50_1.h(issue);
      updateMaximumSeverity($this);
    }
    $this.g50_1.gu(new IssueCollectorEvent($this, issue));
  }
  function updateMaximumSeverity($this) {
    $this.i50_1 = $this.j50().m() ? null : hasIssueWithSeverity($this, IssueSeverity_Error_getInstance()) ? IssueSeverity_Error_getInstance() : IssueSeverity_Warning_getInstance();
  }
  function IssueCollector$lambda(this$0) {
    return function (it) {
      var tmp;
      if (it.s4u_1.l4u()) {
        this$0.a2();
        tmp = Unit_instance;
      }
      return Unit_instance;
    };
  }
  function IssueCollector$lambda_0(this$0) {
    return function (it) {
      handleNewIssue(this$0, it);
      return Unit_instance;
    };
  }
  function IssueCollector(clearOnExecutionStart, eventBus) {
    clearOnExecutionStart = clearOnExecutionStart === VOID ? true : clearOnExecutionStart;
    eventBus = eventBus === VOID ? BaseModule_getInstance().bp_1 : eventBus;
    this.g50_1 = eventBus;
    if (clearOnExecutionStart) {
      var tmp = getKClass(SchedulerActivationStateEvent);
      this.g50_1.z17(tmp, IssueCollector$lambda(this));
    }
    var tmp_0 = getKClass(IssueImpl);
    this.g50_1.z17(tmp_0, IssueCollector$lambda_0(this));
    var tmp_1 = this;
    // Inline function 'kotlin.collections.mutableListOf' call
    tmp_1.h50_1 = ArrayList_init_$Create$();
    this.i50_1 = null;
  }
  protoOf(IssueCollector).o = function () {
    return this.h50_1.o();
  };
  protoOf(IssueCollector).j50 = function () {
    return this.h50_1;
  };
  protoOf(IssueCollector).a2 = function () {
    this.h50_1.a2();
    updateMaximumSeverity(this);
    this.g50_1.gu(new IssueCollectorEvent(this, null));
  };
  function fillProperties($this, properties) {
    properties.et('execution.scheduler.eventSystemSpeedLimit', SystemSpeedCategory_Observe_getInstance().m50_1);
    properties.et('execution.issues.maxCount', 100);
    properties.et('TimedSchedulerTask.slowDownFactor', 4.0);
  }
  function ExecutionModule$noiseGeneratorHolder$delegate$lambda() {
    return new NoiseGeneratorHolder(ExecutionModule_getInstance().p50_1);
  }
  function ExecutionModule$_get_noiseGeneratorHolder_$ref_4lmy23() {
    return function (p0) {
      return p0.u50();
    };
  }
  function ExecutionModule$schedulerTaskFactory$lambda(speedCategory, eventBus) {
    return new TimedSchedulerTask(speedCategory, VOID, eventBus);
  }
  function ExecutionModule() {
    ExecutionModule_instance = this;
    AbstractModule.call(this);
    this.p50_1 = new NoNoiseGenerator();
    this.q50_1 = new RandomNoiseGenerator();
    var tmp = this;
    tmp.r50_1 = lazy(ExecutionModule$noiseGeneratorHolder$delegate$lambda);
    var tmp_0 = this;
    tmp_0.s50_1 = ExecutionModule$schedulerTaskFactory$lambda;
    var tmp_1 = this;
    var tmp0_eventBus = BaseModule_getInstance().bp_1;
    tmp_1.t50_1 = new IssueCollector(true, tmp0_eventBus);
  }
  protoOf(ExecutionModule).u50 = function () {
    var tmp0 = this.r50_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('noiseGeneratorHolder', 1, tmp, ExecutionModule$_get_noiseGeneratorHolder_$ref_4lmy23(), null);
    return tmp0.j2();
  };
  protoOf(ExecutionModule).to = function () {
    BaseModule_getInstance().vo();
    fillProperties(this, BaseModule_getInstance().zo_1);
    Translations_getInstance().wm('jabbah-execution');
  };
  var ExecutionModule_instance;
  function ExecutionModule_getInstance() {
    if (ExecutionModule_instance == null)
      new ExecutionModule();
    return ExecutionModule_instance;
  }
  function NoiseGeneratorHolder(current, eventBus) {
    eventBus = eventBus === VOID ? BaseModule_getInstance().bp_1 : eventBus;
    this.v50_1 = eventBus;
    this.w50_1 = current;
  }
  function NoNoiseGenerator() {
    AbstractNoiseGenerator.call(this, 'execution.noiseGenerator.none');
  }
  protoOf(NoNoiseGenerator).y50 = function (bound) {
    return 0;
  };
  function AbstractNoiseGenerator(nameKey) {
    this.z50_1 = nameKey;
  }
  function RandomNoiseGenerator() {
    AbstractNoiseGenerator.call(this, 'execution.noiseGenerator.random');
  }
  protoOf(RandomNoiseGenerator).y50 = function (bound) {
    return Default_getInstance().cg(0, bound);
  };
  function ExecutionErrorHandlerImpl() {
    var tmp = this;
    // Inline function 'kotlin.collections.mutableListOf' call
    tmp.b51_1 = ArrayList_init_$Create$();
  }
  protoOf(ExecutionErrorHandlerImpl).c51 = function (error) {
    this.b51_1.h(error);
  };
  protoOf(ExecutionErrorHandlerImpl).du = function () {
    this.b51_1.a2();
  };
  protoOf(ExecutionErrorHandlerImpl).d51 = function (force, signalHandler) {
    if (this.b51_1.m()) {
      return Unit_instance;
    }
    // Inline function 'kotlin.collections.mutableListOf' call
    var toRemove = ArrayList_init_$Create$();
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = this.b51_1.i();
    while (_iterator__ex2g4s.j()) {
      var element = _iterator__ex2g4s.k();
      if (element.v4t(force, signalHandler)) {
        toRemove.h(element);
      }
    }
    this.b51_1.c3(toRemove);
  };
  function ManualSchedulerTask() {
    AbstractSchedulerTask.call(this, 'execution.task.manual');
  }
  protoOf(ManualSchedulerTask).h51 = function (scheduler) {
    this.g51_1 = scheduler;
  };
  protoOf(ManualSchedulerTask).i51 = function () {
  };
  protoOf(ManualSchedulerTask).yp = function () {
  };
  function Scheduler() {
  }
  function Companion_1() {
    Companion_instance_1 = this;
    this.r51_1 = new ExecutionStepResult(false, false);
    this.s51_1 = new ExecutionStepResult(false, true);
    this.t51_1 = new ExecutionStepResult(true, false);
  }
  var Companion_instance_1;
  function Companion_getInstance_3() {
    if (Companion_instance_1 == null)
      new Companion_1();
    return Companion_instance_1;
  }
  function ExecutionStepResult(recalculated, breakpoint) {
    Companion_getInstance_3();
    this.u51_1 = recalculated;
    this.v51_1 = breakpoint;
  }
  protoOf(ExecutionStepResult).toString = function () {
    return 'ExecutionStepResult(recalculated=' + this.u51_1 + ', breakpoint=' + this.v51_1 + ')';
  };
  protoOf(ExecutionStepResult).hashCode = function () {
    var result = getBooleanHashCode(this.u51_1);
    result = imul(result, 31) + getBooleanHashCode(this.v51_1) | 0;
    return result;
  };
  protoOf(ExecutionStepResult).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof ExecutionStepResult))
      return false;
    if (!(this.u51_1 === other.u51_1))
      return false;
    if (!(this.v51_1 === other.v51_1))
      return false;
    return true;
  };
  function BreakEvent() {
  }
  function SchedulerEvent(scheduler, source) {
    this.w51_1 = scheduler;
    this.x51_1 = source;
  }
  function SchedulerSingleStepModeEvent(scheduler) {
    this.y51_1 = scheduler;
  }
  protoOf(SchedulerSingleStepModeEvent).toString = function () {
    return 'SchedulerSingleStepModeEvent(scheduler=' + toString(this.y51_1) + ')';
  };
  protoOf(SchedulerSingleStepModeEvent).hashCode = function () {
    return hashCode(this.y51_1);
  };
  protoOf(SchedulerSingleStepModeEvent).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof SchedulerSingleStepModeEvent))
      return false;
    if (!equals(this.y51_1, other.y51_1))
      return false;
    return true;
  };
  function ExecutionStoppedOnIssueEvent(issue, scheduler) {
    this.z51_1 = issue;
    this.a52_1 = scheduler;
  }
  protoOf(ExecutionStoppedOnIssueEvent).toString = function () {
    return 'ExecutionStoppedOnIssueEvent(issue=' + toString(this.z51_1) + ', scheduler=' + toString(this.a52_1) + ')';
  };
  protoOf(ExecutionStoppedOnIssueEvent).hashCode = function () {
    var result = hashCode(this.z51_1);
    result = imul(result, 31) + hashCode(this.a52_1) | 0;
    return result;
  };
  protoOf(ExecutionStoppedOnIssueEvent).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof ExecutionStoppedOnIssueEvent))
      return false;
    if (!equals(this.z51_1, other.z51_1))
      return false;
    if (!equals(this.a52_1, other.a52_1))
      return false;
    return true;
  };
  function BreakpointEvent(scheduler) {
    this.t4u_1 = scheduler;
  }
  protoOf(BreakpointEvent).toString = function () {
    return 'BreakpointEvent(scheduler=' + toString(this.t4u_1) + ')';
  };
  protoOf(BreakpointEvent).hashCode = function () {
    return hashCode(this.t4u_1);
  };
  protoOf(BreakpointEvent).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof BreakpointEvent))
      return false;
    if (!equals(this.t4u_1, other.t4u_1))
      return false;
    return true;
  };
  function SchedulerActivationStateEvent(scheduler) {
    this.s4u_1 = scheduler;
  }
  protoOf(SchedulerActivationStateEvent).toString = function () {
    return 'SchedulerActivationStateEvent(scheduler=' + toString(this.s4u_1) + ')';
  };
  protoOf(SchedulerActivationStateEvent).hashCode = function () {
    return hashCode(this.s4u_1);
  };
  protoOf(SchedulerActivationStateEvent).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof SchedulerActivationStateEvent))
      return false;
    if (!equals(this.s4u_1, other.s4u_1))
      return false;
    return true;
  };
  var SchedulerActivationState_ACTIVE_instance;
  var SchedulerActivationState_PASSIVE_instance;
  var SchedulerActivationState_entriesInitialized;
  function SchedulerActivationState_initEntries() {
    if (SchedulerActivationState_entriesInitialized)
      return Unit_instance;
    SchedulerActivationState_entriesInitialized = true;
    SchedulerActivationState_ACTIVE_instance = new SchedulerActivationState('ACTIVE', 0);
    SchedulerActivationState_PASSIVE_instance = new SchedulerActivationState('PASSIVE', 1);
  }
  function SchedulerActivationState(name, ordinal) {
    Enum.call(this, name, ordinal);
  }
  function SchedulerActivationStatePreparationEvent(scheduler) {
    this.b52_1 = scheduler;
  }
  protoOf(SchedulerActivationStatePreparationEvent).toString = function () {
    return 'SchedulerActivationStatePreparationEvent(scheduler=' + toString(this.b52_1) + ')';
  };
  protoOf(SchedulerActivationStatePreparationEvent).hashCode = function () {
    return hashCode(this.b52_1);
  };
  protoOf(SchedulerActivationStatePreparationEvent).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof SchedulerActivationStatePreparationEvent))
      return false;
    if (!equals(this.b52_1, other.b52_1))
      return false;
    return true;
  };
  function SchedulerActivationState_ACTIVE_getInstance() {
    SchedulerActivationState_initEntries();
    return SchedulerActivationState_ACTIVE_instance;
  }
  function SchedulerActivationState_PASSIVE_getInstance() {
    SchedulerActivationState_initEntries();
    return SchedulerActivationState_PASSIVE_instance;
  }
  function _get_LOG__e5r759($this) {
    var tmp0 = $this.c52_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('LOG', 1, tmp, SchedulerImpl$Companion$_get_LOG_$ref_vpagyj(), null);
    return tmp0.j2();
  }
  function SchedulerImpl$Companion$_get_LOG_$ref_vpagyj() {
    return function (p0) {
      return _get_LOG__e5r759(p0);
    };
  }
  function addRequest($this, request) {
    var tmp0 = $this.h52_1;
    // Inline function 'kotlin.collections.set' call
    var key = request.j52_1;
    tmp0.y1(key, request);
  }
  function SchedulerImpl$Slot$actingDone$lambda() {
    return 'Actor is done ';
  }
  function SchedulerImpl$Request$act$lambda() {
    return 'Actor starts acting';
  }
  function Companion_2() {
    Companion_instance_2 = this;
    this.c52_1 = logger(getKClass(SchedulerImpl));
    this.d52_1 = 'execution.scheduler.stopOnIssue';
    this.e52_1 = 'execution.scheduler.enableSoftBreakpoints';
    this.f52_1 = 'execution.scheduler.enableSimulationTimeStatusBar';
  }
  var Companion_instance_2;
  function Companion_getInstance_4() {
    if (Companion_instance_2 == null)
      new Companion_2();
    return Companion_instance_2;
  }
  function _get_displaySimulationTime__8co2bf($this) {
    return $this.e53_1 || ($this.j53_1 && $this.n52_1.p4u_1.o2(SystemSpeedCategory_Observe_getInstance()) >= 0);
  }
  function _set_isInBreakpoint__1hzh2h($this, value) {
    if ($this.g53_1 === value) {
      return Unit_instance;
    }
    $this.g53_1 = value;
    if ($this.g53_1) {
      $this.f53_1 = false;
      $this.n52_1.m4u_1.e1o();
    }
    _get_LOG__e5r759(Companion_getInstance_4()).ql('isInBreakpoint is ' + $this.g53_1);
    $this.p52_1.gu(new BreakpointEvent($this));
  }
  function requestActingImpl($this, actor, delay, data) {
    if (!$this.l4u()) {
      return Unit_instance;
    }
    if (_get_LOG__e5r759(Companion_getInstance_4()).sl()) {
      $this.q51(actor, SchedulerImpl$requestActingImpl$lambda(delay));
    }
    var tmp0 = add($this.p51(), delay);
    // Inline function 'kotlin.Long.plus' call
    var other = $this.q52_1.w50_1.y50(10);
    var schedulingTime = add(tmp0, fromInt(other));
    var slot = getSlotAt($this, schedulingTime);
    if (!(slot == null)) {
      slot.o53(actor, data);
    } else {
      addSlot($this, new Slot($this, schedulingTime, actor, data));
    }
    startTaskIfNeeded($this);
  }
  function handlePaused($this) {
    $this.r52_1.yp();
    $this.x52_1 = $this.o52_1.op();
  }
  function handleResumed($this) {
    if (!$this.l4u()) {
      return Unit_instance;
    }
    $this.y52_1 = add($this.y52_1, subtract($this.o52_1.op(), $this.x52_1));
    executeImpl($this, true);
    $this.h53_1 = false;
    _set_isInBreakpoint__1hzh2h($this, false);
    startTaskIfNeeded($this);
  }
  function postSchedulerEvent($this, actor) {
    if ($this.l4u()) {
      $this.p53(actor);
    }
  }
  function publishSimulationTimeStatus($this) {
    Status_getInstance().fu(StatusType_Small_getInstance(), StringUtils_getInstance().qu($this.v52_1) + ' ns');
  }
  function clearSimulationTimeStatus($this) {
    Status_getInstance().fu(StatusType_Small_getInstance(), null);
  }
  function addSlot($this, slot) {
    if (_get_LOG__e5r759(Companion_getInstance_4()).sl()) {
      _get_LOG__e5r759(Companion_getInstance_4()).ql('Add slot ' + StringUtils_getInstance().qu(slot.g52_1));
    }
    $this.t52_1.sv(slot);
  }
  function removeSlot($this, slot) {
    if (!$this.t52_1.qv()) {
      if (_get_LOG__e5r759(Companion_getInstance_4()).sl()) {
        _get_LOG__e5r759(Companion_getInstance_4()).ql('Remove slot ' + StringUtils_getInstance().qu(slot.g52_1));
      }
      $this.t52_1.tv(slot);
      if ($this.t52_1.qv()) {
        $this.r52_1.yp();
      }
    }
    $this.s52_1.d51($this.t52_1.qv(), $this);
  }
  function getSlotAt($this, relativeTime) {
    // Inline function 'kotlin.collections.find' call
    var tmp0 = $this.t52_1.uv();
    var tmp$ret$1;
    $l$block: {
      // Inline function 'kotlin.collections.firstOrNull' call
      var _iterator__ex2g4s = tmp0.i();
      while (_iterator__ex2g4s.j()) {
        var element = _iterator__ex2g4s.k();
        if (element.g52_1 === relativeTime) {
          tmp$ret$1 = element;
          break $l$block;
        }
      }
      tmp$ret$1 = null;
    }
    return tmp$ret$1;
  }
  function getSlotWithRequestForActor($this, actor) {
    var tmp0 = $this.t52_1.uv();
    var tmp$ret$0;
    $l$block: {
      // Inline function 'kotlin.collections.firstOrNull' call
      var _iterator__ex2g4s = tmp0.i();
      while (_iterator__ex2g4s.j()) {
        var element = _iterator__ex2g4s.k();
        if (!(element.q53(actor) == null)) {
          tmp$ret$0 = element;
          break $l$block;
        }
      }
      tmp$ret$0 = null;
    }
    return tmp$ret$0;
  }
  function reset($this) {
    $this.v52_1 = 0n;
    $this.l53_1 = 0n;
    $this.t52_1.a2();
    $this.s52_1.du();
  }
  function start($this) {
    $this.p52_1.gu(new SchedulerActivationStatePreparationEvent($this));
    _get_LOG__e5r759(Companion_getInstance_4()).ql('Scheduler started');
    reset($this);
    $this.w52_1 = $this.o52_1.op();
    $this.x52_1 = 0n;
    $this.y52_1 = 0n;
    $this.n52_1.m4u_1.f1o();
    _set_isInBreakpoint__1hzh2h($this, false);
    $this.f53_1 = false;
    $this.h53_1 = false;
    $this.u52_1 = SchedulerActivationState_ACTIVE_getInstance();
    startTaskIfNeeded($this);
    $this.p52_1.gu(new SchedulerActivationStateEvent($this));
  }
  function startTaskIfNeeded($this) {
    if (!$this.n52_1.m4u_1.b1o_1) {
      $this.r52_1.i51();
    }
  }
  function stop($this) {
    _get_LOG__e5r759(Companion_getInstance_4()).ql('Scheduler stopped');
    $this.r52_1.yp();
    $this.u52_1 = SchedulerActivationState_PASSIVE_getInstance();
    _set_isInBreakpoint__1hzh2h($this, false);
    $this.p52_1.gu(new SchedulerActivationStateEvent($this));
    reset($this);
    $this.p52_1.gu(new SchedulerActivationStatePreparationEvent($this));
  }
  function updateRelativeTime($this, relativeTime) {
    // Inline function 'kotlin.math.max' call
    var b = $this.v52_1;
    var newRelativeTime = relativeTime >= b ? relativeTime : b;
    if (newRelativeTime > $this.v52_1) {
      $this.v52_1 = newRelativeTime;
      if (_get_LOG__e5r759(Companion_getInstance_4()).sl()) {
        _get_LOG__e5r759(Companion_getInstance_4()).ql(StringUtils_getInstance().qu($this.p51()) + ' ns Updated relative time');
      }
      if (_get_displaySimulationTime__8co2bf($this)) {
        publishSimulationTimeStatus($this);
      }
      $this.s52_1.d51($this.t52_1.qv(), $this);
    }
  }
  function getRelativeRealTime($this) {
    return subtract(subtract($this.o52_1.op(), $this.w52_1), $this.y52_1);
  }
  function executeImpl($this, resume) {
    var optionalSlot = $this.t52_1.rv();
    if (optionalSlot == null) {
      updateRelativeTime($this, getRelativeRealTime($this));
      return Companion_getInstance_3().r51_1;
    }
    var slot = optionalSlot;
    if (!slot.r53()) {
      updateRelativeTime($this, slot.g52_1);
      return Companion_getInstance_3().r51_1;
    }
    var tmp0 = slot.g52_1;
    // Inline function 'kotlin.math.min' call
    var b = getRelativeRealTime($this);
    var tmp$ret$0 = tmp0 <= b ? tmp0 : b;
    updateRelativeTime($this, tmp$ret$0);
    var recalculated = false;
    if ($this.e53_1 || slot.g52_1 <= $this.v52_1) {
      updateRelativeTime($this, slot.g52_1);
      if (!resume && checkForBreakpoint($this, slot)) {
        $this.r52_1.yp();
        if (slot.s53()) {
          $this.f53_1 = true;
        } else {
          _set_isInBreakpoint__1hzh2h($this, true);
        }
        return Companion_getInstance_3().s51_1;
      }
      _set_isInBreakpoint__1hzh2h($this, false);
      // Inline function 'kotlin.collections.filter' call
      var tmp0_0 = slot.t53();
      // Inline function 'kotlin.collections.filterTo' call
      var destination = ArrayList_init_$Create$();
      var _iterator__ex2g4s = tmp0_0.i();
      while (_iterator__ex2g4s.j()) {
        var element = _iterator__ex2g4s.k();
        if (element.u53()) {
          destination.h(element);
        }
      }
      // Inline function 'kotlin.collections.forEach' call
      var _iterator__ex2g4s_0 = destination.i();
      while (_iterator__ex2g4s_0.j()) {
        var element_0 = _iterator__ex2g4s_0.k();
        element_0.v53();
      }
      if (slot.wv()) {
        removeSlot($this, slot);
      }
      recalculated = true;
    } else {
      var tmp0_1 = getRelativeRealTime($this);
      // Inline function 'kotlin.math.min' call
      var b_0 = slot.g52_1;
      var tmp$ret$6 = tmp0_1 <= b_0 ? tmp0_1 : b_0;
      updateRelativeTime($this, tmp$ret$6);
    }
    return recalculated ? Companion_getInstance_3().t51_1 : Companion_getInstance_3().r51_1;
  }
  function checkForBreakpoint($this, slot) {
    var tmp;
    if ($this.e53_1 && $this.p51() > $this.l53_1) {
      var tmp_0;
      if ($this.h53_1) {
        tmp_0 = true;
      } else {
        var tmp_1;
        if ($this.k53_1) {
          var tmp0 = slot.t53();
          var tmp$ret$0;
          $l$block_0: {
            // Inline function 'kotlin.collections.any' call
            var tmp_2;
            if (isInterface(tmp0, Collection)) {
              tmp_2 = tmp0.m();
            } else {
              tmp_2 = false;
            }
            if (tmp_2) {
              tmp$ret$0 = false;
              break $l$block_0;
            }
            var _iterator__ex2g4s = tmp0.i();
            while (_iterator__ex2g4s.j()) {
              var element = _iterator__ex2g4s.k();
              if (element.u53() && element.j52_1.n4w()) {
                tmp$ret$0 = true;
                break $l$block_0;
              }
            }
            tmp$ret$0 = false;
          }
          tmp_1 = tmp$ret$0;
        } else {
          tmp_1 = false;
        }
        tmp_0 = tmp_1;
      }
      tmp = tmp_0;
    } else {
      tmp = false;
    }
    return tmp;
  }
  function Slot($outer, relativeTime, actor, data) {
    this.i52_1 = $outer;
    this.g52_1 = relativeTime;
    var tmp = this;
    // Inline function 'kotlin.collections.mutableMapOf' call
    tmp.h52_1 = LinkedHashMap_init_$Create$();
    addRequest(this, new Request(this.i52_1, actor, data));
  }
  protoOf(Slot).r53 = function () {
    var tmp0 = this.h52_1.c2();
    var tmp$ret$0;
    $l$block_0: {
      // Inline function 'kotlin.collections.any' call
      var tmp;
      if (isInterface(tmp0, Collection)) {
        tmp = tmp0.m();
      } else {
        tmp = false;
      }
      if (tmp) {
        tmp$ret$0 = false;
        break $l$block_0;
      }
      var _iterator__ex2g4s = tmp0.i();
      while (_iterator__ex2g4s.j()) {
        var element = _iterator__ex2g4s.k();
        if (element.u53()) {
          tmp$ret$0 = true;
          break $l$block_0;
        }
      }
      tmp$ret$0 = false;
    }
    return tmp$ret$0;
  };
  protoOf(Slot).s53 = function () {
    var tmp0 = this.h52_1.c2();
    var tmp$ret$0;
    $l$block_0: {
      // Inline function 'kotlin.collections.any' call
      var tmp;
      if (isInterface(tmp0, Collection)) {
        tmp = tmp0.m();
      } else {
        tmp = false;
      }
      if (tmp) {
        tmp$ret$0 = false;
        break $l$block_0;
      }
      var _iterator__ex2g4s = tmp0.i();
      while (_iterator__ex2g4s.j()) {
        var element = _iterator__ex2g4s.k();
        if (element.s53()) {
          tmp$ret$0 = true;
          break $l$block_0;
        }
      }
      tmp$ret$0 = false;
    }
    return tmp$ret$0;
  };
  protoOf(Slot).wv = function () {
    return this.h52_1.m();
  };
  protoOf(Slot).w53 = function (other) {
    return compareTo(this.g52_1, other.g52_1);
  };
  protoOf(Slot).d = function (other) {
    return this.w53(other instanceof Slot ? other : THROW_CCE());
  };
  protoOf(Slot).t53 = function () {
    return this.h52_1.c2();
  };
  protoOf(Slot).o53 = function (actor, data) {
    var request = this.q53(actor);
    if (!(request == null)) {
      request.x53(data);
    } else {
      addRequest(this, new Request(this.i52_1, actor, data));
    }
  };
  protoOf(Slot).y53 = function (actor, request) {
    if (request == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      this.i52_1.q51(actor, SchedulerImpl$Slot$actingDone$lambda);
      this.h52_1.z1(request.j52_1);
      postSchedulerEvent(this.i52_1, actor);
    }
  };
  protoOf(Slot).q53 = function (actor) {
    return this.h52_1.g2(actor);
  };
  function Request($outer, actor, actorData) {
    this.m52_1 = $outer;
    this.j52_1 = actor;
    this.k52_1 = false;
    this.l52_1 = actorData;
  }
  protoOf(Request).s53 = function () {
    return this.k52_1;
  };
  protoOf(Request).u53 = function () {
    return !this.s53();
  };
  protoOf(Request).x53 = function (actorData) {
    this.l52_1 = actorData;
    this.k52_1 = false;
  };
  protoOf(Request).v53 = function () {
    if (!this.k52_1) {
      this.m52_1.q51(this.j52_1, SchedulerImpl$Request$act$lambda);
      this.k52_1 = true;
      this.j52_1.s4w(this.m52_1, this.l52_1);
    }
  };
  function SchedulerImpl$issueCollectorListener$lambda$lambda($it, this$0) {
    return function () {
      _get_LOG__e5r759(Companion_getInstance_4()).ql("execution stopped due to Issue '" + $it.e50_1.m2() + "'");
      this$0.p52_1.gu(new ExecutionStoppedOnIssueEvent($it.e50_1, this$0));
      return Unit_instance;
    };
  }
  function SchedulerImpl$issueCollectorListener$lambda(this$0) {
    return function (it) {
      var tmp;
      if (this$0.l4u() && this$0.i53_1 && !(it.e50_1 == null)) {
        this$0.q4u().m4u_1.e1o();
        var tmp_0 = System_getInstance();
        tmp_0.fm(SchedulerImpl$issueCollectorListener$lambda$lambda(it, this$0));
        tmp = Unit_instance;
      }
      return Unit_instance;
    };
  }
  function SchedulerImpl$breakListener$lambda(this$0) {
    return function (it) {
      this$0.h53_1 = true;
      var tmp;
      if (this$0.e53_1) {
        _set_isInBreakpoint__1hzh2h(this$0, true);
        tmp = Unit_instance;
      }
      return Unit_instance;
    };
  }
  function SchedulerImpl$pauseEventListener$lambda(this$0) {
    return function (it) {
      var tmp;
      if (this$0.l4u() && it.j1o_1 === this$0.n52_1.m4u_1) {
        var tmp_0;
        if (it.k1o_1) {
          handlePaused(this$0);
          tmp_0 = Unit_instance;
        } else {
          handleResumed(this$0);
          tmp_0 = Unit_instance;
        }
        tmp = tmp_0;
      }
      return Unit_instance;
    };
  }
  function SchedulerImpl$systemSpeedCategoryHandler$lambda(this$0) {
    return function (it) {
      var tmp;
      if (it.z53_1 === this$0.n52_1) {
        _get_LOG__e5r759(Companion_getInstance_4()).ql(StringUtils_getInstance().qu(this$0.p51()) + " ns: SpeedCategory changed to '" + this$0.n52_1.p4u_1.m50_1 + "'");
        var tmp_0;
        if (!_get_displaySimulationTime__8co2bf(this$0)) {
          clearSimulationTimeStatus(this$0);
          tmp_0 = Unit_instance;
        } else {
          publishSimulationTimeStatus(this$0);
          tmp_0 = Unit_instance;
        }
        tmp = tmp_0;
      }
      return Unit_instance;
    };
  }
  function SchedulerImpl$actPrematurely$lambda() {
    return 'Executing prematurely';
  }
  function SchedulerImpl$requestActingImpl$lambda($delay) {
    return function () {
      return 'Request to act after ' + StringUtils_getInstance().qu($delay) + ' ns';
    };
  }
  function SchedulerImpl(currentSystemSpeedCategory, timeService, eventBus, noiseGeneratorHolder, task, executionErrorHandler, isDeepExecution) {
    Companion_getInstance_4();
    timeService = timeService === VOID ? BaseModule_getInstance().cp_1 : timeService;
    eventBus = eventBus === VOID ? BaseModule_getInstance().bp_1 : eventBus;
    noiseGeneratorHolder = noiseGeneratorHolder === VOID ? ExecutionModule_getInstance().u50() : noiseGeneratorHolder;
    task = task === VOID ? ExecutionModule_getInstance().s50_1(currentSystemSpeedCategory, eventBus) : task;
    executionErrorHandler = executionErrorHandler === VOID ? new ExecutionErrorHandlerImpl() : executionErrorHandler;
    isDeepExecution = isDeepExecution === VOID ? true : isDeepExecution;
    this.n52_1 = currentSystemSpeedCategory;
    this.o52_1 = timeService;
    this.p52_1 = eventBus;
    this.q52_1 = noiseGeneratorHolder;
    this.r52_1 = task;
    this.s52_1 = executionErrorHandler;
    this.t52_1 = new PriorityQueue();
    this.u52_1 = SchedulerActivationState_PASSIVE_getInstance();
    this.v52_1 = 0n;
    this.w52_1 = 0n;
    this.x52_1 = 0n;
    this.y52_1 = 0n;
    var tmp = this;
    tmp.z52_1 = SchedulerImpl$issueCollectorListener$lambda(this);
    var tmp_0 = this;
    tmp_0.a53_1 = SchedulerImpl$breakListener$lambda(this);
    var tmp_1 = this;
    tmp_1.b53_1 = SchedulerImpl$pauseEventListener$lambda(this);
    var tmp_2 = this;
    tmp_2.c53_1 = SchedulerImpl$systemSpeedCategoryHandler$lambda(this);
    var tmp_3 = this;
    // Inline function 'kotlin.collections.mutableListOf' call
    tmp_3.d53_1 = ArrayList_init_$Create$();
    this.r52_1.h51(this);
    this.p52_1.z17(getKClass(IssueCollectorEvent), this.z52_1);
    this.p52_1.z17(getKClass(BreakEvent), this.a53_1);
    this.p52_1.z17(getKClass(SystemSpeedPauseEvent), this.b53_1);
    this.p52_1.z17(getKClass(SystemSpeedCategoryEvent), this.c53_1);
    this.e53_1 = false;
    this.f53_1 = false;
    this.g53_1 = false;
    this.h53_1 = false;
    this.i53_1 = BaseModule_getInstance().ap_1.ut('execution.scheduler.stopOnIssue', true);
    this.j53_1 = BaseModule_getInstance().ap_1.ut('execution.scheduler.enableSimulationTimeStatusBar', false);
    this.k53_1 = BaseModule_getInstance().ap_1.ut('execution.scheduler.enableSoftBreakpoints', false);
    this.l53_1 = 0n;
    this.m53_1 = isDeepExecution;
    this.n53_1 = null;
  }
  protoOf(SchedulerImpl).c54 = function () {
    return this.p52_1;
  };
  protoOf(SchedulerImpl).q4u = function () {
    return this.n52_1;
  };
  protoOf(SchedulerImpl).k51 = function () {
    return this.t52_1.qv();
  };
  protoOf(SchedulerImpl).j51 = function (value) {
    if (value === this.l4u()) {
      return Unit_instance;
    }
    if (value) {
      start(this);
    } else {
      stop(this);
    }
    Status_getInstance().fu(StatusType_Small_getInstance(), null);
  };
  protoOf(SchedulerImpl).l4u = function () {
    return this.u52_1.equals(SchedulerActivationState_ACTIVE_getInstance());
  };
  protoOf(SchedulerImpl).g4w = function (value) {
    if (!(value === this.e53_1)) {
      this.e53_1 = value;
      this.p52_1.gu(new SchedulerSingleStepModeEvent(this));
      startTaskIfNeeded(this);
    }
  };
  protoOf(SchedulerImpl).f4w = function () {
    return this.e53_1;
  };
  protoOf(SchedulerImpl).r4u = function () {
    return this.g53_1;
  };
  protoOf(SchedulerImpl).l51 = function (_set____db54di) {
    this.l53_1 = _set____db54di;
  };
  protoOf(SchedulerImpl).m51 = function (listener) {
    if (!this.d53_1.n(listener)) {
      this.d53_1.h(listener);
    }
  };
  protoOf(SchedulerImpl).n51 = function (listener) {
    this.d53_1.h2(listener);
  };
  protoOf(SchedulerImpl).p53 = function (source) {
    var event = new SchedulerEvent(this, source);
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = this.d53_1.i();
    while (_iterator__ex2g4s.j()) {
      var element = _iterator__ex2g4s.k();
      element.d54(event);
    }
  };
  protoOf(SchedulerImpl).o51 = function () {
    return executeImpl(this, false);
  };
  protoOf(SchedulerImpl).t4v = function (_set____db54di) {
    this.m53_1 = _set____db54di;
  };
  protoOf(SchedulerImpl).s4v = function () {
    return this.m53_1;
  };
  protoOf(SchedulerImpl).p51 = function () {
    return this.v52_1;
  };
  protoOf(SchedulerImpl).e54 = function (_set____db54di) {
    this.n53_1 = _set____db54di;
  };
  protoOf(SchedulerImpl).f54 = function () {
    return this.n53_1;
  };
  protoOf(SchedulerImpl).g54 = function () {
    return _get_LOG__e5r759(Companion_getInstance_4()).sl();
  };
  protoOf(SchedulerImpl).h54 = function (clazz, id, msg) {
    if (_get_LOG__e5r759(Companion_getInstance_4()).sl()) {
      _get_LOG__e5r759(Companion_getInstance_4()).ql(StringUtils_getInstance().qu(this.p51()) + ' ns [' + clazz.m9() + ' (' + id + ')]: ' + msg());
    }
  };
  protoOf(SchedulerImpl).q51 = function (actor, msg) {
    if (_get_LOG__e5r759(Companion_getInstance_4()).sl()) {
      _get_LOG__e5r759(Companion_getInstance_4()).ql(StringUtils_getInstance().qu(this.p51()) + ' ns [' + System_getInstance().zl(actor).m9() + ' (' + actor.cv() + ')]: ' + msg());
    }
  };
  protoOf(SchedulerImpl).m4y = function (actor, delay, data) {
    requestActingImpl(this, actor, delay, data);
  };
  protoOf(SchedulerImpl).i54 = function (actor, data) {
    var slot = getSlotWithRequestForActor(this, actor);
    if (!(slot == null)) {
      var request = ensureNotNull(slot.q53(actor));
      if (request.u53()) {
        this.q51(request.j52_1, SchedulerImpl$actPrematurely$lambda);
        request.v53();
      }
    }
  };
  protoOf(SchedulerImpl).n4y = function (actor, data) {
    var slot = this.t52_1.rv();
    if (!(slot == null)) {
      var request = slot.q53(actor);
      if (request == null) {
        slot = getSlotWithRequestForActor(this, actor);
        if (!(slot == null)) {
          request = slot.q53(actor);
        }
      }
      if (!(slot == null)) {
        if (!(request == null) && request.s53()) {
          actor.u4w(this, request.l52_1);
        }
        slot.y53(actor, request);
        if (this.f53_1 && !slot.s53()) {
          _set_isInBreakpoint__1hzh2h(this, true);
        }
        if (slot.wv()) {
          removeSlot(this, slot);
        }
      } else {
        actor.u4w(this, data);
      }
    } else {
      actor.u4w(this, data);
    }
  };
  protoOf(SchedulerImpl).c51 = function (error) {
    this.s52_1.c51(error);
  };
  function AbstractSchedulerTask(nameKey) {
    this.j54_1 = nameKey;
  }
  protoOf(AbstractSchedulerTask).h51 = function (scheduler) {
    this.k54_1 = scheduler;
  };
  function _get_LOG__e5r759_0($this) {
    var tmp0 = $this.l54_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('LOG', 1, tmp, TimedSchedulerTask$Companion$_get_LOG_$ref_96mk21(), null);
    return tmp0.j2();
  }
  function TimedSchedulerTask$Companion$_get_LOG_$ref_96mk21() {
    return function (p0) {
      return _get_LOG__e5r759_0(p0);
    };
  }
  function Companion_3() {
    Companion_instance_3 = this;
    this.l54_1 = logger(getKClass(TimedSchedulerTask));
    this.m54_1 = 10000;
    this.n54_1 = 'TimedSchedulerTask.slowDownFactor';
    this.o54_1 = 4.0;
  }
  var Companion_instance_3;
  function Companion_getInstance_5() {
    if (Companion_instance_3 == null)
      new Companion_3();
    return Companion_instance_3;
  }
  function _get_slowDownFactor__sg5jc7($this) {
    var tmp0 = $this.x54_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('slowDownFactor', 1, tmp, TimedSchedulerTask$_get_slowDownFactor_$ref_ff46mb(), null);
    return tmp0.j2();
  }
  function _get_scheduler__wzo5xm($this) {
    var tmp = $this.y54_1;
    if (!(tmp == null))
      return tmp;
    else {
      throwUninitializedPropertyAccessException('scheduler');
    }
  }
  function calculateTimerInterval($this) {
    var category = $this.r54_1.p4u_1;
    var speed = $this.r54_1.m4u_1.a1o_1;
    var tmp;
    if ($this.r54_1.m4u_1.d1o()) {
      tmp = 1;
    } else {
      var intervals = ensureNotNull($this.v54_1.g2(category));
      tmp = numberToInt(_get_slowDownFactor__sg5jc7($this) * interpolate(category.n50_1, speed, intervals.y_1, intervals.z_1));
    }
    return tmp;
  }
  function calculateNumberOfSteps($this) {
    var category = $this.r54_1.p4u_1;
    var speed = $this.r54_1.m4u_1.a1o_1;
    var tmp;
    if ($this.r54_1.m4u_1.d1o()) {
      tmp = 10000;
    } else {
      var steps = ensureNotNull($this.u54_1.g2(category));
      tmp = interpolate(category.n50_1, speed, steps.y_1, steps.z_1);
    }
    return tmp;
  }
  function adaptToSystemSpeed($this) {
    $this.z54_1 = calculateNumberOfSteps($this);
    $this.a55_1 = calculateTimerInterval($this);
    if (_get_LOG__e5r759_0(Companion_getInstance_5()).sl()) {
      _get_LOG__e5r759_0(Companion_getInstance_5()).ql('number of steps: ' + $this.z54_1 + ', interval: ' + $this.a55_1);
    }
    var needRestart = $this.s54_1.up() === 2147483647 && !($this.a55_1 === 2147483647) && $this.s54_1.zp();
    $this.s54_1.tp($this.a55_1);
    if (needRestart) {
      $this.s54_1.yp();
      $this.s54_1.xp();
    }
  }
  function executeNumberOfSteps($this, number) {
    var effNumber = number + Default_getInstance().cg(0, 3) | 0;
    var count = 0;
    var result = null;
    $l$1: do {
      $l$0: do {
        result = _get_scheduler__wzo5xm($this).o51();
        count = count + 1 | 0;
      }
       while (false);
      var tmp;
      var tmp_0;
      var tmp_1;
      var tmp_2;
      if (result == null) {
        throwUninitializedPropertyAccessException('result');
      } else {
        tmp_2 = result;
      }
      if (!tmp_2.v51_1) {
        tmp_1 = count < effNumber;
      } else {
        tmp_1 = false;
      }
      if (tmp_1) {
        tmp_0 = !_get_scheduler__wzo5xm($this).k51();
      } else {
        tmp_0 = false;
      }
      if (tmp_0) {
        var tmp_3;
        if (result == null) {
          throwUninitializedPropertyAccessException('result');
        } else {
          tmp_3 = result;
        }
        tmp = tmp_3.u51_1;
      } else {
        tmp = false;
      }
    }
     while (tmp);
  }
  function TimedSchedulerTask$systemSpeedHandler$lambda(this$0) {
    return function (it) {
      var tmp;
      if (equals(it.g1o_1, this$0.r54_1.m4u_1)) {
        adaptToSystemSpeed(this$0);
        tmp = Unit_instance;
      }
      return Unit_instance;
    };
  }
  function TimedSchedulerTask$slowDownFactor$delegate$lambda() {
    return BaseModule_getInstance().zo_1.lt('TimedSchedulerTask.slowDownFactor');
  }
  function TimedSchedulerTask$_get_slowDownFactor_$ref_ff46mb() {
    return function (p0) {
      return _get_slowDownFactor__sg5jc7(p0);
    };
  }
  function TimedSchedulerTask$lambda(this$0) {
    return function (it) {
      this$0.actionPerformed(it);
      return Unit_instance;
    };
  }
  function TimedSchedulerTask(currentSystemSpeedCategory, timer, eventBus) {
    Companion_getInstance_5();
    timer = timer === VOID ? System_getInstance().wl() : timer;
    eventBus = eventBus === VOID ? BaseModule_getInstance().bp_1 : eventBus;
    AbstractSchedulerTask.call(this, 'execution.task.timed');
    this.r54_1 = currentSystemSpeedCategory;
    this.s54_1 = timer;
    this.t54_1 = eventBus;
    this.u54_1 = mapOf([to(SystemSpeedCategory_Use_getInstance(), numberRangeToNumber(100, 10000)), to(SystemSpeedCategory_Observe_getInstance(), numberRangeToNumber(3, 100)), to(SystemSpeedCategory_Explore_getInstance(), numberRangeToNumber(1, 3))]);
    this.v54_1 = mapOf([to(SystemSpeedCategory_Use_getInstance(), downTo(5, 1)), to(SystemSpeedCategory_Observe_getInstance(), downTo(10, 5)), to(SystemSpeedCategory_Explore_getInstance(), downTo(30, 10))]);
    var tmp = this;
    tmp.w54_1 = TimedSchedulerTask$systemSpeedHandler$lambda(this);
    var tmp_0 = this;
    tmp_0.x54_1 = lazy(TimedSchedulerTask$slowDownFactor$delegate$lambda);
    this.t54_1.z17(getKClass(SystemSpeedEvent), this.w54_1);
    this.z54_1 = calculateNumberOfSteps(this);
    this.a55_1 = calculateTimerInterval(this);
    var tmp_1 = this.a55_1;
    this.s54_1.wp(tmp_1, VOID, TimedSchedulerTask$lambda(this));
  }
  protoOf(TimedSchedulerTask).h51 = function (scheduler) {
    this.y54_1 = scheduler;
  };
  protoOf(TimedSchedulerTask).i51 = function () {
    if (!_get_scheduler__wzo5xm(this).k51() && !this.s54_1.zp()) {
      _get_LOG__e5r759_0(Companion_getInstance_5()).ql('Starting timer');
      adaptToSystemSpeed(this);
      this.s54_1.xp();
    }
  };
  protoOf(TimedSchedulerTask).yp = function () {
    this.s54_1.yp();
  };
  protoOf(TimedSchedulerTask).actionPerformed = function (event) {
    executeNumberOfSteps(this, this.z54_1);
  };
  function _get_LOG__e5r759_1($this) {
    var tmp0 = $this.b55_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('LOG', 1, tmp, CurrentSystemSpeedCategory$Companion$_get_LOG_$ref_flvtjx(), null);
    return tmp0.j2();
  }
  function CurrentSystemSpeedCategory$Companion$_get_LOG_$ref_flvtjx() {
    return function (p0) {
      return _get_LOG__e5r759_1(p0);
    };
  }
  function Companion_4() {
    Companion_instance_4 = this;
    this.b55_1 = logger(getKClass(CurrentSystemSpeedCategory));
  }
  var Companion_instance_4;
  function Companion_getInstance_6() {
    if (Companion_instance_4 == null)
      new Companion_4();
    return Companion_instance_4;
  }
  function update($this) {
    var oldValue = $this.p4u_1;
    $this.p4u_1 = calculate($this);
    if (!oldValue.equals($this.p4u_1)) {
      _get_LOG__e5r759_1(Companion_getInstance_6()).ql("CurrentSystemSpeedCategory changed to '" + $this.p4u_1.toString() + "'");
      $this.n4u_1.gu(new SystemSpeedCategoryEvent($this, oldValue, $this.p4u_1));
    }
  }
  function calculate($this) {
    var tmp0 = get_entries();
    var tmp$ret$0;
    $l$block: {
      // Inline function 'kotlin.collections.first' call
      var _iterator__ex2g4s = tmp0.i();
      while (_iterator__ex2g4s.j()) {
        var element = _iterator__ex2g4s.k();
        if ($this.m4u_1.a1o_1 >= element.n50_1.y_1) {
          tmp$ret$0 = element;
          break $l$block;
        }
      }
      throw NoSuchElementException_init_$Create$('Collection contains no element matching the predicate.');
    }
    return tmp$ret$0;
  }
  function CurrentSystemSpeedCategory$systemSpeedHandler$lambda(this$0) {
    return function (it) {
      var tmp;
      if (it.g1o_1 === this$0.m4u_1) {
        update(this$0);
        tmp = Unit_instance;
      }
      return Unit_instance;
    };
  }
  function CurrentSystemSpeedCategory(systemSpeed, eventBus) {
    Companion_getInstance_6();
    eventBus = eventBus === VOID ? BaseModule_getInstance().bp_1 : eventBus;
    this.m4u_1 = systemSpeed;
    this.n4u_1 = eventBus;
    var tmp = this;
    tmp.o4u_1 = CurrentSystemSpeedCategory$systemSpeedHandler$lambda(this);
    this.n4u_1.z17(getKClass(SystemSpeedEvent), this.o4u_1);
    this.p4u_1 = calculate(this);
  }
  var SystemSpeedCategory_Use_instance;
  var SystemSpeedCategory_Observe_instance;
  var SystemSpeedCategory_Explore_instance;
  function Companion_5() {
  }
  protoOf(Companion_5).h1f = function (customName) {
    var tmp0 = values();
    var tmp$ret$0;
    $l$block: {
      // Inline function 'kotlin.collections.firstOrNull' call
      var inductionVariable = 0;
      var last = tmp0.length;
      while (inductionVariable < last) {
        var element = tmp0[inductionVariable];
        inductionVariable = inductionVariable + 1 | 0;
        if (element.m50_1 === customName) {
          tmp$ret$0 = element;
          break $l$block;
        }
      }
      tmp$ret$0 = null;
    }
    var tmp0_elvis_lhs = tmp$ret$0;
    var tmp;
    if (tmp0_elvis_lhs == null) {
      throw IllegalArgumentException_init_$Create$('Unknown SystemSpeedCategory');
    } else {
      tmp = tmp0_elvis_lhs;
    }
    return tmp;
  };
  var Companion_instance_5;
  function Companion_getInstance_7() {
    return Companion_instance_5;
  }
  function values() {
    return [SystemSpeedCategory_Use_getInstance(), SystemSpeedCategory_Observe_getInstance(), SystemSpeedCategory_Explore_getInstance()];
  }
  function get_entries() {
    if ($ENTRIES == null)
      $ENTRIES = enumEntries(values());
    return $ENTRIES;
  }
  var SystemSpeedCategory_entriesInitialized;
  function SystemSpeedCategory_initEntries() {
    if (SystemSpeedCategory_entriesInitialized)
      return Unit_instance;
    SystemSpeedCategory_entriesInitialized = true;
    SystemSpeedCategory_Use_instance = new SystemSpeedCategory('Use', 0, 'use', numberRangeToNumber(67, 100));
    SystemSpeedCategory_Observe_instance = new SystemSpeedCategory('Observe', 1, 'observer', numberRangeToNumber(34, 66));
    SystemSpeedCategory_Explore_instance = new SystemSpeedCategory('Explore', 2, 'explore', numberRangeToNumber(0, 33));
  }
  var $ENTRIES;
  function SystemSpeedCategory(name, ordinal, customName, speedRange) {
    Enum.call(this, name, ordinal);
    this.m50_1 = customName;
    this.n50_1 = speedRange;
  }
  protoOf(SystemSpeedCategory).toString = function () {
    var tmp;
    switch (this.l2_1) {
      case 0:
        tmp = Translations_getInstance().bn('execution.systemSpeedCategory.use', []);
        break;
      case 1:
        tmp = Translations_getInstance().bn('execution.systemSpeedCategory.observe', []);
        break;
      case 2:
        tmp = Translations_getInstance().bn('execution.systemSpeedCategory.explore', []);
        break;
      default:
        noWhenBranchMatchedException();
        break;
    }
    return tmp;
  };
  function SystemSpeedCategoryEvent(source, oldValue, newValue) {
    this.z53_1 = source;
    this.a54_1 = oldValue;
    this.b54_1 = newValue;
  }
  protoOf(SystemSpeedCategoryEvent).toString = function () {
    return 'SystemSpeedCategoryEvent(source=' + toString(this.z53_1) + ', oldValue=' + this.a54_1.toString() + ', newValue=' + this.b54_1.toString() + ')';
  };
  protoOf(SystemSpeedCategoryEvent).hashCode = function () {
    var result = hashCode(this.z53_1);
    result = imul(result, 31) + this.a54_1.hashCode() | 0;
    result = imul(result, 31) + this.b54_1.hashCode() | 0;
    return result;
  };
  protoOf(SystemSpeedCategoryEvent).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof SystemSpeedCategoryEvent))
      return false;
    if (!equals(this.z53_1, other.z53_1))
      return false;
    if (!this.a54_1.equals(other.a54_1))
      return false;
    if (!this.b54_1.equals(other.b54_1))
      return false;
    return true;
  };
  function SystemSpeedCategory_Use_getInstance() {
    SystemSpeedCategory_initEntries();
    return SystemSpeedCategory_Use_instance;
  }
  function SystemSpeedCategory_Observe_getInstance() {
    SystemSpeedCategory_initEntries();
    return SystemSpeedCategory_Observe_instance;
  }
  function SystemSpeedCategory_Explore_getInstance() {
    SystemSpeedCategory_initEntries();
    return SystemSpeedCategory_Explore_instance;
  }
  //region block: post-declaration
  defineProp(protoOf(AbstractSchedulerAction), 'requestFocusOnClick', function () {
    return this.wq();
  });
  defineProp(protoOf(PauseOrResumeActionImpl), 'inBreakpoint', function () {
    return this.w4t();
  });
  defineProp(protoOf(PauseOrResumeActionImpl), 'opensDialog', function () {
    return this.vq();
  });
  defineProp(protoOf(PauseOrResumeActionImpl), 'name', function () {
    return this.m2();
  }, function (value) {
    this.kq(value);
  });
  defineProp(protoOf(PauseOrResumeActionImpl), 'description', function () {
    return this.mq();
  }, function (value) {
    this.lq(value);
  });
  defineProp(protoOf(PauseOrResumeActionImpl), 'accelerator', function () {
    return this.oq();
  }, function (value) {
    this.nq(value);
  });
  defineProp(protoOf(PauseOrResumeActionImpl), 'enabled', function () {
    return this.qq();
  }, function (value) {
    this.pq(value);
  });
  defineProp(protoOf(PauseOrResumeActionImpl), 'selected', function () {
    return this.sq();
  }, function (value) {
    this.rq(value);
  });
  defineProp(protoOf(PauseOrResumeActionImpl), 'imagePath', function () {
    return this.uq();
  }, function (value) {
    this.tq(value);
  });
  defineProp(protoOf(PauseOrResumeActionImpl), 'requestFocusOnClick', function () {
    return this.wq();
  });
  defineProp(protoOf(ExecutionDepthAction), 'requestFocusOnClick', function () {
    return this.wq();
  });
  defineProp(protoOf(SingleStepModeAction), 'requestFocusOnClick', function () {
    return this.wq();
  });
  protoOf(ActorDrawableButton).u4x = executionStarted;
  protoOf(ActorDrawableButton).v4x = executionStartDone;
  protoOf(ActorDrawableButton).v4w = executionStopped;
  protoOf(ActorImpl).i4w = get_waiting;
  protoOf(ActorViewBag).v4x = executionStartDone;
  protoOf(ActorViewContainer).v4x = executionStartDone;
  //endregion
  //region block: init
  PROP_PAUSE_OR_RESUME_ACTION_IN_BREAKPOINT = 'inBreakpoint';
  Companion_instance = new Companion();
  Companion_instance_0 = new Companion_0();
  Companion_instance_5 = new Companion_5();
  //endregion
  //region block: exports
  function $jsExportAll$(_) {
    var io = _.io || (_.io = {});
    var antarescircuit = io.antarescircuit || (io.antarescircuit = {});
    var jabbah = antarescircuit.jabbah || (antarescircuit.jabbah = {});
    var execution = jabbah.execution || (jabbah.execution = {});
    var io_0 = _.io || (_.io = {});
    var antarescircuit_0 = io_0.antarescircuit || (io_0.antarescircuit = {});
    var jabbah_0 = antarescircuit_0.jabbah || (antarescircuit_0.jabbah = {});
    var execution_0 = jabbah_0.execution || (jabbah_0.execution = {});
    defineProp(execution_0, 'PROP_PAUSE_OR_RESUME_ACTION_IN_BREAKPOINT', get_PROP_PAUSE_OR_RESUME_ACTION_IN_BREAKPOINT, VOID, true);
    var io_1 = _.io || (_.io = {});
    var antarescircuit_1 = io_1.antarescircuit || (io_1.antarescircuit = {});
    var jabbah_1 = antarescircuit_1.jabbah || (antarescircuit_1.jabbah = {});
    var execution_1 = jabbah_1.execution || (jabbah_1.execution = {});
  }
  $jsExportAll$(_);
  _.$jsExportAll$ = $jsExportAll$;
  _.$_$ = _.$_$ || {};
  _.$_$.a = ExecutionModule_getInstance;
  _.$_$.b = Companion_instance_5;
  _.$_$.c = ActorState_Idle_getInstance;
  _.$_$.d = ActorState_NonExecuting_getInstance;
  _.$_$.e = ActorState_Waiting_getInstance;
  _.$_$.f = SystemSpeedCategory_Explore_getInstance;
  _.$_$.g = SystemSpeedCategory_Observe_getInstance;
  _.$_$.h = SystemSpeedCategory_Use_getInstance;
  _.$_$.i = ActorDrawableButton_init_$Init$;
  _.$_$.j = ActorDrawableButton_init_$Create$;
  _.$_$.k = ActorHandler;
  _.$_$.l = ActorDrawableButton;
  _.$_$.m = ActorImpl;
  _.$_$.n = ActorInteractionContext;
  _.$_$.o = executionStartDone;
  _.$_$.p = executionStarted;
  _.$_$.q = executionStopped;
  _.$_$.r = getExecutionTooltip;
  _.$_$.s = Handler;
  _.$_$.t = ActorViewBag;
  _.$_$.u = ActorViewContainer;
  _.$_$.v = ActorView;
  _.$_$.w = Actor;
  _.$_$.x = ClickableActorInteractionHandlerAdapter;
  _.$_$.y = SimpleActorData;
  _.$_$.z = NoNoiseGenerator;
  _.$_$.a1 = NoiseGeneratorHolder;
  _.$_$.b1 = BreakEvent;
  _.$_$.c1 = ManualSchedulerTask;
  _.$_$.d1 = SchedulerActivationStateEvent;
  _.$_$.e1 = SchedulerEvent;
  _.$_$.f1 = SchedulerImpl;
  _.$_$.g1 = SchedulerSingleStepModeEvent;
  _.$_$.h1 = Scheduler;
  _.$_$.i1 = CurrentSystemSpeedCategory;
  _.$_$.j1 = SystemSpeedCategoryEvent;
  _.$_$.k1 = AbstractExecutionError;
  _.$_$.l1 = ExecutionControlOutlet;
  _.$_$.m1 = ExecutionDepthAction;
  _.$_$.n1 = PauseOrResumeActionImpl;
  _.$_$.o1 = SchedulerActions;
  _.$_$.p1 = SingleStepModeAction;
  //endregion
  return _;
}));

//# sourceMappingURL=jabbah-execution.js.map
