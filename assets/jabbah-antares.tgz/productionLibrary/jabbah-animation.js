(function (factory) {
  if (typeof define === 'function' && define.amd)
    define(['exports', './kotlin-kotlin-stdlib.js', './jabbah-base.js'], factory);
  else if (typeof exports === 'object')
    factory(module.exports, require('./kotlin-kotlin-stdlib.js'), require('./jabbah-base.js'));
  else {
    if (typeof globalThis['kotlin-kotlin-stdlib'] === 'undefined') {
      throw new Error("Error loading module 'jabbah-animation'. Its dependency 'kotlin-kotlin-stdlib' was not found. Please, check whether 'kotlin-kotlin-stdlib' is loaded prior to 'jabbah-animation'.");
    }
    if (typeof globalThis['jabbah-base'] === 'undefined') {
      throw new Error("Error loading module 'jabbah-animation'. Its dependency 'jabbah-base' was not found. Please, check whether 'jabbah-base' is loaded prior to 'jabbah-animation'.");
    }
    globalThis['jabbah-animation'] = factory(typeof globalThis['jabbah-animation'] === 'undefined' ? {} : globalThis['jabbah-animation'], globalThis['kotlin-kotlin-stdlib'], globalThis['jabbah-base']);
  }
}(function (_, kotlin_kotlin, kotlin_jabbah_base) {
  'use strict';
  //region block: imports
  var VOID = kotlin_kotlin.$_$.b;
  var protoOf = kotlin_kotlin.$_$.t7;
  var initMetadataForClass = kotlin_kotlin.$_$.d7;
  var KProperty1 = kotlin_kotlin.$_$.v8;
  var getPropertyCallableRef = kotlin_kotlin.$_$.a7;
  var ArrayList_init_$Create$ = kotlin_kotlin.$_$.n;
  var lazy = kotlin_kotlin.$_$.qb;
  var Unit_instance = kotlin_kotlin.$_$.i;
  var toList = kotlin_kotlin.$_$.s4;
  var getKClass = kotlin_kotlin.$_$.s8;
  var logger = kotlin_jabbah_base.$_$.q7;
  var initMetadataForCompanion = kotlin_kotlin.$_$.e7;
  var Enum = kotlin_kotlin.$_$.xa;
  var AbstractModule = kotlin_jabbah_base.$_$.d7;
  var SystemSpeed = kotlin_jabbah_base.$_$.z6;
  var System_getInstance = kotlin_jabbah_base.$_$.c1;
  var BaseModule_getInstance = kotlin_jabbah_base.$_$.n;
  var initMetadataForObject = kotlin_kotlin.$_$.i7;
  var initMetadataForInterface = kotlin_kotlin.$_$.g7;
  var NoSuchElementException_init_$Create$ = kotlin_kotlin.$_$.h1;
  var removeAll = kotlin_kotlin.$_$.d4;
  var Collection = kotlin_kotlin.$_$.g2;
  var isInterface = kotlin_kotlin.$_$.m7;
  var toString = kotlin_kotlin.$_$.v7;
  var SystemSpeedEvent = kotlin_jabbah_base.$_$.x6;
  var SystemSpeedPauseEvent = kotlin_jabbah_base.$_$.y6;
  var LinkedHashSet_init_$Create$ = kotlin_kotlin.$_$.r;
  var equals = kotlin_kotlin.$_$.u6;
  var toList_0 = kotlin_kotlin.$_$.t4;
  var IllegalArgumentException_init_$Create$ = kotlin_kotlin.$_$.b1;
  var ensureNotNull = kotlin_kotlin.$_$.mb;
  var Point2D = kotlin_jabbah_base.$_$.e6;
  //endregion
  //region block: pre-declaration
  initMetadataForClass(AbstractAnimationTask, 'AbstractAnimationTask');
  initMetadataForClass(AnimationTaskImpl, 'AnimationTaskImpl', VOID, AbstractAnimationTask);
  initMetadataForCompanion(Companion);
  initMetadataForClass(State, 'State', VOID, Enum);
  initMetadataForClass(AnimationJob, 'AnimationJob');
  initMetadataForObject(AnimationModule, 'AnimationModule', VOID, AbstractModule);
  function ended$default(task, canceled, $super) {
    canceled = canceled === VOID ? false : canceled;
    var tmp;
    if ($super === VOID) {
      this.s1p(task, canceled);
      tmp = Unit_instance;
    } else {
      tmp = $super.s1p.call(this, task, canceled);
    }
    return tmp;
  }
  initMetadataForInterface(AnimationTaskListener, 'AnimationTaskListener');
  initMetadataForClass(AnimationTaskAdapter, 'AnimationTaskAdapter', AnimationTaskAdapter, VOID, [AnimationTaskListener]);
  function schedule$default(target, consumer, sequence, duration, dependsOnSystemSpeed, $super) {
    dependsOnSystemSpeed = dependsOnSystemSpeed === VOID ? false : dependsOnSystemSpeed;
    return $super === VOID ? this.j1q(target, consumer, sequence, duration, dependsOnSystemSpeed) : $super.j1q.call(this, target, consumer, sequence, duration, dependsOnSystemSpeed);
  }
  initMetadataForInterface(Animator, 'Animator');
  initMetadataForCompanion(Companion_0);
  initMetadataForClass(TaskListener, 'TaskListener', VOID, AnimationTaskAdapter);
  initMetadataForClass(AnimatorImpl, 'AnimatorImpl', VOID, VOID, [Animator]);
  initMetadataForClass(CompositeSequence, 'CompositeSequence');
  initMetadataForClass(DoubleRange, 'DoubleRange');
  initMetadataForClass(Oscillation, 'Oscillation');
  initMetadataForClass(PointRange, 'PointRange');
  //endregion
  function AnimationTaskImpl(target, consumer, sequence, duration, dependsOnSystemSpeed) {
    dependsOnSystemSpeed = dependsOnSystemSpeed === VOID ? false : dependsOnSystemSpeed;
    AbstractAnimationTask.call(this, target, consumer, sequence, duration, dependsOnSystemSpeed);
  }
  function _get_listeners__760gzy($this) {
    var tmp0 = $this.e1p_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('listeners', 1, tmp, AbstractAnimationTask$_get_listeners_$ref_u6mrzw(), null);
    return tmp0.j2();
  }
  function AbstractAnimationTask$listeners$delegate$lambda() {
    // Inline function 'kotlin.collections.mutableListOf' call
    return ArrayList_init_$Create$();
  }
  function AbstractAnimationTask$_get_listeners_$ref_u6mrzw() {
    return function (p0) {
      return _get_listeners__760gzy(p0);
    };
  }
  function AbstractAnimationTask(target, consumer, sequence, duration, dependsOnSystemSpeed, isPausable, key) {
    dependsOnSystemSpeed = dependsOnSystemSpeed === VOID ? false : dependsOnSystemSpeed;
    isPausable = isPausable === VOID ? false : isPausable;
    key = key === VOID ? null : key;
    this.x1o_1 = target;
    this.y1o_1 = consumer;
    this.z1o_1 = sequence;
    this.a1p_1 = duration;
    this.b1p_1 = dependsOnSystemSpeed;
    this.c1p_1 = isPausable;
    this.d1p_1 = key;
    var tmp = this;
    tmp.e1p_1 = lazy(AbstractAnimationTask$listeners$delegate$lambda);
  }
  protoOf(AbstractAnimationTask).f1p = function () {
    return this.x1o_1;
  };
  protoOf(AbstractAnimationTask).g1p = function () {
    return this.a1p_1;
  };
  protoOf(AbstractAnimationTask).h1p = function () {
    return this.b1p_1;
  };
  protoOf(AbstractAnimationTask).i1p = function () {
    return this.c1p_1;
  };
  protoOf(AbstractAnimationTask).o = function () {
    return this.z1o_1.o();
  };
  protoOf(AbstractAnimationTask).j1p = function (listener) {
    if (!_get_listeners__760gzy(this).n(listener)) {
      _get_listeners__760gzy(this).h(listener);
    }
    return this;
  };
  protoOf(AbstractAnimationTask).k1p = function (listener) {
    _get_listeners__760gzy(this).h2(listener);
  };
  protoOf(AbstractAnimationTask).xp = function () {
    this.o1p();
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = _get_listeners__760gzy(this).i();
    while (_iterator__ex2g4s.j()) {
      var element = _iterator__ex2g4s.k();
      element.q1p(this);
    }
  };
  protoOf(AbstractAnimationTask).yp = function () {
    this.p1p();
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = toList(_get_listeners__760gzy(this)).i();
    while (_iterator__ex2g4s.j()) {
      var element = _iterator__ex2g4s.k();
      element.r1p(this);
    }
  };
  protoOf(AbstractAnimationTask).l1p = function () {
    this.p1p();
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = toList(_get_listeners__760gzy(this)).i();
    while (_iterator__ex2g4s.j()) {
      var element = _iterator__ex2g4s.k();
      element.s1p(this, true);
    }
  };
  protoOf(AbstractAnimationTask).m1p = function (distance) {
    var tmp0_safe_receiver = this.z1o_1.t1p(distance);
    var tmp;
    if (tmp0_safe_receiver == null) {
      tmp = null;
    } else {
      // Inline function 'kotlin.let' call
      this.y1o_1(tmp0_safe_receiver);
      tmp = Unit_instance;
    }
    if (tmp == null) {
      this.yp();
    }
  };
  protoOf(AbstractAnimationTask).n1p = function () {
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = _get_listeners__760gzy(this).i();
    while (_iterator__ex2g4s.j()) {
      var element = _iterator__ex2g4s.k();
      element.u1p(this);
    }
  };
  protoOf(AbstractAnimationTask).o1p = function () {
  };
  protoOf(AbstractAnimationTask).p1p = function () {
  };
  function _get_LOG__e5r759($this) {
    var tmp0 = $this.v1p_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('LOG', 1, tmp, AnimationJob$Companion$_get_LOG_$ref_gumibr(), null);
    return tmp0.j2();
  }
  function AnimationJob$Companion$_get_LOG_$ref_gumibr() {
    return function (p0) {
      return _get_LOG__e5r759(p0);
    };
  }
  var State_Created_instance;
  var State_Running_instance;
  var State_Suspended_instance;
  var State_Ended_instance;
  var State_entriesInitialized;
  function State_initEntries() {
    if (State_entriesInitialized)
      return Unit_instance;
    State_entriesInitialized = true;
    State_Created_instance = new State('Created', 0);
    State_Running_instance = new State('Running', 1);
    State_Suspended_instance = new State('Suspended', 2);
    State_Ended_instance = new State('Ended', 3);
  }
  function Companion() {
    Companion_instance = this;
    this.v1p_1 = logger(getKClass(AnimationJob));
  }
  var Companion_instance;
  function Companion_getInstance() {
    if (Companion_instance == null)
      new Companion();
    return Companion_instance;
  }
  function State(name, ordinal) {
    Enum.call(this, name, ordinal);
  }
  function currentDistance($this) {
    if (!$this.w1p_1.h1p()) {
      return $this.x1p_1;
    }
    return $this.y1p_1.a1o_1 / 100.0 * $this.x1p_1;
  }
  function State_Created_getInstance() {
    State_initEntries();
    return State_Created_instance;
  }
  function State_Running_getInstance() {
    State_initEntries();
    return State_Running_instance;
  }
  function State_Suspended_getInstance() {
    State_initEntries();
    return State_Suspended_instance;
  }
  function State_Ended_getInstance() {
    State_initEntries();
    return State_Ended_instance;
  }
  function AnimationJob(task, maxDistance, systemSpeed) {
    Companion_getInstance();
    this.w1p_1 = task;
    this.x1p_1 = maxDistance;
    this.y1p_1 = systemSpeed;
    this.z1p_1 = State_Created_getInstance();
  }
  protoOf(AnimationJob).a1q = function () {
    return this.z1p_1.equals(State_Running_getInstance());
  };
  protoOf(AnimationJob).b1q = function () {
    return this.z1p_1.equals(State_Suspended_getInstance());
  };
  protoOf(AnimationJob).c1q = function () {
    return this.z1p_1.equals(State_Ended_getInstance());
  };
  protoOf(AnimationJob).xp = function () {
    this.z1p_1 = State_Running_getInstance();
  };
  protoOf(AnimationJob).d1q = function () {
    _get_LOG__e5r759(Companion_getInstance()).ql('suspending job');
    this.z1p_1 = State_Suspended_getInstance();
  };
  protoOf(AnimationJob).e1q = function () {
    this.z1p_1 = State_Ended_getInstance();
  };
  protoOf(AnimationJob).f1o = function () {
    _get_LOG__e5r759(Companion_getInstance()).ql('resuming job');
    this.z1p_1 = State_Running_getInstance();
  };
  protoOf(AnimationJob).f1q = function () {
    // Inline function 'kotlin.let' call
    var it = currentDistance(this);
    if (it < 1.0E-7) {
      this.d1q();
    } else {
      this.w1p_1.m1p(it);
    }
  };
  function configureProperties($this, properties) {
  }
  function AnimationModule() {
    AnimationModule_instance = this;
    AbstractModule.call(this);
    this.h1q_1 = new AnimatorImpl(new SystemSpeed(100), System_getInstance().wl());
  }
  protoOf(AnimationModule).to = function () {
    configureProperties(this, BaseModule_getInstance().zo_1);
  };
  var AnimationModule_instance;
  function AnimationModule_getInstance() {
    if (AnimationModule_instance == null)
      new AnimationModule();
    return AnimationModule_instance;
  }
  function AnimationTaskListener() {
  }
  function AnimationTaskAdapter() {
  }
  protoOf(AnimationTaskAdapter).u1p = function (task) {
  };
  protoOf(AnimationTaskAdapter).q1p = function (task) {
  };
  protoOf(AnimationTaskAdapter).s1p = function (task, canceled) {
  };
  function Animator() {
  }
  function AnimatorImpl$Companion$_get_LOG_$ref_wz99zb() {
    return function (p0) {
      return p0.o1q();
    };
  }
  function Companion_0() {
    Companion_instance_0 = this;
    this.m1q_1 = logger(getKClass(AnimatorImpl));
    this.n1q_1 = 20;
  }
  protoOf(Companion_0).o1q = function () {
    var tmp0 = this.m1q_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('LOG', 1, tmp, AnimatorImpl$Companion$_get_LOG_$ref_wz99zb(), null);
    return tmp0.j2();
  };
  var Companion_instance_0;
  function Companion_getInstance_0() {
    if (Companion_instance_0 == null)
      new Companion_0();
    return Companion_instance_0;
  }
  function _get_jobs__d8todx($this) {
    var tmp0 = $this.u1q_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('jobs', 1, tmp, AnimatorImpl$_get_jobs_$ref_fbkevz(), null);
    return tmp0.j2();
  }
  function handle($this, event) {
    event.j1o_1;
    $this.p1q_1;
  }
  function handle_0($this, event) {
    if (event.g1o_1 === $this.p1q_1) {
      if (event.h1o_1 === 0 && event.i1o_1 > 0) {
        resumeSuspendedJobs($this);
      }
    }
  }
  function calculateDistance($this, task) {
    return task.o() / (task.g1p() / $this.r1q_1);
  }
  function findJob($this, task) {
    var tmp0 = _get_jobs__d8todx($this);
    var tmp$ret$0;
    $l$block: {
      // Inline function 'kotlin.collections.first' call
      var _iterator__ex2g4s = tmp0.i();
      while (_iterator__ex2g4s.j()) {
        var element = _iterator__ex2g4s.k();
        if (element.w1p_1 === task) {
          tmp$ret$0 = element;
          break $l$block;
        }
      }
      throw NoSuchElementException_init_$Create$('Collection contains no element matching the predicate.');
    }
    return tmp$ret$0;
  }
  function animationStep($this) {
    // Inline function 'kotlin.collections.filter' call
    var tmp0 = toList(_get_jobs__d8todx($this));
    // Inline function 'kotlin.collections.filterTo' call
    var destination = ArrayList_init_$Create$();
    var _iterator__ex2g4s = tmp0.i();
    while (_iterator__ex2g4s.j()) {
      var element = _iterator__ex2g4s.k();
      if (element.a1q() && (!$this.p1q_1.b1o_1 || !element.w1p_1.i1p())) {
        destination.h(element);
      }
    }
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s_0 = destination.i();
    while (_iterator__ex2g4s_0.j()) {
      var element_0 = _iterator__ex2g4s_0.k();
      element_0.f1q();
    }
    removeEndedJobs($this);
  }
  function removeEndedJobs($this) {
    var tmp = _get_jobs__d8todx($this);
    removeAll(tmp, AnimatorImpl$removeEndedJobs$lambda);
    if (!hasRunningJobs($this)) {
      $this.q1q_1.yp();
    }
  }
  function hasRunningJobs($this) {
    var tmp0 = _get_jobs__d8todx($this);
    var tmp$ret$0;
    $l$block_0: {
      // Inline function 'kotlin.collections.any' call
      var tmp;
      if (isInterface(tmp0, Collection)) {
        tmp = tmp0.m();
      } else {
        tmp = false;
      }
      if (tmp) {
        tmp$ret$0 = false;
        break $l$block_0;
      }
      var _iterator__ex2g4s = tmp0.i();
      while (_iterator__ex2g4s.j()) {
        var element = _iterator__ex2g4s.k();
        if (element.a1q()) {
          tmp$ret$0 = true;
          break $l$block_0;
        }
      }
      tmp$ret$0 = false;
    }
    return tmp$ret$0;
  }
  function resumeSuspendedJobs($this) {
    Companion_getInstance_0().o1q().ql('resume suspended Jobs');
    // Inline function 'kotlin.collections.filter' call
    var tmp0 = _get_jobs__d8todx($this);
    // Inline function 'kotlin.collections.filterTo' call
    var destination = ArrayList_init_$Create$();
    var _iterator__ex2g4s = tmp0.i();
    while (_iterator__ex2g4s.j()) {
      var element = _iterator__ex2g4s.k();
      if (element.b1q()) {
        destination.h(element);
      }
    }
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s_0 = destination.i();
    while (_iterator__ex2g4s_0.j()) {
      var element_0 = _iterator__ex2g4s_0.k();
      element_0.f1o();
    }
    startTimerIfNeeded($this);
  }
  function startTimerIfNeeded($this) {
    if (!$this.q1q_1.zp() && hasRunningJobs($this)) {
      $this.q1q_1.xp();
    }
  }
  function TaskListener($outer) {
    this.x1q_1 = $outer;
    AnimationTaskAdapter.call(this);
  }
  protoOf(TaskListener).q1p = function (task) {
    Companion_getInstance_0().o1q().ql(toString(task) + ' started');
    findJob(this.x1q_1, task).xp();
    startTimerIfNeeded(this.x1q_1);
  };
  protoOf(TaskListener).s1p = function (task, canceled) {
    findJob(this.x1q_1, task).e1q();
    task.k1p(this.x1q_1.t1q_1);
    removeEndedJobs(this.x1q_1);
    Companion_getInstance_0().o1q().ql(toString(task) + ' ended, ' + this.x1q_1.y1q() + ' remaining tasks');
  };
  function AnimatorImpl$jobs$delegate$lambda() {
    // Inline function 'kotlin.collections.mutableListOf' call
    return ArrayList_init_$Create$();
  }
  function AnimatorImpl$_get_jobs_$ref_fbkevz() {
    return function (p0) {
      return _get_jobs__d8todx(p0);
    };
  }
  function AnimatorImpl$systemSpeedHandler$lambda(this$0) {
    return function (it) {
      handle_0(this$0, it);
      return Unit_instance;
    };
  }
  function AnimatorImpl$pauseEventListener$lambda(this$0) {
    return function (it) {
      handle(this$0, it);
      return Unit_instance;
    };
  }
  function AnimatorImpl$lambda(this$0) {
    return function (it) {
      animationStep(this$0);
      return Unit_instance;
    };
  }
  function AnimatorImpl$removeEndedJobs$lambda(it) {
    return it.c1q();
  }
  function AnimatorImpl(systemSpeed, timer, period, eventBus) {
    Companion_getInstance_0();
    timer = timer === VOID ? System_getInstance().wl() : timer;
    period = period === VOID ? 20 : period;
    eventBus = eventBus === VOID ? BaseModule_getInstance().bp_1 : eventBus;
    this.p1q_1 = systemSpeed;
    this.q1q_1 = timer;
    this.r1q_1 = period;
    this.s1q_1 = eventBus;
    this.t1q_1 = new TaskListener(this);
    var tmp = this;
    tmp.u1q_1 = lazy(AnimatorImpl$jobs$delegate$lambda);
    var tmp_0 = this;
    tmp_0.v1q_1 = AnimatorImpl$systemSpeedHandler$lambda(this);
    var tmp_1 = this;
    tmp_1.w1q_1 = AnimatorImpl$pauseEventListener$lambda(this);
    this.q1q_1.wp(this.r1q_1, VOID, AnimatorImpl$lambda(this));
    this.s1q_1.z17(getKClass(SystemSpeedEvent), this.v1q_1);
    this.s1q_1.z17(getKClass(SystemSpeedPauseEvent), this.w1q_1);
  }
  protoOf(AnimatorImpl).y1q = function () {
    return _get_jobs__d8todx(this).o();
  };
  protoOf(AnimatorImpl).i1q = function (task) {
    Companion_getInstance_0().o1q().ql('Scheduling AnimationTask ' + toString(task));
    task.j1p(this.t1q_1);
    _get_jobs__d8todx(this).h(new AnimationJob(task, calculateDistance(this, task), this.p1q_1));
    task.n1p();
    return task;
  };
  protoOf(AnimatorImpl).j1q = function (target, consumer, sequence, duration, dependsOnSystemSpeed) {
    return this.i1q(new AnimationTaskImpl(target, consumer, sequence, duration, dependsOnSystemSpeed));
  };
  protoOf(AnimatorImpl).z1q = function (target) {
    // Inline function 'kotlin.collections.mutableSetOf' call
    var tasks = LinkedHashSet_init_$Create$();
    var jobList = toList(_get_jobs__d8todx(this));
    // Inline function 'kotlin.collections.filter' call
    // Inline function 'kotlin.collections.filterTo' call
    var destination = ArrayList_init_$Create$();
    var _iterator__ex2g4s = jobList.i();
    while (_iterator__ex2g4s.j()) {
      var element = _iterator__ex2g4s.k();
      if (equals(element.w1p_1.f1p(), target)) {
        destination.h(element);
      }
    }
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s_0 = destination.i();
    while (_iterator__ex2g4s_0.j()) {
      var element_0 = _iterator__ex2g4s_0.k();
      tasks.h(element_0.w1p_1);
    }
    return tasks;
  };
  protoOf(AnimatorImpl).l1q = function () {
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = toList(_get_jobs__d8todx(this)).i();
    while (_iterator__ex2g4s.j()) {
      var element = _iterator__ex2g4s.k();
      element.w1p_1.l1p();
    }
  };
  function CompositeSequence(sequences) {
    this.a1r_1 = toList_0(sequences);
    this.b1r_1 = 0;
  }
  protoOf(CompositeSequence).o = function () {
    // Inline function 'kotlin.collections.sumOf' call
    var sum = 0;
    var _iterator__ex2g4s = this.a1r_1.i();
    while (_iterator__ex2g4s.j()) {
      var element = _iterator__ex2g4s.k();
      var tmp = sum;
      sum = tmp + element.o();
    }
    return sum;
  };
  protoOf(CompositeSequence).t1p = function (distance) {
    var next = this.a1r_1.l(this.b1r_1).t1p(distance);
    if (!(next == null)) {
      return next;
    }
    if (this.b1r_1 < (this.a1r_1.o() - 1 | 0)) {
      this.b1r_1 = this.b1r_1 + 1 | 0;
      return this.a1r_1.l(this.b1r_1).t1p(distance);
    }
    return null;
  };
  function calculateNext($this, distance) {
    // Inline function 'kotlin.require' call
    if (!(distance >= 0)) {
      var message = 'distance must not be negative';
      throw IllegalArgumentException_init_$Create$(toString(message));
    }
    if ($this.f1r_1) {
      $this.e1r_1 = null;
      return Unit_instance;
    }
    if ($this.g1r_1 <= 1.0E-7) {
      $this.e1r_1 = null;
      return Unit_instance;
    }
    if ($this.d1r_1 >= $this.c1r_1) {
      $this.e1r_1 = ensureNotNull($this.e1r_1) + distance;
      if (ensureNotNull($this.e1r_1) >= $this.d1r_1) {
        $this.f1r_1 = true;
        $this.e1r_1 = $this.d1r_1;
      }
    } else {
      $this.e1r_1 = ensureNotNull($this.e1r_1) - distance;
      if (ensureNotNull($this.e1r_1) <= $this.d1r_1) {
        $this.f1r_1 = true;
        $this.e1r_1 = $this.d1r_1;
      }
    }
  }
  function DoubleRange(begin, end) {
    this.c1r_1 = begin;
    this.d1r_1 = end;
    this.e1r_1 = this.c1r_1;
    this.f1r_1 = false;
    var tmp = this;
    // Inline function 'kotlin.math.abs' call
    var x = this.c1r_1 - this.d1r_1;
    tmp.g1r_1 = Math.abs(x);
  }
  protoOf(DoubleRange).o = function () {
    return this.g1r_1;
  };
  protoOf(DoubleRange).t1p = function (distance) {
    if (this.e1r_1 == null) {
      return null;
    }
    var result = this.e1r_1;
    calculateNext(this, distance);
    return ensureNotNull(result);
  };
  protoOf(DoubleRange).h1r = function (reversed) {
    var tmp;
    if (reversed) {
      tmp = new DoubleRange(this.d1r_1, this.c1r_1);
    } else {
      tmp = new DoubleRange(this.c1r_1, this.d1r_1);
    }
    return tmp;
  };
  function Oscillation(sequence) {
    this.i1r_1 = sequence;
    this.j1r_1 = sequence.o();
  }
  protoOf(Oscillation).o = function () {
    return this.j1r_1;
  };
  protoOf(Oscillation).t1p = function (distance) {
    var next = this.i1r_1.t1p(distance);
    if (!(next == null)) {
      return next;
    }
    this.i1r_1 = this.i1r_1.h1r(true);
    return this.i1r_1.t1p(distance);
  };
  function hasNext($this) {
    return !($this.o1r_1 == null) && !($this.p1r_1 == null);
  }
  function getNextXY($this, distance) {
    calculateNextXY($this, distance);
    $this.o1r_1 = $this.q1r_1;
    $this.p1r_1 = $this.r1r_1;
  }
  function calculateNextXY($this, distance) {
    var tmp;
    if (distance <= 0.0) {
      tmp = 1.0E-7;
    } else {
      tmp = distance;
    }
    var effDist = tmp;
    if ($this.o() <= 1.0E-7) {
      $this.q1r_1 = null;
      $this.r1r_1 = null;
      return Unit_instance;
    }
    var dx = ($this.l1r_1.kn_1 - $this.k1r_1.kn_1) / $this.o() * effDist;
    var dy = ($this.l1r_1.ln_1 - $this.k1r_1.ln_1) / $this.o() * effDist;
    $this.q1r_1 = ensureNotNull($this.o1r_1) + dx;
    $this.r1r_1 = ensureNotNull($this.p1r_1) + dy;
    var d = $this.k1r_1.e1h(ensureNotNull($this.q1r_1), ensureNotNull($this.r1r_1));
    if (d >= $this.o()) {
      $this.s1r_1 = d - $this.o();
      if (d === $this.o() || $this.m1r_1) {
        $this.q1r_1 = $this.l1r_1.kn_1;
        $this.r1r_1 = $this.l1r_1.ln_1;
      } else {
        resetNext($this);
        return Unit_instance;
      }
    }
    if ($this.q1r_1 === ensureNotNull($this.o1r_1) && $this.r1r_1 === ensureNotNull($this.p1r_1)) {
      resetNext($this);
    }
  }
  function resetNext($this) {
    $this.q1r_1 = null;
    $this.r1r_1 = null;
  }
  function PointRange(begin, end, returnEndPoint, initialOffset) {
    returnEndPoint = returnEndPoint === VOID ? true : returnEndPoint;
    initialOffset = initialOffset === VOID ? null : initialOffset;
    this.k1r_1 = begin;
    this.l1r_1 = end;
    this.m1r_1 = returnEndPoint;
    this.n1r_1 = this.k1r_1.f1h(this.l1r_1);
    this.o1r_1 = this.k1r_1.kn_1;
    this.p1r_1 = this.k1r_1.ln_1;
    this.q1r_1 = null;
    this.r1r_1 = null;
    this.s1r_1 = 0.0;
    if (!(initialOffset == null) && initialOffset > 1.0E-7) {
      calculateNextXY(this, initialOffset);
      this.o1r_1 = this.q1r_1;
      this.p1r_1 = this.r1r_1;
    }
  }
  protoOf(PointRange).o = function () {
    return this.n1r_1;
  };
  protoOf(PointRange).t1p = function (distance) {
    var oldValueX = this.o1r_1;
    var oldValueY = this.p1r_1;
    if (!hasNext(this)) {
      return null;
    }
    getNextXY(this, distance);
    return new Point2D(ensureNotNull(oldValueX), ensureNotNull(oldValueY));
  };
  //region block: post-declaration
  protoOf(AnimationTaskAdapter).r1p = ended$default;
  protoOf(AnimatorImpl).k1q = schedule$default;
  //endregion
  //region block: exports
  _.$_$ = _.$_$ || {};
  _.$_$.a = AnimationModule_getInstance;
  _.$_$.b = AbstractAnimationTask;
  _.$_$.c = AnimationTaskAdapter;
  _.$_$.d = AnimatorImpl;
  _.$_$.e = CompositeSequence;
  _.$_$.f = DoubleRange;
  _.$_$.g = Oscillation;
  _.$_$.h = PointRange;
  //endregion
  return _;
}));

//# sourceMappingURL=jabbah-animation.js.map
