(function (factory) {
  if (typeof define === 'function' && define.amd)
    define(['exports', './kotlin-kotlin-stdlib.js', './jabbah-base.js'], factory);
  else if (typeof exports === 'object')
    factory(module.exports, require('./kotlin-kotlin-stdlib.js'), require('./jabbah-base.js'));
  else {
    if (typeof globalThis['kotlin-kotlin-stdlib'] === 'undefined') {
      throw new Error("Error loading module 'jabbah-animation'. Its dependency 'kotlin-kotlin-stdlib' was not found. Please, check whether 'kotlin-kotlin-stdlib' is loaded prior to 'jabbah-animation'.");
    }
    if (typeof globalThis['jabbah-base'] === 'undefined') {
      throw new Error("Error loading module 'jabbah-animation'. Its dependency 'jabbah-base' was not found. Please, check whether 'jabbah-base' is loaded prior to 'jabbah-animation'.");
    }
    globalThis['jabbah-animation'] = factory(typeof globalThis['jabbah-animation'] === 'undefined' ? {} : globalThis['jabbah-animation'], globalThis['kotlin-kotlin-stdlib'], globalThis['jabbah-base']);
  }
}(function (_, kotlin_kotlin, kotlin_jabbah_base) {
  'use strict';
  //region block: imports
  var VOID = kotlin_kotlin.$_$.b;
  var protoOf = kotlin_kotlin.$_$.t7;
  var initMetadataForClass = kotlin_kotlin.$_$.d7;
  var KProperty1 = kotlin_kotlin.$_$.t8;
  var getPropertyCallableRef = kotlin_kotlin.$_$.a7;
  var ArrayList_init_$Create$ = kotlin_kotlin.$_$.n;
  var lazy = kotlin_kotlin.$_$.ob;
  var Unit_instance = kotlin_kotlin.$_$.i;
  var toList = kotlin_kotlin.$_$.s4;
  var getKClass = kotlin_kotlin.$_$.q8;
  var logger = kotlin_jabbah_base.$_$.q7;
  var initMetadataForCompanion = kotlin_kotlin.$_$.e7;
  var Enum = kotlin_kotlin.$_$.va;
  var AbstractModule = kotlin_jabbah_base.$_$.d7;
  var SystemSpeed = kotlin_jabbah_base.$_$.z6;
  var System_getInstance = kotlin_jabbah_base.$_$.c1;
  var BaseModule_getInstance = kotlin_jabbah_base.$_$.n;
  var initMetadataForObject = kotlin_kotlin.$_$.i7;
  var initMetadataForInterface = kotlin_kotlin.$_$.g7;
  var NoSuchElementException_init_$Create$ = kotlin_kotlin.$_$.h1;
  var removeAll = kotlin_kotlin.$_$.d4;
  var Collection = kotlin_kotlin.$_$.g2;
  var isInterface = kotlin_kotlin.$_$.m7;
  var toString = kotlin_kotlin.$_$.v7;
  var SystemSpeedEvent = kotlin_jabbah_base.$_$.x6;
  var SystemSpeedPauseEvent = kotlin_jabbah_base.$_$.y6;
  var LinkedHashSet_init_$Create$ = kotlin_kotlin.$_$.r;
  var equals = kotlin_kotlin.$_$.u6;
  var toList_0 = kotlin_kotlin.$_$.t4;
  var IllegalArgumentException_init_$Create$ = kotlin_kotlin.$_$.b1;
  var ensureNotNull = kotlin_kotlin.$_$.kb;
  var Point2D = kotlin_jabbah_base.$_$.e6;
  //endregion
  //region block: pre-declaration
  initMetadataForClass(AbstractAnimationTask, 'AbstractAnimationTask');
  initMetadataForClass(AnimationTaskImpl, 'AnimationTaskImpl', VOID, AbstractAnimationTask);
  initMetadataForCompanion(Companion);
  initMetadataForClass(State, 'State', VOID, Enum);
  initMetadataForClass(AnimationJob, 'AnimationJob');
  initMetadataForObject(AnimationModule, 'AnimationModule', VOID, AbstractModule);
  function ended$default(task, canceled, $super) {
    canceled = canceled === VOID ? false : canceled;
    var tmp;
    if ($super === VOID) {
      this.c1p(task, canceled);
      tmp = Unit_instance;
    } else {
      tmp = $super.c1p.call(this, task, canceled);
    }
    return tmp;
  }
  initMetadataForInterface(AnimationTaskListener, 'AnimationTaskListener');
  initMetadataForClass(AnimationTaskAdapter, 'AnimationTaskAdapter', AnimationTaskAdapter, VOID, [AnimationTaskListener]);
  function schedule$default(target, consumer, sequence, duration, dependsOnSystemSpeed, $super) {
    dependsOnSystemSpeed = dependsOnSystemSpeed === VOID ? false : dependsOnSystemSpeed;
    return $super === VOID ? this.t1p(target, consumer, sequence, duration, dependsOnSystemSpeed) : $super.t1p.call(this, target, consumer, sequence, duration, dependsOnSystemSpeed);
  }
  initMetadataForInterface(Animator, 'Animator');
  initMetadataForCompanion(Companion_0);
  initMetadataForClass(TaskListener, 'TaskListener', VOID, AnimationTaskAdapter);
  initMetadataForClass(AnimatorImpl, 'AnimatorImpl', VOID, VOID, [Animator]);
  initMetadataForClass(CompositeSequence, 'CompositeSequence');
  initMetadataForClass(DoubleRange, 'DoubleRange');
  initMetadataForClass(Oscillation, 'Oscillation');
  initMetadataForClass(PointRange, 'PointRange');
  //endregion
  function AnimationTaskImpl(target, consumer, sequence, duration, dependsOnSystemSpeed) {
    dependsOnSystemSpeed = dependsOnSystemSpeed === VOID ? false : dependsOnSystemSpeed;
    AbstractAnimationTask.call(this, target, consumer, sequence, duration, dependsOnSystemSpeed);
  }
  function _get_listeners__760gzy($this) {
    var tmp0 = $this.o1o_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('listeners', 1, tmp, AbstractAnimationTask$_get_listeners_$ref_u6mrzw(), null);
    return tmp0.j2();
  }
  function AbstractAnimationTask$listeners$delegate$lambda() {
    // Inline function 'kotlin.collections.mutableListOf' call
    return ArrayList_init_$Create$();
  }
  function AbstractAnimationTask$_get_listeners_$ref_u6mrzw() {
    return function (p0) {
      return _get_listeners__760gzy(p0);
    };
  }
  function AbstractAnimationTask(target, consumer, sequence, duration, dependsOnSystemSpeed, isPausable, key) {
    dependsOnSystemSpeed = dependsOnSystemSpeed === VOID ? false : dependsOnSystemSpeed;
    isPausable = isPausable === VOID ? false : isPausable;
    key = key === VOID ? null : key;
    this.h1o_1 = target;
    this.i1o_1 = consumer;
    this.j1o_1 = sequence;
    this.k1o_1 = duration;
    this.l1o_1 = dependsOnSystemSpeed;
    this.m1o_1 = isPausable;
    this.n1o_1 = key;
    var tmp = this;
    tmp.o1o_1 = lazy(AbstractAnimationTask$listeners$delegate$lambda);
  }
  protoOf(AbstractAnimationTask).p1o = function () {
    return this.h1o_1;
  };
  protoOf(AbstractAnimationTask).q1o = function () {
    return this.k1o_1;
  };
  protoOf(AbstractAnimationTask).r1o = function () {
    return this.l1o_1;
  };
  protoOf(AbstractAnimationTask).s1o = function () {
    return this.m1o_1;
  };
  protoOf(AbstractAnimationTask).o = function () {
    return this.j1o_1.o();
  };
  protoOf(AbstractAnimationTask).t1o = function (listener) {
    if (!_get_listeners__760gzy(this).n(listener)) {
      _get_listeners__760gzy(this).h(listener);
    }
    return this;
  };
  protoOf(AbstractAnimationTask).u1o = function (listener) {
    _get_listeners__760gzy(this).h2(listener);
  };
  protoOf(AbstractAnimationTask).vp = function () {
    this.y1o();
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = _get_listeners__760gzy(this).i();
    while (_iterator__ex2g4s.j()) {
      var element = _iterator__ex2g4s.k();
      element.a1p(this);
    }
  };
  protoOf(AbstractAnimationTask).wp = function () {
    this.z1o();
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = toList(_get_listeners__760gzy(this)).i();
    while (_iterator__ex2g4s.j()) {
      var element = _iterator__ex2g4s.k();
      element.b1p(this);
    }
  };
  protoOf(AbstractAnimationTask).v1o = function () {
    this.z1o();
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = toList(_get_listeners__760gzy(this)).i();
    while (_iterator__ex2g4s.j()) {
      var element = _iterator__ex2g4s.k();
      element.c1p(this, true);
    }
  };
  protoOf(AbstractAnimationTask).w1o = function (distance) {
    var tmp0_safe_receiver = this.j1o_1.d1p(distance);
    var tmp;
    if (tmp0_safe_receiver == null) {
      tmp = null;
    } else {
      // Inline function 'kotlin.let' call
      this.i1o_1(tmp0_safe_receiver);
      tmp = Unit_instance;
    }
    if (tmp == null) {
      this.wp();
    }
  };
  protoOf(AbstractAnimationTask).x1o = function () {
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = _get_listeners__760gzy(this).i();
    while (_iterator__ex2g4s.j()) {
      var element = _iterator__ex2g4s.k();
      element.e1p(this);
    }
  };
  protoOf(AbstractAnimationTask).y1o = function () {
  };
  protoOf(AbstractAnimationTask).z1o = function () {
  };
  function _get_LOG__e5r759($this) {
    var tmp0 = $this.f1p_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('LOG', 1, tmp, AnimationJob$Companion$_get_LOG_$ref_gumibr(), null);
    return tmp0.j2();
  }
  function AnimationJob$Companion$_get_LOG_$ref_gumibr() {
    return function (p0) {
      return _get_LOG__e5r759(p0);
    };
  }
  var State_Created_instance;
  var State_Running_instance;
  var State_Suspended_instance;
  var State_Ended_instance;
  var State_entriesInitialized;
  function State_initEntries() {
    if (State_entriesInitialized)
      return Unit_instance;
    State_entriesInitialized = true;
    State_Created_instance = new State('Created', 0);
    State_Running_instance = new State('Running', 1);
    State_Suspended_instance = new State('Suspended', 2);
    State_Ended_instance = new State('Ended', 3);
  }
  function Companion() {
    Companion_instance = this;
    this.f1p_1 = logger(getKClass(AnimationJob));
  }
  var Companion_instance;
  function Companion_getInstance() {
    if (Companion_instance == null)
      new Companion();
    return Companion_instance;
  }
  function State(name, ordinal) {
    Enum.call(this, name, ordinal);
  }
  function currentDistance($this) {
    if (!$this.g1p_1.r1o()) {
      return $this.h1p_1;
    }
    return $this.i1p_1.k1n_1 / 100.0 * $this.h1p_1;
  }
  function State_Created_getInstance() {
    State_initEntries();
    return State_Created_instance;
  }
  function State_Running_getInstance() {
    State_initEntries();
    return State_Running_instance;
  }
  function State_Suspended_getInstance() {
    State_initEntries();
    return State_Suspended_instance;
  }
  function State_Ended_getInstance() {
    State_initEntries();
    return State_Ended_instance;
  }
  function AnimationJob(task, maxDistance, systemSpeed) {
    Companion_getInstance();
    this.g1p_1 = task;
    this.h1p_1 = maxDistance;
    this.i1p_1 = systemSpeed;
    this.j1p_1 = State_Created_getInstance();
  }
  protoOf(AnimationJob).k1p = function () {
    return this.j1p_1.equals(State_Running_getInstance());
  };
  protoOf(AnimationJob).l1p = function () {
    return this.j1p_1.equals(State_Suspended_getInstance());
  };
  protoOf(AnimationJob).m1p = function () {
    return this.j1p_1.equals(State_Ended_getInstance());
  };
  protoOf(AnimationJob).vp = function () {
    this.j1p_1 = State_Running_getInstance();
  };
  protoOf(AnimationJob).n1p = function () {
    _get_LOG__e5r759(Companion_getInstance()).ol('suspending job');
    this.j1p_1 = State_Suspended_getInstance();
  };
  protoOf(AnimationJob).o1p = function () {
    this.j1p_1 = State_Ended_getInstance();
  };
  protoOf(AnimationJob).p1n = function () {
    _get_LOG__e5r759(Companion_getInstance()).ol('resuming job');
    this.j1p_1 = State_Running_getInstance();
  };
  protoOf(AnimationJob).p1p = function () {
    // Inline function 'kotlin.let' call
    var it = currentDistance(this);
    if (it < 1.0E-7) {
      this.n1p();
    } else {
      this.g1p_1.w1o(it);
    }
  };
  function configureProperties($this, properties) {
  }
  function AnimationModule() {
    AnimationModule_instance = this;
    AbstractModule.call(this);
    this.r1p_1 = new AnimatorImpl(new SystemSpeed(100), System_getInstance().ul());
  }
  protoOf(AnimationModule).ro = function () {
    configureProperties(this, BaseModule_getInstance().xo_1);
  };
  var AnimationModule_instance;
  function AnimationModule_getInstance() {
    if (AnimationModule_instance == null)
      new AnimationModule();
    return AnimationModule_instance;
  }
  function AnimationTaskListener() {
  }
  function AnimationTaskAdapter() {
  }
  protoOf(AnimationTaskAdapter).e1p = function (task) {
  };
  protoOf(AnimationTaskAdapter).a1p = function (task) {
  };
  protoOf(AnimationTaskAdapter).c1p = function (task, canceled) {
  };
  function Animator() {
  }
  function AnimatorImpl$Companion$_get_LOG_$ref_wz99zb() {
    return function (p0) {
      return p0.y1p();
    };
  }
  function Companion_0() {
    Companion_instance_0 = this;
    this.w1p_1 = logger(getKClass(AnimatorImpl));
    this.x1p_1 = 20;
  }
  protoOf(Companion_0).y1p = function () {
    var tmp0 = this.w1p_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('LOG', 1, tmp, AnimatorImpl$Companion$_get_LOG_$ref_wz99zb(), null);
    return tmp0.j2();
  };
  var Companion_instance_0;
  function Companion_getInstance_0() {
    if (Companion_instance_0 == null)
      new Companion_0();
    return Companion_instance_0;
  }
  function _get_jobs__d8todx($this) {
    var tmp0 = $this.e1q_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('jobs', 1, tmp, AnimatorImpl$_get_jobs_$ref_fbkevz(), null);
    return tmp0.j2();
  }
  function handle($this, event) {
    event.t1n_1;
    $this.z1p_1;
  }
  function handle_0($this, event) {
    if (event.q1n_1 === $this.z1p_1) {
      if (event.r1n_1 === 0 && event.s1n_1 > 0) {
        resumeSuspendedJobs($this);
      }
    }
  }
  function calculateDistance($this, task) {
    return task.o() / (task.q1o() / $this.b1q_1);
  }
  function findJob($this, task) {
    var tmp0 = _get_jobs__d8todx($this);
    var tmp$ret$0;
    $l$block: {
      // Inline function 'kotlin.collections.first' call
      var _iterator__ex2g4s = tmp0.i();
      while (_iterator__ex2g4s.j()) {
        var element = _iterator__ex2g4s.k();
        if (element.g1p_1 === task) {
          tmp$ret$0 = element;
          break $l$block;
        }
      }
      throw NoSuchElementException_init_$Create$('Collection contains no element matching the predicate.');
    }
    return tmp$ret$0;
  }
  function animationStep($this) {
    // Inline function 'kotlin.collections.filter' call
    var tmp0 = toList(_get_jobs__d8todx($this));
    // Inline function 'kotlin.collections.filterTo' call
    var destination = ArrayList_init_$Create$();
    var _iterator__ex2g4s = tmp0.i();
    while (_iterator__ex2g4s.j()) {
      var element = _iterator__ex2g4s.k();
      if (element.k1p() && (!$this.z1p_1.l1n_1 || !element.g1p_1.s1o())) {
        destination.h(element);
      }
    }
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s_0 = destination.i();
    while (_iterator__ex2g4s_0.j()) {
      var element_0 = _iterator__ex2g4s_0.k();
      element_0.p1p();
    }
    removeEndedJobs($this);
  }
  function removeEndedJobs($this) {
    var tmp = _get_jobs__d8todx($this);
    removeAll(tmp, AnimatorImpl$removeEndedJobs$lambda);
    if (!hasRunningJobs($this)) {
      $this.a1q_1.wp();
    }
  }
  function hasRunningJobs($this) {
    var tmp0 = _get_jobs__d8todx($this);
    var tmp$ret$0;
    $l$block_0: {
      // Inline function 'kotlin.collections.any' call
      var tmp;
      if (isInterface(tmp0, Collection)) {
        tmp = tmp0.m();
      } else {
        tmp = false;
      }
      if (tmp) {
        tmp$ret$0 = false;
        break $l$block_0;
      }
      var _iterator__ex2g4s = tmp0.i();
      while (_iterator__ex2g4s.j()) {
        var element = _iterator__ex2g4s.k();
        if (element.k1p()) {
          tmp$ret$0 = true;
          break $l$block_0;
        }
      }
      tmp$ret$0 = false;
    }
    return tmp$ret$0;
  }
  function resumeSuspendedJobs($this) {
    Companion_getInstance_0().y1p().ol('resume suspended Jobs');
    // Inline function 'kotlin.collections.filter' call
    var tmp0 = _get_jobs__d8todx($this);
    // Inline function 'kotlin.collections.filterTo' call
    var destination = ArrayList_init_$Create$();
    var _iterator__ex2g4s = tmp0.i();
    while (_iterator__ex2g4s.j()) {
      var element = _iterator__ex2g4s.k();
      if (element.l1p()) {
        destination.h(element);
      }
    }
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s_0 = destination.i();
    while (_iterator__ex2g4s_0.j()) {
      var element_0 = _iterator__ex2g4s_0.k();
      element_0.p1n();
    }
    startTimerIfNeeded($this);
  }
  function startTimerIfNeeded($this) {
    if (!$this.a1q_1.xp() && hasRunningJobs($this)) {
      $this.a1q_1.vp();
    }
  }
  function TaskListener($outer) {
    this.h1q_1 = $outer;
    AnimationTaskAdapter.call(this);
  }
  protoOf(TaskListener).a1p = function (task) {
    Companion_getInstance_0().y1p().ol(toString(task) + ' started');
    findJob(this.h1q_1, task).vp();
    startTimerIfNeeded(this.h1q_1);
  };
  protoOf(TaskListener).c1p = function (task, canceled) {
    findJob(this.h1q_1, task).o1p();
    task.u1o(this.h1q_1.d1q_1);
    removeEndedJobs(this.h1q_1);
    Companion_getInstance_0().y1p().ol(toString(task) + ' ended, ' + this.h1q_1.i1q() + ' remaining tasks');
  };
  function AnimatorImpl$jobs$delegate$lambda() {
    // Inline function 'kotlin.collections.mutableListOf' call
    return ArrayList_init_$Create$();
  }
  function AnimatorImpl$_get_jobs_$ref_fbkevz() {
    return function (p0) {
      return _get_jobs__d8todx(p0);
    };
  }
  function AnimatorImpl$systemSpeedHandler$lambda(this$0) {
    return function (it) {
      handle_0(this$0, it);
      return Unit_instance;
    };
  }
  function AnimatorImpl$pauseEventListener$lambda(this$0) {
    return function (it) {
      handle(this$0, it);
      return Unit_instance;
    };
  }
  function AnimatorImpl$lambda(this$0) {
    return function (it) {
      animationStep(this$0);
      return Unit_instance;
    };
  }
  function AnimatorImpl$removeEndedJobs$lambda(it) {
    return it.m1p();
  }
  function AnimatorImpl(systemSpeed, timer, period, eventBus) {
    Companion_getInstance_0();
    timer = timer === VOID ? System_getInstance().ul() : timer;
    period = period === VOID ? 20 : period;
    eventBus = eventBus === VOID ? BaseModule_getInstance().zo_1 : eventBus;
    this.z1p_1 = systemSpeed;
    this.a1q_1 = timer;
    this.b1q_1 = period;
    this.c1q_1 = eventBus;
    this.d1q_1 = new TaskListener(this);
    var tmp = this;
    tmp.e1q_1 = lazy(AnimatorImpl$jobs$delegate$lambda);
    var tmp_0 = this;
    tmp_0.f1q_1 = AnimatorImpl$systemSpeedHandler$lambda(this);
    var tmp_1 = this;
    tmp_1.g1q_1 = AnimatorImpl$pauseEventListener$lambda(this);
    this.a1q_1.up(this.b1q_1, VOID, AnimatorImpl$lambda(this));
    this.c1q_1.j17(getKClass(SystemSpeedEvent), this.f1q_1);
    this.c1q_1.j17(getKClass(SystemSpeedPauseEvent), this.g1q_1);
  }
  protoOf(AnimatorImpl).i1q = function () {
    return _get_jobs__d8todx(this).o();
  };
  protoOf(AnimatorImpl).s1p = function (task) {
    Companion_getInstance_0().y1p().ol('Scheduling AnimationTask ' + toString(task));
    task.t1o(this.d1q_1);
    _get_jobs__d8todx(this).h(new AnimationJob(task, calculateDistance(this, task), this.z1p_1));
    task.x1o();
    return task;
  };
  protoOf(AnimatorImpl).t1p = function (target, consumer, sequence, duration, dependsOnSystemSpeed) {
    return this.s1p(new AnimationTaskImpl(target, consumer, sequence, duration, dependsOnSystemSpeed));
  };
  protoOf(AnimatorImpl).j1q = function (target) {
    // Inline function 'kotlin.collections.mutableSetOf' call
    var tasks = LinkedHashSet_init_$Create$();
    var jobList = toList(_get_jobs__d8todx(this));
    // Inline function 'kotlin.collections.filter' call
    // Inline function 'kotlin.collections.filterTo' call
    var destination = ArrayList_init_$Create$();
    var _iterator__ex2g4s = jobList.i();
    while (_iterator__ex2g4s.j()) {
      var element = _iterator__ex2g4s.k();
      if (equals(element.g1p_1.p1o(), target)) {
        destination.h(element);
      }
    }
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s_0 = destination.i();
    while (_iterator__ex2g4s_0.j()) {
      var element_0 = _iterator__ex2g4s_0.k();
      tasks.h(element_0.g1p_1);
    }
    return tasks;
  };
  protoOf(AnimatorImpl).v1p = function () {
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = toList(_get_jobs__d8todx(this)).i();
    while (_iterator__ex2g4s.j()) {
      var element = _iterator__ex2g4s.k();
      element.g1p_1.v1o();
    }
  };
  function CompositeSequence(sequences) {
    this.k1q_1 = toList_0(sequences);
    this.l1q_1 = 0;
  }
  protoOf(CompositeSequence).o = function () {
    // Inline function 'kotlin.collections.sumOf' call
    var sum = 0;
    var _iterator__ex2g4s = this.k1q_1.i();
    while (_iterator__ex2g4s.j()) {
      var element = _iterator__ex2g4s.k();
      var tmp = sum;
      sum = tmp + element.o();
    }
    return sum;
  };
  protoOf(CompositeSequence).d1p = function (distance) {
    var next = this.k1q_1.l(this.l1q_1).d1p(distance);
    if (!(next == null)) {
      return next;
    }
    if (this.l1q_1 < (this.k1q_1.o() - 1 | 0)) {
      this.l1q_1 = this.l1q_1 + 1 | 0;
      return this.k1q_1.l(this.l1q_1).d1p(distance);
    }
    return null;
  };
  function calculateNext($this, distance) {
    // Inline function 'kotlin.require' call
    if (!(distance >= 0)) {
      var message = 'distance must not be negative';
      throw IllegalArgumentException_init_$Create$(toString(message));
    }
    if ($this.p1q_1) {
      $this.o1q_1 = null;
      return Unit_instance;
    }
    if ($this.q1q_1 <= 1.0E-7) {
      $this.o1q_1 = null;
      return Unit_instance;
    }
    if ($this.n1q_1 >= $this.m1q_1) {
      $this.o1q_1 = ensureNotNull($this.o1q_1) + distance;
      if (ensureNotNull($this.o1q_1) >= $this.n1q_1) {
        $this.p1q_1 = true;
        $this.o1q_1 = $this.n1q_1;
      }
    } else {
      $this.o1q_1 = ensureNotNull($this.o1q_1) - distance;
      if (ensureNotNull($this.o1q_1) <= $this.n1q_1) {
        $this.p1q_1 = true;
        $this.o1q_1 = $this.n1q_1;
      }
    }
  }
  function DoubleRange(begin, end) {
    this.m1q_1 = begin;
    this.n1q_1 = end;
    this.o1q_1 = this.m1q_1;
    this.p1q_1 = false;
    var tmp = this;
    // Inline function 'kotlin.math.abs' call
    var x = this.m1q_1 - this.n1q_1;
    tmp.q1q_1 = Math.abs(x);
  }
  protoOf(DoubleRange).o = function () {
    return this.q1q_1;
  };
  protoOf(DoubleRange).d1p = function (distance) {
    if (this.o1q_1 == null) {
      return null;
    }
    var result = this.o1q_1;
    calculateNext(this, distance);
    return ensureNotNull(result);
  };
  protoOf(DoubleRange).r1q = function (reversed) {
    var tmp;
    if (reversed) {
      tmp = new DoubleRange(this.n1q_1, this.m1q_1);
    } else {
      tmp = new DoubleRange(this.m1q_1, this.n1q_1);
    }
    return tmp;
  };
  function Oscillation(sequence) {
    this.s1q_1 = sequence;
    this.t1q_1 = sequence.o();
  }
  protoOf(Oscillation).o = function () {
    return this.t1q_1;
  };
  protoOf(Oscillation).d1p = function (distance) {
    var next = this.s1q_1.d1p(distance);
    if (!(next == null)) {
      return next;
    }
    this.s1q_1 = this.s1q_1.r1q(true);
    return this.s1q_1.d1p(distance);
  };
  function hasNext($this) {
    return !($this.y1q_1 == null) && !($this.z1q_1 == null);
  }
  function getNextXY($this, distance) {
    calculateNextXY($this, distance);
    $this.y1q_1 = $this.a1r_1;
    $this.z1q_1 = $this.b1r_1;
  }
  function calculateNextXY($this, distance) {
    var tmp;
    if (distance <= 0.0) {
      tmp = 1.0E-7;
    } else {
      tmp = distance;
    }
    var effDist = tmp;
    if ($this.o() <= 1.0E-7) {
      $this.a1r_1 = null;
      $this.b1r_1 = null;
      return Unit_instance;
    }
    var dx = ($this.v1q_1.in_1 - $this.u1q_1.in_1) / $this.o() * effDist;
    var dy = ($this.v1q_1.jn_1 - $this.u1q_1.jn_1) / $this.o() * effDist;
    $this.a1r_1 = ensureNotNull($this.y1q_1) + dx;
    $this.b1r_1 = ensureNotNull($this.z1q_1) + dy;
    var d = $this.u1q_1.o1g(ensureNotNull($this.a1r_1), ensureNotNull($this.b1r_1));
    if (d >= $this.o()) {
      $this.c1r_1 = d - $this.o();
      if (d === $this.o() || $this.w1q_1) {
        $this.a1r_1 = $this.v1q_1.in_1;
        $this.b1r_1 = $this.v1q_1.jn_1;
      } else {
        resetNext($this);
        return Unit_instance;
      }
    }
    if ($this.a1r_1 === ensureNotNull($this.y1q_1) && $this.b1r_1 === ensureNotNull($this.z1q_1)) {
      resetNext($this);
    }
  }
  function resetNext($this) {
    $this.a1r_1 = null;
    $this.b1r_1 = null;
  }
  function PointRange(begin, end, returnEndPoint, initialOffset) {
    returnEndPoint = returnEndPoint === VOID ? true : returnEndPoint;
    initialOffset = initialOffset === VOID ? null : initialOffset;
    this.u1q_1 = begin;
    this.v1q_1 = end;
    this.w1q_1 = returnEndPoint;
    this.x1q_1 = this.u1q_1.p1g(this.v1q_1);
    this.y1q_1 = this.u1q_1.in_1;
    this.z1q_1 = this.u1q_1.jn_1;
    this.a1r_1 = null;
    this.b1r_1 = null;
    this.c1r_1 = 0.0;
    if (!(initialOffset == null) && initialOffset > 1.0E-7) {
      calculateNextXY(this, initialOffset);
      this.y1q_1 = this.a1r_1;
      this.z1q_1 = this.b1r_1;
    }
  }
  protoOf(PointRange).o = function () {
    return this.x1q_1;
  };
  protoOf(PointRange).d1p = function (distance) {
    var oldValueX = this.y1q_1;
    var oldValueY = this.z1q_1;
    if (!hasNext(this)) {
      return null;
    }
    getNextXY(this, distance);
    return new Point2D(ensureNotNull(oldValueX), ensureNotNull(oldValueY));
  };
  //region block: post-declaration
  protoOf(AnimationTaskAdapter).b1p = ended$default;
  protoOf(AnimatorImpl).u1p = schedule$default;
  //endregion
  //region block: exports
  _.$_$ = _.$_$ || {};
  _.$_$.a = AnimationModule_getInstance;
  _.$_$.b = AbstractAnimationTask;
  _.$_$.c = AnimationTaskAdapter;
  _.$_$.d = AnimatorImpl;
  _.$_$.e = CompositeSequence;
  _.$_$.f = DoubleRange;
  _.$_$.g = Oscillation;
  _.$_$.h = PointRange;
  //endregion
  return _;
}));

//# sourceMappingURL=jabbah-animation.js.map
