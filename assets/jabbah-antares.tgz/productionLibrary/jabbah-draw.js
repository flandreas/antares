(function (factory) {
  if (typeof define === 'function' && define.amd)
    define(['exports', './kotlin-kotlin-stdlib.js', './jabbah-base.js', './jabbah-animation.js'], factory);
  else if (typeof exports === 'object')
    factory(module.exports, require('./kotlin-kotlin-stdlib.js'), require('./jabbah-base.js'), require('./jabbah-animation.js'));
  else {
    if (typeof globalThis['kotlin-kotlin-stdlib'] === 'undefined') {
      throw new Error("Error loading module 'jabbah-draw'. Its dependency 'kotlin-kotlin-stdlib' was not found. Please, check whether 'kotlin-kotlin-stdlib' is loaded prior to 'jabbah-draw'.");
    }
    if (typeof globalThis['jabbah-base'] === 'undefined') {
      throw new Error("Error loading module 'jabbah-draw'. Its dependency 'jabbah-base' was not found. Please, check whether 'jabbah-base' is loaded prior to 'jabbah-draw'.");
    }
    if (typeof globalThis['jabbah-animation'] === 'undefined') {
      throw new Error("Error loading module 'jabbah-draw'. Its dependency 'jabbah-animation' was not found. Please, check whether 'jabbah-animation' is loaded prior to 'jabbah-draw'.");
    }
    globalThis['jabbah-draw'] = factory(typeof globalThis['jabbah-draw'] === 'undefined' ? {} : globalThis['jabbah-draw'], globalThis['kotlin-kotlin-stdlib'], globalThis['jabbah-base'], globalThis['jabbah-animation']);
  }
}(function (_, kotlin_kotlin, kotlin_jabbah_base, kotlin_jabbah_animation) {
  'use strict';
  //region block: imports
  var imul = Math.imul;
  var Unit_instance = kotlin_kotlin.$_$.i;
  var protoOf = kotlin_kotlin.$_$.t7;
  var initMetadataForClass = kotlin_kotlin.$_$.d7;
  var StringBuilder_init_$Create$ = kotlin_kotlin.$_$.v;
  var initMetadataForCompanion = kotlin_kotlin.$_$.e7;
  var toString = kotlin_kotlin.$_$.v7;
  var IllegalArgumentException_init_$Create$ = kotlin_kotlin.$_$.b1;
  var equals = kotlin_kotlin.$_$.u6;
  var noWhenBranchMatchedException = kotlin_kotlin.$_$.rb;
  var toFloatArray = kotlin_kotlin.$_$.q4;
  var toTypedArray = kotlin_kotlin.$_$.x4;
  var Rectangle2D = kotlin_jabbah_base.$_$.f6;
  var VOID = kotlin_kotlin.$_$.b;
  var AffineTransformImpl = kotlin_jabbah_base.$_$.y5;
  var Companion_getInstance = kotlin_jabbah_base.$_$.h;
  var THROW_CCE = kotlin_kotlin.$_$.fb;
  var AffineTransformImpl_init_$Create$ = kotlin_jabbah_base.$_$.n3;
  var Path2DJs = kotlin_jabbah_base.$_$.d6;
  var Rectangle2D_init_$Create$ = kotlin_jabbah_base.$_$.t3;
  var getKClassFromExpression = kotlin_kotlin.$_$.r8;
  var initMetadataForObject = kotlin_kotlin.$_$.i7;
  var MouseEventType_CLICKED_getInstance = kotlin_jabbah_base.$_$.k2;
  var MouseEventType_PRESSED_getInstance = kotlin_jabbah_base.$_$.p2;
  var MouseEventType_RELEASED_getInstance = kotlin_jabbah_base.$_$.q2;
  var MouseEventType_ENTERED_getInstance = kotlin_jabbah_base.$_$.m2;
  var MouseEventType_EXITED_getInstance = kotlin_jabbah_base.$_$.n2;
  var MouseEventType_MOVED_getInstance = kotlin_jabbah_base.$_$.o2;
  var MouseEventType_DRAGGED_getInstance = kotlin_jabbah_base.$_$.l2;
  var MouseEventType_WHEEL_ROTATED_getInstance = kotlin_jabbah_base.$_$.s2;
  var MouseEventType_UNKNOWN_getInstance = kotlin_jabbah_base.$_$.r2;
  var Button_BUTTON1_getInstance = kotlin_jabbah_base.$_$.z1;
  var Button_BUTTON2_getInstance = kotlin_jabbah_base.$_$.a2;
  var Button_BUTTON3_getInstance = kotlin_jabbah_base.$_$.b2;
  var Button_NONE_getInstance = kotlin_jabbah_base.$_$.c2;
  var Modifier_Shift_getInstance = kotlin_jabbah_base.$_$.j2;
  var Modifier_Ctrl_getInstance = kotlin_jabbah_base.$_$.h2;
  var Modifier_Meta_getInstance = kotlin_jabbah_base.$_$.i2;
  var Modifier_Alt_getInstance = kotlin_jabbah_base.$_$.g2;
  var numberToInt = kotlin_kotlin.$_$.r7;
  var Point2D_init_$Create$ = kotlin_jabbah_base.$_$.r3;
  var get_isAltDown = kotlin_jabbah_base.$_$.h5;
  var get_isControlDown = kotlin_jabbah_base.$_$.j5;
  var get_isShiftDown = kotlin_jabbah_base.$_$.m5;
  var get_isCtrlDown = kotlin_jabbah_base.$_$.k5;
  var get_isAltGraphDown = kotlin_jabbah_base.$_$.i5;
  var get_isMetaDown = kotlin_jabbah_base.$_$.l5;
  var hasModifier = kotlin_jabbah_base.$_$.g5;
  var defineProp = kotlin_kotlin.$_$.t6;
  var MouseEvent_0 = kotlin_jabbah_base.$_$.s5;
  var KeyEventType_PRESSED_getInstance = kotlin_jabbah_base.$_$.d2;
  var KeyEventType_RELEASED_getInstance = kotlin_jabbah_base.$_$.e2;
  var KeyEventType_TYPED_getInstance = kotlin_jabbah_base.$_$.f2;
  var numberToChar = kotlin_kotlin.$_$.q7;
  var InputEvent = kotlin_jabbah_base.$_$.n5;
  var Companion_instance = kotlin_jabbah_base.$_$.e;
  var to = kotlin_kotlin.$_$.vb;
  var mapOf = kotlin_kotlin.$_$.v3;
  var KProperty1 = kotlin_kotlin.$_$.v8;
  var getPropertyCallableRef = kotlin_kotlin.$_$.a7;
  var getKClass = kotlin_kotlin.$_$.s8;
  var logger = kotlin_jabbah_base.$_$.q7;
  var throwUninitializedPropertyAccessException = kotlin_kotlin.$_$.t5;
  var ArrayList_init_$Create$ = kotlin_kotlin.$_$.n;
  var PropertyOwnerImpl = kotlin_jabbah_base.$_$.v5;
  var ensureNotNull = kotlin_kotlin.$_$.mb;
  var lazy = kotlin_kotlin.$_$.qb;
  var Throttle = kotlin_jabbah_base.$_$.b7;
  var Dimension2D_init_$Create$ = kotlin_jabbah_base.$_$.o3;
  var UnsupportedOperationException_init_$Create$ = kotlin_kotlin.$_$.m1;
  var AbstractModule = kotlin_jabbah_base.$_$.d7;
  var BaseModuleJs_getInstance = kotlin_jabbah_base.$_$.m;
  var BaseModule_getInstance = kotlin_jabbah_base.$_$.n;
  var hashCode = kotlin_kotlin.$_$.c7;
  var PropertiesProxy = kotlin_jabbah_base.$_$.l7;
  var Disposable = kotlin_jabbah_base.$_$.f7;
  var initMetadataForInterface = kotlin_kotlin.$_$.g7;
  var contains = kotlin_kotlin.$_$.t2;
  var Collection = kotlin_kotlin.$_$.g2;
  var isInterface = kotlin_kotlin.$_$.m7;
  var toImmutableList = kotlin_jabbah_base.$_$.f4;
  var objectCreate = kotlin_kotlin.$_$.s7;
  var Point2D = kotlin_jabbah_base.$_$.e6;
  var UnhandledEventBehaviour_Strict_getInstance = kotlin_jabbah_base.$_$.c3;
  var System_getInstance = kotlin_jabbah_base.$_$.c1;
  var RectangularShape = kotlin_jabbah_base.$_$.g6;
  var FunctionAdapter = kotlin_kotlin.$_$.k6;
  var PropertyChangeListener = kotlin_jabbah_base.$_$.t5;
  var getNumberHashCode = kotlin_kotlin.$_$.y6;
  var Enum = kotlin_kotlin.$_$.xa;
  var Rotation_R0_getInstance = kotlin_jabbah_base.$_$.x2;
  var MutableCollection = kotlin_kotlin.$_$.j2;
  var asReversed = kotlin_kotlin.$_$.o2;
  var getBooleanHashCode = kotlin_kotlin.$_$.x6;
  var coerceAtLeast = kotlin_kotlin.$_$.e8;
  var coerceAtMost = kotlin_kotlin.$_$.g8;
  var Rectangle2D_init_$Create$_0 = kotlin_jabbah_base.$_$.s3;
  var RoundRectangle2D_init_$Create$ = kotlin_jabbah_base.$_$.v3;
  var Translations_getInstance = kotlin_jabbah_base.$_$.d1;
  var Companion_instance_0 = kotlin_jabbah_base.$_$.i;
  var Tooltip = kotlin_jabbah_base.$_$.n7;
  var AbstractAnimationTask = kotlin_jabbah_animation.$_$.b;
  var Companion_getInstance_0 = kotlin_jabbah_base.$_$.f;
  var Companion_instance_1 = kotlin_jabbah_base.$_$.p;
  var addAll = kotlin_kotlin.$_$.n2;
  var _Char___init__impl__6a9atx = kotlin_kotlin.$_$.n1;
  var charArrayOf = kotlin_kotlin.$_$.o6;
  var split = kotlin_kotlin.$_$.y9;
  var checkIndexOverflow = kotlin_kotlin.$_$.r2;
  var RichTextParser_init_$Create$ = kotlin_jabbah_base.$_$.x3;
  var SyntaxError = kotlin_jabbah_base.$_$.z4;
  var PointRange = kotlin_jabbah_animation.$_$.h;
  var copyToArray = kotlin_kotlin.$_$.a3;
  var CompositeSequence = kotlin_jabbah_animation.$_$.e;
  var DoubleRange = kotlin_jabbah_animation.$_$.f;
  var Oscillation = kotlin_jabbah_animation.$_$.g;
  var AnimationModule_getInstance = kotlin_jabbah_animation.$_$.a;
  var AnimationTaskAdapter = kotlin_jabbah_animation.$_$.c;
  var Ring2D = kotlin_jabbah_base.$_$.h6;
  var Ellipse2D = kotlin_jabbah_base.$_$.b6;
  var RoundRectangle2D = kotlin_jabbah_base.$_$.i6;
  var round = kotlin_kotlin.$_$.z7;
  var numberRangeToNumber = kotlin_kotlin.$_$.o7;
  var coerceIn = kotlin_kotlin.$_$.i8;
  var roundToInt = kotlin_kotlin.$_$.y7;
  var rangeTo = kotlin_kotlin.$_$.m8;
  var coerceIn_0 = kotlin_kotlin.$_$.j8;
  var until = kotlin_kotlin.$_$.q8;
  var collectionSizeOrDefault = kotlin_kotlin.$_$.s2;
  var ArrayList_init_$Create$_0 = kotlin_kotlin.$_$.m;
  var toList = kotlin_kotlin.$_$.s4;
  var Geometry_instance = kotlin_jabbah_base.$_$.g;
  var enumEntries = kotlin_kotlin.$_$.s5;
  var NoSuchElementException_init_$Create$ = kotlin_kotlin.$_$.h1;
  var LinkedHashMap_init_$Create$ = kotlin_kotlin.$_$.q;
  var indexOf = kotlin_kotlin.$_$.k3;
  var get_indices = kotlin_kotlin.$_$.m3;
  var compareTo = kotlin_kotlin.$_$.s6;
  var Comparable = kotlin_kotlin.$_$.va;
  var minOrNull = kotlin_kotlin.$_$.x3;
  var IllegalStateException_init_$Create$ = kotlin_kotlin.$_$.d1;
  var contentEquals = kotlin_kotlin.$_$.x2;
  var contentHashCode = kotlin_kotlin.$_$.z2;
  var UnsupportedOperationException_init_$Create$_0 = kotlin_kotlin.$_$.l1;
  var checkCountOverflow = kotlin_kotlin.$_$.q2;
  var rangeTo_0 = kotlin_kotlin.$_$.n8;
  var Shape = kotlin_jabbah_base.$_$.m6;
  var last = kotlin_kotlin.$_$.r3;
  var Point2D_init_$Create$_0 = kotlin_jabbah_base.$_$.q3;
  var contains_0 = kotlin_jabbah_base.$_$.j6;
  var contains_1 = kotlin_jabbah_base.$_$.k6;
  var intersects = kotlin_jabbah_base.$_$.l6;
  var listOf = kotlin_kotlin.$_$.t3;
  var resettableLazy = kotlin_jabbah_base.$_$.r7;
  var mutableListOf = kotlin_kotlin.$_$.y3;
  var addAll_0 = kotlin_kotlin.$_$.m2;
  var first = kotlin_kotlin.$_$.h3;
  var AbstractAction = kotlin_jabbah_base.$_$.c7;
  var AbstractAction_init_$Init$ = kotlin_jabbah_base.$_$.y3;
  var Vector2D = kotlin_jabbah_base.$_$.n6;
  var MouseAdapter = kotlin_jabbah_base.$_$.q5;
  var MouseEventImpl = kotlin_jabbah_base.$_$.r5;
  var toString_0 = kotlin_kotlin.$_$.tb;
  var KeyAdapter = kotlin_jabbah_base.$_$.o5;
  var subtract = kotlin_kotlin.$_$.i6;
  var PreferencesChangedEvent = kotlin_jabbah_base.$_$.k7;
  var StringUtils_getInstance = kotlin_jabbah_base.$_$.b1;
  var startsWith = kotlin_kotlin.$_$.ba;
  var Companion_instance_2 = kotlin_jabbah_base.$_$.q;
  var endsWith = kotlin_kotlin.$_$.h9;
  var charSequenceLength = kotlin_kotlin.$_$.r6;
  var PropertyChangeSupport = kotlin_jabbah_base.$_$.u5;
  var KProperty0 = kotlin_kotlin.$_$.u8;
  var maxOrNull = kotlin_kotlin.$_$.w3;
  var Rectangle2D_init_$Create$_1 = kotlin_jabbah_base.$_$.u3;
  var near = kotlin_jabbah_base.$_$.s6;
  //endregion
  //region block: pre-declaration
  initMetadataForClass(EmbeddedImageJs, 'EmbeddedImageJs');
  initMetadataForCompanion(Companion);
  function translate(p) {
    return this.l1d(p.kn_1, p.ln_1);
  }
  function drawLine(p1, p2) {
    return this.t1u(p1.kn_1, p1.ln_1, p2.kn_1, p2.ln_1);
  }
  function drawCircle(x, y, r) {
    this.c1v(x - r, y - r, 2 * r, 2 * r);
  }
  function fillCircle(x, y, r) {
    this.f1v(x - r, y - r, 2 * r, 2 * r);
  }
  initMetadataForInterface(Graphics2D, 'Graphics2D');
  initMetadataForClass(AbstractGraphics2D, 'AbstractGraphics2D', VOID, VOID, [Graphics2D]);
  initMetadataForClass(Graphics2DJs, 'Graphics2DJs', VOID, AbstractGraphics2D);
  initMetadataForObject(TextRenderInfoFactoryImpl, 'TextRenderInfoFactoryImpl');
  initMetadataForObject(PolylineShapeFactory, 'PolylineShapeFactory');
  initMetadataForClass(MouseEventBridge, 'MouseEventBridge');
  initMetadataForClass(MouseMotionEventBridge, 'MouseMotionEventBridge');
  initMetadataForClass(MouseWheelEventBridge, 'MouseWheelEventBridge');
  initMetadataForClass(KeyEventBridge, 'KeyEventBridge');
  initMetadataForClass(MouseEventJs, 'MouseEventJs', VOID, VOID, [MouseEvent_0]);
  initMetadataForClass(KeyEventJs, 'KeyEventJs', VOID, VOID, [InputEvent]);
  initMetadataForCompanion(Companion_0);
  initMetadataForClass(CanvasJs, 'CanvasJs');
  initMetadataForObject(DrawModuleJs, 'DrawModuleJs', VOID, AbstractModule);
  initMetadataForCompanion(Companion_1);
  initMetadataForClass(ApplicationContextHolder, 'ApplicationContextHolder', ApplicationContextHolder);
  initMetadataForClass(PopupMenuEvent, 'PopupMenuEvent');
  initMetadataForClass(DrawContext, 'DrawContext');
  initMetadataForClass(DrawProperties, 'DrawProperties', DrawProperties, PropertiesProxy);
  function contains_2(p) {
    return this.go(p.kn_1, p.ln_1);
  }
  function intersects_0(rect) {
    return this.fo().ro(rect);
  }
  initMetadataForInterface(Drawable, 'Drawable', VOID, VOID, [Disposable]);
  initMetadataForClass(DrawableExplanation, 'DrawableExplanation');
  initMetadataForClass(DrawableBag$backToFrontIterator$1);
  function contains_3(drawable) {
    return contains(this.u20(), drawable);
  }
  function contains_4(x, y) {
    if (this.t20()) {
      var location = this.y20(x, y).j1h(this.jw());
      var tmp0 = this.u20();
      var tmp$ret$0;
      $l$block_0: {
        // Inline function 'kotlin.collections.any' call
        var tmp;
        if (isInterface(tmp0, Collection)) {
          tmp = tmp0.m();
        } else {
          tmp = false;
        }
        if (tmp) {
          tmp$ret$0 = false;
          break $l$block_0;
        }
        var _iterator__ex2g4s = tmp0.i();
        while (_iterator__ex2g4s.j()) {
          var element = _iterator__ex2g4s.k();
          if (element.d20() && element.po(location)) {
            tmp$ret$0 = true;
            break $l$block_0;
          }
        }
        tmp$ret$0 = false;
      }
      return tmp$ret$0;
    }
    var tmp0_0 = this.u20();
    var tmp$ret$2;
    $l$block_2: {
      // Inline function 'kotlin.collections.any' call
      var tmp_0;
      if (isInterface(tmp0_0, Collection)) {
        tmp_0 = tmp0_0.m();
      } else {
        tmp_0 = false;
      }
      if (tmp_0) {
        tmp$ret$2 = false;
        break $l$block_2;
      }
      var _iterator__ex2g4s_0 = tmp0_0.i();
      while (_iterator__ex2g4s_0.j()) {
        var element_0 = _iterator__ex2g4s_0.k();
        if (element_0.d20() && element_0.po(this.y20(x, y))) {
          tmp$ret$2 = true;
          break $l$block_2;
        }
      }
      tmp$ret$2 = false;
    }
    return tmp$ret$2;
  }
  function add$default(drawable, index, $super) {
    index = index === VOID ? 0 : index;
    return $super === VOID ? this.a21(drawable, index) : $super.a21.call(this, drawable, index);
  }
  function frontToBackIterator() {
    return this.u20().i();
  }
  function backToFrontIterator() {
    var iter = this.u20().v1(this.u20().o());
    return new DrawableBag$backToFrontIterator$1(iter);
  }
  function getDrawableAt(x, y, predicate) {
    if (this.t20()) {
      var p = this.y20(x, y).j1h(this.jw());
      var tmp0 = this.u20();
      var tmp$ret$0;
      $l$block: {
        // Inline function 'kotlin.collections.firstOrNull' call
        var _iterator__ex2g4s = tmp0.i();
        while (_iterator__ex2g4s.j()) {
          var element = _iterator__ex2g4s.k();
          if (element.d20() && predicate(element) && element.po(p)) {
            tmp$ret$0 = element;
            break $l$block;
          }
        }
        tmp$ret$0 = null;
      }
      return tmp$ret$0;
    }
    var p_0 = this.y20(x, y);
    var tmp0_0 = this.u20();
    var tmp$ret$2;
    $l$block_0: {
      // Inline function 'kotlin.collections.firstOrNull' call
      var _iterator__ex2g4s_0 = tmp0_0.i();
      while (_iterator__ex2g4s_0.j()) {
        var element_0 = _iterator__ex2g4s_0.k();
        if (element_0.d20() && predicate(element_0) && element_0.po(p_0)) {
          tmp$ret$2 = element_0;
          break $l$block_0;
        }
      }
      tmp$ret$2 = null;
    }
    return tmp$ret$2;
  }
  function getDrawableAt_0(rect, predicate) {
    if (this.t20()) {
      var r = this.h21(rect).l1c(this.jw().c1h());
      var tmp0 = this.u20();
      var tmp$ret$0;
      $l$block: {
        // Inline function 'kotlin.collections.firstOrNull' call
        var _iterator__ex2g4s = tmp0.i();
        while (_iterator__ex2g4s.j()) {
          var element = _iterator__ex2g4s.k();
          if (element.d20() && predicate(element) && element.ro(r)) {
            tmp$ret$0 = element;
            break $l$block;
          }
        }
        tmp$ret$0 = null;
      }
      return tmp$ret$0;
    }
    var r_0 = this.h21(rect);
    var tmp0_0 = this.u20();
    var tmp$ret$2;
    $l$block_0: {
      // Inline function 'kotlin.collections.firstOrNull' call
      var _iterator__ex2g4s_0 = tmp0_0.i();
      while (_iterator__ex2g4s_0.j()) {
        var element_0 = _iterator__ex2g4s_0.k();
        if (element_0.d20() && predicate(element_0) && element_0.ro(r_0)) {
          tmp$ret$2 = element_0;
          break $l$block_0;
        }
      }
      tmp$ret$2 = null;
    }
    return tmp$ret$2;
  }
  function getDrawableAt_1(x, y) {
    return this.f21(x, y, DrawableBag$getDrawableAt$lambda);
  }
  function getDrawableAt_2(location) {
    return this.f21(location.kn_1, location.ln_1, DrawableBag$getDrawableAt$lambda_0);
  }
  function getDrawables(predicate) {
    // Inline function 'kotlin.collections.filter' call
    var tmp0 = this.u20();
    // Inline function 'kotlin.collections.filterTo' call
    var destination = ArrayList_init_$Create$();
    var _iterator__ex2g4s = tmp0.i();
    while (_iterator__ex2g4s.j()) {
      var element = _iterator__ex2g4s.k();
      if (predicate(element)) {
        destination.h(element);
      }
    }
    return toImmutableList(destination);
  }
  function getDrawableIntersection(drawable, predicate) {
    if (this.t20()) {
      var r = this.h21(drawable.fo()).l1c(this.jw().c1h());
      // Inline function 'kotlin.collections.filter' call
      var tmp0 = this.u20();
      // Inline function 'kotlin.collections.filterTo' call
      var destination = ArrayList_init_$Create$();
      var _iterator__ex2g4s = tmp0.i();
      while (_iterator__ex2g4s.j()) {
        var element = _iterator__ex2g4s.k();
        if (!(element === drawable) && element.d20() && predicate(element) && element.ro(r)) {
          destination.h(element);
        }
      }
      return destination;
    }
    var r_0 = this.h21(drawable.fo());
    // Inline function 'kotlin.collections.filter' call
    var tmp0_0 = this.u20();
    // Inline function 'kotlin.collections.filterTo' call
    var destination_0 = ArrayList_init_$Create$();
    var _iterator__ex2g4s_0 = tmp0_0.i();
    while (_iterator__ex2g4s_0.j()) {
      var element_0 = _iterator__ex2g4s_0.k();
      if (!(element_0 === drawable) && element_0.d20() && predicate(element_0) && element_0.ro(r_0)) {
        destination_0.h(element_0);
      }
    }
    return destination_0;
  }
  function getDrawableIntersection$default(drawable, predicate, $super) {
    var tmp;
    if (predicate === VOID) {
      tmp = DrawableBag$getDrawableIntersection$lambda;
    } else {
      tmp = predicate;
    }
    predicate = tmp;
    return $super === VOID ? this.l21(drawable, predicate) : getDrawableIntersection(drawable, predicate);
  }
  function getDrawable(predicate) {
    var tmp0 = this.u20();
    var tmp$ret$0;
    $l$block: {
      // Inline function 'kotlin.collections.firstOrNull' call
      var _iterator__ex2g4s = tmp0.i();
      while (_iterator__ex2g4s.j()) {
        var element = _iterator__ex2g4s.k();
        if (predicate(element)) {
          tmp$ret$0 = element;
          break $l$block;
        }
      }
      tmp$ret$0 = null;
    }
    return tmp$ret$0;
  }
  function rotateBack(x, y) {
    return this.w20().k1i().n1i(this.jw(), x, y);
  }
  function rotateBack_0(pos) {
    return this.y20(pos.kn_1, pos.ln_1);
  }
  function rotateBack_1(rect) {
    return this.w20().k1i().p1i(this.jw(), rect);
  }
  initMetadataForInterface(DrawableBag, 'DrawableBag');
  function moveBy(dx, dy) {
    this.v20(this.jw().vn(dx, dy));
  }
  initMetadataForInterface(Locatable, 'Locatable', VOID, VOID, [Drawable]);
  function contains_5(x, y) {
    return contains_4.call(this, x, y);
  }
  initMetadataForInterface(DrawableContainer, 'DrawableContainer', VOID, VOID, [Locatable, DrawableBag]);
  initMetadataForClass(DrawableContainerEvent, 'DrawableContainerEvent');
  initMetadataForInterface(DrawableContainerListener, 'DrawableContainerListener');
  initMetadataForClass(DrawableEvent, 'DrawableEvent');
  initMetadataForClass(DrawableAdapter, 'DrawableAdapter', DrawableAdapter);
  function get_isFocusOwner() {
    return FocusManager_instance.h22_1 === this;
  }
  function requestFocus() {
    return FocusManager_instance.j22(this);
  }
  function focusGained() {
  }
  function focusLost() {
  }
  initMetadataForInterface(Focusable, 'Focusable');
  initMetadataForObject(FocusManager, 'FocusManager');
  initMetadataForClass(InputEventContext, 'InputEventContext');
  initMetadataForCompanion(Companion_2);
  initMetadataForInterface(InputEventHandler, 'InputEventHandler');
  initMetadataForClass(InputEventHandlerAdapter, 'InputEventHandlerAdapter', InputEventHandlerAdapter, VOID, [InputEventHandler]);
  initMetadataForCompanion(Companion_3);
  initMetadataForClass(StateMachineInputEventHandler, 'StateMachineInputEventHandler', VOID, VOID, [InputEventHandler]);
  function get_devicePixelRatio() {
    return this.s23().r1x();
  }
  function get_center() {
    return new Point2D(this.f1c() / 2.0, this.h1c() / 2.0);
  }
  function get_zoomFactor() {
    return this.h24().k24_1;
  }
  initMetadataForInterface(View, 'View', VOID, VOID, [Disposable]);
  initMetadataForCompanion(Companion_4);
  initMetadataForClass(ViewTransformation, 'ViewTransformation');
  initMetadataForClass(CloseViewRequest, 'CloseViewRequest');
  initMetadataForCompanion(Companion_5);
  initMetadataForClass(ViewContentBounds, 'ViewContentBounds');
  initMetadataForCompanion(Companion_6);
  initMetadataForClass(sam$io_antarescircuit_jabbah_base_event_PropertyChangeListener$0, 'sam$io_antarescircuit_jabbah_base_event_PropertyChangeListener$0', VOID, VOID, [PropertyChangeListener, FunctionAdapter]);
  initMetadataForClass(ViewDecorator, 'ViewDecorator');
  function multiplyZoomFactor$default(factor, zoomLocation, $super) {
    zoomLocation = zoomLocation === VOID ? null : zoomLocation;
    var tmp;
    if ($super === VOID) {
      this.a27(factor, zoomLocation);
      tmp = Unit_instance;
    } else {
      tmp = $super.a27.call(this, factor, zoomLocation);
    }
    return tmp;
  }
  initMetadataForInterface(ViewNavigator, 'ViewNavigator');
  initMetadataForObject(IdentityViewToModelTransform, 'IdentityViewToModelTransform');
  initMetadataForCompanion(Companion_7);
  initMetadataForClass(ZoomPan, 'ZoomPan', ZoomPan_init_$Create$);
  initMetadataForCompanion(Companion_8);
  initMetadataForClass(ZoomStrategy, 'ZoomStrategy');
  initMetadataForClass(ZoomStrategyType, 'ZoomStrategyType', VOID, Enum);
  initMetadataForClass(ZoomStrategyType$NORMAL, 'NORMAL', VOID, ZoomStrategyType);
  initMetadataForClass(ZoomStrategyType$FIT, 'FIT', VOID, ZoomStrategyType);
  initMetadataForClass(ZoomStrategyType$FIT_MAX_NORMAL, 'FIT_MAX_NORMAL', VOID, ZoomStrategyType);
  initMetadataForClass(ZoomStrategyType$CENTER, 'CENTER', VOID, ZoomStrategyType);
  initMetadataForClass(ZoomStrategyType$VALUE, 'VALUE', VOID, ZoomStrategyType);
  initMetadataForClass(ZoomStrategyType$NONE, 'NONE', VOID, ZoomStrategyType);
  initMetadataForClass(DrawableBagImpl, 'DrawableBagImpl', DrawableBagImpl, VOID, [DrawableBag]);
  initMetadataForClass(DrawableBagInputEventHandler, 'DrawableBagInputEventHandler', DrawableBagInputEventHandler, InputEventHandlerAdapter);
  initMetadataForClass(DrawableContainerAdapter, 'DrawableContainerAdapter', DrawableContainerAdapter, VOID, [DrawableContainerListener]);
  initMetadataForInterface(DrawableDrawer, 'DrawableDrawer');
  initMetadataForClass(AbstractDrawableDrawer, 'AbstractDrawableDrawer', VOID, VOID, [DrawableDrawer]);
  initMetadataForClass(DrawableContainerDrawer, 'DrawableContainerDrawer', DrawableContainerDrawer, AbstractDrawableDrawer);
  initMetadataForClass(AbstractDrawable, 'AbstractDrawable', VOID, VOID, [Drawable]);
  initMetadataForClass(DrawableContainerImpl, 'DrawableContainerImpl', DrawableContainerImpl, AbstractDrawable, [DrawableContainer, Locatable]);
  initMetadataForClass(AbstractDrawableProperty, 'AbstractDrawableProperty');
  initMetadataForClass(DrawableProperty, 'DrawableProperty', VOID, AbstractDrawableProperty);
  initMetadataForClass(DrawableGeometryProperty, 'DrawableGeometryProperty', VOID, AbstractDrawableProperty);
  initMetadataForInterface(Unzoomable, 'Unzoomable', VOID, VOID, [Drawable]);
  initMetadataForClass(UnzoomableContainer, 'UnzoomableContainer', UnzoomableContainer, DrawableContainerImpl, [Unzoomable, DrawableContainer]);
  initMetadataForClass(DrawableOwner, 'DrawableOwner');
  function get_widthInt() {
    // Inline function 'kotlin.math.ceil' call
    var x = this.f1c();
    var tmp$ret$0 = Math.ceil(x);
    return numberToInt(tmp$ret$0);
  }
  function get_heightInt() {
    // Inline function 'kotlin.math.ceil' call
    var x = this.h1c();
    var tmp$ret$0 = Math.ceil(x);
    return numberToInt(tmp$ret$0);
  }
  function get_x() {
    return this.a2c().p1a();
  }
  function get_y() {
    return this.a2c().q1a();
  }
  function get_xInt() {
    return numberToInt(this.p1a());
  }
  function get_yInt() {
    return numberToInt(this.q1a());
  }
  function setBounds(x, y, w, h) {
    return this.z2b(x, y, w, h);
  }
  function setBounds_0(r) {
    return this.z2b(r.p1a(), r.q1a(), r.f1c(), r.h1c());
  }
  initMetadataForInterface(RectangularDrawable, 'RectangularDrawable', VOID, VOID, [Locatable]);
  initMetadataForClass(AbstractRectangle, 'AbstractRectangle', VOID, AbstractDrawable, [RectangularDrawable]);
  initMetadataForClass(AbstractRectangularUnzoomable, 'AbstractRectangularUnzoomable', VOID, AbstractDrawable, [Unzoomable]);
  initMetadataForInterface(Stylable, 'Stylable');
  initMetadataForClass(AbstractStyledDrawable, 'AbstractStyledDrawable', VOID, AbstractDrawable, [Stylable]);
  initMetadataForCompanion(Companion_9);
  initMetadataForClass(ArrowBubble, 'ArrowBubble', VOID, AbstractStyledDrawable);
  initMetadataForClass(ArrowBubblePosition, 'ArrowBubblePosition');
  initMetadataForClass(PositionInfo, 'PositionInfo');
  initMetadataForObject(ArrowBubblePositioner, 'ArrowBubblePositioner');
  initMetadataForInterface(Colorable, 'Colorable');
  initMetadataForClass(DefaultDrawableDrawer, 'DefaultDrawableDrawer', DefaultDrawableDrawer, AbstractDrawableDrawer);
  initMetadataForClass(VerticalPosition, 'VerticalPosition');
  initMetadataForObject(DrawableAttendantPositioner, 'DrawableAttendantPositioner');
  initMetadataForInterface(ButtonAction, 'ButtonAction');
  initMetadataForCompanion(Companion_10);
  initMetadataForClass(EditInteractionHandler, 'EditInteractionHandler', VOID, InputEventHandlerAdapter);
  initMetadataForClass(DrawableButton, 'DrawableButton', VOID, AbstractRectangle, [Stylable]);
  initMetadataForClass(AbstractDrawableButtonRenderer, 'AbstractDrawableButtonRenderer');
  initMetadataForClass(IconDrawableButtonRenderer, 'IconDrawableButtonRenderer', VOID, AbstractDrawableButtonRenderer);
  initMetadataForCompanion(Companion_11);
  function applyTo(color) {
    return Companion_instance_19.k2k(this.d2i(), color);
  }
  initMetadataForInterface(Transparent, 'Transparent', VOID, VOID, [Drawable]);
  initMetadataForClass(FlexibleTextView, 'FlexibleTextView', VOID, AbstractStyledDrawable, [Transparent, Unzoomable, Locatable]);
  function get_canMirror() {
    return true;
  }
  initMetadataForInterface(Mirrorable, 'Mirrorable', VOID, VOID, [Drawable]);
  initMetadataForCompanion(Companion_12);
  function prepareMoveBy(components) {
  }
  function completeMoveBy() {
  }
  initMetadataForInterface(Movable, 'Movable', VOID, VOID, [Locatable]);
  initMetadataForClass(MoveLocatableAnimation, 'MoveLocatableAnimation', VOID, AbstractAnimationTask);
  function set_orientation(value) {
    this.m28(value.n1f_1);
  }
  function get_orientation() {
    return Companion_getInstance_0().s1f(this.w20());
  }
  initMetadataForInterface(Orientable, 'Orientable', VOID, VOID, [Locatable]);
  initMetadataForCompanion(Companion_13);
  initMetadataForClass(ChunkView, 'ChunkView');
  initMetadataForClass(RichTextDrawable, 'RichTextDrawable', VOID, AbstractRectangle);
  initMetadataForCompanion(Companion_14);
  initMetadataForClass(ShakeLocatableAnimation, 'ShakeLocatableAnimation', VOID, AbstractAnimationTask);
  initMetadataForClass(GlowTask, 'GlowTask', GlowTask, AbstractAnimationTask);
  initMetadataForObject(SynchronizedGlowAnimation, 'SynchronizedGlowAnimation');
  initMetadataForClass(TransparentImpl, 'TransparentImpl', VOID, VOID, [Transparent, Drawable]);
  initMetadataForCompanion(Companion_15);
  initMetadataForClass(TransparentAnimation$Companion$fadeInOut$1, VOID, VOID, AnimationTaskAdapter);
  initMetadataForClass(TransparentAnimation$Companion$fadeInOut$4, VOID, VOID, AnimationTaskAdapter);
  initMetadataForCompanion(Companion_16);
  initMetadataForClass(TransparentAnimation, 'TransparentAnimation', VOID, AbstractAnimationTask);
  initMetadataForCompanion(Companion_17);
  initMetadataForCompanion(Companion_18);
  initMetadataForClass(Color, 'Color');
  initMetadataForCompanion(Companion_19);
  initMetadataForClass(ColorGradient, 'ColorGradient');
  initMetadataForClass(CompositeColorGradient, 'CompositeColorGradient');
  initMetadataForCompanion(Companion_20);
  initMetadataForClass(CompositeColor, 'CompositeColor', CompositeColor);
  initMetadataForClass(Cursor, 'Cursor', VOID, Enum);
  initMetadataForObject(DrawGraphicsModule, 'DrawGraphicsModule', VOID, AbstractModule);
  initMetadataForObject(DropShadow, 'DropShadow');
  initMetadataForClass(FontImpl, 'FontImpl', FontImpl);
  initMetadataForClass(FontStyle, 'FontStyle', VOID, Enum);
  initMetadataForCompanion(Companion_21);
  initMetadataForClass(LogicalFontFamily, 'LogicalFontFamily', VOID, Enum);
  function draw(context, location) {
    return this.q2f(context, location, context.q1z(Themes_getInstance().h2g().z2f_1.c1u()));
  }
  initMetadataForInterface(Icon, 'Icon');
  initMetadataForClass(KnobIcon, 'KnobIcon', VOID, VOID, [Icon]);
  initMetadataForClass(RemoveIcon, 'RemoveIcon', VOID, VOID, [Icon]);
  initMetadataForClass(AddIcon, 'AddIcon', VOID, VOID, [Icon]);
  initMetadataForClass(DeleteIcon, 'DeleteIcon', DeleteIcon, VOID, [Icon]);
  initMetadataForCompanion(Companion_22);
  initMetadataForClass(ImageType, 'ImageType', VOID, Enum);
  initMetadataForClass(LinearColorGradient, 'LinearColorGradient');
  initMetadataForClass(PredefinedColor, 'PredefinedColor');
  initMetadataForCompanion(Companion_23);
  initMetadataForClass(PredefinedColorIdentity, 'PredefinedColorIdentity', VOID, Enum);
  initMetadataForObject(PredefinedColorRepository, 'PredefinedColorRepository');
  initMetadataForClass(PredefinedStroke, 'PredefinedStroke');
  initMetadataForObject(PredefinedStrokeRepository, 'PredefinedStrokeRepository');
  initMetadataForCompanion(Companion_24);
  initMetadataForClass(PredefinedStrokeIdentity, 'PredefinedStrokeIdentity', VOID, Enum);
  initMetadataForClass(RadialColorGradient, 'RadialColorGradient');
  initMetadataForClass(RadialColorGradientCache, 'RadialColorGradientCache');
  initMetadataForObject(ReferenceColorSequenceProvider, 'ReferenceColorSequenceProvider');
  initMetadataForClass(ReferenceColor, 'ReferenceColor');
  initMetadataForClass(Usage, 'Usage', VOID, VOID, [Comparable]);
  initMetadataForClass(FlexibleReferenceColorSequenceImpl, 'FlexibleReferenceColorSequenceImpl', FlexibleReferenceColorSequenceImpl);
  initMetadataForClass(ReferenceColorReplacement, 'ReferenceColorReplacement');
  initMetadataForClass(ReferenceColorEvent, 'ReferenceColorEvent');
  initMetadataForClass(Stroke, 'Stroke', Stroke);
  initMetadataForClass(LineCap, 'LineCap', VOID, Enum);
  initMetadataForClass(LineJoin, 'LineJoin', VOID, Enum);
  initMetadataForObject(TextRenderInfoFactory, 'TextRenderInfoFactory');
  initMetadataForClass(TextRenderInfo, 'TextRenderInfo');
  initMetadataForClass(DrawModule$imageLoader$1);
  initMetadataForObject(DrawModule, 'DrawModule', VOID, AbstractModule);
  initMetadataForCompanion(Companion_25);
  initMetadataForClass(ArrowHead, 'ArrowHead', ArrowHead, AbstractDrawable, [Drawable]);
  function getFirstPoint() {
    return this.u2k(0);
  }
  function getLastPoint() {
    return this.u2k(this.t2k() - 1 | 0);
  }
  function findSegment$default(x, y, area, $super) {
    area = area === VOID ? 4 : area;
    return $super === VOID ? this.g2r(x, y, area) : $super.g2r.call(this, x, y, area);
  }
  function isSegmentOrthogonal(index) {
    return this.n2r(index) || this.o2r(index);
  }
  initMetadataForInterface(Polyline, 'Polyline');
  initMetadataForCompanion(Companion_26);
  initMetadataForClass(PolylineInterference, 'PolylineInterference');
  initMetadataForClass(PolylineDrawable, 'PolylineDrawable', PolylineDrawable, AbstractStyledDrawable, [Polyline, Locatable, Transparent]);
  initMetadataForCompanion(Companion_27);
  initMetadataForInterface(PolylineShape, 'PolylineShape', VOID, VOID, [Polyline, Shape]);
  initMetadataForCompanion(Companion_28);
  initMetadataForClass(PolylineShapeImpl, 'PolylineShapeImpl', PolylineShapeImpl, VOID, [PolylineShape]);
  initMetadataForObject(DrawStyleModule, 'DrawStyleModule', VOID, AbstractModule);
  initMetadataForCompanion(Companion_29);
  initMetadataForInterface(Theme, 'Theme');
  initMetadataForClass(DrawTheme, 'DrawTheme', DrawTheme, VOID, [Theme]);
  initMetadataForClass(StylableImpl, 'StylableImpl', VOID, VOID, [Stylable]);
  initMetadataForClass(BasicStyle, 'BasicStyle', BasicStyle);
  initMetadataForCompanion(Companion_30);
  initMetadataForClass(StyleRepository, 'StyleRepository', StyleRepository);
  initMetadataForCompanion(Companion_31);
  initMetadataForClass(StyleType, 'StyleType');
  initMetadataForObject(Themes, 'Themes');
  initMetadataForClass(ThemeEvent, 'ThemeEvent');
  initMetadataForClass(ViewPropertyListener, 'ViewPropertyListener', VOID, VOID, [PropertyChangeListener]);
  initMetadataForClass(AbstractContentViewAction, 'AbstractContentViewAction', VOID, AbstractAction);
  initMetadataForClass(AbstractViewAction, 'AbstractViewAction', VOID, AbstractContentViewAction);
  initMetadataForCompanion(Companion_32);
  initMetadataForClass(AutoPanning, 'AutoPanning', VOID, MouseAdapter);
  initMetadataForClass(ActiveContentViewChangedEvent, 'ActiveContentViewChangedEvent');
  initMetadataForClass(ContentViewManagerImpl, 'ContentViewManagerImpl', ContentViewManagerImpl_init_$Create$);
  initMetadataForObject(DrawViewModule, 'DrawViewModule', VOID, AbstractModule);
  initMetadataForCompanion(Companion_33);
  initMetadataForClass(sam$io_antarescircuit_jabbah_base_event_PropertyChangeListener$0_0, 'sam$io_antarescircuit_jabbah_base_event_PropertyChangeListener$0', VOID, VOID, [PropertyChangeListener, FunctionAdapter]);
  initMetadataForClass(sam$io_antarescircuit_jabbah_base_event_PropertyChangeListener$0_1, 'sam$io_antarescircuit_jabbah_base_event_PropertyChangeListener$0', VOID, VOID, [PropertyChangeListener, FunctionAdapter]);
  initMetadataForClass(InvalidatableViewPainter, 'InvalidatableViewPainter', VOID, VOID, [Disposable]);
  initMetadataForCompanion(Companion_34);
  initMetadataForClass(MouseWheelModeController, 'MouseWheelModeController', MouseWheelModeController, KeyAdapter);
  initMetadataForClass(PanMethod, 'PanMethod', VOID, Enum);
  initMetadataForClass(PanMethod$MiddleMouseButton, 'MiddleMouseButton', VOID, PanMethod);
  initMetadataForClass(PanMethod$AltLeftMouseButton, 'AltLeftMouseButton', VOID, PanMethod);
  initMetadataForClass(PanMethod$SpaceLeftMouseButton, 'SpaceLeftMouseButton', VOID, PanMethod);
  initMetadataForCompanion(Companion_35);
  initMetadataForObject(CurrentPanMethod, 'CurrentPanMethod');
  initMetadataForObject(TooltipManager, 'TooltipManager');
  initMetadataForClass(TooltipEvent, 'TooltipEvent');
  initMetadataForClass(TooltipView, 'TooltipView');
  initMetadataForClass(TooltipRequest, 'TooltipRequest');
  initMetadataForCompanion(Companion_36);
  initMetadataForClass(TooltipHandler, 'TooltipHandler');
  initMetadataForClass(ChildListener, 'ChildListener');
  initMetadataForClass(OverlayListener, 'OverlayListener');
  initMetadataForClass(PropertyChangeHandler, 'PropertyChangeHandler', VOID, VOID, [PropertyChangeListener]);
  initMetadataForClass(EventHandler, 'EventHandler', VOID, InputEventHandlerAdapter);
  initMetadataForClass(ViewImpl, 'ViewImpl', VOID, VOID, [View]);
  initMetadataForCompanion(Companion_37);
  initMetadataForClass(ViewNavigatorImpl, 'ViewNavigatorImpl', VOID, VOID, [ViewNavigator]);
  initMetadataForCompanion(Companion_38);
  initMetadataForClass(ViewSpace, 'ViewSpace');
  initMetadataForObject(ZoomPanActions, 'ZoomPanActions');
  initMetadataForClass(AbstractZoomPanAction, 'AbstractZoomPanAction', VOID, AbstractViewAction);
  initMetadataForClass(ZoomInAction, 'ZoomInAction', ZoomInAction, AbstractZoomPanAction);
  initMetadataForClass(ZoomNormalAction, 'ZoomNormalAction', ZoomNormalAction, AbstractZoomPanAction);
  initMetadataForClass(ZoomOutAction, 'ZoomOutAction', ZoomOutAction, AbstractZoomPanAction);
  initMetadataForClass(ZoomFitAction, 'ZoomFitAction', ZoomFitAction, AbstractZoomPanAction);
  initMetadataForClass(ZoomFitMaxNormalAction, 'ZoomFitMaxNormalAction', ZoomFitMaxNormalAction, AbstractZoomPanAction);
  initMetadataForClass(ZoomCenterAction, 'ZoomCenterAction', ZoomCenterAction, AbstractZoomPanAction);
  initMetadataForCompanion(Companion_39);
  initMetadataForCompanion(Companion_40);
  initMetadataForClass(MouseController, 'MouseController', VOID, MouseAdapter);
  initMetadataForClass(ZoomPanController, 'ZoomPanController');
  initMetadataForClass(ZoomedPointTranslation, 'ZoomedPointTranslation');
  initMetadataForClass(ZoomedPointVoyageAnimation, 'ZoomedPointVoyageAnimation', VOID, AbstractAnimationTask);
  initMetadataForClass(ZoomedPointVoyage, 'ZoomedPointVoyage');
  //endregion
  function EmbeddedImageJs(type, data) {
    this.t1r_1 = new Image();
    this.t1r_1.src = 'data:' + type.y1r_1 + ';base64,' + data;
  }
  protoOf(EmbeddedImageJs).f1c = function () {
    return this.t1r_1.width;
  };
  protoOf(EmbeddedImageJs).h1c = function () {
    return this.t1r_1.height;
  };
  function toJsFontStyle($this, font) {
    var sb = StringBuilder_init_$Create$();
    if (font.a1s()) {
      sb.i7('bold ');
    }
    if (font.b1s()) {
      sb.i7('italic ');
    }
    return sb.toString();
  }
  function toJsFontName($this, font) {
    var tmp0 = get_entries();
    var tmp$ret$0;
    $l$block: {
      // Inline function 'kotlin.collections.firstOrNull' call
      var _iterator__ex2g4s = tmp0.i();
      while (_iterator__ex2g4s.j()) {
        var element = _iterator__ex2g4s.k();
        if (element.k2_1 === font.c1s().d1s()) {
          tmp$ret$0 = element;
          break $l$block;
        }
      }
      tmp$ret$0 = null;
    }
    var tmp0_safe_receiver = tmp$ret$0;
    var tmp1_elvis_lhs = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.g1s_1;
    return tmp1_elvis_lhs == null ? LogicalFontFamily_SANS_SERIF_getInstance().h1s_1 : tmp1_elvis_lhs;
  }
  function Companion() {
  }
  protoOf(Companion).i1s = function (font) {
    return toJsFontStyle(this, font) + ' ' + font.o() + 'px ' + toJsFontName(this, font);
  };
  var Companion_instance_3;
  function Companion_getInstance_1() {
    return Companion_instance_3;
  }
  function playPolygon($this, x, y, n) {
    $this.k1s_1.moveTo(x[0], y[0]);
    var inductionVariable = 1;
    if (inductionVariable < n)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        $this.k1s_1.lineTo(x[i], y[i]);
      }
       while (inductionVariable < n);
    $this.k1s_1.closePath();
  }
  function toLinearJsGradient($this, gradient) {
    var jsGradient = $this.k1s_1.createLinearGradient(gradient.r1s_1.kn_1, gradient.r1s_1.ln_1, gradient.t1s_1.kn_1, gradient.t1s_1.ln_1);
    jsGradient.addColorStop(0.0, Companion_getInstance_19().w1s(gradient.s1s_1));
    jsGradient.addColorStop(1.0, Companion_getInstance_19().w1s(gradient.u1s_1));
    return jsGradient;
  }
  function toRadialJsGradient($this, gradient) {
    var jsGradient = $this.k1s_1.createRadialGradient(gradient.x1s_1.kn_1, gradient.x1s_1.ln_1, 0.0, gradient.x1s_1.kn_1, gradient.x1s_1.ln_1, gradient.y1s_1);
    jsGradient.addColorStop(0.0, Companion_getInstance_19().w1s(gradient.z1s_1));
    jsGradient.addColorStop(1.0, Companion_getInstance_19().w1s(gradient.a1t_1));
    return jsGradient;
  }
  function forwardTransform($this) {
    var matrix = $this.b1t().k1d();
    $this.k1s_1.setTransform(matrix[0], matrix[1], matrix[2], matrix[3], matrix[4], matrix[5]);
  }
  function toLineCap($this, cap) {
    var tmp;
    // Inline function 'org.w3c.dom.BUTT' call
    // Inline function 'kotlin.js.asDynamic' call
    // Inline function 'kotlin.js.unsafeCast' call
    if (equals(cap, 'butt')) {
      tmp = LineCap_BUTT_getInstance();
    } else {
      // Inline function 'org.w3c.dom.ROUND' call
      // Inline function 'kotlin.js.asDynamic' call
      // Inline function 'kotlin.js.unsafeCast' call
      if (equals(cap, 'round')) {
        tmp = LineCap_ROUND_getInstance();
      } else {
        // Inline function 'org.w3c.dom.SQUARE' call
        // Inline function 'kotlin.js.asDynamic' call
        // Inline function 'kotlin.js.unsafeCast' call
        if (equals(cap, 'square')) {
          tmp = LineCap_SQUARE_getInstance();
        } else {
          throw IllegalArgumentException_init_$Create$('unknown cap ' + toString(cap));
        }
      }
    }
    return tmp;
  }
  function fromLineCap($this, cap) {
    var tmp;
    switch (cap.l2_1) {
      case 0:
        // Inline function 'org.w3c.dom.BUTT' call

        // Inline function 'kotlin.js.asDynamic' call

        // Inline function 'kotlin.js.unsafeCast' call

        tmp = 'butt';
        break;
      case 1:
        // Inline function 'org.w3c.dom.ROUND' call

        // Inline function 'kotlin.js.asDynamic' call

        // Inline function 'kotlin.js.unsafeCast' call

        tmp = 'round';
        break;
      case 2:
        // Inline function 'org.w3c.dom.SQUARE' call

        // Inline function 'kotlin.js.asDynamic' call

        // Inline function 'kotlin.js.unsafeCast' call

        tmp = 'square';
        break;
      default:
        noWhenBranchMatchedException();
        break;
    }
    return tmp;
  }
  function toLineJoin($this, join) {
    var tmp;
    // Inline function 'org.w3c.dom.MITER' call
    // Inline function 'kotlin.js.asDynamic' call
    // Inline function 'kotlin.js.unsafeCast' call
    if (equals(join, 'miter')) {
      tmp = LineJoin_MITER_getInstance();
    } else {
      // Inline function 'org.w3c.dom.ROUND' call
      // Inline function 'kotlin.js.asDynamic' call
      // Inline function 'kotlin.js.unsafeCast' call
      if (equals(join, 'round')) {
        tmp = LineJoin_ROUND_getInstance();
      } else {
        // Inline function 'org.w3c.dom.BEVEL' call
        // Inline function 'kotlin.js.asDynamic' call
        // Inline function 'kotlin.js.unsafeCast' call
        if (equals(join, 'bevel')) {
          tmp = LineJoin_BEVEL_getInstance();
        } else {
          throw IllegalArgumentException_init_$Create$('unknown join ' + toString(join));
        }
      }
    }
    return tmp;
  }
  function fromLineJoin($this, join) {
    var tmp;
    switch (join.l2_1) {
      case 0:
        // Inline function 'org.w3c.dom.MITER' call

        // Inline function 'kotlin.js.asDynamic' call

        // Inline function 'kotlin.js.unsafeCast' call

        tmp = 'miter';
        break;
      case 1:
        // Inline function 'org.w3c.dom.ROUND' call

        // Inline function 'kotlin.js.asDynamic' call

        // Inline function 'kotlin.js.unsafeCast' call

        tmp = 'round';
        break;
      case 2:
        // Inline function 'org.w3c.dom.BEVEL' call

        // Inline function 'kotlin.js.asDynamic' call

        // Inline function 'kotlin.js.unsafeCast' call

        tmp = 'bevel';
        break;
      default:
        noWhenBranchMatchedException();
        break;
    }
    return tmp;
  }
  function toDash($this, dash) {
    var tmp = 0;
    var tmp_0 = dash.length;
    // Inline function 'kotlin.arrayOfNulls' call
    var tmp_1 = Array(tmp_0);
    while (tmp < tmp_0) {
      var tmp_2 = tmp;
      tmp_1[tmp_2] = dash[tmp_2];
      tmp = tmp + 1 | 0;
    }
    return toFloatArray(tmp_1);
  }
  function fromDash($this, dash) {
    if (dash == null) {
      // Inline function 'kotlin.doubleArrayOf' call
      var tmp$ret$0 = new Float64Array([]);
      return toTypedArray(tmp$ret$0);
    }
    var tmp = 0;
    var tmp_0 = dash.length;
    // Inline function 'kotlin.arrayOfNulls' call
    var tmp_1 = Array(tmp_0);
    while (tmp < tmp_0) {
      var tmp_2 = tmp;
      tmp_1[tmp_2] = dash[tmp_2];
      tmp = tmp + 1 | 0;
    }
    return tmp_1;
  }
  function drawPath($this, path) {
    $this.k1s_1.beginPath();
    path.no($this.k1s_1);
    $this.k1s_1.stroke();
    $this.k1s_1.closePath();
  }
  function fillPath($this, path) {
    $this.k1s_1.beginPath();
    path.no($this.k1s_1);
    $this.k1s_1.fill();
    $this.k1s_1.closePath();
  }
  function Graphics2DJs(ctx) {
    AbstractGraphics2D.call(this);
    this.k1s_1 = ctx;
    this.l1s_1 = new Rectangle2D();
    this.k1s_1.setTransform(1.0, 0.0, 0.0, 1.0, 0.0, 0.0);
    this.m1s_1 = true;
    this.n1s_1 = new AffineTransformImpl(1.0, VOID, VOID, 1.0);
    this.o1s_1 = new Color(0, 0, 0, 255);
    this.p1s_1 = new LinearColorGradient(Companion_getInstance().w1a_1, Companion_getInstance_20().d1t_1, Companion_getInstance().w1a_1, Companion_getInstance_20().d1t_1);
    this.q1s_1 = null;
  }
  protoOf(Graphics2DJs).n1t = function () {
    this.k1s_1.beginPath();
  };
  protoOf(Graphics2DJs).o1t = function (x, y) {
    this.k1s_1.moveTo(x, y);
  };
  protoOf(Graphics2DJs).p1t = function (x, y) {
    this.k1s_1.lineTo(x, y);
  };
  protoOf(Graphics2DJs).q1t = function (xc, yc, x1, y1) {
    this.k1s_1.quadraticCurveTo(xc, yc, x1, y1);
  };
  protoOf(Graphics2DJs).r1t = function (xc1, yc1, xc2, yc2, x1, y1) {
    this.k1s_1.bezierCurveTo(xc1, yc1, xc2, yc2, x1, y1);
  };
  protoOf(Graphics2DJs).s1t = function (x, y, radius, startAngle, endAngle, anticlockwise) {
    this.k1s_1.arc(x, y, radius, startAngle, endAngle, anticlockwise);
  };
  protoOf(Graphics2DJs).t1t = function () {
    this.k1s_1.stroke();
  };
  protoOf(Graphics2DJs).u1t = function () {
    this.k1s_1.fill();
  };
  protoOf(Graphics2DJs).v1t = function () {
    this.k1s_1.closePath();
  };
  protoOf(Graphics2DJs).w1t = function () {
    return false;
  };
  protoOf(Graphics2DJs).x1t = function (_set____db54di) {
    this.m1s_1 = _set____db54di;
  };
  protoOf(Graphics2DJs).y1t = function (x, y, w, h) {
  };
  protoOf(Graphics2DJs).z1t = function (r) {
  };
  protoOf(Graphics2DJs).a1u = function (value) {
    this.n1s_1 = value;
    forwardTransform(this);
  };
  protoOf(Graphics2DJs).b1t = function () {
    var tmp = this.n1s_1;
    return AffineTransformImpl_init_$Create$(tmp instanceof AffineTransformImpl ? tmp : THROW_CCE());
  };
  protoOf(Graphics2DJs).b1u = function (value) {
    this.o1s_1 = value;
    // Inline function 'kotlin.also' call
    var this_0 = Companion_getInstance_19().w1s(value);
    this.k1s_1.fillStyle = this_0;
    this.k1s_1.strokeStyle = this_0;
  };
  protoOf(Graphics2DJs).c1u = function () {
    return this.o1s_1;
  };
  protoOf(Graphics2DJs).d1u = function (value) {
    if (value instanceof Color) {
      this.b1u(value);
    } else {
      if (value instanceof LinearColorGradient) {
        this.p1s_1 = value;
        // Inline function 'kotlin.also' call
        var this_0 = toLinearJsGradient(this, value);
        this.k1s_1.fillStyle = this_0;
        this.k1s_1.strokeStyle = this_0;
      } else {
        if (value instanceof RadialColorGradient) {
          this.p1s_1 = value;
          // Inline function 'kotlin.also' call
          var this_1 = toRadialJsGradient(this, value);
          this.k1s_1.fillStyle = this_1;
          this.k1s_1.strokeStyle = this_1;
        } else {
          throw IllegalArgumentException_init_$Create$('unsupported Paint implementation');
        }
      }
    }
  };
  protoOf(Graphics2DJs).e1u = function (value) {
    this.k1s_1.lineWidth = value.f1u_1;
    this.k1s_1.lineCap = fromLineCap(this, value.g1u_1);
    this.k1s_1.lineJoin = fromLineJoin(this, value.h1u_1);
    this.k1s_1.miterLimit = value.i1u_1;
    this.k1s_1.setLineDash(fromDash(this, value.j1u_1));
    var tmp0_safe_receiver = value.k1u_1;
    var tmp1_elvis_lhs = tmp0_safe_receiver == null ? null : tmp0_safe_receiver;
    this.k1s_1.lineDashOffset = tmp1_elvis_lhs == null ? 0.0 : tmp1_elvis_lhs;
  };
  protoOf(Graphics2DJs).l1u = function () {
    return new Stroke(this.k1s_1.lineWidth, toLineCap(this, this.k1s_1.lineCap), toLineJoin(this, this.k1s_1.lineJoin), this.k1s_1.miterLimit, toDash(this, this.k1s_1.getLineDash()), this.k1s_1.lineDashOffset);
  };
  protoOf(Graphics2DJs).m1u = function (value) {
    this.q1s_1 = value;
    this.k1s_1.font = Companion_instance_3.i1s(value);
  };
  protoOf(Graphics2DJs).n1u = function () {
    return this.k1s_1.save();
  };
  protoOf(Graphics2DJs).o1u = function () {
    return this.k1s_1.restore();
  };
  protoOf(Graphics2DJs).n1d = function (sx, sy) {
    this.b1t().n1d(sx, sy);
    this.k1s_1.scale(sx, sy);
  };
  protoOf(Graphics2DJs).l1d = function (tx, ty) {
    this.b1t().l1d(tx, ty);
    this.k1s_1.translate(tx, ty);
  };
  protoOf(Graphics2DJs).o1d = function (theta) {
    this.r1u(this.q1u() + theta);
    this.b1t().o1d(theta);
    this.k1s_1.rotate(theta);
  };
  protoOf(Graphics2DJs).s1u = function (x1, y1, x2, y2) {
    this.n1t();
    this.o1t(x1, y1);
    this.p1t(x2, y2);
    this.t1t();
    this.v1t();
  };
  protoOf(Graphics2DJs).t1u = function (x1, y1, x2, y2) {
    this.n1t();
    this.o1t(x1, y1);
    this.p1t(x2, y2);
    this.t1t();
    this.v1t();
  };
  protoOf(Graphics2DJs).u1u = function (x, y, w, h) {
    this.k1s_1.strokeRect(x + 0.5, y + 0.5, w, h);
  };
  protoOf(Graphics2DJs).v1u = function (x, y, w, h) {
    this.k1s_1.strokeRect(x, y, w, h);
  };
  protoOf(Graphics2DJs).w1u = function (x, y, w, h, arcW, arcH) {
    this.x1u(x, y, w, h, arcW, arcH);
  };
  protoOf(Graphics2DJs).y1u = function (x, y, w, h) {
    this.k1s_1.fillRect(x + 0.5, y + 0.5, w, h);
  };
  protoOf(Graphics2DJs).z1u = function (x, y, w, h) {
    this.k1s_1.fillRect(x, y, w, h);
  };
  protoOf(Graphics2DJs).a1v = function (x, y, w, h, arcW, arcH) {
    this.b1v(x, y, w, h, arcW, arcH);
  };
  protoOf(Graphics2DJs).c1v = function (x, y, w, h) {
    this.k1s_1.beginPath();
    this.d1v(x, y, w, h);
    this.k1s_1.stroke();
    this.k1s_1.closePath();
  };
  protoOf(Graphics2DJs).e1v = function (x, y, w, h) {
    this.c1v(x, y, w, h);
  };
  protoOf(Graphics2DJs).f1v = function (x, y, w, h) {
    this.k1s_1.beginPath();
    this.d1v(x, y, w, h);
    this.k1s_1.fill();
    this.k1s_1.closePath();
  };
  protoOf(Graphics2DJs).g1v = function (x, y, w, h) {
    this.f1v(x, y, w, h);
  };
  protoOf(Graphics2DJs).h1v = function (x, y, n) {
    this.k1s_1.beginPath();
    playPolygon(this, x, y, n);
    this.k1s_1.fill();
  };
  protoOf(Graphics2DJs).i1v = function (x, y) {
    this.y1u(x, y, 1, 1);
  };
  protoOf(Graphics2DJs).j1v = function (shape) {
    if (shape instanceof Path2DJs) {
      drawPath(this, shape);
    } else {
      protoOf(AbstractGraphics2D).j1v.call(this, shape);
    }
  };
  protoOf(Graphics2DJs).k1v = function (shape) {
    if (shape instanceof Path2DJs) {
      fillPath(this, shape);
    } else {
      protoOf(AbstractGraphics2D).k1v.call(this, shape);
    }
  };
  protoOf(Graphics2DJs).l1v = function () {
    var tmp;
    if (this.w1t()) {
      tmp = Rectangle2D_init_$Create$(this.l1s_1);
    } else {
      tmp = null;
    }
    return tmp;
  };
  protoOf(Graphics2DJs).m1v = function (r) {
    r.i1c(this.l1s_1.u1h_1, this.l1s_1.v1h_1, this.l1s_1.w1h_1, this.l1s_1.x1h_1);
    return r;
  };
  protoOf(Graphics2DJs).n1v = function (s, x, y) {
    this.k1s_1.fillText(s, x, y);
  };
  protoOf(Graphics2DJs).o1v = function (image, x, y) {
    if (image instanceof EmbeddedImageJs) {
      this.k1s_1.drawImage(image.t1r_1, x, y);
    } else {
      throw IllegalArgumentException_init_$Create$('unsupported image type ' + getKClassFromExpression(image).m9());
    }
  };
  function TextRenderInfoFactoryImpl() {
    TextRenderInfoFactoryImpl_instance = this;
    var tmp = this;
    var tmp_0 = document.createElement('canvas');
    tmp.e1w_1 = tmp_0 instanceof HTMLCanvasElement ? tmp_0 : THROW_CCE();
  }
  protoOf(TextRenderInfoFactoryImpl).f1w = function (text, font) {
    var tmp = this.e1w_1.getContext('2d');
    var context = tmp instanceof CanvasRenderingContext2D ? tmp : THROW_CCE();
    context.font = Companion_instance_3.i1s(font);
    var metrics = context.measureText(text);
    var ascent = 7.0 / 8 * font.o();
    var descent = 1.0 / 8 * font.o();
    return new TextRenderInfo(new Rectangle2D(0.0, -ascent, metrics.width, ascent + descent), ascent);
  };
  var TextRenderInfoFactoryImpl_instance;
  function TextRenderInfoFactoryImpl_getInstance() {
    if (TextRenderInfoFactoryImpl_instance == null)
      new TextRenderInfoFactoryImpl();
    return TextRenderInfoFactoryImpl_instance;
  }
  function PolylineShapeFactory() {
  }
  protoOf(PolylineShapeFactory).g1w = function (points) {
    return new PolylineShapeImpl(points);
  };
  var PolylineShapeFactory_instance;
  function PolylineShapeFactory_getInstance() {
    return PolylineShapeFactory_instance;
  }
  function get_keyboardEventKeyMap() {
    _init_properties_CanvasEvents_kt__7kjjnz();
    return keyboardEventKeyMap;
  }
  var keyboardEventKeyMap;
  function MouseEventBridge(windowToCanvas, listener, canvas) {
    this.h1w_1 = windowToCanvas;
    this.i1w_1 = listener;
    this.j1w_1 = canvas;
  }
  protoOf(MouseEventBridge).k1w = function (event) {
    var e = new MouseEventJs(this.h1w_1(event instanceof MouseEvent ? event : THROW_CCE()), this.j1w_1, event);
    switch (event.type) {
      case 'mousedown':
        this.i1w_1.i1b(e);
        break;
      case 'mouseup':
        this.i1w_1.j1b(e);
        break;
      case 'click':
        this.i1w_1.h1b(e);
        break;
      case 'dblclick':
        this.i1w_1.h1b(e);
        break;
    }
  };
  protoOf(MouseEventBridge).handleEvent = function (event) {
    return this.k1w(event);
  };
  function MouseMotionEventBridge(windowToCanvas, listener, canvas) {
    this.l1w_1 = windowToCanvas;
    this.m1w_1 = listener;
    this.n1w_1 = canvas;
    this.o1w_1 = false;
  }
  protoOf(MouseMotionEventBridge).k1w = function (event) {
    var e = new MouseEventJs(this.l1w_1(event instanceof MouseEvent ? event : THROW_CCE()), this.n1w_1, event, this.o1w_1);
    switch (event.type) {
      case 'mousedown':
        this.o1w_1 = true;
        break;
      case 'mouseup':
        this.o1w_1 = false;
        break;
      case 'mousemove':
        if (this.o1w_1) {
          this.m1w_1.k1b(e);
        } else {
          this.m1w_1.l1b(e);
        }

        break;
    }
  };
  protoOf(MouseMotionEventBridge).handleEvent = function (event) {
    return this.k1w(event);
  };
  function MouseWheelEventBridge(windowToCanvas, listener, canvas) {
    this.p1w_1 = windowToCanvas;
    this.q1w_1 = listener;
    this.r1w_1 = canvas;
  }
  protoOf(MouseWheelEventBridge).k1w = function (event) {
    var w3cEvent = event instanceof WheelEvent ? event : THROW_CCE();
    var e = new MouseEventJs(this.p1w_1(w3cEvent), this.r1w_1, w3cEvent);
    this.q1w_1.m1b(e);
  };
  protoOf(MouseWheelEventBridge).handleEvent = function (event) {
    return this.k1w(event);
  };
  function KeyEventBridge(listener, canvas) {
    this.s1w_1 = listener;
    this.t1w_1 = canvas;
  }
  protoOf(KeyEventBridge).k1w = function (event) {
    var e = new KeyEventJs(this.t1w_1, event instanceof KeyboardEvent ? event : THROW_CCE());
    switch (e.k1a().l2_1) {
      case 0:
        this.s1w_1.m1a(e);
        break;
      case 1:
        this.s1w_1.n1a(e);
        break;
      case 2:
        this.s1w_1.o1a(e);
        break;
      default:
        break;
    }
  };
  protoOf(KeyEventBridge).handleEvent = function (event) {
    return this.k1w(event);
  };
  function convertEventType($this) {
    switch ($this.y1w_1.type) {
      case 'click':
        return MouseEventType_CLICKED_getInstance();
      case 'mousedown':
        return MouseEventType_PRESSED_getInstance();
      case 'mouseup':
        return MouseEventType_RELEASED_getInstance();
      case 'mouseenter':
        return MouseEventType_ENTERED_getInstance();
      case 'mouseleave':
        return MouseEventType_EXITED_getInstance();
      case 'mousemove':
        return $this.z1w_1 ? MouseEventType_DRAGGED_getInstance() : MouseEventType_MOVED_getInstance();
      case 'wheel':
        return MouseEventType_WHEEL_ROTATED_getInstance();
      default:
        return MouseEventType_UNKNOWN_getInstance();
    }
  }
  function convertButton($this) {
    switch ($this.y1w_1.button) {
      case 0:
        return Button_BUTTON1_getInstance();
      case 1:
        return Button_BUTTON2_getInstance();
      case 2:
        return Button_BUTTON3_getInstance();
      default:
        return Button_NONE_getInstance();
    }
  }
  function convertModifiers($this) {
    var modifiers = 0;
    if ($this.y1w_1.shiftKey) {
      modifiers = modifiers | Modifier_Shift_getInstance().mask;
    }
    if ($this.y1w_1.ctrlKey) {
      modifiers = modifiers | Modifier_Ctrl_getInstance().mask;
    }
    if ($this.y1w_1.metaKey) {
      modifiers = modifiers | Modifier_Meta_getInstance().mask;
    }
    if ($this.y1w_1.altKey) {
      modifiers = modifiers | Modifier_Alt_getInstance().mask;
    }
    return modifiers;
  }
  function MouseEventJs(location, canvas, event, pressed) {
    pressed = pressed === VOID ? false : pressed;
    this.w1w_1 = location;
    this.x1w_1 = canvas;
    this.y1w_1 = event;
    this.z1w_1 = pressed;
    this.a1x_1 = convertEventType(this);
  }
  protoOf(MouseEventJs).jw = function () {
    return this.w1w_1;
  };
  protoOf(MouseEventJs).o17 = function () {
    return this.y1w_1;
  };
  protoOf(MouseEventJs).k1a = function () {
    return this.a1x_1;
  };
  protoOf(MouseEventJs).p17 = function () {
    return this.x1w_1;
  };
  protoOf(MouseEventJs).r1a = function () {
    return convertButton(this);
  };
  protoOf(MouseEventJs).s1a = function () {
    return this.y1w_1.type === 'dblclick' ? 2 : 1;
  };
  protoOf(MouseEventJs).q17 = function () {
    return convertModifiers(this);
  };
  protoOf(MouseEventJs).t1a = function () {
    var tmp;
    var tmp_0 = this.y1w_1;
    if (tmp_0 instanceof WheelEvent) {
      tmp = Point2D_init_$Create$(-numberToInt(this.y1w_1.deltaX) | 0, -numberToInt(this.y1w_1.deltaY) | 0);
    } else {
      tmp = Companion_getInstance().w1a_1;
    }
    return tmp;
  };
  protoOf(MouseEventJs).p1a = function () {
    return this.w1w_1.s1c();
  };
  protoOf(MouseEventJs).q1a = function () {
    return this.w1w_1.t1c();
  };
  protoOf(MouseEventJs).consumeEvent = function () {
    this.y1w_1.preventDefault();
  };
  protoOf(MouseEventJs).isEventConsumed = function () {
    return this.y1w_1.defaultPrevented;
  };
  protoOf(MouseEventJs).u1a = function () {
    return this.r1a().equals(Button_BUTTON1_getInstance());
  };
  protoOf(MouseEventJs).v1a = function () {
    return this.r1a().equals(Button_BUTTON2_getInstance());
  };
  protoOf(MouseEventJs).toString = function () {
    return 'MouseEvent ' + this.a1x_1.toString();
  };
  function convertModifiers_0($this) {
    var modifiers = 0;
    if ($this.v1w_1.shiftKey) {
      modifiers = modifiers | Modifier_Shift_getInstance().mask;
    }
    if ($this.v1w_1.ctrlKey) {
      modifiers = modifiers | Modifier_Ctrl_getInstance().mask;
    }
    if ($this.v1w_1.metaKey) {
      modifiers = modifiers | Modifier_Meta_getInstance().mask;
    }
    if ($this.v1w_1.altKey) {
      modifiers = modifiers | Modifier_Alt_getInstance().mask;
    }
    return modifiers;
  }
  function convertEventType_0($this) {
    switch ($this.v1w_1.type) {
      case 'keydown':
        return KeyEventType_PRESSED_getInstance();
      case 'keyup':
        return KeyEventType_RELEASED_getInstance();
      default:
        return KeyEventType_TYPED_getInstance();
    }
  }
  function KeyEventJs(canvas, event) {
    this.u1w_1 = canvas;
    this.v1w_1 = event;
  }
  protoOf(KeyEventJs).o17 = function () {
    return this.v1w_1;
  };
  protoOf(KeyEventJs).k1a = function () {
    return convertEventType_0(this);
  };
  protoOf(KeyEventJs).i2 = function () {
    var tmp = get_keyboardEventKeyMap();
    // Inline function 'kotlin.text.lowercase' call
    // Inline function 'kotlin.js.asDynamic' call
    var tmp$ret$0 = this.v1w_1.key.toLowerCase();
    var tmp0_elvis_lhs = tmp.g2(tmp$ret$0);
    return tmp0_elvis_lhs == null ? 0 : tmp0_elvis_lhs;
  };
  protoOf(KeyEventJs).l1a = function () {
    return numberToChar(this.v1w_1.charCode);
  };
  protoOf(KeyEventJs).p17 = function () {
    return this.u1w_1;
  };
  protoOf(KeyEventJs).q17 = function () {
    return convertModifiers_0(this);
  };
  protoOf(KeyEventJs).consumeEvent = function () {
    this.v1w_1.preventDefault();
  };
  protoOf(KeyEventJs).isEventConsumed = function () {
    return this.v1w_1.defaultPrevented;
  };
  var properties_initialized_CanvasEvents_kt_uzzwmr;
  function _init_properties_CanvasEvents_kt__7kjjnz() {
    if (!properties_initialized_CanvasEvents_kt_uzzwmr) {
      properties_initialized_CanvasEvents_kt_uzzwmr = true;
      keyboardEventKeyMap = mapOf([to('arrowleft', Companion_instance.o18_1), to('arrowright', Companion_instance.p18_1), to('arrowup', Companion_instance.q18_1), to('arrowdown', Companion_instance.r18_1), to('arrowdown', Companion_instance.r18_1), to('escape', Companion_instance.s18_1), to('alt', Companion_instance.u18_1), to('enter', Companion_instance.t18_1), to('delete', Companion_instance.v18_1), to(' ', Companion_instance.w18_1), to('0', Companion_instance.b19_1), to('1', Companion_instance.c19_1), to('2', Companion_instance.d19_1), to('3', Companion_instance.e19_1), to('4', Companion_instance.f19_1), to('5', Companion_instance.g19_1), to('6', Companion_instance.h19_1), to('7', Companion_instance.i19_1), to('8', Companion_instance.j19_1), to('9', Companion_instance.k19_1), to('a', Companion_instance.l19_1), to('b', Companion_instance.m19_1), to('c', Companion_instance.n19_1), to('d', Companion_instance.o19_1), to('e', Companion_instance.p19_1), to('f', Companion_instance.q19_1), to('x', Companion_instance.r19_1), to('z', Companion_instance.s19_1)]);
    }
  }
  function _get_LOG__e5r759($this) {
    var tmp0 = $this.b1x_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('LOG', 1, tmp, CanvasJs$Companion$_get_LOG_$ref_z8go9t(), null);
    return tmp0.j2();
  }
  function CanvasJs$Companion$_get_LOG_$ref_z8go9t() {
    return function (p0) {
      return _get_LOG__e5r759(p0);
    };
  }
  function Companion_0() {
    Companion_instance_4 = this;
    this.b1x_1 = logger(getKClass(CanvasJs));
  }
  var Companion_instance_4;
  function Companion_getInstance_2() {
    if (Companion_instance_4 == null)
      new Companion_0();
    return Companion_instance_4;
  }
  function _get_mouseListeners__9yov67($this) {
    var tmp0 = $this.i1x_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('mouseListeners', 1, tmp, CanvasJs$_get_mouseListeners_$ref_jcxtz1(), null);
    return tmp0.j2();
  }
  function _get_mouseMotionListeners__dn4ljb($this) {
    var tmp0 = $this.j1x_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('mouseMotionListeners', 1, tmp, CanvasJs$_get_mouseMotionListeners_$ref_qktcp(), null);
    return tmp0.j2();
  }
  function _get_mouseWheelListeners__sj0sxk($this) {
    var tmp0 = $this.k1x_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('mouseWheelListeners', 1, tmp, CanvasJs$_get_mouseWheelListeners_$ref_giy2oc(), null);
    return tmp0.j2();
  }
  function _get_keyListeners__kpczth($this) {
    var tmp0 = $this.l1x_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('keyListeners', 1, tmp, CanvasJs$_get_keyListeners_$ref_39kcd(), null);
    return tmp0.j2();
  }
  function _get_devicePixelRatioHandler__9bgwn6($this) {
    var tmp = $this.p1x_1;
    if (!(tmp == null))
      return tmp;
    else {
      throwUninitializedPropertyAccessException('devicePixelRatioHandler');
    }
  }
  function throttledResize($this, event) {
    event = event === VOID ? null : event;
    $this.q1x_1.dq();
  }
  function initializeDevicePixelRatioHandler($this) {
    var tmp = $this;
    tmp.p1x_1 = CanvasJs$initializeDevicePixelRatioHandler$lambda($this);
  }
  function handleDevicePixelRatioChanged($this) {
    resize($this);
    $this.e1x_1.nr('PROP_DEVICE_PIXEL_RATIO', $this.r1x(), $this.r1x());
  }
  function resize($this) {
    var oldDimension = $this.s1x();
    var rect = $this.c1x_1.getBoundingClientRect();
    var dpr = window.devicePixelRatio;
    _get_LOG__e5r759(Companion_getInstance_2()).pl('Resize CanvasJs w=' + rect.width + ', h=' + rect.height);
    // Inline function 'kotlin.math.ceil' call
    var x = rect.width * dpr;
    var tmp$ret$0 = Math.ceil(x);
    $this.c1x_1.width = numberToInt(tmp$ret$0);
    // Inline function 'kotlin.math.ceil' call
    var x_0 = rect.height * dpr;
    var tmp$ret$1 = Math.ceil(x_0);
    $this.c1x_1.height = numberToInt(tmp$ret$1);
    $this.t1x();
    $this.e1x_1.nr('PROP_DIMENSION', oldDimension, $this.s1x());
  }
  function paint($this) {
    if (!$this.h1x_1) {
      $this.d1x_1.u1x($this.g1x_1);
    }
  }
  function windowToCanvas($this, event) {
    var rect = $this.c1x_1.getBoundingClientRect();
    return Point2D_init_$Create$(numberToInt((event.clientX - rect.left) * window.devicePixelRatio), numberToInt((event.clientY - rect.top) * window.devicePixelRatio));
  }
  function mouseEventBridgeOf($this, l) {
    var tmp0 = _get_mouseListeners__9yov67($this);
    var tmp$ret$0;
    $l$block: {
      // Inline function 'kotlin.collections.firstOrNull' call
      var _iterator__ex2g4s = tmp0.i();
      while (_iterator__ex2g4s.j()) {
        var element = _iterator__ex2g4s.k();
        if (element.i1w_1 === l) {
          tmp$ret$0 = element;
          break $l$block;
        }
      }
      tmp$ret$0 = null;
    }
    return tmp$ret$0;
  }
  function mouseMotionEventBridgeOf($this, l) {
    var tmp0 = _get_mouseMotionListeners__dn4ljb($this);
    var tmp$ret$0;
    $l$block: {
      // Inline function 'kotlin.collections.firstOrNull' call
      var _iterator__ex2g4s = tmp0.i();
      while (_iterator__ex2g4s.j()) {
        var element = _iterator__ex2g4s.k();
        if (element.m1w_1 === l) {
          tmp$ret$0 = element;
          break $l$block;
        }
      }
      tmp$ret$0 = null;
    }
    return tmp$ret$0;
  }
  function mouseWheelEventBridgeOf($this, l) {
    var tmp0 = _get_mouseWheelListeners__sj0sxk($this);
    var tmp$ret$0;
    $l$block: {
      // Inline function 'kotlin.collections.firstOrNull' call
      var _iterator__ex2g4s = tmp0.i();
      while (_iterator__ex2g4s.j()) {
        var element = _iterator__ex2g4s.k();
        if (element.q1w_1 === l) {
          tmp$ret$0 = element;
          break $l$block;
        }
      }
      tmp$ret$0 = null;
    }
    return tmp$ret$0;
  }
  function keyEventBridgeOf($this, l) {
    var tmp0 = _get_keyListeners__kpczth($this);
    var tmp$ret$0;
    $l$block: {
      // Inline function 'kotlin.collections.firstOrNull' call
      var _iterator__ex2g4s = tmp0.i();
      while (_iterator__ex2g4s.j()) {
        var element = _iterator__ex2g4s.k();
        if (element.s1w_1 === l) {
          tmp$ret$0 = element;
          break $l$block;
        }
      }
      tmp$ret$0 = null;
    }
    return tmp$ret$0;
  }
  function CanvasJs$mouseListeners$delegate$lambda() {
    // Inline function 'kotlin.collections.mutableListOf' call
    return ArrayList_init_$Create$();
  }
  function CanvasJs$_get_mouseListeners_$ref_jcxtz1() {
    return function (p0) {
      return _get_mouseListeners__9yov67(p0);
    };
  }
  function CanvasJs$mouseMotionListeners$delegate$lambda() {
    // Inline function 'kotlin.collections.mutableListOf' call
    return ArrayList_init_$Create$();
  }
  function CanvasJs$_get_mouseMotionListeners_$ref_qktcp() {
    return function (p0) {
      return _get_mouseMotionListeners__dn4ljb(p0);
    };
  }
  function CanvasJs$mouseWheelListeners$delegate$lambda() {
    // Inline function 'kotlin.collections.mutableListOf' call
    return ArrayList_init_$Create$();
  }
  function CanvasJs$_get_mouseWheelListeners_$ref_giy2oc() {
    return function (p0) {
      return _get_mouseWheelListeners__sj0sxk(p0);
    };
  }
  function CanvasJs$keyListeners$delegate$lambda() {
    // Inline function 'kotlin.collections.mutableListOf' call
    return ArrayList_init_$Create$();
  }
  function CanvasJs$_get_keyListeners_$ref_39kcd() {
    return function (p0) {
      return _get_keyListeners__kpczth(p0);
    };
  }
  function CanvasJs$resize$ref(p0) {
    var l = function () {
      var tmp0 = p0;
      resize(tmp0);
      return Unit_instance;
    };
    l.callableName = 'resize';
    return l;
  }
  function CanvasJs$throttledResize$ref(p0) {
    var l = function (_this__u8e3s4) {
      var tmp0 = p0;
      throttledResize(tmp0, _this__u8e3s4);
      return Unit_instance;
    };
    l.callableName = 'throttledResize';
    return l;
  }
  function CanvasJs$initializeDevicePixelRatioHandler$lambda$lambda($media, this$0) {
    return function (it) {
      $media.removeEventListener('change', _get_devicePixelRatioHandler__9bgwn6(this$0));
      return Unit_instance;
    };
  }
  function CanvasJs$initializeDevicePixelRatioHandler$lambda(this$0) {
    return function (it) {
      var tmp0_safe_receiver = this$0.o1x_1;
      if (tmp0_safe_receiver == null)
        null;
      else
        tmp0_safe_receiver(null);
      var mqString = '(resolution: ' + window.devicePixelRatio + 'dppx';
      var media = window.matchMedia(mqString);
      media.addEventListener('change', _get_devicePixelRatioHandler__9bgwn6(this$0));
      var tmp = this$0;
      tmp.o1x_1 = CanvasJs$initializeDevicePixelRatioHandler$lambda$lambda(media, this$0);
      handleDevicePixelRatioChanged(this$0);
      return Unit_instance;
    };
  }
  function CanvasJs$windowToCanvas$ref(p0) {
    var l = function (_this__u8e3s4) {
      var tmp0 = p0;
      return windowToCanvas(tmp0, _this__u8e3s4);
    };
    l.callableName = 'windowToCanvas';
    return l;
  }
  function CanvasJs$windowToCanvas$ref_0(p0) {
    var l = function (_this__u8e3s4) {
      var tmp0 = p0;
      return windowToCanvas(tmp0, _this__u8e3s4);
    };
    l.callableName = 'windowToCanvas';
    return l;
  }
  function CanvasJs$windowToCanvas$ref_1(p0) {
    var l = function (_this__u8e3s4) {
      var tmp0 = p0;
      return windowToCanvas(tmp0, _this__u8e3s4);
    };
    l.callableName = 'windowToCanvas';
    return l;
  }
  function CanvasJs(canvas, view, styleProvider, propertyOwner) {
    Companion_getInstance_2();
    styleProvider = styleProvider === VOID ? DrawStyleModule_getInstance().w1x_1 : styleProvider;
    propertyOwner = propertyOwner === VOID ? new PropertyOwnerImpl() : propertyOwner;
    this.c1x_1 = canvas;
    this.d1x_1 = view;
    this.e1x_1 = propertyOwner;
    var tmp = this;
    var tmp_0 = ensureNotNull(this.c1x_1.getContext('2d'));
    tmp.f1x_1 = tmp_0 instanceof CanvasRenderingContext2D ? tmp_0 : THROW_CCE();
    this.g1x_1 = new Graphics2DJs(this.f1x_1);
    this.h1x_1 = true;
    var tmp_1 = this;
    tmp_1.i1x_1 = lazy(CanvasJs$mouseListeners$delegate$lambda);
    var tmp_2 = this;
    tmp_2.j1x_1 = lazy(CanvasJs$mouseMotionListeners$delegate$lambda);
    var tmp_3 = this;
    tmp_3.k1x_1 = lazy(CanvasJs$mouseWheelListeners$delegate$lambda);
    var tmp_4 = this;
    tmp_4.l1x_1 = lazy(CanvasJs$keyListeners$delegate$lambda);
    this.m1x_1 = styleProvider.f1y(Companion_getInstance_33().d1y_1).c1u().y1x_1;
    this.n1x_1 = null;
    this.o1x_1 = null;
    var tmp_5 = this;
    tmp_5.q1x_1 = new Throttle(CanvasJs$resize$ref(this), 100);
    this.e1x_1.t1b(this);
    this.d1x_1.g1y(this);
    this.d1x_1.to();
    this.h1x_1 = false;
    initializeDevicePixelRatioHandler(this);
    _get_devicePixelRatioHandler__9bgwn6(this)(null);
    var tmp_6 = window;
    tmp_6.addEventListener('resize', CanvasJs$throttledResize$ref(this));
  }
  protoOf(CanvasJs).v1o = function () {
    return this.d1x_1;
  };
  protoOf(CanvasJs).r1x = function () {
    return window.devicePixelRatio;
  };
  protoOf(CanvasJs).s1x = function () {
    return Dimension2D_init_$Create$(this.c1x_1.width, this.c1x_1.height);
  };
  protoOf(CanvasJs).h1y = function () {
    throw UnsupportedOperationException_init_$Create$('getting mouseLocation not yet implemented');
  };
  protoOf(CanvasJs).i1y = function () {
    return true;
  };
  protoOf(CanvasJs).j1y = function () {
    return false;
  };
  protoOf(CanvasJs).k1y = function () {
    this.c1x_1.focus();
  };
  protoOf(CanvasJs).l1y = function (cursor) {
    switch (cursor.l2_1) {
      case 0:
        this.c1x_1.style.cursor = 'default';
        break;
      case 1:
        this.c1x_1.style.cursor = 'wait';
        break;
      case 2:
        this.c1x_1.style.cursor = 'pointer';
        break;
      case 3:
        this.c1x_1.style.cursor = 'move';
        break;
      case 4:
        this.c1x_1.style.cursor = 'crosshair';
        break;
      case 5:
        this.c1x_1.style.cursor = 'nw-resize';
        break;
      case 6:
        this.c1x_1.style.cursor = 'n-resize';
        break;
      case 7:
        this.c1x_1.style.cursor = 'ne-resize';
        break;
      case 8:
        this.c1x_1.style.cursor = 'e-resize';
        break;
      case 9:
        this.c1x_1.style.cursor = 'se-resize';
        break;
      case 10:
        this.c1x_1.style.cursor = 's-resize';
        break;
      case 11:
        this.c1x_1.style.cursor = 'sw-resize';
        break;
      case 12:
        this.c1x_1.style.cursor = 'w-resize';
        break;
      case 13:
        this.c1x_1.style.cursor = 'text';
        break;
      default:
        noWhenBranchMatchedException();
        break;
    }
  };
  protoOf(CanvasJs).t1x = function () {
    this.m1y(0, 0, this.c1x_1.width, this.c1x_1.height);
  };
  protoOf(CanvasJs).m1y = function (x, y, width, height) {
    var xx = 0;
    var yy = 0;
    var ww = this.c1x_1.width;
    var hh = this.c1x_1.height;
    this.g1x_1.l1s_1.i1c(xx, yy, ww, hh);
    this.f1x_1.save();
    this.f1x_1.setTransform(1.0, 0.0, 0.0, 1.0, 0.0, 0.0);
    this.f1x_1.fillStyle = 'rgba(' + this.m1x_1.n1y_1 + ',' + this.m1x_1.o1y_1 + ', ' + this.m1x_1.p1y_1 + ', 1.0)';
    this.f1x_1.fillRect(xx, yy, ww, hh);
    this.f1x_1.restore();
    var dpr = this.r1x();
    this.f1x_1.scale(dpr, dpr);
    paint(this);
    this.f1x_1.scale(1 / dpr, 1 / dpr);
  };
  protoOf(CanvasJs).r1y = function (l) {
    var bridge = mouseEventBridgeOf(this, l);
    if (bridge == null) {
      bridge = new MouseEventBridge(CanvasJs$windowToCanvas$ref(this), l, this.c1x_1);
      this.c1x_1.addEventListener('mousedown', bridge);
      this.c1x_1.addEventListener('mouseup', bridge);
      this.c1x_1.addEventListener('click', bridge);
      this.c1x_1.addEventListener('dblclick', bridge);
      _get_mouseListeners__9yov67(this).h(bridge);
    }
  };
  protoOf(CanvasJs).s1y = function (l) {
    var bridge = mouseEventBridgeOf(this, l);
    if (!(bridge == null)) {
      this.c1x_1.removeEventListener('mousedown', bridge);
      this.c1x_1.removeEventListener('mouseup', bridge);
      this.c1x_1.removeEventListener('click', bridge);
      this.c1x_1.removeEventListener('dblclick', bridge);
      _get_mouseListeners__9yov67(this).h2(bridge);
    }
  };
  protoOf(CanvasJs).t1y = function (l) {
    var bridge = mouseMotionEventBridgeOf(this, l);
    if (bridge == null) {
      bridge = new MouseMotionEventBridge(CanvasJs$windowToCanvas$ref_0(this), l, this.c1x_1);
      this.c1x_1.addEventListener('mousedown', bridge);
      this.c1x_1.addEventListener('mouseup', bridge);
      this.c1x_1.addEventListener('mousemove', bridge);
      _get_mouseMotionListeners__dn4ljb(this).h(bridge);
    }
  };
  protoOf(CanvasJs).u1y = function (l) {
    var bridge = mouseMotionEventBridgeOf(this, l);
    if (!(bridge == null)) {
      this.c1x_1.removeEventListener('mousedown', bridge);
      this.c1x_1.removeEventListener('mouseup', bridge);
      this.c1x_1.removeEventListener('mousemove', bridge);
      _get_mouseMotionListeners__dn4ljb(this).h2(bridge);
    }
  };
  protoOf(CanvasJs).v1y = function (l) {
    var bridge = mouseWheelEventBridgeOf(this, l);
    if (bridge == null) {
      bridge = new MouseWheelEventBridge(CanvasJs$windowToCanvas$ref_1(this), l, this.c1x_1);
      this.c1x_1.addEventListener('wheel', bridge);
      _get_mouseWheelListeners__sj0sxk(this).h(bridge);
    }
  };
  protoOf(CanvasJs).w1y = function (l) {
    var bridge = mouseWheelEventBridgeOf(this, l);
    if (!(bridge == null)) {
      this.c1x_1.removeEventListener('wheel', bridge);
      _get_mouseWheelListeners__sj0sxk(this).h2(bridge);
    }
  };
  protoOf(CanvasJs).x1y = function (l) {
    var bridge = keyEventBridgeOf(this, l);
    if (bridge == null) {
      bridge = new KeyEventBridge(l, this.c1x_1);
      this.c1x_1.addEventListener('keydown', bridge);
      this.c1x_1.addEventListener('keyup', bridge);
    }
  };
  protoOf(CanvasJs).y1y = function (l) {
    var bridge = keyEventBridgeOf(this, l);
    if (!(bridge == null)) {
      this.c1x_1.removeEventListener('keydown', bridge);
      this.c1x_1.removeEventListener('keyup', bridge);
      _get_keyListeners__kpczth(this).h2(bridge);
    }
  };
  protoOf(CanvasJs).z1y = function (e) {
  };
  protoOf(CanvasJs).a1z = function (name, oldValue, newValue) {
  };
  protoOf(CanvasJs).nr = function (name, oldValue, newValue) {
    return this.a1z(name, oldValue, newValue);
  };
  protoOf(CanvasJs).b1z = function (l) {
    this.e1x_1.u1b(l);
  };
  protoOf(CanvasJs).u1b = function (l) {
    return this.b1z(l);
  };
  protoOf(CanvasJs).c1z = function (l) {
    this.e1x_1.v1b(l);
  };
  protoOf(CanvasJs).v1b = function (l) {
    return this.c1z(l);
  };
  protoOf(CanvasJs).t1b = function (_set____db54di) {
    this.e1x_1.t1b(_set____db54di);
  };
  function fillProperties($this, properties) {
    properties.et('draw.view.tooltipsEnabled', true);
    properties.et('view.ZoomPanController.wheelZoomRequiredMeta', true);
  }
  function DrawModuleJs() {
    DrawModuleJs_instance = this;
    AbstractModule.call(this);
  }
  protoOf(DrawModuleJs).to = function () {
    BaseModuleJs_getInstance().vo();
    DrawModule_getInstance().vo();
    fillProperties(this, BaseModule_getInstance().zo_1);
  };
  var DrawModuleJs_instance;
  function DrawModuleJs_getInstance() {
    if (DrawModuleJs_instance == null)
      new DrawModuleJs();
    return DrawModuleJs_instance;
  }
  function Companion_1() {
    this.e1z_1 = 'PROP_APPLICATION_CONTEXT';
  }
  var Companion_instance_5;
  function Companion_getInstance_3() {
    return Companion_instance_5;
  }
  function ApplicationContextHolder(applicationContext, propertyOwner) {
    applicationContext = applicationContext === VOID ? null : applicationContext;
    propertyOwner = propertyOwner === VOID ? new PropertyOwnerImpl() : propertyOwner;
    this.f1z_1 = propertyOwner;
    this.g1z_1 = applicationContext;
    this.f1z_1.t1b(this);
  }
  protoOf(ApplicationContextHolder).h1z = function (value) {
    var oldValue = this.g1z_1;
    this.g1z_1 = value;
    this.f1z_1.nr('PROP_APPLICATION_CONTEXT', oldValue, value);
  };
  protoOf(ApplicationContextHolder).b1z = function (l) {
    this.f1z_1.u1b(l);
  };
  protoOf(ApplicationContextHolder).u1b = function (l) {
    return this.b1z(l);
  };
  protoOf(ApplicationContextHolder).c1z = function (l) {
    this.f1z_1.v1b(l);
  };
  protoOf(ApplicationContextHolder).v1b = function (l) {
    return this.c1z(l);
  };
  protoOf(ApplicationContextHolder).a1z = function (name, oldValue, newValue) {
    this.f1z_1.nr(name, oldValue, newValue);
  };
  protoOf(ApplicationContextHolder).nr = function (name, oldValue, newValue) {
    return this.a1z(name, oldValue, newValue);
  };
  protoOf(ApplicationContextHolder).t1b = function (_set____db54di) {
    this.f1z_1.t1b(_set____db54di);
  };
  function PopupMenuEvent(canvas) {
    this.i1z_1 = canvas;
  }
  protoOf(PopupMenuEvent).toString = function () {
    return 'PopupMenuEvent(canvas=' + toString(this.i1z_1) + ')';
  };
  protoOf(PopupMenuEvent).hashCode = function () {
    return hashCode(this.i1z_1);
  };
  protoOf(PopupMenuEvent).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof PopupMenuEvent))
      return false;
    if (!equals(this.i1z_1, other.i1z_1))
      return false;
    return true;
  };
  function DrawContext(g, modelClip, appContext) {
    modelClip = modelClip === VOID ? null : modelClip;
    appContext = appContext === VOID ? null : appContext;
    this.j1z_1 = g;
    this.k1z_1 = modelClip;
    this.l1z_1 = appContext;
    this.m1z_1 = false;
    this.n1z_1 = null;
    this.o1z_1 = null;
    this.p1z_1 = null;
  }
  protoOf(DrawContext).q1z = function (color) {
    return this.m1z_1 ? ensureNotNull(this.n1z_1) : color;
  };
  protoOf(DrawContext).r1z = function (color) {
    return this.m1z_1 ? ensureNotNull(this.n1z_1).x1x_1 : color;
  };
  protoOf(DrawContext).s1z = function (color) {
    return this.m1z_1 ? ensureNotNull(this.n1z_1).y1x_1 : color;
  };
  protoOf(DrawContext).t1z = function (color) {
    return this.m1z_1 ? ensureNotNull(this.n1z_1).z1x_1 : color;
  };
  protoOf(DrawContext).u1z = function () {
    return this.l1z_1;
  };
  protoOf(DrawContext).v1z = function (defaultColor) {
    var tmp0_safe_receiver = this.o1z_1;
    var tmp1_elvis_lhs = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.c1u();
    return tmp1_elvis_lhs == null ? defaultColor : tmp1_elvis_lhs;
  };
  function DrawProperties(target) {
    target = target === VOID ? BaseModule_getInstance().zo_1 : target;
    PropertiesProxy.call(this, target);
  }
  protoOf(DrawProperties).y1z = function (name) {
    return this.qt_1.nt(name);
  };
  protoOf(DrawProperties).z1z = function (name) {
    return this.qt_1.nt(name);
  };
  protoOf(DrawProperties).a20 = function (name) {
    return this.qt_1.nt(name);
  };
  function Drawable() {
  }
  function DrawableExplanation(explanation, sourceRect) {
    this.q20_1 = explanation;
    this.r20_1 = sourceRect;
  }
  protoOf(DrawableExplanation).toString = function () {
    return 'DrawableExplanation(explanation=' + toString(this.q20_1) + ', sourceRect=' + toString(this.r20_1) + ')';
  };
  protoOf(DrawableExplanation).hashCode = function () {
    var result = hashCode(this.q20_1);
    result = imul(result, 31) + hashCode(this.r20_1) | 0;
    return result;
  };
  protoOf(DrawableExplanation).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof DrawableExplanation))
      return false;
    if (!equals(this.q20_1, other.q20_1))
      return false;
    if (!equals(this.r20_1, other.r20_1))
      return false;
    return true;
  };
  function DrawableBag$backToFrontIterator$1($iter) {
    this.s20_1 = $iter;
  }
  protoOf(DrawableBag$backToFrontIterator$1).j = function () {
    return this.s20_1.n3();
  };
  protoOf(DrawableBag$backToFrontIterator$1).k = function () {
    return this.s20_1.o3();
  };
  function DrawableBag$getDrawableAt$lambda(it) {
    return true;
  }
  function DrawableBag$getDrawableAt$lambda_0(it) {
    return true;
  }
  function DrawableBag$getDrawableIntersection$lambda(it) {
    return true;
  }
  function DrawableBag() {
  }
  function DrawableContainer() {
  }
  function DrawableContainerEvent(container, child) {
    this.w21_1 = container;
    this.x21_1 = child;
  }
  protoOf(DrawableContainerEvent).toString = function () {
    return 'DrawableContainerEvent(container=' + toString(this.w21_1) + ', child=' + toString(this.x21_1) + ')';
  };
  protoOf(DrawableContainerEvent).hashCode = function () {
    var result = hashCode(this.w21_1);
    result = imul(result, 31) + hashCode(this.x21_1) | 0;
    return result;
  };
  protoOf(DrawableContainerEvent).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof DrawableContainerEvent))
      return false;
    if (!equals(this.w21_1, other.w21_1))
      return false;
    if (!equals(this.x21_1, other.x21_1))
      return false;
    return true;
  };
  function DrawableContainerListener() {
  }
  function DrawableEvent_init_$Init$(source, $this) {
    DrawableEvent.call($this, source, Rectangle2D_init_$Create$(source.fo()));
    return $this;
  }
  function DrawableEvent_init_$Create$(source) {
    return DrawableEvent_init_$Init$(source, objectCreate(protoOf(DrawableEvent)));
  }
  function DrawableEvent(source, area) {
    this.a22_1 = source;
    this.b22_1 = area;
  }
  protoOf(DrawableEvent).toString = function () {
    return 'DrawableEvent(source=' + toString(this.a22_1) + ', area=' + toString(this.b22_1) + ')';
  };
  protoOf(DrawableEvent).hashCode = function () {
    var result = hashCode(this.a22_1);
    result = imul(result, 31) + hashCode(this.b22_1) | 0;
    return result;
  };
  protoOf(DrawableEvent).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof DrawableEvent))
      return false;
    if (!equals(this.a22_1, other.a22_1))
      return false;
    if (!equals(this.b22_1, other.b22_1))
      return false;
    return true;
  };
  function DrawableAdapter() {
  }
  protoOf(DrawableAdapter).c22 = function (event) {
  };
  protoOf(DrawableAdapter).d22 = function (event) {
  };
  protoOf(DrawableAdapter).e22 = function (event) {
  };
  function Focusable() {
  }
  function _set_focusOwner__ald35o($this, value) {
    if (equals($this.h22_1, value)) {
      return Unit_instance;
    }
    if (!(value == null) && !value.f22()) {
      return Unit_instance;
    }
    var oldValue = $this.h22_1;
    $this.h22_1 = value;
    if (oldValue == null)
      null;
    else {
      oldValue.l22();
    }
    var tmp1_safe_receiver = $this.h22_1;
    if (tmp1_safe_receiver == null)
      null;
    else {
      tmp1_safe_receiver.k22();
    }
  }
  function FocusManager() {
    this.h22_1 = null;
  }
  protoOf(FocusManager).j22 = function (c) {
    _set_focusOwner__ald35o(this, c);
  };
  protoOf(FocusManager).m22 = function () {
    _set_focusOwner__ald35o(this, null);
  };
  var FocusManager_instance;
  function FocusManager_getInstance() {
    return FocusManager_instance;
  }
  function InputEventContext(view, mouseEvent, keyEvent, x, y, readonly) {
    mouseEvent = mouseEvent === VOID ? null : mouseEvent;
    keyEvent = keyEvent === VOID ? null : keyEvent;
    x = x === VOID ? 0.0 : x;
    y = y === VOID ? 0.0 : y;
    readonly = readonly === VOID ? false : readonly;
    this.n22_1 = view;
    this.o22_1 = mouseEvent;
    this.p22_1 = keyEvent;
    this.q22_1 = x;
    this.r22_1 = y;
    this.s22_1 = readonly;
    this.t22_1 = new Point2D(this.q22_1, this.r22_1);
  }
  protoOf(InputEventContext).u22 = function (p) {
    return this.v22(p.kn_1, p.ln_1);
  };
  protoOf(InputEventContext).v22 = function (x, y) {
    return new InputEventContext(this.n22_1, this.o22_1, this.p22_1, x, y);
  };
  protoOf(InputEventContext).toString = function () {
    var tmp0_safe_receiver = this.o22_1;
    var tmp1_elvis_lhs = tmp0_safe_receiver == null ? null : toString(tmp0_safe_receiver);
    var tmp;
    if (tmp1_elvis_lhs == null) {
      var tmp2_safe_receiver = this.p22_1;
      tmp = tmp2_safe_receiver == null ? null : toString(tmp2_safe_receiver);
    } else {
      tmp = tmp1_elvis_lhs;
    }
    var tmp3_elvis_lhs = tmp;
    return tmp3_elvis_lhs == null ? '' : tmp3_elvis_lhs;
  };
  function Companion_2() {
    Companion_instance_6 = this;
    this.w22_1 = new InputEventHandlerAdapter();
  }
  var Companion_instance_6;
  function Companion_getInstance_4() {
    if (Companion_instance_6 == null)
      new Companion_2();
    return Companion_instance_6;
  }
  function InputEventHandlerAdapter$_init_$lambda_h27nti(it) {
    return null;
  }
  function InputEventHandlerAdapter(successor) {
    Companion_getInstance_4();
    var tmp;
    if (successor === VOID) {
      tmp = InputEventHandlerAdapter$_init_$lambda_h27nti;
    } else {
      tmp = successor;
    }
    successor = tmp;
    this.x22_1 = successor;
  }
  protoOf(InputEventHandlerAdapter).y22 = function (context) {
    var tmp0_safe_receiver = this.x22_1(context);
    return tmp0_safe_receiver == null ? null : tmp0_safe_receiver.y22(context);
  };
  protoOf(InputEventHandlerAdapter).z22 = function (context) {
    var tmp0_safe_receiver = this.x22_1(context);
    return tmp0_safe_receiver == null ? null : tmp0_safe_receiver.z22(context);
  };
  protoOf(InputEventHandlerAdapter).a23 = function (context) {
    var tmp0_safe_receiver = this.x22_1(context);
    return tmp0_safe_receiver == null ? null : tmp0_safe_receiver.a23(context);
  };
  protoOf(InputEventHandlerAdapter).b23 = function (context) {
    var tmp0_safe_receiver = this.x22_1(context);
    return tmp0_safe_receiver == null ? null : tmp0_safe_receiver.b23(context);
  };
  protoOf(InputEventHandlerAdapter).c23 = function (context) {
    var tmp0_safe_receiver = this.x22_1(context);
    return tmp0_safe_receiver == null ? null : tmp0_safe_receiver.c23(context);
  };
  protoOf(InputEventHandlerAdapter).d23 = function (context) {
    var tmp0_safe_receiver = this.x22_1(context);
    return tmp0_safe_receiver == null ? null : tmp0_safe_receiver.d23(context);
  };
  protoOf(InputEventHandlerAdapter).e23 = function (context) {
    var tmp0_safe_receiver = this.x22_1(context);
    return tmp0_safe_receiver == null ? null : tmp0_safe_receiver.e23(context);
  };
  function InputEventHandler() {
  }
  function StateMachineInputEventHandler$Companion$mouseMoved$lambda(it) {
    var tmp0_safe_receiver = it.o22_1;
    return equals(tmp0_safe_receiver == null ? null : tmp0_safe_receiver.k1a(), MouseEventType_MOVED_getInstance());
  }
  function StateMachineInputEventHandler$Companion$mouseDragged$lambda(it) {
    var tmp0_safe_receiver = it.o22_1;
    return equals(tmp0_safe_receiver == null ? null : tmp0_safe_receiver.k1a(), MouseEventType_DRAGGED_getInstance());
  }
  function StateMachineInputEventHandler$Companion$mouseLeftPressed$lambda(it) {
    var tmp;
    var tmp0_safe_receiver = it.o22_1;
    if (equals(tmp0_safe_receiver == null ? null : tmp0_safe_receiver.k1a(), MouseEventType_PRESSED_getInstance())) {
      tmp = it.o22_1.u1a();
    } else {
      tmp = false;
    }
    return tmp;
  }
  function StateMachineInputEventHandler$Companion$mouseLeftReleased$lambda(it) {
    var tmp;
    var tmp0_safe_receiver = it.o22_1;
    if (equals(tmp0_safe_receiver == null ? null : tmp0_safe_receiver.k1a(), MouseEventType_RELEASED_getInstance())) {
      tmp = it.o22_1.u1a();
    } else {
      tmp = false;
    }
    return tmp;
  }
  function StateMachineInputEventHandler$Companion$mouseLeftClicked$lambda(it) {
    var tmp;
    var tmp0_safe_receiver = it.o22_1;
    if (equals(tmp0_safe_receiver == null ? null : tmp0_safe_receiver.k1a(), MouseEventType_CLICKED_getInstance())) {
      tmp = it.o22_1.u1a();
    } else {
      tmp = false;
    }
    return tmp;
  }
  function StateMachineInputEventHandler$Companion$mouseLeftSingleClicked$lambda(it) {
    var tmp;
    var tmp_0;
    var tmp0_safe_receiver = it.o22_1;
    if (equals(tmp0_safe_receiver == null ? null : tmp0_safe_receiver.k1a(), MouseEventType_CLICKED_getInstance())) {
      tmp_0 = it.o22_1.u1a();
    } else {
      tmp_0 = false;
    }
    if (tmp_0) {
      tmp = !(it.o22_1.s1a() === 2);
    } else {
      tmp = false;
    }
    return tmp;
  }
  function StateMachineInputEventHandler$Companion$mouseLeftDoubleClicked$lambda(it) {
    var tmp;
    var tmp_0;
    var tmp0_safe_receiver = it.o22_1;
    if (equals(tmp0_safe_receiver == null ? null : tmp0_safe_receiver.k1a(), MouseEventType_CLICKED_getInstance())) {
      tmp_0 = it.o22_1.u1a();
    } else {
      tmp_0 = false;
    }
    if (tmp_0) {
      tmp = it.o22_1.s1a() === 2;
    } else {
      tmp = false;
    }
    return tmp;
  }
  function StateMachineInputEventHandler$Companion$keyReleased$lambda(it) {
    var tmp0_safe_receiver = it.p22_1;
    return equals(tmp0_safe_receiver == null ? null : tmp0_safe_receiver.k1a(), KeyEventType_RELEASED_getInstance());
  }
  function StateMachineInputEventHandler$Companion$escapePressed$lambda(it) {
    var tmp;
    var tmp0_safe_receiver = it.p22_1;
    if (equals(tmp0_safe_receiver == null ? null : tmp0_safe_receiver.k1a(), KeyEventType_PRESSED_getInstance())) {
      tmp = it.p22_1.i2() === Companion_instance.s18_1;
    } else {
      tmp = false;
    }
    return tmp;
  }
  function StateMachineInputEventHandler$Companion$altPressed$lambda(it) {
    var tmp;
    var tmp0_safe_receiver = it.p22_1;
    if (equals(tmp0_safe_receiver == null ? null : tmp0_safe_receiver.k1a(), KeyEventType_PRESSED_getInstance())) {
      tmp = it.p22_1.i2() === Companion_instance.u18_1;
    } else {
      tmp = false;
    }
    return tmp;
  }
  function StateMachineInputEventHandler$Companion$altReleased$lambda(it) {
    var tmp;
    var tmp0_safe_receiver = it.p22_1;
    if (equals(tmp0_safe_receiver == null ? null : tmp0_safe_receiver.k1a(), KeyEventType_RELEASED_getInstance())) {
      tmp = it.p22_1.i2() === Companion_instance.u18_1;
    } else {
      tmp = false;
    }
    return tmp;
  }
  function Companion_3() {
    Companion_instance_7 = this;
    var tmp = this;
    tmp.f23_1 = StateMachineInputEventHandler$Companion$mouseMoved$lambda;
    var tmp_0 = this;
    tmp_0.g23_1 = StateMachineInputEventHandler$Companion$mouseDragged$lambda;
    var tmp_1 = this;
    tmp_1.h23_1 = StateMachineInputEventHandler$Companion$mouseLeftPressed$lambda;
    var tmp_2 = this;
    tmp_2.i23_1 = StateMachineInputEventHandler$Companion$mouseLeftReleased$lambda;
    var tmp_3 = this;
    tmp_3.j23_1 = StateMachineInputEventHandler$Companion$mouseLeftClicked$lambda;
    var tmp_4 = this;
    tmp_4.k23_1 = StateMachineInputEventHandler$Companion$mouseLeftSingleClicked$lambda;
    var tmp_5 = this;
    tmp_5.l23_1 = StateMachineInputEventHandler$Companion$mouseLeftDoubleClicked$lambda;
    var tmp_6 = this;
    tmp_6.m23_1 = StateMachineInputEventHandler$Companion$keyReleased$lambda;
    var tmp_7 = this;
    tmp_7.n23_1 = StateMachineInputEventHandler$Companion$escapePressed$lambda;
    var tmp_8 = this;
    tmp_8.o23_1 = StateMachineInputEventHandler$Companion$altPressed$lambda;
    var tmp_9 = this;
    tmp_9.p23_1 = StateMachineInputEventHandler$Companion$altReleased$lambda;
  }
  var Companion_instance_7;
  function Companion_getInstance_5() {
    if (Companion_instance_7 == null)
      new Companion_3();
    return Companion_instance_7;
  }
  function StateMachineInputEventHandler(sm, successor) {
    Companion_getInstance_5();
    successor = successor === VOID ? null : successor;
    this.q23_1 = sm;
    this.r23_1 = successor;
    if (this.q23_1.s1m_1.equals(UnhandledEventBehaviour_Strict_getInstance())) {
      throw IllegalArgumentException_init_$Create$('StateMachine must not be strict');
    }
  }
  protoOf(StateMachineInputEventHandler).y22 = function (context) {
    var tmp0_safe_receiver = context.o22_1;
    if (!equals(tmp0_safe_receiver == null ? null : tmp0_safe_receiver.r1a(), Button_BUTTON1_getInstance())) {
      return this;
    }
    var tmp;
    if (this.q23_1.j1m(context)) {
      tmp = this;
    } else {
      var tmp1_safe_receiver = this.r23_1;
      tmp = tmp1_safe_receiver == null ? null : tmp1_safe_receiver.y22(context);
    }
    return tmp;
  };
  protoOf(StateMachineInputEventHandler).z22 = function (context) {
    var tmp;
    if (this.q23_1.j1m(context)) {
      tmp = this;
    } else {
      var tmp0_safe_receiver = this.r23_1;
      tmp = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.z22(context);
    }
    return tmp;
  };
  protoOf(StateMachineInputEventHandler).a23 = function (context) {
    var tmp;
    if (this.q23_1.j1m(context)) {
      tmp = this;
    } else {
      var tmp0_safe_receiver = this.r23_1;
      tmp = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.a23(context);
    }
    return tmp;
  };
  protoOf(StateMachineInputEventHandler).b23 = function (context) {
    var tmp;
    if (this.q23_1.j1m(context)) {
      tmp = this;
    } else {
      var tmp0_safe_receiver = this.r23_1;
      tmp = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.b23(context);
    }
    return tmp;
  };
  protoOf(StateMachineInputEventHandler).c23 = function (context) {
    var tmp;
    if (this.q23_1.j1m(context)) {
      tmp = this;
    } else {
      var tmp0_safe_receiver = this.r23_1;
      tmp = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.c23(context);
    }
    return tmp;
  };
  protoOf(StateMachineInputEventHandler).d23 = function (context) {
    var tmp;
    if (this.q23_1.j1m(context)) {
      tmp = this;
    } else {
      var tmp0_safe_receiver = this.r23_1;
      tmp = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.d23(context);
    }
    return tmp;
  };
  protoOf(StateMachineInputEventHandler).e23 = function (context) {
    var tmp;
    if (this.q23_1.j1m(context)) {
      tmp = this;
    } else {
      var tmp0_safe_receiver = this.r23_1;
      tmp = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.e23(context);
    }
    return tmp;
  };
  function View() {
  }
  function Companion_4() {
  }
  protoOf(Companion_4).m25 = function () {
    var tmp = ZoomPan_init_$Create$();
    // Inline function 'kotlin.apply' call
    var this_0 = System_getInstance().bm();
    this_0.r1d();
    return new ViewTransformation(tmp, this_0);
  };
  var Companion_instance_8;
  function Companion_getInstance_6() {
    return Companion_instance_8;
  }
  function ViewTransformation(zoomPan, affineTransform) {
    this.n25_1 = zoomPan;
    this.o25_1 = affineTransform;
  }
  protoOf(ViewTransformation).p25 = function (zoomPan, affineTransform) {
    return new ViewTransformation(zoomPan, affineTransform);
  };
  protoOf(ViewTransformation).q25 = function (zoomPan, affineTransform, $super) {
    zoomPan = zoomPan === VOID ? this.n25_1 : zoomPan;
    affineTransform = affineTransform === VOID ? this.o25_1 : affineTransform;
    return $super === VOID ? this.p25(zoomPan, affineTransform) : $super.p25.call(this, zoomPan, affineTransform);
  };
  protoOf(ViewTransformation).toString = function () {
    return 'ViewTransformation(zoomPan=' + this.n25_1.toString() + ', affineTransform=' + toString(this.o25_1) + ')';
  };
  protoOf(ViewTransformation).hashCode = function () {
    var result = this.n25_1.hashCode();
    result = imul(result, 31) + hashCode(this.o25_1) | 0;
    return result;
  };
  protoOf(ViewTransformation).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof ViewTransformation))
      return false;
    if (!this.n25_1.equals(other.n25_1))
      return false;
    if (!equals(this.o25_1, other.o25_1))
      return false;
    return true;
  };
  function CloseViewRequest(view) {
    this.r25_1 = view;
  }
  protoOf(CloseViewRequest).toString = function () {
    return 'CloseViewRequest(view=' + toString(this.r25_1) + ')';
  };
  protoOf(CloseViewRequest).hashCode = function () {
    return hashCode(this.r25_1);
  };
  protoOf(CloseViewRequest).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof CloseViewRequest))
      return false;
    if (!equals(this.r25_1, other.r25_1))
      return false;
    return true;
  };
  function Companion_5() {
    this.s25_1 = 'ViewContentBounds.total';
  }
  var Companion_instance_9;
  function Companion_getInstance_7() {
    return Companion_instance_9;
  }
  function ViewContentBounds(propertyOwner, mainBoundsAccessor) {
    propertyOwner = propertyOwner === VOID ? new PropertyOwnerImpl() : propertyOwner;
    this.t25_1 = propertyOwner;
    this.u25_1 = mainBoundsAccessor;
    var tmp = this;
    // Inline function 'kotlin.collections.mutableListOf' call
    tmp.v25_1 = ArrayList_init_$Create$();
    this.t25_1.t1b(this);
  }
  protoOf(ViewContentBounds).w25 = function () {
    return this.u25_1();
  };
  protoOf(ViewContentBounds).x25 = function () {
    var result = this.w25();
    // Inline function 'kotlin.collections.isNotEmpty' call
    if (!this.v25_1.m()) {
      result = Rectangle2D_init_$Create$(result);
      // Inline function 'kotlin.collections.forEach' call
      var _iterator__ex2g4s = this.v25_1.i();
      while (_iterator__ex2g4s.j()) {
        var element = _iterator__ex2g4s.k();
        result.n1c(element.fo());
      }
    }
    return result;
  };
  protoOf(ViewContentBounds).y25 = function (drawable) {
    var oldValue = this.x25();
    this.v25_1.h(drawable);
    this.z25('ViewContentBounds.total', oldValue, this.x25());
  };
  protoOf(ViewContentBounds).a26 = function (drawable) {
    var oldValue = this.x25();
    this.v25_1.h2(drawable);
    this.z25('ViewContentBounds.total', oldValue, this.x25());
  };
  protoOf(ViewContentBounds).b26 = function (l) {
    this.t25_1.u1b(l);
  };
  protoOf(ViewContentBounds).u1b = function (l) {
    return this.b26(l);
  };
  protoOf(ViewContentBounds).c26 = function (l) {
    this.t25_1.v1b(l);
  };
  protoOf(ViewContentBounds).v1b = function (l) {
    return this.c26(l);
  };
  protoOf(ViewContentBounds).z25 = function (name, oldValue, newValue) {
    this.t25_1.nr(name, oldValue, newValue);
  };
  protoOf(ViewContentBounds).nr = function (name, oldValue, newValue) {
    var tmp = (oldValue == null ? true : isInterface(oldValue, RectangularShape)) ? oldValue : THROW_CCE();
    return this.z25(name, tmp, (newValue == null ? true : isInterface(newValue, RectangularShape)) ? newValue : THROW_CCE());
  };
  protoOf(ViewContentBounds).t1b = function (_set____db54di) {
    this.t25_1.t1b(_set____db54di);
  };
  function Companion_6() {
    Companion_instance_10 = this;
    this.d26_1 = 5.0;
    this.e26_1 = new FontImpl();
    this.f26_1 = this.e26_1.j26(FontStyle_ITALIC_getInstance());
  }
  protoOf(Companion_6).k26 = function () {
    return DrawStyleModule_getInstance().w1x_1.f1y(Companion_getInstance_33().d1y_1).c1u().z1x_1;
  };
  protoOf(Companion_6).q26 = function () {
    return this.k26().r26(DrawStyleModule_getInstance().w1x_1.f1y(Companion_getInstance_33().d1y_1).c1u().y1x_1);
  };
  var Companion_instance_10;
  function Companion_getInstance_8() {
    if (Companion_instance_10 == null)
      new Companion_6();
    return Companion_instance_10;
  }
  function updateOverlayContainer($this, current, new_0) {
    if (current == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      $this.s26_1.b24().c21(current);
    }
    if (new_0 == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      $this.s26_1.b24().b21(new_0);
    }
  }
  function update($this) {
    if (!($this.t26_1 == null)) {
      updateTopCentered($this);
    }
    if (!($this.u26_1 == null)) {
      updateBottonRight($this);
    }
    $this.s26_1.b24().k20();
  }
  function updateTopCentered($this) {
    ensureNotNull($this.t26_1).v20(new Point2D($this.s26_1.f1c() / $this.s26_1.s23().r1x() / 2 - $this.s26_1.k25(ensureNotNull($this.t26_1).fo().f1c() / 2) / $this.s26_1.s23().r1x(), 5.0));
  }
  function updateBottonRight($this) {
    ensureNotNull($this.u26_1).v20(new Point2D($this.s26_1.f1c() / $this.s26_1.s23().r1x() - $this.s26_1.k25(ensureNotNull($this.u26_1).fo().f1c()) / $this.s26_1.s23().r1x() - 5.0, $this.s26_1.h1c() / $this.s26_1.s23().r1x() - $this.s26_1.k25(ensureNotNull($this.u26_1).fo().h1c()) / $this.s26_1.s23().r1x() - 5.0));
  }
  function sam$io_antarescircuit_jabbah_base_event_PropertyChangeListener$0(function_0) {
    this.v26_1 = function_0;
  }
  protoOf(sam$io_antarescircuit_jabbah_base_event_PropertyChangeListener$0).propertyChanged = function (e) {
    return this.v26_1(e);
  };
  protoOf(sam$io_antarescircuit_jabbah_base_event_PropertyChangeListener$0).p2 = function () {
    return this.v26_1;
  };
  protoOf(sam$io_antarescircuit_jabbah_base_event_PropertyChangeListener$0).equals = function (other) {
    var tmp;
    if (!(other == null) ? isInterface(other, PropertyChangeListener) : false) {
      var tmp_0;
      if (!(other == null) ? isInterface(other, FunctionAdapter) : false) {
        tmp_0 = equals(this.p2(), other.p2());
      } else {
        tmp_0 = false;
      }
      tmp = tmp_0;
    } else {
      tmp = false;
    }
    return tmp;
  };
  protoOf(sam$io_antarescircuit_jabbah_base_event_PropertyChangeListener$0).hashCode = function () {
    return hashCode(this.p2());
  };
  function ViewDecorator$lambda$lambda(this$0) {
    return function (it) {
      var tmp;
      if (it.name === 'PROP_DIMENSION') {
        update(this$0);
        tmp = Unit_instance;
      }
      return Unit_instance;
    };
  }
  function ViewDecorator$lambda(this$0) {
    return function (it) {
      var tmp;
      if (it.name === 'PROP_CANVAS') {
        var tmp_0 = this$0.s26_1.s23();
        var tmp_1 = ViewDecorator$lambda$lambda(this$0);
        tmp_0.u1b(new sam$io_antarescircuit_jabbah_base_event_PropertyChangeListener$0(tmp_1));
        tmp = Unit_instance;
      }
      return Unit_instance;
    };
  }
  function ViewDecorator(view) {
    Companion_getInstance_8();
    this.s26_1 = view;
    this.t26_1 = null;
    this.u26_1 = null;
    this.s26_1.e24(ViewDecorator$lambda(this));
  }
  protoOf(ViewDecorator).w26 = function (value) {
    updateOverlayContainer(this, this.t26_1, value);
    this.t26_1 = value;
    update(this);
  };
  protoOf(ViewDecorator).x26 = function (value) {
    updateOverlayContainer(this, this.u26_1, value);
    this.u26_1 = value;
    update(this);
  };
  function ViewNavigator() {
  }
  function IdentityViewToModelTransform() {
  }
  protoOf(IdentityViewToModelTransform).b25 = function (x) {
    return x;
  };
  protoOf(IdentityViewToModelTransform).c25 = function (y) {
    return y;
  };
  protoOf(IdentityViewToModelTransform).d25 = function (p) {
    return p;
  };
  protoOf(IdentityViewToModelTransform).e25 = function (p, zoomFactor) {
    return p;
  };
  protoOf(IdentityViewToModelTransform).f25 = function (length) {
    return length;
  };
  protoOf(IdentityViewToModelTransform).g25 = function (p) {
    return p;
  };
  protoOf(IdentityViewToModelTransform).i25 = function (x) {
    return x;
  };
  protoOf(IdentityViewToModelTransform).j25 = function (y) {
    return y;
  };
  protoOf(IdentityViewToModelTransform).h25 = function (p, zoomFactor) {
    return p;
  };
  protoOf(IdentityViewToModelTransform).k25 = function (length) {
    return length;
  };
  protoOf(IdentityViewToModelTransform).l25 = function (p) {
    return p;
  };
  var IdentityViewToModelTransform_instance;
  function IdentityViewToModelTransform_getInstance() {
    return IdentityViewToModelTransform_instance;
  }
  function Companion_7() {
  }
  protoOf(Companion_7).k27 = function () {
    return 1.0;
  };
  var Companion_instance_11;
  function Companion_getInstance_9() {
    return Companion_instance_11;
  }
  function ZoomPan_init_$Init$($this) {
    ZoomPan_init_$Init$_0(IdentityViewToModelTransform_instance, $this);
    return $this;
  }
  function ZoomPan_init_$Create$() {
    return ZoomPan_init_$Init$(objectCreate(protoOf(ZoomPan)));
  }
  function ZoomPan_init_$Init$_0(transform, $this) {
    ZoomPan_init_$Init$_1(transform, 1.0, 0.0, 0.0, $this);
    return $this;
  }
  function ZoomPan_init_$Init$_1(transform, zoomFactor, panX, panY, $this) {
    var tmp = new Point2D(panX, panY);
    ZoomPan.call($this, transform, zoomFactor, tmp, ZoomPan$Companion$defaultDevicePixelRatio$ref(Companion_instance_11));
    return $this;
  }
  function ZoomPan$Companion$defaultDevicePixelRatio$ref(p0) {
    var l = function () {
      return p0.k27();
    };
    l.callableName = 'defaultDevicePixelRatio';
    return l;
  }
  function ZoomPan(transform, zoomFactor, panOrigin, devicePixelRatio) {
    this.j24_1 = transform;
    this.k24_1 = zoomFactor;
    this.l24_1 = panOrigin;
    this.m24_1 = devicePixelRatio;
  }
  protoOf(ZoomPan).toString = function () {
    return 'ZoomPan(transform=' + toString(this.j24_1) + ', zoomFactor=' + this.k24_1 + ', panOrigin=' + this.l24_1.toString() + ', devicePixelRatio=' + toString(this.m24_1) + ')';
  };
  protoOf(ZoomPan).hashCode = function () {
    var result = hashCode(this.j24_1);
    result = imul(result, 31) + getNumberHashCode(this.k24_1) | 0;
    result = imul(result, 31) + this.l24_1.hashCode() | 0;
    result = imul(result, 31) + hashCode(this.m24_1) | 0;
    return result;
  };
  protoOf(ZoomPan).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof ZoomPan))
      return false;
    if (!equals(this.j24_1, other.j24_1))
      return false;
    if (!equals(this.k24_1, other.k24_1))
      return false;
    if (!this.l24_1.equals(other.l24_1))
      return false;
    if (!equals(this.m24_1, other.m24_1))
      return false;
    return true;
  };
  function Companion_8() {
    Companion_instance_12 = this;
    this.l27_1 = new ZoomStrategy(ZoomStrategyType_NONE_getInstance());
    this.m27_1 = new ZoomStrategy(ZoomStrategyType_NORMAL_getInstance());
    this.n27_1 = new ZoomStrategy(ZoomStrategyType_FIT_getInstance());
    this.o27_1 = new ZoomStrategy(ZoomStrategyType_FIT_MAX_NORMAL_getInstance());
    this.p27_1 = new ZoomStrategy(ZoomStrategyType_CENTER_getInstance());
  }
  var Companion_instance_12;
  function Companion_getInstance_10() {
    if (Companion_instance_12 == null)
      new Companion_8();
    return Companion_instance_12;
  }
  function ZoomStrategy(type, zoomFactor) {
    Companion_getInstance_10();
    zoomFactor = zoomFactor === VOID ? null : zoomFactor;
    this.q27_1 = type;
    this.r27_1 = zoomFactor;
  }
  protoOf(ZoomStrategy).s27 = function (navigator) {
    return this.q27_1.v27(navigator, this.r27_1);
  };
  protoOf(ZoomStrategy).toString = function () {
    return 'ZoomStrategy(type=' + this.q27_1.toString() + ', zoomFactor=' + this.r27_1 + ')';
  };
  protoOf(ZoomStrategy).hashCode = function () {
    var result = this.q27_1.hashCode();
    result = imul(result, 31) + (this.r27_1 == null ? 0 : getNumberHashCode(this.r27_1)) | 0;
    return result;
  };
  protoOf(ZoomStrategy).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof ZoomStrategy))
      return false;
    if (!this.q27_1.equals(other.q27_1))
      return false;
    if (!equals(this.r27_1, other.r27_1))
      return false;
    return true;
  };
  function ZoomStrategyType$NORMAL() {
    ZoomStrategyType.call(this, 'NORMAL', 0);
    ZoomStrategyType_NORMAL_instance = this;
  }
  protoOf(ZoomStrategyType$NORMAL).v27 = function (navigator, zoomFactor) {
    return navigator.e27();
  };
  var ZoomStrategyType_NORMAL_instance;
  function ZoomStrategyType$FIT() {
    ZoomStrategyType.call(this, 'FIT', 1);
    ZoomStrategyType_FIT_instance = this;
  }
  protoOf(ZoomStrategyType$FIT).v27 = function (navigator, zoomFactor) {
    return navigator.g27();
  };
  var ZoomStrategyType_FIT_instance;
  function ZoomStrategyType$FIT_MAX_NORMAL() {
    ZoomStrategyType.call(this, 'FIT_MAX_NORMAL', 2);
    ZoomStrategyType_FIT_MAX_NORMAL_instance = this;
  }
  protoOf(ZoomStrategyType$FIT_MAX_NORMAL).v27 = function (navigator, zoomFactor) {
    return navigator.h27();
  };
  var ZoomStrategyType_FIT_MAX_NORMAL_instance;
  function ZoomStrategyType$CENTER() {
    ZoomStrategyType.call(this, 'CENTER', 3);
    ZoomStrategyType_CENTER_instance = this;
  }
  protoOf(ZoomStrategyType$CENTER).v27 = function (navigator, zoomFactor) {
    return navigator.d27();
  };
  var ZoomStrategyType_CENTER_instance;
  function ZoomStrategyType$VALUE() {
    ZoomStrategyType.call(this, 'VALUE', 4);
    ZoomStrategyType_VALUE_instance = this;
  }
  protoOf(ZoomStrategyType$VALUE).v27 = function (navigator, zoomFactor) {
    return navigator.f27(zoomFactor == null ? 1.0 : zoomFactor);
  };
  var ZoomStrategyType_VALUE_instance;
  function ZoomStrategyType$NONE() {
    ZoomStrategyType.call(this, 'NONE', 5);
    ZoomStrategyType_NONE_instance = this;
  }
  protoOf(ZoomStrategyType$NONE).v27 = function (navigator, zoomFactor) {
  };
  var ZoomStrategyType_NONE_instance;
  var ZoomStrategyType_entriesInitialized;
  function ZoomStrategyType_initEntries() {
    if (ZoomStrategyType_entriesInitialized)
      return Unit_instance;
    ZoomStrategyType_entriesInitialized = true;
    ZoomStrategyType_NORMAL_instance = new ZoomStrategyType$NORMAL();
    ZoomStrategyType_FIT_instance = new ZoomStrategyType$FIT();
    ZoomStrategyType_FIT_MAX_NORMAL_instance = new ZoomStrategyType$FIT_MAX_NORMAL();
    ZoomStrategyType_CENTER_instance = new ZoomStrategyType$CENTER();
    ZoomStrategyType_VALUE_instance = new ZoomStrategyType$VALUE();
    ZoomStrategyType_NONE_instance = new ZoomStrategyType$NONE();
  }
  function ZoomStrategyType(name, ordinal) {
    Enum.call(this, name, ordinal);
  }
  function ZoomStrategyType_NORMAL_getInstance() {
    ZoomStrategyType_initEntries();
    return ZoomStrategyType_NORMAL_instance;
  }
  function ZoomStrategyType_FIT_getInstance() {
    ZoomStrategyType_initEntries();
    return ZoomStrategyType_FIT_instance;
  }
  function ZoomStrategyType_FIT_MAX_NORMAL_getInstance() {
    ZoomStrategyType_initEntries();
    return ZoomStrategyType_FIT_MAX_NORMAL_instance;
  }
  function ZoomStrategyType_CENTER_getInstance() {
    ZoomStrategyType_initEntries();
    return ZoomStrategyType_CENTER_instance;
  }
  function ZoomStrategyType_VALUE_getInstance() {
    ZoomStrategyType_initEntries();
    return ZoomStrategyType_VALUE_instance;
  }
  function ZoomStrategyType_NONE_getInstance() {
    ZoomStrategyType_initEntries();
    return ZoomStrategyType_NONE_instance;
  }
  function _get__drawables__8b3f7v($this) {
    var tmp0 = $this.l28_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('_drawables', 1, tmp, DrawableBagImpl$_get__drawables_$ref_vz5go2(), null);
    return tmp0.j2();
  }
  function DrawableBagImpl$_drawables$delegate$lambda() {
    // Inline function 'kotlin.collections.mutableListOf' call
    return ArrayList_init_$Create$();
  }
  function DrawableBagImpl$_get__drawables_$ref_vz5go2() {
    return function (p0) {
      return _get__drawables__8b3f7v(p0);
    };
  }
  function DrawableBagImpl(location, useLocation, rotation) {
    location = location === VOID ? Companion_getInstance().w1a_1 : location;
    useLocation = useLocation === VOID ? false : useLocation;
    rotation = rotation === VOID ? Rotation_R0_getInstance() : rotation;
    this.i28_1 = location;
    this.j28_1 = useLocation;
    this.k28_1 = rotation;
    var tmp = this;
    tmp.l28_1 = lazy(DrawableBagImpl$_drawables$delegate$lambda);
  }
  protoOf(DrawableBagImpl).v20 = function (_set____db54di) {
    this.i28_1 = _set____db54di;
  };
  protoOf(DrawableBagImpl).jw = function () {
    return this.i28_1;
  };
  protoOf(DrawableBagImpl).t20 = function () {
    return this.j28_1;
  };
  protoOf(DrawableBagImpl).m28 = function (_set____db54di) {
    this.k28_1 = _set____db54di;
  };
  protoOf(DrawableBagImpl).w20 = function () {
    return this.k28_1;
  };
  protoOf(DrawableBagImpl).u20 = function () {
    return _get__drawables__8b3f7v(this);
  };
  protoOf(DrawableBagImpl).z20 = function () {
    _get__drawables__8b3f7v(this).a2();
    return this;
  };
  protoOf(DrawableBagImpl).a21 = function (drawable, index) {
    _get__drawables__8b3f7v(this).t3(index, drawable);
    return this;
  };
  protoOf(DrawableBagImpl).c21 = function (drawable) {
    // Inline function 'kotlin.collections.remove' call
    var this_0 = _get__drawables__8b3f7v(this);
    (isInterface(this_0, MutableCollection) ? this_0 : THROW_CCE()).h2(drawable);
    return this;
  };
  function mightRemember($this, handler) {
    $this.o28_1 = handler;
    return !(handler == null) && !$this.q28().jw().equals(Companion_getInstance().w1a_1) ? $this : handler;
  }
  function onTargetOrContainer($this, context, handler) {
    var localContext = getLocalContext($this, context);
    if (!($this.o28_1 == null)) {
      return mightRemember($this, handler(ensureNotNull($this.o28_1), localContext));
    }
    var tmp0_safe_receiver = $this.j21(context.t22_1);
    var tmp;
    if (tmp0_safe_receiver == null) {
      tmp = null;
    } else {
      // Inline function 'kotlin.let' call
      tmp = mightRemember($this, handler($this.r28(tmp0_safe_receiver, localContext), localContext));
    }
    var tmp1_elvis_lhs = tmp;
    return tmp1_elvis_lhs == null ? mightRemember($this, null) : tmp1_elvis_lhs;
  }
  function getLocalContext($this, context) {
    var tmp;
    if ($this.q28().jw().equals(Companion_getInstance().w1a_1) && $this.q28().w20().equals(Rotation_R0_getInstance())) {
      tmp = context;
    } else {
      var tmp_0 = context.u22($this.q28().o21(context.t22_1).j1h($this.q28().jw()));
      tmp = tmp_0 instanceof InputEventContext ? tmp_0 : THROW_CCE();
    }
    return tmp;
  }
  function DrawableBagInputEventHandler$mouseMoved$lambda(h, c) {
    return h.z22(c);
  }
  function DrawableBagInputEventHandler$mousePressed$lambda(h, c) {
    return h.a23(c);
  }
  function DrawableBagInputEventHandler$mouseDragged$lambda(h, c) {
    return h.b23(c);
  }
  function DrawableBagInputEventHandler$mouseReleased$lambda(h, c) {
    return h.c23(c);
  }
  function DrawableBagInputEventHandler$mouseClicked$lambda(h, c) {
    return h.y22(c);
  }
  function DrawableBagInputEventHandler() {
    InputEventHandlerAdapter.call(this);
    this.o28_1 = null;
    this.p28_1 = null;
  }
  protoOf(DrawableBagInputEventHandler).q28 = function () {
    return ensureNotNull(this.p28_1);
  };
  protoOf(DrawableBagInputEventHandler).s28 = function (context) {
    return onTargetOrContainer(this, context, DrawableBagInputEventHandler$mouseMoved$lambda);
  };
  protoOf(DrawableBagInputEventHandler).z22 = function (context) {
    return this.s28(context instanceof InputEventContext ? context : THROW_CCE());
  };
  protoOf(DrawableBagInputEventHandler).t28 = function (context) {
    return onTargetOrContainer(this, context, DrawableBagInputEventHandler$mousePressed$lambda);
  };
  protoOf(DrawableBagInputEventHandler).a23 = function (context) {
    return this.t28(context instanceof InputEventContext ? context : THROW_CCE());
  };
  protoOf(DrawableBagInputEventHandler).u28 = function (context) {
    return onTargetOrContainer(this, context, DrawableBagInputEventHandler$mouseDragged$lambda);
  };
  protoOf(DrawableBagInputEventHandler).b23 = function (context) {
    return this.u28(context instanceof InputEventContext ? context : THROW_CCE());
  };
  protoOf(DrawableBagInputEventHandler).v28 = function (context) {
    return onTargetOrContainer(this, context, DrawableBagInputEventHandler$mouseReleased$lambda);
  };
  protoOf(DrawableBagInputEventHandler).c23 = function (context) {
    return this.v28(context instanceof InputEventContext ? context : THROW_CCE());
  };
  protoOf(DrawableBagInputEventHandler).w28 = function (context) {
    return onTargetOrContainer(this, context, DrawableBagInputEventHandler$mouseClicked$lambda);
  };
  protoOf(DrawableBagInputEventHandler).y22 = function (context) {
    return this.w28(context instanceof InputEventContext ? context : THROW_CCE());
  };
  protoOf(DrawableBagInputEventHandler).x28 = function (drawableBag) {
    this.p28_1 = drawableBag;
    this.o28_1 = null;
  };
  protoOf(DrawableBagInputEventHandler).j21 = function (location) {
    return this.q28().j21(location);
  };
  protoOf(DrawableBagInputEventHandler).r28 = function (drawable, context) {
    return drawable.e20(context);
  };
  function DrawableContainerAdapter() {
  }
  protoOf(DrawableContainerAdapter).y21 = function (event) {
  };
  protoOf(DrawableContainerAdapter).z21 = function (event) {
  };
  function DrawableContainerDrawer() {
    AbstractDrawableDrawer.call(this);
  }
  protoOf(DrawableContainerDrawer).z28 = function (context, drawable) {
    this.a29(drawable, context);
    this.c29(context, drawable);
  };
  protoOf(DrawableContainerDrawer).a29 = function (drawable, context) {
    var tmp;
    if (!isInterface(drawable, Stylable)) {
      tmp = true;
    } else {
      tmp = !drawable.h29().g29_1;
    }
    if (tmp) {
      drawable.h20(context);
    }
  };
  function _get_containerListeners__ggqsul($this) {
    var tmp0 = $this.q29_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('containerListeners', 1, tmp, DrawableContainerImpl$_get_containerListeners_$ref_84y0gt(), null);
    return tmp0.j2();
  }
  function _get_inputEventHandler__jupodl($this) {
    var tmp0 = $this.s29_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('inputEventHandler', 1, tmp, DrawableContainerImpl$_get_inputEventHandler_$ref_dhj0hn(), null);
    return tmp0.j2();
  }
  function getClip($this, context) {
    var tmp;
    if ($this.o29_1) {
      var tmp_0;
      if (context.j1z_1.w1t()) {
        context.j1z_1.m1v($this.t29_1);
        tmp_0 = $this.t29_1;
      } else {
        tmp_0 = null;
      }
      tmp = tmp_0;
    } else {
      tmp = context.k1z_1;
    }
    return tmp;
  }
  function childBoundingBox($this, child) {
    var tmp;
    if ($this.t20()) {
      tmp = Rectangle2D_init_$Create$(child.fo()).l1c($this.jw());
    } else {
      tmp = child.fo();
    }
    return tmp;
  }
  function notifyDrawableAdded($this, drawable) {
    var event = new DrawableContainerEvent($this, drawable);
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = _get_containerListeners__ggqsul($this).i();
    while (_iterator__ex2g4s.j()) {
      var element = _iterator__ex2g4s.k();
      element.y21(event);
    }
  }
  function notifyDrawableRemoved($this, drawable) {
    var event = new DrawableContainerEvent($this, drawable);
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = _get_containerListeners__ggqsul($this).i();
    while (_iterator__ex2g4s.j()) {
      var element = _iterator__ex2g4s.k();
      element.z21(event);
    }
  }
  function removeDrawableImpl($this, drawable, last) {
    if (contains($this.x29(), drawable)) {
      // Inline function 'kotlin.collections.remove' call
      var this_0 = $this.x29();
      (isInterface(this_0, MutableCollection) ? this_0 : THROW_CCE()).h2(drawable);
      drawable.n20($this);
      if (last) {
        $this.y29();
      }
      $this.j20(childBoundingBox($this, drawable));
      notifyDrawableRemoved($this, drawable);
    }
  }
  function DrawableContainerImpl$children$delegate$lambda() {
    // Inline function 'kotlin.collections.mutableListOf' call
    return ArrayList_init_$Create$();
  }
  function DrawableContainerImpl$_get_children_$ref_278nyc() {
    return function (p0) {
      return p0.x29();
    };
  }
  function DrawableContainerImpl$containerListeners$delegate$lambda() {
    // Inline function 'kotlin.collections.mutableListOf' call
    return ArrayList_init_$Create$();
  }
  function DrawableContainerImpl$_get_containerListeners_$ref_84y0gt() {
    return function (p0) {
      return _get_containerListeners__ggqsul(p0);
    };
  }
  function DrawableContainerImpl$inputEventHandler$delegate$lambda(this$0) {
    return function () {
      return this$0.c2a();
    };
  }
  function DrawableContainerImpl$_get_inputEventHandler_$ref_dhj0hn() {
    return function (p0) {
      return _get_inputEventHandler__jupodl(p0);
    };
  }
  function DrawableContainerImpl(location, useLocation, visible, useViewCoordinates) {
    location = location === VOID ? Companion_getInstance().w1a_1 : location;
    useLocation = useLocation === VOID ? false : useLocation;
    visible = visible === VOID ? true : visible;
    useViewCoordinates = useViewCoordinates === VOID ? false : useViewCoordinates;
    AbstractDrawable.call(this, visible);
    this.n29_1 = useLocation;
    this.o29_1 = useViewCoordinates;
    var tmp = this;
    tmp.p29_1 = lazy(DrawableContainerImpl$children$delegate$lambda);
    var tmp_0 = this;
    tmp_0.q29_1 = lazy(DrawableContainerImpl$containerListeners$delegate$lambda);
    this.r29_1 = new DefaultDrawableDrawer();
    var tmp_1 = this;
    tmp_1.s29_1 = lazy(DrawableContainerImpl$inputEventHandler$delegate$lambda(this));
    this.t29_1 = new Rectangle2D();
    this.u29_1 = location;
    this.v29_1 = Rotation_R0_getInstance();
    this.w29_1 = new Rectangle2D();
  }
  protoOf(DrawableContainerImpl).t20 = function () {
    return this.n29_1;
  };
  protoOf(DrawableContainerImpl).x29 = function () {
    var tmp0 = this.p29_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('children', 1, tmp, DrawableContainerImpl$_get_children_$ref_278nyc(), null);
    return tmp0.j2();
  };
  protoOf(DrawableContainerImpl).v20 = function (value) {
    if (!this.u29_1.equals(value)) {
      this.u29_1 = value;
      this.y29();
    }
  };
  protoOf(DrawableContainerImpl).jw = function () {
    return this.u29_1;
  };
  protoOf(DrawableContainerImpl).u20 = function () {
    return this.x29();
  };
  protoOf(DrawableContainerImpl).w20 = function () {
    return this.v29_1;
  };
  protoOf(DrawableContainerImpl).a21 = function (drawable, index) {
    if (this.x29().n(drawable)) {
      return this;
    }
    this.x29().t3(index, drawable);
    drawable.m20(this);
    if (drawable.d20()) {
      var drawableBBox = childBoundingBox(this, drawable);
      if (this.u20().o() === 1) {
        this.w29_1.m1c(drawableBBox);
      } else {
        this.w29_1.n1c(drawableBBox);
      }
      this.j20(drawableBBox);
      this.l20();
    }
    notifyDrawableAdded(this, drawable);
    return this;
  };
  protoOf(DrawableContainerImpl).c21 = function (drawable) {
    removeDrawableImpl(this, drawable, true);
    return this;
  };
  protoOf(DrawableContainerImpl).z20 = function () {
    while (this.x29().o() > 0) {
      removeDrawableImpl(this, this.x29().l(0), this.x29().o() === 1);
    }
    return this;
  };
  protoOf(DrawableContainerImpl).fo = function () {
    return this.w29_1;
  };
  protoOf(DrawableContainerImpl).n13 = function (visitor) {
    if (visitor.hs(this)) {
      // Inline function 'kotlin.collections.iterator' call
      var _iterator__ex2g4s = this.e21();
      $l$loop: while (_iterator__ex2g4s.j()) {
        var d = _iterator__ex2g4s.k();
        if (!d.n13(visitor)) {
          break $l$loop;
        }
      }
    }
    return visitor.ks(this);
  };
  protoOf(DrawableContainerImpl).h20 = function (context) {
    this.d2a(context, this.r29_1);
  };
  protoOf(DrawableContainerImpl).d2a = function (context, drawer) {
    var tmp;
    if (this.d20()) {
      // Inline function 'kotlin.collections.isNotEmpty' call
      tmp = !this.x29().m();
    } else {
      tmp = false;
    }
    if (tmp) {
      var clip = getClip(this, context);
      var oldModelClip = context.k1z_1;
      if (this.t20()) {
        context.j1z_1.l1d(this.jw().kn_1, this.jw().ln_1);
        if (!(clip == null)) {
          clip = new Rectangle2D(clip.p1a() - this.jw().kn_1, clip.q1a() - this.jw().ln_1, clip.f1c(), clip.h1c());
          if (!this.o29_1 && !(context.k1z_1 == null)) {
            context.k1z_1 = clip;
          }
        }
      }
      // Inline function 'kotlin.collections.forEach' call
      var _iterator__ex2g4s = this.e2a().i();
      while (_iterator__ex2g4s.j()) {
        var element = _iterator__ex2g4s.k();
        if (element.d20()) {
          if (clip == null || element.ro(clip)) {
            drawer.z28(context, element);
          }
        }
      }
      if (this.t20()) {
        context.j1z_1.l1d(-this.jw().kn_1, -this.jw().ln_1);
        DrawModule_getInstance().q2a(this, context.j1z_1);
      } else {
        DrawModule_getInstance().q2a(this, context.j1z_1);
      }
      DrawModule_getInstance().r2a(this.jw(), context);
      context.k1z_1 = oldModelClip;
    }
  };
  protoOf(DrawableContainerImpl).e20 = function (context) {
    _get_inputEventHandler__jupodl(this).x28(this);
    return _get_inputEventHandler__jupodl(this);
  };
  protoOf(DrawableContainerImpl).e2a = function () {
    return asReversed(this.x29());
  };
  protoOf(DrawableContainerImpl).o20 = function (context) {
    if (this.t20()) {
      var localContext = context.u22(context.t22_1.j1h(this.jw()));
      var tmp0_safe_receiver = this.j21(context.t22_1);
      var tmp1_elvis_lhs = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.o20(localContext);
      return tmp1_elvis_lhs == null ? protoOf(AbstractDrawable).o20.call(this, localContext) : tmp1_elvis_lhs;
    }
    var tmp2_safe_receiver = this.j21(context.t22_1);
    var tmp3_elvis_lhs = tmp2_safe_receiver == null ? null : tmp2_safe_receiver.o20(context);
    return tmp3_elvis_lhs == null ? protoOf(AbstractDrawable).o20.call(this, context) : tmp3_elvis_lhs;
  };
  protoOf(DrawableContainerImpl).p21 = function (drawableDrawer) {
    this.r29_1 = drawableDrawer;
  };
  protoOf(DrawableContainerImpl).q21 = function (listener) {
    if (!_get_containerListeners__ggqsul(this).n(listener)) {
      _get_containerListeners__ggqsul(this).h(listener);
    }
  };
  protoOf(DrawableContainerImpl).r21 = function (listener) {
    _get_containerListeners__ggqsul(this).h2(listener);
  };
  protoOf(DrawableContainerImpl).s21 = function (drawable, region) {
    if (this.t20()) {
      this.j20(Rectangle2D_init_$Create$(region).l1c(this.jw()));
    } else {
      this.j20(region);
    }
  };
  protoOf(DrawableContainerImpl).t21 = function (drawable) {
    this.s2a();
  };
  protoOf(DrawableContainerImpl).u21 = function (drawable) {
    this.y29();
    if (!this.fo().qo(drawable.fo())) {
      this.l20();
    }
  };
  protoOf(DrawableContainerImpl).c2a = function () {
    return new DrawableBagInputEventHandler();
  };
  protoOf(DrawableContainerImpl).y29 = function () {
    var tmp0 = this.x29();
    var tmp$ret$0;
    $l$block: {
      // Inline function 'kotlin.collections.firstOrNull' call
      var _iterator__ex2g4s = tmp0.i();
      while (_iterator__ex2g4s.j()) {
        var element = _iterator__ex2g4s.k();
        if (element.d20()) {
          tmp$ret$0 = element;
          break $l$block;
        }
      }
      tmp$ret$0 = null;
    }
    var tmp0_safe_receiver = tmp$ret$0;
    var tmp;
    if (tmp0_safe_receiver == null) {
      tmp = null;
    } else {
      // Inline function 'kotlin.let' call
      this.w29_1.m1c(childBoundingBox(this, tmp0_safe_receiver));
      tmp = Unit_instance;
    }
    if (tmp == null) {
      this.w29_1.i1c(0.0, 0.0, 0.0, 0.0);
    }
    // Inline function 'kotlin.collections.filter' call
    var tmp0_0 = this.x29();
    // Inline function 'kotlin.collections.filterTo' call
    var destination = ArrayList_init_$Create$();
    var _iterator__ex2g4s_0 = tmp0_0.i();
    while (_iterator__ex2g4s_0.j()) {
      var element_0 = _iterator__ex2g4s_0.k();
      if (element_0.d20()) {
        destination.h(element_0);
      }
    }
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s_1 = destination.i();
    while (_iterator__ex2g4s_1.j()) {
      var element_1 = _iterator__ex2g4s_1.k();
      this.w29_1.n1c(childBoundingBox(this, element_1));
    }
  };
  function DrawableProperty(initialValue, afterSet, afterChange) {
    afterSet = afterSet === VOID ? null : afterSet;
    afterChange = afterChange === VOID ? null : afterChange;
    AbstractDrawableProperty.call(this, initialValue, afterSet, afterChange);
  }
  function DrawableGeometryProperty$_init_$lambda_w78xzu(it) {
    it.l20();
    return Unit_instance;
  }
  function DrawableGeometryProperty(initialValue, afterSet, afterChange) {
    afterSet = afterSet === VOID ? null : afterSet;
    var tmp;
    if (afterChange === VOID) {
      tmp = DrawableGeometryProperty$_init_$lambda_w78xzu;
    } else {
      tmp = afterChange;
    }
    afterChange = tmp;
    AbstractDrawableProperty.call(this, initialValue, afterSet, afterChange);
  }
  function AbstractDrawableProperty(initialValue, afterSet, afterChange) {
    afterSet = afterSet === VOID ? null : afterSet;
    afterChange = afterChange === VOID ? null : afterChange;
    this.v2a_1 = afterSet;
    this.w2a_1 = afterChange;
    this.x2a_1 = initialValue;
  }
  protoOf(AbstractDrawableProperty).y2a = function (thisRef, property) {
    return this.x2a_1;
  };
  protoOf(AbstractDrawableProperty).wf = function (thisRef, property) {
    return this.y2a((!(thisRef == null) ? isInterface(thisRef, Drawable) : false) ? thisRef : THROW_CCE(), property);
  };
  protoOf(AbstractDrawableProperty).z2a = function (thisRef, property, value) {
    if (!equals(this.x2a_1, value)) {
      thisRef.i20();
      this.x2a_1 = value;
      var tmp0_safe_receiver = this.v2a_1;
      if (tmp0_safe_receiver == null)
        null;
      else
        tmp0_safe_receiver();
      thisRef.i20();
      thisRef.k20();
      var tmp1_safe_receiver = this.w2a_1;
      if (tmp1_safe_receiver == null)
        null;
      else
        tmp1_safe_receiver(thisRef);
    }
  };
  protoOf(AbstractDrawableProperty).yf = function (thisRef, property, value) {
    return this.z2a((!(thisRef == null) ? isInterface(thisRef, Drawable) : false) ? thisRef : THROW_CCE(), property, value);
  };
  function UnzoomableContainer() {
    DrawableContainerImpl.call(this);
    this.n2b_1 = null;
  }
  protoOf(UnzoomableContainer).o2b = function (value) {
    this.n2b_1 = value;
    var iter = this.d21();
    while (iter.j()) {
      iter.k().o2b(value);
    }
  };
  protoOf(UnzoomableContainer).p2b = function (drawable, index) {
    protoOf(DrawableContainerImpl).a21.call(this, drawable, index);
    drawable.o2b(this.n2b_1);
    return this;
  };
  protoOf(UnzoomableContainer).a21 = function (drawable, index) {
    return this.p2b(isInterface(drawable, Unzoomable) ? drawable : THROW_CCE(), index);
  };
  function _get_listeners__760gzy($this) {
    var tmp0 = $this.z29_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('listeners', 1, tmp, AbstractDrawable$_get_listeners_$ref_lumzwd(), null);
    return tmp0.j2();
  }
  function DrawableOwner(owner, inner) {
    this.q2b_1 = owner;
    this.r2b_1 = inner;
    this.r2b_1.f20(this);
  }
  protoOf(DrawableOwner).gs = function () {
    this.r2b_1.g20(this);
  };
  protoOf(DrawableOwner).c22 = function (event) {
    this.q2b_1.i20();
  };
  protoOf(DrawableOwner).d22 = function (event) {
    this.q2b_1.s2a();
  };
  protoOf(DrawableOwner).e22 = function (event) {
    this.q2b_1.l20();
  };
  function AbstractDrawable$listeners$delegate$lambda() {
    // Inline function 'kotlin.collections.mutableListOf' call
    return ArrayList_init_$Create$();
  }
  function AbstractDrawable$_get_listeners_$ref_lumzwd() {
    return function (p0) {
      return _get_listeners__760gzy(p0);
    };
  }
  function AbstractDrawable(visible) {
    visible = visible === VOID ? true : visible;
    var tmp = this;
    tmp.z29_1 = lazy(AbstractDrawable$listeners$delegate$lambda);
    this.a2a_1 = null;
    this.b2a_1 = visible;
  }
  protoOf(AbstractDrawable).b20 = function () {
    return this.a2a_1;
  };
  protoOf(AbstractDrawable).c20 = function (value) {
    if (!(value === this.d20())) {
      this.i20();
      this.b2a_1 = value;
      this.l20();
      this.k20();
    }
  };
  protoOf(AbstractDrawable).d20 = function () {
    return this.b2a_1;
  };
  protoOf(AbstractDrawable).gs = function () {
  };
  protoOf(AbstractDrawable).n13 = function (visitor) {
    return visitor.is(this);
  };
  protoOf(AbstractDrawable).e20 = function (context) {
    return Companion_getInstance_4().w22_1;
  };
  protoOf(AbstractDrawable).f20 = function (listener) {
    if (!_get_listeners__760gzy(this).n(listener)) {
      _get_listeners__760gzy(this).h(listener);
    }
  };
  protoOf(AbstractDrawable).g20 = function (listener) {
    _get_listeners__760gzy(this).h2(listener);
  };
  protoOf(AbstractDrawable).i20 = function () {
    this.j20(this.fo());
  };
  protoOf(AbstractDrawable).j20 = function (region) {
    var tmp0_safe_receiver = this.b20();
    if (tmp0_safe_receiver == null)
      null;
    else {
      tmp0_safe_receiver.s21(this, region);
    }
    // Inline function 'kotlin.collections.isNotEmpty' call
    if (!_get_listeners__760gzy(this).m()) {
      var event = new DrawableEvent(this, region);
      // Inline function 'kotlin.collections.forEach' call
      var _iterator__ex2g4s = _get_listeners__760gzy(this).i();
      while (_iterator__ex2g4s.j()) {
        var element = _iterator__ex2g4s.k();
        element.c22(event);
      }
    }
  };
  protoOf(AbstractDrawable).k20 = function () {
    this.s2a();
  };
  protoOf(AbstractDrawable).m20 = function (container) {
    this.a2a_1 = container;
  };
  protoOf(AbstractDrawable).n20 = function (container) {
    this.a2a_1 = null;
  };
  protoOf(AbstractDrawable).o20 = function (context) {
    return null;
  };
  protoOf(AbstractDrawable).p20 = function (x, y) {
    return null;
  };
  protoOf(AbstractDrawable).l20 = function () {
    var tmp0_safe_receiver = this.b20();
    if (tmp0_safe_receiver == null)
      null;
    else {
      tmp0_safe_receiver.u21(this);
    }
    // Inline function 'kotlin.collections.isNotEmpty' call
    if (!_get_listeners__760gzy(this).m()) {
      var event = DrawableEvent_init_$Create$(this);
      // Inline function 'kotlin.collections.forEach' call
      var _iterator__ex2g4s = _get_listeners__760gzy(this).i();
      while (_iterator__ex2g4s.j()) {
        var element = _iterator__ex2g4s.k();
        element.e22(event);
      }
    }
  };
  protoOf(AbstractDrawable).s2a = function () {
    var tmp0_safe_receiver = this.b20();
    if (tmp0_safe_receiver == null)
      null;
    else {
      tmp0_safe_receiver.t21(this);
    }
    // Inline function 'kotlin.collections.isNotEmpty' call
    if (!_get_listeners__760gzy(this).m()) {
      var event = DrawableEvent_init_$Create$(this);
      // Inline function 'kotlin.collections.forEach' call
      var _iterator__ex2g4s = _get_listeners__760gzy(this).i();
      while (_iterator__ex2g4s.j()) {
        var element = _iterator__ex2g4s.k();
        element.d22(event);
      }
    }
  };
  protoOf(AbstractDrawable).s2b = function (context, shape, fillColor) {
    if (!(fillColor == null)) {
      context.j1z_1.b1u(fillColor);
      context.j1z_1.k1v(shape);
    }
  };
  protoOf(AbstractDrawable).t2b = function (context, shape, strokeColor, stroke) {
    if (!(stroke == null) && !(strokeColor == null)) {
      context.j1z_1.b1u(strokeColor);
      context.j1z_1.e1u(stroke);
      context.j1z_1.j1v(shape);
    }
  };
  protoOf(AbstractDrawable).u2b = function (title, text, subText) {
    return buildToolTipText(title, text, subText, true);
  };
  protoOf(AbstractDrawable).t2a = function (relativeLocation) {
    return this.u2a(relativeLocation.kn_1, relativeLocation.ln_1);
  };
  protoOf(AbstractDrawable).u2a = function (relX, relY) {
    var x = relX;
    var y = relY;
    var p = this.b20();
    while (!(p == null)) {
      x = x + p.jw().kn_1;
      y = y + p.jw().ln_1;
      p = p.b20();
    }
    return new Point2D(x, y);
  };
  function AbstractDrawableDrawer() {
    this.b29_1 = null;
  }
  protoOf(AbstractDrawableDrawer).i29 = function (_set____db54di) {
    this.b29_1 = _set____db54di;
  };
  protoOf(AbstractDrawableDrawer).j29 = function () {
    return this.b29_1;
  };
  protoOf(AbstractDrawableDrawer).c29 = function (context, drawable) {
    var tmp0_safe_receiver = this.j29();
    if (tmp0_safe_receiver == null)
      null;
    else {
      tmp0_safe_receiver.z28(context, drawable);
    }
  };
  function AbstractRectangle_init_$Init$(x, y, w, h, $this) {
    AbstractRectangle.call($this, new Rectangle2D(x, y, w, h));
    return $this;
  }
  function AbstractRectangle_init_$Init$_0($this) {
    AbstractRectangle_init_$Init$(0.0, 0.0, 0.0, 0.0, $this);
    return $this;
  }
  function AbstractRectangle(shape) {
    AbstractDrawable.call(this);
    this.y2b_1 = shape;
  }
  protoOf(AbstractRectangle).v20 = function (value) {
    this.z2b(value.kn_1, value.ln_1, this.f1c(), this.h1c());
  };
  protoOf(AbstractRectangle).jw = function () {
    return new Point2D(this.p1a(), this.q1a());
  };
  protoOf(AbstractRectangle).fo = function () {
    return new Rectangle2D(this.a2c().p1a() - this.b2c(), this.a2c().q1a() - this.b2c(), this.a2c().f1c() + 2 * this.b2c(), this.a2c().h1c() + 2 * this.b2c());
  };
  protoOf(AbstractRectangle).go = function (x, y) {
    return this.y2b_1.go(x, y);
  };
  protoOf(AbstractRectangle).a2c = function () {
    return this.y2b_1;
  };
  protoOf(AbstractRectangle).f1c = function () {
    return this.a2c().f1c();
  };
  protoOf(AbstractRectangle).h1c = function () {
    return this.a2c().h1c();
  };
  protoOf(AbstractRectangle).z2b = function (x, y, w, h) {
    this.i20();
    this.y2b_1.i1c(x, y, w, h);
    this.i20();
    this.l20();
  };
  protoOf(AbstractRectangle).ho = function (x, y, w, h) {
    return this.y2b_1.ho(x, y, w, h);
  };
  protoOf(AbstractRectangle).c2c = function (context, borderColor, fillColor, stroke) {
    this.d2c(context, this.y2b_1, borderColor, fillColor, stroke);
  };
  protoOf(AbstractRectangle).d2c = function (context, shape, borderColor, fillColor, stroke) {
    if (!(fillColor == null)) {
      context.j1z_1.b1u(fillColor);
      context.j1z_1.k1v(shape);
    }
    if (!(borderColor == null) && !(stroke == null)) {
      context.j1z_1.e1u(stroke);
      context.j1z_1.b1u(borderColor);
      context.j1z_1.j1v(shape);
    }
  };
  protoOf(AbstractRectangle).e2c = function (context, x, y, w, h, borderColor, fillColor, stroke) {
    this.f2c(context, numberToInt(x), numberToInt(y), numberToInt(w), numberToInt(h), borderColor, fillColor, stroke);
  };
  protoOf(AbstractRectangle).f2c = function (context, x, y, w, h, borderColor, fillColor, stroke) {
    if (!(fillColor == null)) {
      context.j1z_1.b1u(fillColor);
      context.j1z_1.y1u(x, y, w, h);
    }
    if (!(borderColor == null) && !(stroke == null)) {
      context.j1z_1.e1u(stroke);
      context.j1z_1.b1u(borderColor);
      context.j1z_1.u1u(x, y, w, h);
    }
  };
  function AbstractRectangularUnzoomable(halfSize, location) {
    location = location === VOID ? Companion_getInstance().w1a_1 : location;
    AbstractDrawable.call(this);
    this.l2c_1 = ZoomPan_init_$Create$();
    this.m2c_1 = location;
    this.n2c_1 = halfSize;
    this.o2c_1 = new Rectangle2D();
  }
  protoOf(AbstractRectangularUnzoomable).o2b = function (_set____db54di) {
    this.l2c_1 = _set____db54di;
  };
  protoOf(AbstractRectangularUnzoomable).h24 = function () {
    return this.l2c_1;
  };
  protoOf(AbstractRectangularUnzoomable).v20 = function (value) {
    this.i20();
    this.m2c_1 = value;
    this.i20();
    this.l20();
  };
  protoOf(AbstractRectangularUnzoomable).jw = function () {
    return this.m2c_1;
  };
  protoOf(AbstractRectangularUnzoomable).p2c = function (value) {
    this.i20();
    this.n2c_1 = value;
    this.i20();
    this.l20();
  };
  protoOf(AbstractRectangularUnzoomable).f1c = function () {
    return 2 * this.n2c_1;
  };
  protoOf(AbstractRectangularUnzoomable).h1c = function () {
    return 2 * this.n2c_1;
  };
  protoOf(AbstractRectangularUnzoomable).q2c = function () {
    return ensureNotNull(this.h24()).j24_1.g25(this.m2c_1).k1h(ensureNotNull(this.h24()).m24_1());
  };
  protoOf(AbstractRectangularUnzoomable).fo = function () {
    this.o2c_1.i1c(this.m2c_1.kn_1 - this.n2c_1 / ensureNotNull(this.h24()).k24_1 - this.b2c(), this.m2c_1.ln_1 - this.n2c_1 / ensureNotNull(this.h24()).k24_1 - this.b2c(), 2 * (this.n2c_1 / ensureNotNull(this.h24()).k24_1 + this.b2c()), 2 * (this.n2c_1 / ensureNotNull(this.h24()).k24_1 + this.b2c()));
    return this.o2c_1;
  };
  protoOf(AbstractRectangularUnzoomable).go = function (x, y) {
    return x >= this.m2c_1.kn_1 - this.n2c_1 / ensureNotNull(this.h24()).k24_1 && x <= this.m2c_1.kn_1 + this.n2c_1 / ensureNotNull(this.h24()).k24_1 && y >= this.m2c_1.ln_1 - this.n2c_1 / ensureNotNull(this.h24()).k24_1 && y <= this.m2c_1.ln_1 + this.n2c_1 / ensureNotNull(this.h24()).k24_1;
  };
  protoOf(AbstractRectangularUnzoomable).r2c = function () {
    var p = this.q2c();
    return new Rectangle2D(p.kn_1 - this.n2c_1, p.ln_1 - this.n2c_1, 2 * this.n2c_1, 2 * this.n2c_1);
  };
  function AbstractStyledDrawable_init_$Init$(styleType, styleProvider, $this) {
    AbstractStyledDrawable.call($this, new StylableImpl(VOID, styleType, styleProvider));
    return $this;
  }
  function AbstractStyledDrawable$lambda(this$0) {
    return function () {
      this$0.i20();
      return Unit_instance;
    };
  }
  function AbstractStyledDrawable(stylable) {
    AbstractDrawable.call(this);
    this.v2c_1 = stylable;
    stylable.w2c(AbstractStyledDrawable$lambda(this));
  }
  protoOf(AbstractStyledDrawable).w2c = function (_set____db54di) {
    this.v2c_1.w2c(_set____db54di);
  };
  protoOf(AbstractStyledDrawable).x2c = function () {
    return this.v2c_1.x2c();
  };
  protoOf(AbstractStyledDrawable).c1u = function () {
    return this.v2c_1.c1u();
  };
  protoOf(AbstractStyledDrawable).y2c = function () {
    return this.v2c_1.y2c();
  };
  protoOf(AbstractStyledDrawable).z2c = function () {
    return this.v2c_1.z2c();
  };
  protoOf(AbstractStyledDrawable).a2d = function () {
    return this.v2c_1.a2d();
  };
  protoOf(AbstractStyledDrawable).b2d = function () {
    return this.v2c_1.b2d();
  };
  protoOf(AbstractStyledDrawable).l1u = function () {
    return this.v2c_1.l1u();
  };
  protoOf(AbstractStyledDrawable).c2d = function (_set____db54di) {
    this.v2c_1.c2d(_set____db54di);
  };
  protoOf(AbstractStyledDrawable).h29 = function () {
    return this.v2c_1.h29();
  };
  protoOf(AbstractStyledDrawable).d2d = function () {
    return this.v2c_1.d2d();
  };
  protoOf(AbstractStyledDrawable).e2d = function (_set____db54di) {
    this.v2c_1.e2d(_set____db54di);
  };
  protoOf(AbstractStyledDrawable).f2d = function () {
    return this.v2c_1.f2d();
  };
  protoOf(AbstractStyledDrawable).g2d = function (_set____db54di) {
    this.v2c_1.g2d(_set____db54di);
  };
  protoOf(AbstractStyledDrawable).h2d = function () {
    return this.v2c_1.h2d();
  };
  protoOf(AbstractStyledDrawable).i2d = function () {
    return this.v2c_1.i2d();
  };
  protoOf(AbstractStyledDrawable).j2d = function (_set____db54di) {
    this.v2c_1.j2d(_set____db54di);
  };
  protoOf(AbstractStyledDrawable).k2d = function () {
    return this.v2c_1.k2d();
  };
  protoOf(AbstractStyledDrawable).l2d = function (_set____db54di) {
    this.v2c_1.l2d(_set____db54di);
  };
  protoOf(AbstractStyledDrawable).m2d = function () {
    return this.v2c_1.m2d();
  };
  protoOf(AbstractStyledDrawable).n2d = function (_set____db54di) {
    this.v2c_1.n2d(_set____db54di);
  };
  protoOf(AbstractStyledDrawable).o2d = function (_set____db54di) {
    this.v2c_1.o2d(_set____db54di);
  };
  protoOf(AbstractStyledDrawable).p2d = function () {
    return this.v2c_1.p2d();
  };
  function Companion_9() {
    this.q2d_1 = 8.0;
    this.r2d_1 = 15.0;
    this.s2d_1 = 5.0;
    this.t2d_1 = 15.0;
    this.u2d_1 = 50.0;
    this.v2d_1 = 27.5;
  }
  var Companion_instance_13;
  function Companion_getInstance_11() {
    return Companion_instance_13;
  }
  function _get_width__9isoj9($this) {
    // Inline function 'kotlin.math.max' call
    var b = $this.a2e_1.f1c() + 2 * 8.0;
    return Math.max(50.0, b);
  }
  function _get_height__jyis70($this) {
    return $this.a2e_1.h1c() + 2 * 8.0 + 15.0;
  }
  function _get_wideWidth__86esji($this) {
    return _get_width__9isoj9($this) - 27.5;
  }
  function calculateContentLocation($this, position) {
    var tmp;
    if (position.e2e_1) {
      var tmp_0;
      if (position.f2e_1) {
        tmp_0 = new Point2D(-27.5 + 8.0, 15.0 + 8.0);
      } else {
        tmp_0 = new Point2D(-_get_wideWidth__86esji($this) + 8.0, 15.0 + 8.0);
      }
      tmp = tmp_0;
    } else {
      var tmp_1;
      if (position.f2e_1) {
        tmp_1 = new Point2D(-27.5 + 8.0, -_get_height__jyis70($this) + 8.0);
      } else {
        tmp_1 = new Point2D(-_get_wideWidth__86esji($this) + 8.0, -_get_height__jyis70($this) + 8.0);
      }
      tmp = tmp_1;
    }
    return tmp;
  }
  function createPath($this, position) {
    var tmp;
    if (position.e2e_1) {
      var tmp_0;
      if (position.f2e_1) {
        tmp_0 = createBelowRightPath($this);
      } else {
        tmp_0 = createBelowLeftPath($this);
      }
      tmp = tmp_0;
    } else {
      var tmp_1;
      if (position.f2e_1) {
        tmp_1 = createAboveRightPath($this);
      } else {
        tmp_1 = createAboveLeftPath($this);
      }
      tmp = tmp_1;
    }
    return tmp;
  }
  function createBelowRightPath($this) {
    return System_getInstance().cm().wn(0, 0).yn(15.0 / 2, 15.0).yn(_get_wideWidth__86esji($this) - 5.0, 15.0).bo(_get_wideWidth__86esji($this), 15.0, _get_wideWidth__86esji($this), 15.0 + 5.0).yn(_get_wideWidth__86esji($this), _get_height__jyis70($this) - 5.0).bo(_get_wideWidth__86esji($this), _get_height__jyis70($this), _get_wideWidth__86esji($this) - 5.0, _get_height__jyis70($this)).yn(-27.5 + 5.0, _get_height__jyis70($this)).bo(-27.5, _get_height__jyis70($this), -27.5, _get_height__jyis70($this) - 5.0).yn(-27.5, 15.0 + 5.0).bo(-27.5, 15.0, -27.5 + 5.0, 15.0).yn(-15.0 / 2, 15.0).do();
  }
  function createBelowLeftPath($this) {
    return System_getInstance().cm().wn(0, 0).yn(15.0 / 2, 15.0).yn(27.5 - 5.0, 15.0).bo(27.5, 15.0, 27.5, 15.0 + 5.0).yn(27.5, _get_height__jyis70($this) - 5.0).bo(27.5, _get_height__jyis70($this), 27.5 - 5.0, _get_height__jyis70($this)).yn(-_get_wideWidth__86esji($this) + 5.0, _get_height__jyis70($this)).bo(-_get_wideWidth__86esji($this), _get_height__jyis70($this), -_get_wideWidth__86esji($this), _get_height__jyis70($this) - 5.0).yn(-_get_wideWidth__86esji($this), 15.0 + 5.0).bo(-_get_wideWidth__86esji($this), 15.0, -_get_wideWidth__86esji($this) + 5.0, 15.0).yn(-15.0 / 2, 15.0).do();
  }
  function createAboveRightPath($this) {
    return System_getInstance().cm().wn(0, 0).yn(-15.0 / 2, -15.0).yn(-27.5 + 5.0, -15.0).bo(-27.5, -15.0, -27.5, -15.0 - 5.0).yn(-27.5, -_get_height__jyis70($this) + 5.0).bo(-27.5, -_get_height__jyis70($this), -27.5 + 5.0, -_get_height__jyis70($this)).yn(_get_wideWidth__86esji($this) - 5.0, -_get_height__jyis70($this)).bo(_get_wideWidth__86esji($this), -_get_height__jyis70($this), _get_wideWidth__86esji($this), -_get_height__jyis70($this) + 5.0).yn(_get_wideWidth__86esji($this), -15.0 - 5.0).bo(_get_wideWidth__86esji($this), -15.0, _get_wideWidth__86esji($this) - 5.0, -15.0).yn(15.0 / 2, -15.0).do();
  }
  function createAboveLeftPath($this) {
    return System_getInstance().cm().wn(0, 0).yn(-15.0 / 2, -15.0).yn(-_get_wideWidth__86esji($this) + 5.0, -15.0).bo(-_get_wideWidth__86esji($this), -15.0, -_get_wideWidth__86esji($this), -15.0 - 5.0).yn(-_get_wideWidth__86esji($this), -_get_height__jyis70($this) + 5.0).bo(-_get_wideWidth__86esji($this), -_get_height__jyis70($this), -_get_wideWidth__86esji($this) + 5.0, -_get_height__jyis70($this)).yn(27.5 - 5.0, -_get_height__jyis70($this)).bo(27.5, -_get_height__jyis70($this), 27.5, -_get_height__jyis70($this) + 5.0).yn(27.5, -15.0 - 5.0).bo(27.5, -15.0, 27.5 - 5.0, -15.0).yn(15.0 / 2, -15.0).do();
  }
  function ArrowBubble(content, position, styleType, styleProvider) {
    styleType = styleType === VOID ? Companion_getInstance_33().e1y_1 : styleType;
    styleProvider = styleProvider === VOID ? DrawStyleModule_getInstance().w1x_1 : styleProvider;
    AbstractStyledDrawable_init_$Init$(styleType, styleProvider, this);
    this.a2e_1 = content;
    this.b2e_1 = position;
    this.c2e_1 = createPath(this, this.b2e_1);
    this.a2e_1.v20(calculateContentLocation(this, this.b2e_1));
    new DrawableOwner(this, this.a2e_1);
  }
  protoOf(ArrowBubble).fo = function () {
    return Rectangle2D_init_$Create$(this.c2e_1.fo()).p1c(this.d2d().l1u().f1u_1).l1c(this.b2e_1.d2e_1);
  };
  protoOf(ArrowBubble).h20 = function (context) {
    // Inline function 'io.antarescircuit.jabbah.draw.DrawContext.translated' call
    var d = this.b2e_1.d2e_1;
    context.j1z_1.l1d(d.kn_1, d.ln_1);
    context.j1z_1.b1u(this.d2d().c1u().y1x_1);
    context.j1z_1.k1v(this.c2e_1);
    context.j1z_1.b1u(this.d2d().c1u().x1x_1);
    context.j1z_1.e1u(this.d2d().l1u());
    context.j1z_1.j1v(this.c2e_1);
    context.j1z_1.b1u(this.d2d().c1u().z1x_1);
    context.j1z_1.m1u(this.d2d().b2d());
    this.a2e_1.h20(context);
    context.j1z_1.l1d(-d.kn_1, -d.ln_1);
  };
  protoOf(ArrowBubble).go = function (x, y) {
    return this.c2e_1.go(x - this.b2e_1.d2e_1.kn_1, y - this.b2e_1.d2e_1.ln_1);
  };
  function ArrowBubblePosition(location, belowLocation, rightOfLocation) {
    this.d2e_1 = location;
    this.e2e_1 = belowLocation;
    this.f2e_1 = rightOfLocation;
  }
  protoOf(ArrowBubblePosition).toString = function () {
    return 'ArrowBubblePosition(location=' + this.d2e_1.toString() + ', belowLocation=' + this.e2e_1 + ', rightOfLocation=' + this.f2e_1 + ')';
  };
  protoOf(ArrowBubblePosition).hashCode = function () {
    var result = this.d2e_1.hashCode();
    result = imul(result, 31) + getBooleanHashCode(this.e2e_1) | 0;
    result = imul(result, 31) + getBooleanHashCode(this.f2e_1) | 0;
    return result;
  };
  protoOf(ArrowBubblePosition).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof ArrowBubblePosition))
      return false;
    if (!this.d2e_1.equals(other.d2e_1))
      return false;
    if (!(this.e2e_1 === other.e2e_1))
      return false;
    if (!(this.f2e_1 === other.f2e_1))
      return false;
    return true;
  };
  function positionHorizontally($this, content, describable, view) {
    var width = arrowBubbleWidth($this, content.f1c());
    var centerXView = view.i25(describable.x1c());
    var overlapRight = coerceAtLeast(centerXView + width - 27.5 - view.f1c(), 0.0);
    // Inline function 'kotlin.math.abs' call
    var x = coerceAtMost(centerXView - width + 27.5, 0.0);
    var overlapLeft = Math.abs(x);
    var rightOfLocation = overlapRight <= 0.0 || overlapRight <= overlapLeft;
    var positionX = describable.x1c();
    if (rightOfLocation) {
      if (overlapRight > 0) {
        positionX = positionX - (overlapRight + 5);
      }
    } else {
      if (overlapLeft > 0) {
        positionX = positionX + (overlapLeft + 5);
      }
    }
    return new PositionInfo(positionX, rightOfLocation);
  }
  function positionY($this, content, describable, view, preferredBelow) {
    var tmp;
    if (preferredBelow) {
      tmp = preferredBelowPositionY($this, content, describable, view);
    } else {
      tmp = preferredAbovePositionY($this, content, describable, view);
    }
    return tmp;
  }
  function preferredBelowPositionY($this, content, describable, view) {
    var height = arrowBubbleHeight($this, content.h1c());
    var tmp;
    if (view.j25(describable.c1d()) + 10 + height <= view.h1c()) {
      tmp = describable.c1d() + 10;
    } else {
      tmp = describable.a1d() - 10;
    }
    return tmp;
  }
  function preferredAbovePositionY($this, content, describable, view) {
    var height = arrowBubbleHeight($this, content.h1c());
    var tmp;
    if (view.j25(describable.a1d()) - 10 - height >= 0) {
      tmp = describable.a1d() - 10;
    } else {
      tmp = describable.c1d() + 10;
    }
    return tmp;
  }
  function arrowBubbleWidth($this, contentWidth) {
    return contentWidth + 2 * 8.0;
  }
  function arrowBubbleHeight($this, contentHeight) {
    return contentHeight + 2 * 8.0 + 15.0;
  }
  function PositionInfo(coordinate, defaultPosition) {
    this.g2e_1 = coordinate;
    this.h2e_1 = defaultPosition;
  }
  protoOf(PositionInfo).toString = function () {
    return 'PositionInfo(coordinate=' + this.g2e_1 + ', defaultPosition=' + this.h2e_1 + ')';
  };
  protoOf(PositionInfo).hashCode = function () {
    var result = getNumberHashCode(this.g2e_1);
    result = imul(result, 31) + getBooleanHashCode(this.h2e_1) | 0;
    return result;
  };
  protoOf(PositionInfo).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof PositionInfo))
      return false;
    if (!equals(this.g2e_1, other.g2e_1))
      return false;
    if (!(this.h2e_1 === other.h2e_1))
      return false;
    return true;
  };
  function ArrowBubblePositioner() {
    this.i2e_1 = 10;
    this.j2e_1 = 5;
  }
  protoOf(ArrowBubblePositioner).k2e = function (content, describable, view, preferredBelow) {
    var horizontal = positionHorizontally(this, content, describable, view);
    var positionY_0 = positionY(this, content, describable, view, preferredBelow);
    var belowLocation = positionY_0 > describable.c1d();
    return new ArrowBubblePosition(view.l25(new Point2D(horizontal.g2e_1, positionY_0)), belowLocation, horizontal.h2e_1);
  };
  var ArrowBubblePositioner_instance;
  function ArrowBubblePositioner_getInstance() {
    return ArrowBubblePositioner_instance;
  }
  function Colorable() {
  }
  function DefaultDrawableDrawer() {
    AbstractDrawableDrawer.call(this);
  }
  protoOf(DefaultDrawableDrawer).z28 = function (context, drawable) {
    drawable.h20(context);
    this.c29(context, drawable);
  };
  function VerticalPosition(y, below) {
    this.n2e_1 = y;
    this.o2e_1 = below;
  }
  protoOf(VerticalPosition).toString = function () {
    return 'VerticalPosition(y=' + this.n2e_1 + ', below=' + this.o2e_1 + ')';
  };
  protoOf(VerticalPosition).hashCode = function () {
    var result = getNumberHashCode(this.n2e_1);
    result = imul(result, 31) + getBooleanHashCode(this.o2e_1) | 0;
    return result;
  };
  protoOf(VerticalPosition).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof VerticalPosition))
      return false;
    if (!equals(this.n2e_1, other.n2e_1))
      return false;
    if (!(this.o2e_1 === other.o2e_1))
      return false;
    return true;
  };
  function calculateContentCenterX($this, attendant, attendee, view) {
    var centerXView = view.g25(attendee.d1d());
    var widthHalfView = view.k25(attendant.u1e_1 / 2);
    var rightView = centerXView.kn_1 + widthHalfView;
    var leftView = centerXView.kn_1 - widthHalfView;
    var overlapRightView = coerceAtLeast(rightView - (view.f1c() - 5 | 0), 0.0);
    // Inline function 'kotlin.math.abs' call
    var x = coerceAtMost(leftView - 5, 0.0);
    var overlapLeftView = Math.abs(x);
    var positionX = attendee.x1c();
    if (overlapRightView > 0 && overlapRightView > overlapLeftView) {
      positionX = positionX - view.f25(overlapRightView);
    } else if (overlapLeftView > 0) {
      positionX = positionX + view.f25(overlapLeftView);
    }
    return positionX;
  }
  function calculateVerticalPosition($this, attendant, attendee, view, preferredBelow, distance) {
    var tmp;
    if (preferredBelow) {
      tmp = preferredBelowPositionY_0($this, attendant, attendee, view, distance);
    } else {
      tmp = preferredAbovePositionY_0($this, attendant, attendee, view, distance);
    }
    return tmp;
  }
  function preferredBelowPositionY_0($this, attendant, attendee, view, distance) {
    var tmp;
    if (view.j25(attendee.c1d() + distance) + view.k25(attendant.v1e_1) <= (view.h1c() - 5 | 0)) {
      tmp = new VerticalPosition(attendee.c1d() + distance, true);
    } else {
      tmp = new VerticalPosition(attendee.a1d() - distance, false);
    }
    return tmp;
  }
  function preferredAbovePositionY_0($this, attendant, attendee, view, distance) {
    var tmp;
    if (view.j25(attendee.a1d() - distance) - view.k25(attendant.v1e_1) >= 5) {
      tmp = new VerticalPosition(attendee.a1d() - distance, false);
    } else {
      tmp = new VerticalPosition(attendee.c1d() + distance, true);
    }
    return tmp;
  }
  function DrawableAttendantPositioner() {
    this.p2e_1 = 5;
  }
  protoOf(DrawableAttendantPositioner).q2e = function (attendant, attendee, view, preferredBelow, distance) {
    var verticalPosition = calculateVerticalPosition(this, attendant, attendee, view, preferredBelow, distance);
    var contentCenterX = calculateContentCenterX(this, attendant, attendee, view);
    var tmp;
    if (verticalPosition.o2e_1) {
      tmp = new Point2D(contentCenterX - attendant.u1e_1 / 2, verticalPosition.n2e_1);
    } else {
      tmp = new Point2D(contentCenterX - attendant.u1e_1 / 2, verticalPosition.n2e_1 - attendant.v1e_1);
    }
    return tmp;
  };
  var DrawableAttendantPositioner_instance;
  function DrawableAttendantPositioner_getInstance() {
    return DrawableAttendantPositioner_instance;
  }
  function ButtonAction() {
  }
  function _get_LOG__e5r759_0($this) {
    var tmp0 = $this.s2e_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('LOG', 1, tmp, DrawableButton$Companion$_get_LOG_$ref_4t34a8(), null);
    return tmp0.j2();
  }
  function createShape($this, location, dimension, round) {
    var tmp;
    if (round) {
      tmp = RoundRectangle2D_init_$Create$(location, dimension, 6.0);
    } else {
      tmp = Rectangle2D_init_$Create$_0(location, dimension);
    }
    return tmp;
  }
  function DrawableButton$Companion$_get_LOG_$ref_4t34a8() {
    return function (p0) {
      return _get_LOG__e5r759_0(p0);
    };
  }
  function DrawableButton_init_$Init$(location, tooltipKey, styleType, styleProvider, action, renderer, $this) {
    tooltipKey = tooltipKey === VOID ? null : tooltipKey;
    styleProvider = styleProvider === VOID ? DrawStyleModule_getInstance().w1x_1 : styleProvider;
    DrawableButton.call($this, location, tooltipKey, new StylableImpl(VOID, styleType, styleProvider), action, renderer);
    return $this;
  }
  function DrawableButton_init_$Create$(location, tooltipKey, styleType, styleProvider, action, renderer) {
    return DrawableButton_init_$Init$(location, tooltipKey, styleType, styleProvider, action, renderer, objectCreate(protoOf(DrawableButton)));
  }
  function Companion_10() {
    Companion_instance_14 = this;
    this.s2e_1 = logger(getKClass(DrawableButton));
    this.t2e_1 = 6.0;
  }
  var Companion_instance_14;
  function Companion_getInstance_12() {
    if (Companion_instance_14 == null)
      new Companion_10();
    return Companion_instance_14;
  }
  function EditInteractionHandler($outer) {
    this.v2e_1 = $outer;
    InputEventHandlerAdapter.call(this);
  }
  protoOf(EditInteractionHandler).s28 = function (context) {
    return this.v2e_1.i2f(context.t22_1) ? this : null;
  };
  protoOf(EditInteractionHandler).z22 = function (context) {
    return this.s28(context instanceof InputEventContext ? context : THROW_CCE());
  };
  protoOf(EditInteractionHandler).t28 = function (context) {
    return this;
  };
  protoOf(EditInteractionHandler).a23 = function (context) {
    return this.t28(context instanceof InputEventContext ? context : THROW_CCE());
  };
  protoOf(EditInteractionHandler).w28 = function (context) {
    if (this.v2e_1.f2f_1) {
      var tmp0_safe_receiver = context.o22_1;
      if (tmp0_safe_receiver == null)
        null;
      else {
        tmp0_safe_receiver.consumeEvent();
      }
      this.v2e_1.c2f_1.r2e(context);
    }
    return null;
  };
  protoOf(EditInteractionHandler).y22 = function (context) {
    return this.w28(context instanceof InputEventContext ? context : THROW_CCE());
  };
  function DrawableButton(location, tooltipKey, stylable, action, renderer, specialColor, round) {
    Companion_getInstance_12();
    tooltipKey = tooltipKey === VOID ? null : tooltipKey;
    specialColor = specialColor === VOID ? null : specialColor;
    round = round === VOID ? false : round;
    AbstractRectangle.call(this, createShape(Companion_getInstance_12(), location, renderer.s1x(), round));
    this.a2f_1 = stylable;
    this.b2f_1 = tooltipKey;
    this.c2f_1 = action;
    this.d2f_1 = renderer;
    this.e2f_1 = specialColor;
    this.f2f_1 = true;
    this.g2f_1 = false;
    this.h2f_1 = this.j2f();
  }
  protoOf(DrawableButton).k2f = function () {
    var tmp0_elvis_lhs = this.e2f_1;
    return tmp0_elvis_lhs == null ? this.c1u() : tmp0_elvis_lhs;
  };
  protoOf(DrawableButton).pq = function (value) {
    if (!(this.f2f_1 === value)) {
      this.f2f_1 = value;
      this.i20();
      this.k20();
    }
  };
  protoOf(DrawableButton).l2f = function (value) {
    if (!(this.g2f_1 === value)) {
      this.i20();
      this.g2f_1 = value;
      this.k20();
    }
  };
  protoOf(DrawableButton).b2c = function () {
    return this.d2d().l1u().f1u_1;
  };
  protoOf(DrawableButton).e20 = function (context) {
    var tmp = this.h2f_1;
    return isInterface(tmp, InputEventHandler) ? tmp : THROW_CCE();
  };
  protoOf(DrawableButton).o20 = function (context) {
    var tmp0_safe_receiver = this.b2f_1;
    var tmp;
    if (tmp0_safe_receiver == null) {
      tmp = null;
    } else {
      // Inline function 'kotlin.let' call
      tmp = new Tooltip(Translations_getInstance().bn(tmp0_safe_receiver, []), Companion_instance_0.wu(this.t2a(context.t22_1)));
    }
    return tmp;
  };
  protoOf(DrawableButton).l20 = function () {
    this.l2f(false);
    protoOf(AbstractRectangle).l20.call(this);
  };
  protoOf(DrawableButton).h20 = function (context) {
    this.d2f_1.m2f(this, context);
  };
  protoOf(DrawableButton).j2f = function () {
    return new EditInteractionHandler(this);
  };
  protoOf(DrawableButton).i2f = function (mouseLocation) {
    if (this.po(mouseLocation)) {
      if (!this.g2f_1 && this.f2f_1) {
        _get_LOG__e5r759_0(Companion_getInstance_12()).ql('start hover mode');
        this.l2f(true);
      }
      return true;
    }
    if (this.g2f_1) {
      _get_LOG__e5r759_0(Companion_getInstance_12()).ql('stop hover mode');
      this.l2f(false);
    }
    return false;
  };
  protoOf(DrawableButton).w2c = function (_set____db54di) {
    this.a2f_1.w2c(_set____db54di);
  };
  protoOf(DrawableButton).x2c = function () {
    return this.a2f_1.x2c();
  };
  protoOf(DrawableButton).c1u = function () {
    return this.a2f_1.c1u();
  };
  protoOf(DrawableButton).y2c = function () {
    return this.a2f_1.y2c();
  };
  protoOf(DrawableButton).z2c = function () {
    return this.a2f_1.z2c();
  };
  protoOf(DrawableButton).a2d = function () {
    return this.a2f_1.a2d();
  };
  protoOf(DrawableButton).b2d = function () {
    return this.a2f_1.b2d();
  };
  protoOf(DrawableButton).l1u = function () {
    return this.a2f_1.l1u();
  };
  protoOf(DrawableButton).c2d = function (_set____db54di) {
    this.a2f_1.c2d(_set____db54di);
  };
  protoOf(DrawableButton).h29 = function () {
    return this.a2f_1.h29();
  };
  protoOf(DrawableButton).d2d = function () {
    return this.a2f_1.d2d();
  };
  protoOf(DrawableButton).e2d = function (_set____db54di) {
    this.a2f_1.e2d(_set____db54di);
  };
  protoOf(DrawableButton).f2d = function () {
    return this.a2f_1.f2d();
  };
  protoOf(DrawableButton).g2d = function (_set____db54di) {
    this.a2f_1.g2d(_set____db54di);
  };
  protoOf(DrawableButton).h2d = function () {
    return this.a2f_1.h2d();
  };
  protoOf(DrawableButton).i2d = function () {
    return this.a2f_1.i2d();
  };
  protoOf(DrawableButton).j2d = function (_set____db54di) {
    this.a2f_1.j2d(_set____db54di);
  };
  protoOf(DrawableButton).k2d = function () {
    return this.a2f_1.k2d();
  };
  protoOf(DrawableButton).l2d = function (_set____db54di) {
    this.a2f_1.l2d(_set____db54di);
  };
  protoOf(DrawableButton).m2d = function () {
    return this.a2f_1.m2d();
  };
  protoOf(DrawableButton).n2d = function (_set____db54di) {
    this.a2f_1.n2d(_set____db54di);
  };
  protoOf(DrawableButton).o2d = function (_set____db54di) {
    this.a2f_1.o2d(_set____db54di);
  };
  protoOf(DrawableButton).p2d = function () {
    return this.a2f_1.p2d();
  };
  function IconDrawableButtonRenderer(icon) {
    AbstractDrawableButtonRenderer.call(this);
    this.n2f_1 = icon;
  }
  protoOf(IconDrawableButtonRenderer).s1x = function () {
    return this.n2f_1.o2f();
  };
  protoOf(IconDrawableButtonRenderer).m2f = function (button, context) {
    var tmp;
    if (context.m1z_1) {
      tmp = ensureNotNull(context.n1z_1);
    } else {
      tmp = this.p2f(button);
    }
    var color = tmp;
    context.j1z_1.e1u(button.d2d().l1u());
    this.n2f_1.q2f(context, new Point2D(button.p1a(), button.q1a()), color);
  };
  function AbstractDrawableButtonRenderer() {
  }
  protoOf(AbstractDrawableButtonRenderer).p2f = function (button) {
    var tmp;
    if (button.g2f_1) {
      tmp = Themes_getInstance().h2g().d2g_1;
    } else if (!button.f2f_1) {
      tmp = button.k2f().r2f(128);
    } else {
      tmp = button.k2f();
    }
    return tmp;
  };
  function DrawableDrawer() {
  }
  function Companion_11() {
    this.i2g_1 = 200;
    this.j2g_1 = 10;
    this.k2g_1 = 10;
  }
  var Companion_instance_15;
  function Companion_getInstance_13() {
    return Companion_instance_15;
  }
  function updateGeometry($this) {
    var boxCorner = calculateBoxCorner($this, $this.v2g_1, $this.s2g_1);
    $this.u2g_1.i1c(boxCorner.kn_1, boxCorner.ln_1, _get_boxWidth__wbofio($this), _get_boxHeight__giqgxt($this));
  }
  function calculateBoxCorner($this, anchor, f) {
    var tmp;
    switch ($this.p2g_1.l2_1) {
      case 1:
        tmp = new Point2D(anchor.kn_1 - (($this.q2g_1 / 2 | 0) + 10 | 0) * f, anchor.ln_1 - ($this.t2g_1.h1c() + 20) * f);
        break;
      case 3:
        tmp = new Point2D(anchor.kn_1 - (($this.q2g_1 / 2 | 0) + 10 | 0) * f, anchor.ln_1);
        break;
      case 2:
        tmp = new Point2D(anchor.kn_1 - _get_boxWidth__wbofio($this) * f, anchor.ln_1 - _get_boxHeight__giqgxt($this) / 2 * f);
        break;
      case 0:
        tmp = new Point2D(anchor.kn_1, anchor.ln_1 - _get_boxHeight__giqgxt($this) / 2 * f);
        break;
      default:
        noWhenBranchMatchedException();
        break;
    }
    return tmp;
  }
  function getViewRectangle($this) {
    var anchorView = ensureNotNull($this.w2g_1).j24_1.g25($this.v2g_1).k1h(ensureNotNull($this.w2g_1).m24_1());
    var p = calculateBoxCorner($this, anchorView, $this.s2g_1);
    return new Rectangle2D(p.kn_1, p.ln_1, $this.u2g_1.w1h_1 * $this.s2g_1, $this.u2g_1.x1h_1);
  }
  function _get_boxWidth__wbofio($this) {
    return $this.q2g_1 + 2.0 * 10;
  }
  function _get_boxHeight__giqgxt($this) {
    return $this.t2g_1.h1c() + 2.0 * 10;
  }
  function FlexibleTextView(text, anchor, direction, width, isUnzoomable, devicePixelRatio, styleType, styleProvider) {
    width = width === VOID ? 200 : width;
    isUnzoomable = isUnzoomable === VOID ? true : isUnzoomable;
    devicePixelRatio = devicePixelRatio === VOID ? 1.0 : devicePixelRatio;
    styleType = styleType === VOID ? Companion_getInstance_33().b1y_1 : styleType;
    styleProvider = styleProvider === VOID ? DrawStyleModule_getInstance().w1x_1 : styleProvider;
    AbstractStyledDrawable_init_$Init$(styleType, styleProvider, this);
    this.p2g_1 = direction;
    this.q2g_1 = width;
    this.r2g_1 = isUnzoomable;
    this.s2g_1 = this.r2g_1 ? devicePixelRatio : 1.0;
    var tmp = this;
    var tmp_0;
    if (this.r2g_1) {
      tmp_0 = Companion_getInstance_15().j2h(text, this.b2d().k2h(devicePixelRatio), this.q2g_1 * devicePixelRatio);
    } else {
      tmp_0 = Companion_getInstance_15().j2h(text, this.b2d(), this.q2g_1);
    }
    tmp.t2g_1 = tmp_0;
    this.u2g_1 = new Rectangle2D();
    this.v2g_1 = anchor;
    this.w2g_1 = ZoomPan_init_$Create$();
    this.x2g_1 = new TransparentImpl(this);
    updateGeometry(this);
  }
  protoOf(FlexibleTextView).v20 = function (value) {
    this.i20();
    this.v2g_1 = value;
    updateGeometry(this);
    this.i20();
    this.l20();
  };
  protoOf(FlexibleTextView).jw = function () {
    return this.v2g_1;
  };
  protoOf(FlexibleTextView).fo = function () {
    if (this.r2g_1) {
      var p = calculateBoxCorner(this, this.v2g_1, 1 / ensureNotNull(this.w2g_1).k24_1);
      return new Rectangle2D(p.kn_1 - this.l1u().f1u_1, p.ln_1 - this.l1u().f1u_1, this.u2g_1.w1h_1 / ensureNotNull(this.w2g_1).k24_1 + 2 * this.l1u().f1u_1, this.u2g_1.x1h_1 / ensureNotNull(this.w2g_1).k24_1 + 2 * this.l1u().f1u_1);
    }
    return new Rectangle2D(this.u2g_1.u1h_1 - this.l1u().f1u_1, this.u2g_1.v1h_1 - this.l1u().f1u_1, this.u2g_1.w1h_1 + 2 * this.l1u().f1u_1, this.u2g_1.x1h_1 + 2 * this.l1u().f1u_1);
  };
  protoOf(FlexibleTextView).h20 = function (context) {
    var r = this.r2g_1 ? getViewRectangle(this) : this.u2g_1;
    context.j1z_1.b1u(this.x2g_1.l2h(this.z2c()));
    context.j1z_1.a1v(numberToInt(r.u1h_1), numberToInt(r.v1h_1), numberToInt(r.w1h_1), numberToInt(r.x1h_1), 20, 20);
    context.j1z_1.b1u(this.x2g_1.l2h(this.y2c()));
    context.j1z_1.e1u(this.l1u());
    context.j1z_1.w1u(numberToInt(r.u1h_1), numberToInt(r.v1h_1), numberToInt(r.w1h_1), numberToInt(r.x1h_1), 20, 20);
    context.j1z_1.m1u(this.b2d());
    context.j1z_1.b1u(this.x2g_1.l2h(this.a2d()));
    var tmp2 = r.u1h_1 + 10;
    var tmp = r.v1h_1 + 10;
    // Inline function 'kotlin.math.abs' call
    var x = this.t2g_1.x2h_1.v1h_1;
    // Inline function 'io.antarescircuit.jabbah.draw.DrawContext.translated' call
    var dy = tmp + Math.abs(x);
    context.j1z_1.l1d(tmp2, dy);
    this.t2g_1.h20(context);
    context.j1z_1.l1d(-tmp2, -dy);
  };
  protoOf(FlexibleTextView).go = function (x, y) {
    return this.u2g_1.go(x, y);
  };
  protoOf(FlexibleTextView).o2b = function (value) {
    if (equals(this.w2g_1, value)) {
      return Unit_instance;
    }
    this.i20();
    this.w2g_1 = value;
    updateGeometry(this);
    this.i20();
    this.l20();
  };
  protoOf(FlexibleTextView).a2i = function (value) {
    this.x2g_1.a2i(value);
  };
  protoOf(FlexibleTextView).d2i = function () {
    return this.x2g_1.c2i_1;
  };
  function Locatable() {
  }
  function Mirrorable() {
  }
  function Companion_12() {
  }
  protoOf(Companion_12).h2i = function (movables, offset) {
    this.i2i(movables, offset.kn_1, offset.ln_1);
  };
  protoOf(Companion_12).i2i = function (movables, dx, dy) {
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = movables.i();
    while (_iterator__ex2g4s.j()) {
      var element = _iterator__ex2g4s.k();
      element.j2i(movables);
    }
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s_0 = movables.i();
    while (_iterator__ex2g4s_0.j()) {
      var element_0 = _iterator__ex2g4s_0.k();
      element_0.v21(dx, dy);
    }
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s_1 = movables.i();
    while (_iterator__ex2g4s_1.j()) {
      var element_1 = _iterator__ex2g4s_1.k();
      element_1.k2i();
    }
  };
  var Companion_instance_16;
  function Companion_getInstance_14() {
    return Companion_instance_16;
  }
  function Movable() {
  }
  function MoveLocatableAnimation$_init_$lambda_1mj00z($locatable) {
    return function (it) {
      $locatable.v20(it);
      $locatable.k20();
      return Unit_instance;
    };
  }
  function MoveLocatableAnimation(locatable, sequence, duration, isPausable) {
    isPausable = isPausable === VOID ? true : isPausable;
    AbstractAnimationTask.call(this, locatable, MoveLocatableAnimation$_init_$lambda_1mj00z(locatable), sequence, duration, true, isPausable);
  }
  function Orientable() {
  }
  function RectangularDrawable() {
  }
  function _get_LOG__e5r759_1($this) {
    var tmp0 = $this.y2g_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('LOG', 1, tmp, RichTextDrawable$Companion$_get_LOG_$ref_8c0lc7(), null);
    return tmp0.j2();
  }
  function legacyRichText($this, text, error) {
    _get_LOG__e5r759_1($this).pl('Resorting to legacy format: ' + error.message + ' at ' + error.yy_1.toString());
    return Companion_instance_1.f1l(text);
  }
  function transformToSingleLine($this, richText, font, textMeasurer) {
    var drawable = new RichTextDrawable(richText, font);
    var baselineX = 0.0;
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = richText.uw_1.i();
    while (_iterator__ex2g4s.j()) {
      var element = _iterator__ex2g4s.k();
      // Inline function 'kotlin.collections.forEach' call
      var _iterator__ex2g4s_0 = element.z1k_1.x1k_1.s1k_1.i();
      while (_iterator__ex2g4s_0.j()) {
        var element_0 = _iterator__ex2g4s_0.k();
        // Inline function 'kotlin.also' call
        baselineX = baselineX + createAndAddChunkView(drawable, element_0.d1l_1, element_0.e1l_1, baselineX, 0.0, false, textMeasurer).t2i_1;
      }
      var subscriptX = baselineX + 2;
      var tmp0_safe_receiver = element.a1l_1;
      var tmp1_safe_receiver = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.x1k_1;
      var tmp2_safe_receiver = tmp1_safe_receiver == null ? null : tmp1_safe_receiver.s1k_1;
      if (tmp2_safe_receiver == null)
        null;
      else {
        // Inline function 'kotlin.collections.forEach' call
        var _iterator__ex2g4s_1 = tmp2_safe_receiver.i();
        while (_iterator__ex2g4s_1.j()) {
          var element_1 = _iterator__ex2g4s_1.k();
          // Inline function 'kotlin.also' call
          subscriptX = subscriptX + createAndAddChunkView(drawable, element_1.d1l_1, element_1.e1l_1, subscriptX, +font.o() * 0.2, true, textMeasurer).t2i_1;
        }
      }
      var superscriptX = baselineX + 2;
      var tmp3_safe_receiver = element.b1l_1;
      var tmp4_safe_receiver = tmp3_safe_receiver == null ? null : tmp3_safe_receiver.x1k_1;
      var tmp5_safe_receiver = tmp4_safe_receiver == null ? null : tmp4_safe_receiver.s1k_1;
      if (tmp5_safe_receiver == null)
        null;
      else {
        // Inline function 'kotlin.collections.forEach' call
        var _iterator__ex2g4s_2 = tmp5_safe_receiver.i();
        while (_iterator__ex2g4s_2.j()) {
          var element_2 = _iterator__ex2g4s_2.k();
          // Inline function 'kotlin.also' call
          superscriptX = superscriptX + createAndAddChunkView(drawable, element_2.d1l_1, element_2.e1l_1, superscriptX, (-font.o() | 0) * 0.5, true, textMeasurer).t2i_1;
        }
      }
      var tmp0 = subscriptX;
      // Inline function 'kotlin.math.max' call
      var b = superscriptX;
      baselineX = Math.max(tmp0, b);
    }
    return drawable;
  }
  function transformToMultiline($this, richText, font, preferredWidth, textMeasurer) {
    var drawable = new RichTextDrawable(richText, font);
    var baselineX = 0.0;
    var baselineY = 0.0;
    var lineWidth = 0.0;
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = richText.uw_1.i();
    while (_iterator__ex2g4s.j()) {
      var element = _iterator__ex2g4s.k();
      // Inline function 'kotlin.collections.flatMap' call
      var tmp0 = element.z1k_1.x1k_1.s1k_1;
      // Inline function 'kotlin.collections.flatMapTo' call
      var destination = ArrayList_init_$Create$();
      var _iterator__ex2g4s_0 = tmp0.i();
      while (_iterator__ex2g4s_0.j()) {
        var element_0 = _iterator__ex2g4s_0.k();
        var list = element_0.m1l();
        addAll(destination, list);
      }
      // Inline function 'kotlin.collections.forEach' call
      var _iterator__ex2g4s_1 = destination.i();
      while (_iterator__ex2g4s_1.j()) {
        var element_1 = _iterator__ex2g4s_1.k();
        var lines = split(element_1.d1l_1, charArrayOf([_Char___init__impl__6a9atx(10)]));
        // Inline function 'kotlin.collections.forEachIndexed' call
        var index = 0;
        var _iterator__ex2g4s_2 = lines.i();
        while (_iterator__ex2g4s_2.j()) {
          var item = _iterator__ex2g4s_2.k();
          var _unary__edvuaz = index;
          index = _unary__edvuaz + 1 | 0;
          var index_0 = checkIndexOverflow(_unary__edvuaz);
          var wordView = createChunkView(drawable, item, element_1.e1l_1, baselineX, baselineY, false, textMeasurer);
          var textWidth = wordView.t2i_1;
          if (lineWidth + textWidth > preferredWidth) {
            if (baselineX > 0.0) {
              wordView.z2i(0.0);
              wordView.a2j(wordView.w2i_1 + (wordView.u2i_1 + 3.0));
              addChunkView(drawable, wordView);
              baselineX = wordView.t2i_1;
              baselineY = wordView.w2i_1;
              lineWidth = wordView.t2i_1;
            } else {
              wordView.z2i(0.0);
              wordView.a2j(baselineY);
              addChunkView(drawable, wordView);
              baselineX = 0.0;
              baselineY = baselineY + (wordView.u2i_1 + 3.0);
              lineWidth = 0.0;
            }
          } else {
            wordView.z2i(baselineX);
            wordView.a2j(baselineY);
            addChunkView(drawable, wordView);
            baselineX = baselineX + textWidth;
            lineWidth = lineWidth + textWidth;
          }
          if (index_0 < (lines.o() - 1 | 0)) {
            baselineX = 0.0;
            baselineY = baselineY + (wordView.u2i_1 + 3.0);
            lineWidth = 0.0;
          }
        }
      }
      var subscriptX = baselineX + 2;
      var tmp0_safe_receiver = element.a1l_1;
      var tmp1_safe_receiver = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.x1k_1;
      var tmp2_safe_receiver = tmp1_safe_receiver == null ? null : tmp1_safe_receiver.s1k_1;
      if (tmp2_safe_receiver == null)
        null;
      else {
        // Inline function 'kotlin.collections.forEach' call
        var _iterator__ex2g4s_3 = tmp2_safe_receiver.i();
        while (_iterator__ex2g4s_3.j()) {
          var element_2 = _iterator__ex2g4s_3.k();
          // Inline function 'kotlin.also' call
          subscriptX = subscriptX + createAndAddChunkView(drawable, element_2.d1l_1, element_2.e1l_1, subscriptX, +font.o() * 0.2, true, textMeasurer).t2i_1;
        }
      }
      var superscriptX = baselineX + 2;
      var tmp3_safe_receiver = element.b1l_1;
      var tmp4_safe_receiver = tmp3_safe_receiver == null ? null : tmp3_safe_receiver.x1k_1;
      var tmp5_safe_receiver = tmp4_safe_receiver == null ? null : tmp4_safe_receiver.s1k_1;
      if (tmp5_safe_receiver == null)
        null;
      else {
        // Inline function 'kotlin.collections.forEach' call
        var _iterator__ex2g4s_4 = tmp5_safe_receiver.i();
        while (_iterator__ex2g4s_4.j()) {
          var element_3 = _iterator__ex2g4s_4.k();
          // Inline function 'kotlin.also' call
          superscriptX = superscriptX + createAndAddChunkView(drawable, element_3.d1l_1, element_3.e1l_1, superscriptX, (-font.o() | 0) * 0.5, true, textMeasurer).t2i_1;
        }
      }
      var tmp0_0 = subscriptX;
      // Inline function 'kotlin.math.max' call
      var b = superscriptX;
      baselineX = Math.max(tmp0_0, b);
      lineWidth = baselineX;
    }
    return drawable;
  }
  function RichTextDrawable$Companion$_get_LOG_$ref_8c0lc7() {
    return function (p0) {
      return _get_LOG__e5r759_1(p0);
    };
  }
  function _get_localFont__g8zbd($this) {
    var tmp;
    if ($this.q2i_1) {
      tmp = $this.p2i_1.l1l_1 ? _get_italicIndexFont__oouatc($this.y2i_1) : _get_indexFont__9nm3f4($this.y2i_1);
    } else {
      var tmp_0;
      if ($this.p2i_1.k1l_1) {
        tmp_0 = $this.p2i_1.l1l_1 ? _get_boldItalicFont__jsfamf($this.y2i_1) : _get_boldFont__a9fis7($this.y2i_1);
      } else {
        tmp_0 = $this.p2i_1.l1l_1 ? _get_italicFont__ld5fec($this.y2i_1) : $this.y2i_1.q2h_1;
      }
      tmp = tmp_0;
    }
    return tmp;
  }
  function Companion_13() {
    Companion_instance_17 = this;
    this.y2g_1 = logger(getKClass(RichTextDrawable));
    this.z2g_1 = 0.7;
    this.a2h_1 = 0.2;
    this.b2h_1 = 0.5;
    this.c2h_1 = 2;
    this.d2h_1 = new Stroke(1.0);
    this.e2h_1 = Companion_getInstance_20().m1t_1;
    this.f2h_1 = new Stroke(0.5);
    this.g2h_1 = new Stroke(1.0);
    this.h2h_1 = 3.0;
    this.i2h_1 = true;
  }
  protoOf(Companion_13).b2j = function (text, font, textMeasurer) {
    var tmp;
    try {
      tmp = transformToSingleLine(this, RichTextParser_init_$Create$(text).xy(), font, textMeasurer);
    } catch ($p) {
      var tmp_0;
      if ($p instanceof SyntaxError) {
        var e = $p;
        var tmp_1;
        if (this.i2h_1) {
          tmp_1 = transformToSingleLine(this, legacyRichText(this, text, e), font, textMeasurer);
        } else {
          throw e;
        }
        tmp_0 = tmp_1;
      } else {
        throw $p;
      }
      tmp = tmp_0;
    }
    return tmp;
  };
  protoOf(Companion_13).c2j = function (text, font, textMeasurer, $super) {
    textMeasurer = textMeasurer === VOID ? TextRenderInfoFactory_instance : textMeasurer;
    return $super === VOID ? this.b2j(text, font, textMeasurer) : $super.b2j.call(this, text, font, textMeasurer);
  };
  protoOf(Companion_13).d2j = function (text, font, textMeasurer) {
    return transformToSingleLine(this, Companion_instance_1.f1l(text), font, textMeasurer);
  };
  protoOf(Companion_13).e2j = function (text, font, textMeasurer, $super) {
    textMeasurer = textMeasurer === VOID ? TextRenderInfoFactory_instance : textMeasurer;
    return $super === VOID ? this.d2j(text, font, textMeasurer) : $super.d2j.call(this, text, font, textMeasurer);
  };
  protoOf(Companion_13).f2j = function (text, font, preferredWidth, textMeasurer) {
    var tmp;
    try {
      tmp = transformToMultiline(this, RichTextParser_init_$Create$(text).xy(), font, preferredWidth, textMeasurer);
    } catch ($p) {
      var tmp_0;
      if ($p instanceof SyntaxError) {
        var e = $p;
        var tmp_1;
        if (this.i2h_1) {
          tmp_1 = transformToMultiline(this, legacyRichText(this, text, e), font, preferredWidth, textMeasurer);
        } else {
          throw e;
        }
        tmp_0 = tmp_1;
      } else {
        throw $p;
      }
      tmp = tmp_0;
    }
    return tmp;
  };
  protoOf(Companion_13).j2h = function (text, font, preferredWidth, textMeasurer, $super) {
    textMeasurer = textMeasurer === VOID ? TextRenderInfoFactory_instance : textMeasurer;
    return $super === VOID ? this.f2j(text, font, preferredWidth, textMeasurer) : $super.f2j.call(this, text, font, preferredWidth, textMeasurer);
  };
  var Companion_instance_17;
  function Companion_getInstance_15() {
    if (Companion_instance_17 == null)
      new Companion_13();
    return Companion_instance_17;
  }
  function _get_boldFont__a9fis7($this) {
    var tmp0 = $this.s2h_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('boldFont', 1, tmp, RichTextDrawable$_get_boldFont_$ref_3fkyrn(), null);
    return tmp0.j2();
  }
  function _get_italicFont__ld5fec($this) {
    var tmp0 = $this.t2h_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('italicFont', 1, tmp, RichTextDrawable$_get_italicFont_$ref_wadw6w(), null);
    return tmp0.j2();
  }
  function _get_boldItalicFont__jsfamf($this) {
    var tmp0 = $this.u2h_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('boldItalicFont', 1, tmp, RichTextDrawable$_get_boldItalicFont_$ref_o1qpe5(), null);
    return tmp0.j2();
  }
  function _get_indexFont__9nm3f4($this) {
    var tmp0 = $this.v2h_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('indexFont', 1, tmp, RichTextDrawable$_get_indexFont_$ref_trdqta(), null);
    return tmp0.j2();
  }
  function _get_italicIndexFont__oouatc($this) {
    var tmp0 = $this.w2h_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('italicIndexFont', 1, tmp, RichTextDrawable$_get_italicIndexFont_$ref_pdseky(), null);
    return tmp0.j2();
  }
  function createChunkView($this, text, style, baselineX, baselineY, indexed, textMeasurer) {
    return new ChunkView($this, text, style, baselineX, baselineY, indexed, textMeasurer);
  }
  function createAndAddChunkView($this, text, style, baselineX, baselineY, indexed, textMeasurer) {
    // Inline function 'kotlin.also' call
    var this_0 = createChunkView($this, text, style, baselineX, baselineY, indexed, textMeasurer);
    addChunkView($this, this_0);
    return this_0;
  }
  function addChunkView($this, chunkView) {
    $this.r2h_1.h(chunkView);
    $this.x2h_1.vn(chunkView.r2i_1, chunkView.s2i_1);
    $this.x2h_1.vn(chunkView.r2i_1 + chunkView.t2i_1, chunkView.s2i_1 + chunkView.u2i_1);
    $this.y2b_1.vn(chunkView.r2i_1, chunkView.s2i_1);
    $this.y2b_1.vn(chunkView.r2i_1 + chunkView.t2i_1, chunkView.s2i_1 + chunkView.u2i_1);
  }
  function ChunkView($outer, text, style, baselineX, baselineY, indexed, textMeasurer) {
    indexed = indexed === VOID ? false : indexed;
    this.y2i_1 = $outer;
    this.o2i_1 = text;
    this.p2i_1 = style;
    this.q2i_1 = indexed;
    this.r2i_1 = 0.0;
    this.s2i_1 = 0.0;
    this.t2i_1 = 0.0;
    this.u2i_1 = 0.0;
    this.v2i_1 = baselineX;
    this.w2i_1 = baselineY;
    this.x2i_1 = 0.0;
    var tri = textMeasurer.g2j(this.o2i_1, _get_localFont__g8zbd(this));
    this.x2i_1 = tri.i2j_1;
    this.r2i_1 = baselineX;
    this.s2i_1 = baselineY - this.x2i_1;
    this.t2i_1 = tri.h2j_1.w1h_1;
    this.u2i_1 = tri.h2j_1.x1h_1;
  }
  protoOf(ChunkView).z2i = function (value) {
    this.v2i_1 = value;
    this.r2i_1 = this.v2i_1;
  };
  protoOf(ChunkView).a2j = function (value) {
    this.w2i_1 = value;
    this.s2i_1 = this.w2i_1 - this.x2i_1;
  };
  protoOf(ChunkView).j2j = function (g, maxOverlineLevel) {
    g.m1u(_get_localFont__g8zbd(this));
    g.n1v(this.o2i_1, numberToInt(this.v2i_1), numberToInt(this.w2i_1));
    var inductionVariable = 1;
    var last = this.p2i_1.j1l_1;
    if (inductionVariable <= last)
      do {
        var level = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        g.e1u(Companion_getInstance_15().g2h_1);
        var lineY = this.s2i_1 - 2.5 * (maxOverlineLevel - level | 0);
        if (this.p2i_1.l1l_1) {
          g.t1u(this.r2i_1 + 2, lineY, this.r2i_1 + this.t2i_1, lineY);
        } else {
          g.t1u(this.r2i_1, lineY, this.r2i_1 + this.t2i_1, lineY);
        }
      }
       while (!(level === last));
    if (DrawModule_getInstance().g2a_1) {
      var oldColor = g.c1u();
      g.b1u(Companion_getInstance_15().e2h_1);
      g.e1u(Companion_getInstance_15().f2h_1);
      g.v1u(this.r2i_1, this.s2i_1, this.t2i_1, this.u2i_1);
      g.b1u(oldColor);
    }
  };
  function RichTextDrawable$boldFont$delegate$lambda(this$0) {
    return function () {
      return this$0.q2h_1.j26(FontStyle_BOLD_getInstance());
    };
  }
  function RichTextDrawable$_get_boldFont_$ref_3fkyrn() {
    return function (p0) {
      return _get_boldFont__a9fis7(p0);
    };
  }
  function RichTextDrawable$italicFont$delegate$lambda(this$0) {
    return function () {
      return this$0.q2h_1.j26(FontStyle_ITALIC_getInstance());
    };
  }
  function RichTextDrawable$_get_italicFont_$ref_wadw6w() {
    return function (p0) {
      return _get_italicFont__ld5fec(p0);
    };
  }
  function RichTextDrawable$boldItalicFont$delegate$lambda(this$0) {
    return function () {
      return this$0.q2h_1.j26(FontStyle_BOLD_getInstance()).j26(FontStyle_ITALIC_getInstance());
    };
  }
  function RichTextDrawable$_get_boldItalicFont_$ref_o1qpe5() {
    return function (p0) {
      return _get_boldItalicFont__jsfamf(p0);
    };
  }
  function RichTextDrawable$indexFont$delegate$lambda(this$0) {
    return function () {
      return this$0.q2h_1.k2j(numberToInt(this$0.q2h_1.o() * 0.7)).j26(FontStyle_BOLD_getInstance());
    };
  }
  function RichTextDrawable$_get_indexFont_$ref_trdqta() {
    return function (p0) {
      return _get_indexFont__9nm3f4(p0);
    };
  }
  function RichTextDrawable$italicIndexFont$delegate$lambda(this$0) {
    return function () {
      return this$0.q2h_1.k2j(numberToInt(this$0.q2h_1.o() * 0.7)).j26(FontStyle_BOLD_getInstance()).j26(FontStyle_ITALIC_getInstance());
    };
  }
  function RichTextDrawable$_get_italicIndexFont_$ref_pdseky() {
    return function (p0) {
      return _get_italicIndexFont__oouatc(p0);
    };
  }
  function RichTextDrawable(richText, baseFont) {
    Companion_getInstance_15();
    AbstractRectangle_init_$Init$_0(this);
    this.q2h_1 = baseFont;
    var tmp = this;
    // Inline function 'kotlin.collections.mutableListOf' call
    tmp.r2h_1 = ArrayList_init_$Create$();
    var tmp_0 = this;
    tmp_0.s2h_1 = lazy(RichTextDrawable$boldFont$delegate$lambda(this));
    var tmp_1 = this;
    tmp_1.t2h_1 = lazy(RichTextDrawable$italicFont$delegate$lambda(this));
    var tmp_2 = this;
    tmp_2.u2h_1 = lazy(RichTextDrawable$boldItalicFont$delegate$lambda(this));
    var tmp_3 = this;
    tmp_3.v2h_1 = lazy(RichTextDrawable$indexFont$delegate$lambda(this));
    var tmp_4 = this;
    tmp_4.w2h_1 = lazy(RichTextDrawable$italicIndexFont$delegate$lambda(this));
    this.x2h_1 = new Rectangle2D();
    this.y2h_1 = false;
    this.z2h_1 = richText.i1l();
  }
  protoOf(RichTextDrawable).h20 = function (context) {
    this.l2j(context.j1z_1);
  };
  protoOf(RichTextDrawable).l2j = function (g) {
    // Inline function 'kotlin.math.abs' call
    var x = this.x2h_1.v1h_1;
    var ascent = Math.abs(x);
    g.l1d(this.jw().kn_1, this.jw().ln_1 + ascent);
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = this.r2h_1.i();
    while (_iterator__ex2g4s.j()) {
      var element = _iterator__ex2g4s.k();
      element.j2j(g, this.z2h_1);
    }
    if (this.y2h_1) {
      var y = ((-numberToInt(ascent) | 0) + this.v1c() | 0) + 1 | 0;
      g.e1u(Companion_getInstance_15().d2h_1);
      g.s1u(0, y, this.u1c(), y);
    }
    g.l1d(-this.jw().kn_1, -this.jw().ln_1 - ascent);
  };
  protoOf(RichTextDrawable).b2c = function () {
    return 1.0;
  };
  function createShakeSequence($this, start, range, cycleCount) {
    // Inline function 'kotlin.collections.mutableListOf' call
    var sequences = ArrayList_init_$Create$();
    var inductionVariable = 1;
    if (inductionVariable <= cycleCount)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        sequences.h(new PointRange(start, start.vn(range, 0.0)));
        sequences.h(new PointRange(start.vn(range, 0.0), start.vn(-range, 0.0)));
        sequences.h(new PointRange(start.vn(-range, 0.0), start));
      }
       while (!(i === cycleCount));
    // Inline function 'kotlin.collections.toTypedArray' call
    var tmp$ret$1 = copyToArray(sequences);
    return new CompositeSequence(tmp$ret$1.slice());
  }
  function Companion_14() {
    this.m2j_1 = 200.0;
    this.n2j_1 = 4.0;
    this.o2j_1 = 2;
  }
  var Companion_instance_18;
  function Companion_getInstance_16() {
    return Companion_instance_18;
  }
  function ShakeLocatableAnimation$_init_$lambda_pizhn6($locatable) {
    return function (it) {
      $locatable.v20(it);
      $locatable.k20();
      return Unit_instance;
    };
  }
  function ShakeLocatableAnimation(locatable, duration, range, cycleCount) {
    duration = duration === VOID ? 200.0 : duration;
    range = range === VOID ? 4.0 : range;
    cycleCount = cycleCount === VOID ? 2 : cycleCount;
    AbstractAnimationTask.call(this, locatable, ShakeLocatableAnimation$_init_$lambda_pizhn6(locatable), createShakeSequence(Companion_instance_18, locatable.jw(), range, cycleCount), duration, false, false);
    this.x2j_1 = locatable;
    this.y2j_1 = this.x2j_1.jw();
  }
  protoOf(ShakeLocatableAnimation).p1p = function () {
    this.x2j_1.v20(this.y2j_1);
    this.x2j_1.k20();
  };
  function SynchronizedGlowAnimation$consume$ref(p0) {
    var l = function (_this__u8e3s4) {
      p0.e2k(_this__u8e3s4);
      return Unit_instance;
    };
    l.callableName = 'consume';
    return l;
  }
  function _get_LOG__e5r759_2($this) {
    var tmp0 = $this.z2j_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('LOG', 1, tmp, SynchronizedGlowAnimation$_get_LOG_$ref_7fyyg5(), null);
    return tmp0.j2();
  }
  function GlowTask() {
    var tmp = SynchronizedGlowAnimation_getInstance();
    AbstractAnimationTask.call(this, tmp, SynchronizedGlowAnimation$consume$ref(SynchronizedGlowAnimation_getInstance()), new Oscillation(new DoubleRange(255, 16.0)), 300.0, VOID, VOID, 'SynchronizedGlow');
  }
  function startIfNeeded($this) {
    if (!$this.c2k_1) {
      _get_LOG__e5r759_2($this).ql('Start GlowAnimation task');
      if (AnimationModule_getInstance().h1q_1.z1q(SynchronizedGlowAnimation_getInstance()).m()) {
        AnimationModule_getInstance().h1q_1.i1q($this.a2k_1);
      }
      $this.a2k_1.xp();
      $this.c2k_1 = true;
    }
  }
  function stopIfNeeded($this) {
    if ($this.d2k_1.m()) {
      _get_LOG__e5r759_2($this).ql('Stop GlowAnimation task');
      $this.a2k_1.yp();
      $this.c2k_1 = false;
    }
  }
  function SynchronizedGlowAnimation$_get_LOG_$ref_7fyyg5() {
    return function (p0) {
      return _get_LOG__e5r759_2(p0);
    };
  }
  function SynchronizedGlowAnimation() {
    SynchronizedGlowAnimation_instance = this;
    this.z2j_1 = logger(getKClass(SynchronizedGlowAnimation));
    this.a2k_1 = new GlowTask();
    this.b2k_1 = 255;
    this.c2k_1 = false;
    var tmp = this;
    // Inline function 'kotlin.collections.mutableListOf' call
    tmp.d2k_1 = ArrayList_init_$Create$();
  }
  protoOf(SynchronizedGlowAnimation).f2k = function (transparent) {
    if (!this.d2k_1.n(transparent)) {
      _get_LOG__e5r759_2(this).ql('Add glowing object');
      this.d2k_1.h(transparent);
    }
    startIfNeeded(this);
  };
  protoOf(SynchronizedGlowAnimation).g2k = function (transparent) {
    _get_LOG__e5r759_2(this).ql('Remove glowing object');
    this.d2k_1.h2(transparent);
    stopIfNeeded(this);
    transparent.a2i(255);
    transparent.k20();
  };
  protoOf(SynchronizedGlowAnimation).h2k = function () {
    _get_LOG__e5r759_2(this).ql('Remove all glowing object');
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = this.d2k_1.i();
    while (_iterator__ex2g4s.j()) {
      var element = _iterator__ex2g4s.k();
      element.a2i(255);
      element.k20();
    }
    this.d2k_1.a2();
    stopIfNeeded(this);
  };
  protoOf(SynchronizedGlowAnimation).e2k = function (value) {
    this.b2k_1 = value;
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = this.d2k_1.i();
    while (_iterator__ex2g4s.j()) {
      var element = _iterator__ex2g4s.k();
      element.a2i(numberToInt(SynchronizedGlowAnimation_getInstance().b2k_1));
      element.k20();
    }
  };
  var SynchronizedGlowAnimation_instance;
  function SynchronizedGlowAnimation_getInstance() {
    if (SynchronizedGlowAnimation_instance == null)
      new SynchronizedGlowAnimation();
    return SynchronizedGlowAnimation_instance;
  }
  function TransparentImpl(owner) {
    this.b2i_1 = owner;
    this.c2i_1 = 255;
  }
  protoOf(TransparentImpl).a2i = function (value) {
    if (value > 255 || value < 0) {
      throw IllegalArgumentException_init_$Create$("transparency '" + value + "' must be between 0 and 255");
    }
    this.c2i_1 = value;
    this.b2i_1.i20();
  };
  protoOf(TransparentImpl).d2i = function () {
    return this.c2i_1;
  };
  protoOf(TransparentImpl).b20 = function () {
    return this.b2i_1.b20();
  };
  protoOf(TransparentImpl).fo = function () {
    return this.b2i_1.fo();
  };
  protoOf(TransparentImpl).c20 = function (_set____db54di) {
    this.b2i_1.c20(_set____db54di);
  };
  protoOf(TransparentImpl).d20 = function () {
    return this.b2i_1.d20();
  };
  protoOf(TransparentImpl).n13 = function (visitor) {
    return this.b2i_1.n13(visitor);
  };
  protoOf(TransparentImpl).e20 = function (context) {
    return this.b2i_1.e20(context);
  };
  protoOf(TransparentImpl).f20 = function (listener) {
    this.b2i_1.f20(listener);
  };
  protoOf(TransparentImpl).g20 = function (listener) {
    this.b2i_1.g20(listener);
  };
  protoOf(TransparentImpl).h20 = function (context) {
    this.b2i_1.h20(context);
  };
  protoOf(TransparentImpl).i20 = function () {
    this.b2i_1.i20();
  };
  protoOf(TransparentImpl).k20 = function () {
    this.b2i_1.k20();
  };
  protoOf(TransparentImpl).l20 = function () {
    this.b2i_1.l20();
  };
  protoOf(TransparentImpl).go = function (x, y) {
    return this.b2i_1.go(x, y);
  };
  protoOf(TransparentImpl).po = function (p) {
    return this.b2i_1.po(p);
  };
  protoOf(TransparentImpl).ro = function (rect) {
    return this.b2i_1.ro(rect);
  };
  protoOf(TransparentImpl).m20 = function (container) {
    this.b2i_1.m20(container);
  };
  protoOf(TransparentImpl).n20 = function (container) {
    this.b2i_1.n20(container);
  };
  protoOf(TransparentImpl).o20 = function (context) {
    return this.b2i_1.o20(context);
  };
  protoOf(TransparentImpl).p20 = function (x, y) {
    return this.b2i_1.p20(x, y);
  };
  protoOf(TransparentImpl).gs = function () {
    this.b2i_1.gs();
  };
  function Companion_15() {
    this.i2k_1 = 0;
    this.j2k_1 = 255;
  }
  protoOf(Companion_15).k2k = function (transparency, color) {
    if (transparency === 255) {
      return color;
    }
    var rate = transparency / 255;
    // Inline function 'kotlin.math.floor' call
    var x = color.q1y_1 * rate;
    var tmp$ret$0 = Math.floor(x);
    return color.r2f(numberToInt(tmp$ret$0));
  };
  var Companion_instance_19;
  function Companion_getInstance_17() {
    return Companion_instance_19;
  }
  function Transparent() {
  }
  function _get_LOG__e5r759_3($this) {
    var tmp0 = $this.l2k_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('LOG', 1, tmp, TransparentAnimation$Companion$_get_LOG_$ref_pt14lq(), null);
    return tmp0.j2();
  }
  function TransparentAnimation$Companion$_get_LOG_$ref_pt14lq() {
    return function (p0) {
      return _get_LOG__e5r759_3(p0);
    };
  }
  function TransparentAnimation$Companion$fadeInOut$1($container, $transparent) {
    this.n2k_1 = $container;
    this.o2k_1 = $transparent;
    AnimationTaskAdapter.call(this);
  }
  protoOf(TransparentAnimation$Companion$fadeInOut$1).s1p = function (task, canceled) {
    _get_LOG__e5r759_3(Companion_getInstance_18()).ql('remove transparent');
    this.n2k_1.c21(this.o2k_1);
  };
  function TransparentAnimation$Companion$fadeInOut$lambda($fadeOutAnimation, $timer) {
    return function (it) {
      _get_LOG__e5r759_3(Companion_getInstance_18()).ql('start fade-out animation');
      $fadeOutAnimation.xp();
      $timer.yp();
      return Unit_instance;
    };
  }
  function TransparentAnimation$Companion$fadeInOut$4($timer) {
    this.p2k_1 = $timer;
    AnimationTaskAdapter.call(this);
  }
  protoOf(TransparentAnimation$Companion$fadeInOut$4).s1p = function (task, canceled) {
    _get_LOG__e5r759_3(Companion_getInstance_18()).ql('start timer');
    if (!canceled) {
      this.p2k_1.xp();
    }
  };
  function Companion_16() {
    Companion_instance_20 = this;
    this.l2k_1 = logger(getKClass(TransparentAnimation));
    this.m2k_1 = 300.0;
  }
  protoOf(Companion_16).q2k = function (transparent, duration) {
    return new TransparentAnimation(transparent, new DoubleRange(0, 255), duration);
  };
  protoOf(Companion_16).r2k = function (transparent, duration) {
    return new TransparentAnimation(transparent, new DoubleRange(255, 0), duration);
  };
  protoOf(Companion_16).s2k = function (transparent, container, fadeInTimeMs, holdTimeMs, fadeOutTimeMs, animator) {
    transparent.a2i(0);
    var fadeOutAnimation = this.r2k(transparent, fadeOutTimeMs);
    fadeOutAnimation.j1p(new TransparentAnimation$Companion$fadeInOut$1(container, transparent));
    animator.i1q(fadeOutAnimation);
    var timer = System_getInstance().wl();
    timer.wp(holdTimeMs, VOID, TransparentAnimation$Companion$fadeInOut$lambda(fadeOutAnimation, timer));
    var fadeInAnimation = this.q2k(transparent, fadeInTimeMs);
    fadeInAnimation.j1p(new TransparentAnimation$Companion$fadeInOut$4(timer));
    animator.i1q(fadeInAnimation);
    _get_LOG__e5r759_3(this).ql('start fade-in animation');
    fadeInAnimation.xp();
  };
  var Companion_instance_20;
  function Companion_getInstance_18() {
    if (Companion_instance_20 == null)
      new Companion_16();
    return Companion_instance_20;
  }
  function TransparentAnimation$_init_$lambda_74dix($transparent) {
    return function (it) {
      $transparent.a2i(numberToInt(it));
      $transparent.k20();
      return Unit_instance;
    };
  }
  function TransparentAnimation(transparent, sequence, duration, key) {
    Companion_getInstance_18();
    key = key === VOID ? null : key;
    AbstractAnimationTask.call(this, transparent, TransparentAnimation$_init_$lambda_74dix(transparent), sequence, duration, VOID, VOID, key);
  }
  function Unzoomable() {
  }
  function _get_LOG__e5r759_4($this) {
    var tmp0 = $this.v1s_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('LOG', 1, tmp, AbstractGraphics2D$Companion$_get_LOG_$ref_iz4qv3(), null);
    return tmp0.j2();
  }
  function AbstractGraphics2D$Companion$_get_LOG_$ref_iz4qv3() {
    return function (p0) {
      return _get_LOG__e5r759_4(p0);
    };
  }
  function Companion_17() {
    Companion_instance_21 = this;
    this.v1s_1 = logger(getKClass(AbstractGraphics2D));
  }
  protoOf(Companion_17).w1s = function (color) {
    var alpha;
    switch (color.q1y_1) {
      case 255:
        alpha = 1.0;
        break;
      case 0:
        alpha = 0.0;
        break;
      default:
        alpha = color.q1y_1 / 255.0;
        break;
    }
    return 'rgba(' + color.n1y_1 + ',' + color.o1y_1 + ',' + color.p1y_1 + ',' + alpha + ')';
  };
  var Companion_instance_21;
  function Companion_getInstance_19() {
    if (Companion_instance_21 == null)
      new Companion_17();
    return Companion_instance_21;
  }
  function AbstractGraphics2D() {
    Companion_getInstance_19();
    this.p1u_1 = 0.0;
  }
  protoOf(AbstractGraphics2D).r1u = function (_set____db54di) {
    this.p1u_1 = _set____db54di;
  };
  protoOf(AbstractGraphics2D).q1u = function () {
    return this.p1u_1;
  };
  protoOf(AbstractGraphics2D).j1v = function (shape) {
    if (shape instanceof Rectangle2D) {
      this.p1v(shape);
    } else {
      if (shape instanceof RoundRectangle2D) {
        this.r1v(shape);
      } else {
        if (shape instanceof Ellipse2D) {
          this.u1v(shape);
        } else {
          if (isInterface(shape, PolylineShape)) {
            this.w1v(shape);
          } else {
            if (shape instanceof Ring2D) {
              this.t1v(shape);
            } else {
              _get_LOG__e5r759_4(Companion_getInstance_19()).ml('Unsupported shape ' + toString(shape));
              throw IllegalArgumentException_init_$Create$('Unsupported shape ' + toString(shape));
            }
          }
        }
      }
    }
  };
  protoOf(AbstractGraphics2D).k1v = function (shape) {
    if (shape instanceof Rectangle2D) {
      this.q1v(shape);
    } else {
      if (shape instanceof RoundRectangle2D) {
        this.s1v(shape);
      } else {
        if (shape instanceof Ellipse2D) {
          this.v1v(shape);
        } else {
          if (isInterface(shape, PolylineShape)) {
            this.x1v(shape);
          } else {
            if (shape instanceof Ring2D) {
              this.t1v(shape);
            } else {
              _get_LOG__e5r759_4(Companion_getInstance_19()).ml('Unsupported shape ' + toString(shape));
              throw IllegalArgumentException_init_$Create$('Unsupported shape ' + toString(shape));
            }
          }
        }
      }
    }
  };
  protoOf(AbstractGraphics2D).p1v = function (rect) {
    this.u1u(numberToInt(rect.u1h_1), numberToInt(rect.v1h_1), numberToInt(rect.w1h_1), numberToInt(rect.x1h_1));
  };
  protoOf(AbstractGraphics2D).q1v = function (rect) {
    this.y1u(numberToInt(rect.u1h_1), numberToInt(rect.v1h_1), numberToInt(rect.w1h_1), numberToInt(rect.x1h_1));
  };
  protoOf(AbstractGraphics2D).r1v = function (rect) {
    this.x1u(rect.p1a(), rect.q1a(), rect.f1c(), rect.h1c(), rect.v1i_1, rect.w1i_1);
  };
  protoOf(AbstractGraphics2D).x1u = function (x, y, w, h, arcW, arcH) {
    this.n1t();
    this.z1v(x, y, w, h, arcW, arcH);
    this.t1t();
  };
  protoOf(AbstractGraphics2D).s1v = function (rect) {
    this.b1v(rect.p1a(), rect.q1a(), rect.f1c(), rect.h1c(), rect.v1i_1, rect.w1i_1);
  };
  protoOf(AbstractGraphics2D).b1v = function (x, y, w, h, arcW, arcH) {
    this.n1t();
    this.z1v(x, y, w, h, arcW, arcH);
    this.u1t();
  };
  protoOf(AbstractGraphics2D).t1v = function (ring) {
    this.n1t();
    this.a1w(ring.p1a(), ring.q1a(), ring.f1c(), ring.h1c(), ring.e1i_1);
    this.u1t();
  };
  protoOf(AbstractGraphics2D).u1v = function (ellipse) {
    this.n1t();
    this.d1v(ellipse.j1g_1, ellipse.k1g_1, ellipse.l1g_1, ellipse.m1g_1);
    this.t1t();
  };
  protoOf(AbstractGraphics2D).v1v = function (ellipse) {
    this.n1t();
    this.d1v(ellipse.j1g_1, ellipse.k1g_1, ellipse.l1g_1, ellipse.m1g_1);
    this.u1t();
  };
  protoOf(AbstractGraphics2D).w1v = function (polyline) {
    this.n1t();
    this.y1v(polyline);
    this.t1t();
    this.v1t();
  };
  protoOf(AbstractGraphics2D).x1v = function (polyline) {
    this.n1t();
    this.y1v(polyline);
    this.u1t();
    this.v1t();
  };
  protoOf(AbstractGraphics2D).y1v = function (polyline) {
    if (polyline.t2k() < 2) {
      return Unit_instance;
    }
    this.o1t(polyline.u2k(0).kn_1, polyline.u2k(0).ln_1);
    var inductionVariable = 1;
    var last = polyline.t2k();
    if (inductionVariable < last)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        this.p1t(polyline.u2k(i).kn_1, polyline.u2k(i).ln_1);
      }
       while (inductionVariable < last);
  };
  protoOf(AbstractGraphics2D).z1v = function (x, y, w, h, arcW, arcH) {
    var tmp0 = arcW / 2;
    // Inline function 'kotlin.math.min' call
    var b = w / 2;
    var arcWW = Math.min(tmp0, b);
    var tmp0_0 = arcH / 2;
    // Inline function 'kotlin.math.min' call
    var b_0 = h / 2;
    var arcHH = Math.min(tmp0_0, b_0);
    this.o1t(x, y + arcHH);
    this.p1t(x, y + h - arcHH);
    this.q1t(x, y + h, x + arcWW, y + h);
    this.p1t(x + w - arcWW, y + h);
    this.q1t(x + w, y + h, x + w, y + h - arcHH);
    this.p1t(x + w, y + arcHH);
    this.q1t(x + w, y, x + w - arcWW, y);
    this.p1t(x + arcWW, y);
    this.q1t(x, y, x, y + arcHH);
  };
  protoOf(AbstractGraphics2D).d1v = function (x, y, w, h) {
    var kappa = 0.5522848;
    var ox = w / 2 * kappa;
    var oy = h / 2 * kappa;
    var xe = x + w;
    var ye = y + h;
    var xm = x + w / 2;
    var ym = y + h / 2;
    this.o1t(x, ym);
    this.r1t(x, ym - oy, xm - ox, y, xm, y);
    this.r1t(xm + ox, y, xe, ym - oy, xe, ym);
    this.r1t(xe, ym + oy, xm + ox, ye, xm, ye);
    this.r1t(xm - ox, ye, x, ym + oy, x, ym);
  };
  protoOf(AbstractGraphics2D).a1w = function (x, y, w, h, thickness) {
    if (!(w === h)) {
      _get_LOG__e5r759_4(Companion_getInstance_19()).nl('Graphics2DJs: requested ellipsoid ring, but only circular ring supported.');
    }
    this.s1t(x + w / 2, y + w / 2, w / 2, 0.0, 3.141592653589793 * 2, false);
    this.s1t(x + w / 2, y + w / 2, w / 2 - thickness, 0.0, 3.141592653589793 * 2, true);
  };
  function Companion_18() {
    Companion_instance_22 = this;
    this.c1t_1 = 0.7;
    this.d1t_1 = Color_init_$Create$(0, 0, 0);
    this.e1t_1 = Color_init_$Create$(255, 255, 255);
    this.f1t_1 = Color_init_$Create$(255, 0, 0);
    this.g1t_1 = Color_init_$Create$(255, 200, 0);
    this.h1t_1 = Color_init_$Create$(64, 64, 64);
    this.i1t_1 = Color_init_$Create$(128, 128, 128);
    this.j1t_1 = Color_init_$Create$(192, 192, 192);
    this.k1t_1 = Color_init_$Create$(0, 0, 255);
    this.l1t_1 = Color_init_$Create$(255, 255, 0);
    this.m1t_1 = Color_init_$Create$(18, 138, 58);
  }
  var Companion_instance_22;
  function Companion_getInstance_20() {
    if (Companion_instance_22 == null)
      new Companion_18();
    return Companion_instance_22;
  }
  function Color_init_$Init$(red, green, blue, $this) {
    Color.call($this, red, green, blue, 255);
    return $this;
  }
  function Color_init_$Create$(red, green, blue) {
    return Color_init_$Init$(red, green, blue, objectCreate(protoOf(Color)));
  }
  function Color(red, green, blue, alpha) {
    Companion_getInstance_20();
    this.n1y_1 = red;
    this.o1y_1 = green;
    this.p1y_1 = blue;
    this.q1y_1 = alpha;
  }
  protoOf(Color).v2k = function () {
    // Inline function 'kotlin.math.max' call
    var a = numberToInt(this.n1y_1 * 0.7);
    var tmp = Math.max(a, 0);
    // Inline function 'kotlin.math.max' call
    var a_0 = numberToInt(this.o1y_1 * 0.7);
    var tmp_0 = Math.max(a_0, 0);
    // Inline function 'kotlin.math.max' call
    var a_1 = numberToInt(this.p1y_1 * 0.7);
    var tmp$ret$2 = Math.max(a_1, 0);
    return Color_init_$Create$(tmp, tmp_0, tmp$ret$2);
  };
  protoOf(Color).w2k = function () {
    // Inline function 'kotlin.math.min' call
    var a = numberToInt(this.n1y_1 / 0.7);
    var tmp = Math.min(a, 255);
    // Inline function 'kotlin.math.min' call
    var a_0 = numberToInt(this.o1y_1 / 0.7);
    var tmp_0 = Math.min(a_0, 255);
    // Inline function 'kotlin.math.min' call
    var a_1 = numberToInt(this.p1y_1 / 0.7);
    var tmp$ret$2 = Math.min(a_1, 255);
    return Color_init_$Create$(tmp, tmp_0, tmp$ret$2);
  };
  protoOf(Color).x2k = function (other, factor) {
    // Inline function 'kotlin.math.round' call
    var x = this.n1y_1 + (other.n1y_1 - this.n1y_1 | 0) * factor;
    var tmp$ret$0 = round(x);
    var tmp = coerceIn(numberToInt(tmp$ret$0), numberRangeToNumber(0, 255));
    // Inline function 'kotlin.math.round' call
    var x_0 = this.o1y_1 + (other.o1y_1 - this.o1y_1 | 0) * factor;
    var tmp$ret$1 = round(x_0);
    var tmp_0 = coerceIn(numberToInt(tmp$ret$1), numberRangeToNumber(0, 255));
    // Inline function 'kotlin.math.round' call
    var x_1 = this.p1y_1 + (other.p1y_1 - this.p1y_1 | 0) * factor;
    var tmp$ret$2 = round(x_1);
    return Color_init_$Create$(tmp, tmp_0, coerceIn(numberToInt(tmp$ret$2), numberRangeToNumber(0, 255)));
  };
  protoOf(Color).r26 = function (other, factor, $super) {
    factor = factor === VOID ? 0.5 : factor;
    return $super === VOID ? this.x2k(other, factor) : $super.x2k.call(this, other, factor);
  };
  protoOf(Color).r2f = function (alpha) {
    return new Color(this.n1y_1, this.o1y_1, this.p1y_1, alpha);
  };
  protoOf(Color).y2k = function () {
    // Inline function 'kotlin.math.min' call
    var a = this.o1y_1 + 8 | 0;
    var tmp$ret$0 = Math.min(a, 255);
    return new Color(this.n1y_1, tmp$ret$0, this.p1y_1, this.q1y_1);
  };
  protoOf(Color).toString = function () {
    return 'Color(red=' + this.n1y_1 + ', green=' + this.o1y_1 + ', blue=' + this.p1y_1 + ', alpha=' + this.q1y_1 + ')';
  };
  protoOf(Color).hashCode = function () {
    var result = this.n1y_1;
    result = imul(result, 31) + this.o1y_1 | 0;
    result = imul(result, 31) + this.p1y_1 | 0;
    result = imul(result, 31) + this.q1y_1 | 0;
    return result;
  };
  protoOf(Color).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof Color))
      return false;
    if (!(this.n1y_1 === other.n1y_1))
      return false;
    if (!(this.o1y_1 === other.o1y_1))
      return false;
    if (!(this.p1y_1 === other.p1y_1))
      return false;
    if (!(this.q1y_1 === other.q1y_1))
      return false;
    return true;
  };
  function Companion_19() {
  }
  protoOf(Companion_19).z2k = function (start, end, steps, at) {
    var dRed = (end.n1y_1 - start.n1y_1 | 0) / (steps - 1 | 0);
    var dGreen = (end.o1y_1 - start.o1y_1 | 0) / (steps - 1 | 0);
    var dBlue = (end.p1y_1 - start.p1y_1 | 0) / (steps - 1 | 0);
    var red = start.n1y_1 + dRed * at;
    var green = start.o1y_1 + dGreen * at;
    var blue = start.p1y_1 + dBlue * at;
    // Inline function 'kotlin.math.roundToInt' call
    var tmp$ret$0 = roundToInt(red);
    var tmp = coerceIn(tmp$ret$0, numberRangeToNumber(0, 255));
    // Inline function 'kotlin.math.roundToInt' call
    var tmp$ret$1 = roundToInt(green);
    var tmp_0 = coerceIn(tmp$ret$1, numberRangeToNumber(0, 255));
    // Inline function 'kotlin.math.roundToInt' call
    var tmp$ret$2 = roundToInt(blue);
    return Color_init_$Create$(tmp, tmp_0, coerceIn(tmp$ret$2, numberRangeToNumber(0, 255)));
  };
  var Companion_instance_23;
  function Companion_getInstance_21() {
    return Companion_instance_23;
  }
  function createGradient($this) {
    // Inline function 'kotlin.collections.mutableListOf' call
    var result = ArrayList_init_$Create$();
    var inductionVariable = 0;
    var last = $this.c2l_1;
    if (inductionVariable < last)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        result.h(Companion_instance_23.z2k($this.a2l_1, $this.b2l_1, $this.c2l_1, i));
      }
       while (inductionVariable < last);
    return result;
  }
  function ColorGradient$colors$delegate$lambda(this$0) {
    return function () {
      return createGradient(this$0);
    };
  }
  function ColorGradient$_get_colors_$ref_ghx52z() {
    return function (p0) {
      return p0.e2l();
    };
  }
  function ColorGradient(start, end, steps) {
    steps = steps === VOID ? 100 : steps;
    this.a2l_1 = start;
    this.b2l_1 = end;
    this.c2l_1 = steps;
    var tmp = this;
    tmp.d2l_1 = lazy(ColorGradient$colors$delegate$lambda(this));
  }
  protoOf(ColorGradient).e2l = function () {
    var tmp0 = this.d2l_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('colors', 1, tmp, ColorGradient$_get_colors_$ref_ghx52z(), null);
    return tmp0.j2();
  };
  protoOf(ColorGradient).f2l = function (x) {
    var tmp = this.e2l();
    // Inline function 'kotlin.math.roundToInt' call
    var this_0 = coerceIn_0(x, rangeTo(0.0, 1.0)) * this.c2l_1;
    var tmp$ret$0 = roundToInt(this_0);
    return tmp.l(coerceIn(tmp$ret$0, until(0, this.c2l_1)));
  };
  function _get_colors__hj58bp($this) {
    var tmp0 = $this.k2l_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('colors', 1, tmp, CompositeColorGradient$_get_colors_$ref_7qthb2(), null);
    return tmp0.j2();
  }
  function createGradient_0($this) {
    // Inline function 'kotlin.collections.map' call
    var this_0 = (new ColorGradient($this.h2l_1, $this.i2l_1, $this.j2l_1)).e2l();
    // Inline function 'kotlin.collections.mapTo' call
    var destination = ArrayList_init_$Create$_0(collectionSizeOrDefault(this_0, 10));
    var _iterator__ex2g4s = this_0.i();
    while (_iterator__ex2g4s.j()) {
      var item = _iterator__ex2g4s.k();
      var tmp$ret$2 = new CompositeColor(item, $this.g2l_1);
      destination.h(tmp$ret$2);
    }
    return toList(destination);
  }
  function CompositeColorGradient$colors$delegate$lambda(this$0) {
    return function () {
      return createGradient_0(this$0);
    };
  }
  function CompositeColorGradient$_get_colors_$ref_7qthb2() {
    return function (p0) {
      return _get_colors__hj58bp(p0);
    };
  }
  function CompositeColorGradient(background, start, end, steps) {
    steps = steps === VOID ? 100 : steps;
    this.g2l_1 = background;
    this.h2l_1 = start;
    this.i2l_1 = end;
    this.j2l_1 = steps;
    var tmp = this;
    tmp.k2l_1 = lazy(CompositeColorGradient$colors$delegate$lambda(this));
  }
  protoOf(CompositeColorGradient).f2l = function (x) {
    var tmp = _get_colors__hj58bp(this);
    // Inline function 'kotlin.math.roundToInt' call
    var this_0 = coerceIn_0(x, rangeTo(0.0, 1.0)) * this.j2l_1;
    var tmp$ret$0 = roundToInt(this_0);
    return tmp.l(coerceIn(tmp$ret$0, until(0, this.j2l_1)));
  };
  function Companion_20() {
    this.l2l_1 = 0.083333336;
    this.m2l_1 = 0.6;
  }
  protoOf(Companion_20).n2l = function (foregroundColor, backgroundColor) {
    return new CompositeColor(foregroundColor, backgroundColor, foregroundColor.w2k().w2k());
  };
  protoOf(Companion_20).o2l = function (foregroundColor, backgroundColor) {
    return new CompositeColor(foregroundColor, backgroundColor, foregroundColor.v2k());
  };
  var Companion_instance_24;
  function Companion_getInstance_22() {
    return Companion_instance_24;
  }
  function CompositeColor(foregroundColor, backgroundColor, textColor) {
    foregroundColor = foregroundColor === VOID ? Themes_getInstance().h2g().z2f_1.c1u().x1x_1 : foregroundColor;
    backgroundColor = backgroundColor === VOID ? Themes_getInstance().h2g().x2f_1.c1u().y1x_1 : backgroundColor;
    textColor = textColor === VOID ? foregroundColor : textColor;
    this.x1x_1 = foregroundColor;
    this.y1x_1 = backgroundColor;
    this.z1x_1 = textColor;
  }
  protoOf(CompositeColor).p2l = function () {
    // Inline function 'kotlin.math.ceil' call
    var x = (this.y1x_1.n1y_1 + this.z1x_1.n1y_1 | 0) / 2.0;
    var tmp$ret$0 = Math.ceil(x);
    var tmp = numberToInt(tmp$ret$0);
    // Inline function 'kotlin.math.ceil' call
    var x_0 = (this.y1x_1.o1y_1 + this.z1x_1.o1y_1 | 0) / 2.0;
    var tmp$ret$1 = Math.ceil(x_0);
    var tmp_0 = numberToInt(tmp$ret$1);
    // Inline function 'kotlin.math.ceil' call
    var x_1 = (this.y1x_1.p1y_1 + this.z1x_1.p1y_1 | 0) / 2.0;
    var tmp$ret$2 = Math.ceil(x_1);
    return Color_init_$Create$(tmp, tmp_0, numberToInt(tmp$ret$2));
  };
  protoOf(CompositeColor).q2l = function (color) {
    return new CompositeColor(this.x1x_1, color, this.z1x_1);
  };
  protoOf(CompositeColor).r2f = function (alpha) {
    return new CompositeColor(this.x1x_1.r2f(alpha), this.y1x_1.r2f(alpha), this.z1x_1.r2f(alpha));
  };
  protoOf(CompositeColor).r2l = function () {
    return new CompositeColor(this.x1x_1, this.y1x_1.x2k(this.z1x_1, 0.083333336), this.z1x_1);
  };
  protoOf(CompositeColor).s2l = function () {
    return new CompositeColor(this.x1x_1, this.y1x_1, this.z1x_1.x2k(this.y1x_1, 0.6));
  };
  protoOf(CompositeColor).v2k = function () {
    return new CompositeColor(this.x1x_1.v2k(), this.y1x_1.v2k(), this.z1x_1.v2k());
  };
  protoOf(CompositeColor).toString = function () {
    return 'CompositeColor(foregroundColor=' + this.x1x_1.toString() + ', backgroundColor=' + this.y1x_1.toString() + ', textColor=' + this.z1x_1.toString() + ')';
  };
  protoOf(CompositeColor).hashCode = function () {
    var result = this.x1x_1.hashCode();
    result = imul(result, 31) + this.y1x_1.hashCode() | 0;
    result = imul(result, 31) + this.z1x_1.hashCode() | 0;
    return result;
  };
  protoOf(CompositeColor).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof CompositeColor))
      return false;
    if (!this.x1x_1.equals(other.x1x_1))
      return false;
    if (!this.y1x_1.equals(other.y1x_1))
      return false;
    if (!this.z1x_1.equals(other.z1x_1))
      return false;
    return true;
  };
  var Cursor_DEFAULT_instance;
  var Cursor_WAIT_instance;
  var Cursor_CLICK_instance;
  var Cursor_MOVE_instance;
  var Cursor_CROSSHAIR_instance;
  var Cursor_NW_RESIZE_instance;
  var Cursor_N_RESIZE_instance;
  var Cursor_NE_RESIZE_instance;
  var Cursor_E_RESIZE_instance;
  var Cursor_SE_RESIZE_instance;
  var Cursor_S_RESIZE_instance;
  var Cursor_SW_RESIZE_instance;
  var Cursor_W_RESIZE_instance;
  var Cursor_TEXT_instance;
  var Cursor_entriesInitialized;
  function Cursor_initEntries() {
    if (Cursor_entriesInitialized)
      return Unit_instance;
    Cursor_entriesInitialized = true;
    Cursor_DEFAULT_instance = new Cursor('DEFAULT', 0);
    Cursor_WAIT_instance = new Cursor('WAIT', 1);
    Cursor_CLICK_instance = new Cursor('CLICK', 2);
    Cursor_MOVE_instance = new Cursor('MOVE', 3);
    Cursor_CROSSHAIR_instance = new Cursor('CROSSHAIR', 4);
    Cursor_NW_RESIZE_instance = new Cursor('NW_RESIZE', 5);
    Cursor_N_RESIZE_instance = new Cursor('N_RESIZE', 6);
    Cursor_NE_RESIZE_instance = new Cursor('NE_RESIZE', 7);
    Cursor_E_RESIZE_instance = new Cursor('E_RESIZE', 8);
    Cursor_SE_RESIZE_instance = new Cursor('SE_RESIZE', 9);
    Cursor_S_RESIZE_instance = new Cursor('S_RESIZE', 10);
    Cursor_SW_RESIZE_instance = new Cursor('SW_RESIZE', 11);
    Cursor_W_RESIZE_instance = new Cursor('W_RESIZE', 12);
    Cursor_TEXT_instance = new Cursor('TEXT', 13);
  }
  function Cursor(name, ordinal) {
    Enum.call(this, name, ordinal);
  }
  function Cursor_DEFAULT_getInstance() {
    Cursor_initEntries();
    return Cursor_DEFAULT_instance;
  }
  function Cursor_CLICK_getInstance() {
    Cursor_initEntries();
    return Cursor_CLICK_instance;
  }
  function Cursor_MOVE_getInstance() {
    Cursor_initEntries();
    return Cursor_MOVE_instance;
  }
  function Cursor_CROSSHAIR_getInstance() {
    Cursor_initEntries();
    return Cursor_CROSSHAIR_instance;
  }
  function Cursor_NW_RESIZE_getInstance() {
    Cursor_initEntries();
    return Cursor_NW_RESIZE_instance;
  }
  function Cursor_N_RESIZE_getInstance() {
    Cursor_initEntries();
    return Cursor_N_RESIZE_instance;
  }
  function Cursor_NE_RESIZE_getInstance() {
    Cursor_initEntries();
    return Cursor_NE_RESIZE_instance;
  }
  function Cursor_E_RESIZE_getInstance() {
    Cursor_initEntries();
    return Cursor_E_RESIZE_instance;
  }
  function Cursor_SE_RESIZE_getInstance() {
    Cursor_initEntries();
    return Cursor_SE_RESIZE_instance;
  }
  function Cursor_S_RESIZE_getInstance() {
    Cursor_initEntries();
    return Cursor_S_RESIZE_instance;
  }
  function Cursor_SW_RESIZE_getInstance() {
    Cursor_initEntries();
    return Cursor_SW_RESIZE_instance;
  }
  function Cursor_W_RESIZE_getInstance() {
    Cursor_initEntries();
    return Cursor_W_RESIZE_instance;
  }
  function fillProperties_0($this, properties) {
    properties.et('draw.graphics.shadow', false);
    properties.et('draw.graphics.dropShadow.offset', 2);
  }
  function predefineColors($this, repository) {
    repository.b2n(new PredefinedColor(PredefinedColorIdentity_White_getInstance(), $this.k2m_1));
    repository.b2n(new PredefinedColor(PredefinedColorIdentity_Black_getInstance(), $this.l2m_1));
    repository.b2n(new PredefinedColor(PredefinedColorIdentity_Gray_getInstance(), $this.m2m_1));
    repository.b2n(new PredefinedColor(PredefinedColorIdentity_Yellow_getInstance(), $this.a2m_1));
    repository.b2n(new PredefinedColor(PredefinedColorIdentity_Brown_getInstance(), $this.g2m_1));
    repository.b2n(new PredefinedColor(PredefinedColorIdentity_Red_getInstance(), $this.u2l_1));
    repository.b2n(new PredefinedColor(PredefinedColorIdentity_Violet_getInstance(), $this.c2m_1));
    repository.b2n(new PredefinedColor(PredefinedColorIdentity_Blue_getInstance(), $this.w2l_1));
    repository.b2n(new PredefinedColor(PredefinedColorIdentity_Turquoise_getInstance(), $this.i2m_1));
    repository.b2n(new PredefinedColor(PredefinedColorIdentity_Green_getInstance(), $this.y2l_1));
  }
  function predefineStrokes($this, repository) {
    repository.f2n(new PredefinedStroke(PredefinedStrokeIdentity_ThinDotted_getInstance(), $this.p2m_1));
    repository.f2n(new PredefinedStroke(PredefinedStrokeIdentity_ThinSolid_getInstance(), $this.q2m_1));
    repository.f2n(new PredefinedStroke(PredefinedStrokeIdentity_ThinDashed_getInstance(), $this.r2m_1));
    repository.f2n(new PredefinedStroke(PredefinedStrokeIdentity_NormalDotted_getInstance(), $this.s2m_1));
    repository.f2n(new PredefinedStroke(PredefinedStrokeIdentity_NormalSolid_getInstance(), $this.t2m_1));
    repository.f2n(new PredefinedStroke(PredefinedStrokeIdentity_NormalDashed_getInstance(), $this.u2m_1));
    repository.f2n(new PredefinedStroke(PredefinedStrokeIdentity_ThickDotted_getInstance(), $this.v2m_1));
    repository.f2n(new PredefinedStroke(PredefinedStrokeIdentity_ThickSolid_getInstance(), $this.w2m_1));
    repository.f2n(new PredefinedStroke(PredefinedStrokeIdentity_ThickDashed_getInstance(), $this.x2m_1));
  }
  function DrawGraphicsModule() {
    DrawGraphicsModule_instance = this;
    AbstractModule.call(this);
    this.u2l_1 = Companion_instance_24.o2l(Color_init_$Create$(236, 35, 46), Color_init_$Create$(248, 170, 145));
    this.v2l_1 = new CompositeColor(Color_init_$Create$(236, 35, 46), Color_init_$Create$(90, 3, 7), Color_init_$Create$(255, 204, 204));
    this.w2l_1 = Companion_instance_24.o2l(Color_init_$Create$(72, 186, 233), Color_init_$Create$(185, 223, 245));
    this.x2l_1 = Companion_instance_24.n2l(Color_init_$Create$(44, 116, 179), Color_init_$Create$(20, 66, 114));
    this.y2l_1 = Companion_instance_24.o2l(Color_init_$Create$(115, 191, 91), Color_init_$Create$(198, 226, 184));
    this.z2l_1 = Companion_instance_24.n2l(Color_init_$Create$(115, 191, 91), Color_init_$Create$(7, 87, 9));
    this.a2m_1 = Companion_instance_24.o2l(Color_init_$Create$(254, 209, 58), Color_init_$Create$(251, 245, 183));
    this.b2m_1 = new CompositeColor(Color_init_$Create$(245, 235, 62), Color_init_$Create$(67, 69, 10), Color_init_$Create$(255, 255, 228));
    this.c2m_1 = Companion_instance_24.o2l(Color_init_$Create$(91, 84, 161), Color_init_$Create$(211, 207, 231));
    this.d2m_1 = Companion_instance_24.n2l(Color_init_$Create$(125, 108, 171), Color_init_$Create$(55, 14, 91));
    this.e2m_1 = Companion_instance_24.o2l(Color_init_$Create$(234, 34, 123), Color_init_$Create$(250, 214, 223));
    this.f2m_1 = Companion_instance_24.n2l(Color_init_$Create$(188, 126, 179), Color_init_$Create$(104, 8, 89));
    this.g2m_1 = Companion_instance_24.o2l(Color_init_$Create$(149, 92, 11), Color_init_$Create$(234, 173, 85));
    this.h2m_1 = new CompositeColor(Color_init_$Create$(203, 119, 18), Color_init_$Create$(94, 65, 4), Color_init_$Create$(255, 197, 109));
    this.i2m_1 = Companion_instance_24.o2l(Color_init_$Create$(69, 181, 172), Color_init_$Create$(187, 255, 242));
    this.j2m_1 = Companion_instance_24.n2l(Color_init_$Create$(69, 213, 203), Color_init_$Create$(12, 86, 103));
    this.k2m_1 = new CompositeColor(Companion_getInstance_20().d1t_1, Companion_getInstance_20().e1t_1);
    this.l2m_1 = new CompositeColor(Companion_getInstance_20().e1t_1, Companion_getInstance_20().d1t_1);
    this.m2m_1 = new CompositeColor(Color_init_$Create$(114, 114, 114), Color_init_$Create$(227, 227, 227));
    this.n2m_1 = Companion_instance_24.n2l(Color_init_$Create$(104, 104, 104), Color_init_$Create$(64, 64, 64));
    var tmp = this;
    // Inline function 'kotlin.floatArrayOf' call
    tmp.o2m_1 = new Float32Array([1.0, 5.0]);
    this.p2m_1 = new Stroke(0.5, VOID, VOID, VOID, this.o2m_1);
    this.q2m_1 = new Stroke(0.5);
    var tmp_0 = this;
    // Inline function 'kotlin.floatArrayOf' call
    var tmp$ret$1 = new Float32Array([5.0]);
    tmp_0.r2m_1 = new Stroke(0.5, VOID, VOID, VOID, tmp$ret$1);
    this.s2m_1 = new Stroke(1.5, VOID, VOID, VOID, this.o2m_1);
    this.t2m_1 = new Stroke(1.5);
    var tmp_1 = this;
    // Inline function 'kotlin.floatArrayOf' call
    var tmp$ret$2 = new Float32Array([5.0]);
    tmp_1.u2m_1 = new Stroke(1.5, VOID, VOID, VOID, tmp$ret$2);
    this.v2m_1 = new Stroke(3.0, VOID, VOID, VOID, this.o2m_1);
    this.w2m_1 = new Stroke(3.0);
    var tmp_2 = this;
    // Inline function 'kotlin.floatArrayOf' call
    var tmp$ret$3 = new Float32Array([5.0]);
    tmp_2.x2m_1 = new Stroke(3.0, VOID, VOID, VOID, tmp$ret$3);
  }
  protoOf(DrawGraphicsModule).to = function () {
    BaseModule_getInstance().vo();
    predefineColors(this, PredefinedColorRepository_getInstance());
    predefineStrokes(this, PredefinedStrokeRepository_getInstance());
    fillProperties_0(this, DrawModule_getInstance().l2a_1);
  };
  var DrawGraphicsModule_instance;
  function DrawGraphicsModule_getInstance() {
    if (DrawGraphicsModule_instance == null)
      new DrawGraphicsModule();
    return DrawGraphicsModule_instance;
  }
  function _get_useShadow__eh2mae($this) {
    return BaseModule_getInstance().zo_1.ht('draw.graphics.shadow');
  }
  function DropShadow() {
    this.g2n_1 = 'draw.graphics.dropShadow.offset';
    this.h2n_1 = 'draw.graphics.shadow';
  }
  protoOf(DropShadow).i2n = function () {
    return BaseModule_getInstance().zo_1.kt('draw.graphics.dropShadow.offset');
  };
  protoOf(DropShadow).j2n = function (context) {
    if (_get_useShadow__eh2mae(this)) {
      var p = Geometry_instance.v1g(this.i2n(), this.i2n(), -context.j1z_1.q1u());
      context.j1z_1.l1d(p.kn_1, p.ln_1);
    }
  };
  protoOf(DropShadow).k2n = function (context) {
    if (_get_useShadow__eh2mae(this)) {
      var p = Geometry_instance.v1g(this.i2n(), this.i2n(), -context.j1z_1.q1u());
      context.j1z_1.l1d(-p.kn_1, -p.ln_1);
    }
  };
  protoOf(DropShadow).l2n = function (context, transparency, drawer) {
    if (_get_useShadow__eh2mae(this) && transparency === 255) {
      this.j2n(context);
      context.j1z_1.b1u(context.q1z(Themes_getInstance().h2g().c2g_1).x1x_1);
      drawer(context);
      this.k2n(context);
    }
  };
  protoOf(DropShadow).m2n = function (rect, rotation) {
    if (_get_useShadow__eh2mae(this)) {
      switch (rotation.l2_1) {
        case 0:
          rect.q1c(0.0, 0.0, this.i2n(), this.i2n());
          break;
        case 1:
          rect.q1c(0.0, this.i2n(), this.i2n(), 0.0);
          break;
        case 2:
          rect.q1c(this.i2n(), this.i2n(), 0.0, 0.0);
          break;
        case 3:
          rect.q1c(this.i2n(), 0.0, 0.0, this.i2n());
          break;
        default:
          noWhenBranchMatchedException();
          break;
      }
    }
  };
  var DropShadow_instance;
  function DropShadow_getInstance() {
    return DropShadow_instance;
  }
  function FontImpl(family, style, size) {
    family = family === VOID ? LogicalFontFamily_SANS_SERIF_getInstance() : family;
    style = style === VOID ? FontStyle_PLAIN_getInstance().p2n_1 : style;
    size = size === VOID ? 12 : size;
    this.g26_1 = family;
    this.h26_1 = style;
    this.i26_1 = size;
  }
  protoOf(FontImpl).c1s = function () {
    return this.g26_1;
  };
  protoOf(FontImpl).o = function () {
    return this.i26_1;
  };
  protoOf(FontImpl).a1s = function () {
    return !((this.h26_1 & FontStyle_BOLD_getInstance().p2n_1) === 0);
  };
  protoOf(FontImpl).b1s = function () {
    return !((this.h26_1 & FontStyle_ITALIC_getInstance().p2n_1) === 0);
  };
  protoOf(FontImpl).j26 = function (style) {
    var tmp;
    if (style.equals(FontStyle_PLAIN_getInstance())) {
      tmp = this.q2n(VOID, FontStyle_PLAIN_getInstance().p2n_1);
    } else {
      tmp = this.q2n(VOID, this.h26_1 | style.p2n_1);
    }
    return tmp;
  };
  protoOf(FontImpl).k2j = function (size) {
    return this.q2n(VOID, VOID, size);
  };
  protoOf(FontImpl).r2n = function (family) {
    return this.q2n(family);
  };
  protoOf(FontImpl).k2h = function (factor) {
    var tmp;
    if (factor === 1.0) {
      tmp = this;
    } else {
      tmp = this.k2j(numberToInt(this.i26_1 * factor));
    }
    return tmp;
  };
  protoOf(FontImpl).s2n = function (family, style, size) {
    return new FontImpl(family, style, size);
  };
  protoOf(FontImpl).q2n = function (family, style, size, $super) {
    family = family === VOID ? this.g26_1 : family;
    style = style === VOID ? this.h26_1 : style;
    size = size === VOID ? this.i26_1 : size;
    return $super === VOID ? this.s2n(family, style, size) : $super.s2n.call(this, family, style, size);
  };
  protoOf(FontImpl).toString = function () {
    return 'FontImpl(family=' + toString(this.g26_1) + ', style=' + this.h26_1 + ', size=' + this.i26_1 + ')';
  };
  protoOf(FontImpl).hashCode = function () {
    var result = hashCode(this.g26_1);
    result = imul(result, 31) + this.h26_1 | 0;
    result = imul(result, 31) + this.i26_1 | 0;
    return result;
  };
  protoOf(FontImpl).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof FontImpl))
      return false;
    if (!equals(this.g26_1, other.g26_1))
      return false;
    if (!(this.h26_1 === other.h26_1))
      return false;
    if (!(this.i26_1 === other.i26_1))
      return false;
    return true;
  };
  var FontStyle_PLAIN_instance;
  var FontStyle_BOLD_instance;
  var FontStyle_ITALIC_instance;
  var FontStyle_entriesInitialized;
  function FontStyle_initEntries() {
    if (FontStyle_entriesInitialized)
      return Unit_instance;
    FontStyle_entriesInitialized = true;
    FontStyle_PLAIN_instance = new FontStyle('PLAIN', 0, 0);
    FontStyle_BOLD_instance = new FontStyle('BOLD', 1, 1);
    FontStyle_ITALIC_instance = new FontStyle('ITALIC', 2, 2);
  }
  function FontStyle(name, ordinal, value) {
    Enum.call(this, name, ordinal);
    this.p2n_1 = value;
  }
  var LogicalFontFamily_SERIF_instance;
  var LogicalFontFamily_SANS_SERIF_instance;
  var LogicalFontFamily_MONOSPACED_instance;
  var LogicalFontFamily_DIALOG_instance;
  function Companion_21() {
  }
  var Companion_instance_25;
  function Companion_getInstance_23() {
    return Companion_instance_25;
  }
  function values() {
    return [LogicalFontFamily_SERIF_getInstance(), LogicalFontFamily_SANS_SERIF_getInstance(), LogicalFontFamily_MONOSPACED_getInstance(), LogicalFontFamily_DIALOG_getInstance()];
  }
  function get_entries() {
    if ($ENTRIES == null)
      $ENTRIES = enumEntries(values());
    return $ENTRIES;
  }
  var LogicalFontFamily_entriesInitialized;
  function LogicalFontFamily_initEntries() {
    if (LogicalFontFamily_entriesInitialized)
      return Unit_instance;
    LogicalFontFamily_entriesInitialized = true;
    LogicalFontFamily_SERIF_instance = new LogicalFontFamily('SERIF', 0, 'Serif', 'serif');
    LogicalFontFamily_SANS_SERIF_instance = new LogicalFontFamily('SANS_SERIF', 1, 'SansSerif', 'sans-serif');
    LogicalFontFamily_MONOSPACED_instance = new LogicalFontFamily('MONOSPACED', 2, 'Monospaced', 'monospace');
    LogicalFontFamily_DIALOG_instance = new LogicalFontFamily('DIALOG', 3, 'Dialog', 'sans-serif');
  }
  var $ENTRIES;
  function LogicalFontFamily(name, ordinal, javaName, jsName) {
    Enum.call(this, name, ordinal);
    this.g1s_1 = javaName;
    this.h1s_1 = jsName;
  }
  protoOf(LogicalFontFamily).d1s = function () {
    return this.g1s_1;
  };
  function FontStyle_PLAIN_getInstance() {
    FontStyle_initEntries();
    return FontStyle_PLAIN_instance;
  }
  function FontStyle_BOLD_getInstance() {
    FontStyle_initEntries();
    return FontStyle_BOLD_instance;
  }
  function FontStyle_ITALIC_getInstance() {
    FontStyle_initEntries();
    return FontStyle_ITALIC_instance;
  }
  function LogicalFontFamily_SERIF_getInstance() {
    LogicalFontFamily_initEntries();
    return LogicalFontFamily_SERIF_instance;
  }
  function LogicalFontFamily_SANS_SERIF_getInstance() {
    LogicalFontFamily_initEntries();
    return LogicalFontFamily_SANS_SERIF_instance;
  }
  function LogicalFontFamily_MONOSPACED_getInstance() {
    LogicalFontFamily_initEntries();
    return LogicalFontFamily_MONOSPACED_instance;
  }
  function LogicalFontFamily_DIALOG_getInstance() {
    LogicalFontFamily_initEntries();
    return LogicalFontFamily_DIALOG_instance;
  }
  function Graphics2D() {
  }
  function Icon() {
  }
  function KnobIcon(dim) {
    this.u2n_1 = dim;
  }
  protoOf(KnobIcon).o2f = function () {
    return this.u2n_1;
  };
  protoOf(KnobIcon).q2f = function (context, location, color) {
    context.j1z_1.b1u(color.x1x_1);
    // Inline function 'io.antarescircuit.jabbah.draw.DrawContext.translated' call
    context.j1z_1.l1d(location.kn_1, location.ln_1);
    context.j1z_1.c1v(0.0, 0.0, this.u2n_1.u1e_1, this.u2n_1.v1e_1);
    context.j1z_1.f1v(this.u2n_1.u1e_1 / 2 - 3, this.u2n_1.v1e_1 / 2 - 3, 6.0, 6.0);
    context.j1z_1.t1u(this.u2n_1.u1e_1 / 2, this.u2n_1.v1e_1 / 2, this.u2n_1.u1e_1 / 2 + 4, this.u2n_1.v1e_1 / 2 - 4);
    context.j1z_1.l1d(-location.kn_1, -location.ln_1);
  };
  function RemoveIcon(dim) {
    this.v2n_1 = dim;
  }
  protoOf(RemoveIcon).o2f = function () {
    return this.v2n_1;
  };
  protoOf(RemoveIcon).q2f = function (context, location, color) {
    context.j1z_1.b1u(color.x1x_1);
    context.j1z_1.c1v(location.kn_1, location.ln_1, this.v2n_1.u1e_1, this.v2n_1.v1e_1);
    context.j1z_1.t1u(location.kn_1 + this.v2n_1.u1e_1 / 3, location.ln_1 + this.v2n_1.v1e_1 / 2, location.kn_1 + 2 * this.v2n_1.u1e_1 / 3, location.ln_1 + this.v2n_1.v1e_1 / 2);
  };
  function AddIcon(dim) {
    this.w2n_1 = dim;
  }
  protoOf(AddIcon).o2f = function () {
    return this.w2n_1;
  };
  protoOf(AddIcon).q2f = function (context, location, color) {
    context.j1z_1.b1u(color.x1x_1);
    context.j1z_1.c1v(location.kn_1, location.ln_1, this.w2n_1.u1e_1, this.w2n_1.v1e_1);
    context.j1z_1.t1u(location.kn_1 + this.w2n_1.u1e_1 / 3, location.ln_1 + this.w2n_1.v1e_1 / 2, location.kn_1 + 2 * this.w2n_1.u1e_1 / 3, location.ln_1 + this.w2n_1.v1e_1 / 2);
    context.j1z_1.t1u(location.kn_1 + this.w2n_1.u1e_1 / 2, location.ln_1 + this.w2n_1.v1e_1 / 3, location.kn_1 + this.w2n_1.u1e_1 / 2, location.ln_1 + 2 * this.w2n_1.v1e_1 / 3);
  };
  function DeleteIcon() {
    this.x2n_1 = Dimension2D_init_$Create$(20, 20);
  }
  protoOf(DeleteIcon).o2f = function () {
    return this.x2n_1;
  };
  protoOf(DeleteIcon).q2f = function (context, location, color) {
    context.j1z_1.b1u(color.x1x_1);
    // Inline function 'io.antarescircuit.jabbah.draw.DrawContext.translated' call
    context.j1z_1.l1d(location.kn_1, location.ln_1);
    context.j1z_1.c1v(0.0, 0.0, this.x2n_1.u1e_1, this.x2n_1.v1e_1);
    context.j1z_1.s1u(4, 6, 16, 6);
    context.j1z_1.s1u(6, 6, 8, 14);
    context.j1z_1.s1u(8, 14, 12, 14);
    context.j1z_1.s1u(12, 14, 14, 6);
    context.j1z_1.y1u(9, 4, 2, 2);
    context.j1z_1.l1d(-location.kn_1, -location.ln_1);
  };
  var ImageType_SVG_instance;
  var ImageType_JPG_instance;
  var ImageType_GIF_instance;
  var ImageType_PNG_instance;
  function Companion_22() {
  }
  protoOf(Companion_22).h1f = function (customName) {
    var tmp0 = get_entries_0();
    var tmp$ret$0;
    $l$block: {
      // Inline function 'kotlin.collections.firstOrNull' call
      var _iterator__ex2g4s = tmp0.i();
      while (_iterator__ex2g4s.j()) {
        var element = _iterator__ex2g4s.k();
        if (element.w1r_1 === customName) {
          tmp$ret$0 = element;
          break $l$block;
        }
      }
      tmp$ret$0 = null;
    }
    var tmp0_elvis_lhs = tmp$ret$0;
    var tmp;
    if (tmp0_elvis_lhs == null) {
      throw IllegalArgumentException_init_$Create$("Unknown ImageType '" + customName + "'");
    } else {
      tmp = tmp0_elvis_lhs;
    }
    return tmp;
  };
  protoOf(Companion_22).y2n = function (mimeType) {
    var tmp0 = get_entries_0();
    var tmp$ret$0;
    $l$block: {
      // Inline function 'kotlin.collections.firstOrNull' call
      var _iterator__ex2g4s = tmp0.i();
      while (_iterator__ex2g4s.j()) {
        var element = _iterator__ex2g4s.k();
        if (element.y1r_1 === mimeType) {
          tmp$ret$0 = element;
          break $l$block;
        }
      }
      tmp$ret$0 = null;
    }
    return tmp$ret$0;
  };
  var Companion_instance_26;
  function Companion_getInstance_24() {
    return Companion_instance_26;
  }
  function values_0() {
    return [ImageType_SVG_getInstance(), ImageType_JPG_getInstance(), ImageType_GIF_getInstance(), ImageType_PNG_getInstance()];
  }
  function get_entries_0() {
    if ($ENTRIES_0 == null)
      $ENTRIES_0 = enumEntries(values_0());
    return $ENTRIES_0;
  }
  var ImageType_entriesInitialized;
  function ImageType_initEntries() {
    if (ImageType_entriesInitialized)
      return Unit_instance;
    ImageType_entriesInitialized = true;
    ImageType_SVG_instance = new ImageType('SVG', 0, 'SVG', 'svg', 'image/svg+xml', false);
    ImageType_JPG_instance = new ImageType('JPG', 1, 'JPG', 'jpg', 'image/jpeg', true);
    ImageType_GIF_instance = new ImageType('GIF', 2, 'GIF', 'gif', 'image/gif', true);
    ImageType_PNG_instance = new ImageType('PNG', 3, 'PNG', 'png', 'image/png', true);
  }
  var $ENTRIES_0;
  function ImageType(name, ordinal, customName, fileExtension, mimeType, isRaster) {
    Enum.call(this, name, ordinal);
    this.w1r_1 = customName;
    this.x1r_1 = fileExtension;
    this.y1r_1 = mimeType;
    this.z1r_1 = isRaster;
  }
  protoOf(ImageType).toString = function () {
    return this.w1r_1;
  };
  function ImageType_SVG_getInstance() {
    ImageType_initEntries();
    return ImageType_SVG_instance;
  }
  function ImageType_JPG_getInstance() {
    ImageType_initEntries();
    return ImageType_JPG_instance;
  }
  function ImageType_GIF_getInstance() {
    ImageType_initEntries();
    return ImageType_GIF_instance;
  }
  function ImageType_PNG_getInstance() {
    ImageType_initEntries();
    return ImageType_PNG_instance;
  }
  function LinearColorGradient(p1, color1, p2, color2) {
    this.r1s_1 = p1;
    this.s1s_1 = color1;
    this.t1s_1 = p2;
    this.u1s_1 = color2;
  }
  protoOf(LinearColorGradient).toString = function () {
    return 'LinearColorGradient(p1=' + this.r1s_1.toString() + ', color1=' + this.s1s_1.toString() + ', p2=' + this.t1s_1.toString() + ', color2=' + this.u1s_1.toString() + ')';
  };
  protoOf(LinearColorGradient).hashCode = function () {
    var result = this.r1s_1.hashCode();
    result = imul(result, 31) + this.s1s_1.hashCode() | 0;
    result = imul(result, 31) + this.t1s_1.hashCode() | 0;
    result = imul(result, 31) + this.u1s_1.hashCode() | 0;
    return result;
  };
  protoOf(LinearColorGradient).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof LinearColorGradient))
      return false;
    if (!this.r1s_1.equals(other.r1s_1))
      return false;
    if (!this.s1s_1.equals(other.s1s_1))
      return false;
    if (!this.t1s_1.equals(other.t1s_1))
      return false;
    if (!this.u1s_1.equals(other.u1s_1))
      return false;
    return true;
  };
  function PredefinedColor(identity, color) {
    this.z2n_1 = identity;
    this.a2o_1 = color;
  }
  protoOf(PredefinedColor).m2 = function () {
    return this.z2n_1.d2o_1;
  };
  protoOf(PredefinedColor).mq = function () {
    return this.z2n_1.mq();
  };
  protoOf(PredefinedColor).toString = function () {
    return this.mq();
  };
  protoOf(PredefinedColor).hashCode = function () {
    var result = this.z2n_1.hashCode();
    result = imul(result, 31) + this.a2o_1.hashCode() | 0;
    return result;
  };
  protoOf(PredefinedColor).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof PredefinedColor))
      return false;
    if (!this.z2n_1.equals(other.z2n_1))
      return false;
    if (!this.a2o_1.equals(other.a2o_1))
      return false;
    return true;
  };
  var PredefinedColorIdentity_White_instance;
  var PredefinedColorIdentity_Black_instance;
  var PredefinedColorIdentity_Gray_instance;
  var PredefinedColorIdentity_Yellow_instance;
  var PredefinedColorIdentity_Brown_instance;
  var PredefinedColorIdentity_Red_instance;
  var PredefinedColorIdentity_Violet_instance;
  var PredefinedColorIdentity_Blue_instance;
  var PredefinedColorIdentity_Turquoise_instance;
  var PredefinedColorIdentity_Green_instance;
  function Companion_23() {
  }
  protoOf(Companion_23).f2o = function (idName) {
    // Inline function 'kotlin.collections.map' call
    var this_0 = values_1();
    // Inline function 'kotlin.collections.mapTo' call
    var destination = ArrayList_init_$Create$_0(this_0.length);
    var inductionVariable = 0;
    var last = this_0.length;
    while (inductionVariable < last) {
      var item = this_0[inductionVariable];
      inductionVariable = inductionVariable + 1 | 0;
      var tmp$ret$2 = item.d2o_1;
      destination.h(tmp$ret$2);
    }
    return destination.n(idName);
  };
  protoOf(Companion_23).g2o = function (idName) {
    var tmp0 = values_1();
    var tmp$ret$0;
    $l$block: {
      // Inline function 'kotlin.collections.first' call
      var inductionVariable = 0;
      var last = tmp0.length;
      while (inductionVariable < last) {
        var element = tmp0[inductionVariable];
        inductionVariable = inductionVariable + 1 | 0;
        if (element.d2o_1 === idName) {
          tmp$ret$0 = element;
          break $l$block;
        }
      }
      throw NoSuchElementException_init_$Create$('Array contains no element matching the predicate.');
    }
    return tmp$ret$0;
  };
  var Companion_instance_27;
  function Companion_getInstance_25() {
    return Companion_instance_27;
  }
  function values_1() {
    return [PredefinedColorIdentity_White_getInstance(), PredefinedColorIdentity_Black_getInstance(), PredefinedColorIdentity_Gray_getInstance(), PredefinedColorIdentity_Yellow_getInstance(), PredefinedColorIdentity_Brown_getInstance(), PredefinedColorIdentity_Red_getInstance(), PredefinedColorIdentity_Violet_getInstance(), PredefinedColorIdentity_Blue_getInstance(), PredefinedColorIdentity_Turquoise_getInstance(), PredefinedColorIdentity_Green_getInstance()];
  }
  var PredefinedColorIdentity_entriesInitialized;
  function PredefinedColorIdentity_initEntries() {
    if (PredefinedColorIdentity_entriesInitialized)
      return Unit_instance;
    PredefinedColorIdentity_entriesInitialized = true;
    PredefinedColorIdentity_White_instance = new PredefinedColorIdentity('White', 0, 'white', 'graphics.color.white.name');
    PredefinedColorIdentity_Black_instance = new PredefinedColorIdentity('Black', 1, 'black', 'graphics.color.black.name');
    PredefinedColorIdentity_Gray_instance = new PredefinedColorIdentity('Gray', 2, 'gray', 'graphics.color.gray.name');
    PredefinedColorIdentity_Yellow_instance = new PredefinedColorIdentity('Yellow', 3, 'yellow', 'graphics.color.yellow.name');
    PredefinedColorIdentity_Brown_instance = new PredefinedColorIdentity('Brown', 4, 'brown', 'graphics.color.brown.name');
    PredefinedColorIdentity_Red_instance = new PredefinedColorIdentity('Red', 5, 'red', 'graphics.color.red.name');
    PredefinedColorIdentity_Violet_instance = new PredefinedColorIdentity('Violet', 6, 'violet', 'graphics.color.violet.name');
    PredefinedColorIdentity_Blue_instance = new PredefinedColorIdentity('Blue', 7, 'blue', 'graphics.color.blue.name');
    PredefinedColorIdentity_Turquoise_instance = new PredefinedColorIdentity('Turquoise', 8, 'turquoise', 'graphics.color.turquoise.name');
    PredefinedColorIdentity_Green_instance = new PredefinedColorIdentity('Green', 9, 'green', 'graphics.color.green.name');
  }
  function PredefinedColorIdentity(name, ordinal, idName, descriptionKey) {
    Enum.call(this, name, ordinal);
    this.d2o_1 = idName;
    this.e2o_1 = descriptionKey;
  }
  protoOf(PredefinedColorIdentity).mq = function () {
    return Translations_getInstance().bn(this.e2o_1, []);
  };
  function _get_colorsList__ezi03($this) {
    var tmp0 = $this.z2m_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('colorsList', 1, tmp, PredefinedColorRepository$_get_colorsList_$ref_tq9z3r(), null);
    return tmp0.j2();
  }
  function _get_colors__hj58bp_0($this) {
    var tmp0 = $this.a2n_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('colors', 1, tmp, PredefinedColorRepository$_get_colors_$ref_agwlj(), null);
    return tmp0.j2();
  }
  function containsName($this, name) {
    return !($this.g2o(name) == null);
  }
  function PredefinedColorRepository$colorsList$delegate$lambda() {
    // Inline function 'kotlin.collections.mutableListOf' call
    return ArrayList_init_$Create$();
  }
  function PredefinedColorRepository$_get_colorsList_$ref_tq9z3r() {
    return function (p0) {
      return _get_colorsList__ezi03(p0);
    };
  }
  function PredefinedColorRepository$colors$delegate$lambda() {
    // Inline function 'kotlin.collections.mutableMapOf' call
    return LinkedHashMap_init_$Create$();
  }
  function PredefinedColorRepository$_get_colors_$ref_agwlj() {
    return function (p0) {
      return _get_colors__hj58bp_0(p0);
    };
  }
  function PredefinedColorRepository() {
    PredefinedColorRepository_instance = this;
    this.y2m_1 = logger(getKClass(PredefinedColorRepository));
    var tmp = this;
    tmp.z2m_1 = lazy(PredefinedColorRepository$colorsList$delegate$lambda);
    var tmp_0 = this;
    tmp_0.a2n_1 = lazy(PredefinedColorRepository$colors$delegate$lambda);
  }
  protoOf(PredefinedColorRepository).g2o = function (idName) {
    var tmp;
    if (Companion_instance_27.f2o(idName)) {
      tmp = _get_colors__hj58bp_0(this).g2(Companion_instance_27.g2o(idName));
    } else {
      tmp = null;
    }
    return tmp;
  };
  protoOf(PredefinedColorRepository).h2o = function (identity) {
    return _get_colors__hj58bp_0(this).g2(identity);
  };
  protoOf(PredefinedColorRepository).b2n = function (color) {
    if (containsName(this, color.m2())) {
      _get_colorsList__ezi03(this).u2(indexOf(_get_colorsList__ezi03(this), this.g2o(color.m2())), color);
    } else {
      _get_colorsList__ezi03(this).h(color);
    }
    var tmp0 = _get_colors__hj58bp_0(this);
    // Inline function 'kotlin.collections.set' call
    var key = color.z2n_1;
    tmp0.y1(key, color);
  };
  var PredefinedColorRepository_instance;
  function PredefinedColorRepository_getInstance() {
    if (PredefinedColorRepository_instance == null)
      new PredefinedColorRepository();
    return PredefinedColorRepository_instance;
  }
  function PredefinedColorIdentity_White_getInstance() {
    PredefinedColorIdentity_initEntries();
    return PredefinedColorIdentity_White_instance;
  }
  function PredefinedColorIdentity_Black_getInstance() {
    PredefinedColorIdentity_initEntries();
    return PredefinedColorIdentity_Black_instance;
  }
  function PredefinedColorIdentity_Gray_getInstance() {
    PredefinedColorIdentity_initEntries();
    return PredefinedColorIdentity_Gray_instance;
  }
  function PredefinedColorIdentity_Yellow_getInstance() {
    PredefinedColorIdentity_initEntries();
    return PredefinedColorIdentity_Yellow_instance;
  }
  function PredefinedColorIdentity_Brown_getInstance() {
    PredefinedColorIdentity_initEntries();
    return PredefinedColorIdentity_Brown_instance;
  }
  function PredefinedColorIdentity_Red_getInstance() {
    PredefinedColorIdentity_initEntries();
    return PredefinedColorIdentity_Red_instance;
  }
  function PredefinedColorIdentity_Violet_getInstance() {
    PredefinedColorIdentity_initEntries();
    return PredefinedColorIdentity_Violet_instance;
  }
  function PredefinedColorIdentity_Blue_getInstance() {
    PredefinedColorIdentity_initEntries();
    return PredefinedColorIdentity_Blue_instance;
  }
  function PredefinedColorIdentity_Turquoise_getInstance() {
    PredefinedColorIdentity_initEntries();
    return PredefinedColorIdentity_Turquoise_instance;
  }
  function PredefinedColorIdentity_Green_getInstance() {
    PredefinedColorIdentity_initEntries();
    return PredefinedColorIdentity_Green_instance;
  }
  function PredefinedStroke(identity, stroke) {
    this.i2o_1 = identity;
    this.j2o_1 = stroke;
  }
  protoOf(PredefinedStroke).toString = function () {
    return 'PredefinedStroke(identity=' + this.i2o_1.toString() + ', stroke=' + this.j2o_1.toString() + ')';
  };
  protoOf(PredefinedStroke).hashCode = function () {
    var result = this.i2o_1.hashCode();
    result = imul(result, 31) + this.j2o_1.hashCode() | 0;
    return result;
  };
  protoOf(PredefinedStroke).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof PredefinedStroke))
      return false;
    if (!this.i2o_1.equals(other.i2o_1))
      return false;
    if (!this.j2o_1.equals(other.j2o_1))
      return false;
    return true;
  };
  function _get_LOG__e5r759_5($this) {
    var tmp0 = $this.c2n_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('LOG', 1, tmp, PredefinedStrokeRepository$_get_LOG_$ref_gt74io(), null);
    return tmp0.j2();
  }
  function _get_strokesList__w6e8fs($this) {
    var tmp0 = $this.d2n_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('strokesList', 1, tmp, PredefinedStrokeRepository$_get_strokesList_$ref_a57giz(), null);
    return tmp0.j2();
  }
  function _get_strokes__63e5l6($this) {
    var tmp0 = $this.e2n_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('strokes', 1, tmp, PredefinedStrokeRepository$_get_strokes_$ref_fz9yzt(), null);
    return tmp0.j2();
  }
  function containsId($this, id) {
    return !($this.k2o(id) == null);
  }
  function PredefinedStrokeRepository$_get_LOG_$ref_gt74io() {
    return function (p0) {
      return _get_LOG__e5r759_5(p0);
    };
  }
  function PredefinedStrokeRepository$strokesList$delegate$lambda() {
    // Inline function 'kotlin.collections.mutableListOf' call
    return ArrayList_init_$Create$();
  }
  function PredefinedStrokeRepository$_get_strokesList_$ref_a57giz() {
    return function (p0) {
      return _get_strokesList__w6e8fs(p0);
    };
  }
  function PredefinedStrokeRepository$strokes$delegate$lambda() {
    // Inline function 'kotlin.collections.mutableMapOf' call
    return LinkedHashMap_init_$Create$();
  }
  function PredefinedStrokeRepository$_get_strokes_$ref_fz9yzt() {
    return function (p0) {
      return _get_strokes__63e5l6(p0);
    };
  }
  function PredefinedStrokeRepository() {
    PredefinedStrokeRepository_instance = this;
    this.c2n_1 = logger(getKClass(PredefinedColorRepository));
    var tmp = this;
    tmp.d2n_1 = lazy(PredefinedStrokeRepository$strokesList$delegate$lambda);
    var tmp_0 = this;
    tmp_0.e2n_1 = lazy(PredefinedStrokeRepository$strokes$delegate$lambda);
  }
  protoOf(PredefinedStrokeRepository).k2o = function (id) {
    return _get_strokes__63e5l6(this).g2(Companion_instance_28.k2o(id));
  };
  protoOf(PredefinedStrokeRepository).l2o = function (identity) {
    return _get_strokes__63e5l6(this).g2(identity);
  };
  protoOf(PredefinedStrokeRepository).f2n = function (stroke) {
    if (containsId(this, stroke.i2o_1.o2o_1)) {
      _get_LOG__e5r759_5(this).nl('PredefinedStroke with id ' + stroke.i2o_1.o2o_1 + ' already registered, replacing');
      _get_strokesList__w6e8fs(this).u2(indexOf(_get_strokesList__w6e8fs(this), this.k2o(stroke.i2o_1.o2o_1)), stroke);
    } else {
      _get_strokesList__w6e8fs(this).h(stroke);
    }
    var tmp0 = _get_strokes__63e5l6(this);
    // Inline function 'kotlin.collections.set' call
    var key = stroke.i2o_1;
    tmp0.y1(key, stroke);
  };
  var PredefinedStrokeRepository_instance;
  function PredefinedStrokeRepository_getInstance() {
    if (PredefinedStrokeRepository_instance == null)
      new PredefinedStrokeRepository();
    return PredefinedStrokeRepository_instance;
  }
  var PredefinedStrokeIdentity_ThinDotted_instance;
  var PredefinedStrokeIdentity_ThinSolid_instance;
  var PredefinedStrokeIdentity_ThinDashed_instance;
  var PredefinedStrokeIdentity_NormalDotted_instance;
  var PredefinedStrokeIdentity_NormalSolid_instance;
  var PredefinedStrokeIdentity_NormalDashed_instance;
  var PredefinedStrokeIdentity_ThickDotted_instance;
  var PredefinedStrokeIdentity_ThickSolid_instance;
  var PredefinedStrokeIdentity_ThickDashed_instance;
  function Companion_24() {
  }
  protoOf(Companion_24).k2o = function (id) {
    var tmp0 = values_2();
    var tmp$ret$0;
    $l$block: {
      // Inline function 'kotlin.collections.first' call
      var inductionVariable = 0;
      var last = tmp0.length;
      while (inductionVariable < last) {
        var element = tmp0[inductionVariable];
        inductionVariable = inductionVariable + 1 | 0;
        if (element.o2o_1 === id) {
          tmp$ret$0 = element;
          break $l$block;
        }
      }
      throw NoSuchElementException_init_$Create$('Array contains no element matching the predicate.');
    }
    return tmp$ret$0;
  };
  var Companion_instance_28;
  function Companion_getInstance_26() {
    return Companion_instance_28;
  }
  function values_2() {
    return [PredefinedStrokeIdentity_ThinDotted_getInstance(), PredefinedStrokeIdentity_ThinSolid_getInstance(), PredefinedStrokeIdentity_ThinDashed_getInstance(), PredefinedStrokeIdentity_NormalDotted_getInstance(), PredefinedStrokeIdentity_NormalSolid_getInstance(), PredefinedStrokeIdentity_NormalDashed_getInstance(), PredefinedStrokeIdentity_ThickDotted_getInstance(), PredefinedStrokeIdentity_ThickSolid_getInstance(), PredefinedStrokeIdentity_ThickDashed_getInstance()];
  }
  var PredefinedStrokeIdentity_entriesInitialized;
  function PredefinedStrokeIdentity_initEntries() {
    if (PredefinedStrokeIdentity_entriesInitialized)
      return Unit_instance;
    PredefinedStrokeIdentity_entriesInitialized = true;
    PredefinedStrokeIdentity_ThinDotted_instance = new PredefinedStrokeIdentity('ThinDotted', 0, 'thin-dotted');
    PredefinedStrokeIdentity_ThinSolid_instance = new PredefinedStrokeIdentity('ThinSolid', 1, 'thin-solid');
    PredefinedStrokeIdentity_ThinDashed_instance = new PredefinedStrokeIdentity('ThinDashed', 2, 'thin-dashed');
    PredefinedStrokeIdentity_NormalDotted_instance = new PredefinedStrokeIdentity('NormalDotted', 3, 'normal-dotted');
    PredefinedStrokeIdentity_NormalSolid_instance = new PredefinedStrokeIdentity('NormalSolid', 4, 'normal-solid');
    PredefinedStrokeIdentity_NormalDashed_instance = new PredefinedStrokeIdentity('NormalDashed', 5, 'normal-dashed');
    PredefinedStrokeIdentity_ThickDotted_instance = new PredefinedStrokeIdentity('ThickDotted', 6, 'thick-dotted');
    PredefinedStrokeIdentity_ThickSolid_instance = new PredefinedStrokeIdentity('ThickSolid', 7, 'thick-solid');
    PredefinedStrokeIdentity_ThickDashed_instance = new PredefinedStrokeIdentity('ThickDashed', 8, 'thick-dashed');
  }
  function PredefinedStrokeIdentity(name, ordinal, id) {
    Enum.call(this, name, ordinal);
    this.o2o_1 = id;
  }
  function PredefinedStrokeIdentity_ThinDotted_getInstance() {
    PredefinedStrokeIdentity_initEntries();
    return PredefinedStrokeIdentity_ThinDotted_instance;
  }
  function PredefinedStrokeIdentity_ThinSolid_getInstance() {
    PredefinedStrokeIdentity_initEntries();
    return PredefinedStrokeIdentity_ThinSolid_instance;
  }
  function PredefinedStrokeIdentity_ThinDashed_getInstance() {
    PredefinedStrokeIdentity_initEntries();
    return PredefinedStrokeIdentity_ThinDashed_instance;
  }
  function PredefinedStrokeIdentity_NormalDotted_getInstance() {
    PredefinedStrokeIdentity_initEntries();
    return PredefinedStrokeIdentity_NormalDotted_instance;
  }
  function PredefinedStrokeIdentity_NormalSolid_getInstance() {
    PredefinedStrokeIdentity_initEntries();
    return PredefinedStrokeIdentity_NormalSolid_instance;
  }
  function PredefinedStrokeIdentity_NormalDashed_getInstance() {
    PredefinedStrokeIdentity_initEntries();
    return PredefinedStrokeIdentity_NormalDashed_instance;
  }
  function PredefinedStrokeIdentity_ThickDotted_getInstance() {
    PredefinedStrokeIdentity_initEntries();
    return PredefinedStrokeIdentity_ThickDotted_instance;
  }
  function PredefinedStrokeIdentity_ThickSolid_getInstance() {
    PredefinedStrokeIdentity_initEntries();
    return PredefinedStrokeIdentity_ThickSolid_instance;
  }
  function PredefinedStrokeIdentity_ThickDashed_getInstance() {
    PredefinedStrokeIdentity_initEntries();
    return PredefinedStrokeIdentity_ThickDashed_instance;
  }
  function RadialColorGradient(center, radius, centerColor, perimeterColor) {
    this.x1s_1 = center;
    this.y1s_1 = radius;
    this.z1s_1 = centerColor;
    this.a1t_1 = perimeterColor;
  }
  protoOf(RadialColorGradient).toString = function () {
    return 'RadialColorGradient(center=' + this.x1s_1.toString() + ', radius=' + this.y1s_1 + ', centerColor=' + this.z1s_1.toString() + ', perimeterColor=' + this.a1t_1.toString() + ')';
  };
  protoOf(RadialColorGradient).hashCode = function () {
    var result = this.x1s_1.hashCode();
    result = imul(result, 31) + this.y1s_1 | 0;
    result = imul(result, 31) + this.z1s_1.hashCode() | 0;
    result = imul(result, 31) + this.a1t_1.hashCode() | 0;
    return result;
  };
  protoOf(RadialColorGradient).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof RadialColorGradient))
      return false;
    if (!this.x1s_1.equals(other.x1s_1))
      return false;
    if (!(this.y1s_1 === other.y1s_1))
      return false;
    if (!this.z1s_1.equals(other.z1s_1))
      return false;
    if (!this.a1t_1.equals(other.a1t_1))
      return false;
    return true;
  };
  function RadialColorGradientCache(center, radius, backgroundColor) {
    this.p2o_1 = center;
    this.q2o_1 = radius;
    this.r2o_1 = backgroundColor;
    var tmp = this;
    // Inline function 'kotlin.collections.mutableMapOf' call
    tmp.s2o_1 = LinkedHashMap_init_$Create$();
    this.t2o_1 = this.r2o_1.r2f(0);
    var tmp_0 = this;
    // Inline function 'kotlin.also' call
    var this_0 = new Float32Array(3);
    this_0[0] = 0.0;
    this_0[1] = 0.6;
    this_0[2] = 1.0;
    tmp_0.u2o_1 = this_0;
  }
  protoOf(RadialColorGradientCache).v2o = function (gradient, factor) {
    var factorInt = numberToInt(factor * 100);
    var alpha1 = numberToInt(factor * 255);
    // Inline function 'kotlin.collections.getOrPut' call
    var this_0 = this.s2o_1;
    var value = this_0.g2(factorInt);
    var tmp;
    if (value == null) {
      var centerColor = gradient.f2l(1.0);
      var answer = new RadialColorGradient(this.p2o_1, this.q2o_1, centerColor.r2f(alpha1), this.t2o_1);
      this_0.y1(factorInt, answer);
      tmp = answer;
    } else {
      tmp = value;
    }
    return tmp;
  };
  function _get_LOG__e5r759_6($this) {
    var tmp0 = $this.w2o_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('LOG', 1, tmp, ReferenceColorSequenceProvider$_get_LOG_$ref_gvc732(), null);
    return tmp0.j2();
  }
  function ReferenceColorSequenceProvider$_get_LOG_$ref_gvc732() {
    return function (p0) {
      return _get_LOG__e5r759_6(p0);
    };
  }
  function ReferenceColorSequenceProvider() {
    ReferenceColorSequenceProvider_instance = this;
    this.w2o_1 = logger(getKClass(ReferenceColorSequenceProvider));
    var tmp = this;
    // Inline function 'kotlin.collections.mutableListOf' call
    tmp.x2o_1 = ArrayList_init_$Create$();
  }
  protoOf(ReferenceColorSequenceProvider).y2o = function () {
    return new FlexibleReferenceColorSequenceImpl();
  };
  protoOf(ReferenceColorSequenceProvider).z2o = function (colors) {
    if (this.a2p() > 0 && !(this.a2p() === colors.o())) {
      _get_LOG__e5r759_6(this).ml('inconsistent replacement color count old=' + this.a2p() + ', new=' + colors.o());
      throw IllegalArgumentException_init_$Create$('inconsistent color count');
    }
    // Inline function 'kotlin.collections.filter' call
    var tmp0 = get_indices(colors);
    // Inline function 'kotlin.collections.filterTo' call
    var destination = ArrayList_init_$Create$();
    var inductionVariable = tmp0.y_1;
    var last = tmp0.z_1;
    if (inductionVariable <= last)
      do {
        var element = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        if (element < ReferenceColorSequenceProvider_getInstance().a2p()) {
          destination.h(element);
        }
      }
       while (!(element === last));
    // Inline function 'kotlin.collections.map' call
    // Inline function 'kotlin.collections.mapTo' call
    var destination_0 = ArrayList_init_$Create$_0(collectionSizeOrDefault(destination, 10));
    var _iterator__ex2g4s = destination.i();
    while (_iterator__ex2g4s.j()) {
      var item = _iterator__ex2g4s.k();
      var tmp$ret$5 = new ReferenceColorReplacement(ReferenceColorSequenceProvider_getInstance().x2o_1.l(item), colors.l(item));
      destination_0.h(tmp$ret$5);
    }
    var replacements = destination_0;
    this.x2o_1.a2();
    this.x2o_1.f1(colors);
    BaseModule_getInstance().bp_1.gu(new ReferenceColorEvent(replacements));
  };
  protoOf(ReferenceColorSequenceProvider).a2p = function () {
    return this.x2o_1.o();
  };
  protoOf(ReferenceColorSequenceProvider).b2p = function (index) {
    return this.x2o_1.l(index);
  };
  protoOf(ReferenceColorSequenceProvider).c2p = function (color) {
    return this.x2o_1.p(color);
  };
  var ReferenceColorSequenceProvider_instance;
  function ReferenceColorSequenceProvider_getInstance() {
    if (ReferenceColorSequenceProvider_instance == null)
      new ReferenceColorSequenceProvider();
    return ReferenceColorSequenceProvider_instance;
  }
  function ReferenceColor(onBackground, onDark) {
    onDark = onDark === VOID ? onBackground : onDark;
    this.d2p_1 = onBackground;
    this.e2p_1 = onDark;
  }
  protoOf(ReferenceColor).toString = function () {
    return 'ReferenceColor(onBackground=' + this.d2p_1.toString() + ', onDark=' + this.e2p_1.toString() + ')';
  };
  protoOf(ReferenceColor).hashCode = function () {
    var result = this.d2p_1.hashCode();
    result = imul(result, 31) + this.e2p_1.hashCode() | 0;
    return result;
  };
  protoOf(ReferenceColor).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof ReferenceColor))
      return false;
    if (!this.d2p_1.equals(other.d2p_1))
      return false;
    if (!this.e2p_1.equals(other.e2p_1))
      return false;
    return true;
  };
  function Usage($outer, index, count) {
    this.h2p_1 = $outer;
    this.f2p_1 = index;
    this.g2p_1 = count;
  }
  protoOf(Usage).i2p = function (other) {
    if (!(this.g2p_1 === other.g2p_1)) {
      return compareTo(this.g2p_1, other.g2p_1);
    }
    return compareTo(this.f2p_1, other.f2p_1);
  };
  protoOf(Usage).d = function (other) {
    return this.i2p(other instanceof Usage ? other : THROW_CCE());
  };
  function FlexibleReferenceColorSequenceImpl() {
    var tmp = this;
    // Inline function 'kotlin.collections.map' call
    var this_0 = until(0, ReferenceColorSequenceProvider_getInstance().a2p());
    // Inline function 'kotlin.collections.mapTo' call
    var destination = ArrayList_init_$Create$_0(collectionSizeOrDefault(this_0, 10));
    var inductionVariable = this_0.y_1;
    var last = this_0.z_1;
    if (inductionVariable <= last)
      do {
        var item = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        var it = item;
        var tmp$ret$2 = new Usage(this, it, 0);
        destination.h(tmp$ret$2);
      }
       while (!(item === last));
    tmp.j2p_1 = destination;
  }
  protoOf(FlexibleReferenceColorSequenceImpl).k = function () {
    var usage = ensureNotNull(minOrNull(this.j2p_1));
    usage.g2p_1 = usage.g2p_1 + 1 | 0;
    return ReferenceColorSequenceProvider_getInstance().b2p(usage.f2p_1);
  };
  protoOf(FlexibleReferenceColorSequenceImpl).k2p = function (color) {
    var index = ReferenceColorSequenceProvider_getInstance().c2p(color);
    // Inline function 'kotlin.collections.find' call
    var tmp0 = this.j2p_1;
    var tmp$ret$1;
    $l$block: {
      // Inline function 'kotlin.collections.firstOrNull' call
      var _iterator__ex2g4s = tmp0.i();
      while (_iterator__ex2g4s.j()) {
        var element = _iterator__ex2g4s.k();
        if (element.f2p_1 === index && element.g2p_1 > 0) {
          tmp$ret$1 = element;
          break $l$block;
        }
      }
      tmp$ret$1 = null;
    }
    var tmp0_elvis_lhs = tmp$ret$1;
    var tmp;
    if (tmp0_elvis_lhs == null) {
      throw IllegalStateException_init_$Create$('nothing to free');
    } else {
      tmp = tmp0_elvis_lhs;
    }
    var usage = tmp;
    usage.g2p_1 = usage.g2p_1 - 1 | 0;
  };
  function ReferenceColorReplacement(oldColor, newColor) {
    this.l2p_1 = oldColor;
    this.m2p_1 = newColor;
  }
  protoOf(ReferenceColorReplacement).toString = function () {
    return 'ReferenceColorReplacement(oldColor=' + this.l2p_1.toString() + ', newColor=' + this.m2p_1.toString() + ')';
  };
  protoOf(ReferenceColorReplacement).hashCode = function () {
    var result = this.l2p_1.hashCode();
    result = imul(result, 31) + this.m2p_1.hashCode() | 0;
    return result;
  };
  protoOf(ReferenceColorReplacement).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof ReferenceColorReplacement))
      return false;
    if (!this.l2p_1.equals(other.l2p_1))
      return false;
    if (!this.m2p_1.equals(other.m2p_1))
      return false;
    return true;
  };
  function ReferenceColorEvent(replacements) {
    this.n2p_1 = replacements;
  }
  protoOf(ReferenceColorEvent).toString = function () {
    return 'ReferenceColorEvent(replacements=' + toString(this.n2p_1) + ')';
  };
  protoOf(ReferenceColorEvent).hashCode = function () {
    return hashCode(this.n2p_1);
  };
  protoOf(ReferenceColorEvent).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof ReferenceColorEvent))
      return false;
    if (!equals(this.n2p_1, other.n2p_1))
      return false;
    return true;
  };
  function Stroke(width, cap, join, miterLimit, dash, dashPhase) {
    width = width === VOID ? 1.0 : width;
    cap = cap === VOID ? LineCap_SQUARE_getInstance() : cap;
    join = join === VOID ? LineJoin_MITER_getInstance() : join;
    miterLimit = miterLimit === VOID ? 10.0 : miterLimit;
    dash = dash === VOID ? null : dash;
    dashPhase = dashPhase === VOID ? null : dashPhase;
    this.f1u_1 = width;
    this.g1u_1 = cap;
    this.h1u_1 = join;
    this.i1u_1 = miterLimit;
    this.j1u_1 = dash;
    this.k1u_1 = dashPhase;
    if (this.f1u_1 < 0.0) {
      throw IllegalArgumentException_init_$Create$('negative width');
    }
    if (this.h1u_1.equals(LineJoin_MITER_getInstance()) && this.i1u_1 < 1.0) {
      throw IllegalArgumentException_init_$Create$('miterlimit < 1');
    }
    if (!(this.j1u_1 == null)) {
      if (!(this.k1u_1 == null) && this.k1u_1 < 0.0) {
        throw IllegalArgumentException_init_$Create$('negative dash phase');
      }
      var allZero = false;
      var indexedObject = this.j1u_1;
      var inductionVariable = 0;
      var last = indexedObject.length;
      while (inductionVariable < last) {
        var value = indexedObject[inductionVariable];
        inductionVariable = inductionVariable + 1 | 0;
        if (value > 0.0) {
          allZero = false;
        } else if (value < 0.0) {
          throw IllegalArgumentException_init_$Create$('negative dash length');
        }
      }
      if (allZero) {
        throw IllegalArgumentException_init_$Create$('dash lengths all zero');
      }
    }
  }
  protoOf(Stroke).o2p = function () {
    return this.p2p(this.f1u_1 * 0.7);
  };
  protoOf(Stroke).equals = function (other) {
    if (this === other)
      return true;
    if (other == null || !getKClassFromExpression(this).equals(getKClassFromExpression(other)))
      return false;
    if (!(other instanceof Stroke))
      THROW_CCE();
    if (!(this.f1u_1 === other.f1u_1))
      return false;
    if (!this.g1u_1.equals(other.g1u_1))
      return false;
    if (!this.h1u_1.equals(other.h1u_1))
      return false;
    if (!(this.i1u_1 === other.i1u_1))
      return false;
    if (!(this.j1u_1 == null)) {
      if (other.j1u_1 == null)
        return false;
      if (!contentEquals(this.j1u_1, other.j1u_1))
        return false;
    } else if (!(other.j1u_1 == null))
      return false;
    if (!(this.k1u_1 == other.k1u_1))
      return false;
    return true;
  };
  protoOf(Stroke).hashCode = function () {
    var result = getNumberHashCode(this.f1u_1);
    result = imul(31, result) + this.g1u_1.hashCode() | 0;
    result = imul(31, result) + this.h1u_1.hashCode() | 0;
    result = imul(31, result) + getNumberHashCode(this.i1u_1) | 0;
    var tmp = imul(31, result);
    var tmp0_safe_receiver = this.j1u_1;
    var tmp1_elvis_lhs = tmp0_safe_receiver == null ? null : contentHashCode(tmp0_safe_receiver);
    result = tmp + (tmp1_elvis_lhs == null ? 0 : tmp1_elvis_lhs) | 0;
    var tmp_0 = imul(31, result);
    var tmp2_safe_receiver = this.k1u_1;
    var tmp3_elvis_lhs = tmp2_safe_receiver == null ? null : getNumberHashCode(tmp2_safe_receiver);
    result = tmp_0 + (tmp3_elvis_lhs == null ? 0 : tmp3_elvis_lhs) | 0;
    return result;
  };
  protoOf(Stroke).q2p = function (width, cap, join, miterLimit, dash, dashPhase) {
    return new Stroke(width, cap, join, miterLimit, dash, dashPhase);
  };
  protoOf(Stroke).p2p = function (width, cap, join, miterLimit, dash, dashPhase, $super) {
    width = width === VOID ? this.f1u_1 : width;
    cap = cap === VOID ? this.g1u_1 : cap;
    join = join === VOID ? this.h1u_1 : join;
    miterLimit = miterLimit === VOID ? this.i1u_1 : miterLimit;
    dash = dash === VOID ? this.j1u_1 : dash;
    dashPhase = dashPhase === VOID ? this.k1u_1 : dashPhase;
    return $super === VOID ? this.q2p(width, cap, join, miterLimit, dash, dashPhase) : $super.q2p.call(this, width, cap, join, miterLimit, dash, dashPhase);
  };
  protoOf(Stroke).toString = function () {
    return 'Stroke(width=' + this.f1u_1 + ', cap=' + this.g1u_1.toString() + ', join=' + this.h1u_1.toString() + ', miterLimit=' + this.i1u_1 + ', dash=' + toString(this.j1u_1) + ', dashPhase=' + this.k1u_1 + ')';
  };
  var LineCap_BUTT_instance;
  var LineCap_ROUND_instance;
  var LineCap_SQUARE_instance;
  var LineCap_entriesInitialized;
  function LineCap_initEntries() {
    if (LineCap_entriesInitialized)
      return Unit_instance;
    LineCap_entriesInitialized = true;
    LineCap_BUTT_instance = new LineCap('BUTT', 0);
    LineCap_ROUND_instance = new LineCap('ROUND', 1);
    LineCap_SQUARE_instance = new LineCap('SQUARE', 2);
  }
  function LineCap(name, ordinal) {
    Enum.call(this, name, ordinal);
  }
  var LineJoin_MITER_instance;
  var LineJoin_ROUND_instance;
  var LineJoin_BEVEL_instance;
  var LineJoin_entriesInitialized;
  function LineJoin_initEntries() {
    if (LineJoin_entriesInitialized)
      return Unit_instance;
    LineJoin_entriesInitialized = true;
    LineJoin_MITER_instance = new LineJoin('MITER', 0);
    LineJoin_ROUND_instance = new LineJoin('ROUND', 1);
    LineJoin_BEVEL_instance = new LineJoin('BEVEL', 2);
  }
  function LineJoin(name, ordinal) {
    Enum.call(this, name, ordinal);
  }
  function LineCap_BUTT_getInstance() {
    LineCap_initEntries();
    return LineCap_BUTT_instance;
  }
  function LineCap_ROUND_getInstance() {
    LineCap_initEntries();
    return LineCap_ROUND_instance;
  }
  function LineCap_SQUARE_getInstance() {
    LineCap_initEntries();
    return LineCap_SQUARE_instance;
  }
  function LineJoin_MITER_getInstance() {
    LineJoin_initEntries();
    return LineJoin_MITER_instance;
  }
  function LineJoin_ROUND_getInstance() {
    LineJoin_initEntries();
    return LineJoin_ROUND_instance;
  }
  function LineJoin_BEVEL_getInstance() {
    LineJoin_initEntries();
    return LineJoin_BEVEL_instance;
  }
  function TextRenderInfoFactory() {
  }
  protoOf(TextRenderInfoFactory).g2j = function (text, font) {
    return TextRenderInfoFactoryImpl_getInstance().f1w(text, font);
  };
  var TextRenderInfoFactory_instance;
  function TextRenderInfoFactory_getInstance() {
    return TextRenderInfoFactory_instance;
  }
  function TextRenderInfo(textBounds, ascent) {
    this.h2j_1 = textBounds;
    this.i2j_1 = ascent;
  }
  protoOf(TextRenderInfo).toString = function () {
    return 'TextRenderInfo(textBounds=' + this.h2j_1.toString() + ', ascent=' + this.i2j_1 + ')';
  };
  protoOf(TextRenderInfo).hashCode = function () {
    var result = this.h2j_1.hashCode();
    result = imul(result, 31) + getNumberHashCode(this.i2j_1) | 0;
    return result;
  };
  protoOf(TextRenderInfo).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof TextRenderInfo))
      return false;
    if (!this.h2j_1.equals(other.h2j_1))
      return false;
    if (!equals(this.i2j_1, other.i2j_1))
      return false;
    return true;
  };
  function fillProperties_1($this, properties) {
    properties.et('view.command.zoom.step', 1.5);
    properties.et('draw.panMethod', PanMethod_MiddleMouseButton_getInstance().u2p());
  }
  function DrawModule$rasterImageFactory$lambda(_unused_var__etf5q3, _unused_var__etf5q3_0) {
    throw UnsupportedOperationException_init_$Create$_0();
  }
  function DrawModule$imageLoader$1() {
  }
  protoOf(DrawModule$imageLoader$1).v2p = function (path, type) {
    throw UnsupportedOperationException_init_$Create$_0();
  };
  function DrawModule$drawContextFactory$lambda(g, mc, appContext) {
    return new DrawContext(g, mc, appContext);
  }
  function DrawModule() {
    DrawModule_instance = this;
    AbstractModule.call(this);
    this.g2a_1 = false;
    this.h2a_1 = Companion_getInstance_20().f1t_1;
    this.i2a_1 = Companion_getInstance_20().l1t_1;
    this.j2a_1 = Companion_getInstance_20().k1t_1;
    this.k2a_1 = new Stroke(0.5);
    this.l2a_1 = new DrawProperties(BaseModule_getInstance().zo_1);
    var tmp = this;
    tmp.m2a_1 = DrawModule$rasterImageFactory$lambda;
    var tmp_0 = this;
    tmp_0.n2a_1 = new DrawModule$imageLoader$1();
    var tmp_1 = this;
    tmp_1.o2a_1 = DrawModule$drawContextFactory$lambda;
    this.p2a_1 = Companion_instance.u18_1;
  }
  protoOf(DrawModule).to = function () {
    BaseModule_getInstance().vo();
    Translations_getInstance().wm('jabbah-draw');
    DrawGraphicsModule_getInstance().vo();
    DrawStyleModule_getInstance().vo();
    DrawViewModule_getInstance().vo();
    AnimationModule_getInstance().vo();
    fillProperties_1(this, this.l2a_1);
  };
  protoOf(DrawModule).w2p = function (drawable, g, color) {
    if (this.g2a_1) {
      g.b1u(color);
      g.e1u(this.k2a_1);
      g.j1v(drawable.fo());
    }
  };
  protoOf(DrawModule).q2a = function (drawable, g, color, $super) {
    color = color === VOID ? this.h2a_1 : color;
    var tmp;
    if ($super === VOID) {
      this.w2p(drawable, g, color);
      tmp = Unit_instance;
    } else {
      tmp = $super.w2p.call(this, drawable, g, color);
    }
    return tmp;
  };
  protoOf(DrawModule).x2p = function (locatable, context, color) {
    if (this.g2a_1) {
      this.w2p(locatable, context.j1z_1, color);
      this.y2p(locatable.jw(), context, color);
    }
  };
  protoOf(DrawModule).z2p = function (locatable, context, color, $super) {
    color = color === VOID ? this.h2a_1 : color;
    var tmp;
    if ($super === VOID) {
      this.x2p(locatable, context, color);
      tmp = Unit_instance;
    } else {
      tmp = $super.x2p.call(this, locatable, context, color);
    }
    return tmp;
  };
  protoOf(DrawModule).y2p = function (location, context, color) {
    if (this.g2a_1) {
      context.j1z_1.b1u(color);
      context.j1z_1.g1v(numberToInt(location.kn_1 - 2), numberToInt(location.ln_1 - 2), 4, 4);
    }
  };
  protoOf(DrawModule).r2a = function (location, context, color, $super) {
    color = color === VOID ? this.h2a_1 : color;
    var tmp;
    if ($super === VOID) {
      this.y2p(location, context, color);
      tmp = Unit_instance;
    } else {
      tmp = $super.y2p.call(this, location, context, color);
    }
    return tmp;
  };
  var DrawModule_instance;
  function DrawModule_getInstance() {
    if (DrawModule_instance == null)
      new DrawModule();
    return DrawModule_instance;
  }
  function Companion_25() {
    Companion_instance_29 = this;
    this.a2q_1 = 4;
    this.b2q_1 = 10;
    this.c2q_1 = 1.0;
    this.d2q_1 = true;
    this.e2q_1 = false;
    this.f2q_1 = 4;
    this.g2q_1 = System_getInstance().bm();
    this.h2q_1 = new Stroke(1.0);
  }
  protoOf(Companion_25).i2q = function () {
    return new ArrowHead();
  };
  protoOf(Companion_25).j2q = function () {
    return new ArrowHead(VOID, VOID, VOID, VOID, true);
  };
  var Companion_instance_29;
  function Companion_getInstance_27() {
    if (Companion_instance_29 == null)
      new Companion_25();
    return Companion_instance_29;
  }
  function setLocationImpl($this, x, y) {
    Companion_getInstance_27().g2q_1.s1d(x - $this.p2q_1.kn_1, y - $this.p2q_1.ln_1);
    $this.p2q_1 = new Point2D(x, y);
    $this.s2q_1.mn(Companion_getInstance_27().g2q_1);
    $this.r2q_1 = Companion_getInstance_27().g2q_1.nn($this.r2q_1);
  }
  function createUnidirectionalShape($this, width, length, compactness) {
    var path = System_getInstance().cm();
    path.wn(0, 0);
    path.zn(-length | 0, -width | 0);
    var tmp = $this;
    var tmp_0;
    if (compactness === 1.0) {
      path.zn(-length | 0, width);
      tmp_0 = Point2D_init_$Create$(-length | 0, 0);
    } else {
      var innerLength = length * compactness;
      path.ao(-innerLength, 0.0);
      path.zn(-length | 0, width);
      tmp_0 = new Point2D(-innerLength, 0.0);
    }
    tmp.r2q_1 = tmp_0;
    path.do();
    return path;
  }
  function createBidirectionalShape($this, width, length, compactness) {
    var path = System_getInstance().cm();
    var innerLength = length * compactness;
    path.wn(0, 0);
    path.zn(-length | 0, -width | 0);
    if (compactness === 1.0) {
      path.zn(-length | 0, 0);
      path.zn((-length | 0) - 4 | 0, 0);
    } else {
      path.ao(-innerLength, 0.0);
      path.ao(((-length | 0) - 4 | 0) - (length - innerLength), 0.0);
    }
    path.zn((-length | 0) - 4 | 0, -width | 0);
    path.zn(((-length | 0) - 4 | 0) - length | 0, 0);
    path.zn((-length | 0) - 4 | 0, width);
    if (compactness === 1.0) {
      path.zn((-length | 0) - 4 | 0, 0);
      path.zn(-length | 0, 0);
    } else {
      path.ao(((-length | 0) - 4 | 0) - (length - innerLength), 0.0);
      path.ao(-innerLength, 0.0);
    }
    path.zn(-length | 0, width);
    $this.r2q_1 = Point2D_init_$Create$(imul(-2, length) - 4 | 0, 0);
    path.do();
    return path;
  }
  function ArrowHead(width, length, compactness, filled, bidirectional) {
    Companion_getInstance_27();
    width = width === VOID ? 4 : width;
    length = length === VOID ? 10 : length;
    compactness = compactness === VOID ? 1.0 : compactness;
    filled = filled === VOID ? true : filled;
    bidirectional = bidirectional === VOID ? false : bidirectional;
    AbstractDrawable.call(this);
    this.n2q_1 = length;
    this.o2q_1 = filled;
    this.p2q_1 = Companion_getInstance().w1a_1;
    this.q2q_1 = 0.0;
    this.r2q_1 = Companion_getInstance().w1a_1;
    var tmp = this;
    var tmp_0;
    if (bidirectional) {
      tmp_0 = createBidirectionalShape(this, width, this.n2q_1, compactness);
    } else {
      tmp_0 = createUnidirectionalShape(this, width, this.n2q_1, compactness);
    }
    tmp.s2q_1 = tmp_0;
  }
  protoOf(ArrowHead).fo = function () {
    return Rectangle2D_init_$Create$(this.s2q_1.fo()).p1c(Companion_getInstance_27().h2q_1.f1u_1);
  };
  protoOf(ArrowHead).h20 = function (context) {
    var oldStroke = context.j1z_1.l1u();
    context.j1z_1.e1u(Companion_getInstance_27().h2q_1);
    context.j1z_1.j1v(this.s2q_1);
    if (this.o2q_1) {
      context.j1z_1.k1v(this.s2q_1);
    }
    context.j1z_1.e1u(oldStroke);
    DrawModule_getInstance().q2a(this, context.j1z_1);
  };
  protoOf(ArrowHead).go = function (x, y) {
    return this.s2q_1.go(x, y);
  };
  protoOf(ArrowHead).o = function () {
    return this.n2q_1;
  };
  protoOf(ArrowHead).t2q = function (location, orientation) {
    this.i20();
    setLocationImpl(this, location.kn_1, location.ln_1);
    Companion_getInstance_27().g2q_1.r1d();
    var rot = Geometry_instance.q1g(orientation, location);
    Companion_getInstance_27().g2q_1.t1d(this.q2q_1 - rot, location.kn_1, location.ln_1);
    this.r2q_1 = Companion_getInstance_27().g2q_1.nn(this.r2q_1);
    this.s2q_1.mn(Companion_getInstance_27().g2q_1);
    this.q2q_1 = rot;
    this.i20();
    this.l20();
  };
  function Polyline() {
  }
  function Companion_26() {
    Companion_instance_30 = this;
    this.s2r_1 = new PolylineInterference(0, 0);
  }
  var Companion_instance_30;
  function Companion_getInstance_28() {
    if (Companion_instance_30 == null)
      new Companion_26();
    return Companion_instance_30;
  }
  function PolylineInterference(intersectionCount, overlappingCount) {
    Companion_getInstance_28();
    this.t2r_1 = intersectionCount;
    this.u2r_1 = overlappingCount;
  }
  protoOf(PolylineInterference).toString = function () {
    return 'PolylineInterference(intersectionCount=' + this.t2r_1 + ', overlappingCount=' + this.u2r_1 + ')';
  };
  protoOf(PolylineInterference).hashCode = function () {
    var result = this.t2r_1;
    result = imul(result, 31) + this.u2r_1 | 0;
    return result;
  };
  protoOf(PolylineInterference).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof PolylineInterference))
      return false;
    if (!(this.t2r_1 === other.t2r_1))
      return false;
    if (!(this.u2r_1 === other.u2r_1))
      return false;
    return true;
  };
  function drawImpl($this, context, lineColor, fillColor) {
    var oldColor = context.j1z_1.c1u();
    if ($this.i2d() && !(fillColor == null)) {
      var tmp = DropShadow_instance;
      var tmp_0 = $this.d2i();
      tmp.l2n(context, tmp_0, PolylineDrawable$drawImpl$lambda(context, $this));
    }
    if (!(fillColor == null)) {
      context.j1z_1.b1u(fillColor);
      context.j1z_1.k1v($this.z2r_1);
    }
    context.j1z_1.b1u(lineColor);
    context.j1z_1.e1u($this.l1u());
    context.j1z_1.j1v($this.z2r_1);
    var tmp0_safe_receiver = $this.z2r_1.v2q();
    if (tmp0_safe_receiver == null)
      null;
    else {
      tmp0_safe_receiver.h20(context);
    }
    var tmp1_safe_receiver = $this.z2r_1.x2q();
    if (tmp1_safe_receiver == null)
      null;
    else {
      tmp1_safe_receiver.h20(context);
    }
    context.j1z_1.b1u(oldColor);
  }
  function PolylineDrawable$drawImpl$lambda($context, this$0) {
    return function (it) {
      $context.j1z_1.k1v(this$0.z2r_1);
      return Unit_instance;
    };
  }
  function PolylineDrawable(shape, styleType, styleProvider) {
    shape = shape === VOID ? PolylineShapeFactory_instance.g1w(null) : shape;
    styleType = styleType === VOID ? Companion_getInstance_33().b1y_1 : styleType;
    styleProvider = styleProvider === VOID ? DrawStyleModule_getInstance().w1x_1 : styleProvider;
    AbstractStyledDrawable_init_$Init$(styleType, styleProvider, this);
    this.z2r_1 = shape;
    this.a2s_1 = new TransparentImpl(this);
  }
  protoOf(PolylineDrawable).toString = function () {
    return Translations_getInstance().bn('edit.component.polyline', []);
  };
  protoOf(PolylineDrawable).v20 = function (value) {
    this.i20();
    this.z2r_1.f2r(value.kn_1, value.ln_1);
    this.i20();
    this.l20();
  };
  protoOf(PolylineDrawable).jw = function () {
    return this.z2r_1.u2k(0);
  };
  protoOf(PolylineDrawable).v21 = function (dx, dy) {
    this.i20();
    this.z2r_1.f2r(this.jw().kn_1 + dx, this.jw().ln_1 + dy);
    this.i20();
    this.l20();
  };
  protoOf(PolylineDrawable).a2i = function (value) {
    this.a2s_1.a2i(value);
  };
  protoOf(PolylineDrawable).d2i = function () {
    return this.a2s_1.c2i_1;
  };
  protoOf(PolylineDrawable).fo = function () {
    var bbox = Rectangle2D_init_$Create$(this.z2r_1.fo());
    var lw = this.b2s();
    bbox.i1c(bbox.u1h_1 - lw, bbox.v1h_1 - lw, bbox.w1h_1 + 2 * lw, bbox.x1h_1 + 2 * lw);
    return bbox;
  };
  protoOf(PolylineDrawable).h20 = function (context) {
    if (context.m1z_1) {
      drawImpl(this, context, ensureNotNull(context.n1z_1).x1x_1, this.f2d() ? ensureNotNull(context.n1z_1).y1x_1 : null);
    } else {
      drawImpl(this, context, this.a2s_1.l2h(this.y2c()), this.f2d() ? this.a2s_1.l2h(this.z2c()) : null);
    }
  };
  protoOf(PolylineDrawable).go = function (x, y) {
    return this.z2r_1.go(x, y);
  };
  protoOf(PolylineDrawable).a = function () {
    return this.z2r_1.a();
  };
  protoOf(PolylineDrawable).t2k = function () {
    return this.z2r_1.t2k();
  };
  protoOf(PolylineDrawable).y2q = function () {
    return this.z2r_1.y2q();
  };
  protoOf(PolylineDrawable).u2q = function (value) {
    this.i20();
    this.z2r_1.u2q(value);
    this.i20();
    this.l20();
  };
  protoOf(PolylineDrawable).v2q = function () {
    return this.z2r_1.v2q();
  };
  protoOf(PolylineDrawable).w2q = function (value) {
    this.i20();
    this.z2r_1.w2q(value);
    this.i20();
    this.l20();
  };
  protoOf(PolylineDrawable).x2q = function () {
    return this.z2r_1.x2q();
  };
  protoOf(PolylineDrawable).a2 = function () {
    this.z2r_1.a2();
  };
  protoOf(PolylineDrawable).c2s = function (x, y) {
    return this.z2q(this.t2k(), x, y);
  };
  protoOf(PolylineDrawable).z2q = function (index, x, y) {
    this.i20();
    this.z2r_1.z2q(index, x, y);
    this.i20();
    this.l20();
    return this;
  };
  protoOf(PolylineDrawable).a2r = function (index) {
    this.i20();
    this.z2r_1.a2r(index);
    this.i20();
    this.l20();
    return this;
  };
  protoOf(PolylineDrawable).u2k = function (index) {
    return this.z2r_1.u2k(index);
  };
  protoOf(PolylineDrawable).d2r = function (index, x, y) {
    this.i20();
    this.z2r_1.d2r(index, x, y);
    this.i20();
    this.l20();
    return this;
  };
  protoOf(PolylineDrawable).e2r = function (points) {
    this.i20();
    this.z2r_1.e2r(points);
    this.i20();
    this.l20();
    return this;
  };
  protoOf(PolylineDrawable).f2r = function (x, y) {
    this.i20();
    this.z2r_1.f2r(x, y);
    this.i20();
    this.l20();
    return this;
  };
  protoOf(PolylineDrawable).b2s = function () {
    return this.l1u().f1u_1;
  };
  protoOf(PolylineDrawable).g2r = function (x, y, area) {
    return this.z2r_1.g2r(x, y, area);
  };
  protoOf(PolylineDrawable).i2r = function (x, y, area) {
    return this.z2r_1.i2r(x, y, area);
  };
  protoOf(PolylineDrawable).j2r = function (index) {
    return this.z2r_1.j2r(index);
  };
  protoOf(PolylineDrawable).k2r = function () {
    this.i20();
    if (this.z2r_1.k2r()) {
      this.i20();
      this.l20();
      return true;
    }
    return false;
  };
  protoOf(PolylineDrawable).l2r = function (index) {
    return this.z2r_1.l2r(index);
  };
  protoOf(PolylineDrawable).m2r = function (startIndex, endIndex) {
    return this.z2r_1.m2r(startIndex, endIndex);
  };
  protoOf(PolylineDrawable).n2r = function (index) {
    return this.z2r_1.n2r(index);
  };
  protoOf(PolylineDrawable).o2r = function (index) {
    return this.z2r_1.o2r(index);
  };
  protoOf(PolylineDrawable).p2r = function (index) {
    return this.z2r_1.p2r(index);
  };
  protoOf(PolylineDrawable).f2i = function (x) {
    this.z2r_1.f2i(x);
  };
  protoOf(PolylineDrawable).g2i = function (y) {
    this.z2r_1.g2i(y);
  };
  protoOf(PolylineDrawable).r2r = function (otherIndex, other) {
    return this.z2r_1.r2r(otherIndex, other);
  };
  protoOf(PolylineDrawable).q2r = function (index, otherIndex, other) {
    return this.z2r_1.q2r(index, otherIndex, other);
  };
  function calculateIntersectionCount($this, points, other) {
    // Inline function 'kotlin.collections.sumOf' call
    var sum = 0;
    var progression = until(0, points.o() - 1 | 0);
    var inductionVariable = progression.y_1;
    var last = progression.z_1;
    if (inductionVariable <= last)
      do {
        var element = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        var tmp = sum;
        var it = element;
        sum = tmp + calculateIntersectionCount_0(Companion_instance_31, it, points, other) | 0;
      }
       while (!(element === last));
    return sum;
  }
  function calculateIntersectionCount_0($this, index, points, other) {
    var tmp0 = until(0, other.o() - 1 | 0);
    var tmp$ret$0;
    $l$block: {
      // Inline function 'kotlin.collections.count' call
      var tmp;
      if (isInterface(tmp0, Collection)) {
        tmp = tmp0.m();
      } else {
        tmp = false;
      }
      if (tmp) {
        tmp$ret$0 = 0;
        break $l$block;
      }
      var count = 0;
      var inductionVariable = tmp0.y_1;
      var last = tmp0.z_1;
      if (inductionVariable <= last)
        do {
          var element = inductionVariable;
          inductionVariable = inductionVariable + 1 | 0;
          var it = element;
          if (doSegmentsIntersect(Companion_instance_31, index, points, it, other)) {
            count = count + 1 | 0;
            checkCountOverflow(count);
          }
        }
         while (!(element === last));
      tmp$ret$0 = count;
    }
    return tmp$ret$0;
  }
  function doSegmentsIntersect($this, index, points, otherIndex, other) {
    var tmp;
    if ($this.e2s(index, points) && $this.d2s(otherIndex, other)) {
      tmp = (Companion_getInstance().a1h(points.l(index), points.l(index + 1 | 0)).c1(other.l(otherIndex).kn_1) && Companion_getInstance().b1h(other.l(otherIndex), other.l(otherIndex + 1 | 0)).c1(points.l(index).ln_1));
    } else if ($this.d2s(index, points) && $this.e2s(otherIndex, other)) {
      tmp = (Companion_getInstance().b1h(points.l(index), points.l(index + 1 | 0)).c1(other.l(otherIndex).ln_1) && Companion_getInstance().a1h(other.l(otherIndex), other.l(otherIndex + 1 | 0)).c1(points.l(index).kn_1));
    } else {
      tmp = false;
    }
    return tmp;
  }
  function calculateOverlappingCount($this, points, other) {
    // Inline function 'kotlin.collections.sumOf' call
    var sum = 0;
    var progression = until(0, points.o() - 1 | 0);
    var inductionVariable = progression.y_1;
    var last = progression.z_1;
    if (inductionVariable <= last)
      do {
        var element = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        var tmp = sum;
        var it = element;
        sum = tmp + calculateOverlappingCount_0(Companion_instance_31, points, it, other) | 0;
      }
       while (!(element === last));
    return sum;
  }
  function calculateOverlappingCount_0($this, points, index, other) {
    var tmp0 = until(0, other.o() - 1 | 0);
    var tmp$ret$0;
    $l$block: {
      // Inline function 'kotlin.collections.count' call
      var tmp;
      if (isInterface(tmp0, Collection)) {
        tmp = tmp0.m();
      } else {
        tmp = false;
      }
      if (tmp) {
        tmp$ret$0 = 0;
        break $l$block;
      }
      var count = 0;
      var inductionVariable = tmp0.y_1;
      var last = tmp0.z_1;
      if (inductionVariable <= last)
        do {
          var element = inductionVariable;
          inductionVariable = inductionVariable + 1 | 0;
          var it = element;
          if (Companion_instance_31.f2s(index, points, other, it)) {
            count = count + 1 | 0;
            checkCountOverflow(count);
          }
        }
         while (!(element === last));
      tmp$ret$0 = count;
    }
    return tmp$ret$0;
  }
  function overlapHorizontally($this, index, points, other, otherIndex) {
    var tmp;
    // Inline function 'kotlin.math.abs' call
    var x = points.l(index).ln_1 - other.l(otherIndex).ln_1;
    if (Math.abs(x) <= 2) {
      tmp = points.l(index).kn_1 >= other.l(otherIndex).kn_1 && points.l(index).kn_1 <= other.l(otherIndex + 1 | 0).kn_1 || (points.l(index + 1 | 0).kn_1 >= other.l(otherIndex).kn_1 && points.l(index + 1 | 0).kn_1 <= other.l(otherIndex + 1 | 0).kn_1);
    } else {
      tmp = false;
    }
    return tmp;
  }
  function overlapVertically($this, points, index, other, otherIndex) {
    // Inline function 'kotlin.math.abs' call
    var x = points.l(index).kn_1 - other.l(otherIndex).kn_1;
    if (Math.abs(x) > 2) {
      return false;
    }
    var tmp0 = points.l(index).ln_1;
    // Inline function 'kotlin.math.min' call
    var b = points.l(index + 1 | 0).ln_1;
    var tmp = Math.min(tmp0, b);
    var tmp0_0 = points.l(index).ln_1;
    // Inline function 'kotlin.math.max' call
    var b_0 = points.l(index + 1 | 0).ln_1;
    var tmp$ret$2 = Math.max(tmp0_0, b_0);
    var range = rangeTo_0(tmp, tmp$ret$2);
    return range.c1(other.l(otherIndex).ln_1) || range.c1(other.l(otherIndex + 1 | 0).ln_1);
  }
  function Companion_27() {
  }
  protoOf(Companion_27).e2s = function (index, points) {
    return Geometry_instance.n1g(points.l(index).ln_1, points.l(index + 1 | 0).ln_1);
  };
  protoOf(Companion_27).d2s = function (index, points) {
    return Geometry_instance.n1g(points.l(index).kn_1, points.l(index + 1 | 0).kn_1);
  };
  protoOf(Companion_27).g2s = function (points, others) {
    // Inline function 'kotlin.collections.sumOf' call
    var sum = 0;
    var _iterator__ex2g4s = others.i();
    while (_iterator__ex2g4s.j()) {
      var element = _iterator__ex2g4s.k();
      var tmp = sum;
      sum = tmp + calculateIntersectionCount(Companion_instance_31, points, element) | 0;
    }
    var tmp_0 = sum;
    // Inline function 'kotlin.collections.sumOf' call
    var sum_0 = 0;
    var _iterator__ex2g4s_0 = others.i();
    while (_iterator__ex2g4s_0.j()) {
      var element_0 = _iterator__ex2g4s_0.k();
      var tmp_1 = sum_0;
      sum_0 = tmp_1 + calculateOverlappingCount(Companion_instance_31, points, element_0) | 0;
    }
    var tmp$ret$2 = sum_0;
    return new PolylineInterference(tmp_0, tmp$ret$2);
  };
  protoOf(Companion_27).f2s = function (index, points, other, otherIndex) {
    var tmp;
    if (this.e2s(index, points) && this.e2s(otherIndex, other)) {
      tmp = overlapHorizontally(this, index, points, other, otherIndex);
    } else if (this.d2s(index, points) && this.d2s(otherIndex, other)) {
      tmp = overlapVertically(this, points, index, other, otherIndex);
    } else {
      tmp = false;
    }
    return tmp;
  };
  var Companion_instance_31;
  function Companion_getInstance_29() {
    return Companion_instance_31;
  }
  function PolylineShape() {
  }
  function Companion_28() {
    this.h2s_1 = 2.0;
  }
  var Companion_instance_32;
  function Companion_getInstance_30() {
    return Companion_instance_32;
  }
  function _get_segmentIndices__vithg7($this) {
    return until(0, $this.t2k() - 1 | 0);
  }
  function updateBoundingBox($this) {
    var bbox = new Rectangle2D();
    if ($this.t2k() === 0) {
      $this.j2s_1 = bbox;
      return Unit_instance;
    }
    bbox.i1c($this.i2s_1.l(0).kn_1, $this.i2s_1.l(0).ln_1, 0.0, 0.0);
    var inductionVariable = 1;
    var last = $this.t2k();
    if (inductionVariable < last)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        bbox.eo($this.i2s_1.l(i));
      }
       while (inductionVariable < last);
    if (!($this.k2s_1 == null)) {
      bbox.n1c(ensureNotNull($this.k2s_1).fo());
    }
    if (!($this.l2s_1 == null)) {
      bbox.n1c(ensureNotNull($this.l2s_1).fo());
    }
    $this.j2s_1 = bbox;
  }
  function updateLineTerminatorLocations($this) {
    if (!($this.k2s_1 == null) && $this.t2k() >= 2) {
      ensureNotNull($this.k2s_1).t2q($this.i2s_1.l(0), $this.i2s_1.l(1));
    }
    if (!($this.l2s_1 == null) && $this.t2k() >= 2) {
      ensureNotNull($this.l2s_1).t2q(last($this.i2s_1), $this.i2s_1.l($this.t2k() - 2 | 0));
    }
  }
  function intersects_1($this, r) {
    var tmp0 = _get_segmentIndices__vithg7($this);
    var tmp$ret$0;
    $l$block_0: {
      // Inline function 'kotlin.collections.any' call
      var tmp;
      if (isInterface(tmp0, Collection)) {
        tmp = tmp0.m();
      } else {
        tmp = false;
      }
      if (tmp) {
        tmp$ret$0 = false;
        break $l$block_0;
      }
      var inductionVariable = tmp0.y_1;
      var last = tmp0.z_1;
      if (inductionVariable <= last)
        do {
          var element = inductionVariable;
          inductionVariable = inductionVariable + 1 | 0;
          var it = element;
          if (intersectsSegment($this, it, r)) {
            tmp$ret$0 = true;
            break $l$block_0;
          }
        }
         while (!(element === last));
      tmp$ret$0 = false;
    }
    return tmp$ret$0;
  }
  function intersectsSegment($this, index, r) {
    if ($this.t2k() < 2) {
      return false;
    }
    var start = $this.i2s_1.l(index);
    var end = $this.i2s_1.l(index + 1 | 0);
    return r.k1c(start.kn_1, start.ln_1, end.kn_1, end.ln_1);
  }
  function canCompactPoint($this, index) {
    if ($this.i2s_1.l(index).equals($this.i2s_1.l(index - 1 | 0))) {
      return true;
    }
    if (index > ($this.t2k() - 2 | 0)) {
      return false;
    }
    return isCoparallelX($this, index) || isCoparallelY($this, index);
  }
  function isCoparallelX($this, index) {
    return Geometry_instance.n1g($this.i2s_1.l(index).kn_1, $this.i2s_1.l(index - 1 | 0).kn_1) && Geometry_instance.n1g($this.i2s_1.l(index).kn_1, $this.i2s_1.l(index + 1 | 0).kn_1);
  }
  function isCoparallelY($this, index) {
    return Geometry_instance.n1g($this.i2s_1.l(index).ln_1, $this.i2s_1.l(index - 1 | 0).ln_1) && Geometry_instance.n1g($this.i2s_1.l(index).ln_1, $this.i2s_1.l(index + 1 | 0).ln_1);
  }
  function containsInArea($this, x, y) {
    if ($this.i2s_1.o() <= 2 || !$this.fo().go(x, y)) {
      return false;
    }
    var hits = 0;
    var lastX;
    var lastY;
    var curX = last($this.i2s_1).kn_1;
    var curY = last($this.i2s_1).ln_1;
    var i = -1;
    $l$loop_5: while (i < ($this.i2s_1.o() - 1 | 0)) {
      i = i + 1 | 0;
      lastX = curX;
      lastY = curY;
      curX = $this.i2s_1.l(i).kn_1;
      curY = $this.i2s_1.l(i).ln_1;
      if (curY === lastY) {
        continue $l$loop_5;
      }
      var tmp;
      if (curX < lastX) {
        if (x >= lastX) {
          continue $l$loop_5;
        }
        tmp = numberToInt(curX);
      } else {
        if (x >= curX) {
          continue $l$loop_5;
        }
        tmp = numberToInt(lastX);
      }
      var leftX = tmp;
      var test1;
      var test2;
      if (curY < lastY) {
        if (y < curY || y >= lastY) {
          continue $l$loop_5;
        }
        if (x < leftX) {
          hits = hits + 1 | 0;
          continue $l$loop_5;
        }
        test1 = x - curX;
        test2 = y - curY;
      } else {
        if (y < lastY || y >= curY) {
          continue $l$loop_5;
        }
        if (x < leftX) {
          hits = hits + 1 | 0;
          continue $l$loop_5;
        }
        test1 = x - lastX;
        test2 = y - lastY;
      }
      if (test1 < test2 / (lastY - curY) * (lastX - curX)) {
        hits = hits + 1 | 0;
      }
    }
    return !((hits & 1) === 0);
  }
  function PolylineShapeImpl(pts) {
    var tmp;
    if (pts === VOID) {
      // Inline function 'kotlin.collections.mutableListOf' call
      tmp = ArrayList_init_$Create$();
    } else {
      tmp = pts;
    }
    pts = tmp;
    var tmp_0 = this;
    // Inline function 'kotlin.collections.mutableListOf' call
    tmp_0.i2s_1 = ArrayList_init_$Create$();
    this.j2s_1 = new Rectangle2D();
    if (!(pts == null)) {
      this.i2s_1.f1(pts);
    }
    updateBoundingBox(this);
    this.k2s_1 = null;
    this.l2s_1 = null;
  }
  protoOf(PolylineShapeImpl).y2q = function () {
    return this.i2s_1;
  };
  protoOf(PolylineShapeImpl).fo = function () {
    return this.j2s_1;
  };
  protoOf(PolylineShapeImpl).go = function (x, y) {
    return containsInArea(this, x, y) || this.io(x - 2.0, y - 2.0, 2 * 2.0, 2 * 2.0);
  };
  protoOf(PolylineShapeImpl).ho = function (x, y, width, height) {
    return false;
  };
  protoOf(PolylineShapeImpl).io = function (x, y, w, h) {
    return intersects_1(this, new Rectangle2D(x, y, w, h));
  };
  protoOf(PolylineShapeImpl).a = function () {
    var l = 0.0;
    if (this.t2k() > 1) {
      var progression = _get_segmentIndices__vithg7(this);
      var inductionVariable = progression.y_1;
      var last = progression.z_1;
      if (inductionVariable <= last)
        do {
          var i = inductionVariable;
          inductionVariable = inductionVariable + 1 | 0;
          l = l + this.l2r(i);
        }
         while (!(i === last));
    }
    return l;
  };
  protoOf(PolylineShapeImpl).t2k = function () {
    return this.i2s_1.o();
  };
  protoOf(PolylineShapeImpl).u2q = function (value) {
    this.k2s_1 = value;
    updateLineTerminatorLocations(this);
    updateBoundingBox(this);
  };
  protoOf(PolylineShapeImpl).v2q = function () {
    return this.k2s_1;
  };
  protoOf(PolylineShapeImpl).w2q = function (value) {
    this.l2s_1 = value;
    updateLineTerminatorLocations(this);
    updateBoundingBox(this);
  };
  protoOf(PolylineShapeImpl).x2q = function () {
    return this.l2s_1;
  };
  protoOf(PolylineShapeImpl).a2 = function () {
    this.i2s_1.a2();
    updateBoundingBox(this);
  };
  protoOf(PolylineShapeImpl).z2q = function (index, x, y) {
    this.i2s_1.t3(index, new Point2D(x, y));
    updateLineTerminatorLocations(this);
    updateBoundingBox(this);
    return this;
  };
  protoOf(PolylineShapeImpl).a2r = function (index) {
    this.i2s_1.h3(index);
    updateLineTerminatorLocations(this);
    updateBoundingBox(this);
    return this;
  };
  protoOf(PolylineShapeImpl).u2k = function (index) {
    return this.i2s_1.l(index);
  };
  protoOf(PolylineShapeImpl).d2r = function (index, x, y) {
    this.i2s_1.u2(index, new Point2D(x, y));
    updateLineTerminatorLocations(this);
    updateBoundingBox(this);
    return this;
  };
  protoOf(PolylineShapeImpl).e2r = function (points) {
    this.i2s_1.a2();
    var _iterator__ex2g4s = points.i();
    while (_iterator__ex2g4s.j()) {
      var p = _iterator__ex2g4s.k();
      this.i2s_1.h(Point2D_init_$Create$_0(p));
    }
    updateLineTerminatorLocations(this);
    updateBoundingBox(this);
    return this;
  };
  protoOf(PolylineShapeImpl).f2r = function (x, y) {
    if (this.t2k() === 0) {
      return this;
    }
    var dx = x - this.i2s_1.l(0).kn_1;
    var dy = y - this.i2s_1.l(0).ln_1;
    // Inline function 'kotlin.collections.forEachIndexed' call
    var index = 0;
    var _iterator__ex2g4s = toList(this.i2s_1).i();
    while (_iterator__ex2g4s.j()) {
      var item = _iterator__ex2g4s.k();
      var _unary__edvuaz = index;
      index = _unary__edvuaz + 1 | 0;
      var index_0 = checkIndexOverflow(_unary__edvuaz);
      this.i2s_1.u2(index_0, new Point2D(item.kn_1 + dx, item.ln_1 + dy));
    }
    updateLineTerminatorLocations(this);
    updateBoundingBox(this);
    return this;
  };
  protoOf(PolylineShapeImpl).g2r = function (x, y, area) {
    var rect = new Rectangle2D(x - area, y - area, 2 * area, 2 * area);
    var tmp0 = _get_segmentIndices__vithg7(this);
    var tmp$ret$0;
    $l$block: {
      // Inline function 'kotlin.collections.firstOrNull' call
      var inductionVariable = tmp0.y_1;
      var last = tmp0.z_1;
      if (inductionVariable <= last)
        do {
          var element = inductionVariable;
          inductionVariable = inductionVariable + 1 | 0;
          var it = element;
          if (intersectsSegment(this, it, rect)) {
            tmp$ret$0 = element;
            break $l$block;
          }
        }
         while (!(element === last));
      tmp$ret$0 = null;
    }
    return tmp$ret$0;
  };
  protoOf(PolylineShapeImpl).i2r = function (x, y, area) {
    // Inline function 'io.antarescircuit.jabbah.base.collection.indexOfFirstOrNull' call
    var tmp0 = this.i2s_1;
    var tmp$ret$1;
    $l$block: {
      // Inline function 'kotlin.collections.indexOfFirst' call
      var index = 0;
      var _iterator__ex2g4s = tmp0.i();
      while (_iterator__ex2g4s.j()) {
        var item = _iterator__ex2g4s.k();
        if (item.i1h(x, y, area)) {
          tmp$ret$1 = index;
          break $l$block;
        }
        index = index + 1 | 0;
      }
      tmp$ret$1 = -1;
    }
    var index_0 = tmp$ret$1;
    return index_0 >= 0 ? index_0 : null;
  };
  protoOf(PolylineShapeImpl).j2r = function (index) {
    return new Point2D(this.i2s_1.l(index).kn_1 + (this.i2s_1.l(index + 1 | 0).kn_1 - this.i2s_1.l(index).kn_1) / 2, this.i2s_1.l(index).ln_1 + (this.i2s_1.l(index + 1 | 0).ln_1 - this.i2s_1.l(index).ln_1) / 2);
  };
  protoOf(PolylineShapeImpl).k2r = function () {
    if (this.t2k() <= 2) {
      return false;
    }
    var i = 1;
    var changed = false;
    while (i < this.t2k()) {
      if (canCompactPoint(this, i)) {
        changed = true;
        this.i2s_1.h3(i);
        if (i > 1) {
          i = i - 1 | 0;
        }
      } else {
        i = i + 1 | 0;
      }
    }
    if (changed) {
      updateBoundingBox(this);
    }
    return changed;
  };
  protoOf(PolylineShapeImpl).l2r = function (index) {
    return this.i2s_1.l(index).f1h(this.i2s_1.l(index + 1 | 0));
  };
  protoOf(PolylineShapeImpl).m2r = function (startIndex, endIndex) {
    return this.i2s_1.w1(startIndex, endIndex);
  };
  protoOf(PolylineShapeImpl).n2r = function (index) {
    return Companion_instance_31.e2s(index, this.i2s_1);
  };
  protoOf(PolylineShapeImpl).o2r = function (index) {
    return Companion_instance_31.d2s(index, this.i2s_1);
  };
  protoOf(PolylineShapeImpl).q2r = function (index, otherIndex, other) {
    return Companion_instance_31.e2s(index, this.i2s_1) && Companion_instance_31.d2s(otherIndex, other) || (Companion_instance_31.d2s(index, this.i2s_1) && Companion_instance_31.e2s(otherIndex, other));
  };
  protoOf(PolylineShapeImpl).f2i = function (x) {
    // Inline function 'kotlin.collections.map' call
    var this_0 = this.i2s_1;
    // Inline function 'kotlin.collections.mapTo' call
    var destination = ArrayList_init_$Create$_0(collectionSizeOrDefault(this_0, 10));
    var _iterator__ex2g4s = this_0.i();
    while (_iterator__ex2g4s.j()) {
      var item = _iterator__ex2g4s.k();
      var tmp$ret$2 = item.g1h(x);
      destination.h(tmp$ret$2);
    }
    this.e2r(destination);
  };
  protoOf(PolylineShapeImpl).g2i = function (y) {
    // Inline function 'kotlin.collections.map' call
    var this_0 = this.i2s_1;
    // Inline function 'kotlin.collections.mapTo' call
    var destination = ArrayList_init_$Create$_0(collectionSizeOrDefault(this_0, 10));
    var _iterator__ex2g4s = this_0.i();
    while (_iterator__ex2g4s.j()) {
      var item = _iterator__ex2g4s.k();
      var tmp$ret$2 = item.h1h(y);
      destination.h(tmp$ret$2);
    }
    this.e2r(destination);
  };
  protoOf(PolylineShapeImpl).r2r = function (otherIndex, other) {
    var tmp0 = _get_segmentIndices__vithg7(this);
    var tmp$ret$0;
    $l$block_0: {
      // Inline function 'kotlin.collections.any' call
      var tmp;
      if (isInterface(tmp0, Collection)) {
        tmp = tmp0.m();
      } else {
        tmp = false;
      }
      if (tmp) {
        tmp$ret$0 = false;
        break $l$block_0;
      }
      var inductionVariable = tmp0.y_1;
      var last = tmp0.z_1;
      if (inductionVariable <= last)
        do {
          var element = inductionVariable;
          inductionVariable = inductionVariable + 1 | 0;
          var it = element;
          if (Companion_instance_31.f2s(it, this.i2s_1, other, otherIndex)) {
            tmp$ret$0 = true;
            break $l$block_0;
          }
        }
         while (!(element === last));
      tmp$ret$0 = false;
    }
    return tmp$ret$0;
  };
  function fillProperties_2($this, properties) {
    properties.et('draw.style.foregroundColor', Companion_getInstance_20().d1t_1);
    properties.et('draw.style.backgroundColor', Companion_getInstance_20().e1t_1);
    properties.et('draw.style.textColor', Companion_getInstance_20().d1t_1);
    properties.et('draw.style.stroke', new Stroke());
    properties.et('draw.style.font', new FontImpl());
  }
  function configureStyleRepository($this, repository) {
    repository.m2s(Companion_getInstance_33().d1y_1, new BasicStyle());
    repository.m2s(Companion_getInstance_33().b1y_1, new BasicStyle());
    repository.m2s(Companion_getInstance_33().c1y_1, new BasicStyle());
    repository.m2s(Companion_getInstance_33().e1y_1, new BasicStyle());
  }
  function DrawStyleModule() {
    DrawStyleModule_instance = this;
    AbstractModule.call(this);
    this.w1x_1 = Companion_getInstance_32().n2s_1;
  }
  protoOf(DrawStyleModule).to = function () {
    DrawGraphicsModule_getInstance().vo();
    fillProperties_2(this, BaseModule_getInstance().zo_1);
    configureStyleRepository(this, Companion_getInstance_32().n2s_1);
  };
  var DrawStyleModule_instance;
  function DrawStyleModule_getInstance() {
    if (DrawStyleModule_instance == null)
      new DrawStyleModule();
    return DrawStyleModule_instance;
  }
  function Companion_29() {
    Companion_instance_33 = this;
    this.p2s_1 = 'default';
    this.q2s_1 = false;
    this.r2s_1 = new BasicStyle(new CompositeColor(Color_init_$Create$(240, 240, 240), Companion_getInstance_20().e1t_1, Companion_getInstance_20().d1t_1));
    this.s2s_1 = new BasicStyle();
    this.t2s_1 = new BasicStyle();
    this.u2s_1 = new BasicStyle(VOID, this.t2s_1.l1u().o2p());
    this.v2s_1 = new BasicStyle(new CompositeColor(Color_init_$Create$(249, 214, 54), Color_init_$Create$(255, 253, 219), Companion_getInstance_20().d1t_1));
    this.w2s_1 = new CompositeColor(Companion_getInstance_20().i1t_1, Companion_getInstance_20().i1t_1, Companion_getInstance_20().i1t_1);
    this.x2s_1 = new CompositeColor(Companion_getInstance_20().g1t_1, Companion_getInstance_20().e1t_1);
    this.y2s_1 = listOf([new ReferenceColor(DrawGraphicsModule_getInstance().a2m_1, DrawGraphicsModule_getInstance().b2m_1), new ReferenceColor(DrawGraphicsModule_getInstance().u2l_1, DrawGraphicsModule_getInstance().v2l_1), new ReferenceColor(DrawGraphicsModule_getInstance().w2l_1, DrawGraphicsModule_getInstance().x2l_1), new ReferenceColor(DrawGraphicsModule_getInstance().y2l_1, DrawGraphicsModule_getInstance().z2l_1), new ReferenceColor(DrawGraphicsModule_getInstance().e2m_1, DrawGraphicsModule_getInstance().f2m_1), new ReferenceColor(DrawGraphicsModule_getInstance().c2m_1, DrawGraphicsModule_getInstance().d2m_1), new ReferenceColor(DrawGraphicsModule_getInstance().m2m_1, DrawGraphicsModule_getInstance().m2m_1.v2k()), new ReferenceColor(DrawGraphicsModule_getInstance().k2m_1, DrawGraphicsModule_getInstance().k2m_1.v2k()), new ReferenceColor(DrawGraphicsModule_getInstance().l2m_1, DrawGraphicsModule_getInstance().l2m_1.v2k())]);
    this.z2s_1 = listOf([new PredefinedColor(PredefinedColorIdentity_White_getInstance(), DrawGraphicsModule_getInstance().k2m_1), new PredefinedColor(PredefinedColorIdentity_Black_getInstance(), DrawGraphicsModule_getInstance().l2m_1), new PredefinedColor(PredefinedColorIdentity_Gray_getInstance(), DrawGraphicsModule_getInstance().m2m_1), new PredefinedColor(PredefinedColorIdentity_Yellow_getInstance(), DrawGraphicsModule_getInstance().a2m_1), new PredefinedColor(PredefinedColorIdentity_Brown_getInstance(), DrawGraphicsModule_getInstance().g2m_1), new PredefinedColor(PredefinedColorIdentity_Red_getInstance(), DrawGraphicsModule_getInstance().u2l_1), new PredefinedColor(PredefinedColorIdentity_Violet_getInstance(), DrawGraphicsModule_getInstance().c2m_1), new PredefinedColor(PredefinedColorIdentity_Blue_getInstance(), DrawGraphicsModule_getInstance().w2l_1), new PredefinedColor(PredefinedColorIdentity_Turquoise_getInstance(), DrawGraphicsModule_getInstance().i2m_1), new PredefinedColor(PredefinedColorIdentity_Green_getInstance(), DrawGraphicsModule_getInstance().y2l_1)]);
  }
  var Companion_instance_33;
  function Companion_getInstance_31() {
    if (Companion_instance_33 == null)
      new Companion_29();
    return Companion_instance_33;
  }
  function DrawTheme(name, dark, referenceColorSequenceProvider, referenceColors, predefinedColors, background, text, figure, annotation, tooltip, shadow, hover) {
    Companion_getInstance_31();
    name = name === VOID ? 'default' : name;
    dark = dark === VOID ? false : dark;
    referenceColorSequenceProvider = referenceColorSequenceProvider === VOID ? ReferenceColorSequenceProvider_getInstance() : referenceColorSequenceProvider;
    referenceColors = referenceColors === VOID ? Companion_getInstance_31().y2s_1 : referenceColors;
    predefinedColors = predefinedColors === VOID ? Companion_getInstance_31().z2s_1 : predefinedColors;
    background = background === VOID ? Companion_getInstance_31().r2s_1 : background;
    text = text === VOID ? Companion_getInstance_31().s2s_1 : text;
    figure = figure === VOID ? Companion_getInstance_31().t2s_1 : figure;
    annotation = annotation === VOID ? Companion_getInstance_31().u2s_1 : annotation;
    tooltip = tooltip === VOID ? Companion_getInstance_31().v2s_1 : tooltip;
    shadow = shadow === VOID ? Companion_getInstance_31().w2s_1 : shadow;
    hover = hover === VOID ? Companion_getInstance_31().x2s_1 : hover;
    this.s2f_1 = name;
    this.t2f_1 = dark;
    this.u2f_1 = referenceColorSequenceProvider;
    this.v2f_1 = referenceColors;
    this.w2f_1 = predefinedColors;
    this.x2f_1 = background;
    this.y2f_1 = text;
    this.z2f_1 = figure;
    this.a2g_1 = annotation;
    this.b2g_1 = tooltip;
    this.c2g_1 = shadow;
    this.d2g_1 = hover;
  }
  protoOf(DrawTheme).m2 = function () {
    return this.s2f_1;
  };
  protoOf(DrawTheme).e2t = function () {
    return this.t2f_1;
  };
  protoOf(DrawTheme).toString = function () {
    return this.m2();
  };
  protoOf(DrawTheme).f2t = function (styleRepository, styleOnly) {
    if (!styleOnly) {
      this.u2f_1.z2o(this.v2f_1);
      // Inline function 'kotlin.collections.forEach' call
      var _iterator__ex2g4s = this.w2f_1.i();
      while (_iterator__ex2g4s.j()) {
        var element = _iterator__ex2g4s.k();
        PredefinedColorRepository_getInstance().b2n(element);
      }
    }
    styleRepository.m2s(Companion_getInstance_33().a1y_1, this.y2f_1);
    styleRepository.m2s(Companion_getInstance_33().d1y_1, this.x2f_1);
    styleRepository.m2s(Companion_getInstance_33().b1y_1, this.z2f_1);
    styleRepository.m2s(Companion_getInstance_33().c1y_1, this.a2g_1);
    styleRepository.m2s(Companion_getInstance_33().e1y_1, this.b2g_1);
  };
  function Stylable() {
  }
  function StylableImpl$_color$lambda(this$0) {
    return function () {
      return new CompositeColor(this$0.y2c(), this$0.z2c(), this$0.a2d());
    };
  }
  function StylableImpl(invalidator, styleType, styleProvider, filled, stroked, customColor, customStroke, customFont, customShadow) {
    invalidator = invalidator === VOID ? null : invalidator;
    filled = filled === VOID ? true : filled;
    stroked = stroked === VOID ? true : stroked;
    customColor = customColor === VOID ? null : customColor;
    customStroke = customStroke === VOID ? null : customStroke;
    customFont = customFont === VOID ? null : customFont;
    customShadow = customShadow === VOID ? null : customShadow;
    this.g2t_1 = invalidator;
    this.h2t_1 = styleProvider;
    this.i2t_1 = styleType;
    this.j2t_1 = filled;
    this.k2t_1 = stroked;
    var tmp = this;
    tmp.l2t_1 = customColor == null ? null : customColor.z2n_1;
    var tmp_0 = this;
    tmp_0.m2t_1 = customStroke == null ? null : customStroke.i2o_1;
    this.n2t_1 = customFont;
    this.o2t_1 = customShadow;
    var tmp_1 = this;
    tmp_1.p2t_1 = resettableLazy(StylableImpl$_color$lambda(this));
  }
  protoOf(StylableImpl).w2c = function (_set____db54di) {
    this.g2t_1 = _set____db54di;
  };
  protoOf(StylableImpl).x2c = function () {
    return this.h2t_1;
  };
  protoOf(StylableImpl).c2d = function (value) {
    if (!equals(this.i2t_1, value)) {
      var tmp0_safe_receiver = this.g2t_1;
      if (tmp0_safe_receiver == null)
        null;
      else
        tmp0_safe_receiver();
      this.i2t_1 = value;
      var tmp1_safe_receiver = this.g2t_1;
      if (tmp1_safe_receiver == null)
        null;
      else
        tmp1_safe_receiver();
      this.p2t_1.du();
    }
  };
  protoOf(StylableImpl).h29 = function () {
    return this.i2t_1;
  };
  protoOf(StylableImpl).d2d = function () {
    return this.h2t_1.f1y(this.i2t_1);
  };
  protoOf(StylableImpl).e2d = function (value) {
    if (!(this.j2t_1 === value)) {
      var tmp0_safe_receiver = this.g2t_1;
      if (tmp0_safe_receiver == null)
        null;
      else
        tmp0_safe_receiver();
      this.j2t_1 = value;
      var tmp1_safe_receiver = this.g2t_1;
      if (tmp1_safe_receiver == null)
        null;
      else
        tmp1_safe_receiver();
    }
  };
  protoOf(StylableImpl).f2d = function () {
    return this.j2t_1;
  };
  protoOf(StylableImpl).g2d = function (value) {
    if (!(this.k2t_1 === value)) {
      var tmp0_safe_receiver = this.g2t_1;
      if (tmp0_safe_receiver == null)
        null;
      else
        tmp0_safe_receiver();
      this.k2t_1 = value;
      var tmp1_safe_receiver = this.g2t_1;
      if (tmp1_safe_receiver == null)
        null;
      else
        tmp1_safe_receiver();
    }
  };
  protoOf(StylableImpl).h2d = function () {
    return this.k2t_1;
  };
  protoOf(StylableImpl).j2d = function (value) {
    var tmp = this.l2t_1;
    if (!equals(tmp, value == null ? null : value.z2n_1)) {
      var tmp0_safe_receiver = this.g2t_1;
      if (tmp0_safe_receiver == null)
        null;
      else
        tmp0_safe_receiver();
      var tmp_0 = this;
      tmp_0.l2t_1 = value == null ? null : value.z2n_1;
      var tmp2_safe_receiver = this.g2t_1;
      if (tmp2_safe_receiver == null)
        null;
      else
        tmp2_safe_receiver();
      this.p2t_1.du();
    }
  };
  protoOf(StylableImpl).k2d = function () {
    return !(this.l2t_1 == null) ? PredefinedColorRepository_getInstance().h2o(ensureNotNull(this.l2t_1)) : null;
  };
  protoOf(StylableImpl).l2d = function (value) {
    var tmp = this.m2t_1;
    if (!equals(tmp, value == null ? null : value.i2o_1)) {
      var tmp0_safe_receiver = this.g2t_1;
      if (tmp0_safe_receiver == null)
        null;
      else
        tmp0_safe_receiver();
      var tmp_0 = this;
      tmp_0.m2t_1 = value == null ? null : value.i2o_1;
      var tmp2_safe_receiver = this.g2t_1;
      if (tmp2_safe_receiver == null)
        null;
      else
        tmp2_safe_receiver();
    }
  };
  protoOf(StylableImpl).m2d = function () {
    return !(this.m2t_1 == null) ? PredefinedStrokeRepository_getInstance().l2o(ensureNotNull(this.m2t_1)) : null;
  };
  protoOf(StylableImpl).n2d = function (value) {
    if (!equals(this.n2t_1, value)) {
      var tmp0_safe_receiver = this.g2t_1;
      if (tmp0_safe_receiver == null)
        null;
      else
        tmp0_safe_receiver();
      this.n2t_1 = value;
      var tmp1_safe_receiver = this.g2t_1;
      if (tmp1_safe_receiver == null)
        null;
      else
        tmp1_safe_receiver();
    }
  };
  protoOf(StylableImpl).o2d = function (value) {
    if (!(this.o2t_1 == value)) {
      var effectiveValue = value === this.i2d() ? null : value;
      var tmp0_safe_receiver = this.g2t_1;
      if (tmp0_safe_receiver == null)
        null;
      else
        tmp0_safe_receiver();
      this.o2t_1 = effectiveValue;
      var tmp1_safe_receiver = this.g2t_1;
      if (tmp1_safe_receiver == null)
        null;
      else
        tmp1_safe_receiver();
    }
  };
  protoOf(StylableImpl).p2d = function () {
    return this.o2t_1;
  };
  protoOf(StylableImpl).c1u = function () {
    return this.p2t_1.j2();
  };
  protoOf(StylableImpl).y2c = function () {
    var tmp0_safe_receiver = this.k2d();
    var tmp1_safe_receiver = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.a2o_1;
    var tmp2_elvis_lhs = tmp1_safe_receiver == null ? null : tmp1_safe_receiver.x1x_1;
    return tmp2_elvis_lhs == null ? this.d2d().c1u().x1x_1 : tmp2_elvis_lhs;
  };
  protoOf(StylableImpl).z2c = function () {
    var tmp0_safe_receiver = this.k2d();
    var tmp1_safe_receiver = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.a2o_1;
    var tmp2_elvis_lhs = tmp1_safe_receiver == null ? null : tmp1_safe_receiver.y1x_1;
    return tmp2_elvis_lhs == null ? this.d2d().c1u().y1x_1 : tmp2_elvis_lhs;
  };
  protoOf(StylableImpl).a2d = function () {
    var tmp0_safe_receiver = this.k2d();
    var tmp1_safe_receiver = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.a2o_1;
    var tmp2_elvis_lhs = tmp1_safe_receiver == null ? null : tmp1_safe_receiver.z1x_1;
    return tmp2_elvis_lhs == null ? this.d2d().c1u().z1x_1 : tmp2_elvis_lhs;
  };
  protoOf(StylableImpl).b2d = function () {
    var tmp0_elvis_lhs = this.n2t_1;
    return tmp0_elvis_lhs == null ? this.d2d().b2d() : tmp0_elvis_lhs;
  };
  protoOf(StylableImpl).l1u = function () {
    var tmp0_safe_receiver = this.m2d();
    var tmp1_elvis_lhs = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.j2o_1;
    return tmp1_elvis_lhs == null ? this.d2d().l1u() : tmp1_elvis_lhs;
  };
  protoOf(StylableImpl).i2d = function () {
    var tmp0_elvis_lhs = this.o2t_1;
    return tmp0_elvis_lhs == null ? this.d2d().i2d() : tmp0_elvis_lhs;
  };
  function BasicStyle(color, stroke, font, shadow) {
    color = color === VOID ? new CompositeColor(DrawModule_getInstance().l2a_1.z1z('draw.style.foregroundColor'), DrawModule_getInstance().l2a_1.z1z('draw.style.backgroundColor'), DrawModule_getInstance().l2a_1.z1z('draw.style.textColor')) : color;
    stroke = stroke === VOID ? DrawModule_getInstance().l2a_1.a20('draw.style.stroke') : stroke;
    font = font === VOID ? DrawModule_getInstance().l2a_1.y1z('draw.style.font') : font;
    shadow = shadow === VOID ? false : shadow;
    this.a2t_1 = color;
    this.b2t_1 = stroke;
    this.c2t_1 = font;
    this.d2t_1 = shadow;
  }
  protoOf(BasicStyle).c1u = function () {
    return this.a2t_1;
  };
  protoOf(BasicStyle).l1u = function () {
    return this.b2t_1;
  };
  protoOf(BasicStyle).b2d = function () {
    return this.c2t_1;
  };
  protoOf(BasicStyle).i2d = function () {
    return this.d2t_1;
  };
  function _get_LOG__e5r759_7($this) {
    var tmp0 = $this.o2s_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('LOG', 1, tmp, StyleRepository$Companion$_get_LOG_$ref_ip7vej(), null);
    return tmp0.j2();
  }
  function StyleRepository$Companion$_get_LOG_$ref_ip7vej() {
    return function (p0) {
      return _get_LOG__e5r759_7(p0);
    };
  }
  function Companion_30() {
    Companion_instance_34 = this;
    this.n2s_1 = new StyleRepository();
    this.o2s_1 = logger(getKClass(StyleRepository));
  }
  var Companion_instance_34;
  function Companion_getInstance_32() {
    if (Companion_instance_34 == null)
      new Companion_30();
    return Companion_instance_34;
  }
  function _get_typeMap__nyz98v($this) {
    var tmp0 = $this.n26_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('typeMap', 1, tmp, StyleRepository$_get_typeMap_$ref_u7jtez(), null);
    return tmp0.j2();
  }
  function _get_typeList__wsttqr($this) {
    var tmp0 = $this.o26_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('typeList', 1, tmp, StyleRepository$_get_typeList_$ref_x7lj9n(), null);
    return tmp0.j2();
  }
  function _get_styleMap__go6280($this) {
    var tmp0 = $this.p26_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('styleMap', 1, tmp, StyleRepository$_get_styleMap_$ref_nd1008(), null);
    return tmp0.j2();
  }
  function StyleRepository$typeMap$delegate$lambda() {
    // Inline function 'kotlin.collections.mutableMapOf' call
    return LinkedHashMap_init_$Create$();
  }
  function StyleRepository$_get_typeMap_$ref_u7jtez() {
    return function (p0) {
      return _get_typeMap__nyz98v(p0);
    };
  }
  function StyleRepository$typeList$delegate$lambda() {
    // Inline function 'kotlin.collections.mutableListOf' call
    return ArrayList_init_$Create$();
  }
  function StyleRepository$_get_typeList_$ref_x7lj9n() {
    return function (p0) {
      return _get_typeList__wsttqr(p0);
    };
  }
  function StyleRepository$styleMap$delegate$lambda() {
    // Inline function 'kotlin.collections.mutableMapOf' call
    return LinkedHashMap_init_$Create$();
  }
  function StyleRepository$_get_styleMap_$ref_nd1008() {
    return function (p0) {
      return _get_styleMap__go6280(p0);
    };
  }
  function StyleRepository(predefinedColorProvider, predefinedStrokeProvider) {
    Companion_getInstance_32();
    predefinedColorProvider = predefinedColorProvider === VOID ? PredefinedColorRepository_getInstance() : predefinedColorProvider;
    predefinedStrokeProvider = predefinedStrokeProvider === VOID ? PredefinedStrokeRepository_getInstance() : predefinedStrokeProvider;
    this.l26_1 = predefinedColorProvider;
    this.m26_1 = predefinedStrokeProvider;
    var tmp = this;
    tmp.n26_1 = lazy(StyleRepository$typeMap$delegate$lambda);
    var tmp_0 = this;
    tmp_0.o26_1 = lazy(StyleRepository$typeList$delegate$lambda);
    var tmp_1 = this;
    tmp_1.p26_1 = lazy(StyleRepository$styleMap$delegate$lambda);
  }
  protoOf(StyleRepository).q2t = function () {
    return this.l26_1;
  };
  protoOf(StyleRepository).r2t = function () {
    return this.m26_1;
  };
  protoOf(StyleRepository).f1y = function (styleType) {
    var style = _get_styleMap__go6280(this).g2(styleType);
    if (style == null) {
      _get_LOG__e5r759_7(Companion_getInstance_32()).ml("No registered Style for StyleType '" + styleType.d29_1 + "'");
      throw NoSuchElementException_init_$Create$('getStyle');
    }
    return style;
  };
  protoOf(StyleRepository).s2t = function (name) {
    var styleType = _get_typeMap__nyz98v(this).g2(name);
    if (styleType == null) {
      _get_LOG__e5r759_7(Companion_getInstance_32()).ml("No registered StyleType '" + name + "'");
      throw NoSuchElementException_init_$Create$('getStyleType');
    }
    return styleType;
  };
  protoOf(StyleRepository).t2t = function (styleType) {
    var tmp0 = _get_typeMap__nyz98v(this);
    // Inline function 'kotlin.collections.set' call
    var key = styleType.d29_1;
    tmp0.y1(key, styleType);
    _get_typeList__wsttqr(this).h(styleType);
    return this;
  };
  protoOf(StyleRepository).m2s = function (styleType, style) {
    if (!_get_typeMap__nyz98v(this).e2(styleType.d29_1)) {
      this.t2t(styleType);
    }
    // Inline function 'kotlin.collections.set' call
    _get_styleMap__go6280(this).y1(styleType, style);
    return this;
  };
  function Companion_31() {
    Companion_instance_35 = this;
    this.a1y_1 = new StyleType('text', 'draw.styleType.text.name');
    this.b1y_1 = new StyleType('figure', 'draw.styleType.figure.name');
    this.c1y_1 = new StyleType('annotation', 'draw.styleType.annotation.name');
    this.d1y_1 = new StyleType('background', 'draw.styleType.background.name', true);
    this.e1y_1 = new StyleType('tooltip', 'draw.styleType.tooltipView.name', true);
  }
  var Companion_instance_35;
  function Companion_getInstance_33() {
    if (Companion_instance_35 == null)
      new Companion_31();
    return Companion_instance_35;
  }
  function StyleType(name, descriptionKey, isSystem, isBackdrop) {
    Companion_getInstance_33();
    isSystem = isSystem === VOID ? false : isSystem;
    isBackdrop = isBackdrop === VOID ? false : isBackdrop;
    this.d29_1 = name;
    this.e29_1 = descriptionKey;
    this.f29_1 = isSystem;
    this.g29_1 = isBackdrop;
  }
  protoOf(StyleType).mq = function () {
    return Translations_getInstance().bn(this.e29_1, []);
  };
  protoOf(StyleType).toString = function () {
    return this.mq();
  };
  function _set_current__qj3kk($this, value) {
    if (!($this.g2g_1 === value)) {
      $this.g2g_1 = value;
      $this.g2g_1.f2t(DrawStyleModule_getInstance().w1x_1, false);
      BaseModule_getInstance().bp_1.gu(new ThemeEvent($this.g2g_1));
    }
  }
  function Themes() {
    Themes_instance = this;
    this.e2g_1 = 'draw.style.Theme.name';
    this.f2g_1 = mutableListOf([new DrawTheme()]);
    this.g2g_1 = this.f2g_1.l(0);
  }
  protoOf(Themes).h2g = function () {
    var tmp = this.g2g_1;
    return isInterface(tmp, Theme) ? tmp : THROW_CCE();
  };
  protoOf(Themes).ob = function (name) {
    var tmp0 = this.f2g_1;
    var tmp$ret$0;
    $l$block: {
      // Inline function 'kotlin.collections.firstOrNull' call
      var _iterator__ex2g4s = tmp0.i();
      while (_iterator__ex2g4s.j()) {
        var element = _iterator__ex2g4s.k();
        if (element.m2() === name) {
          tmp$ret$0 = element;
          break $l$block;
        }
      }
      tmp$ret$0 = null;
    }
    return tmp$ret$0;
  };
  protoOf(Themes).u2t = function (themes) {
    // Inline function 'kotlin.collections.isNotEmpty' call
    // Inline function 'kotlin.collections.isEmpty' call
    if (!(themes.length === 0)) {
      this.f2g_1.a2();
      addAll_0(this.f2g_1, themes);
      var tmp;
      if (BaseModule_getInstance().zo_1.dt('draw.style.Theme.name')) {
        tmp = BaseModule_getInstance().zo_1.jt('draw.style.Theme.name');
      } else {
        tmp = null;
      }
      var storedThemeName = tmp;
      // Inline function 'kotlin.collections.map' call
      var this_0 = this.f2g_1;
      // Inline function 'kotlin.collections.mapTo' call
      var destination = ArrayList_init_$Create$_0(collectionSizeOrDefault(this_0, 10));
      var _iterator__ex2g4s = this_0.i();
      while (_iterator__ex2g4s.j()) {
        var item = _iterator__ex2g4s.k();
        var tmp$ret$4 = item.m2();
        destination.h(tmp$ret$4);
      }
      if (contains(destination, storedThemeName)) {
        _set_current__qj3kk(this, ensureNotNull(this.ob(ensureNotNull(storedThemeName))));
      } else {
        _set_current__qj3kk(this, ensureNotNull(this.ob(first(this.f2g_1).m2())));
        this.v2t(this.g2g_1.m2());
      }
    }
  };
  protoOf(Themes).v2t = function (themeName) {
    BaseModule_getInstance().zo_1.et('draw.style.Theme.name', themeName);
  };
  var Themes_instance;
  function Themes_getInstance() {
    if (Themes_instance == null)
      new Themes();
    return Themes_instance;
  }
  function Theme() {
  }
  function ThemeEvent(currentTheme) {
    this.w2t_1 = currentTheme;
  }
  protoOf(ThemeEvent).toString = function () {
    return 'ThemeEvent(currentTheme=' + toString(this.w2t_1) + ')';
  };
  protoOf(ThemeEvent).hashCode = function () {
    return hashCode(this.w2t_1);
  };
  protoOf(ThemeEvent).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof ThemeEvent))
      return false;
    if (!equals(this.w2t_1, other.w2t_1))
      return false;
    return true;
  };
  function ViewPropertyListener($outer) {
    this.x2t_1 = $outer;
  }
  protoOf(ViewPropertyListener).propertyChanged = function (e) {
    this.x2t_1.k2u(e);
  };
  function activeViewChanged($this, oldView, newView) {
    var tmp1_safe_receiver = oldView == null ? null : oldView.v1o();
    if (tmp1_safe_receiver == null)
      null;
    else {
      tmp1_safe_receiver.c1z($this.j2u_1);
    }
    $this.updateEnabled();
    var tmp3_safe_receiver = newView == null ? null : newView.v1o();
    if (tmp3_safe_receiver == null)
      null;
    else {
      tmp3_safe_receiver.b1z($this.j2u_1);
    }
    $this.l2u();
  }
  function AbstractContentViewAction$activeViewHandler$lambda(this$0) {
    return function (it) {
      activeViewChanged(this$0, it.n2u_1, it.o2u_1);
      return Unit_instance;
    };
  }
  function AbstractContentViewAction(baseName, eventBus, viewManager) {
    eventBus = eventBus === VOID ? BaseModule_getInstance().bp_1 : eventBus;
    viewManager = viewManager === VOID ? DrawViewModule_getInstance().q2u_1 : viewManager;
    AbstractAction_init_$Init$(baseName, VOID, VOID, this);
    this.g2u_1 = eventBus;
    this.h2u_1 = viewManager;
    var tmp = this;
    tmp.i2u_1 = AbstractContentViewAction$activeViewHandler$lambda(this);
    this.j2u_1 = new ViewPropertyListener(this);
    this.g2u_1.z17(getKClass(ActiveContentViewChangedEvent), this.i2u_1);
    var tmp0_safe_receiver = this.v1o();
    if (tmp0_safe_receiver == null)
      null;
    else {
      tmp0_safe_receiver.b1z(this.j2u_1);
    }
    this.pq(false);
  }
  protoOf(AbstractContentViewAction).v1o = function () {
    var tmp0_safe_receiver = this.h2u_1.r2u();
    return tmp0_safe_receiver == null ? null : tmp0_safe_receiver.v1o();
  };
  protoOf(AbstractContentViewAction).dispose = function () {
    protoOf(AbstractAction).dispose.call(this);
    this.g2u_1.b18(this.i2u_1);
  };
  protoOf(AbstractContentViewAction).k2u = function (e) {
  };
  protoOf(AbstractContentViewAction).yr = function () {
    return !(this.h2u_1.r2u() == null);
  };
  protoOf(AbstractContentViewAction).l2u = function () {
  };
  function AbstractViewAction(baseName, eventBus, viewManager) {
    eventBus = eventBus === VOID ? BaseModule_getInstance().bp_1 : eventBus;
    viewManager = viewManager === VOID ? DrawViewModule_getInstance().q2u_1 : viewManager;
    AbstractContentViewAction.call(this, baseName, eventBus, viewManager);
  }
  protoOf(AbstractViewAction).yr = function () {
    return this.e2v();
  };
  protoOf(AbstractViewAction).e2v = function () {
    return !(this.h2u_1.r2u() == null) && !(ensureNotNull(this.h2u_1.r2u()).v1o() == null);
  };
  function Companion_32() {
    this.f2v_1 = 50;
    this.g2v_1 = 10;
    this.h2v_1 = 50;
  }
  var Companion_instance_36;
  function Companion_getInstance_34() {
    return Companion_instance_36;
  }
  function start($this) {
    $this.j2v_1.xp();
  }
  function stop($this) {
    $this.j2v_1.yp();
  }
  function pan($this) {
    var dir = $this.k2v_1.u1a() ? 1 : -1;
    var panDirection_0 = panDirection($this, $this.k2v_1.jw()).y1f(dir * 10);
    $this.i2v_1.n24().c27(numberToInt(panDirection_0.x1i_1), numberToInt(panDirection_0.y1i_1));
    $this.i2v_1.z1y($this.k2v_1);
  }
  function isInsideSensitiveRegion($this, p) {
    return p.kn_1 <= 50 || p.kn_1 > ($this.i2v_1.f1c() - 50 | 0) || p.ln_1 <= 50 || p.ln_1 > ($this.i2v_1.h1c() - 50 | 0);
  }
  function panDirection($this, p) {
    return (new Vector2D(($this.i2v_1.f1c() / 2 | 0) - p.kn_1, ($this.i2v_1.h1c() / 2 | 0) - p.ln_1)).b1j();
  }
  function AutoPanning$lambda(this$0) {
    return function (it) {
      pan(this$0);
      return Unit_instance;
    };
  }
  function AutoPanning(view) {
    MouseAdapter.call(this);
    this.i2v_1 = view;
    this.j2v_1 = System_getInstance().wl();
    this.k2v_1 = new MouseEventImpl();
    this.l2v_1 = true;
    this.j2v_1.wp(50, VOID, AutoPanning$lambda(this));
  }
  protoOf(AutoPanning).k1b = function (e) {
    this.k2v_1 = e;
    if (isInsideSensitiveRegion(this, e.jw())) {
      if (!this.j2v_1.zp()) {
        start(this);
      }
    } else {
      if (this.j2v_1.zp()) {
        stop(this);
      }
    }
  };
  protoOf(AutoPanning).m2v = function () {
    if (this.l2v_1) {
      this.i2v_1.t1y(this);
    }
  };
  protoOf(AutoPanning).n2v = function () {
    this.i2v_1.u1y(this);
    stop(this);
  };
  function ActiveContentViewChangedEvent(viewManager, oldView, newView) {
    this.m2u_1 = viewManager;
    this.n2u_1 = oldView;
    this.o2u_1 = newView;
  }
  protoOf(ActiveContentViewChangedEvent).toString = function () {
    return 'ActiveContentViewChangedEvent(viewManager=' + toString(this.m2u_1) + ', oldView=' + toString_0(this.n2u_1) + ', newView=' + toString_0(this.o2u_1) + ')';
  };
  protoOf(ActiveContentViewChangedEvent).hashCode = function () {
    var result = hashCode(this.m2u_1);
    result = imul(result, 31) + (this.n2u_1 == null ? 0 : hashCode(this.n2u_1)) | 0;
    result = imul(result, 31) + (this.o2u_1 == null ? 0 : hashCode(this.o2u_1)) | 0;
    return result;
  };
  protoOf(ActiveContentViewChangedEvent).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof ActiveContentViewChangedEvent))
      return false;
    if (!equals(this.m2u_1, other.m2u_1))
      return false;
    if (!equals(this.n2u_1, other.n2u_1))
      return false;
    if (!equals(this.o2u_1, other.o2u_1))
      return false;
    return true;
  };
  function ContentViewManagerImpl_init_$Init$($this) {
    ContentViewManagerImpl.call($this, BaseModule_getInstance().bp_1);
    return $this;
  }
  function ContentViewManagerImpl_init_$Create$() {
    return ContentViewManagerImpl_init_$Init$(objectCreate(protoOf(ContentViewManagerImpl)));
  }
  function ContentViewManagerImpl(eventBus) {
    this.o2v_1 = eventBus;
    this.p2v_1 = null;
  }
  protoOf(ContentViewManagerImpl).q2v = function (value) {
    var oldView = this.p2v_1;
    this.p2v_1 = value;
    this.o2v_1.gu(new ActiveContentViewChangedEvent(this, oldView, this.p2v_1));
  };
  protoOf(ContentViewManagerImpl).r2u = function () {
    return this.p2v_1;
  };
  function fillProperties_3($this, properties) {
    properties.et('draw.view.minZoomFactor', 0.05);
    properties.et('draw.view.maxZoomFactor', 20.0);
    properties.et('draw.view.defaultZoomFactor', 1.0);
    properties.et('view.ZoomPanController.wheelZoomStep', 1.1);
    properties.et('view.ZoomPanController.wheelZoomRequiredMeta', false);
    properties.et('view.ZoomPanController.wheelPanStep', 5);
    properties.et('draw.view.tooltipsEnabled', true);
    properties.et('draw.view.TooltipManager.delay', 1500);
  }
  function DrawViewModule() {
    DrawViewModule_instance = this;
    AbstractModule.call(this);
    this.q2u_1 = new ContentViewManagerImpl(BaseModule_getInstance().bp_1);
  }
  protoOf(DrawViewModule).to = function () {
    BaseModule_getInstance().vo();
    fillProperties_3(this, BaseModule_getInstance().zo_1);
    TooltipManager_getInstance().f2w(BaseModule_getInstance().bp_1);
  };
  var DrawViewModule_instance;
  function DrawViewModule_getInstance() {
    if (DrawViewModule_instance == null)
      new DrawViewModule();
    return DrawViewModule_instance;
  }
  function Companion_33() {
    this.g2w_1 = 50;
  }
  var Companion_instance_37;
  function Companion_getInstance_35() {
    return Companion_instance_37;
  }
  function repaintDirtyRegion($this) {
    if ($this.j2w_1) {
      $this.h2w_1.m1y(0, 0, $this.h2w_1.f1c(), $this.h2w_1.h1c());
    } else {
      var p1 = !($this.i2w_1 == null) ? $this.h2w_1.g25(new Point2D(ensureNotNull($this.i2w_1).z1c(), ensureNotNull($this.i2w_1).a1d())) : Companion_getInstance().w1a_1;
      var p2 = !($this.i2w_1 == null) ? $this.h2w_1.g25(new Point2D(ensureNotNull($this.i2w_1).b1d(), ensureNotNull($this.i2w_1).c1d())) : $this.l2w_1;
      // Inline function 'kotlin.math.floor' call
      var x = p1.kn_1;
      var tmp$ret$0 = Math.floor(x);
      var x1 = numberToInt(tmp$ret$0);
      // Inline function 'kotlin.math.floor' call
      var x_0 = p1.ln_1;
      var tmp$ret$1 = Math.floor(x_0);
      var y1 = numberToInt(tmp$ret$1);
      // Inline function 'kotlin.math.ceil' call
      var x_1 = p2.kn_1;
      var tmp$ret$2 = Math.ceil(x_1);
      var x2 = numberToInt(tmp$ret$2);
      // Inline function 'kotlin.math.ceil' call
      var x_2 = p2.ln_1;
      var tmp$ret$3 = Math.ceil(x_2);
      var y2 = numberToInt(tmp$ret$3);
      $this.h2w_1.m1y(x1 - 1 | 0, y1 - 1 | 0, (x2 - x1 | 0) + 2 | 0, (y2 - y1 | 0) + 2 | 0);
    }
    $this.i2w_1 = null;
    $this.j2w_1 = false;
  }
  function startTimerIfNeeded($this) {
    if (!$this.k2w_1.zp()) {
      $this.k2w_1.xp();
    }
  }
  function sam$io_antarescircuit_jabbah_base_event_PropertyChangeListener$0_0(function_0) {
    this.o2w_1 = function_0;
  }
  protoOf(sam$io_antarescircuit_jabbah_base_event_PropertyChangeListener$0_0).propertyChanged = function (e) {
    return this.o2w_1(e);
  };
  protoOf(sam$io_antarescircuit_jabbah_base_event_PropertyChangeListener$0_0).p2 = function () {
    return this.o2w_1;
  };
  protoOf(sam$io_antarescircuit_jabbah_base_event_PropertyChangeListener$0_0).equals = function (other) {
    var tmp;
    if (!(other == null) ? isInterface(other, PropertyChangeListener) : false) {
      var tmp_0;
      if (!(other == null) ? isInterface(other, FunctionAdapter) : false) {
        tmp_0 = equals(this.p2(), other.p2());
      } else {
        tmp_0 = false;
      }
      tmp = tmp_0;
    } else {
      tmp = false;
    }
    return tmp;
  };
  protoOf(sam$io_antarescircuit_jabbah_base_event_PropertyChangeListener$0_0).hashCode = function () {
    return hashCode(this.p2());
  };
  function sam$io_antarescircuit_jabbah_base_event_PropertyChangeListener$0_1(function_0) {
    this.p2w_1 = function_0;
  }
  protoOf(sam$io_antarescircuit_jabbah_base_event_PropertyChangeListener$0_1).propertyChanged = function (e) {
    return this.p2w_1(e);
  };
  protoOf(sam$io_antarescircuit_jabbah_base_event_PropertyChangeListener$0_1).p2 = function () {
    return this.p2w_1;
  };
  protoOf(sam$io_antarescircuit_jabbah_base_event_PropertyChangeListener$0_1).equals = function (other) {
    var tmp;
    if (!(other == null) ? isInterface(other, PropertyChangeListener) : false) {
      var tmp_0;
      if (!(other == null) ? isInterface(other, FunctionAdapter) : false) {
        tmp_0 = equals(this.p2(), other.p2());
      } else {
        tmp_0 = false;
      }
      tmp = tmp_0;
    } else {
      tmp = false;
    }
    return tmp;
  };
  protoOf(sam$io_antarescircuit_jabbah_base_event_PropertyChangeListener$0_1).hashCode = function () {
    return hashCode(this.p2());
  };
  function InvalidatableViewPainter$viewDimensionListener$lambda(this$0) {
    return function (it) {
      var tmp;
      if (it.name === 'PROP_DIMENSION') {
        this$0.l2w_1 = Point2D_init_$Create$(this$0.h2w_1.f1c(), this$0.h2w_1.h1c());
        tmp = Unit_instance;
      }
      return Unit_instance;
    };
  }
  function InvalidatableViewPainter$viewListener$lambda(this$0) {
    return function (it) {
      var tmp;
      if (it.name === 'PROP_CANVAS') {
        this$0.h2w_1.s23().u1b(this$0.m2w_1);
        tmp = Unit_instance;
      }
      return Unit_instance;
    };
  }
  function InvalidatableViewPainter$lambda$lambda(this$0) {
    return function () {
      repaintDirtyRegion(this$0);
      return Unit_instance;
    };
  }
  function InvalidatableViewPainter$lambda(this$0) {
    return function (it) {
      this$0.k2w_1.yp();
      var tmp = System_getInstance();
      tmp.fm(InvalidatableViewPainter$lambda$lambda(this$0));
      return Unit_instance;
    };
  }
  function InvalidatableViewPainter(view) {
    this.h2w_1 = view;
    this.i2w_1 = null;
    this.j2w_1 = false;
    this.k2w_1 = System_getInstance().wl();
    this.l2w_1 = Point2D_init_$Create$(this.h2w_1.f1c(), this.h2w_1.h1c());
    var tmp = this;
    var tmp_0 = InvalidatableViewPainter$viewDimensionListener$lambda(this);
    tmp.m2w_1 = new sam$io_antarescircuit_jabbah_base_event_PropertyChangeListener$0_0(tmp_0);
    var tmp_1 = this;
    var tmp_2 = InvalidatableViewPainter$viewListener$lambda(this);
    tmp_1.n2w_1 = new sam$io_antarescircuit_jabbah_base_event_PropertyChangeListener$0_1(tmp_2);
    this.h2w_1.b1z(this.n2w_1);
    this.k2w_1.vp(20, false, InvalidatableViewPainter$lambda(this));
  }
  protoOf(InvalidatableViewPainter).gs = function () {
    this.h2w_1.c1z(this.n2w_1);
    this.h2w_1.s23().v1b(this.m2w_1);
  };
  protoOf(InvalidatableViewPainter).q2w = function () {
    startTimerIfNeeded(this);
  };
  protoOf(InvalidatableViewPainter).r2w = function (context) {
    this.h2w_1.h20(context);
  };
  protoOf(InvalidatableViewPainter).s2w = function (region) {
    if (region == null) {
      this.j2w_1 = true;
    } else {
      if (!this.j2w_1) {
        var tmp = this;
        var tmp0_safe_receiver = this.i2w_1;
        var tmp_0 = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.n1c(region);
        var tmp1_elvis_lhs = (tmp_0 == null ? true : tmp_0 instanceof Rectangle2D) ? tmp_0 : THROW_CCE();
        tmp.i2w_1 = tmp1_elvis_lhs == null ? Rectangle2D_init_$Create$(region) : tmp1_elvis_lhs;
      }
    }
  };
  function Companion_34() {
    this.t2w_1 = 200;
  }
  var Companion_instance_38;
  function Companion_getInstance_36() {
    return Companion_instance_38;
  }
  function MouseWheelModeController() {
    KeyAdapter.call(this);
    this.u2w_1 = 0n;
    this.v2w_1 = 0n;
    this.w2w_1 = false;
    this.x2w_1 = true;
    this.y2w_1 = null;
  }
  protoOf(MouseWheelModeController).du = function () {
    this.w2w_1 = false;
    this.x2w_1 = true;
    this.v2w_1 = 0n;
    this.v2w_1 = 0n;
  };
  protoOf(MouseWheelModeController).z2w = function () {
    var now = System_getInstance().vl();
    var switchMode = this.x2w_1 && this.w2w_1 && subtract(now, this.u2w_1) > 200n || (!this.x2w_1 && !this.w2w_1 && subtract(now, this.v2w_1) > 200n);
    this.x2w_1 = this.x2w_1 && !switchMode || (!this.x2w_1 && switchMode);
    return this.x2w_1;
  };
  protoOf(MouseWheelModeController).a2x = function () {
    this.u2w_1 = System_getInstance().vl();
  };
  protoOf(MouseWheelModeController).b2x = function () {
    this.v2w_1 = System_getInstance().vl();
  };
  protoOf(MouseWheelModeController).n1a = function (e) {
    this.y2w_1 = e.i2();
    if (e.i2() === DrawModule_getInstance().p2a_1) {
      this.w2w_1 = true;
    }
  };
  protoOf(MouseWheelModeController).o1a = function (e) {
    this.y2w_1 = null;
    if (e.i2() === DrawModule_getInstance().p2a_1) {
      this.w2w_1 = false;
    }
  };
  function PanMethod$MiddleMouseButton() {
    PanMethod.call(this, 'MiddleMouseButton', 0, 'middleMouseButton');
    PanMethod_MiddleMouseButton_instance = this;
  }
  protoOf(PanMethod$MiddleMouseButton).mq = function () {
    return Translations_getInstance().bn('draw.panMethod.middleMouseButton.desc', []);
  };
  protoOf(PanMethod$MiddleMouseButton).f2x = function (event, pressedKeyCode) {
    return event.v1a();
  };
  var PanMethod_MiddleMouseButton_instance;
  function PanMethod$AltLeftMouseButton() {
    PanMethod.call(this, 'AltLeftMouseButton', 1, 'altLeftMouseButton');
    PanMethod_AltLeftMouseButton_instance = this;
  }
  protoOf(PanMethod$AltLeftMouseButton).mq = function () {
    return Translations_getInstance().bn('draw.panMethod.altLeftMouseButton.desc', []);
  };
  protoOf(PanMethod$AltLeftMouseButton).f2x = function (event, pressedKeyCode) {
    return event.u1a() && event.isAltDown;
  };
  var PanMethod_AltLeftMouseButton_instance;
  function PanMethod$SpaceLeftMouseButton() {
    PanMethod.call(this, 'SpaceLeftMouseButton', 2, 'spaceLeftMouseButton');
    PanMethod_SpaceLeftMouseButton_instance = this;
  }
  protoOf(PanMethod$SpaceLeftMouseButton).mq = function () {
    return Translations_getInstance().bn('draw.panMethod.spaceLeftMouseButton.desc', []);
  };
  protoOf(PanMethod$SpaceLeftMouseButton).f2x = function (event, pressedKeyCode) {
    return event.u1a() && pressedKeyCode === Companion_instance.w18_1;
  };
  var PanMethod_SpaceLeftMouseButton_instance;
  function Companion_35() {
    this.n2x_1 = 'draw.panMethod';
  }
  protoOf(Companion_35).h1f = function (customName) {
    var tmp0 = get_entries_1();
    var tmp$ret$0;
    $l$block: {
      // Inline function 'kotlin.collections.firstOrNull' call
      var _iterator__ex2g4s = tmp0.i();
      while (_iterator__ex2g4s.j()) {
        var element = _iterator__ex2g4s.k();
        if (element.u2p() === customName) {
          tmp$ret$0 = element;
          break $l$block;
        }
      }
      tmp$ret$0 = null;
    }
    var tmp0_elvis_lhs = tmp$ret$0;
    var tmp;
    if (tmp0_elvis_lhs == null) {
      throw IllegalArgumentException_init_$Create$("unknown PanMethod '" + customName + "'");
    } else {
      tmp = tmp0_elvis_lhs;
    }
    return tmp;
  };
  var Companion_instance_39;
  function Companion_getInstance_37() {
    return Companion_instance_39;
  }
  function values_3() {
    return [PanMethod_MiddleMouseButton_getInstance(), PanMethod_AltLeftMouseButton_getInstance(), PanMethod_SpaceLeftMouseButton_getInstance()];
  }
  function get_entries_1() {
    if ($ENTRIES_1 == null)
      $ENTRIES_1 = enumEntries(values_3());
    return $ENTRIES_1;
  }
  var PanMethod_entriesInitialized;
  function PanMethod_initEntries() {
    if (PanMethod_entriesInitialized)
      return Unit_instance;
    PanMethod_entriesInitialized = true;
    PanMethod_MiddleMouseButton_instance = new PanMethod$MiddleMouseButton();
    PanMethod_AltLeftMouseButton_instance = new PanMethod$AltLeftMouseButton();
    PanMethod_SpaceLeftMouseButton_instance = new PanMethod$SpaceLeftMouseButton();
  }
  var $ENTRIES_1;
  function PanMethod(name, ordinal, customName) {
    Enum.call(this, name, ordinal);
    this.t2p_1 = customName;
  }
  protoOf(PanMethod).u2p = function () {
    return this.t2p_1;
  };
  protoOf(PanMethod).g2x = function (event, pressedKeyCode, $super) {
    pressedKeyCode = pressedKeyCode === VOID ? null : pressedKeyCode;
    return $super === VOID ? this.f2x(event, pressedKeyCode) : $super.f2x.call(this, event, pressedKeyCode);
  };
  protoOf(PanMethod).toString = function () {
    var tmp;
    switch (this.l2_1) {
      case 0:
        tmp = Translations_getInstance().bn('draw.panMethod.middleMouseButton.name', []);
        break;
      case 1:
        tmp = Translations_getInstance().bn('draw.panMethod.altLeftMouseButton.name', []);
        break;
      case 2:
        tmp = Translations_getInstance().bn('draw.panMethod.spaceLeftMouseButton.name', []);
        break;
      default:
        noWhenBranchMatchedException();
        break;
    }
    return tmp;
  };
  function _get_panMethodFromProperties__kl0kfq($this) {
    return Companion_instance_39.h1f(BaseModule_getInstance().zo_1.jt('draw.panMethod'));
  }
  function CurrentPanMethod$lambda(this$0) {
    return function (it) {
      this$0.p2x_1 = _get_panMethodFromProperties__kl0kfq(this$0);
      return Unit_instance;
    };
  }
  function CurrentPanMethod() {
    CurrentPanMethod_instance = this;
    this.o2x_1 = BaseModule_getInstance().bp_1;
    this.p2x_1 = _get_panMethodFromProperties__kl0kfq(this);
    var tmp = getKClass(PreferencesChangedEvent);
    this.o2x_1.z17(tmp, CurrentPanMethod$lambda(this));
  }
  var CurrentPanMethod_instance;
  function CurrentPanMethod_getInstance() {
    if (CurrentPanMethod_instance == null)
      new CurrentPanMethod();
    return CurrentPanMethod_instance;
  }
  function PanMethod_MiddleMouseButton_getInstance() {
    PanMethod_initEntries();
    return PanMethod_MiddleMouseButton_instance;
  }
  function PanMethod_AltLeftMouseButton_getInstance() {
    PanMethod_initEntries();
    return PanMethod_AltLeftMouseButton_instance;
  }
  function PanMethod_SpaceLeftMouseButton_getInstance() {
    PanMethod_initEntries();
    return PanMethod_SpaceLeftMouseButton_instance;
  }
  function buildToolTipText(title, text, subText, endWithPeriod) {
    endWithPeriod = endWithPeriod === VOID ? false : endWithPeriod;
    var builder = StringBuilder_init_$Create$();
    var hasText = StringUtils_getInstance().lu(text);
    var hasSubText = StringUtils_getInstance().lu(subText);
    if (StringUtils_getInstance().mu(title)) {
      var titleText = ensureNotNull(title);
      if (hasText && !startsWith(ensureNotNull(text), _Char___init__impl__6a9atx(10))) {
        titleText = titleText + ':';
      }
      builder.i7(Companion_instance_2.i1k(titleText));
    }
    if (hasText) {
      builder.i7(' ').i7(ensureNotNull(text));
      if (endWithPeriod && !endsWith(text, '.')) {
        builder.j7(_Char___init__impl__6a9atx(46));
      }
    }
    if (hasSubText) {
      // Inline function 'kotlin.text.isNotEmpty' call
      if (charSequenceLength(builder) > 0) {
        // Inline function 'kotlin.text.appendLine' call
        // Inline function 'kotlin.text.appendLine' call
        builder.j7(_Char___init__impl__6a9atx(10)).j7(_Char___init__impl__6a9atx(10));
      }
      builder.i7(ensureNotNull(subText));
      if (endWithPeriod && !endsWith(subText, '.')) {
        builder.j7(_Char___init__impl__6a9atx(46));
      }
    }
    var tmp;
    // Inline function 'kotlin.text.isEmpty' call
    if (charSequenceLength(builder) === 0) {
      tmp = null;
    } else {
      tmp = builder.toString();
    }
    return tmp;
  }
  function _get_LOG__e5r759_8($this) {
    var tmp0 = $this.r2v_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('LOG', 1, tmp, TooltipManager$_get_LOG_$ref_lph8qm(), null);
    return tmp0.j2();
  }
  function _get_timer__axs3pw($this) {
    if ($this.b2w_1 == null) {
      initTimer($this);
    }
    return ensureNotNull($this.b2w_1);
  }
  function initTimer($this) {
    $this.b2w_1 = System_getInstance().wl();
    var tmp = _get_timer__axs3pw($this);
    var tmp_0 = BaseModule_getInstance().zo_1.kt('draw.view.TooltipManager.delay');
    tmp.vp(tmp_0, false, TooltipManager$initTimer$lambda);
  }
  function handle($this, event) {
    if (event.q2x_1 == null || event.s2x_1 == null) {
      tooltipDismissed($this);
    } else {
      tooltipRequested($this, event);
    }
  }
  function tooltipRequested($this, event) {
    if (!($this.y2v_1 == null) || !($this.z2v_1 == null)) {
      disposeTooltip($this);
    }
    $this.a2w_1 = new TooltipRequest(ensureNotNull(event.q2x_1), event.r2x_1, event.s2x_1, event.t2x_1);
    _get_timer__axs3pw($this).xp();
  }
  function tooltipDismissed($this) {
    if (!($this.y2v_1 == null) || !($this.z2v_1 == null)) {
      _get_LOG__e5r759_8($this).ql('tooltipDismissed()');
      disposeTooltip($this);
    }
    if (_get_timer__axs3pw($this).zp()) {
      _get_timer__axs3pw($this).yp();
    }
  }
  function displayImpl($this) {
    _get_timer__axs3pw($this).yp();
    var tmp0_safe_receiver = $this.a2w_1;
    if (tmp0_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      disposeTooltip(TooltipManager_getInstance());
      if (!(tmp0_safe_receiver.w2x_1 == null)) {
        TooltipManager_getInstance().y2v_1 = new TooltipView(createTextArrowBubble(TooltipManager_getInstance(), tmp0_safe_receiver.w2x_1, tmp0_safe_receiver.v2x_1), tmp0_safe_receiver.v2x_1);
        tmp0_safe_receiver.v2x_1.b24().b21(ensureNotNull(TooltipManager_getInstance().y2v_1).y2x_1);
      }
      if (!(tmp0_safe_receiver.x2x_1 == null)) {
        TooltipManager_getInstance().z2v_1 = new TooltipView(createExplanationArrowBubble(TooltipManager_getInstance(), tmp0_safe_receiver.x2x_1, tmp0_safe_receiver.v2x_1), tmp0_safe_receiver.v2x_1);
        if (TooltipManager_getInstance().y2v_1 == null || !(ensureNotNull(TooltipManager_getInstance().y2v_1).y2x_1.b2e_1.e2e_1 === ensureNotNull(TooltipManager_getInstance().z2v_1).y2x_1.b2e_1.e2e_1)) {
          tmp0_safe_receiver.v2x_1.b24().b21(ensureNotNull(TooltipManager_getInstance().z2v_1).y2x_1);
        }
      }
      tmp0_safe_receiver.v2x_1.b24().k20();
      var tmp = TooltipManager_getInstance();
      tmp.c2w_1 = tmp0_safe_receiver.v2x_1.e24(TooltipManager$displayImpl$lambda);
      TooltipManager_getInstance().a2w_1 = null;
    }
  }
  function disposeTooltip($this) {
    var tmp0_safe_receiver = $this.y2v_1;
    if (tmp0_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      tmp0_safe_receiver.z2x_1.b24().c21(tmp0_safe_receiver.y2x_1);
      tmp0_safe_receiver.z2x_1.b24().k20();
      var tmp0_safe_receiver_0 = TooltipManager_getInstance().c2w_1;
      if (tmp0_safe_receiver_0 == null)
        null;
      else {
        // Inline function 'kotlin.let' call
        tmp0_safe_receiver.z2x_1.c1z(tmp0_safe_receiver_0);
      }
      TooltipManager_getInstance().y2v_1 = null;
    }
    var tmp1_safe_receiver = $this.z2v_1;
    if (tmp1_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      tmp1_safe_receiver.z2x_1.b24().c21(tmp1_safe_receiver.y2x_1);
      tmp1_safe_receiver.z2x_1.b24().k20();
      var tmp0_safe_receiver_1 = TooltipManager_getInstance().c2w_1;
      if (tmp0_safe_receiver_1 == null)
        null;
      else {
        // Inline function 'kotlin.let' call
        tmp1_safe_receiver.z2x_1.c1z(tmp0_safe_receiver_1);
      }
      TooltipManager_getInstance().z2v_1 = null;
    }
    $this.y2v_1 = null;
    $this.z2v_1 = null;
  }
  function createTextArrowBubble($this, tooltip, view) {
    var font = $this.e2w_1.f1y(Companion_getInstance_33().e1y_1).b2d();
    var multilineText = Companion_getInstance_15().j2h(tooltip.xu_1, font, 300);
    return new ArrowBubble(multilineText, ArrowBubblePositioner_instance.k2e(multilineText, tooltip.yu_1, view, true), Companion_getInstance_33().e1y_1, $this.e2w_1);
  }
  function createExplanationArrowBubble($this, explanation, view) {
    return new ArrowBubble(explanation.q20_1, ArrowBubblePositioner_instance.k2e(explanation.q20_1, explanation.r20_1, view, false), Companion_getInstance_33().e1y_1, $this.e2w_1);
  }
  function TooltipManager$_get_LOG_$ref_lph8qm() {
    return function (p0) {
      return _get_LOG__e5r759_8(p0);
    };
  }
  function TooltipManager$tooltipEventHandler$lambda(it) {
    handle(TooltipManager_getInstance(), it);
    return Unit_instance;
  }
  function TooltipManager$preferencesChangeHandler$lambda(it) {
    initTimer(TooltipManager_getInstance());
    return Unit_instance;
  }
  function TooltipManager$initTimer$lambda(it) {
    displayImpl(TooltipManager_getInstance());
    return Unit_instance;
  }
  function TooltipManager$displayImpl$lambda(event) {
    var tmp0_safe_receiver = TooltipManager_getInstance().y2v_1;
    if (equals(event.source, tmp0_safe_receiver == null ? null : tmp0_safe_receiver.z2x_1)) {
      disposeTooltip(TooltipManager_getInstance());
    }
    return Unit_instance;
  }
  function TooltipManager() {
    TooltipManager_instance = this;
    this.r2v_1 = logger(getKClass(TooltipManager));
    this.s2v_1 = 'draw.view.TooltipManager.delay';
    this.t2v_1 = 300;
    this.u2v_1 = 50;
    this.v2v_1 = 10;
    var tmp = this;
    tmp.w2v_1 = TooltipManager$tooltipEventHandler$lambda;
    var tmp_0 = this;
    tmp_0.x2v_1 = TooltipManager$preferencesChangeHandler$lambda;
    this.y2v_1 = null;
    this.z2v_1 = null;
    this.a2w_1 = null;
    this.b2w_1 = null;
    this.c2w_1 = null;
    this.d2w_1 = BaseModule_getInstance().bp_1;
    this.e2w_1 = DrawStyleModule_getInstance().w1x_1;
    this.d2w_1.z17(getKClass(TooltipEvent), this.w2v_1);
    this.d2w_1.z17(getKClass(PreferencesChangedEvent), this.x2v_1);
  }
  protoOf(TooltipManager).f2w = function (value) {
    if (!equals(this.d2w_1, value)) {
      this.d2w_1.a18(getKClass(TooltipEvent), this.w2v_1);
      this.d2w_1.a18(getKClass(PreferencesChangedEvent), this.x2v_1);
      this.d2w_1 = value;
      this.d2w_1.z17(getKClass(TooltipEvent), this.w2v_1);
      this.d2w_1.z17(getKClass(PreferencesChangedEvent), this.x2v_1);
    }
  };
  var TooltipManager_instance;
  function TooltipManager_getInstance() {
    if (TooltipManager_instance == null)
      new TooltipManager();
    return TooltipManager_instance;
  }
  function TooltipEvent(origin, view, tooltip, explanation) {
    this.q2x_1 = origin;
    this.r2x_1 = view;
    this.s2x_1 = tooltip;
    this.t2x_1 = explanation;
  }
  protoOf(TooltipEvent).toString = function () {
    return 'TooltipEvent(origin=' + toString_0(this.q2x_1) + ', view=' + toString(this.r2x_1) + ', tooltip=' + toString_0(this.s2x_1) + ', explanation=' + toString_0(this.t2x_1) + ')';
  };
  protoOf(TooltipEvent).hashCode = function () {
    var result = this.q2x_1 == null ? 0 : hashCode(this.q2x_1);
    result = imul(result, 31) + hashCode(this.r2x_1) | 0;
    result = imul(result, 31) + (this.s2x_1 == null ? 0 : this.s2x_1.hashCode()) | 0;
    result = imul(result, 31) + (this.t2x_1 == null ? 0 : this.t2x_1.hashCode()) | 0;
    return result;
  };
  protoOf(TooltipEvent).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof TooltipEvent))
      return false;
    if (!equals(this.q2x_1, other.q2x_1))
      return false;
    if (!equals(this.r2x_1, other.r2x_1))
      return false;
    if (!equals(this.s2x_1, other.s2x_1))
      return false;
    if (!equals(this.t2x_1, other.t2x_1))
      return false;
    return true;
  };
  function TooltipView(arrowBubble, view) {
    this.y2x_1 = arrowBubble;
    this.z2x_1 = view;
  }
  protoOf(TooltipView).toString = function () {
    return 'TooltipView(arrowBubble=' + toString(this.y2x_1) + ', view=' + toString(this.z2x_1) + ')';
  };
  protoOf(TooltipView).hashCode = function () {
    var result = hashCode(this.y2x_1);
    result = imul(result, 31) + hashCode(this.z2x_1) | 0;
    return result;
  };
  protoOf(TooltipView).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof TooltipView))
      return false;
    if (!equals(this.y2x_1, other.y2x_1))
      return false;
    if (!equals(this.z2x_1, other.z2x_1))
      return false;
    return true;
  };
  function TooltipRequest(origin, view, tooltip, explanation) {
    this.u2x_1 = origin;
    this.v2x_1 = view;
    this.w2x_1 = tooltip;
    this.x2x_1 = explanation;
  }
  protoOf(TooltipRequest).toString = function () {
    return 'TooltipRequest(origin=' + toString(this.u2x_1) + ', view=' + toString(this.v2x_1) + ', tooltip=' + toString_0(this.w2x_1) + ', explanation=' + toString_0(this.x2x_1) + ')';
  };
  protoOf(TooltipRequest).hashCode = function () {
    var result = hashCode(this.u2x_1);
    result = imul(result, 31) + hashCode(this.v2x_1) | 0;
    result = imul(result, 31) + (this.w2x_1 == null ? 0 : this.w2x_1.hashCode()) | 0;
    result = imul(result, 31) + (this.x2x_1 == null ? 0 : this.x2x_1.hashCode()) | 0;
    return result;
  };
  protoOf(TooltipRequest).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof TooltipRequest))
      return false;
    if (!equals(this.u2x_1, other.u2x_1))
      return false;
    if (!equals(this.v2x_1, other.v2x_1))
      return false;
    if (!equals(this.w2x_1, other.w2x_1))
      return false;
    if (!equals(this.x2x_1, other.x2x_1))
      return false;
    return true;
  };
  function Companion_36() {
    this.a2y_1 = 'draw.view.tooltipsEnabled';
  }
  var Companion_instance_40;
  function Companion_getInstance_38() {
    return Companion_instance_40;
  }
  function getTooltip($this, drawable, context) {
    var tmp;
    if ($this.j2y_1) {
      tmp = $this.d2y_1(drawable, context);
    } else {
      tmp = null;
    }
    return tmp;
  }
  function getExplanation($this, drawable, x, y) {
    var tmp;
    if ($this.j2y_1 && $this.k2y_1) {
      tmp = $this.e2y_1(drawable, x, y);
    } else {
      tmp = null;
    }
    return tmp;
  }
  function clearLastTargets($this) {
    $this.f2y_1 = null;
    $this.g2y_1 = null;
    $this.h2y_1 = null;
    $this.i2y_1 = null;
  }
  function setLastTargets($this, drawable, tooltipText, explanation, sourceRect) {
    $this.f2y_1 = drawable;
    $this.g2y_1 = tooltipText;
    $this.h2y_1 = explanation;
    $this.i2y_1 = sourceRect;
  }
  function TooltipHandler$_init_$lambda_4n6k04(c, x, y) {
    return c.i21(x, y);
  }
  function TooltipHandler$_init_$lambda_4n6k04_0(d, context) {
    return d.o20(context);
  }
  function TooltipHandler$_init_$lambda_4n6k04_1(d, x, y) {
    return d.p20(x, y);
  }
  function TooltipHandler$popupMenuHandler$lambda(this$0) {
    return function (it) {
      this$0.m2y(it.i1z_1.v1o());
      return Unit_instance;
    };
  }
  function TooltipHandler(eventBus, drawableRetriever, tooltipAccessor, explanationAccessor) {
    var tmp;
    if (drawableRetriever === VOID) {
      tmp = TooltipHandler$_init_$lambda_4n6k04;
    } else {
      tmp = drawableRetriever;
    }
    drawableRetriever = tmp;
    var tmp_0;
    if (tooltipAccessor === VOID) {
      tmp_0 = TooltipHandler$_init_$lambda_4n6k04_0;
    } else {
      tmp_0 = tooltipAccessor;
    }
    tooltipAccessor = tmp_0;
    var tmp_1;
    if (explanationAccessor === VOID) {
      tmp_1 = TooltipHandler$_init_$lambda_4n6k04_1;
    } else {
      tmp_1 = explanationAccessor;
    }
    explanationAccessor = tmp_1;
    this.b2y_1 = eventBus;
    this.c2y_1 = drawableRetriever;
    this.d2y_1 = tooltipAccessor;
    this.e2y_1 = explanationAccessor;
    this.f2y_1 = null;
    this.g2y_1 = null;
    this.h2y_1 = null;
    this.i2y_1 = null;
    this.j2y_1 = BaseModule_getInstance().zo_1.ht('draw.view.tooltipsEnabled');
    this.k2y_1 = BaseModule_getInstance().zo_1.ht('base.beginnerHelpTooltip');
    var tmp_2 = this;
    tmp_2.l2y_1 = TooltipHandler$popupMenuHandler$lambda(this);
    this.b2y_1.z17(getKClass(PopupMenuEvent), this.l2y_1);
  }
  protoOf(TooltipHandler).n2y = function (view, container, context) {
    var drawable = this.c2y_1(container, context.q22_1, context.r22_1);
    if (drawable == null) {
      if (!(this.f2y_1 == null)) {
        this.b2y_1.gu(new TooltipEvent(null, view, null, null));
        clearLastTargets(this);
      }
      return Unit_instance;
    }
    var tooltip = getTooltip(this, drawable, context);
    var explanation = getExplanation(this, drawable, context.q22_1, context.r22_1);
    var tmp;
    var tmp_0 = StringUtils_getInstance();
    if (tmp_0.ku(tooltip == null ? null : tooltip.xu_1)) {
      tmp = explanation == null;
    } else {
      tmp = false;
    }
    if (tmp) {
      if (!(this.f2y_1 == null) || !(this.h2y_1 == null)) {
        clearLastTargets(this);
        this.b2y_1.gu(new TooltipEvent(null, view, null, null));
      }
      return Unit_instance;
    }
    var tmp_1;
    var tmp_2;
    var tmp_3;
    if (!(drawable === this.f2y_1)) {
      tmp_3 = true;
    } else {
      tmp_3 = !((tooltip == null ? null : tooltip.xu_1) == this.g2y_1);
    }
    if (tmp_3) {
      tmp_2 = true;
    } else {
      var tmp_4 = explanation == null ? null : explanation.q20_1;
      var tmp5_safe_receiver = this.h2y_1;
      tmp_2 = !(tmp_4 === (tmp5_safe_receiver == null ? null : tmp5_safe_receiver.q20_1));
    }
    if (tmp_2) {
      tmp_1 = true;
    } else {
      var tmp_5 = this.i2y_1;
      tmp_1 = !equals(tmp_5, tooltip == null ? null : tooltip.yu_1);
    }
    if (tmp_1) {
      var tmp_6 = tooltip == null ? null : tooltip.xu_1;
      setLastTargets(this, drawable, tmp_6, explanation, tooltip == null ? null : tooltip.yu_1);
      this.b2y_1.gu(new TooltipEvent(drawable, view, tooltip, explanation));
    }
  };
  protoOf(TooltipHandler).m2y = function (view) {
    this.b2y_1.gu(new TooltipEvent(null, view, null, null));
  };
  function calculateCombinedBoundingBox($this) {
    var bbox = new Rectangle2D();
    // Inline function 'kotlin.collections.filter' call
    var tmp0 = $this.s2y_1;
    // Inline function 'kotlin.collections.filterTo' call
    var destination = ArrayList_init_$Create$();
    var _iterator__ex2g4s = tmp0.i();
    while (_iterator__ex2g4s.j()) {
      var element = _iterator__ex2g4s.k();
      if (element.d20()) {
        destination.h(element);
      }
    }
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s_0 = destination.i();
    while (_iterator__ex2g4s_0.j()) {
      var element_0 = _iterator__ex2g4s_0.k();
      bbox.n1c(element_0.fo());
    }
    return bbox;
  }
  function ChildListener($outer) {
    this.p2z_1 = $outer;
  }
  protoOf(ChildListener).c22 = function (event) {
    this.p2z_1.f2z_1.s2w(event.b22_1);
  };
  protoOf(ChildListener).d22 = function (event) {
    this.p2z_1.f2z_1.q2w();
  };
  protoOf(ChildListener).e22 = function (event) {
  };
  function OverlayListener($outer) {
    this.q2z_1 = $outer;
  }
  protoOf(OverlayListener).c22 = function (event) {
    this.q2z_1.f2z_1.s2w(null);
  };
  protoOf(OverlayListener).d22 = function (event) {
    this.q2z_1.f2z_1.q2w();
  };
  protoOf(OverlayListener).e22 = function (event) {
  };
  function PropertyChangeHandler($outer) {
    this.r2z_1 = $outer;
  }
  protoOf(PropertyChangeHandler).propertyChanged = function (e) {
    switch (e.name) {
      case 'PROP_DIMENSION':
        this.r2z_1.u23().w2z(this.r2z_1.s23().s1x());
        this.r2z_1.z2y_1 = (this.r2z_1.u23().u2z_1.w1e_1 > 0 && this.r2z_1.u23().u2z_1.x1e_1 > 0);
        this.r2z_1.x2z();
        break;
      case 'PROP_DEVICE_PIXEL_RATIO':
        this.r2z_1.x2z();
        break;
      case 'ViewSpace.area':
        this.r2z_1.x2z();
        break;
      case 'PROP_APPLICATION_CONTEXT':
        this.r2z_1.y2z();
        this.r2z_1.t1x();
        break;
      case 'ViewContentBounds.total':
        this.r2z_1.x2z();
        break;
    }
  };
  function EventHandler($outer) {
    this.b30_1 = $outer;
    InputEventHandlerAdapter.call(this);
    this.a30_1 = null;
  }
  protoOf(EventHandler).z22 = function (context) {
    var destination = null;
    var tmp0 = this.b30_1.s2y_1;
    $l$block: {
      // Inline function 'kotlin.collections.firstOrNull' call
      var _iterator__ex2g4s = tmp0.i();
      while (_iterator__ex2g4s.j()) {
        var element = _iterator__ex2g4s.k();
        destination = element.e20(context).z22(context);
        if (!(destination == null)) {
          break $l$block;
        }
      }
    }
    return destination;
  };
  protoOf(EventHandler).y22 = function (context) {
    var destination = null;
    var tmp0 = this.b30_1.s2y_1;
    $l$block: {
      // Inline function 'kotlin.collections.firstOrNull' call
      var _iterator__ex2g4s = tmp0.i();
      while (_iterator__ex2g4s.j()) {
        var element = _iterator__ex2g4s.k();
        destination = element.e20(context).y22(context);
        if (!(destination == null)) {
          break $l$block;
        }
      }
    }
    this.a30_1 = destination;
    return destination;
  };
  protoOf(EventHandler).a23 = function (context) {
    var destination = null;
    var tmp0 = this.b30_1.s2y_1;
    $l$block: {
      // Inline function 'kotlin.collections.firstOrNull' call
      var _iterator__ex2g4s = tmp0.i();
      while (_iterator__ex2g4s.j()) {
        var element = _iterator__ex2g4s.k();
        destination = element.e20(context).a23(context);
        if (!(destination == null)) {
          break $l$block;
        }
      }
    }
    this.a30_1 = destination;
    return destination;
  };
  protoOf(EventHandler).b23 = function (context) {
    var tmp0_safe_receiver = this.a30_1;
    return tmp0_safe_receiver == null ? null : tmp0_safe_receiver.b23(context);
  };
  protoOf(EventHandler).c23 = function (context) {
    var tmp0_safe_receiver = this.a30_1;
    return tmp0_safe_receiver == null ? null : tmp0_safe_receiver.c23(context);
  };
  protoOf(EventHandler).d23 = function (context) {
    var tmp = this;
    var tmp0_safe_receiver = this.a30_1;
    tmp.a30_1 = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.d23(context);
    return this.a30_1;
  };
  protoOf(EventHandler).e23 = function (context) {
    var tmp = this;
    var tmp0_safe_receiver = this.a30_1;
    tmp.a30_1 = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.e23(context);
    return this.a30_1;
  };
  function ViewImpl$_init_$lambda_aablwm(it) {
    return new InvalidatableViewPainter(it);
  }
  function ViewImpl$themeListener$lambda(this$0) {
    return function (it) {
      this$0.y2z();
      this$0.t1x();
      return Unit_instance;
    };
  }
  function ViewImpl$calculateCombinedBoundingBox$ref(p0) {
    var l = function () {
      var tmp0 = p0;
      return calculateCombinedBoundingBox(tmp0);
    };
    l.callableName = 'calculateCombinedBoundingBox';
    return l;
  }
  function ViewImpl(affineTransformFactory, applicationContextHolder, eventBus, name, viewPainterFactory) {
    eventBus = eventBus === VOID ? BaseModule_getInstance().bp_1 : eventBus;
    name = name === VOID ? '' : name;
    var tmp;
    if (viewPainterFactory === VOID) {
      tmp = ViewImpl$_init_$lambda_aablwm;
    } else {
      tmp = viewPainterFactory;
    }
    viewPainterFactory = tmp;
    this.o2y_1 = affineTransformFactory;
    this.p2y_1 = eventBus;
    this.q2y_1 = name;
    this.r2y_1 = new ZoomPanController(this);
    var tmp_0 = this;
    // Inline function 'kotlin.collections.mutableListOf' call
    tmp_0.s2y_1 = ArrayList_init_$Create$();
    this.t2y_1 = new PropertyChangeSupport(this);
    var tmp_1 = this;
    tmp_1.u2y_1 = ViewImpl$themeListener$lambda(this);
    this.v2y_1 = new PropertyChangeHandler(this);
    this.w2y_1 = new ViewSpace(Dimension2D_init_$Create$(0, 0));
    this.x2y_1 = this.c30();
    this.y2y_1 = null;
    this.z2y_1 = false;
    this.p2y_1.z17(getKClass(ThemeEvent), this.u2y_1);
    if (applicationContextHolder == null)
      null;
    else {
      applicationContextHolder.b1z(this.v2y_1);
    }
    this.x23().b26(this.v2y_1);
    this.u23().d30(this.v2y_1);
    this.a2z_1 = applicationContextHolder;
    this.b2z_1 = new EventHandler(this);
    this.c2z_1 = null;
    this.d2z_1 = new DrawableContainerImpl(VOID, VOID, VOID, true);
    this.e2z_1 = new ViewDecorator(this);
    this.f2z_1 = viewPainterFactory(this);
    this.g2z_1 = new Rectangle2D();
    this.h2z_1 = new ChildListener(this);
    this.i2z_1 = new OverlayListener(this);
    this.j2z_1 = true;
    this.k2z_1 = new ViewNavigatorImpl(this, this.o2y_1);
    this.l2z_1 = new ZoomStrategy(ZoomStrategyType_FIT_MAX_NORMAL_getInstance());
    this.m2z_1 = this.p24();
    this.n2z_1 = Companion_instance_8.m25();
    this.o2z_1 = true;
    this.d2z_1.f20(this.i2z_1);
  }
  protoOf(ViewImpl).u23 = function () {
    return this.w2y_1;
  };
  protoOf(ViewImpl).x23 = function () {
    return this.x2y_1;
  };
  protoOf(ViewImpl).t23 = function () {
    return !(this.y2y_1 == null);
  };
  protoOf(ViewImpl).g1y = function (value) {
    if (!(this.y2y_1 == null)) {
      ensureNotNull(this.y2y_1).v1b(this.v2y_1);
    }
    this.y2y_1 = value;
    this.s23().u1b(this.v2y_1);
    this.u23().w2z(this.s23().s1x());
    this.u23().e30(this.v2y_1);
    this.z2y_1 = this.s23().i1y();
    this.f30('PROP_CANVAS', null, this.y2y_1);
  };
  protoOf(ViewImpl).s23 = function () {
    return ensureNotNull(this.y2y_1);
  };
  protoOf(ViewImpl).v1o = function () {
    return this;
  };
  protoOf(ViewImpl).to = function () {
    this.v24();
    this.r2y_1.pq(true);
  };
  protoOf(ViewImpl).gs = function () {
    this.p2y_1.a18(getKClass(ThemeEvent), this.u2y_1);
    var tmp0_safe_receiver = this.y2y_1;
    if (tmp0_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      tmp0_safe_receiver.v1b(this.v2y_1);
      this.f2z_1.gs();
    }
    this.u23().d30(this.v2y_1);
    this.x23().c26(this.v2y_1);
    this.r2y_1.gs();
  };
  protoOf(ViewImpl).v23 = function () {
    return this.a2z_1;
  };
  protoOf(ViewImpl).w23 = function () {
    var tmp0_safe_receiver = this.v23();
    return tmp0_safe_receiver == null ? null : tmp0_safe_receiver.g1z_1;
  };
  protoOf(ViewImpl).w24 = function () {
    return this.s2y_1.o();
  };
  protoOf(ViewImpl).q30 = function (drawable) {
    return this.x24(drawable, this.w24());
  };
  protoOf(ViewImpl).x24 = function (drawable, index) {
    // Inline function 'kotlin.check' call
    if (!!this.s2y_1.n(drawable)) {
      var message = 'drawable already contained';
      throw IllegalStateException_init_$Create$(toString(message));
    }
    if (isInterface(drawable, Unzoomable)) {
      drawable.o2b(this.h24());
    }
    this.s2y_1.t3(index, drawable);
    drawable.f20(this.h2z_1);
    drawable.i20();
    drawable.k20();
  };
  protoOf(ViewImpl).r30 = function (drawable) {
    drawable.i20();
    this.s2y_1.h2(drawable);
    drawable.k20();
    drawable.g20(this.h2z_1);
  };
  protoOf(ViewImpl).y24 = function (drawable) {
    return this.s2y_1.n(drawable);
  };
  protoOf(ViewImpl).z24 = function (oldDrawable, newDrawable) {
    oldDrawable.i20();
    oldDrawable.g20(this.h2z_1);
    this.s2y_1.u2(this.s2y_1.p(oldDrawable), newDrawable);
    newDrawable.f20(this.h2z_1);
  };
  protoOf(ViewImpl).a25 = function (x, y, condition) {
    var _iterator__ex2g4s = this.s2y_1.i();
    while (_iterator__ex2g4s.j()) {
      var drawable = _iterator__ex2g4s.k();
      if (isInterface(drawable, DrawableContainer)) {
        var innerDrawable = drawable.i21(x, y);
        if (!(innerDrawable == null) && condition(innerDrawable)) {
          return innerDrawable;
        }
      }
    }
    return null;
  };
  protoOf(ViewImpl).f1c = function () {
    var tmp0_safe_receiver = this.y2y_1;
    var tmp1_safe_receiver = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.s1x();
    var tmp2_safe_receiver = tmp1_safe_receiver == null ? null : tmp1_safe_receiver.u1e_1;
    var tmp3_elvis_lhs = tmp2_safe_receiver == null ? null : numberToInt(tmp2_safe_receiver);
    return tmp3_elvis_lhs == null ? 0 : tmp3_elvis_lhs;
  };
  protoOf(ViewImpl).h1c = function () {
    var tmp0_safe_receiver = this.y2y_1;
    var tmp1_safe_receiver = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.s1x();
    var tmp2_safe_receiver = tmp1_safe_receiver == null ? null : tmp1_safe_receiver.v1e_1;
    var tmp3_elvis_lhs = tmp2_safe_receiver == null ? null : numberToInt(tmp2_safe_receiver);
    return tmp3_elvis_lhs == null ? 0 : tmp3_elvis_lhs;
  };
  protoOf(ViewImpl).c30 = function () {
    return new ViewContentBounds(VOID, ViewImpl$calculateCombinedBoundingBox$ref(this));
  };
  protoOf(ViewImpl).z1y = function (e) {
    var tmp0_safe_receiver = this.y2y_1;
    if (tmp0_safe_receiver == null)
      null;
    else {
      tmp0_safe_receiver.z1y(e);
    }
  };
  protoOf(ViewImpl).d24 = function (e) {
    return this.b2z_1;
  };
  protoOf(ViewImpl).r1y = function (l) {
    var tmp0_safe_receiver = this.y2y_1;
    if (tmp0_safe_receiver == null)
      null;
    else {
      tmp0_safe_receiver.r1y(l);
    }
  };
  protoOf(ViewImpl).s1y = function (l) {
    var tmp0_safe_receiver = this.y2y_1;
    if (tmp0_safe_receiver == null)
      null;
    else {
      tmp0_safe_receiver.s1y(l);
    }
  };
  protoOf(ViewImpl).t1y = function (l) {
    var tmp0_safe_receiver = this.y2y_1;
    if (tmp0_safe_receiver == null)
      null;
    else {
      tmp0_safe_receiver.t1y(l);
    }
  };
  protoOf(ViewImpl).u1y = function (l) {
    var tmp0_safe_receiver = this.y2y_1;
    if (tmp0_safe_receiver == null)
      null;
    else {
      tmp0_safe_receiver.u1y(l);
    }
  };
  protoOf(ViewImpl).v1y = function (l) {
    var tmp0_safe_receiver = this.y2y_1;
    if (tmp0_safe_receiver == null)
      null;
    else {
      tmp0_safe_receiver.v1y(l);
    }
  };
  protoOf(ViewImpl).w1y = function (l) {
    var tmp0_safe_receiver = this.y2y_1;
    if (tmp0_safe_receiver == null)
      null;
    else {
      tmp0_safe_receiver.w1y(l);
    }
  };
  protoOf(ViewImpl).x1y = function (l) {
    var tmp0_safe_receiver = this.y2y_1;
    if (tmp0_safe_receiver == null)
      null;
    else {
      tmp0_safe_receiver.x1y(l);
    }
  };
  protoOf(ViewImpl).y1y = function (l) {
    var tmp0_safe_receiver = this.y2y_1;
    if (tmp0_safe_receiver == null)
      null;
    else {
      tmp0_safe_receiver.y1y(l);
    }
  };
  protoOf(ViewImpl).b1z = function (l) {
    this.t2y_1.zr(l);
  };
  protoOf(ViewImpl).e24 = function (l) {
    return this.t2y_1.x1b(l);
  };
  protoOf(ViewImpl).c1z = function (l) {
    this.t2y_1.as(l);
  };
  protoOf(ViewImpl).f30 = function (name, oldValue, newValue) {
    this.t2y_1.nr(name, oldValue, newValue);
  };
  protoOf(ViewImpl).y23 = function (value) {
    if (!equals(this.c2z_1, value)) {
      this.y2z();
      this.c2z_1 = value;
      this.t1x();
    }
  };
  protoOf(ViewImpl).z23 = function () {
    return this.c2z_1;
  };
  protoOf(ViewImpl).b24 = function () {
    return this.d2z_1;
  };
  protoOf(ViewImpl).c24 = function () {
    return this.e2z_1;
  };
  protoOf(ViewImpl).a24 = function () {
    return this.j2z_1;
  };
  protoOf(ViewImpl).l1y = function (cursor) {
    this.s23().l1y(cursor);
  };
  protoOf(ViewImpl).u1x = function (g) {
    var tmp;
    if (g.w1t()) {
      g.m1v(this.g2z_1);
      this.g2z_1.u1h_1 = this.b25(this.g2z_1.u1h_1);
      this.g2z_1.v1h_1 = this.c25(this.g2z_1.v1h_1);
      this.g2z_1.w1h_1 = this.f25(this.g2z_1.w1h_1);
      this.g2z_1.x1h_1 = this.f25(this.g2z_1.x1h_1);
      tmp = this.g2z_1;
    } else {
      tmp = null;
    }
    var modelClip = tmp;
    this.f2z_1.r2w(DrawModule_getInstance().o2a_1(g, modelClip, this.w23()));
  };
  protoOf(ViewImpl).h20 = function (context) {
    if (!this.z2y_1) {
      return Unit_instance;
    }
    context.j1z_1.n1u();
    var oldTransform = context.j1z_1.b1t();
    var zoomedTransform = context.j1z_1.b1t();
    zoomedTransform.q1d(this.g24().o25_1);
    context.j1z_1.x1t(this.a24());
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = asReversed(this.s2y_1).i();
    while (_iterator__ex2g4s.j()) {
      var element = _iterator__ex2g4s.k();
      if (isInterface(element, Unzoomable)) {
        context.j1z_1.a1u(oldTransform);
        // Inline function 'kotlin.also' call
        var this_0 = this.s23().r1x();
        context.j1z_1.n1d(this_0, this_0);
        element.h20(context);
        context.j1z_1.n1d(1 / this_0, 1 / this_0);
      } else {
        context.j1z_1.a1u(zoomedTransform);
        element.h20(context);
      }
    }
    if (!(this.z23() == null)) {
      context.j1z_1.b1u(ensureNotNull(this.z23()));
      context.j1z_1.z1u(0.0, 0.0, this.s23().s1x().u1e_1, this.s23().s1x().v1e_1);
    }
    if (DrawModule_getInstance().g2a_1) {
      context.j1z_1.b1u(DrawModule_getInstance().j2a_1);
      var originView = this.g25(Companion_getInstance().w1a_1);
      context.j1z_1.t1u(originView.kn_1, 0.0, originView.kn_1, this.h1c());
      context.j1z_1.t1u(0.0, originView.ln_1, this.f1c(), originView.ln_1);
    }
    context.j1z_1.a1u(oldTransform);
    // Inline function 'kotlin.also' call
    var this_1 = this.s23().r1x();
    context.j1z_1.n1d(this_1, this_1);
    this.d2z_1.h20(context);
    context.j1z_1.n1d(1 / this_1, 1 / this_1);
    context.j1z_1.o1u();
  };
  protoOf(ViewImpl).t1x = function () {
    var tmp0_safe_receiver = this.y2y_1;
    if (tmp0_safe_receiver == null)
      null;
    else {
      tmp0_safe_receiver.t1x();
    }
  };
  protoOf(ViewImpl).m1y = function (x, y, w, h) {
    var tmp0_safe_receiver = this.y2y_1;
    if (tmp0_safe_receiver == null)
      null;
    else {
      tmp0_safe_receiver.m1y(x, y, w, h);
    }
  };
  protoOf(ViewImpl).s30 = function (region) {
    if (this.y2y_1 == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      this.f2z_1.s2w(region);
    }
  };
  protoOf(ViewImpl).y2z = function (region, $super) {
    region = region === VOID ? null : region;
    var tmp;
    if ($super === VOID) {
      this.s30(region);
      tmp = Unit_instance;
    } else {
      tmp = $super.s30.call(this, region);
    }
    return tmp;
  };
  protoOf(ViewImpl).n24 = function () {
    return this.k2z_1;
  };
  protoOf(ViewImpl).o24 = function (_set____db54di) {
    this.l2z_1 = _set____db54di;
  };
  protoOf(ViewImpl).p24 = function () {
    return this.l2z_1;
  };
  protoOf(ViewImpl).q24 = function (value) {
    if (!this.m2z_1.equals(value)) {
      var oldValue = this.m2z_1;
      this.m2z_1 = value;
      this.f30('draw.view.zoomStrategy', oldValue, this.m2z_1);
    }
    this.m2z_1.s27(this.n24());
  };
  protoOf(ViewImpl).r24 = function () {
    return this.m2z_1;
  };
  protoOf(ViewImpl).f24 = function (value) {
    var oldValue = this.n2z_1;
    this.n2z_1 = value;
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = this.s2y_1.i();
    while (_iterator__ex2g4s.j()) {
      var element = _iterator__ex2g4s.k();
      if (isInterface(element, Unzoomable)) {
        element.o2b(this.h24());
      }
    }
    this.y2z();
    this.t1x();
    this.f30('PROP_TRANSFORMATION', oldValue, this.n2z_1);
  };
  protoOf(ViewImpl).g24 = function () {
    return this.n2z_1;
  };
  protoOf(ViewImpl).h24 = function () {
    return this.g24().n25_1;
  };
  protoOf(ViewImpl).s24 = function (value) {
    if (!(this.o2z_1 === value)) {
      this.o2z_1 = value;
      this.f30('PROP_USER_ZOOM_ENABLED', !this.o2z_1, this.o2z_1);
    }
  };
  protoOf(ViewImpl).t24 = function () {
    return this.o2z_1;
  };
  protoOf(ViewImpl).u24 = function (value) {
    this.r2y_1.u24(value);
  };
  protoOf(ViewImpl).v24 = function () {
    this.q24(this.p24());
    this.x2z();
  };
  protoOf(ViewImpl).x2z = function () {
    this.r24().s27(this.n24());
  };
  protoOf(ViewImpl).b25 = function (x) {
    return this.g24().o25_1.p1d(new Point2D(x, 0.0)).kn_1;
  };
  protoOf(ViewImpl).c25 = function (y) {
    return this.g24().o25_1.p1d(new Point2D(0.0, y)).ln_1;
  };
  protoOf(ViewImpl).d25 = function (p) {
    return this.g24().o25_1.p1d(p);
  };
  protoOf(ViewImpl).e25 = function (p, zoomFactor) {
    var tmp;
    if (zoomFactor === this.i24()) {
      tmp = this.d25(p);
    } else {
      tmp = this.n24().y26(zoomFactor).o25_1.p1d(p);
    }
    return tmp;
  };
  protoOf(ViewImpl).f25 = function (length) {
    return length / this.i24();
  };
  protoOf(ViewImpl).g25 = function (p) {
    return this.g24().o25_1.nn(p);
  };
  protoOf(ViewImpl).i25 = function (x) {
    return this.g25(new Point2D(x, 0.0)).kn_1;
  };
  protoOf(ViewImpl).j25 = function (y) {
    return this.g25(new Point2D(0.0, y)).ln_1;
  };
  protoOf(ViewImpl).h25 = function (p, zoomFactor) {
    var tmp;
    if (zoomFactor === this.i24()) {
      tmp = this.g25(p);
    } else {
      tmp = this.n24().y26(zoomFactor).o25_1.nn(p);
    }
    return tmp;
  };
  protoOf(ViewImpl).k25 = function (length) {
    return length * this.i24();
  };
  protoOf(ViewImpl).l25 = function (p) {
    return this.g25(p).y1f(1 / this.s23().r1x());
  };
  function ViewNavigatorImpl$Companion$_get_LOG_$ref_gshcq6() {
    return function (p0) {
      return p0.o1q();
    };
  }
  function Companion_37() {
    Companion_instance_41 = this;
    this.t30_1 = logger(getKClass(ViewNavigatorImpl));
    this.u30_1 = 20;
  }
  protoOf(Companion_37).o1q = function () {
    var tmp0 = this.t30_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('LOG', 1, tmp, ViewNavigatorImpl$Companion$_get_LOG_$ref_gshcq6(), null);
    return tmp0.j2();
  };
  var Companion_instance_41;
  function Companion_getInstance_39() {
    if (Companion_instance_41 == null)
      new Companion_37();
    return Companion_instance_41;
  }
  function _get_defaultZoomFactor__r0sdji($this) {
    return $this.x30_1.lt('draw.view.defaultZoomFactor');
  }
  function _get_minZoomFactor__ocim3h($this) {
    return BaseModule_getInstance().zo_1.lt('draw.view.minZoomFactor');
  }
  function _get_maxZoomFactor__dhemff($this) {
    return BaseModule_getInstance().zo_1.lt('draw.view.maxZoomFactor');
  }
  function _get_effDefaultZoomFactor__j7gypf($this) {
    return _get_defaultZoomFactor__r0sdji($this) * $this.v30_1.s23().r1x();
  }
  function createTransformation($this, zoomPan) {
    // Inline function 'kotlin.apply' call
    var this_0 = $this.w30_1();
    this_0.n1d(zoomPan.k24_1, zoomPan.k24_1);
    this_0.m1d(zoomPan.l24_1.c1h());
    return new ViewTransformation(zoomPan, this_0);
  }
  function setZoomPan($this, zoomPan) {
    $this.v30_1.f24(createTransformation($this, zoomPan));
  }
  function calculateContentCenterPan($this, zoomFactor, fixMaxNormal) {
    fixMaxNormal = fixMaxNormal === VOID ? false : fixMaxNormal;
    var bounds = $this.v30_1.x23();
    var newCenter = $this.v30_1.h25(new Point2D(bounds.w25().x1c(), bounds.w25().y1c()), zoomFactor);
    if (fixMaxNormal) {
      var overlapY = $this.v30_1.u23().v2z_1.a1d() + 20 - $this.v30_1.h25(new Point2D(0.0, bounds.w25().a1d()), zoomFactor).ln_1;
      if (overlapY > 0) {
        newCenter = newCenter.j1h(new Point2D(0.0, overlapY));
      }
    }
    var result = new Point2D($this.v30_1.h24().l24_1.kn_1 + (newCenter.kn_1 - $this.v30_1.u23().u2z_1.u1e_1 / 2.0) / zoomFactor, $this.v30_1.h24().l24_1.ln_1 + (newCenter.ln_1 - $this.v30_1.u23().u2z_1.v1e_1 / 2.0) / zoomFactor);
    Companion_getInstance_39().o1q().ql('center Pan for content ' + toString(bounds) + ' in view ' + $this.v30_1.s23().s1x().toString() + ' is ' + result.toString());
    return result;
  }
  function calculateFitZoomFactor($this) {
    var bounds = $this.v30_1.x23().x25();
    if (bounds.f1c() === 0.0 || bounds.h1c() === 0.0) {
      return _get_effDefaultZoomFactor__j7gypf($this);
    }
    if ($this.v30_1.u23().v2z_1.u1c() === 0 || $this.v30_1.u23().v2z_1.v1c() === 0) {
      return _get_effDefaultZoomFactor__j7gypf($this);
    }
    var tmp0 = ($this.v30_1.u23().v2z_1.u1c() - 40 | 0) / bounds.f1c();
    // Inline function 'kotlin.math.min' call
    var b = ($this.v30_1.u23().v2z_1.v1c() - 40 | 0) / bounds.h1c();
    return Math.min(tmp0, b);
  }
  function View$_get_devicePixelRatio_$ref_aprbr2(p0) {
    return function () {
      return p0.r1x();
    };
  }
  function View$_get_devicePixelRatio_$ref_aprbr2_0(p0) {
    return function () {
      return p0.r1x();
    };
  }
  function View$_get_devicePixelRatio_$ref_aprbr2_1(p0) {
    return function () {
      return p0.r1x();
    };
  }
  function View$_get_devicePixelRatio_$ref_aprbr2_2(p0) {
    return function () {
      return p0.r1x();
    };
  }
  function View$_get_devicePixelRatio_$ref_aprbr2_3(p0) {
    return function () {
      return p0.r1x();
    };
  }
  function View$_get_devicePixelRatio_$ref_aprbr2_4(p0) {
    return function () {
      return p0.r1x();
    };
  }
  function View$_get_devicePixelRatio_$ref_aprbr2_5(p0) {
    return function () {
      return p0.r1x();
    };
  }
  function ViewNavigatorImpl(view, affineTransformFactory, properties) {
    Companion_getInstance_39();
    properties = properties === VOID ? BaseModule_getInstance().zo_1 : properties;
    this.v30_1 = view;
    this.w30_1 = affineTransformFactory;
    this.x30_1 = properties;
  }
  protoOf(ViewNavigatorImpl).y26 = function (zoomFactor) {
    var tmp = this.v30_1.h24().l24_1;
    var tmp_0 = KProperty0;
    return createTransformation(this, new ZoomPan(this.v30_1, zoomFactor, tmp, getPropertyCallableRef('devicePixelRatio', 0, tmp_0, View$_get_devicePixelRatio_$ref_aprbr2(this.v30_1), null)));
  };
  protoOf(ViewNavigatorImpl).y30 = function (zoomFactor, zoomLocation) {
    var effZoomLocation = zoomLocation == null ? this.v30_1.d1d() : zoomLocation;
    if (!this.j27(zoomFactor)) {
      return Unit_instance;
    }
    var zoomLocationBeforeM = this.v30_1.d25(effZoomLocation);
    var zoomLocationAfterM = this.v30_1.e25(effZoomLocation, zoomFactor);
    var offset = zoomLocationBeforeM.j1h(zoomLocationAfterM);
    var tmp = this.v30_1.h24().l24_1.eo(offset);
    var tmp_0 = KProperty0;
    var zoomPan = new ZoomPan(this.v30_1, zoomFactor, tmp, getPropertyCallableRef('devicePixelRatio', 0, tmp_0, View$_get_devicePixelRatio_$ref_aprbr2_0(this.v30_1), null));
    this.v30_1.f24(createTransformation(this, zoomPan));
  };
  protoOf(ViewNavigatorImpl).z26 = function (translation) {
    var locationAfterZoomV = translation.z30_1.y1f(translation.b31_1);
    var offsetV = translation.a31_1.j1h(locationAfterZoomV);
    var offsetM = offsetV.y1f(1 / translation.b31_1).c1h();
    var tmp = KProperty0;
    var zoomPan = new ZoomPan(this.v30_1, translation.b31_1, offsetM, getPropertyCallableRef('devicePixelRatio', 0, tmp, View$_get_devicePixelRatio_$ref_aprbr2_1(this.v30_1), null));
    this.v30_1.f24(createTransformation(this, zoomPan));
  };
  protoOf(ViewNavigatorImpl).a27 = function (factor, zoomLocation) {
    var zoomFactor = this.v30_1.i24() * factor;
    if (this.j27(zoomFactor)) {
      this.y30(zoomFactor, zoomLocation);
    }
  };
  protoOf(ViewNavigatorImpl).c27 = function (dx, dy) {
    var tmp = this.v30_1.i24();
    var tmp_0 = new Point2D(this.v30_1.h24().l24_1.kn_1 - dx / this.v30_1.i24(), this.v30_1.h24().l24_1.ln_1 - dy / this.v30_1.i24());
    var tmp_1 = KProperty0;
    setZoomPan(this, new ZoomPan(this.v30_1, tmp, tmp_0, getPropertyCallableRef('devicePixelRatio', 0, tmp_1, View$_get_devicePixelRatio_$ref_aprbr2_2(this.v30_1), null)));
  };
  protoOf(ViewNavigatorImpl).d27 = function () {
    this.f27(this.v30_1.i24());
  };
  protoOf(ViewNavigatorImpl).e27 = function () {
    this.f27(_get_effDefaultZoomFactor__j7gypf(this));
  };
  protoOf(ViewNavigatorImpl).f27 = function (zoomFactor) {
    if (this.j27(zoomFactor)) {
      var tmp = calculateContentCenterPan(this, zoomFactor);
      var tmp_0 = KProperty0;
      setZoomPan(this, new ZoomPan(this.v30_1, zoomFactor, tmp, getPropertyCallableRef('devicePixelRatio', 0, tmp_0, View$_get_devicePixelRatio_$ref_aprbr2_3(this.v30_1), null)));
    }
  };
  protoOf(ViewNavigatorImpl).g27 = function () {
    var zoomFactor = calculateFitZoomFactor(this);
    if (this.j27(zoomFactor)) {
      var tmp = calculateContentCenterPan(this, zoomFactor);
      var tmp_0 = KProperty0;
      setZoomPan(this, new ZoomPan(this.v30_1, zoomFactor, tmp, getPropertyCallableRef('devicePixelRatio', 0, tmp_0, View$_get_devicePixelRatio_$ref_aprbr2_4(this.v30_1), null)));
    }
  };
  protoOf(ViewNavigatorImpl).h27 = function () {
    var zoomFactor = this.i27();
    if (this.j27(zoomFactor)) {
      var tmp = calculateContentCenterPan(this, zoomFactor, true);
      var tmp_0 = KProperty0;
      setZoomPan(this, new ZoomPan(this.v30_1, zoomFactor, tmp, getPropertyCallableRef('devicePixelRatio', 0, tmp_0, View$_get_devicePixelRatio_$ref_aprbr2_5(this.v30_1), null)));
    }
  };
  protoOf(ViewNavigatorImpl).i27 = function () {
    var tmp0 = _get_effDefaultZoomFactor__j7gypf(this);
    // Inline function 'kotlin.math.min' call
    var b = calculateFitZoomFactor(this);
    return Math.min(tmp0, b);
  };
  protoOf(ViewNavigatorImpl).j27 = function (zoomFactor) {
    var containsLower = _get_minZoomFactor__ocim3h(this);
    return zoomFactor <= _get_maxZoomFactor__dhemff(this) ? containsLower <= zoomFactor : false;
  };
  function Companion_38() {
    this.c31_1 = 'ViewSpace.area';
  }
  var Companion_instance_42;
  function Companion_getInstance_40() {
    return Companion_instance_42;
  }
  function updateArea($this) {
    var oldValue = $this.v2z_1;
    var tmp0_elvis_lhs = maxOrNull($this.t2z_1);
    var topReduction = tmp0_elvis_lhs == null ? 0 : tmp0_elvis_lhs;
    $this.v2z_1 = Rectangle2D_init_$Create$_1(0, topReduction, $this.u2z_1.w1e_1, $this.u2z_1.x1e_1 - topReduction | 0);
    $this.d31('ViewSpace.area', oldValue, $this.v2z_1);
  }
  function ViewSpace(viewDimension, propertyOwner) {
    propertyOwner = propertyOwner === VOID ? new PropertyOwnerImpl() : propertyOwner;
    this.s2z_1 = propertyOwner;
    var tmp = this;
    // Inline function 'kotlin.collections.mutableListOf' call
    tmp.t2z_1 = ArrayList_init_$Create$();
    this.u2z_1 = viewDimension;
    this.v2z_1 = Rectangle2D_init_$Create$_1(0, 0, viewDimension.w1e_1, viewDimension.x1e_1);
    this.s2z_1.t1b(this);
    updateArea(this);
  }
  protoOf(ViewSpace).w2z = function (value) {
    if (!this.u2z_1.equals(value)) {
      this.u2z_1 = value;
      updateArea(this);
    }
  };
  protoOf(ViewSpace).e30 = function (l) {
    this.s2z_1.u1b(l);
  };
  protoOf(ViewSpace).u1b = function (l) {
    return this.e30(l);
  };
  protoOf(ViewSpace).d30 = function (l) {
    this.s2z_1.v1b(l);
  };
  protoOf(ViewSpace).v1b = function (l) {
    return this.d30(l);
  };
  protoOf(ViewSpace).d31 = function (name, oldValue, newValue) {
    this.s2z_1.nr(name, oldValue, newValue);
  };
  protoOf(ViewSpace).nr = function (name, oldValue, newValue) {
    var tmp = (oldValue == null ? true : oldValue instanceof Rectangle2D) ? oldValue : THROW_CCE();
    return this.d31(name, tmp, (newValue == null ? true : newValue instanceof Rectangle2D) ? newValue : THROW_CCE());
  };
  protoOf(ViewSpace).t1b = function (_set____db54di) {
    this.s2z_1.t1b(_set____db54di);
  };
  function get_zoomInAction() {
    _init_properties_ZoomPanAction_kt__uhg82a();
    var tmp0 = zoomInAction$delegate;
    var tmp = KProperty0;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('zoomInAction', 0, tmp, _get_zoomInAction_$ref_cghp70(), null);
    return tmp0.j2();
  }
  var zoomInAction$delegate;
  function get_zoomNormalAction() {
    _init_properties_ZoomPanAction_kt__uhg82a();
    var tmp0 = zoomNormalAction$delegate;
    var tmp = KProperty0;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('zoomNormalAction', 0, tmp, _get_zoomNormalAction_$ref_vqlqnq(), null);
    return tmp0.j2();
  }
  var zoomNormalAction$delegate;
  function get_zoomOutAction() {
    _init_properties_ZoomPanAction_kt__uhg82a();
    var tmp0 = zoomOutAction$delegate;
    var tmp = KProperty0;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('zoomOutAction', 0, tmp, _get_zoomOutAction_$ref_i71pvz(), null);
    return tmp0.j2();
  }
  var zoomOutAction$delegate;
  function get_zoomFitAction() {
    _init_properties_ZoomPanAction_kt__uhg82a();
    var tmp0 = zoomFitAction$delegate;
    var tmp = KProperty0;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('zoomFitAction', 0, tmp, _get_zoomFitAction_$ref_9m088c(), null);
    return tmp0.j2();
  }
  var zoomFitAction$delegate;
  function get_zoomFitMaxNormalAction() {
    _init_properties_ZoomPanAction_kt__uhg82a();
    var tmp0 = zoomFitMaxNormalAction$delegate;
    var tmp = KProperty0;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('zoomFitMaxNormalAction', 0, tmp, _get_zoomFitMaxNormalAction_$ref_g7olbr(), null);
    return tmp0.j2();
  }
  var zoomFitMaxNormalAction$delegate;
  function get_zoomCenterAction() {
    _init_properties_ZoomPanAction_kt__uhg82a();
    var tmp0 = zoomCenterAction$delegate;
    var tmp = KProperty0;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('zoomCenterAction', 0, tmp, _get_zoomCenterAction_$ref_379gtg(), null);
    return tmp0.j2();
  }
  var zoomCenterAction$delegate;
  function ZoomPanActions() {
  }
  protoOf(ZoomPanActions).e31 = function () {
    return get_zoomNormalAction();
  };
  protoOf(ZoomPanActions).f31 = function () {
    return get_zoomInAction();
  };
  protoOf(ZoomPanActions).g31 = function () {
    return get_zoomOutAction();
  };
  protoOf(ZoomPanActions).h31 = function () {
    return get_zoomFitAction();
  };
  protoOf(ZoomPanActions).i31 = function () {
    return get_zoomFitMaxNormalAction();
  };
  protoOf(ZoomPanActions).j31 = function () {
    return get_zoomCenterAction();
  };
  var ZoomPanActions_instance;
  function ZoomPanActions_getInstance() {
    return ZoomPanActions_instance;
  }
  function ZoomInAction(viewManager, eventBus) {
    viewManager = viewManager === VOID ? DrawViewModule_getInstance().q2u_1 : viewManager;
    eventBus = eventBus === VOID ? BaseModule_getInstance().bp_1 : eventBus;
    AbstractZoomPanAction.call(this, Companion_getInstance_10().l27_1, 'view.action.zoomIn', eventBus, viewManager);
  }
  protoOf(ZoomInAction).yr = function () {
    return protoOf(AbstractZoomPanAction).yr.call(this) && !(this.v1o() == null) && ensureNotNull(this.v1o()).n24().j27(ensureNotNull(this.v1o()).i24() * this.l32_1);
  };
  protoOf(ZoomInAction).execute = function (event) {
    var view = ensureNotNull(ensureNotNull(this.h2u_1.r2u()).v1o());
    view.n24().b27(this.l32_1);
    view.q24(Companion_getInstance_10().l27_1);
  };
  function ZoomNormalAction(viewManager, eventBus) {
    viewManager = viewManager === VOID ? DrawViewModule_getInstance().q2u_1 : viewManager;
    eventBus = eventBus === VOID ? BaseModule_getInstance().bp_1 : eventBus;
    AbstractZoomPanAction.call(this, Companion_getInstance_10().m27_1, 'view.action.zoomNormal', eventBus, viewManager);
  }
  function ZoomOutAction(viewManager, eventBus) {
    viewManager = viewManager === VOID ? DrawViewModule_getInstance().q2u_1 : viewManager;
    eventBus = eventBus === VOID ? BaseModule_getInstance().bp_1 : eventBus;
    AbstractZoomPanAction.call(this, Companion_getInstance_10().l27_1, 'view.action.zoomOut', eventBus, viewManager);
  }
  protoOf(ZoomOutAction).yr = function () {
    return protoOf(AbstractZoomPanAction).yr.call(this) && !(this.v1o() == null) && ensureNotNull(this.v1o()).n24().j27(1 / ensureNotNull(this.v1o()).i24() * this.l32_1);
  };
  protoOf(ZoomOutAction).execute = function (event) {
    var view = ensureNotNull(ensureNotNull(this.h2u_1.r2u()).v1o());
    view.n24().b27(1 / this.l32_1);
    view.q24(Companion_getInstance_10().l27_1);
  };
  function ZoomFitAction(viewManager, eventBus) {
    viewManager = viewManager === VOID ? DrawViewModule_getInstance().q2u_1 : viewManager;
    eventBus = eventBus === VOID ? BaseModule_getInstance().bp_1 : eventBus;
    AbstractZoomPanAction.call(this, Companion_getInstance_10().n27_1, 'view.action.zoomFit', eventBus, viewManager);
  }
  function ZoomFitMaxNormalAction(viewManager, eventBus) {
    viewManager = viewManager === VOID ? DrawViewModule_getInstance().q2u_1 : viewManager;
    eventBus = eventBus === VOID ? BaseModule_getInstance().bp_1 : eventBus;
    AbstractZoomPanAction.call(this, Companion_getInstance_10().o27_1, 'view.action.zoomFitMaxNormal', eventBus, viewManager);
  }
  function ZoomCenterAction(viewManager, eventBus) {
    viewManager = viewManager === VOID ? DrawViewModule_getInstance().q2u_1 : viewManager;
    eventBus = eventBus === VOID ? BaseModule_getInstance().bp_1 : eventBus;
    AbstractZoomPanAction.call(this, Companion_getInstance_10().p27_1, 'view.action.zoomCenter', eventBus, viewManager);
  }
  function Companion_39() {
    this.f35_1 = 'view.command.zoom.step';
  }
  var Companion_instance_43;
  function Companion_getInstance_41() {
    return Companion_instance_43;
  }
  function updateSelected($this) {
    $this.rq($this.m32());
  }
  function AbstractZoomPanAction(zoomStrategy, baseName, eventBus, viewManager) {
    eventBus = eventBus === VOID ? BaseModule_getInstance().bp_1 : eventBus;
    viewManager = viewManager === VOID ? DrawViewModule_getInstance().q2u_1 : viewManager;
    AbstractViewAction.call(this, baseName, eventBus, viewManager);
    this.k32_1 = zoomStrategy;
    this.l32_1 = BaseModule_getInstance().zo_1.lt('view.command.zoom.step');
  }
  protoOf(AbstractZoomPanAction).execute = function (event) {
    ensureNotNull(ensureNotNull(this.h2u_1.r2u()).v1o()).q24(this.k32_1);
  };
  protoOf(AbstractZoomPanAction).yr = function () {
    var tmp;
    if (protoOf(AbstractViewAction).yr.call(this)) {
      var tmp0_safe_receiver = this.h2u_1.r2u();
      var tmp1_safe_receiver = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.v1o();
      tmp = (tmp1_safe_receiver == null ? null : tmp1_safe_receiver.t24()) === true;
    } else {
      tmp = false;
    }
    return tmp;
  };
  protoOf(AbstractZoomPanAction).k2u = function (e) {
    protoOf(AbstractViewAction).k2u.call(this, e);
    switch (e.name) {
      case 'PROP_USER_ZOOM_ENABLED':
        this.updateEnabled();
        break;
      case 'draw.view.zoomStrategy':
        updateSelected(this);
        break;
      case 'PROP_TRANSFORMATION':
        this.updateEnabled();
        break;
    }
  };
  protoOf(AbstractZoomPanAction).l2u = function () {
    updateSelected(this);
    this.updateEnabled();
  };
  protoOf(AbstractZoomPanAction).m32 = function () {
    var tmp0_safe_receiver = this.h2u_1.r2u();
    var tmp1_safe_receiver = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.v1o();
    return equals(tmp1_safe_receiver == null ? null : tmp1_safe_receiver.r24(), this.k32_1);
  };
  function zoomInAction$delegate$lambda() {
    _init_properties_ZoomPanAction_kt__uhg82a();
    return new ZoomInAction();
  }
  function _get_zoomInAction_$ref_cghp70() {
    return function () {
      return get_zoomInAction();
    };
  }
  function zoomNormalAction$delegate$lambda() {
    _init_properties_ZoomPanAction_kt__uhg82a();
    return new ZoomNormalAction();
  }
  function _get_zoomNormalAction_$ref_vqlqnq() {
    return function () {
      return get_zoomNormalAction();
    };
  }
  function zoomOutAction$delegate$lambda() {
    _init_properties_ZoomPanAction_kt__uhg82a();
    return new ZoomOutAction();
  }
  function _get_zoomOutAction_$ref_i71pvz() {
    return function () {
      return get_zoomOutAction();
    };
  }
  function zoomFitAction$delegate$lambda() {
    _init_properties_ZoomPanAction_kt__uhg82a();
    return new ZoomFitAction();
  }
  function _get_zoomFitAction_$ref_9m088c() {
    return function () {
      return get_zoomFitAction();
    };
  }
  function zoomFitMaxNormalAction$delegate$lambda() {
    _init_properties_ZoomPanAction_kt__uhg82a();
    return new ZoomFitMaxNormalAction();
  }
  function _get_zoomFitMaxNormalAction_$ref_g7olbr() {
    return function () {
      return get_zoomFitMaxNormalAction();
    };
  }
  function zoomCenterAction$delegate$lambda() {
    _init_properties_ZoomPanAction_kt__uhg82a();
    return new ZoomCenterAction();
  }
  function _get_zoomCenterAction_$ref_379gtg() {
    return function () {
      return get_zoomCenterAction();
    };
  }
  var properties_initialized_ZoomPanAction_kt_3igp1s;
  function _init_properties_ZoomPanAction_kt__uhg82a() {
    if (!properties_initialized_ZoomPanAction_kt_3igp1s) {
      properties_initialized_ZoomPanAction_kt_3igp1s = true;
      zoomInAction$delegate = lazy(zoomInAction$delegate$lambda);
      zoomNormalAction$delegate = lazy(zoomNormalAction$delegate$lambda);
      zoomOutAction$delegate = lazy(zoomOutAction$delegate$lambda);
      zoomFitAction$delegate = lazy(zoomFitAction$delegate$lambda);
      zoomFitMaxNormalAction$delegate = lazy(zoomFitMaxNormalAction$delegate$lambda);
      zoomCenterAction$delegate = lazy(zoomCenterAction$delegate$lambda);
    }
  }
  function _get_LOG__e5r759_9($this) {
    var tmp0 = $this.g35_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('LOG', 1, tmp, ZoomPanController$Companion$_get_LOG_$ref_qix2e(), null);
    return tmp0.j2();
  }
  function ZoomPanController$Companion$_get_LOG_$ref_qix2e() {
    return function (p0) {
      return _get_LOG__e5r759_9(p0);
    };
  }
  function isZoomOutWheelRotation($this, e) {
    return e.t1a().ln_1 < 0.0;
  }
  function isZoomWithMetaIfRequired($this, e) {
    return e.isMetaDown || !_get_wheelZoomRequiresMeta__yweuk0($this.k35_1);
  }
  function getZoomChangeFactorFromWheelRotation($this, e) {
    if (!near(e.t1a().ln_1, 0.0)) {
      return isZoomOutWheelRotation($this, e) ? 1 / _get_wheelZoomStep__lkqvft($this.k35_1) : _get_wheelZoomStep__lkqvft($this.k35_1);
    }
    return 1.0;
  }
  function getPanVectorFromWheelRotation($this, e) {
    return e.t1a().y1f(_get_wheelPanStep__9i9m3n($this.k35_1));
  }
  function panByWheel($this, e) {
    $this.k35_1.o30_1 = Companion_getInstance().w1a_1;
    pan_0($this.k35_1, getPanVectorFromWheelRotation($this, e));
    $this.k35_1.k30_1.b2x();
  }
  function zoomByWheel($this, e) {
    $this.k35_1.g30_1.n24().a27(getZoomChangeFactorFromWheelRotation($this, e), e.jw());
    $this.k35_1.k30_1.a2x();
  }
  function Companion_40() {
    Companion_instance_44 = this;
    this.g35_1 = logger(getKClass(ZoomPanController));
    this.h35_1 = 'view.ZoomPanController.wheelZoomStep';
    this.i35_1 = 'view.ZoomPanController.wheelZoomRequiredMeta';
    this.j35_1 = 'view.ZoomPanController.wheelPanStep';
  }
  var Companion_instance_44;
  function Companion_getInstance_42() {
    if (Companion_instance_44 == null)
      new Companion_40();
    return Companion_instance_44;
  }
  function _get_wheelZoomStep__lkqvft($this) {
    return BaseModule_getInstance().zo_1.lt('view.ZoomPanController.wheelZoomStep');
  }
  function _get_wheelPanStep__9i9m3n($this) {
    return BaseModule_getInstance().zo_1.kt('view.ZoomPanController.wheelPanStep');
  }
  function _get_wheelZoomRequiresMeta__yweuk0($this) {
    return BaseModule_getInstance().zo_1.ht('view.ZoomPanController.wheelZoomRequiredMeta');
  }
  function startPan($this, pos) {
    $this.o30_1 = pos;
    $this.n30_1 = true;
  }
  function pan_0($this, pos) {
    var delta = pos.j1h($this.o30_1);
    $this.g30_1.n24().c27(numberToInt(delta.kn_1), numberToInt(delta.ln_1));
    $this.o30_1 = pos;
  }
  function MouseController($outer) {
    this.k35_1 = $outer;
    MouseAdapter.call(this);
  }
  protoOf(MouseController).i1b = function (e) {
    this.k35_1.m30_1 = true;
    if (!CurrentPanMethod_getInstance().p2x_1.f2x(e, this.k35_1.k30_1.y2w_1)) {
      return Unit_instance;
    }
    startPan(this.k35_1, e.jw());
  };
  protoOf(MouseController).k1b = function (e) {
    if (e.u1a() || e.v1a()) {
      this.k35_1.l30_1.m2v();
    }
    if (this.k35_1.n30_1) {
      pan_0(this.k35_1, e.jw());
    }
  };
  protoOf(MouseController).j1b = function (e) {
    this.k35_1.m30_1 = false;
    this.k35_1.n30_1 = false;
    if (!e.r1a().equals(Button_BUTTON3_getInstance())) {
      this.k35_1.l30_1.n2v();
    }
    if (CurrentPanMethod_getInstance().p2x_1.f2x(e, this.k35_1.k30_1.y2w_1)) {
      this.k35_1.g30_1.q24(Companion_getInstance_10().l27_1);
    }
  };
  protoOf(MouseController).m1b = function (e) {
    if (this.k35_1.m30_1) {
      return Unit_instance;
    }
    if (!isZoomWithMetaIfRequired(this, e)) {
      return Unit_instance;
    }
    this.k35_1.g30_1.q24(Companion_getInstance_10().l27_1);
    if (this.k35_1.k30_1.z2w()) {
      zoomByWheel(this, e);
    } else {
      panByWheel(this, e);
    }
    e.consumeEvent();
  };
  function ZoomPanController$activeViewChangeHandler$lambda(this$0) {
    return function (it) {
      _get_LOG__e5r759_9(Companion_getInstance_42()).ql('activeContentViewChanged, resetting mouseWheelModeController');
      this$0.k30_1.du();
      return Unit_instance;
    };
  }
  function ZoomPanController(view, eventBus) {
    Companion_getInstance_42();
    eventBus = eventBus === VOID ? BaseModule_getInstance().bp_1 : eventBus;
    this.g30_1 = view;
    this.h30_1 = eventBus;
    this.i30_1 = false;
    this.j30_1 = new MouseController(this);
    this.k30_1 = new MouseWheelModeController();
    this.l30_1 = new AutoPanning(this.g30_1);
    this.m30_1 = false;
    this.n30_1 = false;
    this.o30_1 = Companion_getInstance().w1a_1;
    var tmp = this;
    tmp.p30_1 = ZoomPanController$activeViewChangeHandler$lambda(this);
    this.h30_1.z17(getKClass(ActiveContentViewChangedEvent), this.p30_1);
  }
  protoOf(ZoomPanController).pq = function (value) {
    if (value) {
      this.g30_1.r1y(this.j30_1);
      this.g30_1.t1y(this.j30_1);
      this.g30_1.v1y(this.j30_1);
      this.g30_1.x1y(this.k30_1);
    } else {
      this.g30_1.s1y(this.j30_1);
      this.g30_1.u1y(this.j30_1);
      this.g30_1.w1y(this.j30_1);
      this.g30_1.y1y(this.k30_1);
    }
    this.i30_1 = value;
  };
  protoOf(ZoomPanController).u24 = function (value) {
    this.l30_1.l2v_1 = value;
  };
  protoOf(ZoomPanController).gs = function () {
    this.h30_1.b18(this.p30_1);
  };
  function ZoomedPointTranslation(modelPoint, viewPoint, zoomFactor) {
    this.z30_1 = modelPoint;
    this.a31_1 = viewPoint;
    this.b31_1 = zoomFactor;
  }
  protoOf(ZoomedPointTranslation).toString = function () {
    return 'ZoomedPointTranslation(modelPoint=' + this.z30_1.toString() + ', viewPoint=' + this.a31_1.toString() + ', zoomFactor=' + this.b31_1 + ')';
  };
  protoOf(ZoomedPointTranslation).hashCode = function () {
    var result = this.z30_1.hashCode();
    result = imul(result, 31) + this.a31_1.hashCode() | 0;
    result = imul(result, 31) + getNumberHashCode(this.b31_1) | 0;
    return result;
  };
  protoOf(ZoomedPointTranslation).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof ZoomedPointTranslation))
      return false;
    if (!this.z30_1.equals(other.z30_1))
      return false;
    if (!this.a31_1.equals(other.a31_1))
      return false;
    if (!equals(this.b31_1, other.b31_1))
      return false;
    return true;
  };
  function ZoomedPointVoyageAnimation$_init_$lambda_of1by4($view) {
    return function (it) {
      $view.n24().z26(it);
      return Unit_instance;
    };
  }
  function ZoomedPointVoyageAnimation(view, duration, destination) {
    AbstractAnimationTask.call(this, view, ZoomedPointVoyageAnimation$_init_$lambda_of1by4(view), new ZoomedPointVoyage(view, destination), duration);
  }
  function calculateNext($this, distance) {
    if (distance === 0.0) {
      return ensureNotNull($this.o35_1);
    }
    var tmp;
    if ($this.n35_1) {
      tmp = distance / $this.l35_1.o();
    } else {
      tmp = distance / $this.m35_1.g1r_1;
    }
    var fraction = tmp;
    var viewLocationDistance = fraction * $this.l35_1.o();
    var zoomFactorDistance = fraction * $this.m35_1.g1r_1;
    var nextViewLocation = $this.l35_1.t1p(viewLocationDistance);
    var nextZoomFactor = $this.m35_1.t1p(zoomFactorDistance);
    if (nextViewLocation == null && nextZoomFactor == null) {
      return null;
    }
    var viewLocation = nextViewLocation == null ? ensureNotNull($this.o35_1).a31_1 : nextViewLocation;
    var zoomFactor = nextZoomFactor == null ? ensureNotNull($this.o35_1).b31_1 : nextZoomFactor;
    return new ZoomedPointTranslation(ensureNotNull($this.o35_1).z30_1, viewLocation, zoomFactor);
  }
  function ZoomedPointVoyage(view, destination) {
    this.l35_1 = new PointRange(view.g25(destination.z30_1), destination.a31_1);
    this.m35_1 = new DoubleRange(view.i24(), destination.b31_1);
    var tmp = this;
    // Inline function 'kotlin.math.abs' call
    var x = this.l35_1.o();
    var tmp_0 = Math.abs(x);
    // Inline function 'kotlin.math.abs' call
    var x_0 = this.m35_1.g1r_1;
    tmp.n35_1 = tmp_0 >= Math.abs(x_0);
    this.o35_1 = new ZoomedPointTranslation(destination.z30_1, view.g25(destination.z30_1), view.i24());
    this.p35_1 = this.n35_1 ? this.l35_1.o() : this.m35_1.g1r_1;
  }
  protoOf(ZoomedPointVoyage).o = function () {
    return this.p35_1;
  };
  protoOf(ZoomedPointVoyage).t1p = function (distance) {
    if (this.p35_1 <= 0 || this.o35_1 == null) {
      return null;
    }
    this.o35_1 = calculateNext(this, distance);
    return this.o35_1;
  };
  //region block: post-declaration
  protoOf(AbstractGraphics2D).m1d = translate;
  protoOf(AbstractGraphics2D).b1w = drawLine;
  protoOf(AbstractGraphics2D).c1w = drawCircle;
  protoOf(AbstractGraphics2D).d1w = fillCircle;
  protoOf(MouseEventJs).t17 = get_isAltDown;
  protoOf(MouseEventJs).u17 = get_isControlDown;
  protoOf(MouseEventJs).v17 = get_isShiftDown;
  protoOf(MouseEventJs).w17 = get_isCtrlDown;
  protoOf(MouseEventJs).x17 = get_isAltGraphDown;
  protoOf(MouseEventJs).y17 = get_isMetaDown;
  protoOf(MouseEventJs).hasModifier = hasModifier;
  defineProp(protoOf(MouseEventJs), 'event', function () {
    return this.o17();
  });
  defineProp(protoOf(MouseEventJs), 'source', function () {
    return this.p17();
  });
  defineProp(protoOf(MouseEventJs), 'modifiers', function () {
    return this.q17();
  });
  defineProp(protoOf(MouseEventJs), 'isAltDown', function () {
    return this.t17();
  });
  defineProp(protoOf(MouseEventJs), 'isControlDown', function () {
    return this.u17();
  });
  defineProp(protoOf(MouseEventJs), 'isShiftDown', function () {
    return this.v17();
  });
  defineProp(protoOf(MouseEventJs), 'isCtrlDown', function () {
    return this.w17();
  });
  defineProp(protoOf(MouseEventJs), 'isAltGraphDown', function () {
    return this.x17();
  });
  defineProp(protoOf(MouseEventJs), 'isMetaDown', function () {
    return this.y17();
  });
  protoOf(KeyEventJs).t17 = get_isAltDown;
  protoOf(KeyEventJs).u17 = get_isControlDown;
  protoOf(KeyEventJs).v17 = get_isShiftDown;
  protoOf(KeyEventJs).w17 = get_isCtrlDown;
  protoOf(KeyEventJs).x17 = get_isAltGraphDown;
  protoOf(KeyEventJs).y17 = get_isMetaDown;
  protoOf(KeyEventJs).hasModifier = hasModifier;
  defineProp(protoOf(KeyEventJs), 'event', function () {
    return this.o17();
  });
  defineProp(protoOf(KeyEventJs), 'source', function () {
    return this.p17();
  });
  defineProp(protoOf(KeyEventJs), 'modifiers', function () {
    return this.q17();
  });
  defineProp(protoOf(KeyEventJs), 'isAltDown', function () {
    return this.t17();
  });
  defineProp(protoOf(KeyEventJs), 'isControlDown', function () {
    return this.u17();
  });
  defineProp(protoOf(KeyEventJs), 'isShiftDown', function () {
    return this.v17();
  });
  defineProp(protoOf(KeyEventJs), 'isCtrlDown', function () {
    return this.w17();
  });
  defineProp(protoOf(KeyEventJs), 'isAltGraphDown', function () {
    return this.x17();
  });
  defineProp(protoOf(KeyEventJs), 'isMetaDown', function () {
    return this.y17();
  });
  protoOf(DrawableBagImpl).b21 = add$default;
  protoOf(DrawableBagImpl).x20 = contains_3;
  protoOf(DrawableBagImpl).go = contains_4;
  protoOf(DrawableBagImpl).d21 = frontToBackIterator;
  protoOf(DrawableBagImpl).f21 = getDrawableAt;
  protoOf(DrawableBagImpl).g21 = getDrawableAt_0;
  protoOf(DrawableBagImpl).i21 = getDrawableAt_1;
  protoOf(DrawableBagImpl).j21 = getDrawableAt_2;
  protoOf(DrawableBagImpl).k21 = getDrawables;
  protoOf(DrawableBagImpl).l21 = getDrawableIntersection;
  protoOf(DrawableBagImpl).m21 = getDrawableIntersection$default;
  protoOf(DrawableBagImpl).n21 = getDrawable;
  protoOf(DrawableBagImpl).y20 = rotateBack;
  protoOf(DrawableBagImpl).o21 = rotateBack_0;
  protoOf(DrawableBagImpl).h21 = rotateBack_1;
  protoOf(AbstractDrawable).po = contains_2;
  protoOf(AbstractDrawable).ro = intersects_0;
  protoOf(DrawableContainerImpl).b21 = add$default;
  protoOf(DrawableContainerImpl).go = contains_5;
  protoOf(DrawableContainerImpl).x20 = contains_3;
  protoOf(DrawableContainerImpl).v21 = moveBy;
  protoOf(DrawableContainerImpl).d21 = frontToBackIterator;
  protoOf(DrawableContainerImpl).e21 = backToFrontIterator;
  protoOf(DrawableContainerImpl).f21 = getDrawableAt;
  protoOf(DrawableContainerImpl).g21 = getDrawableAt_0;
  protoOf(DrawableContainerImpl).i21 = getDrawableAt_1;
  protoOf(DrawableContainerImpl).j21 = getDrawableAt_2;
  protoOf(DrawableContainerImpl).k21 = getDrawables;
  protoOf(DrawableContainerImpl).l21 = getDrawableIntersection;
  protoOf(DrawableContainerImpl).m21 = getDrawableIntersection$default;
  protoOf(DrawableContainerImpl).n21 = getDrawable;
  protoOf(DrawableContainerImpl).y20 = rotateBack;
  protoOf(DrawableContainerImpl).o21 = rotateBack_0;
  protoOf(DrawableContainerImpl).h21 = rotateBack_1;
  protoOf(AbstractRectangle).u1c = get_widthInt;
  protoOf(AbstractRectangle).v1c = get_heightInt;
  protoOf(AbstractRectangle).p1a = get_x;
  protoOf(AbstractRectangle).q1a = get_y;
  protoOf(AbstractRectangle).s1c = get_xInt;
  protoOf(AbstractRectangle).t1c = get_yInt;
  protoOf(AbstractRectangle).g2c = setBounds;
  protoOf(AbstractRectangle).h2c = setBounds_0;
  protoOf(AbstractRectangle).v21 = moveBy;
  protoOf(FlexibleTextView).l2h = applyTo;
  protoOf(FlexibleTextView).v21 = moveBy;
  protoOf(TransparentImpl).l2h = applyTo;
  protoOf(PolylineDrawable).h2r = findSegment$default;
  protoOf(PolylineDrawable).b2r = getFirstPoint;
  protoOf(PolylineDrawable).c2r = getLastPoint;
  protoOf(PolylineDrawable).l2h = applyTo;
  protoOf(PolylineShapeImpl).h2r = findSegment$default;
  protoOf(PolylineShapeImpl).b2r = getFirstPoint;
  protoOf(PolylineShapeImpl).c2r = getLastPoint;
  protoOf(PolylineShapeImpl).p2r = isSegmentOrthogonal;
  protoOf(PolylineShapeImpl).po = contains_0;
  protoOf(PolylineShapeImpl).qo = contains_1;
  protoOf(PolylineShapeImpl).ro = intersects;
  defineProp(protoOf(AbstractContentViewAction), 'requestFocusOnClick', function () {
    return this.wq();
  });
  defineProp(protoOf(AbstractViewAction), 'requestFocusOnClick', function () {
    return this.wq();
  });
  protoOf(ViewImpl).r1x = get_devicePixelRatio;
  protoOf(ViewImpl).d1d = get_center;
  protoOf(ViewImpl).i24 = get_zoomFactor;
  protoOf(ViewNavigatorImpl).b27 = multiplyZoomFactor$default;
  defineProp(protoOf(ZoomPanActions), 'zoomNormalAction', protoOf(ZoomPanActions).e31);
  defineProp(protoOf(ZoomPanActions), 'zoomInAction', protoOf(ZoomPanActions).f31);
  defineProp(protoOf(ZoomPanActions), 'zoomOutAction', protoOf(ZoomPanActions).g31);
  defineProp(protoOf(ZoomPanActions), 'zoomFitAction', protoOf(ZoomPanActions).h31);
  defineProp(protoOf(ZoomPanActions), 'zoomFitMaxNormalAction', protoOf(ZoomPanActions).i31);
  defineProp(protoOf(ZoomPanActions), 'zoomCenterAction', protoOf(ZoomPanActions).j31);
  defineProp(protoOf(AbstractZoomPanAction), 'requestFocusOnClick', function () {
    return this.wq();
  });
  defineProp(protoOf(ZoomInAction), 'requestFocusOnClick', function () {
    return this.wq();
  });
  defineProp(protoOf(ZoomNormalAction), 'requestFocusOnClick', function () {
    return this.wq();
  });
  defineProp(protoOf(ZoomOutAction), 'requestFocusOnClick', function () {
    return this.wq();
  });
  defineProp(protoOf(ZoomFitAction), 'requestFocusOnClick', function () {
    return this.wq();
  });
  defineProp(protoOf(ZoomFitMaxNormalAction), 'requestFocusOnClick', function () {
    return this.wq();
  });
  defineProp(protoOf(ZoomCenterAction), 'requestFocusOnClick', function () {
    return this.wq();
  });
  //endregion
  //region block: init
  Companion_instance_3 = new Companion();
  PolylineShapeFactory_instance = new PolylineShapeFactory();
  Companion_instance_5 = new Companion_1();
  FocusManager_instance = new FocusManager();
  Companion_instance_8 = new Companion_4();
  Companion_instance_9 = new Companion_5();
  IdentityViewToModelTransform_instance = new IdentityViewToModelTransform();
  Companion_instance_11 = new Companion_7();
  Companion_instance_13 = new Companion_9();
  ArrowBubblePositioner_instance = new ArrowBubblePositioner();
  DrawableAttendantPositioner_instance = new DrawableAttendantPositioner();
  Companion_instance_15 = new Companion_11();
  Companion_instance_16 = new Companion_12();
  Companion_instance_18 = new Companion_14();
  Companion_instance_19 = new Companion_15();
  Companion_instance_23 = new Companion_19();
  Companion_instance_24 = new Companion_20();
  DropShadow_instance = new DropShadow();
  Companion_instance_25 = new Companion_21();
  Companion_instance_26 = new Companion_22();
  Companion_instance_27 = new Companion_23();
  Companion_instance_28 = new Companion_24();
  TextRenderInfoFactory_instance = new TextRenderInfoFactory();
  Companion_instance_31 = new Companion_27();
  Companion_instance_32 = new Companion_28();
  Companion_instance_36 = new Companion_32();
  Companion_instance_37 = new Companion_33();
  Companion_instance_38 = new Companion_34();
  Companion_instance_39 = new Companion_35();
  Companion_instance_40 = new Companion_36();
  Companion_instance_42 = new Companion_38();
  ZoomPanActions_instance = new ZoomPanActions();
  Companion_instance_43 = new Companion_39();
  //endregion
  //region block: exports
  function $jsExportAll$(_) {
    var io = _.io || (_.io = {});
    var antarescircuit = io.antarescircuit || (io.antarescircuit = {});
    var jabbah = antarescircuit.jabbah || (antarescircuit.jabbah = {});
    var draw = jabbah.draw || (jabbah.draw = {});
    var view = draw.view || (draw.view = {});
    defineProp(view, 'ZoomPanActions', ZoomPanActions_getInstance, VOID, true);
  }
  $jsExportAll$(_);
  _.$jsExportAll$ = $jsExportAll$;
  _.$_$ = _.$_$ || {};
  _.$_$.a = DrawableAttendantPositioner_instance;
  _.$_$.b = Companion_instance_16;
  _.$_$.c = Companion_getInstance_15;
  _.$_$.d = SynchronizedGlowAnimation_getInstance;
  _.$_$.e = Companion_instance_19;
  _.$_$.f = Companion_getInstance_18;
  _.$_$.g = Companion_getInstance_20;
  _.$_$.h = Companion_instance_23;
  _.$_$.i = DrawGraphicsModule_getInstance;
  _.$_$.j = DropShadow_instance;
  _.$_$.k = Companion_instance_26;
  _.$_$.l = ReferenceColorSequenceProvider_getInstance;
  _.$_$.m = TextRenderInfoFactory_instance;
  _.$_$.n = DrawModule_getInstance;
  _.$_$.o = Companion_getInstance_27;
  _.$_$.p = Companion_getInstance_28;
  _.$_$.q = Companion_instance_31;
  _.$_$.r = PolylineShapeFactory_instance;
  _.$_$.s = DrawStyleModule_getInstance;
  _.$_$.t = Companion_getInstance_31;
  _.$_$.u = Companion_getInstance_32;
  _.$_$.v = Companion_getInstance_33;
  _.$_$.w = Themes_getInstance;
  _.$_$.x = CurrentPanMethod_getInstance;
  _.$_$.y = DrawViewModule_getInstance;
  _.$_$.z = FocusManager_instance;
  _.$_$.a1 = Companion_getInstance_5;
  _.$_$.b1 = Companion_getInstance_8;
  _.$_$.c1 = DrawModuleJs_getInstance;
  _.$_$.d1 = Cursor_CLICK_getInstance;
  _.$_$.e1 = Cursor_CROSSHAIR_getInstance;
  _.$_$.f1 = Cursor_DEFAULT_getInstance;
  _.$_$.g1 = Cursor_E_RESIZE_getInstance;
  _.$_$.h1 = Cursor_MOVE_getInstance;
  _.$_$.i1 = Cursor_NE_RESIZE_getInstance;
  _.$_$.j1 = Cursor_NW_RESIZE_getInstance;
  _.$_$.k1 = Cursor_N_RESIZE_getInstance;
  _.$_$.l1 = Cursor_SE_RESIZE_getInstance;
  _.$_$.m1 = Cursor_SW_RESIZE_getInstance;
  _.$_$.n1 = Cursor_S_RESIZE_getInstance;
  _.$_$.o1 = Cursor_W_RESIZE_getInstance;
  _.$_$.p1 = FontStyle_PLAIN_getInstance;
  _.$_$.q1 = ImageType_SVG_getInstance;
  _.$_$.r1 = LineCap_BUTT_getInstance;
  _.$_$.s1 = LineCap_ROUND_getInstance;
  _.$_$.t1 = LineCap_SQUARE_getInstance;
  _.$_$.u1 = LineJoin_MITER_getInstance;
  _.$_$.v1 = LineJoin_ROUND_getInstance;
  _.$_$.w1 = LogicalFontFamily_DIALOG_getInstance;
  _.$_$.x1 = LogicalFontFamily_MONOSPACED_getInstance;
  _.$_$.y1 = LogicalFontFamily_SANS_SERIF_getInstance;
  _.$_$.z1 = PredefinedColorIdentity_Black_getInstance;
  _.$_$.a2 = PredefinedColorIdentity_Blue_getInstance;
  _.$_$.b2 = PredefinedColorIdentity_Brown_getInstance;
  _.$_$.c2 = PredefinedColorIdentity_Gray_getInstance;
  _.$_$.d2 = PredefinedColorIdentity_Green_getInstance;
  _.$_$.e2 = PredefinedColorIdentity_Red_getInstance;
  _.$_$.f2 = PredefinedColorIdentity_Turquoise_getInstance;
  _.$_$.g2 = PredefinedColorIdentity_Violet_getInstance;
  _.$_$.h2 = PredefinedColorIdentity_White_getInstance;
  _.$_$.i2 = PredefinedColorIdentity_Yellow_getInstance;
  _.$_$.j2 = ZoomStrategyType_VALUE_getInstance;
  _.$_$.k2 = findSegment$default;
  _.$_$.l2 = AbstractRectangle_init_$Init$;
  _.$_$.m2 = AbstractRectangle_init_$Init$_0;
  _.$_$.n2 = AbstractStyledDrawable_init_$Init$;
  _.$_$.o2 = DrawableButton_init_$Create$;
  _.$_$.p2 = Color_init_$Create$;
  _.$_$.q2 = DrawableBagImpl;
  _.$_$.r2 = DrawableBagInputEventHandler;
  _.$_$.s2 = DrawableContainerAdapter;
  _.$_$.t2 = DrawableContainerDrawer;
  _.$_$.u2 = DrawableContainerImpl;
  _.$_$.v2 = DrawableGeometryProperty;
  _.$_$.w2 = DrawableProperty;
  _.$_$.x2 = UnzoomableContainer;
  _.$_$.y2 = DrawableOwner;
  _.$_$.z2 = AbstractDrawableButtonRenderer;
  _.$_$.a3 = AbstractDrawableDrawer;
  _.$_$.b3 = AbstractDrawable;
  _.$_$.c3 = AbstractRectangle;
  _.$_$.d3 = AbstractRectangularUnzoomable;
  _.$_$.e3 = AbstractStyledDrawable;
  _.$_$.f3 = ButtonAction;
  _.$_$.g3 = Colorable;
  _.$_$.h3 = EditInteractionHandler;
  _.$_$.i3 = DrawableButton;
  _.$_$.j3 = DrawableDrawer;
  _.$_$.k3 = FlexibleTextView;
  _.$_$.l3 = IconDrawableButtonRenderer;
  _.$_$.m3 = moveBy;
  _.$_$.n3 = Locatable;
  _.$_$.o3 = get_canMirror;
  _.$_$.p3 = Mirrorable;
  _.$_$.q3 = completeMoveBy;
  _.$_$.r3 = prepareMoveBy;
  _.$_$.s3 = Movable;
  _.$_$.t3 = MoveLocatableAnimation;
  _.$_$.u3 = get_orientation;
  _.$_$.v3 = set_orientation;
  _.$_$.w3 = Orientable;
  _.$_$.x3 = get_heightInt;
  _.$_$.y3 = setBounds;
  _.$_$.z3 = setBounds_0;
  _.$_$.a4 = get_widthInt;
  _.$_$.b4 = get_x;
  _.$_$.c4 = get_xInt;
  _.$_$.d4 = get_y;
  _.$_$.e4 = get_yInt;
  _.$_$.f4 = RectangularDrawable;
  _.$_$.g4 = ShakeLocatableAnimation;
  _.$_$.h4 = applyTo;
  _.$_$.i4 = TransparentImpl;
  _.$_$.j4 = Transparent;
  _.$_$.k4 = Unzoomable;
  _.$_$.l4 = AddIcon;
  _.$_$.m4 = ColorGradient;
  _.$_$.n4 = Color;
  _.$_$.o4 = CompositeColorGradient;
  _.$_$.p4 = CompositeColor;
  _.$_$.q4 = DeleteIcon;
  _.$_$.r4 = EmbeddedImageJs;
  _.$_$.s4 = FontImpl;
  _.$_$.t4 = draw;
  _.$_$.u4 = Icon;
  _.$_$.v4 = KnobIcon;
  _.$_$.w4 = LinearColorGradient;
  _.$_$.x4 = PredefinedColor;
  _.$_$.y4 = RadialColorGradientCache;
  _.$_$.z4 = ReferenceColor;
  _.$_$.a5 = RemoveIcon;
  _.$_$.b5 = Stroke;
  _.$_$.c5 = ArrowHead;
  _.$_$.d5 = PolylineDrawable;
  _.$_$.e5 = Polyline;
  _.$_$.f5 = BasicStyle;
  _.$_$.g5 = DrawTheme;
  _.$_$.h5 = StylableImpl;
  _.$_$.i5 = Stylable;
  _.$_$.j5 = StyleType;
  _.$_$.k5 = CanvasJs;
  _.$_$.l5 = InvalidatableViewPainter;
  _.$_$.m5 = TooltipHandler;
  _.$_$.n5 = ViewImpl;
  _.$_$.o5 = ZoomedPointTranslation;
  _.$_$.p5 = ZoomedPointVoyageAnimation;
  _.$_$.q5 = buildToolTipText;
  _.$_$.r5 = ApplicationContextHolder;
  _.$_$.s5 = CloseViewRequest;
  _.$_$.t5 = DrawContext;
  _.$_$.u5 = DrawableAdapter;
  _.$_$.v5 = DrawableContainerListener;
  _.$_$.w5 = DrawableContainer;
  _.$_$.x5 = DrawableExplanation;
  _.$_$.y5 = Drawable;
  _.$_$.z5 = focusGained;
  _.$_$.a6 = focusLost;
  _.$_$.b6 = get_isFocusOwner;
  _.$_$.c6 = requestFocus;
  _.$_$.d6 = Focusable;
  _.$_$.e6 = InputEventContext;
  _.$_$.f6 = InputEventHandlerAdapter;
  _.$_$.g6 = InputEventHandler;
  _.$_$.h6 = StateMachineInputEventHandler;
  _.$_$.i6 = ViewContentBounds;
  _.$_$.j6 = ViewTransformation;
  _.$_$.k6 = View;
  _.$_$.l6 = ZoomStrategy;
  //endregion
  return _;
}));

//# sourceMappingURL=jabbah-draw.js.map
