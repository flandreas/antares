(function (factory) {
  if (typeof define === 'function' && define.amd)
    define(['exports', './kotlin-kotlin-stdlib.js', './jabbah-base.js', './jabbah-animation.js'], factory);
  else if (typeof exports === 'object')
    factory(module.exports, require('./kotlin-kotlin-stdlib.js'), require('./jabbah-base.js'), require('./jabbah-animation.js'));
  else {
    if (typeof globalThis['kotlin-kotlin-stdlib'] === 'undefined') {
      throw new Error("Error loading module 'jabbah-draw'. Its dependency 'kotlin-kotlin-stdlib' was not found. Please, check whether 'kotlin-kotlin-stdlib' is loaded prior to 'jabbah-draw'.");
    }
    if (typeof globalThis['jabbah-base'] === 'undefined') {
      throw new Error("Error loading module 'jabbah-draw'. Its dependency 'jabbah-base' was not found. Please, check whether 'jabbah-base' is loaded prior to 'jabbah-draw'.");
    }
    if (typeof globalThis['jabbah-animation'] === 'undefined') {
      throw new Error("Error loading module 'jabbah-draw'. Its dependency 'jabbah-animation' was not found. Please, check whether 'jabbah-animation' is loaded prior to 'jabbah-draw'.");
    }
    globalThis['jabbah-draw'] = factory(typeof globalThis['jabbah-draw'] === 'undefined' ? {} : globalThis['jabbah-draw'], globalThis['kotlin-kotlin-stdlib'], globalThis['jabbah-base'], globalThis['jabbah-animation']);
  }
}(function (_, kotlin_kotlin, kotlin_jabbah_base, kotlin_jabbah_animation) {
  'use strict';
  //region block: imports
  var imul = Math.imul;
  var Unit_instance = kotlin_kotlin.$_$.i;
  var protoOf = kotlin_kotlin.$_$.t7;
  var initMetadataForClass = kotlin_kotlin.$_$.d7;
  var StringBuilder_init_$Create$ = kotlin_kotlin.$_$.v;
  var initMetadataForCompanion = kotlin_kotlin.$_$.e7;
  var toString = kotlin_kotlin.$_$.v7;
  var IllegalArgumentException_init_$Create$ = kotlin_kotlin.$_$.b1;
  var equals = kotlin_kotlin.$_$.u6;
  var noWhenBranchMatchedException = kotlin_kotlin.$_$.pb;
  var toFloatArray = kotlin_kotlin.$_$.q4;
  var toTypedArray = kotlin_kotlin.$_$.x4;
  var Rectangle2D = kotlin_jabbah_base.$_$.f6;
  var VOID = kotlin_kotlin.$_$.b;
  var AffineTransformImpl = kotlin_jabbah_base.$_$.y5;
  var Companion_getInstance = kotlin_jabbah_base.$_$.h;
  var THROW_CCE = kotlin_kotlin.$_$.db;
  var AffineTransformImpl_init_$Create$ = kotlin_jabbah_base.$_$.n3;
  var Path2DJs = kotlin_jabbah_base.$_$.d6;
  var Rectangle2D_init_$Create$ = kotlin_jabbah_base.$_$.t3;
  var getKClassFromExpression = kotlin_kotlin.$_$.p8;
  var initMetadataForObject = kotlin_kotlin.$_$.i7;
  var MouseEventType_CLICKED_getInstance = kotlin_jabbah_base.$_$.k2;
  var MouseEventType_PRESSED_getInstance = kotlin_jabbah_base.$_$.p2;
  var MouseEventType_RELEASED_getInstance = kotlin_jabbah_base.$_$.q2;
  var MouseEventType_ENTERED_getInstance = kotlin_jabbah_base.$_$.m2;
  var MouseEventType_EXITED_getInstance = kotlin_jabbah_base.$_$.n2;
  var MouseEventType_MOVED_getInstance = kotlin_jabbah_base.$_$.o2;
  var MouseEventType_DRAGGED_getInstance = kotlin_jabbah_base.$_$.l2;
  var MouseEventType_WHEEL_ROTATED_getInstance = kotlin_jabbah_base.$_$.s2;
  var MouseEventType_UNKNOWN_getInstance = kotlin_jabbah_base.$_$.r2;
  var Button_BUTTON1_getInstance = kotlin_jabbah_base.$_$.z1;
  var Button_BUTTON2_getInstance = kotlin_jabbah_base.$_$.a2;
  var Button_BUTTON3_getInstance = kotlin_jabbah_base.$_$.b2;
  var Button_NONE_getInstance = kotlin_jabbah_base.$_$.c2;
  var Modifier_Shift_getInstance = kotlin_jabbah_base.$_$.j2;
  var Modifier_Ctrl_getInstance = kotlin_jabbah_base.$_$.h2;
  var Modifier_Meta_getInstance = kotlin_jabbah_base.$_$.i2;
  var Modifier_Alt_getInstance = kotlin_jabbah_base.$_$.g2;
  var numberToInt = kotlin_kotlin.$_$.r7;
  var Point2D_init_$Create$ = kotlin_jabbah_base.$_$.r3;
  var get_isAltDown = kotlin_jabbah_base.$_$.h5;
  var get_isControlDown = kotlin_jabbah_base.$_$.j5;
  var get_isShiftDown = kotlin_jabbah_base.$_$.m5;
  var get_isCtrlDown = kotlin_jabbah_base.$_$.k5;
  var get_isAltGraphDown = kotlin_jabbah_base.$_$.i5;
  var get_isMetaDown = kotlin_jabbah_base.$_$.l5;
  var hasModifier = kotlin_jabbah_base.$_$.g5;
  var defineProp = kotlin_kotlin.$_$.t6;
  var MouseEvent_0 = kotlin_jabbah_base.$_$.s5;
  var KeyEventType_PRESSED_getInstance = kotlin_jabbah_base.$_$.d2;
  var KeyEventType_RELEASED_getInstance = kotlin_jabbah_base.$_$.e2;
  var KeyEventType_TYPED_getInstance = kotlin_jabbah_base.$_$.f2;
  var numberToChar = kotlin_kotlin.$_$.q7;
  var InputEvent = kotlin_jabbah_base.$_$.n5;
  var Companion_instance = kotlin_jabbah_base.$_$.e;
  var to = kotlin_kotlin.$_$.tb;
  var mapOf = kotlin_kotlin.$_$.v3;
  var KProperty1 = kotlin_kotlin.$_$.t8;
  var getPropertyCallableRef = kotlin_kotlin.$_$.a7;
  var getKClass = kotlin_kotlin.$_$.q8;
  var logger = kotlin_jabbah_base.$_$.q7;
  var throwUninitializedPropertyAccessException = kotlin_kotlin.$_$.t5;
  var ArrayList_init_$Create$ = kotlin_kotlin.$_$.n;
  var PropertyOwnerImpl = kotlin_jabbah_base.$_$.v5;
  var ensureNotNull = kotlin_kotlin.$_$.kb;
  var lazy = kotlin_kotlin.$_$.ob;
  var Throttle = kotlin_jabbah_base.$_$.b7;
  var Dimension2D_init_$Create$ = kotlin_jabbah_base.$_$.o3;
  var UnsupportedOperationException_init_$Create$ = kotlin_kotlin.$_$.m1;
  var AbstractModule = kotlin_jabbah_base.$_$.d7;
  var BaseModuleJs_getInstance = kotlin_jabbah_base.$_$.m;
  var BaseModule_getInstance = kotlin_jabbah_base.$_$.n;
  var hashCode = kotlin_kotlin.$_$.c7;
  var PropertiesProxy = kotlin_jabbah_base.$_$.l7;
  var Disposable = kotlin_jabbah_base.$_$.f7;
  var initMetadataForInterface = kotlin_kotlin.$_$.g7;
  var contains = kotlin_kotlin.$_$.t2;
  var Collection = kotlin_kotlin.$_$.g2;
  var isInterface = kotlin_kotlin.$_$.m7;
  var toImmutableList = kotlin_jabbah_base.$_$.f4;
  var objectCreate = kotlin_kotlin.$_$.s7;
  var Point2D = kotlin_jabbah_base.$_$.e6;
  var UnhandledEventBehaviour_Strict_getInstance = kotlin_jabbah_base.$_$.c3;
  var System_getInstance = kotlin_jabbah_base.$_$.c1;
  var RectangularShape = kotlin_jabbah_base.$_$.g6;
  var FunctionAdapter = kotlin_kotlin.$_$.k6;
  var PropertyChangeListener = kotlin_jabbah_base.$_$.t5;
  var getNumberHashCode = kotlin_kotlin.$_$.y6;
  var Enum = kotlin_kotlin.$_$.va;
  var Rotation_R0_getInstance = kotlin_jabbah_base.$_$.x2;
  var MutableCollection = kotlin_kotlin.$_$.j2;
  var asReversed = kotlin_kotlin.$_$.o2;
  var getBooleanHashCode = kotlin_kotlin.$_$.x6;
  var coerceAtLeast = kotlin_kotlin.$_$.d8;
  var coerceAtMost = kotlin_kotlin.$_$.e8;
  var Rectangle2D_init_$Create$_0 = kotlin_jabbah_base.$_$.s3;
  var RoundRectangle2D_init_$Create$ = kotlin_jabbah_base.$_$.v3;
  var Translations_getInstance = kotlin_jabbah_base.$_$.d1;
  var Companion_instance_0 = kotlin_jabbah_base.$_$.i;
  var Tooltip = kotlin_jabbah_base.$_$.n7;
  var AbstractAnimationTask = kotlin_jabbah_animation.$_$.b;
  var Companion_getInstance_0 = kotlin_jabbah_base.$_$.f;
  var Companion_instance_1 = kotlin_jabbah_base.$_$.p;
  var addAll = kotlin_kotlin.$_$.n2;
  var _Char___init__impl__6a9atx = kotlin_kotlin.$_$.n1;
  var charArrayOf = kotlin_kotlin.$_$.o6;
  var split = kotlin_kotlin.$_$.w9;
  var checkIndexOverflow = kotlin_kotlin.$_$.r2;
  var RichTextParser_init_$Create$ = kotlin_jabbah_base.$_$.x3;
  var SyntaxError = kotlin_jabbah_base.$_$.z4;
  var PointRange = kotlin_jabbah_animation.$_$.h;
  var copyToArray = kotlin_kotlin.$_$.a3;
  var CompositeSequence = kotlin_jabbah_animation.$_$.e;
  var DoubleRange = kotlin_jabbah_animation.$_$.f;
  var Oscillation = kotlin_jabbah_animation.$_$.g;
  var AnimationModule_getInstance = kotlin_jabbah_animation.$_$.a;
  var AnimationTaskAdapter = kotlin_jabbah_animation.$_$.c;
  var Ring2D = kotlin_jabbah_base.$_$.h6;
  var Ellipse2D = kotlin_jabbah_base.$_$.b6;
  var RoundRectangle2D = kotlin_jabbah_base.$_$.i6;
  var round = kotlin_kotlin.$_$.y7;
  var numberRangeToNumber = kotlin_kotlin.$_$.o7;
  var coerceIn = kotlin_kotlin.$_$.g8;
  var roundToInt = kotlin_kotlin.$_$.x7;
  var rangeTo = kotlin_kotlin.$_$.k8;
  var coerceIn_0 = kotlin_kotlin.$_$.h8;
  var until = kotlin_kotlin.$_$.o8;
  var collectionSizeOrDefault = kotlin_kotlin.$_$.s2;
  var ArrayList_init_$Create$_0 = kotlin_kotlin.$_$.m;
  var toList = kotlin_kotlin.$_$.s4;
  var Geometry_instance = kotlin_jabbah_base.$_$.g;
  var enumEntries = kotlin_kotlin.$_$.s5;
  var NoSuchElementException_init_$Create$ = kotlin_kotlin.$_$.h1;
  var LinkedHashMap_init_$Create$ = kotlin_kotlin.$_$.q;
  var indexOf = kotlin_kotlin.$_$.k3;
  var get_indices = kotlin_kotlin.$_$.m3;
  var compareTo = kotlin_kotlin.$_$.s6;
  var Comparable = kotlin_kotlin.$_$.ta;
  var minOrNull = kotlin_kotlin.$_$.x3;
  var IllegalStateException_init_$Create$ = kotlin_kotlin.$_$.d1;
  var contentEquals = kotlin_kotlin.$_$.x2;
  var contentHashCode = kotlin_kotlin.$_$.z2;
  var UnsupportedOperationException_init_$Create$_0 = kotlin_kotlin.$_$.l1;
  var checkCountOverflow = kotlin_kotlin.$_$.q2;
  var rangeTo_0 = kotlin_kotlin.$_$.l8;
  var Shape = kotlin_jabbah_base.$_$.m6;
  var last = kotlin_kotlin.$_$.r3;
  var Point2D_init_$Create$_0 = kotlin_jabbah_base.$_$.q3;
  var contains_0 = kotlin_jabbah_base.$_$.j6;
  var contains_1 = kotlin_jabbah_base.$_$.k6;
  var intersects = kotlin_jabbah_base.$_$.l6;
  var listOf = kotlin_kotlin.$_$.t3;
  var resettableLazy = kotlin_jabbah_base.$_$.r7;
  var mutableListOf = kotlin_kotlin.$_$.y3;
  var addAll_0 = kotlin_kotlin.$_$.m2;
  var first = kotlin_kotlin.$_$.h3;
  var AbstractAction = kotlin_jabbah_base.$_$.c7;
  var AbstractAction_init_$Init$ = kotlin_jabbah_base.$_$.y3;
  var Vector2D = kotlin_jabbah_base.$_$.n6;
  var MouseAdapter = kotlin_jabbah_base.$_$.q5;
  var MouseEventImpl = kotlin_jabbah_base.$_$.r5;
  var toString_0 = kotlin_kotlin.$_$.rb;
  var KeyAdapter = kotlin_jabbah_base.$_$.o5;
  var subtract = kotlin_kotlin.$_$.i6;
  var PreferencesChangedEvent = kotlin_jabbah_base.$_$.k7;
  var StringUtils_getInstance = kotlin_jabbah_base.$_$.b1;
  var startsWith = kotlin_kotlin.$_$.z9;
  var Companion_instance_2 = kotlin_jabbah_base.$_$.q;
  var endsWith = kotlin_kotlin.$_$.f9;
  var charSequenceLength = kotlin_kotlin.$_$.r6;
  var PropertyChangeSupport = kotlin_jabbah_base.$_$.u5;
  var KProperty0 = kotlin_kotlin.$_$.s8;
  var maxOrNull = kotlin_kotlin.$_$.w3;
  var Rectangle2D_init_$Create$_1 = kotlin_jabbah_base.$_$.u3;
  var near = kotlin_jabbah_base.$_$.s6;
  //endregion
  //region block: pre-declaration
  initMetadataForClass(EmbeddedImageJs, 'EmbeddedImageJs');
  initMetadataForCompanion(Companion);
  function translate(p) {
    return this.v1c(p.in_1, p.jn_1);
  }
  function drawLine(p1, p2) {
    return this.d1u(p1.in_1, p1.jn_1, p2.in_1, p2.jn_1);
  }
  function drawCircle(x, y, r) {
    this.m1u(x - r, y - r, 2 * r, 2 * r);
  }
  function fillCircle(x, y, r) {
    this.p1u(x - r, y - r, 2 * r, 2 * r);
  }
  initMetadataForInterface(Graphics2D, 'Graphics2D');
  initMetadataForClass(AbstractGraphics2D, 'AbstractGraphics2D', VOID, VOID, [Graphics2D]);
  initMetadataForClass(Graphics2DJs, 'Graphics2DJs', VOID, AbstractGraphics2D);
  initMetadataForObject(TextRenderInfoFactoryImpl, 'TextRenderInfoFactoryImpl');
  initMetadataForObject(PolylineShapeFactory, 'PolylineShapeFactory');
  initMetadataForClass(MouseEventBridge, 'MouseEventBridge');
  initMetadataForClass(MouseMotionEventBridge, 'MouseMotionEventBridge');
  initMetadataForClass(MouseWheelEventBridge, 'MouseWheelEventBridge');
  initMetadataForClass(KeyEventBridge, 'KeyEventBridge');
  initMetadataForClass(MouseEventJs, 'MouseEventJs', VOID, VOID, [MouseEvent_0]);
  initMetadataForClass(KeyEventJs, 'KeyEventJs', VOID, VOID, [InputEvent]);
  initMetadataForCompanion(Companion_0);
  initMetadataForClass(CanvasJs, 'CanvasJs');
  initMetadataForObject(DrawModuleJs, 'DrawModuleJs', VOID, AbstractModule);
  initMetadataForCompanion(Companion_1);
  initMetadataForClass(ApplicationContextHolder, 'ApplicationContextHolder', ApplicationContextHolder);
  initMetadataForClass(PopupMenuEvent, 'PopupMenuEvent');
  initMetadataForClass(DrawContext, 'DrawContext');
  initMetadataForClass(DrawProperties, 'DrawProperties', DrawProperties, PropertiesProxy);
  function contains_2(p) {
    return this.eo(p.in_1, p.jn_1);
  }
  function intersects_0(rect) {
    return this.do().po(rect);
  }
  initMetadataForInterface(Drawable, 'Drawable', VOID, VOID, [Disposable]);
  initMetadataForClass(DrawableExplanation, 'DrawableExplanation');
  initMetadataForClass(DrawableBag$backToFrontIterator$1);
  function contains_3(drawable) {
    return contains(this.e20(), drawable);
  }
  function contains_4(x, y) {
    if (this.d20()) {
      var location = this.i20(x, y).t1g(this.hw());
      var tmp0 = this.e20();
      var tmp$ret$0;
      $l$block_0: {
        // Inline function 'kotlin.collections.any' call
        var tmp;
        if (isInterface(tmp0, Collection)) {
          tmp = tmp0.m();
        } else {
          tmp = false;
        }
        if (tmp) {
          tmp$ret$0 = false;
          break $l$block_0;
        }
        var _iterator__ex2g4s = tmp0.i();
        while (_iterator__ex2g4s.j()) {
          var element = _iterator__ex2g4s.k();
          if (element.n1z() && element.no(location)) {
            tmp$ret$0 = true;
            break $l$block_0;
          }
        }
        tmp$ret$0 = false;
      }
      return tmp$ret$0;
    }
    var tmp0_0 = this.e20();
    var tmp$ret$2;
    $l$block_2: {
      // Inline function 'kotlin.collections.any' call
      var tmp_0;
      if (isInterface(tmp0_0, Collection)) {
        tmp_0 = tmp0_0.m();
      } else {
        tmp_0 = false;
      }
      if (tmp_0) {
        tmp$ret$2 = false;
        break $l$block_2;
      }
      var _iterator__ex2g4s_0 = tmp0_0.i();
      while (_iterator__ex2g4s_0.j()) {
        var element_0 = _iterator__ex2g4s_0.k();
        if (element_0.n1z() && element_0.no(this.i20(x, y))) {
          tmp$ret$2 = true;
          break $l$block_2;
        }
      }
      tmp$ret$2 = false;
    }
    return tmp$ret$2;
  }
  function add$default(drawable, index, $super) {
    index = index === VOID ? 0 : index;
    return $super === VOID ? this.k20(drawable, index) : $super.k20.call(this, drawable, index);
  }
  function frontToBackIterator() {
    return this.e20().i();
  }
  function backToFrontIterator() {
    var iter = this.e20().v1(this.e20().o());
    return new DrawableBag$backToFrontIterator$1(iter);
  }
  function getDrawableAt(x, y, predicate) {
    if (this.d20()) {
      var p = this.i20(x, y).t1g(this.hw());
      var tmp0 = this.e20();
      var tmp$ret$0;
      $l$block: {
        // Inline function 'kotlin.collections.firstOrNull' call
        var _iterator__ex2g4s = tmp0.i();
        while (_iterator__ex2g4s.j()) {
          var element = _iterator__ex2g4s.k();
          if (element.n1z() && predicate(element) && element.no(p)) {
            tmp$ret$0 = element;
            break $l$block;
          }
        }
        tmp$ret$0 = null;
      }
      return tmp$ret$0;
    }
    var p_0 = this.i20(x, y);
    var tmp0_0 = this.e20();
    var tmp$ret$2;
    $l$block_0: {
      // Inline function 'kotlin.collections.firstOrNull' call
      var _iterator__ex2g4s_0 = tmp0_0.i();
      while (_iterator__ex2g4s_0.j()) {
        var element_0 = _iterator__ex2g4s_0.k();
        if (element_0.n1z() && predicate(element_0) && element_0.no(p_0)) {
          tmp$ret$2 = element_0;
          break $l$block_0;
        }
      }
      tmp$ret$2 = null;
    }
    return tmp$ret$2;
  }
  function getDrawableAt_0(rect, predicate) {
    if (this.d20()) {
      var r = this.r20(rect).v1b(this.hw().m1g());
      var tmp0 = this.e20();
      var tmp$ret$0;
      $l$block: {
        // Inline function 'kotlin.collections.firstOrNull' call
        var _iterator__ex2g4s = tmp0.i();
        while (_iterator__ex2g4s.j()) {
          var element = _iterator__ex2g4s.k();
          if (element.n1z() && predicate(element) && element.po(r)) {
            tmp$ret$0 = element;
            break $l$block;
          }
        }
        tmp$ret$0 = null;
      }
      return tmp$ret$0;
    }
    var r_0 = this.r20(rect);
    var tmp0_0 = this.e20();
    var tmp$ret$2;
    $l$block_0: {
      // Inline function 'kotlin.collections.firstOrNull' call
      var _iterator__ex2g4s_0 = tmp0_0.i();
      while (_iterator__ex2g4s_0.j()) {
        var element_0 = _iterator__ex2g4s_0.k();
        if (element_0.n1z() && predicate(element_0) && element_0.po(r_0)) {
          tmp$ret$2 = element_0;
          break $l$block_0;
        }
      }
      tmp$ret$2 = null;
    }
    return tmp$ret$2;
  }
  function getDrawableAt_1(x, y) {
    return this.p20(x, y, DrawableBag$getDrawableAt$lambda);
  }
  function getDrawableAt_2(location) {
    return this.p20(location.in_1, location.jn_1, DrawableBag$getDrawableAt$lambda_0);
  }
  function getDrawables(predicate) {
    // Inline function 'kotlin.collections.filter' call
    var tmp0 = this.e20();
    // Inline function 'kotlin.collections.filterTo' call
    var destination = ArrayList_init_$Create$();
    var _iterator__ex2g4s = tmp0.i();
    while (_iterator__ex2g4s.j()) {
      var element = _iterator__ex2g4s.k();
      if (predicate(element)) {
        destination.h(element);
      }
    }
    return toImmutableList(destination);
  }
  function getDrawableIntersection(drawable, predicate) {
    if (this.d20()) {
      var r = this.r20(drawable.do()).v1b(this.hw().m1g());
      // Inline function 'kotlin.collections.filter' call
      var tmp0 = this.e20();
      // Inline function 'kotlin.collections.filterTo' call
      var destination = ArrayList_init_$Create$();
      var _iterator__ex2g4s = tmp0.i();
      while (_iterator__ex2g4s.j()) {
        var element = _iterator__ex2g4s.k();
        if (!(element === drawable) && element.n1z() && predicate(element) && element.po(r)) {
          destination.h(element);
        }
      }
      return destination;
    }
    var r_0 = this.r20(drawable.do());
    // Inline function 'kotlin.collections.filter' call
    var tmp0_0 = this.e20();
    // Inline function 'kotlin.collections.filterTo' call
    var destination_0 = ArrayList_init_$Create$();
    var _iterator__ex2g4s_0 = tmp0_0.i();
    while (_iterator__ex2g4s_0.j()) {
      var element_0 = _iterator__ex2g4s_0.k();
      if (!(element_0 === drawable) && element_0.n1z() && predicate(element_0) && element_0.po(r_0)) {
        destination_0.h(element_0);
      }
    }
    return destination_0;
  }
  function getDrawableIntersection$default(drawable, predicate, $super) {
    var tmp;
    if (predicate === VOID) {
      tmp = DrawableBag$getDrawableIntersection$lambda;
    } else {
      tmp = predicate;
    }
    predicate = tmp;
    return $super === VOID ? this.v20(drawable, predicate) : getDrawableIntersection(drawable, predicate);
  }
  function getDrawable(predicate) {
    var tmp0 = this.e20();
    var tmp$ret$0;
    $l$block: {
      // Inline function 'kotlin.collections.firstOrNull' call
      var _iterator__ex2g4s = tmp0.i();
      while (_iterator__ex2g4s.j()) {
        var element = _iterator__ex2g4s.k();
        if (predicate(element)) {
          tmp$ret$0 = element;
          break $l$block;
        }
      }
      tmp$ret$0 = null;
    }
    return tmp$ret$0;
  }
  function rotateBack(x, y) {
    return this.g20().u1h().x1h(this.hw(), x, y);
  }
  function rotateBack_0(pos) {
    return this.i20(pos.in_1, pos.jn_1);
  }
  function rotateBack_1(rect) {
    return this.g20().u1h().z1h(this.hw(), rect);
  }
  initMetadataForInterface(DrawableBag, 'DrawableBag');
  function moveBy(dx, dy) {
    this.f20(this.hw().tn(dx, dy));
  }
  initMetadataForInterface(Locatable, 'Locatable', VOID, VOID, [Drawable]);
  function contains_5(x, y) {
    return contains_4.call(this, x, y);
  }
  initMetadataForInterface(DrawableContainer, 'DrawableContainer', VOID, VOID, [Locatable, DrawableBag]);
  initMetadataForClass(DrawableContainerEvent, 'DrawableContainerEvent');
  initMetadataForInterface(DrawableContainerListener, 'DrawableContainerListener');
  initMetadataForClass(DrawableEvent, 'DrawableEvent');
  initMetadataForClass(DrawableAdapter, 'DrawableAdapter', DrawableAdapter);
  function get_isFocusOwner() {
    return FocusManager_instance.r21_1 === this;
  }
  function requestFocus() {
    return FocusManager_instance.t21(this);
  }
  function focusGained() {
  }
  function focusLost() {
  }
  initMetadataForInterface(Focusable, 'Focusable');
  initMetadataForObject(FocusManager, 'FocusManager');
  initMetadataForClass(InputEventContext, 'InputEventContext');
  initMetadataForCompanion(Companion_2);
  initMetadataForInterface(InputEventHandler, 'InputEventHandler');
  initMetadataForClass(InputEventHandlerAdapter, 'InputEventHandlerAdapter', InputEventHandlerAdapter, VOID, [InputEventHandler]);
  initMetadataForCompanion(Companion_3);
  initMetadataForClass(StateMachineInputEventHandler, 'StateMachineInputEventHandler', VOID, VOID, [InputEventHandler]);
  function get_devicePixelRatio() {
    return this.c23().b1x();
  }
  function get_center() {
    return new Point2D(this.p1b() / 2.0, this.r1b() / 2.0);
  }
  function get_zoomFactor() {
    return this.r23().u23_1;
  }
  initMetadataForInterface(View, 'View', VOID, VOID, [Disposable]);
  initMetadataForCompanion(Companion_4);
  initMetadataForClass(ViewTransformation, 'ViewTransformation');
  initMetadataForClass(CloseViewRequest, 'CloseViewRequest');
  initMetadataForCompanion(Companion_5);
  initMetadataForClass(ViewContentBounds, 'ViewContentBounds');
  initMetadataForCompanion(Companion_6);
  initMetadataForClass(sam$io_antarescircuit_jabbah_base_event_PropertyChangeListener$0, 'sam$io_antarescircuit_jabbah_base_event_PropertyChangeListener$0', VOID, VOID, [PropertyChangeListener, FunctionAdapter]);
  initMetadataForClass(ViewDecorator, 'ViewDecorator');
  function multiplyZoomFactor$default(factor, zoomLocation, $super) {
    zoomLocation = zoomLocation === VOID ? null : zoomLocation;
    var tmp;
    if ($super === VOID) {
      this.k26(factor, zoomLocation);
      tmp = Unit_instance;
    } else {
      tmp = $super.k26.call(this, factor, zoomLocation);
    }
    return tmp;
  }
  initMetadataForInterface(ViewNavigator, 'ViewNavigator');
  initMetadataForObject(IdentityViewToModelTransform, 'IdentityViewToModelTransform');
  initMetadataForCompanion(Companion_7);
  initMetadataForClass(ZoomPan, 'ZoomPan', ZoomPan_init_$Create$);
  initMetadataForCompanion(Companion_8);
  initMetadataForClass(ZoomStrategy, 'ZoomStrategy');
  initMetadataForClass(ZoomStrategyType, 'ZoomStrategyType', VOID, Enum);
  initMetadataForClass(ZoomStrategyType$NORMAL, 'NORMAL', VOID, ZoomStrategyType);
  initMetadataForClass(ZoomStrategyType$FIT, 'FIT', VOID, ZoomStrategyType);
  initMetadataForClass(ZoomStrategyType$FIT_MAX_NORMAL, 'FIT_MAX_NORMAL', VOID, ZoomStrategyType);
  initMetadataForClass(ZoomStrategyType$CENTER, 'CENTER', VOID, ZoomStrategyType);
  initMetadataForClass(ZoomStrategyType$VALUE, 'VALUE', VOID, ZoomStrategyType);
  initMetadataForClass(ZoomStrategyType$NONE, 'NONE', VOID, ZoomStrategyType);
  initMetadataForClass(DrawableBagImpl, 'DrawableBagImpl', DrawableBagImpl, VOID, [DrawableBag]);
  initMetadataForClass(DrawableBagInputEventHandler, 'DrawableBagInputEventHandler', DrawableBagInputEventHandler, InputEventHandlerAdapter);
  initMetadataForClass(DrawableContainerAdapter, 'DrawableContainerAdapter', DrawableContainerAdapter, VOID, [DrawableContainerListener]);
  initMetadataForInterface(DrawableDrawer, 'DrawableDrawer');
  initMetadataForClass(AbstractDrawableDrawer, 'AbstractDrawableDrawer', VOID, VOID, [DrawableDrawer]);
  initMetadataForClass(DrawableContainerDrawer, 'DrawableContainerDrawer', DrawableContainerDrawer, AbstractDrawableDrawer);
  initMetadataForClass(AbstractDrawable, 'AbstractDrawable', VOID, VOID, [Drawable]);
  initMetadataForClass(DrawableContainerImpl, 'DrawableContainerImpl', DrawableContainerImpl, AbstractDrawable, [DrawableContainer, Locatable]);
  initMetadataForClass(AbstractDrawableProperty, 'AbstractDrawableProperty');
  initMetadataForClass(DrawableProperty, 'DrawableProperty', VOID, AbstractDrawableProperty);
  initMetadataForClass(DrawableGeometryProperty, 'DrawableGeometryProperty', VOID, AbstractDrawableProperty);
  initMetadataForInterface(Unzoomable, 'Unzoomable', VOID, VOID, [Drawable]);
  initMetadataForClass(UnzoomableContainer, 'UnzoomableContainer', UnzoomableContainer, DrawableContainerImpl, [DrawableContainer, Unzoomable]);
  initMetadataForClass(DrawableOwner, 'DrawableOwner');
  function get_widthInt() {
    // Inline function 'kotlin.math.ceil' call
    var x = this.p1b();
    var tmp$ret$0 = Math.ceil(x);
    return numberToInt(tmp$ret$0);
  }
  function get_heightInt() {
    // Inline function 'kotlin.math.ceil' call
    var x = this.r1b();
    var tmp$ret$0 = Math.ceil(x);
    return numberToInt(tmp$ret$0);
  }
  function get_x() {
    return this.k2b().z19();
  }
  function get_y() {
    return this.k2b().a1a();
  }
  function get_xInt() {
    return numberToInt(this.z19());
  }
  function get_yInt() {
    return numberToInt(this.a1a());
  }
  function setBounds(x, y, w, h) {
    return this.j2b(x, y, w, h);
  }
  function setBounds_0(r) {
    return this.j2b(r.z19(), r.a1a(), r.p1b(), r.r1b());
  }
  initMetadataForInterface(RectangularDrawable, 'RectangularDrawable', VOID, VOID, [Locatable]);
  initMetadataForClass(AbstractRectangle, 'AbstractRectangle', VOID, AbstractDrawable, [RectangularDrawable]);
  initMetadataForClass(AbstractRectangularUnzoomable, 'AbstractRectangularUnzoomable', VOID, AbstractDrawable, [Unzoomable]);
  initMetadataForInterface(Stylable, 'Stylable');
  initMetadataForClass(AbstractStyledDrawable, 'AbstractStyledDrawable', VOID, AbstractDrawable, [Stylable]);
  initMetadataForCompanion(Companion_9);
  initMetadataForClass(ArrowBubble, 'ArrowBubble', VOID, AbstractStyledDrawable);
  initMetadataForClass(ArrowBubblePosition, 'ArrowBubblePosition');
  initMetadataForClass(PositionInfo, 'PositionInfo');
  initMetadataForObject(ArrowBubblePositioner, 'ArrowBubblePositioner');
  initMetadataForInterface(Colorable, 'Colorable');
  initMetadataForClass(DefaultDrawableDrawer, 'DefaultDrawableDrawer', DefaultDrawableDrawer, AbstractDrawableDrawer);
  initMetadataForClass(VerticalPosition, 'VerticalPosition');
  initMetadataForObject(DrawableAttendantPositioner, 'DrawableAttendantPositioner');
  initMetadataForInterface(ButtonAction, 'ButtonAction');
  initMetadataForCompanion(Companion_10);
  initMetadataForClass(EditInteractionHandler, 'EditInteractionHandler', VOID, InputEventHandlerAdapter);
  initMetadataForClass(DrawableButton, 'DrawableButton', VOID, AbstractRectangle, [Stylable]);
  initMetadataForClass(AbstractDrawableButtonRenderer, 'AbstractDrawableButtonRenderer');
  initMetadataForClass(IconDrawableButtonRenderer, 'IconDrawableButtonRenderer', VOID, AbstractDrawableButtonRenderer);
  initMetadataForCompanion(Companion_11);
  function applyTo(color) {
    return Companion_instance_19.u2j(this.n2h(), color);
  }
  initMetadataForInterface(Transparent, 'Transparent', VOID, VOID, [Drawable]);
  initMetadataForClass(FlexibleTextView, 'FlexibleTextView', VOID, AbstractStyledDrawable, [Transparent, Unzoomable, Locatable]);
  function get_canMirror() {
    return true;
  }
  initMetadataForInterface(Mirrorable, 'Mirrorable', VOID, VOID, [Drawable]);
  initMetadataForCompanion(Companion_12);
  function prepareMoveBy(components) {
  }
  function completeMoveBy() {
  }
  initMetadataForInterface(Movable, 'Movable', VOID, VOID, [Locatable]);
  initMetadataForClass(MoveLocatableAnimation, 'MoveLocatableAnimation', VOID, AbstractAnimationTask);
  function set_orientation(value) {
    this.w27(value.x1e_1);
  }
  function get_orientation() {
    return Companion_getInstance_0().c1f(this.g20());
  }
  initMetadataForInterface(Orientable, 'Orientable', VOID, VOID, [Locatable]);
  initMetadataForCompanion(Companion_13);
  initMetadataForClass(ChunkView, 'ChunkView');
  initMetadataForClass(RichTextDrawable, 'RichTextDrawable', VOID, AbstractRectangle);
  initMetadataForCompanion(Companion_14);
  initMetadataForClass(ShakeLocatableAnimation, 'ShakeLocatableAnimation', VOID, AbstractAnimationTask);
  initMetadataForClass(GlowTask, 'GlowTask', GlowTask, AbstractAnimationTask);
  initMetadataForObject(SynchronizedGlowAnimation, 'SynchronizedGlowAnimation');
  initMetadataForClass(TransparentImpl, 'TransparentImpl', VOID, VOID, [Transparent, Drawable]);
  initMetadataForCompanion(Companion_15);
  initMetadataForClass(TransparentAnimation$Companion$fadeInOut$1, VOID, VOID, AnimationTaskAdapter);
  initMetadataForClass(TransparentAnimation$Companion$fadeInOut$4, VOID, VOID, AnimationTaskAdapter);
  initMetadataForCompanion(Companion_16);
  initMetadataForClass(TransparentAnimation, 'TransparentAnimation', VOID, AbstractAnimationTask);
  initMetadataForCompanion(Companion_17);
  initMetadataForCompanion(Companion_18);
  initMetadataForClass(Color, 'Color');
  initMetadataForCompanion(Companion_19);
  initMetadataForClass(ColorGradient, 'ColorGradient');
  initMetadataForClass(CompositeColorGradient, 'CompositeColorGradient');
  initMetadataForCompanion(Companion_20);
  initMetadataForClass(CompositeColor, 'CompositeColor', CompositeColor);
  initMetadataForClass(Cursor, 'Cursor', VOID, Enum);
  initMetadataForObject(DrawGraphicsModule, 'DrawGraphicsModule', VOID, AbstractModule);
  initMetadataForObject(DropShadow, 'DropShadow');
  initMetadataForClass(FontImpl, 'FontImpl', FontImpl);
  initMetadataForClass(FontStyle, 'FontStyle', VOID, Enum);
  initMetadataForCompanion(Companion_21);
  initMetadataForClass(LogicalFontFamily, 'LogicalFontFamily', VOID, Enum);
  function draw(context, location) {
    return this.a2f(context, location, context.a1z(Themes_getInstance().r2f().j2f_1.m1t()));
  }
  initMetadataForInterface(Icon, 'Icon');
  initMetadataForClass(KnobIcon, 'KnobIcon', VOID, VOID, [Icon]);
  initMetadataForClass(RemoveIcon, 'RemoveIcon', VOID, VOID, [Icon]);
  initMetadataForClass(AddIcon, 'AddIcon', VOID, VOID, [Icon]);
  initMetadataForClass(DeleteIcon, 'DeleteIcon', DeleteIcon, VOID, [Icon]);
  initMetadataForCompanion(Companion_22);
  initMetadataForClass(ImageType, 'ImageType', VOID, Enum);
  initMetadataForClass(LinearColorGradient, 'LinearColorGradient');
  initMetadataForClass(PredefinedColor, 'PredefinedColor');
  initMetadataForCompanion(Companion_23);
  initMetadataForClass(PredefinedColorIdentity, 'PredefinedColorIdentity', VOID, Enum);
  initMetadataForObject(PredefinedColorRepository, 'PredefinedColorRepository');
  initMetadataForClass(PredefinedStroke, 'PredefinedStroke');
  initMetadataForObject(PredefinedStrokeRepository, 'PredefinedStrokeRepository');
  initMetadataForCompanion(Companion_24);
  initMetadataForClass(PredefinedStrokeIdentity, 'PredefinedStrokeIdentity', VOID, Enum);
  initMetadataForClass(RadialColorGradient, 'RadialColorGradient');
  initMetadataForClass(RadialColorGradientCache, 'RadialColorGradientCache');
  initMetadataForObject(ReferenceColorSequenceProvider, 'ReferenceColorSequenceProvider');
  initMetadataForClass(ReferenceColor, 'ReferenceColor');
  initMetadataForClass(Usage, 'Usage', VOID, VOID, [Comparable]);
  initMetadataForClass(FlexibleReferenceColorSequenceImpl, 'FlexibleReferenceColorSequenceImpl', FlexibleReferenceColorSequenceImpl);
  initMetadataForClass(ReferenceColorReplacement, 'ReferenceColorReplacement');
  initMetadataForClass(ReferenceColorEvent, 'ReferenceColorEvent');
  initMetadataForClass(Stroke, 'Stroke', Stroke);
  initMetadataForClass(LineCap, 'LineCap', VOID, Enum);
  initMetadataForClass(LineJoin, 'LineJoin', VOID, Enum);
  initMetadataForObject(TextRenderInfoFactory, 'TextRenderInfoFactory');
  initMetadataForClass(TextRenderInfo, 'TextRenderInfo');
  initMetadataForClass(DrawModule$imageLoader$1);
  initMetadataForObject(DrawModule, 'DrawModule', VOID, AbstractModule);
  initMetadataForCompanion(Companion_25);
  initMetadataForClass(ArrowHead, 'ArrowHead', ArrowHead, AbstractDrawable, [Drawable]);
  function getFirstPoint() {
    return this.e2k(0);
  }
  function getLastPoint() {
    return this.e2k(this.d2k() - 1 | 0);
  }
  function findSegment$default(x, y, area, $super) {
    area = area === VOID ? 4 : area;
    return $super === VOID ? this.q2q(x, y, area) : $super.q2q.call(this, x, y, area);
  }
  function isSegmentOrthogonal(index) {
    return this.x2q(index) || this.y2q(index);
  }
  initMetadataForInterface(Polyline, 'Polyline');
  initMetadataForCompanion(Companion_26);
  initMetadataForClass(PolylineInterference, 'PolylineInterference');
  initMetadataForClass(PolylineDrawable, 'PolylineDrawable', PolylineDrawable, AbstractStyledDrawable, [Polyline, Locatable, Transparent]);
  initMetadataForCompanion(Companion_27);
  initMetadataForInterface(PolylineShape, 'PolylineShape', VOID, VOID, [Polyline, Shape]);
  initMetadataForCompanion(Companion_28);
  initMetadataForClass(PolylineShapeImpl, 'PolylineShapeImpl', PolylineShapeImpl, VOID, [PolylineShape]);
  initMetadataForObject(DrawStyleModule, 'DrawStyleModule', VOID, AbstractModule);
  initMetadataForCompanion(Companion_29);
  initMetadataForInterface(Theme, 'Theme');
  initMetadataForClass(DrawTheme, 'DrawTheme', DrawTheme, VOID, [Theme]);
  initMetadataForClass(StylableImpl, 'StylableImpl', VOID, VOID, [Stylable]);
  initMetadataForClass(BasicStyle, 'BasicStyle', BasicStyle);
  initMetadataForCompanion(Companion_30);
  initMetadataForClass(StyleRepository, 'StyleRepository', StyleRepository);
  initMetadataForCompanion(Companion_31);
  initMetadataForClass(StyleType, 'StyleType');
  initMetadataForObject(Themes, 'Themes');
  initMetadataForClass(ThemeEvent, 'ThemeEvent');
  initMetadataForClass(ViewPropertyListener, 'ViewPropertyListener', VOID, VOID, [PropertyChangeListener]);
  initMetadataForClass(AbstractContentViewAction, 'AbstractContentViewAction', VOID, AbstractAction);
  initMetadataForClass(AbstractViewAction, 'AbstractViewAction', VOID, AbstractContentViewAction);
  initMetadataForCompanion(Companion_32);
  initMetadataForClass(AutoPanning, 'AutoPanning', VOID, MouseAdapter);
  initMetadataForClass(ActiveContentViewChangedEvent, 'ActiveContentViewChangedEvent');
  initMetadataForClass(ContentViewManagerImpl, 'ContentViewManagerImpl', ContentViewManagerImpl_init_$Create$);
  initMetadataForObject(DrawViewModule, 'DrawViewModule', VOID, AbstractModule);
  initMetadataForCompanion(Companion_33);
  initMetadataForClass(sam$io_antarescircuit_jabbah_base_event_PropertyChangeListener$0_0, 'sam$io_antarescircuit_jabbah_base_event_PropertyChangeListener$0', VOID, VOID, [PropertyChangeListener, FunctionAdapter]);
  initMetadataForClass(sam$io_antarescircuit_jabbah_base_event_PropertyChangeListener$0_1, 'sam$io_antarescircuit_jabbah_base_event_PropertyChangeListener$0', VOID, VOID, [PropertyChangeListener, FunctionAdapter]);
  initMetadataForClass(InvalidatableViewPainter, 'InvalidatableViewPainter', VOID, VOID, [Disposable]);
  initMetadataForCompanion(Companion_34);
  initMetadataForClass(MouseWheelModeController, 'MouseWheelModeController', MouseWheelModeController, KeyAdapter);
  initMetadataForClass(PanMethod, 'PanMethod', VOID, Enum);
  initMetadataForClass(PanMethod$MiddleMouseButton, 'MiddleMouseButton', VOID, PanMethod);
  initMetadataForClass(PanMethod$AltLeftMouseButton, 'AltLeftMouseButton', VOID, PanMethod);
  initMetadataForClass(PanMethod$SpaceLeftMouseButton, 'SpaceLeftMouseButton', VOID, PanMethod);
  initMetadataForCompanion(Companion_35);
  initMetadataForObject(CurrentPanMethod, 'CurrentPanMethod');
  initMetadataForObject(TooltipManager, 'TooltipManager');
  initMetadataForClass(TooltipEvent, 'TooltipEvent');
  initMetadataForClass(TooltipView, 'TooltipView');
  initMetadataForClass(TooltipRequest, 'TooltipRequest');
  initMetadataForCompanion(Companion_36);
  initMetadataForClass(TooltipHandler, 'TooltipHandler');
  initMetadataForClass(ChildListener, 'ChildListener');
  initMetadataForClass(OverlayListener, 'OverlayListener');
  initMetadataForClass(PropertyChangeHandler, 'PropertyChangeHandler', VOID, VOID, [PropertyChangeListener]);
  initMetadataForClass(EventHandler, 'EventHandler', VOID, InputEventHandlerAdapter);
  initMetadataForClass(ViewImpl, 'ViewImpl', VOID, VOID, [View]);
  initMetadataForCompanion(Companion_37);
  initMetadataForClass(ViewNavigatorImpl, 'ViewNavigatorImpl', VOID, VOID, [ViewNavigator]);
  initMetadataForCompanion(Companion_38);
  initMetadataForClass(ViewSpace, 'ViewSpace');
  initMetadataForObject(ZoomPanActions, 'ZoomPanActions');
  initMetadataForClass(AbstractZoomPanAction, 'AbstractZoomPanAction', VOID, AbstractViewAction);
  initMetadataForClass(ZoomInAction, 'ZoomInAction', ZoomInAction, AbstractZoomPanAction);
  initMetadataForClass(ZoomNormalAction, 'ZoomNormalAction', ZoomNormalAction, AbstractZoomPanAction);
  initMetadataForClass(ZoomOutAction, 'ZoomOutAction', ZoomOutAction, AbstractZoomPanAction);
  initMetadataForClass(ZoomFitAction, 'ZoomFitAction', ZoomFitAction, AbstractZoomPanAction);
  initMetadataForClass(ZoomFitMaxNormalAction, 'ZoomFitMaxNormalAction', ZoomFitMaxNormalAction, AbstractZoomPanAction);
  initMetadataForClass(ZoomCenterAction, 'ZoomCenterAction', ZoomCenterAction, AbstractZoomPanAction);
  initMetadataForCompanion(Companion_39);
  initMetadataForCompanion(Companion_40);
  initMetadataForClass(MouseController, 'MouseController', VOID, MouseAdapter);
  initMetadataForClass(ZoomPanController, 'ZoomPanController');
  initMetadataForClass(ZoomedPointTranslation, 'ZoomedPointTranslation');
  initMetadataForClass(ZoomedPointVoyageAnimation, 'ZoomedPointVoyageAnimation', VOID, AbstractAnimationTask);
  initMetadataForClass(ZoomedPointVoyage, 'ZoomedPointVoyage');
  //endregion
  function EmbeddedImageJs(type, data) {
    this.d1r_1 = new Image();
    this.d1r_1.src = 'data:' + type.i1r_1 + ';base64,' + data;
  }
  protoOf(EmbeddedImageJs).p1b = function () {
    return this.d1r_1.width;
  };
  protoOf(EmbeddedImageJs).r1b = function () {
    return this.d1r_1.height;
  };
  function toJsFontStyle($this, font) {
    var sb = StringBuilder_init_$Create$();
    if (font.k1r()) {
      sb.h7('bold ');
    }
    if (font.l1r()) {
      sb.h7('italic ');
    }
    return sb.toString();
  }
  function toJsFontName($this, font) {
    var tmp0 = get_entries();
    var tmp$ret$0;
    $l$block: {
      // Inline function 'kotlin.collections.firstOrNull' call
      var _iterator__ex2g4s = tmp0.i();
      while (_iterator__ex2g4s.j()) {
        var element = _iterator__ex2g4s.k();
        if (element.k2_1 === font.m1r().n1r()) {
          tmp$ret$0 = element;
          break $l$block;
        }
      }
      tmp$ret$0 = null;
    }
    var tmp0_safe_receiver = tmp$ret$0;
    var tmp1_elvis_lhs = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.q1r_1;
    return tmp1_elvis_lhs == null ? LogicalFontFamily_SANS_SERIF_getInstance().r1r_1 : tmp1_elvis_lhs;
  }
  function Companion() {
  }
  protoOf(Companion).s1r = function (font) {
    return toJsFontStyle(this, font) + ' ' + font.o() + 'px ' + toJsFontName(this, font);
  };
  var Companion_instance_3;
  function Companion_getInstance_1() {
    return Companion_instance_3;
  }
  function playPolygon($this, x, y, n) {
    $this.u1r_1.moveTo(x[0], y[0]);
    var inductionVariable = 1;
    if (inductionVariable < n)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        $this.u1r_1.lineTo(x[i], y[i]);
      }
       while (inductionVariable < n);
    $this.u1r_1.closePath();
  }
  function toLinearJsGradient($this, gradient) {
    var jsGradient = $this.u1r_1.createLinearGradient(gradient.b1s_1.in_1, gradient.b1s_1.jn_1, gradient.d1s_1.in_1, gradient.d1s_1.jn_1);
    jsGradient.addColorStop(0.0, Companion_getInstance_19().g1s(gradient.c1s_1));
    jsGradient.addColorStop(1.0, Companion_getInstance_19().g1s(gradient.e1s_1));
    return jsGradient;
  }
  function toRadialJsGradient($this, gradient) {
    var jsGradient = $this.u1r_1.createRadialGradient(gradient.h1s_1.in_1, gradient.h1s_1.jn_1, 0.0, gradient.h1s_1.in_1, gradient.h1s_1.jn_1, gradient.i1s_1);
    jsGradient.addColorStop(0.0, Companion_getInstance_19().g1s(gradient.j1s_1));
    jsGradient.addColorStop(1.0, Companion_getInstance_19().g1s(gradient.k1s_1));
    return jsGradient;
  }
  function forwardTransform($this) {
    var matrix = $this.l1s().u1c();
    $this.u1r_1.setTransform(matrix[0], matrix[1], matrix[2], matrix[3], matrix[4], matrix[5]);
  }
  function toLineCap($this, cap) {
    var tmp;
    // Inline function 'org.w3c.dom.BUTT' call
    // Inline function 'kotlin.js.asDynamic' call
    // Inline function 'kotlin.js.unsafeCast' call
    if (equals(cap, 'butt')) {
      tmp = LineCap_BUTT_getInstance();
    } else {
      // Inline function 'org.w3c.dom.ROUND' call
      // Inline function 'kotlin.js.asDynamic' call
      // Inline function 'kotlin.js.unsafeCast' call
      if (equals(cap, 'round')) {
        tmp = LineCap_ROUND_getInstance();
      } else {
        // Inline function 'org.w3c.dom.SQUARE' call
        // Inline function 'kotlin.js.asDynamic' call
        // Inline function 'kotlin.js.unsafeCast' call
        if (equals(cap, 'square')) {
          tmp = LineCap_SQUARE_getInstance();
        } else {
          throw IllegalArgumentException_init_$Create$('unknown cap ' + toString(cap));
        }
      }
    }
    return tmp;
  }
  function fromLineCap($this, cap) {
    var tmp;
    switch (cap.l2_1) {
      case 0:
        // Inline function 'org.w3c.dom.BUTT' call

        // Inline function 'kotlin.js.asDynamic' call

        // Inline function 'kotlin.js.unsafeCast' call

        tmp = 'butt';
        break;
      case 1:
        // Inline function 'org.w3c.dom.ROUND' call

        // Inline function 'kotlin.js.asDynamic' call

        // Inline function 'kotlin.js.unsafeCast' call

        tmp = 'round';
        break;
      case 2:
        // Inline function 'org.w3c.dom.SQUARE' call

        // Inline function 'kotlin.js.asDynamic' call

        // Inline function 'kotlin.js.unsafeCast' call

        tmp = 'square';
        break;
      default:
        noWhenBranchMatchedException();
        break;
    }
    return tmp;
  }
  function toLineJoin($this, join) {
    var tmp;
    // Inline function 'org.w3c.dom.MITER' call
    // Inline function 'kotlin.js.asDynamic' call
    // Inline function 'kotlin.js.unsafeCast' call
    if (equals(join, 'miter')) {
      tmp = LineJoin_MITER_getInstance();
    } else {
      // Inline function 'org.w3c.dom.ROUND' call
      // Inline function 'kotlin.js.asDynamic' call
      // Inline function 'kotlin.js.unsafeCast' call
      if (equals(join, 'round')) {
        tmp = LineJoin_ROUND_getInstance();
      } else {
        // Inline function 'org.w3c.dom.BEVEL' call
        // Inline function 'kotlin.js.asDynamic' call
        // Inline function 'kotlin.js.unsafeCast' call
        if (equals(join, 'bevel')) {
          tmp = LineJoin_BEVEL_getInstance();
        } else {
          throw IllegalArgumentException_init_$Create$('unknown join ' + toString(join));
        }
      }
    }
    return tmp;
  }
  function fromLineJoin($this, join) {
    var tmp;
    switch (join.l2_1) {
      case 0:
        // Inline function 'org.w3c.dom.MITER' call

        // Inline function 'kotlin.js.asDynamic' call

        // Inline function 'kotlin.js.unsafeCast' call

        tmp = 'miter';
        break;
      case 1:
        // Inline function 'org.w3c.dom.ROUND' call

        // Inline function 'kotlin.js.asDynamic' call

        // Inline function 'kotlin.js.unsafeCast' call

        tmp = 'round';
        break;
      case 2:
        // Inline function 'org.w3c.dom.BEVEL' call

        // Inline function 'kotlin.js.asDynamic' call

        // Inline function 'kotlin.js.unsafeCast' call

        tmp = 'bevel';
        break;
      default:
        noWhenBranchMatchedException();
        break;
    }
    return tmp;
  }
  function toDash($this, dash) {
    var tmp = 0;
    var tmp_0 = dash.length;
    // Inline function 'kotlin.arrayOfNulls' call
    var tmp_1 = Array(tmp_0);
    while (tmp < tmp_0) {
      var tmp_2 = tmp;
      tmp_1[tmp_2] = dash[tmp_2];
      tmp = tmp + 1 | 0;
    }
    return toFloatArray(tmp_1);
  }
  function fromDash($this, dash) {
    if (dash == null) {
      // Inline function 'kotlin.doubleArrayOf' call
      var tmp$ret$0 = new Float64Array([]);
      return toTypedArray(tmp$ret$0);
    }
    var tmp = 0;
    var tmp_0 = dash.length;
    // Inline function 'kotlin.arrayOfNulls' call
    var tmp_1 = Array(tmp_0);
    while (tmp < tmp_0) {
      var tmp_2 = tmp;
      tmp_1[tmp_2] = dash[tmp_2];
      tmp = tmp + 1 | 0;
    }
    return tmp_1;
  }
  function drawPath($this, path) {
    $this.u1r_1.beginPath();
    path.lo($this.u1r_1);
    $this.u1r_1.stroke();
    $this.u1r_1.closePath();
  }
  function fillPath($this, path) {
    $this.u1r_1.beginPath();
    path.lo($this.u1r_1);
    $this.u1r_1.fill();
    $this.u1r_1.closePath();
  }
  function Graphics2DJs(ctx) {
    AbstractGraphics2D.call(this);
    this.u1r_1 = ctx;
    this.v1r_1 = new Rectangle2D();
    this.u1r_1.setTransform(1.0, 0.0, 0.0, 1.0, 0.0, 0.0);
    this.w1r_1 = true;
    this.x1r_1 = new AffineTransformImpl(1.0, VOID, VOID, 1.0);
    this.y1r_1 = new Color(0, 0, 0, 255);
    this.z1r_1 = new LinearColorGradient(Companion_getInstance().g1a_1, Companion_getInstance_20().n1s_1, Companion_getInstance().g1a_1, Companion_getInstance_20().n1s_1);
    this.a1s_1 = null;
  }
  protoOf(Graphics2DJs).x1s = function () {
    this.u1r_1.beginPath();
  };
  protoOf(Graphics2DJs).y1s = function (x, y) {
    this.u1r_1.moveTo(x, y);
  };
  protoOf(Graphics2DJs).z1s = function (x, y) {
    this.u1r_1.lineTo(x, y);
  };
  protoOf(Graphics2DJs).a1t = function (xc, yc, x1, y1) {
    this.u1r_1.quadraticCurveTo(xc, yc, x1, y1);
  };
  protoOf(Graphics2DJs).b1t = function (xc1, yc1, xc2, yc2, x1, y1) {
    this.u1r_1.bezierCurveTo(xc1, yc1, xc2, yc2, x1, y1);
  };
  protoOf(Graphics2DJs).c1t = function (x, y, radius, startAngle, endAngle, anticlockwise) {
    this.u1r_1.arc(x, y, radius, startAngle, endAngle, anticlockwise);
  };
  protoOf(Graphics2DJs).d1t = function () {
    this.u1r_1.stroke();
  };
  protoOf(Graphics2DJs).e1t = function () {
    this.u1r_1.fill();
  };
  protoOf(Graphics2DJs).f1t = function () {
    this.u1r_1.closePath();
  };
  protoOf(Graphics2DJs).g1t = function () {
    return false;
  };
  protoOf(Graphics2DJs).h1t = function (_set____db54di) {
    this.w1r_1 = _set____db54di;
  };
  protoOf(Graphics2DJs).i1t = function (x, y, w, h) {
  };
  protoOf(Graphics2DJs).j1t = function (r) {
  };
  protoOf(Graphics2DJs).k1t = function (value) {
    this.x1r_1 = value;
    forwardTransform(this);
  };
  protoOf(Graphics2DJs).l1s = function () {
    var tmp = this.x1r_1;
    return AffineTransformImpl_init_$Create$(tmp instanceof AffineTransformImpl ? tmp : THROW_CCE());
  };
  protoOf(Graphics2DJs).l1t = function (value) {
    this.y1r_1 = value;
    // Inline function 'kotlin.also' call
    var this_0 = Companion_getInstance_19().g1s(value);
    this.u1r_1.fillStyle = this_0;
    this.u1r_1.strokeStyle = this_0;
  };
  protoOf(Graphics2DJs).m1t = function () {
    return this.y1r_1;
  };
  protoOf(Graphics2DJs).n1t = function (value) {
    if (value instanceof Color) {
      this.l1t(value);
    } else {
      if (value instanceof LinearColorGradient) {
        this.z1r_1 = value;
        // Inline function 'kotlin.also' call
        var this_0 = toLinearJsGradient(this, value);
        this.u1r_1.fillStyle = this_0;
        this.u1r_1.strokeStyle = this_0;
      } else {
        if (value instanceof RadialColorGradient) {
          this.z1r_1 = value;
          // Inline function 'kotlin.also' call
          var this_1 = toRadialJsGradient(this, value);
          this.u1r_1.fillStyle = this_1;
          this.u1r_1.strokeStyle = this_1;
        } else {
          throw IllegalArgumentException_init_$Create$('unsupported Paint implementation');
        }
      }
    }
  };
  protoOf(Graphics2DJs).o1t = function (value) {
    this.u1r_1.lineWidth = value.p1t_1;
    this.u1r_1.lineCap = fromLineCap(this, value.q1t_1);
    this.u1r_1.lineJoin = fromLineJoin(this, value.r1t_1);
    this.u1r_1.miterLimit = value.s1t_1;
    this.u1r_1.setLineDash(fromDash(this, value.t1t_1));
    var tmp0_safe_receiver = value.u1t_1;
    var tmp1_elvis_lhs = tmp0_safe_receiver == null ? null : tmp0_safe_receiver;
    this.u1r_1.lineDashOffset = tmp1_elvis_lhs == null ? 0.0 : tmp1_elvis_lhs;
  };
  protoOf(Graphics2DJs).v1t = function () {
    return new Stroke(this.u1r_1.lineWidth, toLineCap(this, this.u1r_1.lineCap), toLineJoin(this, this.u1r_1.lineJoin), this.u1r_1.miterLimit, toDash(this, this.u1r_1.getLineDash()), this.u1r_1.lineDashOffset);
  };
  protoOf(Graphics2DJs).w1t = function (value) {
    this.a1s_1 = value;
    this.u1r_1.font = Companion_instance_3.s1r(value);
  };
  protoOf(Graphics2DJs).x1t = function () {
    return this.u1r_1.save();
  };
  protoOf(Graphics2DJs).y1t = function () {
    return this.u1r_1.restore();
  };
  protoOf(Graphics2DJs).x1c = function (sx, sy) {
    this.l1s().x1c(sx, sy);
    this.u1r_1.scale(sx, sy);
  };
  protoOf(Graphics2DJs).v1c = function (tx, ty) {
    this.l1s().v1c(tx, ty);
    this.u1r_1.translate(tx, ty);
  };
  protoOf(Graphics2DJs).y1c = function (theta) {
    this.b1u(this.a1u() + theta);
    this.l1s().y1c(theta);
    this.u1r_1.rotate(theta);
  };
  protoOf(Graphics2DJs).c1u = function (x1, y1, x2, y2) {
    this.x1s();
    this.y1s(x1, y1);
    this.z1s(x2, y2);
    this.d1t();
    this.f1t();
  };
  protoOf(Graphics2DJs).d1u = function (x1, y1, x2, y2) {
    this.x1s();
    this.y1s(x1, y1);
    this.z1s(x2, y2);
    this.d1t();
    this.f1t();
  };
  protoOf(Graphics2DJs).e1u = function (x, y, w, h) {
    this.u1r_1.strokeRect(x + 0.5, y + 0.5, w, h);
  };
  protoOf(Graphics2DJs).f1u = function (x, y, w, h) {
    this.u1r_1.strokeRect(x, y, w, h);
  };
  protoOf(Graphics2DJs).g1u = function (x, y, w, h, arcW, arcH) {
    this.h1u(x, y, w, h, arcW, arcH);
  };
  protoOf(Graphics2DJs).i1u = function (x, y, w, h) {
    this.u1r_1.fillRect(x + 0.5, y + 0.5, w, h);
  };
  protoOf(Graphics2DJs).j1u = function (x, y, w, h) {
    this.u1r_1.fillRect(x, y, w, h);
  };
  protoOf(Graphics2DJs).k1u = function (x, y, w, h, arcW, arcH) {
    this.l1u(x, y, w, h, arcW, arcH);
  };
  protoOf(Graphics2DJs).m1u = function (x, y, w, h) {
    this.u1r_1.beginPath();
    this.n1u(x, y, w, h);
    this.u1r_1.stroke();
    this.u1r_1.closePath();
  };
  protoOf(Graphics2DJs).o1u = function (x, y, w, h) {
    this.m1u(x, y, w, h);
  };
  protoOf(Graphics2DJs).p1u = function (x, y, w, h) {
    this.u1r_1.beginPath();
    this.n1u(x, y, w, h);
    this.u1r_1.fill();
    this.u1r_1.closePath();
  };
  protoOf(Graphics2DJs).q1u = function (x, y, w, h) {
    this.p1u(x, y, w, h);
  };
  protoOf(Graphics2DJs).r1u = function (x, y, n) {
    this.u1r_1.beginPath();
    playPolygon(this, x, y, n);
    this.u1r_1.fill();
  };
  protoOf(Graphics2DJs).s1u = function (x, y) {
    this.i1u(x, y, 1, 1);
  };
  protoOf(Graphics2DJs).t1u = function (shape) {
    if (shape instanceof Path2DJs) {
      drawPath(this, shape);
    } else {
      protoOf(AbstractGraphics2D).t1u.call(this, shape);
    }
  };
  protoOf(Graphics2DJs).u1u = function (shape) {
    if (shape instanceof Path2DJs) {
      fillPath(this, shape);
    } else {
      protoOf(AbstractGraphics2D).u1u.call(this, shape);
    }
  };
  protoOf(Graphics2DJs).v1u = function () {
    var tmp;
    if (this.g1t()) {
      tmp = Rectangle2D_init_$Create$(this.v1r_1);
    } else {
      tmp = null;
    }
    return tmp;
  };
  protoOf(Graphics2DJs).w1u = function (r) {
    r.s1b(this.v1r_1.e1h_1, this.v1r_1.f1h_1, this.v1r_1.g1h_1, this.v1r_1.h1h_1);
    return r;
  };
  protoOf(Graphics2DJs).x1u = function (s, x, y) {
    this.u1r_1.fillText(s, x, y);
  };
  protoOf(Graphics2DJs).y1u = function (image, x, y) {
    if (image instanceof EmbeddedImageJs) {
      this.u1r_1.drawImage(image.d1r_1, x, y);
    } else {
      throw IllegalArgumentException_init_$Create$('unsupported image type ' + getKClassFromExpression(image).l9());
    }
  };
  function TextRenderInfoFactoryImpl() {
    TextRenderInfoFactoryImpl_instance = this;
    var tmp = this;
    var tmp_0 = document.createElement('canvas');
    tmp.o1v_1 = tmp_0 instanceof HTMLCanvasElement ? tmp_0 : THROW_CCE();
  }
  protoOf(TextRenderInfoFactoryImpl).p1v = function (text, font) {
    var tmp = this.o1v_1.getContext('2d');
    var context = tmp instanceof CanvasRenderingContext2D ? tmp : THROW_CCE();
    context.font = Companion_instance_3.s1r(font);
    var metrics = context.measureText(text);
    var ascent = 7.0 / 8 * font.o();
    var descent = 1.0 / 8 * font.o();
    return new TextRenderInfo(new Rectangle2D(0.0, -ascent, metrics.width, ascent + descent), ascent);
  };
  var TextRenderInfoFactoryImpl_instance;
  function TextRenderInfoFactoryImpl_getInstance() {
    if (TextRenderInfoFactoryImpl_instance == null)
      new TextRenderInfoFactoryImpl();
    return TextRenderInfoFactoryImpl_instance;
  }
  function PolylineShapeFactory() {
  }
  protoOf(PolylineShapeFactory).q1v = function (points) {
    return new PolylineShapeImpl(points);
  };
  var PolylineShapeFactory_instance;
  function PolylineShapeFactory_getInstance() {
    return PolylineShapeFactory_instance;
  }
  function get_keyboardEventKeyMap() {
    _init_properties_CanvasEvents_kt__7kjjnz();
    return keyboardEventKeyMap;
  }
  var keyboardEventKeyMap;
  function MouseEventBridge(windowToCanvas, listener, canvas) {
    this.r1v_1 = windowToCanvas;
    this.s1v_1 = listener;
    this.t1v_1 = canvas;
  }
  protoOf(MouseEventBridge).u1v = function (event) {
    var e = new MouseEventJs(this.r1v_1(event instanceof MouseEvent ? event : THROW_CCE()), this.t1v_1, event);
    switch (event.type) {
      case 'mousedown':
        this.s1v_1.s1a(e);
        break;
      case 'mouseup':
        this.s1v_1.t1a(e);
        break;
      case 'click':
        this.s1v_1.r1a(e);
        break;
      case 'dblclick':
        this.s1v_1.r1a(e);
        break;
    }
  };
  protoOf(MouseEventBridge).handleEvent = function (event) {
    return this.u1v(event);
  };
  function MouseMotionEventBridge(windowToCanvas, listener, canvas) {
    this.v1v_1 = windowToCanvas;
    this.w1v_1 = listener;
    this.x1v_1 = canvas;
    this.y1v_1 = false;
  }
  protoOf(MouseMotionEventBridge).u1v = function (event) {
    var e = new MouseEventJs(this.v1v_1(event instanceof MouseEvent ? event : THROW_CCE()), this.x1v_1, event, this.y1v_1);
    switch (event.type) {
      case 'mousedown':
        this.y1v_1 = true;
        break;
      case 'mouseup':
        this.y1v_1 = false;
        break;
      case 'mousemove':
        if (this.y1v_1) {
          this.w1v_1.u1a(e);
        } else {
          this.w1v_1.v1a(e);
        }

        break;
    }
  };
  protoOf(MouseMotionEventBridge).handleEvent = function (event) {
    return this.u1v(event);
  };
  function MouseWheelEventBridge(windowToCanvas, listener, canvas) {
    this.z1v_1 = windowToCanvas;
    this.a1w_1 = listener;
    this.b1w_1 = canvas;
  }
  protoOf(MouseWheelEventBridge).u1v = function (event) {
    var w3cEvent = event instanceof WheelEvent ? event : THROW_CCE();
    var e = new MouseEventJs(this.z1v_1(w3cEvent), this.b1w_1, w3cEvent);
    this.a1w_1.w1a(e);
  };
  protoOf(MouseWheelEventBridge).handleEvent = function (event) {
    return this.u1v(event);
  };
  function KeyEventBridge(listener, canvas) {
    this.c1w_1 = listener;
    this.d1w_1 = canvas;
  }
  protoOf(KeyEventBridge).u1v = function (event) {
    var e = new KeyEventJs(this.d1w_1, event instanceof KeyboardEvent ? event : THROW_CCE());
    switch (e.u19().l2_1) {
      case 0:
        this.c1w_1.w19(e);
        break;
      case 1:
        this.c1w_1.x19(e);
        break;
      case 2:
        this.c1w_1.y19(e);
        break;
      default:
        break;
    }
  };
  protoOf(KeyEventBridge).handleEvent = function (event) {
    return this.u1v(event);
  };
  function convertEventType($this) {
    switch ($this.i1w_1.type) {
      case 'click':
        return MouseEventType_CLICKED_getInstance();
      case 'mousedown':
        return MouseEventType_PRESSED_getInstance();
      case 'mouseup':
        return MouseEventType_RELEASED_getInstance();
      case 'mouseenter':
        return MouseEventType_ENTERED_getInstance();
      case 'mouseleave':
        return MouseEventType_EXITED_getInstance();
      case 'mousemove':
        return $this.j1w_1 ? MouseEventType_DRAGGED_getInstance() : MouseEventType_MOVED_getInstance();
      case 'wheel':
        return MouseEventType_WHEEL_ROTATED_getInstance();
      default:
        return MouseEventType_UNKNOWN_getInstance();
    }
  }
  function convertButton($this) {
    switch ($this.i1w_1.button) {
      case 0:
        return Button_BUTTON1_getInstance();
      case 1:
        return Button_BUTTON2_getInstance();
      case 2:
        return Button_BUTTON3_getInstance();
      default:
        return Button_NONE_getInstance();
    }
  }
  function convertModifiers($this) {
    var modifiers = 0;
    if ($this.i1w_1.shiftKey) {
      modifiers = modifiers | Modifier_Shift_getInstance().mask;
    }
    if ($this.i1w_1.ctrlKey) {
      modifiers = modifiers | Modifier_Ctrl_getInstance().mask;
    }
    if ($this.i1w_1.metaKey) {
      modifiers = modifiers | Modifier_Meta_getInstance().mask;
    }
    if ($this.i1w_1.altKey) {
      modifiers = modifiers | Modifier_Alt_getInstance().mask;
    }
    return modifiers;
  }
  function MouseEventJs(location, canvas, event, pressed) {
    pressed = pressed === VOID ? false : pressed;
    this.g1w_1 = location;
    this.h1w_1 = canvas;
    this.i1w_1 = event;
    this.j1w_1 = pressed;
    this.k1w_1 = convertEventType(this);
  }
  protoOf(MouseEventJs).hw = function () {
    return this.g1w_1;
  };
  protoOf(MouseEventJs).y16 = function () {
    return this.i1w_1;
  };
  protoOf(MouseEventJs).u19 = function () {
    return this.k1w_1;
  };
  protoOf(MouseEventJs).z16 = function () {
    return this.h1w_1;
  };
  protoOf(MouseEventJs).b1a = function () {
    return convertButton(this);
  };
  protoOf(MouseEventJs).c1a = function () {
    return this.i1w_1.type === 'dblclick' ? 2 : 1;
  };
  protoOf(MouseEventJs).a17 = function () {
    return convertModifiers(this);
  };
  protoOf(MouseEventJs).d1a = function () {
    var tmp;
    var tmp_0 = this.i1w_1;
    if (tmp_0 instanceof WheelEvent) {
      tmp = Point2D_init_$Create$(-numberToInt(this.i1w_1.deltaX) | 0, -numberToInt(this.i1w_1.deltaY) | 0);
    } else {
      tmp = Companion_getInstance().g1a_1;
    }
    return tmp;
  };
  protoOf(MouseEventJs).z19 = function () {
    return this.g1w_1.c1c();
  };
  protoOf(MouseEventJs).a1a = function () {
    return this.g1w_1.d1c();
  };
  protoOf(MouseEventJs).consumeEvent = function () {
    this.i1w_1.preventDefault();
  };
  protoOf(MouseEventJs).isEventConsumed = function () {
    return this.i1w_1.defaultPrevented;
  };
  protoOf(MouseEventJs).e1a = function () {
    return this.b1a().equals(Button_BUTTON1_getInstance());
  };
  protoOf(MouseEventJs).f1a = function () {
    return this.b1a().equals(Button_BUTTON2_getInstance());
  };
  protoOf(MouseEventJs).toString = function () {
    return 'MouseEvent ' + this.k1w_1.toString();
  };
  function convertModifiers_0($this) {
    var modifiers = 0;
    if ($this.f1w_1.shiftKey) {
      modifiers = modifiers | Modifier_Shift_getInstance().mask;
    }
    if ($this.f1w_1.ctrlKey) {
      modifiers = modifiers | Modifier_Ctrl_getInstance().mask;
    }
    if ($this.f1w_1.metaKey) {
      modifiers = modifiers | Modifier_Meta_getInstance().mask;
    }
    if ($this.f1w_1.altKey) {
      modifiers = modifiers | Modifier_Alt_getInstance().mask;
    }
    return modifiers;
  }
  function convertEventType_0($this) {
    switch ($this.f1w_1.type) {
      case 'keydown':
        return KeyEventType_PRESSED_getInstance();
      case 'keyup':
        return KeyEventType_RELEASED_getInstance();
      default:
        return KeyEventType_TYPED_getInstance();
    }
  }
  function KeyEventJs(canvas, event) {
    this.e1w_1 = canvas;
    this.f1w_1 = event;
  }
  protoOf(KeyEventJs).y16 = function () {
    return this.f1w_1;
  };
  protoOf(KeyEventJs).u19 = function () {
    return convertEventType_0(this);
  };
  protoOf(KeyEventJs).i2 = function () {
    var tmp = get_keyboardEventKeyMap();
    // Inline function 'kotlin.text.lowercase' call
    // Inline function 'kotlin.js.asDynamic' call
    var tmp$ret$0 = this.f1w_1.key.toLowerCase();
    var tmp0_elvis_lhs = tmp.g2(tmp$ret$0);
    return tmp0_elvis_lhs == null ? 0 : tmp0_elvis_lhs;
  };
  protoOf(KeyEventJs).v19 = function () {
    return numberToChar(this.f1w_1.charCode);
  };
  protoOf(KeyEventJs).z16 = function () {
    return this.e1w_1;
  };
  protoOf(KeyEventJs).a17 = function () {
    return convertModifiers_0(this);
  };
  protoOf(KeyEventJs).consumeEvent = function () {
    this.f1w_1.preventDefault();
  };
  protoOf(KeyEventJs).isEventConsumed = function () {
    return this.f1w_1.defaultPrevented;
  };
  var properties_initialized_CanvasEvents_kt_uzzwmr;
  function _init_properties_CanvasEvents_kt__7kjjnz() {
    if (!properties_initialized_CanvasEvents_kt_uzzwmr) {
      properties_initialized_CanvasEvents_kt_uzzwmr = true;
      keyboardEventKeyMap = mapOf([to('arrowleft', Companion_instance.y17_1), to('arrowright', Companion_instance.z17_1), to('arrowup', Companion_instance.a18_1), to('arrowdown', Companion_instance.b18_1), to('arrowdown', Companion_instance.b18_1), to('escape', Companion_instance.c18_1), to('alt', Companion_instance.e18_1), to('enter', Companion_instance.d18_1), to('delete', Companion_instance.f18_1), to(' ', Companion_instance.g18_1), to('0', Companion_instance.l18_1), to('1', Companion_instance.m18_1), to('2', Companion_instance.n18_1), to('3', Companion_instance.o18_1), to('4', Companion_instance.p18_1), to('5', Companion_instance.q18_1), to('6', Companion_instance.r18_1), to('7', Companion_instance.s18_1), to('8', Companion_instance.t18_1), to('9', Companion_instance.u18_1), to('a', Companion_instance.v18_1), to('b', Companion_instance.w18_1), to('c', Companion_instance.x18_1), to('d', Companion_instance.y18_1), to('e', Companion_instance.z18_1), to('f', Companion_instance.a19_1), to('x', Companion_instance.b19_1), to('z', Companion_instance.c19_1)]);
    }
  }
  function _get_LOG__e5r759($this) {
    var tmp0 = $this.l1w_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('LOG', 1, tmp, CanvasJs$Companion$_get_LOG_$ref_z8go9t(), null);
    return tmp0.j2();
  }
  function CanvasJs$Companion$_get_LOG_$ref_z8go9t() {
    return function (p0) {
      return _get_LOG__e5r759(p0);
    };
  }
  function Companion_0() {
    Companion_instance_4 = this;
    this.l1w_1 = logger(getKClass(CanvasJs));
  }
  var Companion_instance_4;
  function Companion_getInstance_2() {
    if (Companion_instance_4 == null)
      new Companion_0();
    return Companion_instance_4;
  }
  function _get_mouseListeners__9yov67($this) {
    var tmp0 = $this.s1w_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('mouseListeners', 1, tmp, CanvasJs$_get_mouseListeners_$ref_jcxtz1(), null);
    return tmp0.j2();
  }
  function _get_mouseMotionListeners__dn4ljb($this) {
    var tmp0 = $this.t1w_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('mouseMotionListeners', 1, tmp, CanvasJs$_get_mouseMotionListeners_$ref_qktcp(), null);
    return tmp0.j2();
  }
  function _get_mouseWheelListeners__sj0sxk($this) {
    var tmp0 = $this.u1w_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('mouseWheelListeners', 1, tmp, CanvasJs$_get_mouseWheelListeners_$ref_giy2oc(), null);
    return tmp0.j2();
  }
  function _get_keyListeners__kpczth($this) {
    var tmp0 = $this.v1w_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('keyListeners', 1, tmp, CanvasJs$_get_keyListeners_$ref_39kcd(), null);
    return tmp0.j2();
  }
  function _get_devicePixelRatioHandler__9bgwn6($this) {
    var tmp = $this.z1w_1;
    if (!(tmp == null))
      return tmp;
    else {
      throwUninitializedPropertyAccessException('devicePixelRatioHandler');
    }
  }
  function throttledResize($this, event) {
    event = event === VOID ? null : event;
    $this.a1x_1.bq();
  }
  function initializeDevicePixelRatioHandler($this) {
    var tmp = $this;
    tmp.z1w_1 = CanvasJs$initializeDevicePixelRatioHandler$lambda($this);
  }
  function handleDevicePixelRatioChanged($this) {
    resize($this);
    $this.o1w_1.lr('PROP_DEVICE_PIXEL_RATIO', $this.b1x(), $this.b1x());
  }
  function resize($this) {
    var oldDimension = $this.c1x();
    var rect = $this.m1w_1.getBoundingClientRect();
    var dpr = window.devicePixelRatio;
    _get_LOG__e5r759(Companion_getInstance_2()).nl('Resize CanvasJs w=' + rect.width + ', h=' + rect.height);
    // Inline function 'kotlin.math.ceil' call
    var x = rect.width * dpr;
    var tmp$ret$0 = Math.ceil(x);
    $this.m1w_1.width = numberToInt(tmp$ret$0);
    // Inline function 'kotlin.math.ceil' call
    var x_0 = rect.height * dpr;
    var tmp$ret$1 = Math.ceil(x_0);
    $this.m1w_1.height = numberToInt(tmp$ret$1);
    $this.d1x();
    $this.o1w_1.lr('PROP_DIMENSION', oldDimension, $this.c1x());
  }
  function paint($this) {
    if (!$this.r1w_1) {
      $this.n1w_1.e1x($this.q1w_1);
    }
  }
  function windowToCanvas($this, event) {
    var rect = $this.m1w_1.getBoundingClientRect();
    return Point2D_init_$Create$(numberToInt((event.clientX - rect.left) * window.devicePixelRatio), numberToInt((event.clientY - rect.top) * window.devicePixelRatio));
  }
  function mouseEventBridgeOf($this, l) {
    var tmp0 = _get_mouseListeners__9yov67($this);
    var tmp$ret$0;
    $l$block: {
      // Inline function 'kotlin.collections.firstOrNull' call
      var _iterator__ex2g4s = tmp0.i();
      while (_iterator__ex2g4s.j()) {
        var element = _iterator__ex2g4s.k();
        if (element.s1v_1 === l) {
          tmp$ret$0 = element;
          break $l$block;
        }
      }
      tmp$ret$0 = null;
    }
    return tmp$ret$0;
  }
  function mouseMotionEventBridgeOf($this, l) {
    var tmp0 = _get_mouseMotionListeners__dn4ljb($this);
    var tmp$ret$0;
    $l$block: {
      // Inline function 'kotlin.collections.firstOrNull' call
      var _iterator__ex2g4s = tmp0.i();
      while (_iterator__ex2g4s.j()) {
        var element = _iterator__ex2g4s.k();
        if (element.w1v_1 === l) {
          tmp$ret$0 = element;
          break $l$block;
        }
      }
      tmp$ret$0 = null;
    }
    return tmp$ret$0;
  }
  function mouseWheelEventBridgeOf($this, l) {
    var tmp0 = _get_mouseWheelListeners__sj0sxk($this);
    var tmp$ret$0;
    $l$block: {
      // Inline function 'kotlin.collections.firstOrNull' call
      var _iterator__ex2g4s = tmp0.i();
      while (_iterator__ex2g4s.j()) {
        var element = _iterator__ex2g4s.k();
        if (element.a1w_1 === l) {
          tmp$ret$0 = element;
          break $l$block;
        }
      }
      tmp$ret$0 = null;
    }
    return tmp$ret$0;
  }
  function keyEventBridgeOf($this, l) {
    var tmp0 = _get_keyListeners__kpczth($this);
    var tmp$ret$0;
    $l$block: {
      // Inline function 'kotlin.collections.firstOrNull' call
      var _iterator__ex2g4s = tmp0.i();
      while (_iterator__ex2g4s.j()) {
        var element = _iterator__ex2g4s.k();
        if (element.c1w_1 === l) {
          tmp$ret$0 = element;
          break $l$block;
        }
      }
      tmp$ret$0 = null;
    }
    return tmp$ret$0;
  }
  function CanvasJs$mouseListeners$delegate$lambda() {
    // Inline function 'kotlin.collections.mutableListOf' call
    return ArrayList_init_$Create$();
  }
  function CanvasJs$_get_mouseListeners_$ref_jcxtz1() {
    return function (p0) {
      return _get_mouseListeners__9yov67(p0);
    };
  }
  function CanvasJs$mouseMotionListeners$delegate$lambda() {
    // Inline function 'kotlin.collections.mutableListOf' call
    return ArrayList_init_$Create$();
  }
  function CanvasJs$_get_mouseMotionListeners_$ref_qktcp() {
    return function (p0) {
      return _get_mouseMotionListeners__dn4ljb(p0);
    };
  }
  function CanvasJs$mouseWheelListeners$delegate$lambda() {
    // Inline function 'kotlin.collections.mutableListOf' call
    return ArrayList_init_$Create$();
  }
  function CanvasJs$_get_mouseWheelListeners_$ref_giy2oc() {
    return function (p0) {
      return _get_mouseWheelListeners__sj0sxk(p0);
    };
  }
  function CanvasJs$keyListeners$delegate$lambda() {
    // Inline function 'kotlin.collections.mutableListOf' call
    return ArrayList_init_$Create$();
  }
  function CanvasJs$_get_keyListeners_$ref_39kcd() {
    return function (p0) {
      return _get_keyListeners__kpczth(p0);
    };
  }
  function CanvasJs$resize$ref(p0) {
    var l = function () {
      var tmp0 = p0;
      resize(tmp0);
      return Unit_instance;
    };
    l.callableName = 'resize';
    return l;
  }
  function CanvasJs$throttledResize$ref(p0) {
    var l = function (_this__u8e3s4) {
      var tmp0 = p0;
      throttledResize(tmp0, _this__u8e3s4);
      return Unit_instance;
    };
    l.callableName = 'throttledResize';
    return l;
  }
  function CanvasJs$initializeDevicePixelRatioHandler$lambda$lambda($media, this$0) {
    return function (it) {
      $media.removeEventListener('change', _get_devicePixelRatioHandler__9bgwn6(this$0));
      return Unit_instance;
    };
  }
  function CanvasJs$initializeDevicePixelRatioHandler$lambda(this$0) {
    return function (it) {
      var tmp0_safe_receiver = this$0.y1w_1;
      if (tmp0_safe_receiver == null)
        null;
      else
        tmp0_safe_receiver(null);
      var mqString = '(resolution: ' + window.devicePixelRatio + 'dppx';
      var media = window.matchMedia(mqString);
      media.addEventListener('change', _get_devicePixelRatioHandler__9bgwn6(this$0));
      var tmp = this$0;
      tmp.y1w_1 = CanvasJs$initializeDevicePixelRatioHandler$lambda$lambda(media, this$0);
      handleDevicePixelRatioChanged(this$0);
      return Unit_instance;
    };
  }
  function CanvasJs$windowToCanvas$ref(p0) {
    var l = function (_this__u8e3s4) {
      var tmp0 = p0;
      return windowToCanvas(tmp0, _this__u8e3s4);
    };
    l.callableName = 'windowToCanvas';
    return l;
  }
  function CanvasJs$windowToCanvas$ref_0(p0) {
    var l = function (_this__u8e3s4) {
      var tmp0 = p0;
      return windowToCanvas(tmp0, _this__u8e3s4);
    };
    l.callableName = 'windowToCanvas';
    return l;
  }
  function CanvasJs$windowToCanvas$ref_1(p0) {
    var l = function (_this__u8e3s4) {
      var tmp0 = p0;
      return windowToCanvas(tmp0, _this__u8e3s4);
    };
    l.callableName = 'windowToCanvas';
    return l;
  }
  function CanvasJs(canvas, view, styleProvider, propertyOwner) {
    Companion_getInstance_2();
    styleProvider = styleProvider === VOID ? DrawStyleModule_getInstance().g1x_1 : styleProvider;
    propertyOwner = propertyOwner === VOID ? new PropertyOwnerImpl() : propertyOwner;
    this.m1w_1 = canvas;
    this.n1w_1 = view;
    this.o1w_1 = propertyOwner;
    var tmp = this;
    var tmp_0 = ensureNotNull(this.m1w_1.getContext('2d'));
    tmp.p1w_1 = tmp_0 instanceof CanvasRenderingContext2D ? tmp_0 : THROW_CCE();
    this.q1w_1 = new Graphics2DJs(this.p1w_1);
    this.r1w_1 = true;
    var tmp_1 = this;
    tmp_1.s1w_1 = lazy(CanvasJs$mouseListeners$delegate$lambda);
    var tmp_2 = this;
    tmp_2.t1w_1 = lazy(CanvasJs$mouseMotionListeners$delegate$lambda);
    var tmp_3 = this;
    tmp_3.u1w_1 = lazy(CanvasJs$mouseWheelListeners$delegate$lambda);
    var tmp_4 = this;
    tmp_4.v1w_1 = lazy(CanvasJs$keyListeners$delegate$lambda);
    this.w1w_1 = styleProvider.p1x(Companion_getInstance_33().n1x_1).m1t().i1x_1;
    this.x1w_1 = null;
    this.y1w_1 = null;
    var tmp_5 = this;
    tmp_5.a1x_1 = new Throttle(CanvasJs$resize$ref(this), 100);
    this.o1w_1.d1b(this);
    this.n1w_1.q1x(this);
    this.n1w_1.ro();
    this.r1w_1 = false;
    initializeDevicePixelRatioHandler(this);
    _get_devicePixelRatioHandler__9bgwn6(this)(null);
    var tmp_6 = window;
    tmp_6.addEventListener('resize', CanvasJs$throttledResize$ref(this));
  }
  protoOf(CanvasJs).f1o = function () {
    return this.n1w_1;
  };
  protoOf(CanvasJs).b1x = function () {
    return window.devicePixelRatio;
  };
  protoOf(CanvasJs).c1x = function () {
    return Dimension2D_init_$Create$(this.m1w_1.width, this.m1w_1.height);
  };
  protoOf(CanvasJs).r1x = function () {
    throw UnsupportedOperationException_init_$Create$('getting mouseLocation not yet implemented');
  };
  protoOf(CanvasJs).s1x = function () {
    return true;
  };
  protoOf(CanvasJs).t1x = function () {
    return false;
  };
  protoOf(CanvasJs).u1x = function () {
    this.m1w_1.focus();
  };
  protoOf(CanvasJs).v1x = function (cursor) {
    switch (cursor.l2_1) {
      case 0:
        this.m1w_1.style.cursor = 'default';
        break;
      case 1:
        this.m1w_1.style.cursor = 'wait';
        break;
      case 2:
        this.m1w_1.style.cursor = 'pointer';
        break;
      case 3:
        this.m1w_1.style.cursor = 'move';
        break;
      case 4:
        this.m1w_1.style.cursor = 'crosshair';
        break;
      case 5:
        this.m1w_1.style.cursor = 'nw-resize';
        break;
      case 6:
        this.m1w_1.style.cursor = 'n-resize';
        break;
      case 7:
        this.m1w_1.style.cursor = 'ne-resize';
        break;
      case 8:
        this.m1w_1.style.cursor = 'e-resize';
        break;
      case 9:
        this.m1w_1.style.cursor = 'se-resize';
        break;
      case 10:
        this.m1w_1.style.cursor = 's-resize';
        break;
      case 11:
        this.m1w_1.style.cursor = 'sw-resize';
        break;
      case 12:
        this.m1w_1.style.cursor = 'w-resize';
        break;
      case 13:
        this.m1w_1.style.cursor = 'text';
        break;
      default:
        noWhenBranchMatchedException();
        break;
    }
  };
  protoOf(CanvasJs).d1x = function () {
    this.w1x(0, 0, this.m1w_1.width, this.m1w_1.height);
  };
  protoOf(CanvasJs).w1x = function (x, y, width, height) {
    var xx = 0;
    var yy = 0;
    var ww = this.m1w_1.width;
    var hh = this.m1w_1.height;
    this.q1w_1.v1r_1.s1b(xx, yy, ww, hh);
    this.p1w_1.save();
    this.p1w_1.setTransform(1.0, 0.0, 0.0, 1.0, 0.0, 0.0);
    this.p1w_1.fillStyle = 'rgba(' + this.w1w_1.x1x_1 + ',' + this.w1w_1.y1x_1 + ', ' + this.w1w_1.z1x_1 + ', 1.0)';
    this.p1w_1.fillRect(xx, yy, ww, hh);
    this.p1w_1.restore();
    var dpr = this.b1x();
    this.p1w_1.scale(dpr, dpr);
    paint(this);
    this.p1w_1.scale(1 / dpr, 1 / dpr);
  };
  protoOf(CanvasJs).b1y = function (l) {
    var bridge = mouseEventBridgeOf(this, l);
    if (bridge == null) {
      bridge = new MouseEventBridge(CanvasJs$windowToCanvas$ref(this), l, this.m1w_1);
      this.m1w_1.addEventListener('mousedown', bridge);
      this.m1w_1.addEventListener('mouseup', bridge);
      this.m1w_1.addEventListener('click', bridge);
      this.m1w_1.addEventListener('dblclick', bridge);
      _get_mouseListeners__9yov67(this).h(bridge);
    }
  };
  protoOf(CanvasJs).c1y = function (l) {
    var bridge = mouseEventBridgeOf(this, l);
    if (!(bridge == null)) {
      this.m1w_1.removeEventListener('mousedown', bridge);
      this.m1w_1.removeEventListener('mouseup', bridge);
      this.m1w_1.removeEventListener('click', bridge);
      this.m1w_1.removeEventListener('dblclick', bridge);
      _get_mouseListeners__9yov67(this).h2(bridge);
    }
  };
  protoOf(CanvasJs).d1y = function (l) {
    var bridge = mouseMotionEventBridgeOf(this, l);
    if (bridge == null) {
      bridge = new MouseMotionEventBridge(CanvasJs$windowToCanvas$ref_0(this), l, this.m1w_1);
      this.m1w_1.addEventListener('mousedown', bridge);
      this.m1w_1.addEventListener('mouseup', bridge);
      this.m1w_1.addEventListener('mousemove', bridge);
      _get_mouseMotionListeners__dn4ljb(this).h(bridge);
    }
  };
  protoOf(CanvasJs).e1y = function (l) {
    var bridge = mouseMotionEventBridgeOf(this, l);
    if (!(bridge == null)) {
      this.m1w_1.removeEventListener('mousedown', bridge);
      this.m1w_1.removeEventListener('mouseup', bridge);
      this.m1w_1.removeEventListener('mousemove', bridge);
      _get_mouseMotionListeners__dn4ljb(this).h2(bridge);
    }
  };
  protoOf(CanvasJs).f1y = function (l) {
    var bridge = mouseWheelEventBridgeOf(this, l);
    if (bridge == null) {
      bridge = new MouseWheelEventBridge(CanvasJs$windowToCanvas$ref_1(this), l, this.m1w_1);
      this.m1w_1.addEventListener('wheel', bridge);
      _get_mouseWheelListeners__sj0sxk(this).h(bridge);
    }
  };
  protoOf(CanvasJs).g1y = function (l) {
    var bridge = mouseWheelEventBridgeOf(this, l);
    if (!(bridge == null)) {
      this.m1w_1.removeEventListener('wheel', bridge);
      _get_mouseWheelListeners__sj0sxk(this).h2(bridge);
    }
  };
  protoOf(CanvasJs).h1y = function (l) {
    var bridge = keyEventBridgeOf(this, l);
    if (bridge == null) {
      bridge = new KeyEventBridge(l, this.m1w_1);
      this.m1w_1.addEventListener('keydown', bridge);
      this.m1w_1.addEventListener('keyup', bridge);
    }
  };
  protoOf(CanvasJs).i1y = function (l) {
    var bridge = keyEventBridgeOf(this, l);
    if (!(bridge == null)) {
      this.m1w_1.removeEventListener('keydown', bridge);
      this.m1w_1.removeEventListener('keyup', bridge);
      _get_keyListeners__kpczth(this).h2(bridge);
    }
  };
  protoOf(CanvasJs).j1y = function (e) {
  };
  protoOf(CanvasJs).k1y = function (name, oldValue, newValue) {
  };
  protoOf(CanvasJs).lr = function (name, oldValue, newValue) {
    return this.k1y(name, oldValue, newValue);
  };
  protoOf(CanvasJs).l1y = function (l) {
    this.o1w_1.e1b(l);
  };
  protoOf(CanvasJs).e1b = function (l) {
    return this.l1y(l);
  };
  protoOf(CanvasJs).m1y = function (l) {
    this.o1w_1.f1b(l);
  };
  protoOf(CanvasJs).f1b = function (l) {
    return this.m1y(l);
  };
  protoOf(CanvasJs).d1b = function (_set____db54di) {
    this.o1w_1.d1b(_set____db54di);
  };
  function fillProperties($this, properties) {
    properties.ct('draw.view.tooltipsEnabled', true);
    properties.ct('view.ZoomPanController.wheelZoomRequiredMeta', true);
  }
  function DrawModuleJs() {
    DrawModuleJs_instance = this;
    AbstractModule.call(this);
  }
  protoOf(DrawModuleJs).ro = function () {
    BaseModuleJs_getInstance().to();
    DrawModule_getInstance().to();
    fillProperties(this, BaseModule_getInstance().xo_1);
  };
  var DrawModuleJs_instance;
  function DrawModuleJs_getInstance() {
    if (DrawModuleJs_instance == null)
      new DrawModuleJs();
    return DrawModuleJs_instance;
  }
  function Companion_1() {
    this.o1y_1 = 'PROP_APPLICATION_CONTEXT';
  }
  var Companion_instance_5;
  function Companion_getInstance_3() {
    return Companion_instance_5;
  }
  function ApplicationContextHolder(applicationContext, propertyOwner) {
    applicationContext = applicationContext === VOID ? null : applicationContext;
    propertyOwner = propertyOwner === VOID ? new PropertyOwnerImpl() : propertyOwner;
    this.p1y_1 = propertyOwner;
    this.q1y_1 = applicationContext;
    this.p1y_1.d1b(this);
  }
  protoOf(ApplicationContextHolder).r1y = function (value) {
    var oldValue = this.q1y_1;
    this.q1y_1 = value;
    this.p1y_1.lr('PROP_APPLICATION_CONTEXT', oldValue, value);
  };
  protoOf(ApplicationContextHolder).l1y = function (l) {
    this.p1y_1.e1b(l);
  };
  protoOf(ApplicationContextHolder).e1b = function (l) {
    return this.l1y(l);
  };
  protoOf(ApplicationContextHolder).m1y = function (l) {
    this.p1y_1.f1b(l);
  };
  protoOf(ApplicationContextHolder).f1b = function (l) {
    return this.m1y(l);
  };
  protoOf(ApplicationContextHolder).k1y = function (name, oldValue, newValue) {
    this.p1y_1.lr(name, oldValue, newValue);
  };
  protoOf(ApplicationContextHolder).lr = function (name, oldValue, newValue) {
    return this.k1y(name, oldValue, newValue);
  };
  protoOf(ApplicationContextHolder).d1b = function (_set____db54di) {
    this.p1y_1.d1b(_set____db54di);
  };
  function PopupMenuEvent(canvas) {
    this.s1y_1 = canvas;
  }
  protoOf(PopupMenuEvent).toString = function () {
    return 'PopupMenuEvent(canvas=' + toString(this.s1y_1) + ')';
  };
  protoOf(PopupMenuEvent).hashCode = function () {
    return hashCode(this.s1y_1);
  };
  protoOf(PopupMenuEvent).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof PopupMenuEvent))
      return false;
    if (!equals(this.s1y_1, other.s1y_1))
      return false;
    return true;
  };
  function DrawContext(g, modelClip, appContext) {
    modelClip = modelClip === VOID ? null : modelClip;
    appContext = appContext === VOID ? null : appContext;
    this.t1y_1 = g;
    this.u1y_1 = modelClip;
    this.v1y_1 = appContext;
    this.w1y_1 = false;
    this.x1y_1 = null;
    this.y1y_1 = null;
    this.z1y_1 = null;
  }
  protoOf(DrawContext).a1z = function (color) {
    return this.w1y_1 ? ensureNotNull(this.x1y_1) : color;
  };
  protoOf(DrawContext).b1z = function (color) {
    return this.w1y_1 ? ensureNotNull(this.x1y_1).h1x_1 : color;
  };
  protoOf(DrawContext).c1z = function (color) {
    return this.w1y_1 ? ensureNotNull(this.x1y_1).i1x_1 : color;
  };
  protoOf(DrawContext).d1z = function (color) {
    return this.w1y_1 ? ensureNotNull(this.x1y_1).j1x_1 : color;
  };
  protoOf(DrawContext).e1z = function () {
    return this.v1y_1;
  };
  protoOf(DrawContext).f1z = function (defaultColor) {
    var tmp0_safe_receiver = this.y1y_1;
    var tmp1_elvis_lhs = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.m1t();
    return tmp1_elvis_lhs == null ? defaultColor : tmp1_elvis_lhs;
  };
  function DrawProperties(target) {
    target = target === VOID ? BaseModule_getInstance().xo_1 : target;
    PropertiesProxy.call(this, target);
  }
  protoOf(DrawProperties).i1z = function (name) {
    return this.ot_1.lt(name);
  };
  protoOf(DrawProperties).j1z = function (name) {
    return this.ot_1.lt(name);
  };
  protoOf(DrawProperties).k1z = function (name) {
    return this.ot_1.lt(name);
  };
  function Drawable() {
  }
  function DrawableExplanation(explanation, sourceRect) {
    this.a20_1 = explanation;
    this.b20_1 = sourceRect;
  }
  protoOf(DrawableExplanation).toString = function () {
    return 'DrawableExplanation(explanation=' + toString(this.a20_1) + ', sourceRect=' + toString(this.b20_1) + ')';
  };
  protoOf(DrawableExplanation).hashCode = function () {
    var result = hashCode(this.a20_1);
    result = imul(result, 31) + hashCode(this.b20_1) | 0;
    return result;
  };
  protoOf(DrawableExplanation).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof DrawableExplanation))
      return false;
    if (!equals(this.a20_1, other.a20_1))
      return false;
    if (!equals(this.b20_1, other.b20_1))
      return false;
    return true;
  };
  function DrawableBag$backToFrontIterator$1($iter) {
    this.c20_1 = $iter;
  }
  protoOf(DrawableBag$backToFrontIterator$1).j = function () {
    return this.c20_1.n3();
  };
  protoOf(DrawableBag$backToFrontIterator$1).k = function () {
    return this.c20_1.o3();
  };
  function DrawableBag$getDrawableAt$lambda(it) {
    return true;
  }
  function DrawableBag$getDrawableAt$lambda_0(it) {
    return true;
  }
  function DrawableBag$getDrawableIntersection$lambda(it) {
    return true;
  }
  function DrawableBag() {
  }
  function DrawableContainer() {
  }
  function DrawableContainerEvent(container, child) {
    this.g21_1 = container;
    this.h21_1 = child;
  }
  protoOf(DrawableContainerEvent).toString = function () {
    return 'DrawableContainerEvent(container=' + toString(this.g21_1) + ', child=' + toString(this.h21_1) + ')';
  };
  protoOf(DrawableContainerEvent).hashCode = function () {
    var result = hashCode(this.g21_1);
    result = imul(result, 31) + hashCode(this.h21_1) | 0;
    return result;
  };
  protoOf(DrawableContainerEvent).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof DrawableContainerEvent))
      return false;
    if (!equals(this.g21_1, other.g21_1))
      return false;
    if (!equals(this.h21_1, other.h21_1))
      return false;
    return true;
  };
  function DrawableContainerListener() {
  }
  function DrawableEvent_init_$Init$(source, $this) {
    DrawableEvent.call($this, source, Rectangle2D_init_$Create$(source.do()));
    return $this;
  }
  function DrawableEvent_init_$Create$(source) {
    return DrawableEvent_init_$Init$(source, objectCreate(protoOf(DrawableEvent)));
  }
  function DrawableEvent(source, area) {
    this.k21_1 = source;
    this.l21_1 = area;
  }
  protoOf(DrawableEvent).toString = function () {
    return 'DrawableEvent(source=' + toString(this.k21_1) + ', area=' + toString(this.l21_1) + ')';
  };
  protoOf(DrawableEvent).hashCode = function () {
    var result = hashCode(this.k21_1);
    result = imul(result, 31) + hashCode(this.l21_1) | 0;
    return result;
  };
  protoOf(DrawableEvent).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof DrawableEvent))
      return false;
    if (!equals(this.k21_1, other.k21_1))
      return false;
    if (!equals(this.l21_1, other.l21_1))
      return false;
    return true;
  };
  function DrawableAdapter() {
  }
  protoOf(DrawableAdapter).m21 = function (event) {
  };
  protoOf(DrawableAdapter).n21 = function (event) {
  };
  protoOf(DrawableAdapter).o21 = function (event) {
  };
  function Focusable() {
  }
  function _set_focusOwner__ald35o($this, value) {
    if (equals($this.r21_1, value)) {
      return Unit_instance;
    }
    if (!(value == null) && !value.p21()) {
      return Unit_instance;
    }
    var oldValue = $this.r21_1;
    $this.r21_1 = value;
    if (oldValue == null)
      null;
    else {
      oldValue.v21();
    }
    var tmp1_safe_receiver = $this.r21_1;
    if (tmp1_safe_receiver == null)
      null;
    else {
      tmp1_safe_receiver.u21();
    }
  }
  function FocusManager() {
    this.r21_1 = null;
  }
  protoOf(FocusManager).t21 = function (c) {
    _set_focusOwner__ald35o(this, c);
  };
  protoOf(FocusManager).w21 = function () {
    _set_focusOwner__ald35o(this, null);
  };
  var FocusManager_instance;
  function FocusManager_getInstance() {
    return FocusManager_instance;
  }
  function InputEventContext(view, mouseEvent, keyEvent, x, y, readonly) {
    mouseEvent = mouseEvent === VOID ? null : mouseEvent;
    keyEvent = keyEvent === VOID ? null : keyEvent;
    x = x === VOID ? 0.0 : x;
    y = y === VOID ? 0.0 : y;
    readonly = readonly === VOID ? false : readonly;
    this.x21_1 = view;
    this.y21_1 = mouseEvent;
    this.z21_1 = keyEvent;
    this.a22_1 = x;
    this.b22_1 = y;
    this.c22_1 = readonly;
    this.d22_1 = new Point2D(this.a22_1, this.b22_1);
  }
  protoOf(InputEventContext).e22 = function (p) {
    return this.f22(p.in_1, p.jn_1);
  };
  protoOf(InputEventContext).f22 = function (x, y) {
    return new InputEventContext(this.x21_1, this.y21_1, this.z21_1, x, y);
  };
  protoOf(InputEventContext).toString = function () {
    var tmp0_safe_receiver = this.y21_1;
    var tmp1_elvis_lhs = tmp0_safe_receiver == null ? null : toString(tmp0_safe_receiver);
    var tmp;
    if (tmp1_elvis_lhs == null) {
      var tmp2_safe_receiver = this.z21_1;
      tmp = tmp2_safe_receiver == null ? null : toString(tmp2_safe_receiver);
    } else {
      tmp = tmp1_elvis_lhs;
    }
    var tmp3_elvis_lhs = tmp;
    return tmp3_elvis_lhs == null ? '' : tmp3_elvis_lhs;
  };
  function Companion_2() {
    Companion_instance_6 = this;
    this.g22_1 = new InputEventHandlerAdapter();
  }
  var Companion_instance_6;
  function Companion_getInstance_4() {
    if (Companion_instance_6 == null)
      new Companion_2();
    return Companion_instance_6;
  }
  function InputEventHandlerAdapter$_init_$lambda_h27nti(it) {
    return null;
  }
  function InputEventHandlerAdapter(successor) {
    Companion_getInstance_4();
    var tmp;
    if (successor === VOID) {
      tmp = InputEventHandlerAdapter$_init_$lambda_h27nti;
    } else {
      tmp = successor;
    }
    successor = tmp;
    this.h22_1 = successor;
  }
  protoOf(InputEventHandlerAdapter).i22 = function (context) {
    var tmp0_safe_receiver = this.h22_1(context);
    return tmp0_safe_receiver == null ? null : tmp0_safe_receiver.i22(context);
  };
  protoOf(InputEventHandlerAdapter).j22 = function (context) {
    var tmp0_safe_receiver = this.h22_1(context);
    return tmp0_safe_receiver == null ? null : tmp0_safe_receiver.j22(context);
  };
  protoOf(InputEventHandlerAdapter).k22 = function (context) {
    var tmp0_safe_receiver = this.h22_1(context);
    return tmp0_safe_receiver == null ? null : tmp0_safe_receiver.k22(context);
  };
  protoOf(InputEventHandlerAdapter).l22 = function (context) {
    var tmp0_safe_receiver = this.h22_1(context);
    return tmp0_safe_receiver == null ? null : tmp0_safe_receiver.l22(context);
  };
  protoOf(InputEventHandlerAdapter).m22 = function (context) {
    var tmp0_safe_receiver = this.h22_1(context);
    return tmp0_safe_receiver == null ? null : tmp0_safe_receiver.m22(context);
  };
  protoOf(InputEventHandlerAdapter).n22 = function (context) {
    var tmp0_safe_receiver = this.h22_1(context);
    return tmp0_safe_receiver == null ? null : tmp0_safe_receiver.n22(context);
  };
  protoOf(InputEventHandlerAdapter).o22 = function (context) {
    var tmp0_safe_receiver = this.h22_1(context);
    return tmp0_safe_receiver == null ? null : tmp0_safe_receiver.o22(context);
  };
  function InputEventHandler() {
  }
  function StateMachineInputEventHandler$Companion$mouseMoved$lambda(it) {
    var tmp0_safe_receiver = it.y21_1;
    return equals(tmp0_safe_receiver == null ? null : tmp0_safe_receiver.u19(), MouseEventType_MOVED_getInstance());
  }
  function StateMachineInputEventHandler$Companion$mouseDragged$lambda(it) {
    var tmp0_safe_receiver = it.y21_1;
    return equals(tmp0_safe_receiver == null ? null : tmp0_safe_receiver.u19(), MouseEventType_DRAGGED_getInstance());
  }
  function StateMachineInputEventHandler$Companion$mouseLeftPressed$lambda(it) {
    var tmp;
    var tmp0_safe_receiver = it.y21_1;
    if (equals(tmp0_safe_receiver == null ? null : tmp0_safe_receiver.u19(), MouseEventType_PRESSED_getInstance())) {
      tmp = it.y21_1.e1a();
    } else {
      tmp = false;
    }
    return tmp;
  }
  function StateMachineInputEventHandler$Companion$mouseLeftReleased$lambda(it) {
    var tmp;
    var tmp0_safe_receiver = it.y21_1;
    if (equals(tmp0_safe_receiver == null ? null : tmp0_safe_receiver.u19(), MouseEventType_RELEASED_getInstance())) {
      tmp = it.y21_1.e1a();
    } else {
      tmp = false;
    }
    return tmp;
  }
  function StateMachineInputEventHandler$Companion$mouseLeftClicked$lambda(it) {
    var tmp;
    var tmp0_safe_receiver = it.y21_1;
    if (equals(tmp0_safe_receiver == null ? null : tmp0_safe_receiver.u19(), MouseEventType_CLICKED_getInstance())) {
      tmp = it.y21_1.e1a();
    } else {
      tmp = false;
    }
    return tmp;
  }
  function StateMachineInputEventHandler$Companion$mouseLeftSingleClicked$lambda(it) {
    var tmp;
    var tmp_0;
    var tmp0_safe_receiver = it.y21_1;
    if (equals(tmp0_safe_receiver == null ? null : tmp0_safe_receiver.u19(), MouseEventType_CLICKED_getInstance())) {
      tmp_0 = it.y21_1.e1a();
    } else {
      tmp_0 = false;
    }
    if (tmp_0) {
      tmp = !(it.y21_1.c1a() === 2);
    } else {
      tmp = false;
    }
    return tmp;
  }
  function StateMachineInputEventHandler$Companion$mouseLeftDoubleClicked$lambda(it) {
    var tmp;
    var tmp_0;
    var tmp0_safe_receiver = it.y21_1;
    if (equals(tmp0_safe_receiver == null ? null : tmp0_safe_receiver.u19(), MouseEventType_CLICKED_getInstance())) {
      tmp_0 = it.y21_1.e1a();
    } else {
      tmp_0 = false;
    }
    if (tmp_0) {
      tmp = it.y21_1.c1a() === 2;
    } else {
      tmp = false;
    }
    return tmp;
  }
  function StateMachineInputEventHandler$Companion$keyReleased$lambda(it) {
    var tmp0_safe_receiver = it.z21_1;
    return equals(tmp0_safe_receiver == null ? null : tmp0_safe_receiver.u19(), KeyEventType_RELEASED_getInstance());
  }
  function StateMachineInputEventHandler$Companion$escapePressed$lambda(it) {
    var tmp;
    var tmp0_safe_receiver = it.z21_1;
    if (equals(tmp0_safe_receiver == null ? null : tmp0_safe_receiver.u19(), KeyEventType_PRESSED_getInstance())) {
      tmp = it.z21_1.i2() === Companion_instance.c18_1;
    } else {
      tmp = false;
    }
    return tmp;
  }
  function StateMachineInputEventHandler$Companion$altPressed$lambda(it) {
    var tmp;
    var tmp0_safe_receiver = it.z21_1;
    if (equals(tmp0_safe_receiver == null ? null : tmp0_safe_receiver.u19(), KeyEventType_PRESSED_getInstance())) {
      tmp = it.z21_1.i2() === Companion_instance.e18_1;
    } else {
      tmp = false;
    }
    return tmp;
  }
  function StateMachineInputEventHandler$Companion$altReleased$lambda(it) {
    var tmp;
    var tmp0_safe_receiver = it.z21_1;
    if (equals(tmp0_safe_receiver == null ? null : tmp0_safe_receiver.u19(), KeyEventType_RELEASED_getInstance())) {
      tmp = it.z21_1.i2() === Companion_instance.e18_1;
    } else {
      tmp = false;
    }
    return tmp;
  }
  function Companion_3() {
    Companion_instance_7 = this;
    var tmp = this;
    tmp.p22_1 = StateMachineInputEventHandler$Companion$mouseMoved$lambda;
    var tmp_0 = this;
    tmp_0.q22_1 = StateMachineInputEventHandler$Companion$mouseDragged$lambda;
    var tmp_1 = this;
    tmp_1.r22_1 = StateMachineInputEventHandler$Companion$mouseLeftPressed$lambda;
    var tmp_2 = this;
    tmp_2.s22_1 = StateMachineInputEventHandler$Companion$mouseLeftReleased$lambda;
    var tmp_3 = this;
    tmp_3.t22_1 = StateMachineInputEventHandler$Companion$mouseLeftClicked$lambda;
    var tmp_4 = this;
    tmp_4.u22_1 = StateMachineInputEventHandler$Companion$mouseLeftSingleClicked$lambda;
    var tmp_5 = this;
    tmp_5.v22_1 = StateMachineInputEventHandler$Companion$mouseLeftDoubleClicked$lambda;
    var tmp_6 = this;
    tmp_6.w22_1 = StateMachineInputEventHandler$Companion$keyReleased$lambda;
    var tmp_7 = this;
    tmp_7.x22_1 = StateMachineInputEventHandler$Companion$escapePressed$lambda;
    var tmp_8 = this;
    tmp_8.y22_1 = StateMachineInputEventHandler$Companion$altPressed$lambda;
    var tmp_9 = this;
    tmp_9.z22_1 = StateMachineInputEventHandler$Companion$altReleased$lambda;
  }
  var Companion_instance_7;
  function Companion_getInstance_5() {
    if (Companion_instance_7 == null)
      new Companion_3();
    return Companion_instance_7;
  }
  function StateMachineInputEventHandler(sm, successor) {
    Companion_getInstance_5();
    successor = successor === VOID ? null : successor;
    this.a23_1 = sm;
    this.b23_1 = successor;
    if (this.a23_1.c1m_1.equals(UnhandledEventBehaviour_Strict_getInstance())) {
      throw IllegalArgumentException_init_$Create$('StateMachine must not be strict');
    }
  }
  protoOf(StateMachineInputEventHandler).i22 = function (context) {
    var tmp0_safe_receiver = context.y21_1;
    if (!equals(tmp0_safe_receiver == null ? null : tmp0_safe_receiver.b1a(), Button_BUTTON1_getInstance())) {
      return this;
    }
    var tmp;
    if (this.a23_1.t1l(context)) {
      tmp = this;
    } else {
      var tmp1_safe_receiver = this.b23_1;
      tmp = tmp1_safe_receiver == null ? null : tmp1_safe_receiver.i22(context);
    }
    return tmp;
  };
  protoOf(StateMachineInputEventHandler).j22 = function (context) {
    var tmp;
    if (this.a23_1.t1l(context)) {
      tmp = this;
    } else {
      var tmp0_safe_receiver = this.b23_1;
      tmp = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.j22(context);
    }
    return tmp;
  };
  protoOf(StateMachineInputEventHandler).k22 = function (context) {
    var tmp;
    if (this.a23_1.t1l(context)) {
      tmp = this;
    } else {
      var tmp0_safe_receiver = this.b23_1;
      tmp = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.k22(context);
    }
    return tmp;
  };
  protoOf(StateMachineInputEventHandler).l22 = function (context) {
    var tmp;
    if (this.a23_1.t1l(context)) {
      tmp = this;
    } else {
      var tmp0_safe_receiver = this.b23_1;
      tmp = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.l22(context);
    }
    return tmp;
  };
  protoOf(StateMachineInputEventHandler).m22 = function (context) {
    var tmp;
    if (this.a23_1.t1l(context)) {
      tmp = this;
    } else {
      var tmp0_safe_receiver = this.b23_1;
      tmp = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.m22(context);
    }
    return tmp;
  };
  protoOf(StateMachineInputEventHandler).n22 = function (context) {
    var tmp;
    if (this.a23_1.t1l(context)) {
      tmp = this;
    } else {
      var tmp0_safe_receiver = this.b23_1;
      tmp = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.n22(context);
    }
    return tmp;
  };
  protoOf(StateMachineInputEventHandler).o22 = function (context) {
    var tmp;
    if (this.a23_1.t1l(context)) {
      tmp = this;
    } else {
      var tmp0_safe_receiver = this.b23_1;
      tmp = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.o22(context);
    }
    return tmp;
  };
  function View() {
  }
  function Companion_4() {
  }
  protoOf(Companion_4).w24 = function () {
    var tmp = ZoomPan_init_$Create$();
    // Inline function 'kotlin.apply' call
    var this_0 = System_getInstance().zl();
    this_0.b1d();
    return new ViewTransformation(tmp, this_0);
  };
  var Companion_instance_8;
  function Companion_getInstance_6() {
    return Companion_instance_8;
  }
  function ViewTransformation(zoomPan, affineTransform) {
    this.x24_1 = zoomPan;
    this.y24_1 = affineTransform;
  }
  protoOf(ViewTransformation).z24 = function (zoomPan, affineTransform) {
    return new ViewTransformation(zoomPan, affineTransform);
  };
  protoOf(ViewTransformation).a25 = function (zoomPan, affineTransform, $super) {
    zoomPan = zoomPan === VOID ? this.x24_1 : zoomPan;
    affineTransform = affineTransform === VOID ? this.y24_1 : affineTransform;
    return $super === VOID ? this.z24(zoomPan, affineTransform) : $super.z24.call(this, zoomPan, affineTransform);
  };
  protoOf(ViewTransformation).toString = function () {
    return 'ViewTransformation(zoomPan=' + this.x24_1.toString() + ', affineTransform=' + toString(this.y24_1) + ')';
  };
  protoOf(ViewTransformation).hashCode = function () {
    var result = this.x24_1.hashCode();
    result = imul(result, 31) + hashCode(this.y24_1) | 0;
    return result;
  };
  protoOf(ViewTransformation).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof ViewTransformation))
      return false;
    if (!this.x24_1.equals(other.x24_1))
      return false;
    if (!equals(this.y24_1, other.y24_1))
      return false;
    return true;
  };
  function CloseViewRequest(view) {
    this.b25_1 = view;
  }
  protoOf(CloseViewRequest).toString = function () {
    return 'CloseViewRequest(view=' + toString(this.b25_1) + ')';
  };
  protoOf(CloseViewRequest).hashCode = function () {
    return hashCode(this.b25_1);
  };
  protoOf(CloseViewRequest).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof CloseViewRequest))
      return false;
    if (!equals(this.b25_1, other.b25_1))
      return false;
    return true;
  };
  function Companion_5() {
    this.c25_1 = 'ViewContentBounds.total';
  }
  var Companion_instance_9;
  function Companion_getInstance_7() {
    return Companion_instance_9;
  }
  function ViewContentBounds(propertyOwner, mainBoundsAccessor) {
    propertyOwner = propertyOwner === VOID ? new PropertyOwnerImpl() : propertyOwner;
    this.d25_1 = propertyOwner;
    this.e25_1 = mainBoundsAccessor;
    var tmp = this;
    // Inline function 'kotlin.collections.mutableListOf' call
    tmp.f25_1 = ArrayList_init_$Create$();
    this.d25_1.d1b(this);
  }
  protoOf(ViewContentBounds).g25 = function () {
    return this.e25_1();
  };
  protoOf(ViewContentBounds).h25 = function () {
    var result = this.g25();
    // Inline function 'kotlin.collections.isNotEmpty' call
    if (!this.f25_1.m()) {
      result = Rectangle2D_init_$Create$(result);
      // Inline function 'kotlin.collections.forEach' call
      var _iterator__ex2g4s = this.f25_1.i();
      while (_iterator__ex2g4s.j()) {
        var element = _iterator__ex2g4s.k();
        result.x1b(element.do());
      }
    }
    return result;
  };
  protoOf(ViewContentBounds).i25 = function (drawable) {
    var oldValue = this.h25();
    this.f25_1.h(drawable);
    this.j25('ViewContentBounds.total', oldValue, this.h25());
  };
  protoOf(ViewContentBounds).k25 = function (drawable) {
    var oldValue = this.h25();
    this.f25_1.h2(drawable);
    this.j25('ViewContentBounds.total', oldValue, this.h25());
  };
  protoOf(ViewContentBounds).l25 = function (l) {
    this.d25_1.e1b(l);
  };
  protoOf(ViewContentBounds).e1b = function (l) {
    return this.l25(l);
  };
  protoOf(ViewContentBounds).m25 = function (l) {
    this.d25_1.f1b(l);
  };
  protoOf(ViewContentBounds).f1b = function (l) {
    return this.m25(l);
  };
  protoOf(ViewContentBounds).j25 = function (name, oldValue, newValue) {
    this.d25_1.lr(name, oldValue, newValue);
  };
  protoOf(ViewContentBounds).lr = function (name, oldValue, newValue) {
    var tmp = (oldValue == null ? true : isInterface(oldValue, RectangularShape)) ? oldValue : THROW_CCE();
    return this.j25(name, tmp, (newValue == null ? true : isInterface(newValue, RectangularShape)) ? newValue : THROW_CCE());
  };
  protoOf(ViewContentBounds).d1b = function (_set____db54di) {
    this.d25_1.d1b(_set____db54di);
  };
  function Companion_6() {
    Companion_instance_10 = this;
    this.n25_1 = 5.0;
    this.o25_1 = new FontImpl();
    this.p25_1 = this.o25_1.t25(FontStyle_ITALIC_getInstance());
  }
  protoOf(Companion_6).u25 = function () {
    return DrawStyleModule_getInstance().g1x_1.p1x(Companion_getInstance_33().n1x_1).m1t().j1x_1;
  };
  protoOf(Companion_6).a26 = function () {
    return this.u25().b26(DrawStyleModule_getInstance().g1x_1.p1x(Companion_getInstance_33().n1x_1).m1t().i1x_1);
  };
  var Companion_instance_10;
  function Companion_getInstance_8() {
    if (Companion_instance_10 == null)
      new Companion_6();
    return Companion_instance_10;
  }
  function updateOverlayContainer($this, current, new_0) {
    if (current == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      $this.c26_1.l23().m20(current);
    }
    if (new_0 == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      $this.c26_1.l23().l20(new_0);
    }
  }
  function update($this) {
    if (!($this.d26_1 == null)) {
      updateTopCentered($this);
    }
    if (!($this.e26_1 == null)) {
      updateBottonRight($this);
    }
    $this.c26_1.l23().u1z();
  }
  function updateTopCentered($this) {
    ensureNotNull($this.d26_1).f20(new Point2D($this.c26_1.p1b() / $this.c26_1.c23().b1x() / 2 - $this.c26_1.u24(ensureNotNull($this.d26_1).do().p1b() / 2) / $this.c26_1.c23().b1x(), 5.0));
  }
  function updateBottonRight($this) {
    ensureNotNull($this.e26_1).f20(new Point2D($this.c26_1.p1b() / $this.c26_1.c23().b1x() - $this.c26_1.u24(ensureNotNull($this.e26_1).do().p1b()) / $this.c26_1.c23().b1x() - 5.0, $this.c26_1.r1b() / $this.c26_1.c23().b1x() - $this.c26_1.u24(ensureNotNull($this.e26_1).do().r1b()) / $this.c26_1.c23().b1x() - 5.0));
  }
  function sam$io_antarescircuit_jabbah_base_event_PropertyChangeListener$0(function_0) {
    this.f26_1 = function_0;
  }
  protoOf(sam$io_antarescircuit_jabbah_base_event_PropertyChangeListener$0).propertyChanged = function (e) {
    return this.f26_1(e);
  };
  protoOf(sam$io_antarescircuit_jabbah_base_event_PropertyChangeListener$0).p2 = function () {
    return this.f26_1;
  };
  protoOf(sam$io_antarescircuit_jabbah_base_event_PropertyChangeListener$0).equals = function (other) {
    var tmp;
    if (!(other == null) ? isInterface(other, PropertyChangeListener) : false) {
      var tmp_0;
      if (!(other == null) ? isInterface(other, FunctionAdapter) : false) {
        tmp_0 = equals(this.p2(), other.p2());
      } else {
        tmp_0 = false;
      }
      tmp = tmp_0;
    } else {
      tmp = false;
    }
    return tmp;
  };
  protoOf(sam$io_antarescircuit_jabbah_base_event_PropertyChangeListener$0).hashCode = function () {
    return hashCode(this.p2());
  };
  function ViewDecorator$lambda$lambda(this$0) {
    return function (it) {
      var tmp;
      if (it.name === 'PROP_DIMENSION') {
        update(this$0);
        tmp = Unit_instance;
      }
      return Unit_instance;
    };
  }
  function ViewDecorator$lambda(this$0) {
    return function (it) {
      var tmp;
      if (it.name === 'PROP_CANVAS') {
        var tmp_0 = this$0.c26_1.c23();
        var tmp_1 = ViewDecorator$lambda$lambda(this$0);
        tmp_0.e1b(new sam$io_antarescircuit_jabbah_base_event_PropertyChangeListener$0(tmp_1));
        tmp = Unit_instance;
      }
      return Unit_instance;
    };
  }
  function ViewDecorator(view) {
    Companion_getInstance_8();
    this.c26_1 = view;
    this.d26_1 = null;
    this.e26_1 = null;
    this.c26_1.o23(ViewDecorator$lambda(this));
  }
  protoOf(ViewDecorator).g26 = function (value) {
    updateOverlayContainer(this, this.d26_1, value);
    this.d26_1 = value;
    update(this);
  };
  protoOf(ViewDecorator).h26 = function (value) {
    updateOverlayContainer(this, this.e26_1, value);
    this.e26_1 = value;
    update(this);
  };
  function ViewNavigator() {
  }
  function IdentityViewToModelTransform() {
  }
  protoOf(IdentityViewToModelTransform).l24 = function (x) {
    return x;
  };
  protoOf(IdentityViewToModelTransform).m24 = function (y) {
    return y;
  };
  protoOf(IdentityViewToModelTransform).n24 = function (p) {
    return p;
  };
  protoOf(IdentityViewToModelTransform).o24 = function (p, zoomFactor) {
    return p;
  };
  protoOf(IdentityViewToModelTransform).p24 = function (length) {
    return length;
  };
  protoOf(IdentityViewToModelTransform).q24 = function (p) {
    return p;
  };
  protoOf(IdentityViewToModelTransform).s24 = function (x) {
    return x;
  };
  protoOf(IdentityViewToModelTransform).t24 = function (y) {
    return y;
  };
  protoOf(IdentityViewToModelTransform).r24 = function (p, zoomFactor) {
    return p;
  };
  protoOf(IdentityViewToModelTransform).u24 = function (length) {
    return length;
  };
  protoOf(IdentityViewToModelTransform).v24 = function (p) {
    return p;
  };
  var IdentityViewToModelTransform_instance;
  function IdentityViewToModelTransform_getInstance() {
    return IdentityViewToModelTransform_instance;
  }
  function Companion_7() {
  }
  protoOf(Companion_7).u26 = function () {
    return 1.0;
  };
  var Companion_instance_11;
  function Companion_getInstance_9() {
    return Companion_instance_11;
  }
  function ZoomPan_init_$Init$($this) {
    ZoomPan_init_$Init$_0(IdentityViewToModelTransform_instance, $this);
    return $this;
  }
  function ZoomPan_init_$Create$() {
    return ZoomPan_init_$Init$(objectCreate(protoOf(ZoomPan)));
  }
  function ZoomPan_init_$Init$_0(transform, $this) {
    ZoomPan_init_$Init$_1(transform, 1.0, 0.0, 0.0, $this);
    return $this;
  }
  function ZoomPan_init_$Init$_1(transform, zoomFactor, panX, panY, $this) {
    var tmp = new Point2D(panX, panY);
    ZoomPan.call($this, transform, zoomFactor, tmp, ZoomPan$Companion$defaultDevicePixelRatio$ref(Companion_instance_11));
    return $this;
  }
  function ZoomPan$Companion$defaultDevicePixelRatio$ref(p0) {
    var l = function () {
      return p0.u26();
    };
    l.callableName = 'defaultDevicePixelRatio';
    return l;
  }
  function ZoomPan(transform, zoomFactor, panOrigin, devicePixelRatio) {
    this.t23_1 = transform;
    this.u23_1 = zoomFactor;
    this.v23_1 = panOrigin;
    this.w23_1 = devicePixelRatio;
  }
  protoOf(ZoomPan).toString = function () {
    return 'ZoomPan(transform=' + toString(this.t23_1) + ', zoomFactor=' + this.u23_1 + ', panOrigin=' + this.v23_1.toString() + ', devicePixelRatio=' + toString(this.w23_1) + ')';
  };
  protoOf(ZoomPan).hashCode = function () {
    var result = hashCode(this.t23_1);
    result = imul(result, 31) + getNumberHashCode(this.u23_1) | 0;
    result = imul(result, 31) + this.v23_1.hashCode() | 0;
    result = imul(result, 31) + hashCode(this.w23_1) | 0;
    return result;
  };
  protoOf(ZoomPan).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof ZoomPan))
      return false;
    if (!equals(this.t23_1, other.t23_1))
      return false;
    if (!equals(this.u23_1, other.u23_1))
      return false;
    if (!this.v23_1.equals(other.v23_1))
      return false;
    if (!equals(this.w23_1, other.w23_1))
      return false;
    return true;
  };
  function Companion_8() {
    Companion_instance_12 = this;
    this.v26_1 = new ZoomStrategy(ZoomStrategyType_NONE_getInstance());
    this.w26_1 = new ZoomStrategy(ZoomStrategyType_NORMAL_getInstance());
    this.x26_1 = new ZoomStrategy(ZoomStrategyType_FIT_getInstance());
    this.y26_1 = new ZoomStrategy(ZoomStrategyType_FIT_MAX_NORMAL_getInstance());
    this.z26_1 = new ZoomStrategy(ZoomStrategyType_CENTER_getInstance());
  }
  var Companion_instance_12;
  function Companion_getInstance_10() {
    if (Companion_instance_12 == null)
      new Companion_8();
    return Companion_instance_12;
  }
  function ZoomStrategy(type, zoomFactor) {
    Companion_getInstance_10();
    zoomFactor = zoomFactor === VOID ? null : zoomFactor;
    this.a27_1 = type;
    this.b27_1 = zoomFactor;
  }
  protoOf(ZoomStrategy).c27 = function (navigator) {
    return this.a27_1.f27(navigator, this.b27_1);
  };
  protoOf(ZoomStrategy).toString = function () {
    return 'ZoomStrategy(type=' + this.a27_1.toString() + ', zoomFactor=' + this.b27_1 + ')';
  };
  protoOf(ZoomStrategy).hashCode = function () {
    var result = this.a27_1.hashCode();
    result = imul(result, 31) + (this.b27_1 == null ? 0 : getNumberHashCode(this.b27_1)) | 0;
    return result;
  };
  protoOf(ZoomStrategy).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof ZoomStrategy))
      return false;
    if (!this.a27_1.equals(other.a27_1))
      return false;
    if (!equals(this.b27_1, other.b27_1))
      return false;
    return true;
  };
  function ZoomStrategyType$NORMAL() {
    ZoomStrategyType.call(this, 'NORMAL', 0);
    ZoomStrategyType_NORMAL_instance = this;
  }
  protoOf(ZoomStrategyType$NORMAL).f27 = function (navigator, zoomFactor) {
    return navigator.o26();
  };
  var ZoomStrategyType_NORMAL_instance;
  function ZoomStrategyType$FIT() {
    ZoomStrategyType.call(this, 'FIT', 1);
    ZoomStrategyType_FIT_instance = this;
  }
  protoOf(ZoomStrategyType$FIT).f27 = function (navigator, zoomFactor) {
    return navigator.q26();
  };
  var ZoomStrategyType_FIT_instance;
  function ZoomStrategyType$FIT_MAX_NORMAL() {
    ZoomStrategyType.call(this, 'FIT_MAX_NORMAL', 2);
    ZoomStrategyType_FIT_MAX_NORMAL_instance = this;
  }
  protoOf(ZoomStrategyType$FIT_MAX_NORMAL).f27 = function (navigator, zoomFactor) {
    return navigator.r26();
  };
  var ZoomStrategyType_FIT_MAX_NORMAL_instance;
  function ZoomStrategyType$CENTER() {
    ZoomStrategyType.call(this, 'CENTER', 3);
    ZoomStrategyType_CENTER_instance = this;
  }
  protoOf(ZoomStrategyType$CENTER).f27 = function (navigator, zoomFactor) {
    return navigator.n26();
  };
  var ZoomStrategyType_CENTER_instance;
  function ZoomStrategyType$VALUE() {
    ZoomStrategyType.call(this, 'VALUE', 4);
    ZoomStrategyType_VALUE_instance = this;
  }
  protoOf(ZoomStrategyType$VALUE).f27 = function (navigator, zoomFactor) {
    return navigator.p26(zoomFactor == null ? 1.0 : zoomFactor);
  };
  var ZoomStrategyType_VALUE_instance;
  function ZoomStrategyType$NONE() {
    ZoomStrategyType.call(this, 'NONE', 5);
    ZoomStrategyType_NONE_instance = this;
  }
  protoOf(ZoomStrategyType$NONE).f27 = function (navigator, zoomFactor) {
  };
  var ZoomStrategyType_NONE_instance;
  var ZoomStrategyType_entriesInitialized;
  function ZoomStrategyType_initEntries() {
    if (ZoomStrategyType_entriesInitialized)
      return Unit_instance;
    ZoomStrategyType_entriesInitialized = true;
    ZoomStrategyType_NORMAL_instance = new ZoomStrategyType$NORMAL();
    ZoomStrategyType_FIT_instance = new ZoomStrategyType$FIT();
    ZoomStrategyType_FIT_MAX_NORMAL_instance = new ZoomStrategyType$FIT_MAX_NORMAL();
    ZoomStrategyType_CENTER_instance = new ZoomStrategyType$CENTER();
    ZoomStrategyType_VALUE_instance = new ZoomStrategyType$VALUE();
    ZoomStrategyType_NONE_instance = new ZoomStrategyType$NONE();
  }
  function ZoomStrategyType(name, ordinal) {
    Enum.call(this, name, ordinal);
  }
  function ZoomStrategyType_NORMAL_getInstance() {
    ZoomStrategyType_initEntries();
    return ZoomStrategyType_NORMAL_instance;
  }
  function ZoomStrategyType_FIT_getInstance() {
    ZoomStrategyType_initEntries();
    return ZoomStrategyType_FIT_instance;
  }
  function ZoomStrategyType_FIT_MAX_NORMAL_getInstance() {
    ZoomStrategyType_initEntries();
    return ZoomStrategyType_FIT_MAX_NORMAL_instance;
  }
  function ZoomStrategyType_CENTER_getInstance() {
    ZoomStrategyType_initEntries();
    return ZoomStrategyType_CENTER_instance;
  }
  function ZoomStrategyType_VALUE_getInstance() {
    ZoomStrategyType_initEntries();
    return ZoomStrategyType_VALUE_instance;
  }
  function ZoomStrategyType_NONE_getInstance() {
    ZoomStrategyType_initEntries();
    return ZoomStrategyType_NONE_instance;
  }
  function _get__drawables__8b3f7v($this) {
    var tmp0 = $this.v27_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('_drawables', 1, tmp, DrawableBagImpl$_get__drawables_$ref_vz5go2(), null);
    return tmp0.j2();
  }
  function DrawableBagImpl$_drawables$delegate$lambda() {
    // Inline function 'kotlin.collections.mutableListOf' call
    return ArrayList_init_$Create$();
  }
  function DrawableBagImpl$_get__drawables_$ref_vz5go2() {
    return function (p0) {
      return _get__drawables__8b3f7v(p0);
    };
  }
  function DrawableBagImpl(location, useLocation, rotation) {
    location = location === VOID ? Companion_getInstance().g1a_1 : location;
    useLocation = useLocation === VOID ? false : useLocation;
    rotation = rotation === VOID ? Rotation_R0_getInstance() : rotation;
    this.s27_1 = location;
    this.t27_1 = useLocation;
    this.u27_1 = rotation;
    var tmp = this;
    tmp.v27_1 = lazy(DrawableBagImpl$_drawables$delegate$lambda);
  }
  protoOf(DrawableBagImpl).f20 = function (_set____db54di) {
    this.s27_1 = _set____db54di;
  };
  protoOf(DrawableBagImpl).hw = function () {
    return this.s27_1;
  };
  protoOf(DrawableBagImpl).d20 = function () {
    return this.t27_1;
  };
  protoOf(DrawableBagImpl).w27 = function (_set____db54di) {
    this.u27_1 = _set____db54di;
  };
  protoOf(DrawableBagImpl).g20 = function () {
    return this.u27_1;
  };
  protoOf(DrawableBagImpl).e20 = function () {
    return _get__drawables__8b3f7v(this);
  };
  protoOf(DrawableBagImpl).j20 = function () {
    _get__drawables__8b3f7v(this).a2();
    return this;
  };
  protoOf(DrawableBagImpl).k20 = function (drawable, index) {
    _get__drawables__8b3f7v(this).t3(index, drawable);
    return this;
  };
  protoOf(DrawableBagImpl).m20 = function (drawable) {
    // Inline function 'kotlin.collections.remove' call
    var this_0 = _get__drawables__8b3f7v(this);
    (isInterface(this_0, MutableCollection) ? this_0 : THROW_CCE()).h2(drawable);
    return this;
  };
  function mightRemember($this, handler) {
    $this.y27_1 = handler;
    return !(handler == null) && !$this.a28().hw().equals(Companion_getInstance().g1a_1) ? $this : handler;
  }
  function onTargetOrContainer($this, context, handler) {
    var localContext = getLocalContext($this, context);
    if (!($this.y27_1 == null)) {
      return mightRemember($this, handler(ensureNotNull($this.y27_1), localContext));
    }
    var tmp0_safe_receiver = $this.t20(context.d22_1);
    var tmp;
    if (tmp0_safe_receiver == null) {
      tmp = null;
    } else {
      // Inline function 'kotlin.let' call
      tmp = mightRemember($this, handler($this.b28(tmp0_safe_receiver, localContext), localContext));
    }
    var tmp1_elvis_lhs = tmp;
    return tmp1_elvis_lhs == null ? mightRemember($this, null) : tmp1_elvis_lhs;
  }
  function getLocalContext($this, context) {
    var tmp;
    if ($this.a28().hw().equals(Companion_getInstance().g1a_1) && $this.a28().g20().equals(Rotation_R0_getInstance())) {
      tmp = context;
    } else {
      var tmp_0 = context.e22($this.a28().y20(context.d22_1).t1g($this.a28().hw()));
      tmp = tmp_0 instanceof InputEventContext ? tmp_0 : THROW_CCE();
    }
    return tmp;
  }
  function DrawableBagInputEventHandler$mouseMoved$lambda(h, c) {
    return h.j22(c);
  }
  function DrawableBagInputEventHandler$mousePressed$lambda(h, c) {
    return h.k22(c);
  }
  function DrawableBagInputEventHandler$mouseDragged$lambda(h, c) {
    return h.l22(c);
  }
  function DrawableBagInputEventHandler$mouseReleased$lambda(h, c) {
    return h.m22(c);
  }
  function DrawableBagInputEventHandler$mouseClicked$lambda(h, c) {
    return h.i22(c);
  }
  function DrawableBagInputEventHandler() {
    InputEventHandlerAdapter.call(this);
    this.y27_1 = null;
    this.z27_1 = null;
  }
  protoOf(DrawableBagInputEventHandler).a28 = function () {
    return ensureNotNull(this.z27_1);
  };
  protoOf(DrawableBagInputEventHandler).c28 = function (context) {
    return onTargetOrContainer(this, context, DrawableBagInputEventHandler$mouseMoved$lambda);
  };
  protoOf(DrawableBagInputEventHandler).j22 = function (context) {
    return this.c28(context instanceof InputEventContext ? context : THROW_CCE());
  };
  protoOf(DrawableBagInputEventHandler).d28 = function (context) {
    return onTargetOrContainer(this, context, DrawableBagInputEventHandler$mousePressed$lambda);
  };
  protoOf(DrawableBagInputEventHandler).k22 = function (context) {
    return this.d28(context instanceof InputEventContext ? context : THROW_CCE());
  };
  protoOf(DrawableBagInputEventHandler).e28 = function (context) {
    return onTargetOrContainer(this, context, DrawableBagInputEventHandler$mouseDragged$lambda);
  };
  protoOf(DrawableBagInputEventHandler).l22 = function (context) {
    return this.e28(context instanceof InputEventContext ? context : THROW_CCE());
  };
  protoOf(DrawableBagInputEventHandler).f28 = function (context) {
    return onTargetOrContainer(this, context, DrawableBagInputEventHandler$mouseReleased$lambda);
  };
  protoOf(DrawableBagInputEventHandler).m22 = function (context) {
    return this.f28(context instanceof InputEventContext ? context : THROW_CCE());
  };
  protoOf(DrawableBagInputEventHandler).g28 = function (context) {
    return onTargetOrContainer(this, context, DrawableBagInputEventHandler$mouseClicked$lambda);
  };
  protoOf(DrawableBagInputEventHandler).i22 = function (context) {
    return this.g28(context instanceof InputEventContext ? context : THROW_CCE());
  };
  protoOf(DrawableBagInputEventHandler).h28 = function (drawableBag) {
    this.z27_1 = drawableBag;
    this.y27_1 = null;
  };
  protoOf(DrawableBagInputEventHandler).t20 = function (location) {
    return this.a28().t20(location);
  };
  protoOf(DrawableBagInputEventHandler).b28 = function (drawable, context) {
    return drawable.o1z(context);
  };
  function DrawableContainerAdapter() {
  }
  protoOf(DrawableContainerAdapter).i21 = function (event) {
  };
  protoOf(DrawableContainerAdapter).j21 = function (event) {
  };
  function DrawableContainerDrawer() {
    AbstractDrawableDrawer.call(this);
  }
  protoOf(DrawableContainerDrawer).j28 = function (context, drawable) {
    this.k28(drawable, context);
    this.m28(context, drawable);
  };
  protoOf(DrawableContainerDrawer).k28 = function (drawable, context) {
    var tmp;
    if (!isInterface(drawable, Stylable)) {
      tmp = true;
    } else {
      tmp = !drawable.r28().q28_1;
    }
    if (tmp) {
      drawable.r1z(context);
    }
  };
  function _get_containerListeners__ggqsul($this) {
    var tmp0 = $this.a29_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('containerListeners', 1, tmp, DrawableContainerImpl$_get_containerListeners_$ref_84y0gt(), null);
    return tmp0.j2();
  }
  function _get_inputEventHandler__jupodl($this) {
    var tmp0 = $this.c29_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('inputEventHandler', 1, tmp, DrawableContainerImpl$_get_inputEventHandler_$ref_dhj0hn(), null);
    return tmp0.j2();
  }
  function getClip($this, context) {
    var tmp;
    if ($this.y28_1) {
      var tmp_0;
      if (context.t1y_1.g1t()) {
        context.t1y_1.w1u($this.d29_1);
        tmp_0 = $this.d29_1;
      } else {
        tmp_0 = null;
      }
      tmp = tmp_0;
    } else {
      tmp = context.u1y_1;
    }
    return tmp;
  }
  function childBoundingBox($this, child) {
    var tmp;
    if ($this.d20()) {
      tmp = Rectangle2D_init_$Create$(child.do()).v1b($this.hw());
    } else {
      tmp = child.do();
    }
    return tmp;
  }
  function notifyDrawableAdded($this, drawable) {
    var event = new DrawableContainerEvent($this, drawable);
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = _get_containerListeners__ggqsul($this).i();
    while (_iterator__ex2g4s.j()) {
      var element = _iterator__ex2g4s.k();
      element.i21(event);
    }
  }
  function notifyDrawableRemoved($this, drawable) {
    var event = new DrawableContainerEvent($this, drawable);
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = _get_containerListeners__ggqsul($this).i();
    while (_iterator__ex2g4s.j()) {
      var element = _iterator__ex2g4s.k();
      element.j21(event);
    }
  }
  function removeDrawableImpl($this, drawable, last) {
    if (contains($this.h29(), drawable)) {
      // Inline function 'kotlin.collections.remove' call
      var this_0 = $this.h29();
      (isInterface(this_0, MutableCollection) ? this_0 : THROW_CCE()).h2(drawable);
      drawable.x1z($this);
      if (last) {
        $this.i29();
      }
      $this.t1z(childBoundingBox($this, drawable));
      notifyDrawableRemoved($this, drawable);
    }
  }
  function DrawableContainerImpl$children$delegate$lambda() {
    // Inline function 'kotlin.collections.mutableListOf' call
    return ArrayList_init_$Create$();
  }
  function DrawableContainerImpl$_get_children_$ref_278nyc() {
    return function (p0) {
      return p0.h29();
    };
  }
  function DrawableContainerImpl$containerListeners$delegate$lambda() {
    // Inline function 'kotlin.collections.mutableListOf' call
    return ArrayList_init_$Create$();
  }
  function DrawableContainerImpl$_get_containerListeners_$ref_84y0gt() {
    return function (p0) {
      return _get_containerListeners__ggqsul(p0);
    };
  }
  function DrawableContainerImpl$inputEventHandler$delegate$lambda(this$0) {
    return function () {
      return this$0.m29();
    };
  }
  function DrawableContainerImpl$_get_inputEventHandler_$ref_dhj0hn() {
    return function (p0) {
      return _get_inputEventHandler__jupodl(p0);
    };
  }
  function DrawableContainerImpl(location, useLocation, visible, useViewCoordinates) {
    location = location === VOID ? Companion_getInstance().g1a_1 : location;
    useLocation = useLocation === VOID ? false : useLocation;
    visible = visible === VOID ? true : visible;
    useViewCoordinates = useViewCoordinates === VOID ? false : useViewCoordinates;
    AbstractDrawable.call(this, visible);
    this.x28_1 = useLocation;
    this.y28_1 = useViewCoordinates;
    var tmp = this;
    tmp.z28_1 = lazy(DrawableContainerImpl$children$delegate$lambda);
    var tmp_0 = this;
    tmp_0.a29_1 = lazy(DrawableContainerImpl$containerListeners$delegate$lambda);
    this.b29_1 = new DefaultDrawableDrawer();
    var tmp_1 = this;
    tmp_1.c29_1 = lazy(DrawableContainerImpl$inputEventHandler$delegate$lambda(this));
    this.d29_1 = new Rectangle2D();
    this.e29_1 = location;
    this.f29_1 = Rotation_R0_getInstance();
    this.g29_1 = new Rectangle2D();
  }
  protoOf(DrawableContainerImpl).d20 = function () {
    return this.x28_1;
  };
  protoOf(DrawableContainerImpl).h29 = function () {
    var tmp0 = this.z28_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('children', 1, tmp, DrawableContainerImpl$_get_children_$ref_278nyc(), null);
    return tmp0.j2();
  };
  protoOf(DrawableContainerImpl).f20 = function (value) {
    if (!this.e29_1.equals(value)) {
      this.e29_1 = value;
      this.i29();
    }
  };
  protoOf(DrawableContainerImpl).hw = function () {
    return this.e29_1;
  };
  protoOf(DrawableContainerImpl).e20 = function () {
    return this.h29();
  };
  protoOf(DrawableContainerImpl).g20 = function () {
    return this.f29_1;
  };
  protoOf(DrawableContainerImpl).k20 = function (drawable, index) {
    if (this.h29().n(drawable)) {
      return this;
    }
    this.h29().t3(index, drawable);
    drawable.w1z(this);
    if (drawable.n1z()) {
      var drawableBBox = childBoundingBox(this, drawable);
      if (this.e20().o() === 1) {
        this.g29_1.w1b(drawableBBox);
      } else {
        this.g29_1.x1b(drawableBBox);
      }
      this.t1z(drawableBBox);
      this.v1z();
    }
    notifyDrawableAdded(this, drawable);
    return this;
  };
  protoOf(DrawableContainerImpl).m20 = function (drawable) {
    removeDrawableImpl(this, drawable, true);
    return this;
  };
  protoOf(DrawableContainerImpl).j20 = function () {
    while (this.h29().o() > 0) {
      removeDrawableImpl(this, this.h29().l(0), this.h29().o() === 1);
    }
    return this;
  };
  protoOf(DrawableContainerImpl).do = function () {
    return this.g29_1;
  };
  protoOf(DrawableContainerImpl).e13 = function (visitor) {
    if (visitor.fs(this)) {
      // Inline function 'kotlin.collections.iterator' call
      var _iterator__ex2g4s = this.o20();
      $l$loop: while (_iterator__ex2g4s.j()) {
        var d = _iterator__ex2g4s.k();
        if (!d.e13(visitor)) {
          break $l$loop;
        }
      }
    }
    return visitor.is(this);
  };
  protoOf(DrawableContainerImpl).r1z = function (context) {
    this.n29(context, this.b29_1);
  };
  protoOf(DrawableContainerImpl).n29 = function (context, drawer) {
    var tmp;
    if (this.n1z()) {
      // Inline function 'kotlin.collections.isNotEmpty' call
      tmp = !this.h29().m();
    } else {
      tmp = false;
    }
    if (tmp) {
      var clip = getClip(this, context);
      var oldModelClip = context.u1y_1;
      if (this.d20()) {
        context.t1y_1.v1c(this.hw().in_1, this.hw().jn_1);
        if (!(clip == null)) {
          clip = new Rectangle2D(clip.z19() - this.hw().in_1, clip.a1a() - this.hw().jn_1, clip.p1b(), clip.r1b());
          if (!this.y28_1 && !(context.u1y_1 == null)) {
            context.u1y_1 = clip;
          }
        }
      }
      // Inline function 'kotlin.collections.forEach' call
      var _iterator__ex2g4s = this.o29().i();
      while (_iterator__ex2g4s.j()) {
        var element = _iterator__ex2g4s.k();
        if (element.n1z()) {
          if (clip == null || element.po(clip)) {
            drawer.j28(context, element);
          }
        }
      }
      if (this.d20()) {
        context.t1y_1.v1c(-this.hw().in_1, -this.hw().jn_1);
        DrawModule_getInstance().a2a(this, context.t1y_1);
      } else {
        DrawModule_getInstance().a2a(this, context.t1y_1);
      }
      DrawModule_getInstance().b2a(this.hw(), context);
      context.u1y_1 = oldModelClip;
    }
  };
  protoOf(DrawableContainerImpl).o1z = function (context) {
    _get_inputEventHandler__jupodl(this).h28(this);
    return _get_inputEventHandler__jupodl(this);
  };
  protoOf(DrawableContainerImpl).o29 = function () {
    return asReversed(this.h29());
  };
  protoOf(DrawableContainerImpl).y1z = function (context) {
    if (this.d20()) {
      var localContext = context.e22(context.d22_1.t1g(this.hw()));
      var tmp0_safe_receiver = this.t20(context.d22_1);
      var tmp1_elvis_lhs = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.y1z(localContext);
      return tmp1_elvis_lhs == null ? protoOf(AbstractDrawable).y1z.call(this, localContext) : tmp1_elvis_lhs;
    }
    var tmp2_safe_receiver = this.t20(context.d22_1);
    var tmp3_elvis_lhs = tmp2_safe_receiver == null ? null : tmp2_safe_receiver.y1z(context);
    return tmp3_elvis_lhs == null ? protoOf(AbstractDrawable).y1z.call(this, context) : tmp3_elvis_lhs;
  };
  protoOf(DrawableContainerImpl).z20 = function (drawableDrawer) {
    this.b29_1 = drawableDrawer;
  };
  protoOf(DrawableContainerImpl).a21 = function (listener) {
    if (!_get_containerListeners__ggqsul(this).n(listener)) {
      _get_containerListeners__ggqsul(this).h(listener);
    }
  };
  protoOf(DrawableContainerImpl).b21 = function (listener) {
    _get_containerListeners__ggqsul(this).h2(listener);
  };
  protoOf(DrawableContainerImpl).c21 = function (drawable, region) {
    if (this.d20()) {
      this.t1z(Rectangle2D_init_$Create$(region).v1b(this.hw()));
    } else {
      this.t1z(region);
    }
  };
  protoOf(DrawableContainerImpl).d21 = function (drawable) {
    this.c2a();
  };
  protoOf(DrawableContainerImpl).e21 = function (drawable) {
    this.i29();
    if (!this.do().oo(drawable.do())) {
      this.v1z();
    }
  };
  protoOf(DrawableContainerImpl).m29 = function () {
    return new DrawableBagInputEventHandler();
  };
  protoOf(DrawableContainerImpl).i29 = function () {
    var tmp0 = this.h29();
    var tmp$ret$0;
    $l$block: {
      // Inline function 'kotlin.collections.firstOrNull' call
      var _iterator__ex2g4s = tmp0.i();
      while (_iterator__ex2g4s.j()) {
        var element = _iterator__ex2g4s.k();
        if (element.n1z()) {
          tmp$ret$0 = element;
          break $l$block;
        }
      }
      tmp$ret$0 = null;
    }
    var tmp0_safe_receiver = tmp$ret$0;
    var tmp;
    if (tmp0_safe_receiver == null) {
      tmp = null;
    } else {
      // Inline function 'kotlin.let' call
      this.g29_1.w1b(childBoundingBox(this, tmp0_safe_receiver));
      tmp = Unit_instance;
    }
    if (tmp == null) {
      this.g29_1.s1b(0.0, 0.0, 0.0, 0.0);
    }
    // Inline function 'kotlin.collections.filter' call
    var tmp0_0 = this.h29();
    // Inline function 'kotlin.collections.filterTo' call
    var destination = ArrayList_init_$Create$();
    var _iterator__ex2g4s_0 = tmp0_0.i();
    while (_iterator__ex2g4s_0.j()) {
      var element_0 = _iterator__ex2g4s_0.k();
      if (element_0.n1z()) {
        destination.h(element_0);
      }
    }
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s_1 = destination.i();
    while (_iterator__ex2g4s_1.j()) {
      var element_1 = _iterator__ex2g4s_1.k();
      this.g29_1.x1b(childBoundingBox(this, element_1));
    }
  };
  function DrawableProperty(initialValue, afterSet, afterChange) {
    afterSet = afterSet === VOID ? null : afterSet;
    afterChange = afterChange === VOID ? null : afterChange;
    AbstractDrawableProperty.call(this, initialValue, afterSet, afterChange);
  }
  function DrawableGeometryProperty$_init_$lambda_w78xzu(it) {
    it.v1z();
    return Unit_instance;
  }
  function DrawableGeometryProperty(initialValue, afterSet, afterChange) {
    afterSet = afterSet === VOID ? null : afterSet;
    var tmp;
    if (afterChange === VOID) {
      tmp = DrawableGeometryProperty$_init_$lambda_w78xzu;
    } else {
      tmp = afterChange;
    }
    afterChange = tmp;
    AbstractDrawableProperty.call(this, initialValue, afterSet, afterChange);
  }
  function AbstractDrawableProperty(initialValue, afterSet, afterChange) {
    afterSet = afterSet === VOID ? null : afterSet;
    afterChange = afterChange === VOID ? null : afterChange;
    this.f2a_1 = afterSet;
    this.g2a_1 = afterChange;
    this.h2a_1 = initialValue;
  }
  protoOf(AbstractDrawableProperty).i2a = function (thisRef, property) {
    return this.h2a_1;
  };
  protoOf(AbstractDrawableProperty).vf = function (thisRef, property) {
    return this.i2a((!(thisRef == null) ? isInterface(thisRef, Drawable) : false) ? thisRef : THROW_CCE(), property);
  };
  protoOf(AbstractDrawableProperty).j2a = function (thisRef, property, value) {
    if (!equals(this.h2a_1, value)) {
      thisRef.s1z();
      this.h2a_1 = value;
      var tmp0_safe_receiver = this.f2a_1;
      if (tmp0_safe_receiver == null)
        null;
      else
        tmp0_safe_receiver();
      thisRef.s1z();
      thisRef.u1z();
      var tmp1_safe_receiver = this.g2a_1;
      if (tmp1_safe_receiver == null)
        null;
      else
        tmp1_safe_receiver(thisRef);
    }
  };
  protoOf(AbstractDrawableProperty).xf = function (thisRef, property, value) {
    return this.j2a((!(thisRef == null) ? isInterface(thisRef, Drawable) : false) ? thisRef : THROW_CCE(), property, value);
  };
  function UnzoomableContainer() {
    DrawableContainerImpl.call(this);
    this.x2a_1 = null;
  }
  protoOf(UnzoomableContainer).y2a = function (value) {
    this.x2a_1 = value;
    var iter = this.n20();
    while (iter.j()) {
      iter.k().y2a(value);
    }
  };
  protoOf(UnzoomableContainer).z2a = function (drawable, index) {
    protoOf(DrawableContainerImpl).k20.call(this, drawable, index);
    drawable.y2a(this.x2a_1);
    return this;
  };
  protoOf(UnzoomableContainer).k20 = function (drawable, index) {
    return this.z2a(isInterface(drawable, Unzoomable) ? drawable : THROW_CCE(), index);
  };
  function _get_listeners__760gzy($this) {
    var tmp0 = $this.j29_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('listeners', 1, tmp, AbstractDrawable$_get_listeners_$ref_lumzwd(), null);
    return tmp0.j2();
  }
  function DrawableOwner(owner, inner) {
    this.a2b_1 = owner;
    this.b2b_1 = inner;
    this.b2b_1.p1z(this);
  }
  protoOf(DrawableOwner).es = function () {
    this.b2b_1.q1z(this);
  };
  protoOf(DrawableOwner).m21 = function (event) {
    this.a2b_1.s1z();
  };
  protoOf(DrawableOwner).n21 = function (event) {
    this.a2b_1.c2a();
  };
  protoOf(DrawableOwner).o21 = function (event) {
    this.a2b_1.v1z();
  };
  function AbstractDrawable$listeners$delegate$lambda() {
    // Inline function 'kotlin.collections.mutableListOf' call
    return ArrayList_init_$Create$();
  }
  function AbstractDrawable$_get_listeners_$ref_lumzwd() {
    return function (p0) {
      return _get_listeners__760gzy(p0);
    };
  }
  function AbstractDrawable(visible) {
    visible = visible === VOID ? true : visible;
    var tmp = this;
    tmp.j29_1 = lazy(AbstractDrawable$listeners$delegate$lambda);
    this.k29_1 = null;
    this.l29_1 = visible;
  }
  protoOf(AbstractDrawable).l1z = function () {
    return this.k29_1;
  };
  protoOf(AbstractDrawable).m1z = function (value) {
    if (!(value === this.n1z())) {
      this.s1z();
      this.l29_1 = value;
      this.v1z();
      this.u1z();
    }
  };
  protoOf(AbstractDrawable).n1z = function () {
    return this.l29_1;
  };
  protoOf(AbstractDrawable).es = function () {
  };
  protoOf(AbstractDrawable).e13 = function (visitor) {
    return visitor.gs(this);
  };
  protoOf(AbstractDrawable).o1z = function (context) {
    return Companion_getInstance_4().g22_1;
  };
  protoOf(AbstractDrawable).p1z = function (listener) {
    if (!_get_listeners__760gzy(this).n(listener)) {
      _get_listeners__760gzy(this).h(listener);
    }
  };
  protoOf(AbstractDrawable).q1z = function (listener) {
    _get_listeners__760gzy(this).h2(listener);
  };
  protoOf(AbstractDrawable).s1z = function () {
    this.t1z(this.do());
  };
  protoOf(AbstractDrawable).t1z = function (region) {
    var tmp0_safe_receiver = this.l1z();
    if (tmp0_safe_receiver == null)
      null;
    else {
      tmp0_safe_receiver.c21(this, region);
    }
    // Inline function 'kotlin.collections.isNotEmpty' call
    if (!_get_listeners__760gzy(this).m()) {
      var event = new DrawableEvent(this, region);
      // Inline function 'kotlin.collections.forEach' call
      var _iterator__ex2g4s = _get_listeners__760gzy(this).i();
      while (_iterator__ex2g4s.j()) {
        var element = _iterator__ex2g4s.k();
        element.m21(event);
      }
    }
  };
  protoOf(AbstractDrawable).u1z = function () {
    this.c2a();
  };
  protoOf(AbstractDrawable).w1z = function (container) {
    this.k29_1 = container;
  };
  protoOf(AbstractDrawable).x1z = function (container) {
    this.k29_1 = null;
  };
  protoOf(AbstractDrawable).y1z = function (context) {
    return null;
  };
  protoOf(AbstractDrawable).z1z = function (x, y) {
    return null;
  };
  protoOf(AbstractDrawable).v1z = function () {
    var tmp0_safe_receiver = this.l1z();
    if (tmp0_safe_receiver == null)
      null;
    else {
      tmp0_safe_receiver.e21(this);
    }
    // Inline function 'kotlin.collections.isNotEmpty' call
    if (!_get_listeners__760gzy(this).m()) {
      var event = DrawableEvent_init_$Create$(this);
      // Inline function 'kotlin.collections.forEach' call
      var _iterator__ex2g4s = _get_listeners__760gzy(this).i();
      while (_iterator__ex2g4s.j()) {
        var element = _iterator__ex2g4s.k();
        element.o21(event);
      }
    }
  };
  protoOf(AbstractDrawable).c2a = function () {
    var tmp0_safe_receiver = this.l1z();
    if (tmp0_safe_receiver == null)
      null;
    else {
      tmp0_safe_receiver.d21(this);
    }
    // Inline function 'kotlin.collections.isNotEmpty' call
    if (!_get_listeners__760gzy(this).m()) {
      var event = DrawableEvent_init_$Create$(this);
      // Inline function 'kotlin.collections.forEach' call
      var _iterator__ex2g4s = _get_listeners__760gzy(this).i();
      while (_iterator__ex2g4s.j()) {
        var element = _iterator__ex2g4s.k();
        element.n21(event);
      }
    }
  };
  protoOf(AbstractDrawable).c2b = function (context, shape, fillColor) {
    if (!(fillColor == null)) {
      context.t1y_1.l1t(fillColor);
      context.t1y_1.u1u(shape);
    }
  };
  protoOf(AbstractDrawable).d2b = function (context, shape, strokeColor, stroke) {
    if (!(stroke == null) && !(strokeColor == null)) {
      context.t1y_1.l1t(strokeColor);
      context.t1y_1.o1t(stroke);
      context.t1y_1.t1u(shape);
    }
  };
  protoOf(AbstractDrawable).e2b = function (title, text, subText) {
    return buildToolTipText(title, text, subText, true);
  };
  protoOf(AbstractDrawable).d2a = function (relativeLocation) {
    return this.e2a(relativeLocation.in_1, relativeLocation.jn_1);
  };
  protoOf(AbstractDrawable).e2a = function (relX, relY) {
    var x = relX;
    var y = relY;
    var p = this.l1z();
    while (!(p == null)) {
      x = x + p.hw().in_1;
      y = y + p.hw().jn_1;
      p = p.l1z();
    }
    return new Point2D(x, y);
  };
  function AbstractDrawableDrawer() {
    this.l28_1 = null;
  }
  protoOf(AbstractDrawableDrawer).s28 = function (_set____db54di) {
    this.l28_1 = _set____db54di;
  };
  protoOf(AbstractDrawableDrawer).t28 = function () {
    return this.l28_1;
  };
  protoOf(AbstractDrawableDrawer).m28 = function (context, drawable) {
    var tmp0_safe_receiver = this.t28();
    if (tmp0_safe_receiver == null)
      null;
    else {
      tmp0_safe_receiver.j28(context, drawable);
    }
  };
  function AbstractRectangle_init_$Init$(x, y, w, h, $this) {
    AbstractRectangle.call($this, new Rectangle2D(x, y, w, h));
    return $this;
  }
  function AbstractRectangle_init_$Init$_0($this) {
    AbstractRectangle_init_$Init$(0.0, 0.0, 0.0, 0.0, $this);
    return $this;
  }
  function AbstractRectangle(shape) {
    AbstractDrawable.call(this);
    this.i2b_1 = shape;
  }
  protoOf(AbstractRectangle).f20 = function (value) {
    this.j2b(value.in_1, value.jn_1, this.p1b(), this.r1b());
  };
  protoOf(AbstractRectangle).hw = function () {
    return new Point2D(this.z19(), this.a1a());
  };
  protoOf(AbstractRectangle).do = function () {
    return new Rectangle2D(this.k2b().z19() - this.l2b(), this.k2b().a1a() - this.l2b(), this.k2b().p1b() + 2 * this.l2b(), this.k2b().r1b() + 2 * this.l2b());
  };
  protoOf(AbstractRectangle).eo = function (x, y) {
    return this.i2b_1.eo(x, y);
  };
  protoOf(AbstractRectangle).k2b = function () {
    return this.i2b_1;
  };
  protoOf(AbstractRectangle).p1b = function () {
    return this.k2b().p1b();
  };
  protoOf(AbstractRectangle).r1b = function () {
    return this.k2b().r1b();
  };
  protoOf(AbstractRectangle).j2b = function (x, y, w, h) {
    this.s1z();
    this.i2b_1.s1b(x, y, w, h);
    this.s1z();
    this.v1z();
  };
  protoOf(AbstractRectangle).fo = function (x, y, w, h) {
    return this.i2b_1.fo(x, y, w, h);
  };
  protoOf(AbstractRectangle).m2b = function (context, borderColor, fillColor, stroke) {
    this.n2b(context, this.i2b_1, borderColor, fillColor, stroke);
  };
  protoOf(AbstractRectangle).n2b = function (context, shape, borderColor, fillColor, stroke) {
    if (!(fillColor == null)) {
      context.t1y_1.l1t(fillColor);
      context.t1y_1.u1u(shape);
    }
    if (!(borderColor == null) && !(stroke == null)) {
      context.t1y_1.o1t(stroke);
      context.t1y_1.l1t(borderColor);
      context.t1y_1.t1u(shape);
    }
  };
  protoOf(AbstractRectangle).o2b = function (context, x, y, w, h, borderColor, fillColor, stroke) {
    this.p2b(context, numberToInt(x), numberToInt(y), numberToInt(w), numberToInt(h), borderColor, fillColor, stroke);
  };
  protoOf(AbstractRectangle).p2b = function (context, x, y, w, h, borderColor, fillColor, stroke) {
    if (!(fillColor == null)) {
      context.t1y_1.l1t(fillColor);
      context.t1y_1.i1u(x, y, w, h);
    }
    if (!(borderColor == null) && !(stroke == null)) {
      context.t1y_1.o1t(stroke);
      context.t1y_1.l1t(borderColor);
      context.t1y_1.e1u(x, y, w, h);
    }
  };
  function AbstractRectangularUnzoomable(halfSize, location) {
    location = location === VOID ? Companion_getInstance().g1a_1 : location;
    AbstractDrawable.call(this);
    this.v2b_1 = ZoomPan_init_$Create$();
    this.w2b_1 = location;
    this.x2b_1 = halfSize;
    this.y2b_1 = new Rectangle2D();
  }
  protoOf(AbstractRectangularUnzoomable).y2a = function (_set____db54di) {
    this.v2b_1 = _set____db54di;
  };
  protoOf(AbstractRectangularUnzoomable).r23 = function () {
    return this.v2b_1;
  };
  protoOf(AbstractRectangularUnzoomable).f20 = function (value) {
    this.s1z();
    this.w2b_1 = value;
    this.s1z();
    this.v1z();
  };
  protoOf(AbstractRectangularUnzoomable).hw = function () {
    return this.w2b_1;
  };
  protoOf(AbstractRectangularUnzoomable).z2b = function (value) {
    this.s1z();
    this.x2b_1 = value;
    this.s1z();
    this.v1z();
  };
  protoOf(AbstractRectangularUnzoomable).p1b = function () {
    return 2 * this.x2b_1;
  };
  protoOf(AbstractRectangularUnzoomable).r1b = function () {
    return 2 * this.x2b_1;
  };
  protoOf(AbstractRectangularUnzoomable).a2c = function () {
    return ensureNotNull(this.r23()).t23_1.q24(this.w2b_1).u1g(ensureNotNull(this.r23()).w23_1());
  };
  protoOf(AbstractRectangularUnzoomable).do = function () {
    this.y2b_1.s1b(this.w2b_1.in_1 - this.x2b_1 / ensureNotNull(this.r23()).u23_1 - this.l2b(), this.w2b_1.jn_1 - this.x2b_1 / ensureNotNull(this.r23()).u23_1 - this.l2b(), 2 * (this.x2b_1 / ensureNotNull(this.r23()).u23_1 + this.l2b()), 2 * (this.x2b_1 / ensureNotNull(this.r23()).u23_1 + this.l2b()));
    return this.y2b_1;
  };
  protoOf(AbstractRectangularUnzoomable).eo = function (x, y) {
    return x >= this.w2b_1.in_1 - this.x2b_1 / ensureNotNull(this.r23()).u23_1 && x <= this.w2b_1.in_1 + this.x2b_1 / ensureNotNull(this.r23()).u23_1 && y >= this.w2b_1.jn_1 - this.x2b_1 / ensureNotNull(this.r23()).u23_1 && y <= this.w2b_1.jn_1 + this.x2b_1 / ensureNotNull(this.r23()).u23_1;
  };
  protoOf(AbstractRectangularUnzoomable).b2c = function () {
    var p = this.a2c();
    return new Rectangle2D(p.in_1 - this.x2b_1, p.jn_1 - this.x2b_1, 2 * this.x2b_1, 2 * this.x2b_1);
  };
  function AbstractStyledDrawable_init_$Init$(styleType, styleProvider, $this) {
    AbstractStyledDrawable.call($this, new StylableImpl(VOID, styleType, styleProvider));
    return $this;
  }
  function AbstractStyledDrawable$lambda(this$0) {
    return function () {
      this$0.s1z();
      return Unit_instance;
    };
  }
  function AbstractStyledDrawable(stylable) {
    AbstractDrawable.call(this);
    this.f2c_1 = stylable;
    stylable.g2c(AbstractStyledDrawable$lambda(this));
  }
  protoOf(AbstractStyledDrawable).g2c = function (_set____db54di) {
    this.f2c_1.g2c(_set____db54di);
  };
  protoOf(AbstractStyledDrawable).h2c = function () {
    return this.f2c_1.h2c();
  };
  protoOf(AbstractStyledDrawable).m1t = function () {
    return this.f2c_1.m1t();
  };
  protoOf(AbstractStyledDrawable).i2c = function () {
    return this.f2c_1.i2c();
  };
  protoOf(AbstractStyledDrawable).j2c = function () {
    return this.f2c_1.j2c();
  };
  protoOf(AbstractStyledDrawable).k2c = function () {
    return this.f2c_1.k2c();
  };
  protoOf(AbstractStyledDrawable).l2c = function () {
    return this.f2c_1.l2c();
  };
  protoOf(AbstractStyledDrawable).v1t = function () {
    return this.f2c_1.v1t();
  };
  protoOf(AbstractStyledDrawable).m2c = function (_set____db54di) {
    this.f2c_1.m2c(_set____db54di);
  };
  protoOf(AbstractStyledDrawable).r28 = function () {
    return this.f2c_1.r28();
  };
  protoOf(AbstractStyledDrawable).n2c = function () {
    return this.f2c_1.n2c();
  };
  protoOf(AbstractStyledDrawable).o2c = function (_set____db54di) {
    this.f2c_1.o2c(_set____db54di);
  };
  protoOf(AbstractStyledDrawable).p2c = function () {
    return this.f2c_1.p2c();
  };
  protoOf(AbstractStyledDrawable).q2c = function (_set____db54di) {
    this.f2c_1.q2c(_set____db54di);
  };
  protoOf(AbstractStyledDrawable).r2c = function () {
    return this.f2c_1.r2c();
  };
  protoOf(AbstractStyledDrawable).s2c = function () {
    return this.f2c_1.s2c();
  };
  protoOf(AbstractStyledDrawable).t2c = function (_set____db54di) {
    this.f2c_1.t2c(_set____db54di);
  };
  protoOf(AbstractStyledDrawable).u2c = function () {
    return this.f2c_1.u2c();
  };
  protoOf(AbstractStyledDrawable).v2c = function (_set____db54di) {
    this.f2c_1.v2c(_set____db54di);
  };
  protoOf(AbstractStyledDrawable).w2c = function () {
    return this.f2c_1.w2c();
  };
  protoOf(AbstractStyledDrawable).x2c = function (_set____db54di) {
    this.f2c_1.x2c(_set____db54di);
  };
  protoOf(AbstractStyledDrawable).y2c = function (_set____db54di) {
    this.f2c_1.y2c(_set____db54di);
  };
  protoOf(AbstractStyledDrawable).z2c = function () {
    return this.f2c_1.z2c();
  };
  function Companion_9() {
    this.a2d_1 = 8.0;
    this.b2d_1 = 15.0;
    this.c2d_1 = 5.0;
    this.d2d_1 = 15.0;
    this.e2d_1 = 50.0;
    this.f2d_1 = 27.5;
  }
  var Companion_instance_13;
  function Companion_getInstance_11() {
    return Companion_instance_13;
  }
  function _get_width__9isoj9($this) {
    // Inline function 'kotlin.math.max' call
    var b = $this.k2d_1.p1b() + 2 * 8.0;
    return Math.max(50.0, b);
  }
  function _get_height__jyis70($this) {
    return $this.k2d_1.r1b() + 2 * 8.0 + 15.0;
  }
  function _get_wideWidth__86esji($this) {
    return _get_width__9isoj9($this) - 27.5;
  }
  function calculateContentLocation($this, position) {
    var tmp;
    if (position.o2d_1) {
      var tmp_0;
      if (position.p2d_1) {
        tmp_0 = new Point2D(-27.5 + 8.0, 15.0 + 8.0);
      } else {
        tmp_0 = new Point2D(-_get_wideWidth__86esji($this) + 8.0, 15.0 + 8.0);
      }
      tmp = tmp_0;
    } else {
      var tmp_1;
      if (position.p2d_1) {
        tmp_1 = new Point2D(-27.5 + 8.0, -_get_height__jyis70($this) + 8.0);
      } else {
        tmp_1 = new Point2D(-_get_wideWidth__86esji($this) + 8.0, -_get_height__jyis70($this) + 8.0);
      }
      tmp = tmp_1;
    }
    return tmp;
  }
  function createPath($this, position) {
    var tmp;
    if (position.o2d_1) {
      var tmp_0;
      if (position.p2d_1) {
        tmp_0 = createBelowRightPath($this);
      } else {
        tmp_0 = createBelowLeftPath($this);
      }
      tmp = tmp_0;
    } else {
      var tmp_1;
      if (position.p2d_1) {
        tmp_1 = createAboveRightPath($this);
      } else {
        tmp_1 = createAboveLeftPath($this);
      }
      tmp = tmp_1;
    }
    return tmp;
  }
  function createBelowRightPath($this) {
    return System_getInstance().am().un(0, 0).wn(15.0 / 2, 15.0).wn(_get_wideWidth__86esji($this) - 5.0, 15.0).zn(_get_wideWidth__86esji($this), 15.0, _get_wideWidth__86esji($this), 15.0 + 5.0).wn(_get_wideWidth__86esji($this), _get_height__jyis70($this) - 5.0).zn(_get_wideWidth__86esji($this), _get_height__jyis70($this), _get_wideWidth__86esji($this) - 5.0, _get_height__jyis70($this)).wn(-27.5 + 5.0, _get_height__jyis70($this)).zn(-27.5, _get_height__jyis70($this), -27.5, _get_height__jyis70($this) - 5.0).wn(-27.5, 15.0 + 5.0).zn(-27.5, 15.0, -27.5 + 5.0, 15.0).wn(-15.0 / 2, 15.0).bo();
  }
  function createBelowLeftPath($this) {
    return System_getInstance().am().un(0, 0).wn(15.0 / 2, 15.0).wn(27.5 - 5.0, 15.0).zn(27.5, 15.0, 27.5, 15.0 + 5.0).wn(27.5, _get_height__jyis70($this) - 5.0).zn(27.5, _get_height__jyis70($this), 27.5 - 5.0, _get_height__jyis70($this)).wn(-_get_wideWidth__86esji($this) + 5.0, _get_height__jyis70($this)).zn(-_get_wideWidth__86esji($this), _get_height__jyis70($this), -_get_wideWidth__86esji($this), _get_height__jyis70($this) - 5.0).wn(-_get_wideWidth__86esji($this), 15.0 + 5.0).zn(-_get_wideWidth__86esji($this), 15.0, -_get_wideWidth__86esji($this) + 5.0, 15.0).wn(-15.0 / 2, 15.0).bo();
  }
  function createAboveRightPath($this) {
    return System_getInstance().am().un(0, 0).wn(-15.0 / 2, -15.0).wn(-27.5 + 5.0, -15.0).zn(-27.5, -15.0, -27.5, -15.0 - 5.0).wn(-27.5, -_get_height__jyis70($this) + 5.0).zn(-27.5, -_get_height__jyis70($this), -27.5 + 5.0, -_get_height__jyis70($this)).wn(_get_wideWidth__86esji($this) - 5.0, -_get_height__jyis70($this)).zn(_get_wideWidth__86esji($this), -_get_height__jyis70($this), _get_wideWidth__86esji($this), -_get_height__jyis70($this) + 5.0).wn(_get_wideWidth__86esji($this), -15.0 - 5.0).zn(_get_wideWidth__86esji($this), -15.0, _get_wideWidth__86esji($this) - 5.0, -15.0).wn(15.0 / 2, -15.0).bo();
  }
  function createAboveLeftPath($this) {
    return System_getInstance().am().un(0, 0).wn(-15.0 / 2, -15.0).wn(-_get_wideWidth__86esji($this) + 5.0, -15.0).zn(-_get_wideWidth__86esji($this), -15.0, -_get_wideWidth__86esji($this), -15.0 - 5.0).wn(-_get_wideWidth__86esji($this), -_get_height__jyis70($this) + 5.0).zn(-_get_wideWidth__86esji($this), -_get_height__jyis70($this), -_get_wideWidth__86esji($this) + 5.0, -_get_height__jyis70($this)).wn(27.5 - 5.0, -_get_height__jyis70($this)).zn(27.5, -_get_height__jyis70($this), 27.5, -_get_height__jyis70($this) + 5.0).wn(27.5, -15.0 - 5.0).zn(27.5, -15.0, 27.5 - 5.0, -15.0).wn(15.0 / 2, -15.0).bo();
  }
  function ArrowBubble(content, position, styleType, styleProvider) {
    styleType = styleType === VOID ? Companion_getInstance_33().o1x_1 : styleType;
    styleProvider = styleProvider === VOID ? DrawStyleModule_getInstance().g1x_1 : styleProvider;
    AbstractStyledDrawable_init_$Init$(styleType, styleProvider, this);
    this.k2d_1 = content;
    this.l2d_1 = position;
    this.m2d_1 = createPath(this, this.l2d_1);
    this.k2d_1.f20(calculateContentLocation(this, this.l2d_1));
    new DrawableOwner(this, this.k2d_1);
  }
  protoOf(ArrowBubble).do = function () {
    return Rectangle2D_init_$Create$(this.m2d_1.do()).z1b(this.n2c().v1t().p1t_1).v1b(this.l2d_1.n2d_1);
  };
  protoOf(ArrowBubble).r1z = function (context) {
    // Inline function 'io.antarescircuit.jabbah.draw.DrawContext.translated' call
    var d = this.l2d_1.n2d_1;
    context.t1y_1.v1c(d.in_1, d.jn_1);
    context.t1y_1.l1t(this.n2c().m1t().i1x_1);
    context.t1y_1.u1u(this.m2d_1);
    context.t1y_1.l1t(this.n2c().m1t().h1x_1);
    context.t1y_1.o1t(this.n2c().v1t());
    context.t1y_1.t1u(this.m2d_1);
    context.t1y_1.l1t(this.n2c().m1t().j1x_1);
    context.t1y_1.w1t(this.n2c().l2c());
    this.k2d_1.r1z(context);
    context.t1y_1.v1c(-d.in_1, -d.jn_1);
  };
  protoOf(ArrowBubble).eo = function (x, y) {
    return this.m2d_1.eo(x - this.l2d_1.n2d_1.in_1, y - this.l2d_1.n2d_1.jn_1);
  };
  function ArrowBubblePosition(location, belowLocation, rightOfLocation) {
    this.n2d_1 = location;
    this.o2d_1 = belowLocation;
    this.p2d_1 = rightOfLocation;
  }
  protoOf(ArrowBubblePosition).toString = function () {
    return 'ArrowBubblePosition(location=' + this.n2d_1.toString() + ', belowLocation=' + this.o2d_1 + ', rightOfLocation=' + this.p2d_1 + ')';
  };
  protoOf(ArrowBubblePosition).hashCode = function () {
    var result = this.n2d_1.hashCode();
    result = imul(result, 31) + getBooleanHashCode(this.o2d_1) | 0;
    result = imul(result, 31) + getBooleanHashCode(this.p2d_1) | 0;
    return result;
  };
  protoOf(ArrowBubblePosition).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof ArrowBubblePosition))
      return false;
    if (!this.n2d_1.equals(other.n2d_1))
      return false;
    if (!(this.o2d_1 === other.o2d_1))
      return false;
    if (!(this.p2d_1 === other.p2d_1))
      return false;
    return true;
  };
  function positionHorizontally($this, content, describable, view) {
    var width = arrowBubbleWidth($this, content.p1b());
    var centerXView = view.s24(describable.h1c());
    var overlapRight = coerceAtLeast(centerXView + width - 27.5 - view.p1b(), 0.0);
    // Inline function 'kotlin.math.abs' call
    var x = coerceAtMost(centerXView - width + 27.5, 0.0);
    var overlapLeft = Math.abs(x);
    var rightOfLocation = overlapRight <= 0.0 || overlapRight <= overlapLeft;
    var positionX = describable.h1c();
    if (rightOfLocation) {
      if (overlapRight > 0) {
        positionX = positionX - (overlapRight + 5);
      }
    } else {
      if (overlapLeft > 0) {
        positionX = positionX + (overlapLeft + 5);
      }
    }
    return new PositionInfo(positionX, rightOfLocation);
  }
  function positionY($this, content, describable, view, preferredBelow) {
    var tmp;
    if (preferredBelow) {
      tmp = preferredBelowPositionY($this, content, describable, view);
    } else {
      tmp = preferredAbovePositionY($this, content, describable, view);
    }
    return tmp;
  }
  function preferredBelowPositionY($this, content, describable, view) {
    var height = arrowBubbleHeight($this, content.r1b());
    var tmp;
    if (view.t24(describable.m1c()) + 10 + height <= view.r1b()) {
      tmp = describable.m1c() + 10;
    } else {
      tmp = describable.k1c() - 10;
    }
    return tmp;
  }
  function preferredAbovePositionY($this, content, describable, view) {
    var height = arrowBubbleHeight($this, content.r1b());
    var tmp;
    if (view.t24(describable.k1c()) - 10 - height >= 0) {
      tmp = describable.k1c() - 10;
    } else {
      tmp = describable.m1c() + 10;
    }
    return tmp;
  }
  function arrowBubbleWidth($this, contentWidth) {
    return contentWidth + 2 * 8.0;
  }
  function arrowBubbleHeight($this, contentHeight) {
    return contentHeight + 2 * 8.0 + 15.0;
  }
  function PositionInfo(coordinate, defaultPosition) {
    this.q2d_1 = coordinate;
    this.r2d_1 = defaultPosition;
  }
  protoOf(PositionInfo).toString = function () {
    return 'PositionInfo(coordinate=' + this.q2d_1 + ', defaultPosition=' + this.r2d_1 + ')';
  };
  protoOf(PositionInfo).hashCode = function () {
    var result = getNumberHashCode(this.q2d_1);
    result = imul(result, 31) + getBooleanHashCode(this.r2d_1) | 0;
    return result;
  };
  protoOf(PositionInfo).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof PositionInfo))
      return false;
    if (!equals(this.q2d_1, other.q2d_1))
      return false;
    if (!(this.r2d_1 === other.r2d_1))
      return false;
    return true;
  };
  function ArrowBubblePositioner() {
    this.s2d_1 = 10;
    this.t2d_1 = 5;
  }
  protoOf(ArrowBubblePositioner).u2d = function (content, describable, view, preferredBelow) {
    var horizontal = positionHorizontally(this, content, describable, view);
    var positionY_0 = positionY(this, content, describable, view, preferredBelow);
    var belowLocation = positionY_0 > describable.m1c();
    return new ArrowBubblePosition(view.v24(new Point2D(horizontal.q2d_1, positionY_0)), belowLocation, horizontal.r2d_1);
  };
  var ArrowBubblePositioner_instance;
  function ArrowBubblePositioner_getInstance() {
    return ArrowBubblePositioner_instance;
  }
  function Colorable() {
  }
  function DefaultDrawableDrawer() {
    AbstractDrawableDrawer.call(this);
  }
  protoOf(DefaultDrawableDrawer).j28 = function (context, drawable) {
    drawable.r1z(context);
    this.m28(context, drawable);
  };
  function VerticalPosition(y, below) {
    this.x2d_1 = y;
    this.y2d_1 = below;
  }
  protoOf(VerticalPosition).toString = function () {
    return 'VerticalPosition(y=' + this.x2d_1 + ', below=' + this.y2d_1 + ')';
  };
  protoOf(VerticalPosition).hashCode = function () {
    var result = getNumberHashCode(this.x2d_1);
    result = imul(result, 31) + getBooleanHashCode(this.y2d_1) | 0;
    return result;
  };
  protoOf(VerticalPosition).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof VerticalPosition))
      return false;
    if (!equals(this.x2d_1, other.x2d_1))
      return false;
    if (!(this.y2d_1 === other.y2d_1))
      return false;
    return true;
  };
  function calculateContentCenterX($this, attendant, attendee, view) {
    var centerXView = view.q24(attendee.n1c());
    var widthHalfView = view.u24(attendant.e1e_1 / 2);
    var rightView = centerXView.in_1 + widthHalfView;
    var leftView = centerXView.in_1 - widthHalfView;
    var overlapRightView = coerceAtLeast(rightView - (view.p1b() - 5 | 0), 0.0);
    // Inline function 'kotlin.math.abs' call
    var x = coerceAtMost(leftView - 5, 0.0);
    var overlapLeftView = Math.abs(x);
    var positionX = attendee.h1c();
    if (overlapRightView > 0 && overlapRightView > overlapLeftView) {
      positionX = positionX - view.p24(overlapRightView);
    } else if (overlapLeftView > 0) {
      positionX = positionX + view.p24(overlapLeftView);
    }
    return positionX;
  }
  function calculateVerticalPosition($this, attendant, attendee, view, preferredBelow, distance) {
    var tmp;
    if (preferredBelow) {
      tmp = preferredBelowPositionY_0($this, attendant, attendee, view, distance);
    } else {
      tmp = preferredAbovePositionY_0($this, attendant, attendee, view, distance);
    }
    return tmp;
  }
  function preferredBelowPositionY_0($this, attendant, attendee, view, distance) {
    var tmp;
    if (view.t24(attendee.m1c() + distance) + view.u24(attendant.f1e_1) <= (view.r1b() - 5 | 0)) {
      tmp = new VerticalPosition(attendee.m1c() + distance, true);
    } else {
      tmp = new VerticalPosition(attendee.k1c() - distance, false);
    }
    return tmp;
  }
  function preferredAbovePositionY_0($this, attendant, attendee, view, distance) {
    var tmp;
    if (view.t24(attendee.k1c() - distance) - view.u24(attendant.f1e_1) >= 5) {
      tmp = new VerticalPosition(attendee.k1c() - distance, false);
    } else {
      tmp = new VerticalPosition(attendee.m1c() + distance, true);
    }
    return tmp;
  }
  function DrawableAttendantPositioner() {
    this.z2d_1 = 5;
  }
  protoOf(DrawableAttendantPositioner).a2e = function (attendant, attendee, view, preferredBelow, distance) {
    var verticalPosition = calculateVerticalPosition(this, attendant, attendee, view, preferredBelow, distance);
    var contentCenterX = calculateContentCenterX(this, attendant, attendee, view);
    var tmp;
    if (verticalPosition.y2d_1) {
      tmp = new Point2D(contentCenterX - attendant.e1e_1 / 2, verticalPosition.x2d_1);
    } else {
      tmp = new Point2D(contentCenterX - attendant.e1e_1 / 2, verticalPosition.x2d_1 - attendant.f1e_1);
    }
    return tmp;
  };
  var DrawableAttendantPositioner_instance;
  function DrawableAttendantPositioner_getInstance() {
    return DrawableAttendantPositioner_instance;
  }
  function ButtonAction() {
  }
  function _get_LOG__e5r759_0($this) {
    var tmp0 = $this.c2e_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('LOG', 1, tmp, DrawableButton$Companion$_get_LOG_$ref_4t34a8(), null);
    return tmp0.j2();
  }
  function createShape($this, location, dimension, round) {
    var tmp;
    if (round) {
      tmp = RoundRectangle2D_init_$Create$(location, dimension, 6.0);
    } else {
      tmp = Rectangle2D_init_$Create$_0(location, dimension);
    }
    return tmp;
  }
  function DrawableButton$Companion$_get_LOG_$ref_4t34a8() {
    return function (p0) {
      return _get_LOG__e5r759_0(p0);
    };
  }
  function DrawableButton_init_$Init$(location, tooltipKey, styleType, styleProvider, action, renderer, $this) {
    tooltipKey = tooltipKey === VOID ? null : tooltipKey;
    styleProvider = styleProvider === VOID ? DrawStyleModule_getInstance().g1x_1 : styleProvider;
    DrawableButton.call($this, location, tooltipKey, new StylableImpl(VOID, styleType, styleProvider), action, renderer);
    return $this;
  }
  function DrawableButton_init_$Create$(location, tooltipKey, styleType, styleProvider, action, renderer) {
    return DrawableButton_init_$Init$(location, tooltipKey, styleType, styleProvider, action, renderer, objectCreate(protoOf(DrawableButton)));
  }
  function Companion_10() {
    Companion_instance_14 = this;
    this.c2e_1 = logger(getKClass(DrawableButton));
    this.d2e_1 = 6.0;
  }
  var Companion_instance_14;
  function Companion_getInstance_12() {
    if (Companion_instance_14 == null)
      new Companion_10();
    return Companion_instance_14;
  }
  function EditInteractionHandler($outer) {
    this.f2e_1 = $outer;
    InputEventHandlerAdapter.call(this);
  }
  protoOf(EditInteractionHandler).c28 = function (context) {
    return this.f2e_1.s2e(context.d22_1) ? this : null;
  };
  protoOf(EditInteractionHandler).j22 = function (context) {
    return this.c28(context instanceof InputEventContext ? context : THROW_CCE());
  };
  protoOf(EditInteractionHandler).d28 = function (context) {
    return this;
  };
  protoOf(EditInteractionHandler).k22 = function (context) {
    return this.d28(context instanceof InputEventContext ? context : THROW_CCE());
  };
  protoOf(EditInteractionHandler).g28 = function (context) {
    if (this.f2e_1.p2e_1) {
      var tmp0_safe_receiver = context.y21_1;
      if (tmp0_safe_receiver == null)
        null;
      else {
        tmp0_safe_receiver.consumeEvent();
      }
      this.f2e_1.m2e_1.b2e(context);
    }
    return null;
  };
  protoOf(EditInteractionHandler).i22 = function (context) {
    return this.g28(context instanceof InputEventContext ? context : THROW_CCE());
  };
  function DrawableButton(location, tooltipKey, stylable, action, renderer, specialColor, round) {
    Companion_getInstance_12();
    tooltipKey = tooltipKey === VOID ? null : tooltipKey;
    specialColor = specialColor === VOID ? null : specialColor;
    round = round === VOID ? false : round;
    AbstractRectangle.call(this, createShape(Companion_getInstance_12(), location, renderer.c1x(), round));
    this.k2e_1 = stylable;
    this.l2e_1 = tooltipKey;
    this.m2e_1 = action;
    this.n2e_1 = renderer;
    this.o2e_1 = specialColor;
    this.p2e_1 = true;
    this.q2e_1 = false;
    this.r2e_1 = this.t2e();
  }
  protoOf(DrawableButton).u2e = function () {
    var tmp0_elvis_lhs = this.o2e_1;
    return tmp0_elvis_lhs == null ? this.m1t() : tmp0_elvis_lhs;
  };
  protoOf(DrawableButton).nq = function (value) {
    if (!(this.p2e_1 === value)) {
      this.p2e_1 = value;
      this.s1z();
      this.u1z();
    }
  };
  protoOf(DrawableButton).v2e = function (value) {
    if (!(this.q2e_1 === value)) {
      this.s1z();
      this.q2e_1 = value;
      this.u1z();
    }
  };
  protoOf(DrawableButton).l2b = function () {
    return this.n2c().v1t().p1t_1;
  };
  protoOf(DrawableButton).o1z = function (context) {
    var tmp = this.r2e_1;
    return isInterface(tmp, InputEventHandler) ? tmp : THROW_CCE();
  };
  protoOf(DrawableButton).y1z = function (context) {
    var tmp0_safe_receiver = this.l2e_1;
    var tmp;
    if (tmp0_safe_receiver == null) {
      tmp = null;
    } else {
      // Inline function 'kotlin.let' call
      tmp = new Tooltip(Translations_getInstance().zm(tmp0_safe_receiver, []), Companion_instance_0.uu(this.d2a(context.d22_1)));
    }
    return tmp;
  };
  protoOf(DrawableButton).v1z = function () {
    this.v2e(false);
    protoOf(AbstractRectangle).v1z.call(this);
  };
  protoOf(DrawableButton).r1z = function (context) {
    this.n2e_1.w2e(this, context);
  };
  protoOf(DrawableButton).t2e = function () {
    return new EditInteractionHandler(this);
  };
  protoOf(DrawableButton).s2e = function (mouseLocation) {
    if (this.no(mouseLocation)) {
      if (!this.q2e_1 && this.p2e_1) {
        _get_LOG__e5r759_0(Companion_getInstance_12()).ol('start hover mode');
        this.v2e(true);
      }
      return true;
    }
    if (this.q2e_1) {
      _get_LOG__e5r759_0(Companion_getInstance_12()).ol('stop hover mode');
      this.v2e(false);
    }
    return false;
  };
  protoOf(DrawableButton).g2c = function (_set____db54di) {
    this.k2e_1.g2c(_set____db54di);
  };
  protoOf(DrawableButton).h2c = function () {
    return this.k2e_1.h2c();
  };
  protoOf(DrawableButton).m1t = function () {
    return this.k2e_1.m1t();
  };
  protoOf(DrawableButton).i2c = function () {
    return this.k2e_1.i2c();
  };
  protoOf(DrawableButton).j2c = function () {
    return this.k2e_1.j2c();
  };
  protoOf(DrawableButton).k2c = function () {
    return this.k2e_1.k2c();
  };
  protoOf(DrawableButton).l2c = function () {
    return this.k2e_1.l2c();
  };
  protoOf(DrawableButton).v1t = function () {
    return this.k2e_1.v1t();
  };
  protoOf(DrawableButton).m2c = function (_set____db54di) {
    this.k2e_1.m2c(_set____db54di);
  };
  protoOf(DrawableButton).r28 = function () {
    return this.k2e_1.r28();
  };
  protoOf(DrawableButton).n2c = function () {
    return this.k2e_1.n2c();
  };
  protoOf(DrawableButton).o2c = function (_set____db54di) {
    this.k2e_1.o2c(_set____db54di);
  };
  protoOf(DrawableButton).p2c = function () {
    return this.k2e_1.p2c();
  };
  protoOf(DrawableButton).q2c = function (_set____db54di) {
    this.k2e_1.q2c(_set____db54di);
  };
  protoOf(DrawableButton).r2c = function () {
    return this.k2e_1.r2c();
  };
  protoOf(DrawableButton).s2c = function () {
    return this.k2e_1.s2c();
  };
  protoOf(DrawableButton).t2c = function (_set____db54di) {
    this.k2e_1.t2c(_set____db54di);
  };
  protoOf(DrawableButton).u2c = function () {
    return this.k2e_1.u2c();
  };
  protoOf(DrawableButton).v2c = function (_set____db54di) {
    this.k2e_1.v2c(_set____db54di);
  };
  protoOf(DrawableButton).w2c = function () {
    return this.k2e_1.w2c();
  };
  protoOf(DrawableButton).x2c = function (_set____db54di) {
    this.k2e_1.x2c(_set____db54di);
  };
  protoOf(DrawableButton).y2c = function (_set____db54di) {
    this.k2e_1.y2c(_set____db54di);
  };
  protoOf(DrawableButton).z2c = function () {
    return this.k2e_1.z2c();
  };
  function IconDrawableButtonRenderer(icon) {
    AbstractDrawableButtonRenderer.call(this);
    this.x2e_1 = icon;
  }
  protoOf(IconDrawableButtonRenderer).c1x = function () {
    return this.x2e_1.y2e();
  };
  protoOf(IconDrawableButtonRenderer).w2e = function (button, context) {
    var tmp;
    if (context.w1y_1) {
      tmp = ensureNotNull(context.x1y_1);
    } else {
      tmp = this.z2e(button);
    }
    var color = tmp;
    context.t1y_1.o1t(button.n2c().v1t());
    this.x2e_1.a2f(context, new Point2D(button.z19(), button.a1a()), color);
  };
  function AbstractDrawableButtonRenderer() {
  }
  protoOf(AbstractDrawableButtonRenderer).z2e = function (button) {
    var tmp;
    if (button.q2e_1) {
      tmp = Themes_getInstance().r2f().n2f_1;
    } else if (!button.p2e_1) {
      tmp = button.u2e().b2f(128);
    } else {
      tmp = button.u2e();
    }
    return tmp;
  };
  function DrawableDrawer() {
  }
  function Companion_11() {
    this.s2f_1 = 200;
    this.t2f_1 = 10;
    this.u2f_1 = 10;
  }
  var Companion_instance_15;
  function Companion_getInstance_13() {
    return Companion_instance_15;
  }
  function updateGeometry($this) {
    var boxCorner = calculateBoxCorner($this, $this.f2g_1, $this.c2g_1);
    $this.e2g_1.s1b(boxCorner.in_1, boxCorner.jn_1, _get_boxWidth__wbofio($this), _get_boxHeight__giqgxt($this));
  }
  function calculateBoxCorner($this, anchor, f) {
    var tmp;
    switch ($this.z2f_1.l2_1) {
      case 1:
        tmp = new Point2D(anchor.in_1 - (($this.a2g_1 / 2 | 0) + 10 | 0) * f, anchor.jn_1 - ($this.d2g_1.r1b() + 20) * f);
        break;
      case 3:
        tmp = new Point2D(anchor.in_1 - (($this.a2g_1 / 2 | 0) + 10 | 0) * f, anchor.jn_1);
        break;
      case 2:
        tmp = new Point2D(anchor.in_1 - _get_boxWidth__wbofio($this) * f, anchor.jn_1 - _get_boxHeight__giqgxt($this) / 2 * f);
        break;
      case 0:
        tmp = new Point2D(anchor.in_1, anchor.jn_1 - _get_boxHeight__giqgxt($this) / 2 * f);
        break;
      default:
        noWhenBranchMatchedException();
        break;
    }
    return tmp;
  }
  function getViewRectangle($this) {
    var anchorView = ensureNotNull($this.g2g_1).t23_1.q24($this.f2g_1).u1g(ensureNotNull($this.g2g_1).w23_1());
    var p = calculateBoxCorner($this, anchorView, $this.c2g_1);
    return new Rectangle2D(p.in_1, p.jn_1, $this.e2g_1.g1h_1 * $this.c2g_1, $this.e2g_1.h1h_1);
  }
  function _get_boxWidth__wbofio($this) {
    return $this.a2g_1 + 2.0 * 10;
  }
  function _get_boxHeight__giqgxt($this) {
    return $this.d2g_1.r1b() + 2.0 * 10;
  }
  function FlexibleTextView(text, anchor, direction, width, isUnzoomable, devicePixelRatio, styleType, styleProvider) {
    width = width === VOID ? 200 : width;
    isUnzoomable = isUnzoomable === VOID ? true : isUnzoomable;
    devicePixelRatio = devicePixelRatio === VOID ? 1.0 : devicePixelRatio;
    styleType = styleType === VOID ? Companion_getInstance_33().l1x_1 : styleType;
    styleProvider = styleProvider === VOID ? DrawStyleModule_getInstance().g1x_1 : styleProvider;
    AbstractStyledDrawable_init_$Init$(styleType, styleProvider, this);
    this.z2f_1 = direction;
    this.a2g_1 = width;
    this.b2g_1 = isUnzoomable;
    this.c2g_1 = this.b2g_1 ? devicePixelRatio : 1.0;
    var tmp = this;
    var tmp_0;
    if (this.b2g_1) {
      tmp_0 = Companion_getInstance_15().t2g(text, this.l2c().u2g(devicePixelRatio), this.a2g_1 * devicePixelRatio);
    } else {
      tmp_0 = Companion_getInstance_15().t2g(text, this.l2c(), this.a2g_1);
    }
    tmp.d2g_1 = tmp_0;
    this.e2g_1 = new Rectangle2D();
    this.f2g_1 = anchor;
    this.g2g_1 = ZoomPan_init_$Create$();
    this.h2g_1 = new TransparentImpl(this);
    updateGeometry(this);
  }
  protoOf(FlexibleTextView).f20 = function (value) {
    this.s1z();
    this.f2g_1 = value;
    updateGeometry(this);
    this.s1z();
    this.v1z();
  };
  protoOf(FlexibleTextView).hw = function () {
    return this.f2g_1;
  };
  protoOf(FlexibleTextView).do = function () {
    if (this.b2g_1) {
      var p = calculateBoxCorner(this, this.f2g_1, 1 / ensureNotNull(this.g2g_1).u23_1);
      return new Rectangle2D(p.in_1 - this.v1t().p1t_1, p.jn_1 - this.v1t().p1t_1, this.e2g_1.g1h_1 / ensureNotNull(this.g2g_1).u23_1 + 2 * this.v1t().p1t_1, this.e2g_1.h1h_1 / ensureNotNull(this.g2g_1).u23_1 + 2 * this.v1t().p1t_1);
    }
    return new Rectangle2D(this.e2g_1.e1h_1 - this.v1t().p1t_1, this.e2g_1.f1h_1 - this.v1t().p1t_1, this.e2g_1.g1h_1 + 2 * this.v1t().p1t_1, this.e2g_1.h1h_1 + 2 * this.v1t().p1t_1);
  };
  protoOf(FlexibleTextView).r1z = function (context) {
    var r = this.b2g_1 ? getViewRectangle(this) : this.e2g_1;
    context.t1y_1.l1t(this.h2g_1.v2g(this.j2c()));
    context.t1y_1.k1u(numberToInt(r.e1h_1), numberToInt(r.f1h_1), numberToInt(r.g1h_1), numberToInt(r.h1h_1), 20, 20);
    context.t1y_1.l1t(this.h2g_1.v2g(this.i2c()));
    context.t1y_1.o1t(this.v1t());
    context.t1y_1.g1u(numberToInt(r.e1h_1), numberToInt(r.f1h_1), numberToInt(r.g1h_1), numberToInt(r.h1h_1), 20, 20);
    context.t1y_1.w1t(this.l2c());
    context.t1y_1.l1t(this.h2g_1.v2g(this.k2c()));
    var tmp2 = r.e1h_1 + 10;
    var tmp = r.f1h_1 + 10;
    // Inline function 'kotlin.math.abs' call
    var x = this.d2g_1.h2h_1.f1h_1;
    // Inline function 'io.antarescircuit.jabbah.draw.DrawContext.translated' call
    var dy = tmp + Math.abs(x);
    context.t1y_1.v1c(tmp2, dy);
    this.d2g_1.r1z(context);
    context.t1y_1.v1c(-tmp2, -dy);
  };
  protoOf(FlexibleTextView).eo = function (x, y) {
    return this.e2g_1.eo(x, y);
  };
  protoOf(FlexibleTextView).y2a = function (value) {
    if (equals(this.g2g_1, value)) {
      return Unit_instance;
    }
    this.s1z();
    this.g2g_1 = value;
    updateGeometry(this);
    this.s1z();
    this.v1z();
  };
  protoOf(FlexibleTextView).k2h = function (value) {
    this.h2g_1.k2h(value);
  };
  protoOf(FlexibleTextView).n2h = function () {
    return this.h2g_1.m2h_1;
  };
  function Locatable() {
  }
  function Mirrorable() {
  }
  function Companion_12() {
  }
  protoOf(Companion_12).r2h = function (movables, offset) {
    this.s2h(movables, offset.in_1, offset.jn_1);
  };
  protoOf(Companion_12).s2h = function (movables, dx, dy) {
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = movables.i();
    while (_iterator__ex2g4s.j()) {
      var element = _iterator__ex2g4s.k();
      element.t2h(movables);
    }
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s_0 = movables.i();
    while (_iterator__ex2g4s_0.j()) {
      var element_0 = _iterator__ex2g4s_0.k();
      element_0.f21(dx, dy);
    }
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s_1 = movables.i();
    while (_iterator__ex2g4s_1.j()) {
      var element_1 = _iterator__ex2g4s_1.k();
      element_1.u2h();
    }
  };
  var Companion_instance_16;
  function Companion_getInstance_14() {
    return Companion_instance_16;
  }
  function Movable() {
  }
  function MoveLocatableAnimation$_init_$lambda_1mj00z($locatable) {
    return function (it) {
      $locatable.f20(it);
      $locatable.u1z();
      return Unit_instance;
    };
  }
  function MoveLocatableAnimation(locatable, sequence, duration, isPausable) {
    isPausable = isPausable === VOID ? true : isPausable;
    AbstractAnimationTask.call(this, locatable, MoveLocatableAnimation$_init_$lambda_1mj00z(locatable), sequence, duration, true, isPausable);
  }
  function Orientable() {
  }
  function RectangularDrawable() {
  }
  function _get_LOG__e5r759_1($this) {
    var tmp0 = $this.i2g_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('LOG', 1, tmp, RichTextDrawable$Companion$_get_LOG_$ref_8c0lc7(), null);
    return tmp0.j2();
  }
  function legacyRichText($this, text, error) {
    _get_LOG__e5r759_1($this).nl('Resorting to legacy format: ' + error.message + ' at ' + error.wy_1.toString());
    return Companion_instance_1.p1k(text);
  }
  function transformToSingleLine($this, richText, font, textMeasurer) {
    var drawable = new RichTextDrawable(richText, font);
    var baselineX = 0.0;
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = richText.sw_1.i();
    while (_iterator__ex2g4s.j()) {
      var element = _iterator__ex2g4s.k();
      // Inline function 'kotlin.collections.forEach' call
      var _iterator__ex2g4s_0 = element.j1k_1.h1k_1.c1k_1.i();
      while (_iterator__ex2g4s_0.j()) {
        var element_0 = _iterator__ex2g4s_0.k();
        // Inline function 'kotlin.also' call
        baselineX = baselineX + createAndAddChunkView(drawable, element_0.n1k_1, element_0.o1k_1, baselineX, 0.0, false, textMeasurer).d2i_1;
      }
      var subscriptX = baselineX + 2;
      var tmp0_safe_receiver = element.k1k_1;
      var tmp1_safe_receiver = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.h1k_1;
      var tmp2_safe_receiver = tmp1_safe_receiver == null ? null : tmp1_safe_receiver.c1k_1;
      if (tmp2_safe_receiver == null)
        null;
      else {
        // Inline function 'kotlin.collections.forEach' call
        var _iterator__ex2g4s_1 = tmp2_safe_receiver.i();
        while (_iterator__ex2g4s_1.j()) {
          var element_1 = _iterator__ex2g4s_1.k();
          // Inline function 'kotlin.also' call
          subscriptX = subscriptX + createAndAddChunkView(drawable, element_1.n1k_1, element_1.o1k_1, subscriptX, +font.o() * 0.2, true, textMeasurer).d2i_1;
        }
      }
      var superscriptX = baselineX + 2;
      var tmp3_safe_receiver = element.l1k_1;
      var tmp4_safe_receiver = tmp3_safe_receiver == null ? null : tmp3_safe_receiver.h1k_1;
      var tmp5_safe_receiver = tmp4_safe_receiver == null ? null : tmp4_safe_receiver.c1k_1;
      if (tmp5_safe_receiver == null)
        null;
      else {
        // Inline function 'kotlin.collections.forEach' call
        var _iterator__ex2g4s_2 = tmp5_safe_receiver.i();
        while (_iterator__ex2g4s_2.j()) {
          var element_2 = _iterator__ex2g4s_2.k();
          // Inline function 'kotlin.also' call
          superscriptX = superscriptX + createAndAddChunkView(drawable, element_2.n1k_1, element_2.o1k_1, superscriptX, (-font.o() | 0) * 0.5, true, textMeasurer).d2i_1;
        }
      }
      var tmp0 = subscriptX;
      // Inline function 'kotlin.math.max' call
      var b = superscriptX;
      baselineX = Math.max(tmp0, b);
    }
    return drawable;
  }
  function transformToMultiline($this, richText, font, preferredWidth, textMeasurer) {
    var drawable = new RichTextDrawable(richText, font);
    var baselineX = 0.0;
    var baselineY = 0.0;
    var lineWidth = 0.0;
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = richText.sw_1.i();
    while (_iterator__ex2g4s.j()) {
      var element = _iterator__ex2g4s.k();
      // Inline function 'kotlin.collections.flatMap' call
      var tmp0 = element.j1k_1.h1k_1.c1k_1;
      // Inline function 'kotlin.collections.flatMapTo' call
      var destination = ArrayList_init_$Create$();
      var _iterator__ex2g4s_0 = tmp0.i();
      while (_iterator__ex2g4s_0.j()) {
        var element_0 = _iterator__ex2g4s_0.k();
        var list = element_0.w1k();
        addAll(destination, list);
      }
      // Inline function 'kotlin.collections.forEach' call
      var _iterator__ex2g4s_1 = destination.i();
      while (_iterator__ex2g4s_1.j()) {
        var element_1 = _iterator__ex2g4s_1.k();
        var lines = split(element_1.n1k_1, charArrayOf([_Char___init__impl__6a9atx(10)]));
        // Inline function 'kotlin.collections.forEachIndexed' call
        var index = 0;
        var _iterator__ex2g4s_2 = lines.i();
        while (_iterator__ex2g4s_2.j()) {
          var item = _iterator__ex2g4s_2.k();
          var _unary__edvuaz = index;
          index = _unary__edvuaz + 1 | 0;
          var index_0 = checkIndexOverflow(_unary__edvuaz);
          var wordView = createChunkView(drawable, item, element_1.o1k_1, baselineX, baselineY, false, textMeasurer);
          var textWidth = wordView.d2i_1;
          if (lineWidth + textWidth > preferredWidth) {
            if (baselineX > 0.0) {
              wordView.j2i(0.0);
              wordView.k2i(wordView.g2i_1 + (wordView.e2i_1 + 3.0));
              addChunkView(drawable, wordView);
              baselineX = wordView.d2i_1;
              baselineY = wordView.g2i_1;
              lineWidth = wordView.d2i_1;
            } else {
              wordView.j2i(0.0);
              wordView.k2i(baselineY);
              addChunkView(drawable, wordView);
              baselineX = 0.0;
              baselineY = baselineY + (wordView.e2i_1 + 3.0);
              lineWidth = 0.0;
            }
          } else {
            wordView.j2i(baselineX);
            wordView.k2i(baselineY);
            addChunkView(drawable, wordView);
            baselineX = baselineX + textWidth;
            lineWidth = lineWidth + textWidth;
          }
          if (index_0 < (lines.o() - 1 | 0)) {
            baselineX = 0.0;
            baselineY = baselineY + (wordView.e2i_1 + 3.0);
            lineWidth = 0.0;
          }
        }
      }
      var subscriptX = baselineX + 2;
      var tmp0_safe_receiver = element.k1k_1;
      var tmp1_safe_receiver = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.h1k_1;
      var tmp2_safe_receiver = tmp1_safe_receiver == null ? null : tmp1_safe_receiver.c1k_1;
      if (tmp2_safe_receiver == null)
        null;
      else {
        // Inline function 'kotlin.collections.forEach' call
        var _iterator__ex2g4s_3 = tmp2_safe_receiver.i();
        while (_iterator__ex2g4s_3.j()) {
          var element_2 = _iterator__ex2g4s_3.k();
          // Inline function 'kotlin.also' call
          subscriptX = subscriptX + createAndAddChunkView(drawable, element_2.n1k_1, element_2.o1k_1, subscriptX, +font.o() * 0.2, true, textMeasurer).d2i_1;
        }
      }
      var superscriptX = baselineX + 2;
      var tmp3_safe_receiver = element.l1k_1;
      var tmp4_safe_receiver = tmp3_safe_receiver == null ? null : tmp3_safe_receiver.h1k_1;
      var tmp5_safe_receiver = tmp4_safe_receiver == null ? null : tmp4_safe_receiver.c1k_1;
      if (tmp5_safe_receiver == null)
        null;
      else {
        // Inline function 'kotlin.collections.forEach' call
        var _iterator__ex2g4s_4 = tmp5_safe_receiver.i();
        while (_iterator__ex2g4s_4.j()) {
          var element_3 = _iterator__ex2g4s_4.k();
          // Inline function 'kotlin.also' call
          superscriptX = superscriptX + createAndAddChunkView(drawable, element_3.n1k_1, element_3.o1k_1, superscriptX, (-font.o() | 0) * 0.5, true, textMeasurer).d2i_1;
        }
      }
      var tmp0_0 = subscriptX;
      // Inline function 'kotlin.math.max' call
      var b = superscriptX;
      baselineX = Math.max(tmp0_0, b);
      lineWidth = baselineX;
    }
    return drawable;
  }
  function RichTextDrawable$Companion$_get_LOG_$ref_8c0lc7() {
    return function (p0) {
      return _get_LOG__e5r759_1(p0);
    };
  }
  function _get_localFont__g8zbd($this) {
    var tmp;
    if ($this.a2i_1) {
      tmp = $this.z2h_1.v1k_1 ? _get_italicIndexFont__oouatc($this.i2i_1) : _get_indexFont__9nm3f4($this.i2i_1);
    } else {
      var tmp_0;
      if ($this.z2h_1.u1k_1) {
        tmp_0 = $this.z2h_1.v1k_1 ? _get_boldItalicFont__jsfamf($this.i2i_1) : _get_boldFont__a9fis7($this.i2i_1);
      } else {
        tmp_0 = $this.z2h_1.v1k_1 ? _get_italicFont__ld5fec($this.i2i_1) : $this.i2i_1.a2h_1;
      }
      tmp = tmp_0;
    }
    return tmp;
  }
  function Companion_13() {
    Companion_instance_17 = this;
    this.i2g_1 = logger(getKClass(RichTextDrawable));
    this.j2g_1 = 0.7;
    this.k2g_1 = 0.2;
    this.l2g_1 = 0.5;
    this.m2g_1 = 2;
    this.n2g_1 = new Stroke(1.0);
    this.o2g_1 = Companion_getInstance_20().w1s_1;
    this.p2g_1 = new Stroke(0.5);
    this.q2g_1 = new Stroke(1.0);
    this.r2g_1 = 3.0;
    this.s2g_1 = true;
  }
  protoOf(Companion_13).l2i = function (text, font, textMeasurer) {
    var tmp;
    try {
      tmp = transformToSingleLine(this, RichTextParser_init_$Create$(text).vy(), font, textMeasurer);
    } catch ($p) {
      var tmp_0;
      if ($p instanceof SyntaxError) {
        var e = $p;
        var tmp_1;
        if (this.s2g_1) {
          tmp_1 = transformToSingleLine(this, legacyRichText(this, text, e), font, textMeasurer);
        } else {
          throw e;
        }
        tmp_0 = tmp_1;
      } else {
        throw $p;
      }
      tmp = tmp_0;
    }
    return tmp;
  };
  protoOf(Companion_13).m2i = function (text, font, textMeasurer, $super) {
    textMeasurer = textMeasurer === VOID ? TextRenderInfoFactory_instance : textMeasurer;
    return $super === VOID ? this.l2i(text, font, textMeasurer) : $super.l2i.call(this, text, font, textMeasurer);
  };
  protoOf(Companion_13).n2i = function (text, font, textMeasurer) {
    return transformToSingleLine(this, Companion_instance_1.p1k(text), font, textMeasurer);
  };
  protoOf(Companion_13).o2i = function (text, font, textMeasurer, $super) {
    textMeasurer = textMeasurer === VOID ? TextRenderInfoFactory_instance : textMeasurer;
    return $super === VOID ? this.n2i(text, font, textMeasurer) : $super.n2i.call(this, text, font, textMeasurer);
  };
  protoOf(Companion_13).p2i = function (text, font, preferredWidth, textMeasurer) {
    var tmp;
    try {
      tmp = transformToMultiline(this, RichTextParser_init_$Create$(text).vy(), font, preferredWidth, textMeasurer);
    } catch ($p) {
      var tmp_0;
      if ($p instanceof SyntaxError) {
        var e = $p;
        var tmp_1;
        if (this.s2g_1) {
          tmp_1 = transformToMultiline(this, legacyRichText(this, text, e), font, preferredWidth, textMeasurer);
        } else {
          throw e;
        }
        tmp_0 = tmp_1;
      } else {
        throw $p;
      }
      tmp = tmp_0;
    }
    return tmp;
  };
  protoOf(Companion_13).t2g = function (text, font, preferredWidth, textMeasurer, $super) {
    textMeasurer = textMeasurer === VOID ? TextRenderInfoFactory_instance : textMeasurer;
    return $super === VOID ? this.p2i(text, font, preferredWidth, textMeasurer) : $super.p2i.call(this, text, font, preferredWidth, textMeasurer);
  };
  var Companion_instance_17;
  function Companion_getInstance_15() {
    if (Companion_instance_17 == null)
      new Companion_13();
    return Companion_instance_17;
  }
  function _get_boldFont__a9fis7($this) {
    var tmp0 = $this.c2h_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('boldFont', 1, tmp, RichTextDrawable$_get_boldFont_$ref_3fkyrn(), null);
    return tmp0.j2();
  }
  function _get_italicFont__ld5fec($this) {
    var tmp0 = $this.d2h_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('italicFont', 1, tmp, RichTextDrawable$_get_italicFont_$ref_wadw6w(), null);
    return tmp0.j2();
  }
  function _get_boldItalicFont__jsfamf($this) {
    var tmp0 = $this.e2h_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('boldItalicFont', 1, tmp, RichTextDrawable$_get_boldItalicFont_$ref_o1qpe5(), null);
    return tmp0.j2();
  }
  function _get_indexFont__9nm3f4($this) {
    var tmp0 = $this.f2h_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('indexFont', 1, tmp, RichTextDrawable$_get_indexFont_$ref_trdqta(), null);
    return tmp0.j2();
  }
  function _get_italicIndexFont__oouatc($this) {
    var tmp0 = $this.g2h_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('italicIndexFont', 1, tmp, RichTextDrawable$_get_italicIndexFont_$ref_pdseky(), null);
    return tmp0.j2();
  }
  function createChunkView($this, text, style, baselineX, baselineY, indexed, textMeasurer) {
    return new ChunkView($this, text, style, baselineX, baselineY, indexed, textMeasurer);
  }
  function createAndAddChunkView($this, text, style, baselineX, baselineY, indexed, textMeasurer) {
    // Inline function 'kotlin.also' call
    var this_0 = createChunkView($this, text, style, baselineX, baselineY, indexed, textMeasurer);
    addChunkView($this, this_0);
    return this_0;
  }
  function addChunkView($this, chunkView) {
    $this.b2h_1.h(chunkView);
    $this.h2h_1.tn(chunkView.b2i_1, chunkView.c2i_1);
    $this.h2h_1.tn(chunkView.b2i_1 + chunkView.d2i_1, chunkView.c2i_1 + chunkView.e2i_1);
    $this.i2b_1.tn(chunkView.b2i_1, chunkView.c2i_1);
    $this.i2b_1.tn(chunkView.b2i_1 + chunkView.d2i_1, chunkView.c2i_1 + chunkView.e2i_1);
  }
  function ChunkView($outer, text, style, baselineX, baselineY, indexed, textMeasurer) {
    indexed = indexed === VOID ? false : indexed;
    this.i2i_1 = $outer;
    this.y2h_1 = text;
    this.z2h_1 = style;
    this.a2i_1 = indexed;
    this.b2i_1 = 0.0;
    this.c2i_1 = 0.0;
    this.d2i_1 = 0.0;
    this.e2i_1 = 0.0;
    this.f2i_1 = baselineX;
    this.g2i_1 = baselineY;
    this.h2i_1 = 0.0;
    var tri = textMeasurer.q2i(this.y2h_1, _get_localFont__g8zbd(this));
    this.h2i_1 = tri.s2i_1;
    this.b2i_1 = baselineX;
    this.c2i_1 = baselineY - this.h2i_1;
    this.d2i_1 = tri.r2i_1.g1h_1;
    this.e2i_1 = tri.r2i_1.h1h_1;
  }
  protoOf(ChunkView).j2i = function (value) {
    this.f2i_1 = value;
    this.b2i_1 = this.f2i_1;
  };
  protoOf(ChunkView).k2i = function (value) {
    this.g2i_1 = value;
    this.c2i_1 = this.g2i_1 - this.h2i_1;
  };
  protoOf(ChunkView).t2i = function (g, maxOverlineLevel) {
    g.w1t(_get_localFont__g8zbd(this));
    g.x1u(this.y2h_1, numberToInt(this.f2i_1), numberToInt(this.g2i_1));
    var inductionVariable = 1;
    var last = this.z2h_1.t1k_1;
    if (inductionVariable <= last)
      do {
        var level = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        g.o1t(Companion_getInstance_15().q2g_1);
        var lineY = this.c2i_1 - 2.5 * (maxOverlineLevel - level | 0);
        if (this.z2h_1.v1k_1) {
          g.d1u(this.b2i_1 + 2, lineY, this.b2i_1 + this.d2i_1, lineY);
        } else {
          g.d1u(this.b2i_1, lineY, this.b2i_1 + this.d2i_1, lineY);
        }
      }
       while (!(level === last));
    if (DrawModule_getInstance().q29_1) {
      var oldColor = g.m1t();
      g.l1t(Companion_getInstance_15().o2g_1);
      g.o1t(Companion_getInstance_15().p2g_1);
      g.f1u(this.b2i_1, this.c2i_1, this.d2i_1, this.e2i_1);
      g.l1t(oldColor);
    }
  };
  function RichTextDrawable$boldFont$delegate$lambda(this$0) {
    return function () {
      return this$0.a2h_1.t25(FontStyle_BOLD_getInstance());
    };
  }
  function RichTextDrawable$_get_boldFont_$ref_3fkyrn() {
    return function (p0) {
      return _get_boldFont__a9fis7(p0);
    };
  }
  function RichTextDrawable$italicFont$delegate$lambda(this$0) {
    return function () {
      return this$0.a2h_1.t25(FontStyle_ITALIC_getInstance());
    };
  }
  function RichTextDrawable$_get_italicFont_$ref_wadw6w() {
    return function (p0) {
      return _get_italicFont__ld5fec(p0);
    };
  }
  function RichTextDrawable$boldItalicFont$delegate$lambda(this$0) {
    return function () {
      return this$0.a2h_1.t25(FontStyle_BOLD_getInstance()).t25(FontStyle_ITALIC_getInstance());
    };
  }
  function RichTextDrawable$_get_boldItalicFont_$ref_o1qpe5() {
    return function (p0) {
      return _get_boldItalicFont__jsfamf(p0);
    };
  }
  function RichTextDrawable$indexFont$delegate$lambda(this$0) {
    return function () {
      return this$0.a2h_1.u2i(numberToInt(this$0.a2h_1.o() * 0.7)).t25(FontStyle_BOLD_getInstance());
    };
  }
  function RichTextDrawable$_get_indexFont_$ref_trdqta() {
    return function (p0) {
      return _get_indexFont__9nm3f4(p0);
    };
  }
  function RichTextDrawable$italicIndexFont$delegate$lambda(this$0) {
    return function () {
      return this$0.a2h_1.u2i(numberToInt(this$0.a2h_1.o() * 0.7)).t25(FontStyle_BOLD_getInstance()).t25(FontStyle_ITALIC_getInstance());
    };
  }
  function RichTextDrawable$_get_italicIndexFont_$ref_pdseky() {
    return function (p0) {
      return _get_italicIndexFont__oouatc(p0);
    };
  }
  function RichTextDrawable(richText, baseFont) {
    Companion_getInstance_15();
    AbstractRectangle_init_$Init$_0(this);
    this.a2h_1 = baseFont;
    var tmp = this;
    // Inline function 'kotlin.collections.mutableListOf' call
    tmp.b2h_1 = ArrayList_init_$Create$();
    var tmp_0 = this;
    tmp_0.c2h_1 = lazy(RichTextDrawable$boldFont$delegate$lambda(this));
    var tmp_1 = this;
    tmp_1.d2h_1 = lazy(RichTextDrawable$italicFont$delegate$lambda(this));
    var tmp_2 = this;
    tmp_2.e2h_1 = lazy(RichTextDrawable$boldItalicFont$delegate$lambda(this));
    var tmp_3 = this;
    tmp_3.f2h_1 = lazy(RichTextDrawable$indexFont$delegate$lambda(this));
    var tmp_4 = this;
    tmp_4.g2h_1 = lazy(RichTextDrawable$italicIndexFont$delegate$lambda(this));
    this.h2h_1 = new Rectangle2D();
    this.i2h_1 = false;
    this.j2h_1 = richText.s1k();
  }
  protoOf(RichTextDrawable).r1z = function (context) {
    this.v2i(context.t1y_1);
  };
  protoOf(RichTextDrawable).v2i = function (g) {
    // Inline function 'kotlin.math.abs' call
    var x = this.h2h_1.f1h_1;
    var ascent = Math.abs(x);
    g.v1c(this.hw().in_1, this.hw().jn_1 + ascent);
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = this.b2h_1.i();
    while (_iterator__ex2g4s.j()) {
      var element = _iterator__ex2g4s.k();
      element.t2i(g, this.j2h_1);
    }
    if (this.i2h_1) {
      var y = ((-numberToInt(ascent) | 0) + this.f1c() | 0) + 1 | 0;
      g.o1t(Companion_getInstance_15().n2g_1);
      g.c1u(0, y, this.e1c(), y);
    }
    g.v1c(-this.hw().in_1, -this.hw().jn_1 - ascent);
  };
  protoOf(RichTextDrawable).l2b = function () {
    return 1.0;
  };
  function createShakeSequence($this, start, range, cycleCount) {
    // Inline function 'kotlin.collections.mutableListOf' call
    var sequences = ArrayList_init_$Create$();
    var inductionVariable = 1;
    if (inductionVariable <= cycleCount)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        sequences.h(new PointRange(start, start.tn(range, 0.0)));
        sequences.h(new PointRange(start.tn(range, 0.0), start.tn(-range, 0.0)));
        sequences.h(new PointRange(start.tn(-range, 0.0), start));
      }
       while (!(i === cycleCount));
    // Inline function 'kotlin.collections.toTypedArray' call
    var tmp$ret$1 = copyToArray(sequences);
    return new CompositeSequence(tmp$ret$1.slice());
  }
  function Companion_14() {
    this.w2i_1 = 200.0;
    this.x2i_1 = 4.0;
    this.y2i_1 = 2;
  }
  var Companion_instance_18;
  function Companion_getInstance_16() {
    return Companion_instance_18;
  }
  function ShakeLocatableAnimation$_init_$lambda_pizhn6($locatable) {
    return function (it) {
      $locatable.f20(it);
      $locatable.u1z();
      return Unit_instance;
    };
  }
  function ShakeLocatableAnimation(locatable, duration, range, cycleCount) {
    duration = duration === VOID ? 200.0 : duration;
    range = range === VOID ? 4.0 : range;
    cycleCount = cycleCount === VOID ? 2 : cycleCount;
    AbstractAnimationTask.call(this, locatable, ShakeLocatableAnimation$_init_$lambda_pizhn6(locatable), createShakeSequence(Companion_instance_18, locatable.hw(), range, cycleCount), duration, false, false);
    this.h2j_1 = locatable;
    this.i2j_1 = this.h2j_1.hw();
  }
  protoOf(ShakeLocatableAnimation).z1o = function () {
    this.h2j_1.f20(this.i2j_1);
    this.h2j_1.u1z();
  };
  function SynchronizedGlowAnimation$consume$ref(p0) {
    var l = function (_this__u8e3s4) {
      p0.o2j(_this__u8e3s4);
      return Unit_instance;
    };
    l.callableName = 'consume';
    return l;
  }
  function _get_LOG__e5r759_2($this) {
    var tmp0 = $this.j2j_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('LOG', 1, tmp, SynchronizedGlowAnimation$_get_LOG_$ref_7fyyg5(), null);
    return tmp0.j2();
  }
  function GlowTask() {
    var tmp = SynchronizedGlowAnimation_getInstance();
    AbstractAnimationTask.call(this, tmp, SynchronizedGlowAnimation$consume$ref(SynchronizedGlowAnimation_getInstance()), new Oscillation(new DoubleRange(255, 16.0)), 300.0, VOID, VOID, 'SynchronizedGlow');
  }
  function startIfNeeded($this) {
    if (!$this.m2j_1) {
      _get_LOG__e5r759_2($this).ol('Start GlowAnimation task');
      if (AnimationModule_getInstance().r1p_1.j1q(SynchronizedGlowAnimation_getInstance()).m()) {
        AnimationModule_getInstance().r1p_1.s1p($this.k2j_1);
      }
      $this.k2j_1.vp();
      $this.m2j_1 = true;
    }
  }
  function stopIfNeeded($this) {
    if ($this.n2j_1.m()) {
      _get_LOG__e5r759_2($this).ol('Stop GlowAnimation task');
      $this.k2j_1.wp();
      $this.m2j_1 = false;
    }
  }
  function SynchronizedGlowAnimation$_get_LOG_$ref_7fyyg5() {
    return function (p0) {
      return _get_LOG__e5r759_2(p0);
    };
  }
  function SynchronizedGlowAnimation() {
    SynchronizedGlowAnimation_instance = this;
    this.j2j_1 = logger(getKClass(SynchronizedGlowAnimation));
    this.k2j_1 = new GlowTask();
    this.l2j_1 = 255;
    this.m2j_1 = false;
    var tmp = this;
    // Inline function 'kotlin.collections.mutableListOf' call
    tmp.n2j_1 = ArrayList_init_$Create$();
  }
  protoOf(SynchronizedGlowAnimation).p2j = function (transparent) {
    if (!this.n2j_1.n(transparent)) {
      _get_LOG__e5r759_2(this).ol('Add glowing object');
      this.n2j_1.h(transparent);
    }
    startIfNeeded(this);
  };
  protoOf(SynchronizedGlowAnimation).q2j = function (transparent) {
    _get_LOG__e5r759_2(this).ol('Remove glowing object');
    this.n2j_1.h2(transparent);
    stopIfNeeded(this);
    transparent.k2h(255);
    transparent.u1z();
  };
  protoOf(SynchronizedGlowAnimation).r2j = function () {
    _get_LOG__e5r759_2(this).ol('Remove all glowing object');
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = this.n2j_1.i();
    while (_iterator__ex2g4s.j()) {
      var element = _iterator__ex2g4s.k();
      element.k2h(255);
      element.u1z();
    }
    this.n2j_1.a2();
    stopIfNeeded(this);
  };
  protoOf(SynchronizedGlowAnimation).o2j = function (value) {
    this.l2j_1 = value;
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = this.n2j_1.i();
    while (_iterator__ex2g4s.j()) {
      var element = _iterator__ex2g4s.k();
      element.k2h(numberToInt(SynchronizedGlowAnimation_getInstance().l2j_1));
      element.u1z();
    }
  };
  var SynchronizedGlowAnimation_instance;
  function SynchronizedGlowAnimation_getInstance() {
    if (SynchronizedGlowAnimation_instance == null)
      new SynchronizedGlowAnimation();
    return SynchronizedGlowAnimation_instance;
  }
  function TransparentImpl(owner) {
    this.l2h_1 = owner;
    this.m2h_1 = 255;
  }
  protoOf(TransparentImpl).k2h = function (value) {
    if (value > 255 || value < 0) {
      throw IllegalArgumentException_init_$Create$("transparency '" + value + "' must be between 0 and 255");
    }
    this.m2h_1 = value;
    this.l2h_1.s1z();
  };
  protoOf(TransparentImpl).n2h = function () {
    return this.m2h_1;
  };
  protoOf(TransparentImpl).l1z = function () {
    return this.l2h_1.l1z();
  };
  protoOf(TransparentImpl).do = function () {
    return this.l2h_1.do();
  };
  protoOf(TransparentImpl).m1z = function (_set____db54di) {
    this.l2h_1.m1z(_set____db54di);
  };
  protoOf(TransparentImpl).n1z = function () {
    return this.l2h_1.n1z();
  };
  protoOf(TransparentImpl).e13 = function (visitor) {
    return this.l2h_1.e13(visitor);
  };
  protoOf(TransparentImpl).o1z = function (context) {
    return this.l2h_1.o1z(context);
  };
  protoOf(TransparentImpl).p1z = function (listener) {
    this.l2h_1.p1z(listener);
  };
  protoOf(TransparentImpl).q1z = function (listener) {
    this.l2h_1.q1z(listener);
  };
  protoOf(TransparentImpl).r1z = function (context) {
    this.l2h_1.r1z(context);
  };
  protoOf(TransparentImpl).s1z = function () {
    this.l2h_1.s1z();
  };
  protoOf(TransparentImpl).u1z = function () {
    this.l2h_1.u1z();
  };
  protoOf(TransparentImpl).v1z = function () {
    this.l2h_1.v1z();
  };
  protoOf(TransparentImpl).eo = function (x, y) {
    return this.l2h_1.eo(x, y);
  };
  protoOf(TransparentImpl).no = function (p) {
    return this.l2h_1.no(p);
  };
  protoOf(TransparentImpl).po = function (rect) {
    return this.l2h_1.po(rect);
  };
  protoOf(TransparentImpl).w1z = function (container) {
    this.l2h_1.w1z(container);
  };
  protoOf(TransparentImpl).x1z = function (container) {
    this.l2h_1.x1z(container);
  };
  protoOf(TransparentImpl).y1z = function (context) {
    return this.l2h_1.y1z(context);
  };
  protoOf(TransparentImpl).z1z = function (x, y) {
    return this.l2h_1.z1z(x, y);
  };
  protoOf(TransparentImpl).es = function () {
    this.l2h_1.es();
  };
  function Companion_15() {
    this.s2j_1 = 0;
    this.t2j_1 = 255;
  }
  protoOf(Companion_15).u2j = function (transparency, color) {
    if (transparency === 255) {
      return color;
    }
    var rate = transparency / 255;
    // Inline function 'kotlin.math.floor' call
    var x = color.a1y_1 * rate;
    var tmp$ret$0 = Math.floor(x);
    return color.b2f(numberToInt(tmp$ret$0));
  };
  var Companion_instance_19;
  function Companion_getInstance_17() {
    return Companion_instance_19;
  }
  function Transparent() {
  }
  function _get_LOG__e5r759_3($this) {
    var tmp0 = $this.v2j_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('LOG', 1, tmp, TransparentAnimation$Companion$_get_LOG_$ref_pt14lq(), null);
    return tmp0.j2();
  }
  function TransparentAnimation$Companion$_get_LOG_$ref_pt14lq() {
    return function (p0) {
      return _get_LOG__e5r759_3(p0);
    };
  }
  function TransparentAnimation$Companion$fadeInOut$1($container, $transparent) {
    this.x2j_1 = $container;
    this.y2j_1 = $transparent;
    AnimationTaskAdapter.call(this);
  }
  protoOf(TransparentAnimation$Companion$fadeInOut$1).c1p = function (task, canceled) {
    _get_LOG__e5r759_3(Companion_getInstance_18()).ol('remove transparent');
    this.x2j_1.m20(this.y2j_1);
  };
  function TransparentAnimation$Companion$fadeInOut$lambda($fadeOutAnimation, $timer) {
    return function (it) {
      _get_LOG__e5r759_3(Companion_getInstance_18()).ol('start fade-out animation');
      $fadeOutAnimation.vp();
      $timer.wp();
      return Unit_instance;
    };
  }
  function TransparentAnimation$Companion$fadeInOut$4($timer) {
    this.z2j_1 = $timer;
    AnimationTaskAdapter.call(this);
  }
  protoOf(TransparentAnimation$Companion$fadeInOut$4).c1p = function (task, canceled) {
    _get_LOG__e5r759_3(Companion_getInstance_18()).ol('start timer');
    if (!canceled) {
      this.z2j_1.vp();
    }
  };
  function Companion_16() {
    Companion_instance_20 = this;
    this.v2j_1 = logger(getKClass(TransparentAnimation));
    this.w2j_1 = 300.0;
  }
  protoOf(Companion_16).a2k = function (transparent, duration) {
    return new TransparentAnimation(transparent, new DoubleRange(0, 255), duration);
  };
  protoOf(Companion_16).b2k = function (transparent, duration) {
    return new TransparentAnimation(transparent, new DoubleRange(255, 0), duration);
  };
  protoOf(Companion_16).c2k = function (transparent, container, fadeInTimeMs, holdTimeMs, fadeOutTimeMs, animator) {
    transparent.k2h(0);
    var fadeOutAnimation = this.b2k(transparent, fadeOutTimeMs);
    fadeOutAnimation.t1o(new TransparentAnimation$Companion$fadeInOut$1(container, transparent));
    animator.s1p(fadeOutAnimation);
    var timer = System_getInstance().ul();
    timer.up(holdTimeMs, VOID, TransparentAnimation$Companion$fadeInOut$lambda(fadeOutAnimation, timer));
    var fadeInAnimation = this.a2k(transparent, fadeInTimeMs);
    fadeInAnimation.t1o(new TransparentAnimation$Companion$fadeInOut$4(timer));
    animator.s1p(fadeInAnimation);
    _get_LOG__e5r759_3(this).ol('start fade-in animation');
    fadeInAnimation.vp();
  };
  var Companion_instance_20;
  function Companion_getInstance_18() {
    if (Companion_instance_20 == null)
      new Companion_16();
    return Companion_instance_20;
  }
  function TransparentAnimation$_init_$lambda_74dix($transparent) {
    return function (it) {
      $transparent.k2h(numberToInt(it));
      $transparent.u1z();
      return Unit_instance;
    };
  }
  function TransparentAnimation(transparent, sequence, duration, key) {
    Companion_getInstance_18();
    key = key === VOID ? null : key;
    AbstractAnimationTask.call(this, transparent, TransparentAnimation$_init_$lambda_74dix(transparent), sequence, duration, VOID, VOID, key);
  }
  function Unzoomable() {
  }
  function _get_LOG__e5r759_4($this) {
    var tmp0 = $this.f1s_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('LOG', 1, tmp, AbstractGraphics2D$Companion$_get_LOG_$ref_iz4qv3(), null);
    return tmp0.j2();
  }
  function AbstractGraphics2D$Companion$_get_LOG_$ref_iz4qv3() {
    return function (p0) {
      return _get_LOG__e5r759_4(p0);
    };
  }
  function Companion_17() {
    Companion_instance_21 = this;
    this.f1s_1 = logger(getKClass(AbstractGraphics2D));
  }
  protoOf(Companion_17).g1s = function (color) {
    var alpha;
    switch (color.a1y_1) {
      case 255:
        alpha = 1.0;
        break;
      case 0:
        alpha = 0.0;
        break;
      default:
        alpha = color.a1y_1 / 255.0;
        break;
    }
    return 'rgba(' + color.x1x_1 + ',' + color.y1x_1 + ',' + color.z1x_1 + ',' + alpha + ')';
  };
  var Companion_instance_21;
  function Companion_getInstance_19() {
    if (Companion_instance_21 == null)
      new Companion_17();
    return Companion_instance_21;
  }
  function AbstractGraphics2D() {
    Companion_getInstance_19();
    this.z1t_1 = 0.0;
  }
  protoOf(AbstractGraphics2D).b1u = function (_set____db54di) {
    this.z1t_1 = _set____db54di;
  };
  protoOf(AbstractGraphics2D).a1u = function () {
    return this.z1t_1;
  };
  protoOf(AbstractGraphics2D).t1u = function (shape) {
    if (shape instanceof Rectangle2D) {
      this.z1u(shape);
    } else {
      if (shape instanceof RoundRectangle2D) {
        this.b1v(shape);
      } else {
        if (shape instanceof Ellipse2D) {
          this.e1v(shape);
        } else {
          if (isInterface(shape, PolylineShape)) {
            this.g1v(shape);
          } else {
            if (shape instanceof Ring2D) {
              this.d1v(shape);
            } else {
              _get_LOG__e5r759_4(Companion_getInstance_19()).kl('Unsupported shape ' + toString(shape));
              throw IllegalArgumentException_init_$Create$('Unsupported shape ' + toString(shape));
            }
          }
        }
      }
    }
  };
  protoOf(AbstractGraphics2D).u1u = function (shape) {
    if (shape instanceof Rectangle2D) {
      this.a1v(shape);
    } else {
      if (shape instanceof RoundRectangle2D) {
        this.c1v(shape);
      } else {
        if (shape instanceof Ellipse2D) {
          this.f1v(shape);
        } else {
          if (isInterface(shape, PolylineShape)) {
            this.h1v(shape);
          } else {
            if (shape instanceof Ring2D) {
              this.d1v(shape);
            } else {
              _get_LOG__e5r759_4(Companion_getInstance_19()).kl('Unsupported shape ' + toString(shape));
              throw IllegalArgumentException_init_$Create$('Unsupported shape ' + toString(shape));
            }
          }
        }
      }
    }
  };
  protoOf(AbstractGraphics2D).z1u = function (rect) {
    this.e1u(numberToInt(rect.e1h_1), numberToInt(rect.f1h_1), numberToInt(rect.g1h_1), numberToInt(rect.h1h_1));
  };
  protoOf(AbstractGraphics2D).a1v = function (rect) {
    this.i1u(numberToInt(rect.e1h_1), numberToInt(rect.f1h_1), numberToInt(rect.g1h_1), numberToInt(rect.h1h_1));
  };
  protoOf(AbstractGraphics2D).b1v = function (rect) {
    this.h1u(rect.z19(), rect.a1a(), rect.p1b(), rect.r1b(), rect.f1i_1, rect.g1i_1);
  };
  protoOf(AbstractGraphics2D).h1u = function (x, y, w, h, arcW, arcH) {
    this.x1s();
    this.j1v(x, y, w, h, arcW, arcH);
    this.d1t();
  };
  protoOf(AbstractGraphics2D).c1v = function (rect) {
    this.l1u(rect.z19(), rect.a1a(), rect.p1b(), rect.r1b(), rect.f1i_1, rect.g1i_1);
  };
  protoOf(AbstractGraphics2D).l1u = function (x, y, w, h, arcW, arcH) {
    this.x1s();
    this.j1v(x, y, w, h, arcW, arcH);
    this.e1t();
  };
  protoOf(AbstractGraphics2D).d1v = function (ring) {
    this.x1s();
    this.k1v(ring.z19(), ring.a1a(), ring.p1b(), ring.r1b(), ring.o1h_1);
    this.e1t();
  };
  protoOf(AbstractGraphics2D).e1v = function (ellipse) {
    this.x1s();
    this.n1u(ellipse.t1f_1, ellipse.u1f_1, ellipse.v1f_1, ellipse.w1f_1);
    this.d1t();
  };
  protoOf(AbstractGraphics2D).f1v = function (ellipse) {
    this.x1s();
    this.n1u(ellipse.t1f_1, ellipse.u1f_1, ellipse.v1f_1, ellipse.w1f_1);
    this.e1t();
  };
  protoOf(AbstractGraphics2D).g1v = function (polyline) {
    this.x1s();
    this.i1v(polyline);
    this.d1t();
    this.f1t();
  };
  protoOf(AbstractGraphics2D).h1v = function (polyline) {
    this.x1s();
    this.i1v(polyline);
    this.e1t();
    this.f1t();
  };
  protoOf(AbstractGraphics2D).i1v = function (polyline) {
    if (polyline.d2k() < 2) {
      return Unit_instance;
    }
    this.y1s(polyline.e2k(0).in_1, polyline.e2k(0).jn_1);
    var inductionVariable = 1;
    var last = polyline.d2k();
    if (inductionVariable < last)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        this.z1s(polyline.e2k(i).in_1, polyline.e2k(i).jn_1);
      }
       while (inductionVariable < last);
  };
  protoOf(AbstractGraphics2D).j1v = function (x, y, w, h, arcW, arcH) {
    var tmp0 = arcW / 2;
    // Inline function 'kotlin.math.min' call
    var b = w / 2;
    var arcWW = Math.min(tmp0, b);
    var tmp0_0 = arcH / 2;
    // Inline function 'kotlin.math.min' call
    var b_0 = h / 2;
    var arcHH = Math.min(tmp0_0, b_0);
    this.y1s(x, y + arcHH);
    this.z1s(x, y + h - arcHH);
    this.a1t(x, y + h, x + arcWW, y + h);
    this.z1s(x + w - arcWW, y + h);
    this.a1t(x + w, y + h, x + w, y + h - arcHH);
    this.z1s(x + w, y + arcHH);
    this.a1t(x + w, y, x + w - arcWW, y);
    this.z1s(x + arcWW, y);
    this.a1t(x, y, x, y + arcHH);
  };
  protoOf(AbstractGraphics2D).n1u = function (x, y, w, h) {
    var kappa = 0.5522848;
    var ox = w / 2 * kappa;
    var oy = h / 2 * kappa;
    var xe = x + w;
    var ye = y + h;
    var xm = x + w / 2;
    var ym = y + h / 2;
    this.y1s(x, ym);
    this.b1t(x, ym - oy, xm - ox, y, xm, y);
    this.b1t(xm + ox, y, xe, ym - oy, xe, ym);
    this.b1t(xe, ym + oy, xm + ox, ye, xm, ye);
    this.b1t(xm - ox, ye, x, ym + oy, x, ym);
  };
  protoOf(AbstractGraphics2D).k1v = function (x, y, w, h, thickness) {
    if (!(w === h)) {
      _get_LOG__e5r759_4(Companion_getInstance_19()).ll('Graphics2DJs: requested ellipsoid ring, but only circular ring supported.');
    }
    this.c1t(x + w / 2, y + w / 2, w / 2, 0.0, 3.141592653589793 * 2, false);
    this.c1t(x + w / 2, y + w / 2, w / 2 - thickness, 0.0, 3.141592653589793 * 2, true);
  };
  function Companion_18() {
    Companion_instance_22 = this;
    this.m1s_1 = 0.7;
    this.n1s_1 = Color_init_$Create$(0, 0, 0);
    this.o1s_1 = Color_init_$Create$(255, 255, 255);
    this.p1s_1 = Color_init_$Create$(255, 0, 0);
    this.q1s_1 = Color_init_$Create$(255, 200, 0);
    this.r1s_1 = Color_init_$Create$(64, 64, 64);
    this.s1s_1 = Color_init_$Create$(128, 128, 128);
    this.t1s_1 = Color_init_$Create$(192, 192, 192);
    this.u1s_1 = Color_init_$Create$(0, 0, 255);
    this.v1s_1 = Color_init_$Create$(255, 255, 0);
    this.w1s_1 = Color_init_$Create$(18, 138, 58);
  }
  var Companion_instance_22;
  function Companion_getInstance_20() {
    if (Companion_instance_22 == null)
      new Companion_18();
    return Companion_instance_22;
  }
  function Color_init_$Init$(red, green, blue, $this) {
    Color.call($this, red, green, blue, 255);
    return $this;
  }
  function Color_init_$Create$(red, green, blue) {
    return Color_init_$Init$(red, green, blue, objectCreate(protoOf(Color)));
  }
  function Color(red, green, blue, alpha) {
    Companion_getInstance_20();
    this.x1x_1 = red;
    this.y1x_1 = green;
    this.z1x_1 = blue;
    this.a1y_1 = alpha;
  }
  protoOf(Color).f2k = function () {
    // Inline function 'kotlin.math.max' call
    var a = numberToInt(this.x1x_1 * 0.7);
    var tmp = Math.max(a, 0);
    // Inline function 'kotlin.math.max' call
    var a_0 = numberToInt(this.y1x_1 * 0.7);
    var tmp_0 = Math.max(a_0, 0);
    // Inline function 'kotlin.math.max' call
    var a_1 = numberToInt(this.z1x_1 * 0.7);
    var tmp$ret$2 = Math.max(a_1, 0);
    return Color_init_$Create$(tmp, tmp_0, tmp$ret$2);
  };
  protoOf(Color).g2k = function () {
    // Inline function 'kotlin.math.min' call
    var a = numberToInt(this.x1x_1 / 0.7);
    var tmp = Math.min(a, 255);
    // Inline function 'kotlin.math.min' call
    var a_0 = numberToInt(this.y1x_1 / 0.7);
    var tmp_0 = Math.min(a_0, 255);
    // Inline function 'kotlin.math.min' call
    var a_1 = numberToInt(this.z1x_1 / 0.7);
    var tmp$ret$2 = Math.min(a_1, 255);
    return Color_init_$Create$(tmp, tmp_0, tmp$ret$2);
  };
  protoOf(Color).h2k = function (other, factor) {
    // Inline function 'kotlin.math.round' call
    var x = this.x1x_1 + (other.x1x_1 - this.x1x_1 | 0) * factor;
    var tmp$ret$0 = round(x);
    var tmp = coerceIn(numberToInt(tmp$ret$0), numberRangeToNumber(0, 255));
    // Inline function 'kotlin.math.round' call
    var x_0 = this.y1x_1 + (other.y1x_1 - this.y1x_1 | 0) * factor;
    var tmp$ret$1 = round(x_0);
    var tmp_0 = coerceIn(numberToInt(tmp$ret$1), numberRangeToNumber(0, 255));
    // Inline function 'kotlin.math.round' call
    var x_1 = this.z1x_1 + (other.z1x_1 - this.z1x_1 | 0) * factor;
    var tmp$ret$2 = round(x_1);
    return Color_init_$Create$(tmp, tmp_0, coerceIn(numberToInt(tmp$ret$2), numberRangeToNumber(0, 255)));
  };
  protoOf(Color).b26 = function (other, factor, $super) {
    factor = factor === VOID ? 0.5 : factor;
    return $super === VOID ? this.h2k(other, factor) : $super.h2k.call(this, other, factor);
  };
  protoOf(Color).b2f = function (alpha) {
    return new Color(this.x1x_1, this.y1x_1, this.z1x_1, alpha);
  };
  protoOf(Color).i2k = function () {
    // Inline function 'kotlin.math.min' call
    var a = this.y1x_1 + 8 | 0;
    var tmp$ret$0 = Math.min(a, 255);
    return new Color(this.x1x_1, tmp$ret$0, this.z1x_1, this.a1y_1);
  };
  protoOf(Color).toString = function () {
    return 'Color(red=' + this.x1x_1 + ', green=' + this.y1x_1 + ', blue=' + this.z1x_1 + ', alpha=' + this.a1y_1 + ')';
  };
  protoOf(Color).hashCode = function () {
    var result = this.x1x_1;
    result = imul(result, 31) + this.y1x_1 | 0;
    result = imul(result, 31) + this.z1x_1 | 0;
    result = imul(result, 31) + this.a1y_1 | 0;
    return result;
  };
  protoOf(Color).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof Color))
      return false;
    if (!(this.x1x_1 === other.x1x_1))
      return false;
    if (!(this.y1x_1 === other.y1x_1))
      return false;
    if (!(this.z1x_1 === other.z1x_1))
      return false;
    if (!(this.a1y_1 === other.a1y_1))
      return false;
    return true;
  };
  function Companion_19() {
  }
  protoOf(Companion_19).j2k = function (start, end, steps, at) {
    var dRed = (end.x1x_1 - start.x1x_1 | 0) / (steps - 1 | 0);
    var dGreen = (end.y1x_1 - start.y1x_1 | 0) / (steps - 1 | 0);
    var dBlue = (end.z1x_1 - start.z1x_1 | 0) / (steps - 1 | 0);
    var red = start.x1x_1 + dRed * at;
    var green = start.y1x_1 + dGreen * at;
    var blue = start.z1x_1 + dBlue * at;
    // Inline function 'kotlin.math.roundToInt' call
    var tmp$ret$0 = roundToInt(red);
    var tmp = coerceIn(tmp$ret$0, numberRangeToNumber(0, 255));
    // Inline function 'kotlin.math.roundToInt' call
    var tmp$ret$1 = roundToInt(green);
    var tmp_0 = coerceIn(tmp$ret$1, numberRangeToNumber(0, 255));
    // Inline function 'kotlin.math.roundToInt' call
    var tmp$ret$2 = roundToInt(blue);
    return Color_init_$Create$(tmp, tmp_0, coerceIn(tmp$ret$2, numberRangeToNumber(0, 255)));
  };
  var Companion_instance_23;
  function Companion_getInstance_21() {
    return Companion_instance_23;
  }
  function createGradient($this) {
    // Inline function 'kotlin.collections.mutableListOf' call
    var result = ArrayList_init_$Create$();
    var inductionVariable = 0;
    var last = $this.m2k_1;
    if (inductionVariable < last)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        result.h(Companion_instance_23.j2k($this.k2k_1, $this.l2k_1, $this.m2k_1, i));
      }
       while (inductionVariable < last);
    return result;
  }
  function ColorGradient$colors$delegate$lambda(this$0) {
    return function () {
      return createGradient(this$0);
    };
  }
  function ColorGradient$_get_colors_$ref_ghx52z() {
    return function (p0) {
      return p0.o2k();
    };
  }
  function ColorGradient(start, end, steps) {
    steps = steps === VOID ? 100 : steps;
    this.k2k_1 = start;
    this.l2k_1 = end;
    this.m2k_1 = steps;
    var tmp = this;
    tmp.n2k_1 = lazy(ColorGradient$colors$delegate$lambda(this));
  }
  protoOf(ColorGradient).o2k = function () {
    var tmp0 = this.n2k_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('colors', 1, tmp, ColorGradient$_get_colors_$ref_ghx52z(), null);
    return tmp0.j2();
  };
  protoOf(ColorGradient).p2k = function (x) {
    var tmp = this.o2k();
    // Inline function 'kotlin.math.roundToInt' call
    var this_0 = coerceIn_0(x, rangeTo(0.0, 1.0)) * this.m2k_1;
    var tmp$ret$0 = roundToInt(this_0);
    return tmp.l(coerceIn(tmp$ret$0, until(0, this.m2k_1)));
  };
  function _get_colors__hj58bp($this) {
    var tmp0 = $this.u2k_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('colors', 1, tmp, CompositeColorGradient$_get_colors_$ref_7qthb2(), null);
    return tmp0.j2();
  }
  function createGradient_0($this) {
    // Inline function 'kotlin.collections.map' call
    var this_0 = (new ColorGradient($this.r2k_1, $this.s2k_1, $this.t2k_1)).o2k();
    // Inline function 'kotlin.collections.mapTo' call
    var destination = ArrayList_init_$Create$_0(collectionSizeOrDefault(this_0, 10));
    var _iterator__ex2g4s = this_0.i();
    while (_iterator__ex2g4s.j()) {
      var item = _iterator__ex2g4s.k();
      var tmp$ret$2 = new CompositeColor(item, $this.q2k_1);
      destination.h(tmp$ret$2);
    }
    return toList(destination);
  }
  function CompositeColorGradient$colors$delegate$lambda(this$0) {
    return function () {
      return createGradient_0(this$0);
    };
  }
  function CompositeColorGradient$_get_colors_$ref_7qthb2() {
    return function (p0) {
      return _get_colors__hj58bp(p0);
    };
  }
  function CompositeColorGradient(background, start, end, steps) {
    steps = steps === VOID ? 100 : steps;
    this.q2k_1 = background;
    this.r2k_1 = start;
    this.s2k_1 = end;
    this.t2k_1 = steps;
    var tmp = this;
    tmp.u2k_1 = lazy(CompositeColorGradient$colors$delegate$lambda(this));
  }
  protoOf(CompositeColorGradient).p2k = function (x) {
    var tmp = _get_colors__hj58bp(this);
    // Inline function 'kotlin.math.roundToInt' call
    var this_0 = coerceIn_0(x, rangeTo(0.0, 1.0)) * this.t2k_1;
    var tmp$ret$0 = roundToInt(this_0);
    return tmp.l(coerceIn(tmp$ret$0, until(0, this.t2k_1)));
  };
  function Companion_20() {
    this.v2k_1 = 0.083333336;
    this.w2k_1 = 0.6;
  }
  protoOf(Companion_20).x2k = function (foregroundColor, backgroundColor) {
    return new CompositeColor(foregroundColor, backgroundColor, foregroundColor.g2k().g2k());
  };
  protoOf(Companion_20).y2k = function (foregroundColor, backgroundColor) {
    return new CompositeColor(foregroundColor, backgroundColor, foregroundColor.f2k());
  };
  var Companion_instance_24;
  function Companion_getInstance_22() {
    return Companion_instance_24;
  }
  function CompositeColor(foregroundColor, backgroundColor, textColor) {
    foregroundColor = foregroundColor === VOID ? Themes_getInstance().r2f().j2f_1.m1t().h1x_1 : foregroundColor;
    backgroundColor = backgroundColor === VOID ? Themes_getInstance().r2f().h2f_1.m1t().i1x_1 : backgroundColor;
    textColor = textColor === VOID ? foregroundColor : textColor;
    this.h1x_1 = foregroundColor;
    this.i1x_1 = backgroundColor;
    this.j1x_1 = textColor;
  }
  protoOf(CompositeColor).z2k = function () {
    // Inline function 'kotlin.math.ceil' call
    var x = (this.i1x_1.x1x_1 + this.j1x_1.x1x_1 | 0) / 2.0;
    var tmp$ret$0 = Math.ceil(x);
    var tmp = numberToInt(tmp$ret$0);
    // Inline function 'kotlin.math.ceil' call
    var x_0 = (this.i1x_1.y1x_1 + this.j1x_1.y1x_1 | 0) / 2.0;
    var tmp$ret$1 = Math.ceil(x_0);
    var tmp_0 = numberToInt(tmp$ret$1);
    // Inline function 'kotlin.math.ceil' call
    var x_1 = (this.i1x_1.z1x_1 + this.j1x_1.z1x_1 | 0) / 2.0;
    var tmp$ret$2 = Math.ceil(x_1);
    return Color_init_$Create$(tmp, tmp_0, numberToInt(tmp$ret$2));
  };
  protoOf(CompositeColor).a2l = function (color) {
    return new CompositeColor(this.h1x_1, color, this.j1x_1);
  };
  protoOf(CompositeColor).b2f = function (alpha) {
    return new CompositeColor(this.h1x_1.b2f(alpha), this.i1x_1.b2f(alpha), this.j1x_1.b2f(alpha));
  };
  protoOf(CompositeColor).b2l = function () {
    return new CompositeColor(this.h1x_1, this.i1x_1.h2k(this.j1x_1, 0.083333336), this.j1x_1);
  };
  protoOf(CompositeColor).c2l = function () {
    return new CompositeColor(this.h1x_1, this.i1x_1, this.j1x_1.h2k(this.i1x_1, 0.6));
  };
  protoOf(CompositeColor).f2k = function () {
    return new CompositeColor(this.h1x_1.f2k(), this.i1x_1.f2k(), this.j1x_1.f2k());
  };
  protoOf(CompositeColor).toString = function () {
    return 'CompositeColor(foregroundColor=' + this.h1x_1.toString() + ', backgroundColor=' + this.i1x_1.toString() + ', textColor=' + this.j1x_1.toString() + ')';
  };
  protoOf(CompositeColor).hashCode = function () {
    var result = this.h1x_1.hashCode();
    result = imul(result, 31) + this.i1x_1.hashCode() | 0;
    result = imul(result, 31) + this.j1x_1.hashCode() | 0;
    return result;
  };
  protoOf(CompositeColor).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof CompositeColor))
      return false;
    if (!this.h1x_1.equals(other.h1x_1))
      return false;
    if (!this.i1x_1.equals(other.i1x_1))
      return false;
    if (!this.j1x_1.equals(other.j1x_1))
      return false;
    return true;
  };
  var Cursor_DEFAULT_instance;
  var Cursor_WAIT_instance;
  var Cursor_CLICK_instance;
  var Cursor_MOVE_instance;
  var Cursor_CROSSHAIR_instance;
  var Cursor_NW_RESIZE_instance;
  var Cursor_N_RESIZE_instance;
  var Cursor_NE_RESIZE_instance;
  var Cursor_E_RESIZE_instance;
  var Cursor_SE_RESIZE_instance;
  var Cursor_S_RESIZE_instance;
  var Cursor_SW_RESIZE_instance;
  var Cursor_W_RESIZE_instance;
  var Cursor_TEXT_instance;
  var Cursor_entriesInitialized;
  function Cursor_initEntries() {
    if (Cursor_entriesInitialized)
      return Unit_instance;
    Cursor_entriesInitialized = true;
    Cursor_DEFAULT_instance = new Cursor('DEFAULT', 0);
    Cursor_WAIT_instance = new Cursor('WAIT', 1);
    Cursor_CLICK_instance = new Cursor('CLICK', 2);
    Cursor_MOVE_instance = new Cursor('MOVE', 3);
    Cursor_CROSSHAIR_instance = new Cursor('CROSSHAIR', 4);
    Cursor_NW_RESIZE_instance = new Cursor('NW_RESIZE', 5);
    Cursor_N_RESIZE_instance = new Cursor('N_RESIZE', 6);
    Cursor_NE_RESIZE_instance = new Cursor('NE_RESIZE', 7);
    Cursor_E_RESIZE_instance = new Cursor('E_RESIZE', 8);
    Cursor_SE_RESIZE_instance = new Cursor('SE_RESIZE', 9);
    Cursor_S_RESIZE_instance = new Cursor('S_RESIZE', 10);
    Cursor_SW_RESIZE_instance = new Cursor('SW_RESIZE', 11);
    Cursor_W_RESIZE_instance = new Cursor('W_RESIZE', 12);
    Cursor_TEXT_instance = new Cursor('TEXT', 13);
  }
  function Cursor(name, ordinal) {
    Enum.call(this, name, ordinal);
  }
  function Cursor_DEFAULT_getInstance() {
    Cursor_initEntries();
    return Cursor_DEFAULT_instance;
  }
  function Cursor_CLICK_getInstance() {
    Cursor_initEntries();
    return Cursor_CLICK_instance;
  }
  function Cursor_MOVE_getInstance() {
    Cursor_initEntries();
    return Cursor_MOVE_instance;
  }
  function Cursor_CROSSHAIR_getInstance() {
    Cursor_initEntries();
    return Cursor_CROSSHAIR_instance;
  }
  function Cursor_NW_RESIZE_getInstance() {
    Cursor_initEntries();
    return Cursor_NW_RESIZE_instance;
  }
  function Cursor_N_RESIZE_getInstance() {
    Cursor_initEntries();
    return Cursor_N_RESIZE_instance;
  }
  function Cursor_NE_RESIZE_getInstance() {
    Cursor_initEntries();
    return Cursor_NE_RESIZE_instance;
  }
  function Cursor_E_RESIZE_getInstance() {
    Cursor_initEntries();
    return Cursor_E_RESIZE_instance;
  }
  function Cursor_SE_RESIZE_getInstance() {
    Cursor_initEntries();
    return Cursor_SE_RESIZE_instance;
  }
  function Cursor_S_RESIZE_getInstance() {
    Cursor_initEntries();
    return Cursor_S_RESIZE_instance;
  }
  function Cursor_SW_RESIZE_getInstance() {
    Cursor_initEntries();
    return Cursor_SW_RESIZE_instance;
  }
  function Cursor_W_RESIZE_getInstance() {
    Cursor_initEntries();
    return Cursor_W_RESIZE_instance;
  }
  function fillProperties_0($this, properties) {
    properties.ct('draw.graphics.shadow', false);
    properties.ct('draw.graphics.dropShadow.offset', 2);
  }
  function predefineColors($this, repository) {
    repository.l2m(new PredefinedColor(PredefinedColorIdentity_White_getInstance(), $this.u2l_1));
    repository.l2m(new PredefinedColor(PredefinedColorIdentity_Black_getInstance(), $this.v2l_1));
    repository.l2m(new PredefinedColor(PredefinedColorIdentity_Gray_getInstance(), $this.w2l_1));
    repository.l2m(new PredefinedColor(PredefinedColorIdentity_Yellow_getInstance(), $this.k2l_1));
    repository.l2m(new PredefinedColor(PredefinedColorIdentity_Brown_getInstance(), $this.q2l_1));
    repository.l2m(new PredefinedColor(PredefinedColorIdentity_Red_getInstance(), $this.e2l_1));
    repository.l2m(new PredefinedColor(PredefinedColorIdentity_Violet_getInstance(), $this.m2l_1));
    repository.l2m(new PredefinedColor(PredefinedColorIdentity_Blue_getInstance(), $this.g2l_1));
    repository.l2m(new PredefinedColor(PredefinedColorIdentity_Turquoise_getInstance(), $this.s2l_1));
    repository.l2m(new PredefinedColor(PredefinedColorIdentity_Green_getInstance(), $this.i2l_1));
  }
  function predefineStrokes($this, repository) {
    repository.p2m(new PredefinedStroke(PredefinedStrokeIdentity_ThinDotted_getInstance(), $this.z2l_1));
    repository.p2m(new PredefinedStroke(PredefinedStrokeIdentity_ThinSolid_getInstance(), $this.a2m_1));
    repository.p2m(new PredefinedStroke(PredefinedStrokeIdentity_ThinDashed_getInstance(), $this.b2m_1));
    repository.p2m(new PredefinedStroke(PredefinedStrokeIdentity_NormalDotted_getInstance(), $this.c2m_1));
    repository.p2m(new PredefinedStroke(PredefinedStrokeIdentity_NormalSolid_getInstance(), $this.d2m_1));
    repository.p2m(new PredefinedStroke(PredefinedStrokeIdentity_NormalDashed_getInstance(), $this.e2m_1));
    repository.p2m(new PredefinedStroke(PredefinedStrokeIdentity_ThickDotted_getInstance(), $this.f2m_1));
    repository.p2m(new PredefinedStroke(PredefinedStrokeIdentity_ThickSolid_getInstance(), $this.g2m_1));
    repository.p2m(new PredefinedStroke(PredefinedStrokeIdentity_ThickDashed_getInstance(), $this.h2m_1));
  }
  function DrawGraphicsModule() {
    DrawGraphicsModule_instance = this;
    AbstractModule.call(this);
    this.e2l_1 = Companion_instance_24.y2k(Color_init_$Create$(236, 35, 46), Color_init_$Create$(248, 170, 145));
    this.f2l_1 = new CompositeColor(Color_init_$Create$(236, 35, 46), Color_init_$Create$(90, 3, 7), Color_init_$Create$(255, 204, 204));
    this.g2l_1 = Companion_instance_24.y2k(Color_init_$Create$(72, 186, 233), Color_init_$Create$(185, 223, 245));
    this.h2l_1 = Companion_instance_24.x2k(Color_init_$Create$(44, 116, 179), Color_init_$Create$(20, 66, 114));
    this.i2l_1 = Companion_instance_24.y2k(Color_init_$Create$(115, 191, 91), Color_init_$Create$(198, 226, 184));
    this.j2l_1 = Companion_instance_24.x2k(Color_init_$Create$(115, 191, 91), Color_init_$Create$(7, 87, 9));
    this.k2l_1 = Companion_instance_24.y2k(Color_init_$Create$(254, 209, 58), Color_init_$Create$(251, 245, 183));
    this.l2l_1 = new CompositeColor(Color_init_$Create$(245, 235, 62), Color_init_$Create$(67, 69, 10), Color_init_$Create$(255, 255, 228));
    this.m2l_1 = Companion_instance_24.y2k(Color_init_$Create$(91, 84, 161), Color_init_$Create$(211, 207, 231));
    this.n2l_1 = Companion_instance_24.x2k(Color_init_$Create$(125, 108, 171), Color_init_$Create$(55, 14, 91));
    this.o2l_1 = Companion_instance_24.y2k(Color_init_$Create$(234, 34, 123), Color_init_$Create$(250, 214, 223));
    this.p2l_1 = Companion_instance_24.x2k(Color_init_$Create$(188, 126, 179), Color_init_$Create$(104, 8, 89));
    this.q2l_1 = Companion_instance_24.y2k(Color_init_$Create$(149, 92, 11), Color_init_$Create$(234, 173, 85));
    this.r2l_1 = new CompositeColor(Color_init_$Create$(203, 119, 18), Color_init_$Create$(94, 65, 4), Color_init_$Create$(255, 197, 109));
    this.s2l_1 = Companion_instance_24.y2k(Color_init_$Create$(69, 181, 172), Color_init_$Create$(187, 255, 242));
    this.t2l_1 = Companion_instance_24.x2k(Color_init_$Create$(69, 213, 203), Color_init_$Create$(12, 86, 103));
    this.u2l_1 = new CompositeColor(Companion_getInstance_20().n1s_1, Companion_getInstance_20().o1s_1);
    this.v2l_1 = new CompositeColor(Companion_getInstance_20().o1s_1, Companion_getInstance_20().n1s_1);
    this.w2l_1 = new CompositeColor(Color_init_$Create$(114, 114, 114), Color_init_$Create$(227, 227, 227));
    this.x2l_1 = Companion_instance_24.x2k(Color_init_$Create$(104, 104, 104), Color_init_$Create$(64, 64, 64));
    var tmp = this;
    // Inline function 'kotlin.floatArrayOf' call
    tmp.y2l_1 = new Float32Array([1.0, 5.0]);
    this.z2l_1 = new Stroke(0.5, VOID, VOID, VOID, this.y2l_1);
    this.a2m_1 = new Stroke(0.5);
    var tmp_0 = this;
    // Inline function 'kotlin.floatArrayOf' call
    var tmp$ret$1 = new Float32Array([5.0]);
    tmp_0.b2m_1 = new Stroke(0.5, VOID, VOID, VOID, tmp$ret$1);
    this.c2m_1 = new Stroke(1.5, VOID, VOID, VOID, this.y2l_1);
    this.d2m_1 = new Stroke(1.5);
    var tmp_1 = this;
    // Inline function 'kotlin.floatArrayOf' call
    var tmp$ret$2 = new Float32Array([5.0]);
    tmp_1.e2m_1 = new Stroke(1.5, VOID, VOID, VOID, tmp$ret$2);
    this.f2m_1 = new Stroke(3.0, VOID, VOID, VOID, this.y2l_1);
    this.g2m_1 = new Stroke(3.0);
    var tmp_2 = this;
    // Inline function 'kotlin.floatArrayOf' call
    var tmp$ret$3 = new Float32Array([5.0]);
    tmp_2.h2m_1 = new Stroke(3.0, VOID, VOID, VOID, tmp$ret$3);
  }
  protoOf(DrawGraphicsModule).ro = function () {
    BaseModule_getInstance().to();
    predefineColors(this, PredefinedColorRepository_getInstance());
    predefineStrokes(this, PredefinedStrokeRepository_getInstance());
    fillProperties_0(this, DrawModule_getInstance().v29_1);
  };
  var DrawGraphicsModule_instance;
  function DrawGraphicsModule_getInstance() {
    if (DrawGraphicsModule_instance == null)
      new DrawGraphicsModule();
    return DrawGraphicsModule_instance;
  }
  function _get_useShadow__eh2mae($this) {
    return BaseModule_getInstance().xo_1.ft('draw.graphics.shadow');
  }
  function DropShadow() {
    this.q2m_1 = 'draw.graphics.dropShadow.offset';
    this.r2m_1 = 'draw.graphics.shadow';
  }
  protoOf(DropShadow).s2m = function () {
    return BaseModule_getInstance().xo_1.it('draw.graphics.dropShadow.offset');
  };
  protoOf(DropShadow).t2m = function (context) {
    if (_get_useShadow__eh2mae(this)) {
      var p = Geometry_instance.f1g(this.s2m(), this.s2m(), -context.t1y_1.a1u());
      context.t1y_1.v1c(p.in_1, p.jn_1);
    }
  };
  protoOf(DropShadow).u2m = function (context) {
    if (_get_useShadow__eh2mae(this)) {
      var p = Geometry_instance.f1g(this.s2m(), this.s2m(), -context.t1y_1.a1u());
      context.t1y_1.v1c(-p.in_1, -p.jn_1);
    }
  };
  protoOf(DropShadow).v2m = function (context, transparency, drawer) {
    if (_get_useShadow__eh2mae(this) && transparency === 255) {
      this.t2m(context);
      context.t1y_1.l1t(context.a1z(Themes_getInstance().r2f().m2f_1).h1x_1);
      drawer(context);
      this.u2m(context);
    }
  };
  protoOf(DropShadow).w2m = function (rect, rotation) {
    if (_get_useShadow__eh2mae(this)) {
      switch (rotation.l2_1) {
        case 0:
          rect.a1c(0.0, 0.0, this.s2m(), this.s2m());
          break;
        case 1:
          rect.a1c(0.0, this.s2m(), this.s2m(), 0.0);
          break;
        case 2:
          rect.a1c(this.s2m(), this.s2m(), 0.0, 0.0);
          break;
        case 3:
          rect.a1c(this.s2m(), 0.0, 0.0, this.s2m());
          break;
        default:
          noWhenBranchMatchedException();
          break;
      }
    }
  };
  var DropShadow_instance;
  function DropShadow_getInstance() {
    return DropShadow_instance;
  }
  function FontImpl(family, style, size) {
    family = family === VOID ? LogicalFontFamily_SANS_SERIF_getInstance() : family;
    style = style === VOID ? FontStyle_PLAIN_getInstance().z2m_1 : style;
    size = size === VOID ? 12 : size;
    this.q25_1 = family;
    this.r25_1 = style;
    this.s25_1 = size;
  }
  protoOf(FontImpl).m1r = function () {
    return this.q25_1;
  };
  protoOf(FontImpl).o = function () {
    return this.s25_1;
  };
  protoOf(FontImpl).k1r = function () {
    return !((this.r25_1 & FontStyle_BOLD_getInstance().z2m_1) === 0);
  };
  protoOf(FontImpl).l1r = function () {
    return !((this.r25_1 & FontStyle_ITALIC_getInstance().z2m_1) === 0);
  };
  protoOf(FontImpl).t25 = function (style) {
    var tmp;
    if (style.equals(FontStyle_PLAIN_getInstance())) {
      tmp = this.a2n(VOID, FontStyle_PLAIN_getInstance().z2m_1);
    } else {
      tmp = this.a2n(VOID, this.r25_1 | style.z2m_1);
    }
    return tmp;
  };
  protoOf(FontImpl).u2i = function (size) {
    return this.a2n(VOID, VOID, size);
  };
  protoOf(FontImpl).b2n = function (family) {
    return this.a2n(family);
  };
  protoOf(FontImpl).u2g = function (factor) {
    var tmp;
    if (factor === 1.0) {
      tmp = this;
    } else {
      tmp = this.u2i(numberToInt(this.s25_1 * factor));
    }
    return tmp;
  };
  protoOf(FontImpl).c2n = function (family, style, size) {
    return new FontImpl(family, style, size);
  };
  protoOf(FontImpl).a2n = function (family, style, size, $super) {
    family = family === VOID ? this.q25_1 : family;
    style = style === VOID ? this.r25_1 : style;
    size = size === VOID ? this.s25_1 : size;
    return $super === VOID ? this.c2n(family, style, size) : $super.c2n.call(this, family, style, size);
  };
  protoOf(FontImpl).toString = function () {
    return 'FontImpl(family=' + toString(this.q25_1) + ', style=' + this.r25_1 + ', size=' + this.s25_1 + ')';
  };
  protoOf(FontImpl).hashCode = function () {
    var result = hashCode(this.q25_1);
    result = imul(result, 31) + this.r25_1 | 0;
    result = imul(result, 31) + this.s25_1 | 0;
    return result;
  };
  protoOf(FontImpl).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof FontImpl))
      return false;
    if (!equals(this.q25_1, other.q25_1))
      return false;
    if (!(this.r25_1 === other.r25_1))
      return false;
    if (!(this.s25_1 === other.s25_1))
      return false;
    return true;
  };
  var FontStyle_PLAIN_instance;
  var FontStyle_BOLD_instance;
  var FontStyle_ITALIC_instance;
  var FontStyle_entriesInitialized;
  function FontStyle_initEntries() {
    if (FontStyle_entriesInitialized)
      return Unit_instance;
    FontStyle_entriesInitialized = true;
    FontStyle_PLAIN_instance = new FontStyle('PLAIN', 0, 0);
    FontStyle_BOLD_instance = new FontStyle('BOLD', 1, 1);
    FontStyle_ITALIC_instance = new FontStyle('ITALIC', 2, 2);
  }
  function FontStyle(name, ordinal, value) {
    Enum.call(this, name, ordinal);
    this.z2m_1 = value;
  }
  var LogicalFontFamily_SERIF_instance;
  var LogicalFontFamily_SANS_SERIF_instance;
  var LogicalFontFamily_MONOSPACED_instance;
  var LogicalFontFamily_DIALOG_instance;
  function Companion_21() {
  }
  var Companion_instance_25;
  function Companion_getInstance_23() {
    return Companion_instance_25;
  }
  function values() {
    return [LogicalFontFamily_SERIF_getInstance(), LogicalFontFamily_SANS_SERIF_getInstance(), LogicalFontFamily_MONOSPACED_getInstance(), LogicalFontFamily_DIALOG_getInstance()];
  }
  function get_entries() {
    if ($ENTRIES == null)
      $ENTRIES = enumEntries(values());
    return $ENTRIES;
  }
  var LogicalFontFamily_entriesInitialized;
  function LogicalFontFamily_initEntries() {
    if (LogicalFontFamily_entriesInitialized)
      return Unit_instance;
    LogicalFontFamily_entriesInitialized = true;
    LogicalFontFamily_SERIF_instance = new LogicalFontFamily('SERIF', 0, 'Serif', 'serif');
    LogicalFontFamily_SANS_SERIF_instance = new LogicalFontFamily('SANS_SERIF', 1, 'SansSerif', 'sans-serif');
    LogicalFontFamily_MONOSPACED_instance = new LogicalFontFamily('MONOSPACED', 2, 'Monospaced', 'monospace');
    LogicalFontFamily_DIALOG_instance = new LogicalFontFamily('DIALOG', 3, 'Dialog', 'sans-serif');
  }
  var $ENTRIES;
  function LogicalFontFamily(name, ordinal, javaName, jsName) {
    Enum.call(this, name, ordinal);
    this.q1r_1 = javaName;
    this.r1r_1 = jsName;
  }
  protoOf(LogicalFontFamily).n1r = function () {
    return this.q1r_1;
  };
  function FontStyle_PLAIN_getInstance() {
    FontStyle_initEntries();
    return FontStyle_PLAIN_instance;
  }
  function FontStyle_BOLD_getInstance() {
    FontStyle_initEntries();
    return FontStyle_BOLD_instance;
  }
  function FontStyle_ITALIC_getInstance() {
    FontStyle_initEntries();
    return FontStyle_ITALIC_instance;
  }
  function LogicalFontFamily_SERIF_getInstance() {
    LogicalFontFamily_initEntries();
    return LogicalFontFamily_SERIF_instance;
  }
  function LogicalFontFamily_SANS_SERIF_getInstance() {
    LogicalFontFamily_initEntries();
    return LogicalFontFamily_SANS_SERIF_instance;
  }
  function LogicalFontFamily_MONOSPACED_getInstance() {
    LogicalFontFamily_initEntries();
    return LogicalFontFamily_MONOSPACED_instance;
  }
  function LogicalFontFamily_DIALOG_getInstance() {
    LogicalFontFamily_initEntries();
    return LogicalFontFamily_DIALOG_instance;
  }
  function Graphics2D() {
  }
  function Icon() {
  }
  function KnobIcon(dim) {
    this.e2n_1 = dim;
  }
  protoOf(KnobIcon).y2e = function () {
    return this.e2n_1;
  };
  protoOf(KnobIcon).a2f = function (context, location, color) {
    context.t1y_1.l1t(color.h1x_1);
    // Inline function 'io.antarescircuit.jabbah.draw.DrawContext.translated' call
    context.t1y_1.v1c(location.in_1, location.jn_1);
    context.t1y_1.m1u(0.0, 0.0, this.e2n_1.e1e_1, this.e2n_1.f1e_1);
    context.t1y_1.p1u(this.e2n_1.e1e_1 / 2 - 3, this.e2n_1.f1e_1 / 2 - 3, 6.0, 6.0);
    context.t1y_1.d1u(this.e2n_1.e1e_1 / 2, this.e2n_1.f1e_1 / 2, this.e2n_1.e1e_1 / 2 + 4, this.e2n_1.f1e_1 / 2 - 4);
    context.t1y_1.v1c(-location.in_1, -location.jn_1);
  };
  function RemoveIcon(dim) {
    this.f2n_1 = dim;
  }
  protoOf(RemoveIcon).y2e = function () {
    return this.f2n_1;
  };
  protoOf(RemoveIcon).a2f = function (context, location, color) {
    context.t1y_1.l1t(color.h1x_1);
    context.t1y_1.m1u(location.in_1, location.jn_1, this.f2n_1.e1e_1, this.f2n_1.f1e_1);
    context.t1y_1.d1u(location.in_1 + this.f2n_1.e1e_1 / 3, location.jn_1 + this.f2n_1.f1e_1 / 2, location.in_1 + 2 * this.f2n_1.e1e_1 / 3, location.jn_1 + this.f2n_1.f1e_1 / 2);
  };
  function AddIcon(dim) {
    this.g2n_1 = dim;
  }
  protoOf(AddIcon).y2e = function () {
    return this.g2n_1;
  };
  protoOf(AddIcon).a2f = function (context, location, color) {
    context.t1y_1.l1t(color.h1x_1);
    context.t1y_1.m1u(location.in_1, location.jn_1, this.g2n_1.e1e_1, this.g2n_1.f1e_1);
    context.t1y_1.d1u(location.in_1 + this.g2n_1.e1e_1 / 3, location.jn_1 + this.g2n_1.f1e_1 / 2, location.in_1 + 2 * this.g2n_1.e1e_1 / 3, location.jn_1 + this.g2n_1.f1e_1 / 2);
    context.t1y_1.d1u(location.in_1 + this.g2n_1.e1e_1 / 2, location.jn_1 + this.g2n_1.f1e_1 / 3, location.in_1 + this.g2n_1.e1e_1 / 2, location.jn_1 + 2 * this.g2n_1.f1e_1 / 3);
  };
  function DeleteIcon() {
    this.h2n_1 = Dimension2D_init_$Create$(20, 20);
  }
  protoOf(DeleteIcon).y2e = function () {
    return this.h2n_1;
  };
  protoOf(DeleteIcon).a2f = function (context, location, color) {
    context.t1y_1.l1t(color.h1x_1);
    // Inline function 'io.antarescircuit.jabbah.draw.DrawContext.translated' call
    context.t1y_1.v1c(location.in_1, location.jn_1);
    context.t1y_1.m1u(0.0, 0.0, this.h2n_1.e1e_1, this.h2n_1.f1e_1);
    context.t1y_1.c1u(4, 6, 16, 6);
    context.t1y_1.c1u(6, 6, 8, 14);
    context.t1y_1.c1u(8, 14, 12, 14);
    context.t1y_1.c1u(12, 14, 14, 6);
    context.t1y_1.i1u(9, 4, 2, 2);
    context.t1y_1.v1c(-location.in_1, -location.jn_1);
  };
  var ImageType_SVG_instance;
  var ImageType_JPG_instance;
  var ImageType_GIF_instance;
  var ImageType_PNG_instance;
  function Companion_22() {
  }
  protoOf(Companion_22).r1e = function (customName) {
    var tmp0 = get_entries_0();
    var tmp$ret$0;
    $l$block: {
      // Inline function 'kotlin.collections.firstOrNull' call
      var _iterator__ex2g4s = tmp0.i();
      while (_iterator__ex2g4s.j()) {
        var element = _iterator__ex2g4s.k();
        if (element.g1r_1 === customName) {
          tmp$ret$0 = element;
          break $l$block;
        }
      }
      tmp$ret$0 = null;
    }
    var tmp0_elvis_lhs = tmp$ret$0;
    var tmp;
    if (tmp0_elvis_lhs == null) {
      throw IllegalArgumentException_init_$Create$("Unknown ImageType '" + customName + "'");
    } else {
      tmp = tmp0_elvis_lhs;
    }
    return tmp;
  };
  protoOf(Companion_22).i2n = function (mimeType) {
    var tmp0 = get_entries_0();
    var tmp$ret$0;
    $l$block: {
      // Inline function 'kotlin.collections.firstOrNull' call
      var _iterator__ex2g4s = tmp0.i();
      while (_iterator__ex2g4s.j()) {
        var element = _iterator__ex2g4s.k();
        if (element.i1r_1 === mimeType) {
          tmp$ret$0 = element;
          break $l$block;
        }
      }
      tmp$ret$0 = null;
    }
    return tmp$ret$0;
  };
  var Companion_instance_26;
  function Companion_getInstance_24() {
    return Companion_instance_26;
  }
  function values_0() {
    return [ImageType_SVG_getInstance(), ImageType_JPG_getInstance(), ImageType_GIF_getInstance(), ImageType_PNG_getInstance()];
  }
  function get_entries_0() {
    if ($ENTRIES_0 == null)
      $ENTRIES_0 = enumEntries(values_0());
    return $ENTRIES_0;
  }
  var ImageType_entriesInitialized;
  function ImageType_initEntries() {
    if (ImageType_entriesInitialized)
      return Unit_instance;
    ImageType_entriesInitialized = true;
    ImageType_SVG_instance = new ImageType('SVG', 0, 'SVG', 'svg', 'image/svg+xml', false);
    ImageType_JPG_instance = new ImageType('JPG', 1, 'JPG', 'jpg', 'image/jpeg', true);
    ImageType_GIF_instance = new ImageType('GIF', 2, 'GIF', 'gif', 'image/gif', true);
    ImageType_PNG_instance = new ImageType('PNG', 3, 'PNG', 'png', 'image/png', true);
  }
  var $ENTRIES_0;
  function ImageType(name, ordinal, customName, fileExtension, mimeType, isRaster) {
    Enum.call(this, name, ordinal);
    this.g1r_1 = customName;
    this.h1r_1 = fileExtension;
    this.i1r_1 = mimeType;
    this.j1r_1 = isRaster;
  }
  protoOf(ImageType).toString = function () {
    return this.g1r_1;
  };
  function ImageType_SVG_getInstance() {
    ImageType_initEntries();
    return ImageType_SVG_instance;
  }
  function ImageType_JPG_getInstance() {
    ImageType_initEntries();
    return ImageType_JPG_instance;
  }
  function ImageType_GIF_getInstance() {
    ImageType_initEntries();
    return ImageType_GIF_instance;
  }
  function ImageType_PNG_getInstance() {
    ImageType_initEntries();
    return ImageType_PNG_instance;
  }
  function LinearColorGradient(p1, color1, p2, color2) {
    this.b1s_1 = p1;
    this.c1s_1 = color1;
    this.d1s_1 = p2;
    this.e1s_1 = color2;
  }
  protoOf(LinearColorGradient).toString = function () {
    return 'LinearColorGradient(p1=' + this.b1s_1.toString() + ', color1=' + this.c1s_1.toString() + ', p2=' + this.d1s_1.toString() + ', color2=' + this.e1s_1.toString() + ')';
  };
  protoOf(LinearColorGradient).hashCode = function () {
    var result = this.b1s_1.hashCode();
    result = imul(result, 31) + this.c1s_1.hashCode() | 0;
    result = imul(result, 31) + this.d1s_1.hashCode() | 0;
    result = imul(result, 31) + this.e1s_1.hashCode() | 0;
    return result;
  };
  protoOf(LinearColorGradient).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof LinearColorGradient))
      return false;
    if (!this.b1s_1.equals(other.b1s_1))
      return false;
    if (!this.c1s_1.equals(other.c1s_1))
      return false;
    if (!this.d1s_1.equals(other.d1s_1))
      return false;
    if (!this.e1s_1.equals(other.e1s_1))
      return false;
    return true;
  };
  function PredefinedColor(identity, color) {
    this.j2n_1 = identity;
    this.k2n_1 = color;
  }
  protoOf(PredefinedColor).m2 = function () {
    return this.j2n_1.n2n_1;
  };
  protoOf(PredefinedColor).kq = function () {
    return this.j2n_1.kq();
  };
  protoOf(PredefinedColor).toString = function () {
    return this.kq();
  };
  protoOf(PredefinedColor).hashCode = function () {
    var result = this.j2n_1.hashCode();
    result = imul(result, 31) + this.k2n_1.hashCode() | 0;
    return result;
  };
  protoOf(PredefinedColor).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof PredefinedColor))
      return false;
    if (!this.j2n_1.equals(other.j2n_1))
      return false;
    if (!this.k2n_1.equals(other.k2n_1))
      return false;
    return true;
  };
  var PredefinedColorIdentity_White_instance;
  var PredefinedColorIdentity_Black_instance;
  var PredefinedColorIdentity_Gray_instance;
  var PredefinedColorIdentity_Yellow_instance;
  var PredefinedColorIdentity_Brown_instance;
  var PredefinedColorIdentity_Red_instance;
  var PredefinedColorIdentity_Violet_instance;
  var PredefinedColorIdentity_Blue_instance;
  var PredefinedColorIdentity_Turquoise_instance;
  var PredefinedColorIdentity_Green_instance;
  function Companion_23() {
  }
  protoOf(Companion_23).p2n = function (idName) {
    // Inline function 'kotlin.collections.map' call
    var this_0 = values_1();
    // Inline function 'kotlin.collections.mapTo' call
    var destination = ArrayList_init_$Create$_0(this_0.length);
    var inductionVariable = 0;
    var last = this_0.length;
    while (inductionVariable < last) {
      var item = this_0[inductionVariable];
      inductionVariable = inductionVariable + 1 | 0;
      var tmp$ret$2 = item.n2n_1;
      destination.h(tmp$ret$2);
    }
    return destination.n(idName);
  };
  protoOf(Companion_23).q2n = function (idName) {
    var tmp0 = values_1();
    var tmp$ret$0;
    $l$block: {
      // Inline function 'kotlin.collections.first' call
      var inductionVariable = 0;
      var last = tmp0.length;
      while (inductionVariable < last) {
        var element = tmp0[inductionVariable];
        inductionVariable = inductionVariable + 1 | 0;
        if (element.n2n_1 === idName) {
          tmp$ret$0 = element;
          break $l$block;
        }
      }
      throw NoSuchElementException_init_$Create$('Array contains no element matching the predicate.');
    }
    return tmp$ret$0;
  };
  var Companion_instance_27;
  function Companion_getInstance_25() {
    return Companion_instance_27;
  }
  function values_1() {
    return [PredefinedColorIdentity_White_getInstance(), PredefinedColorIdentity_Black_getInstance(), PredefinedColorIdentity_Gray_getInstance(), PredefinedColorIdentity_Yellow_getInstance(), PredefinedColorIdentity_Brown_getInstance(), PredefinedColorIdentity_Red_getInstance(), PredefinedColorIdentity_Violet_getInstance(), PredefinedColorIdentity_Blue_getInstance(), PredefinedColorIdentity_Turquoise_getInstance(), PredefinedColorIdentity_Green_getInstance()];
  }
  var PredefinedColorIdentity_entriesInitialized;
  function PredefinedColorIdentity_initEntries() {
    if (PredefinedColorIdentity_entriesInitialized)
      return Unit_instance;
    PredefinedColorIdentity_entriesInitialized = true;
    PredefinedColorIdentity_White_instance = new PredefinedColorIdentity('White', 0, 'white', 'graphics.color.white.name');
    PredefinedColorIdentity_Black_instance = new PredefinedColorIdentity('Black', 1, 'black', 'graphics.color.black.name');
    PredefinedColorIdentity_Gray_instance = new PredefinedColorIdentity('Gray', 2, 'gray', 'graphics.color.gray.name');
    PredefinedColorIdentity_Yellow_instance = new PredefinedColorIdentity('Yellow', 3, 'yellow', 'graphics.color.yellow.name');
    PredefinedColorIdentity_Brown_instance = new PredefinedColorIdentity('Brown', 4, 'brown', 'graphics.color.brown.name');
    PredefinedColorIdentity_Red_instance = new PredefinedColorIdentity('Red', 5, 'red', 'graphics.color.red.name');
    PredefinedColorIdentity_Violet_instance = new PredefinedColorIdentity('Violet', 6, 'violet', 'graphics.color.violet.name');
    PredefinedColorIdentity_Blue_instance = new PredefinedColorIdentity('Blue', 7, 'blue', 'graphics.color.blue.name');
    PredefinedColorIdentity_Turquoise_instance = new PredefinedColorIdentity('Turquoise', 8, 'turquoise', 'graphics.color.turquoise.name');
    PredefinedColorIdentity_Green_instance = new PredefinedColorIdentity('Green', 9, 'green', 'graphics.color.green.name');
  }
  function PredefinedColorIdentity(name, ordinal, idName, descriptionKey) {
    Enum.call(this, name, ordinal);
    this.n2n_1 = idName;
    this.o2n_1 = descriptionKey;
  }
  protoOf(PredefinedColorIdentity).kq = function () {
    return Translations_getInstance().zm(this.o2n_1, []);
  };
  function _get_colorsList__ezi03($this) {
    var tmp0 = $this.j2m_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('colorsList', 1, tmp, PredefinedColorRepository$_get_colorsList_$ref_tq9z3r(), null);
    return tmp0.j2();
  }
  function _get_colors__hj58bp_0($this) {
    var tmp0 = $this.k2m_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('colors', 1, tmp, PredefinedColorRepository$_get_colors_$ref_agwlj(), null);
    return tmp0.j2();
  }
  function containsName($this, name) {
    return !($this.q2n(name) == null);
  }
  function PredefinedColorRepository$colorsList$delegate$lambda() {
    // Inline function 'kotlin.collections.mutableListOf' call
    return ArrayList_init_$Create$();
  }
  function PredefinedColorRepository$_get_colorsList_$ref_tq9z3r() {
    return function (p0) {
      return _get_colorsList__ezi03(p0);
    };
  }
  function PredefinedColorRepository$colors$delegate$lambda() {
    // Inline function 'kotlin.collections.mutableMapOf' call
    return LinkedHashMap_init_$Create$();
  }
  function PredefinedColorRepository$_get_colors_$ref_agwlj() {
    return function (p0) {
      return _get_colors__hj58bp_0(p0);
    };
  }
  function PredefinedColorRepository() {
    PredefinedColorRepository_instance = this;
    this.i2m_1 = logger(getKClass(PredefinedColorRepository));
    var tmp = this;
    tmp.j2m_1 = lazy(PredefinedColorRepository$colorsList$delegate$lambda);
    var tmp_0 = this;
    tmp_0.k2m_1 = lazy(PredefinedColorRepository$colors$delegate$lambda);
  }
  protoOf(PredefinedColorRepository).q2n = function (idName) {
    var tmp;
    if (Companion_instance_27.p2n(idName)) {
      tmp = _get_colors__hj58bp_0(this).g2(Companion_instance_27.q2n(idName));
    } else {
      tmp = null;
    }
    return tmp;
  };
  protoOf(PredefinedColorRepository).r2n = function (identity) {
    return _get_colors__hj58bp_0(this).g2(identity);
  };
  protoOf(PredefinedColorRepository).l2m = function (color) {
    if (containsName(this, color.m2())) {
      _get_colorsList__ezi03(this).u2(indexOf(_get_colorsList__ezi03(this), this.q2n(color.m2())), color);
    } else {
      _get_colorsList__ezi03(this).h(color);
    }
    var tmp0 = _get_colors__hj58bp_0(this);
    // Inline function 'kotlin.collections.set' call
    var key = color.j2n_1;
    tmp0.y1(key, color);
  };
  var PredefinedColorRepository_instance;
  function PredefinedColorRepository_getInstance() {
    if (PredefinedColorRepository_instance == null)
      new PredefinedColorRepository();
    return PredefinedColorRepository_instance;
  }
  function PredefinedColorIdentity_White_getInstance() {
    PredefinedColorIdentity_initEntries();
    return PredefinedColorIdentity_White_instance;
  }
  function PredefinedColorIdentity_Black_getInstance() {
    PredefinedColorIdentity_initEntries();
    return PredefinedColorIdentity_Black_instance;
  }
  function PredefinedColorIdentity_Gray_getInstance() {
    PredefinedColorIdentity_initEntries();
    return PredefinedColorIdentity_Gray_instance;
  }
  function PredefinedColorIdentity_Yellow_getInstance() {
    PredefinedColorIdentity_initEntries();
    return PredefinedColorIdentity_Yellow_instance;
  }
  function PredefinedColorIdentity_Brown_getInstance() {
    PredefinedColorIdentity_initEntries();
    return PredefinedColorIdentity_Brown_instance;
  }
  function PredefinedColorIdentity_Red_getInstance() {
    PredefinedColorIdentity_initEntries();
    return PredefinedColorIdentity_Red_instance;
  }
  function PredefinedColorIdentity_Violet_getInstance() {
    PredefinedColorIdentity_initEntries();
    return PredefinedColorIdentity_Violet_instance;
  }
  function PredefinedColorIdentity_Blue_getInstance() {
    PredefinedColorIdentity_initEntries();
    return PredefinedColorIdentity_Blue_instance;
  }
  function PredefinedColorIdentity_Turquoise_getInstance() {
    PredefinedColorIdentity_initEntries();
    return PredefinedColorIdentity_Turquoise_instance;
  }
  function PredefinedColorIdentity_Green_getInstance() {
    PredefinedColorIdentity_initEntries();
    return PredefinedColorIdentity_Green_instance;
  }
  function PredefinedStroke(identity, stroke) {
    this.s2n_1 = identity;
    this.t2n_1 = stroke;
  }
  protoOf(PredefinedStroke).toString = function () {
    return 'PredefinedStroke(identity=' + this.s2n_1.toString() + ', stroke=' + this.t2n_1.toString() + ')';
  };
  protoOf(PredefinedStroke).hashCode = function () {
    var result = this.s2n_1.hashCode();
    result = imul(result, 31) + this.t2n_1.hashCode() | 0;
    return result;
  };
  protoOf(PredefinedStroke).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof PredefinedStroke))
      return false;
    if (!this.s2n_1.equals(other.s2n_1))
      return false;
    if (!this.t2n_1.equals(other.t2n_1))
      return false;
    return true;
  };
  function _get_LOG__e5r759_5($this) {
    var tmp0 = $this.m2m_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('LOG', 1, tmp, PredefinedStrokeRepository$_get_LOG_$ref_gt74io(), null);
    return tmp0.j2();
  }
  function _get_strokesList__w6e8fs($this) {
    var tmp0 = $this.n2m_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('strokesList', 1, tmp, PredefinedStrokeRepository$_get_strokesList_$ref_a57giz(), null);
    return tmp0.j2();
  }
  function _get_strokes__63e5l6($this) {
    var tmp0 = $this.o2m_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('strokes', 1, tmp, PredefinedStrokeRepository$_get_strokes_$ref_fz9yzt(), null);
    return tmp0.j2();
  }
  function containsId($this, id) {
    return !($this.u2n(id) == null);
  }
  function PredefinedStrokeRepository$_get_LOG_$ref_gt74io() {
    return function (p0) {
      return _get_LOG__e5r759_5(p0);
    };
  }
  function PredefinedStrokeRepository$strokesList$delegate$lambda() {
    // Inline function 'kotlin.collections.mutableListOf' call
    return ArrayList_init_$Create$();
  }
  function PredefinedStrokeRepository$_get_strokesList_$ref_a57giz() {
    return function (p0) {
      return _get_strokesList__w6e8fs(p0);
    };
  }
  function PredefinedStrokeRepository$strokes$delegate$lambda() {
    // Inline function 'kotlin.collections.mutableMapOf' call
    return LinkedHashMap_init_$Create$();
  }
  function PredefinedStrokeRepository$_get_strokes_$ref_fz9yzt() {
    return function (p0) {
      return _get_strokes__63e5l6(p0);
    };
  }
  function PredefinedStrokeRepository() {
    PredefinedStrokeRepository_instance = this;
    this.m2m_1 = logger(getKClass(PredefinedColorRepository));
    var tmp = this;
    tmp.n2m_1 = lazy(PredefinedStrokeRepository$strokesList$delegate$lambda);
    var tmp_0 = this;
    tmp_0.o2m_1 = lazy(PredefinedStrokeRepository$strokes$delegate$lambda);
  }
  protoOf(PredefinedStrokeRepository).u2n = function (id) {
    return _get_strokes__63e5l6(this).g2(Companion_instance_28.u2n(id));
  };
  protoOf(PredefinedStrokeRepository).v2n = function (identity) {
    return _get_strokes__63e5l6(this).g2(identity);
  };
  protoOf(PredefinedStrokeRepository).p2m = function (stroke) {
    if (containsId(this, stroke.s2n_1.y2n_1)) {
      _get_LOG__e5r759_5(this).ll('PredefinedStroke with id ' + stroke.s2n_1.y2n_1 + ' already registered, replacing');
      _get_strokesList__w6e8fs(this).u2(indexOf(_get_strokesList__w6e8fs(this), this.u2n(stroke.s2n_1.y2n_1)), stroke);
    } else {
      _get_strokesList__w6e8fs(this).h(stroke);
    }
    var tmp0 = _get_strokes__63e5l6(this);
    // Inline function 'kotlin.collections.set' call
    var key = stroke.s2n_1;
    tmp0.y1(key, stroke);
  };
  var PredefinedStrokeRepository_instance;
  function PredefinedStrokeRepository_getInstance() {
    if (PredefinedStrokeRepository_instance == null)
      new PredefinedStrokeRepository();
    return PredefinedStrokeRepository_instance;
  }
  var PredefinedStrokeIdentity_ThinDotted_instance;
  var PredefinedStrokeIdentity_ThinSolid_instance;
  var PredefinedStrokeIdentity_ThinDashed_instance;
  var PredefinedStrokeIdentity_NormalDotted_instance;
  var PredefinedStrokeIdentity_NormalSolid_instance;
  var PredefinedStrokeIdentity_NormalDashed_instance;
  var PredefinedStrokeIdentity_ThickDotted_instance;
  var PredefinedStrokeIdentity_ThickSolid_instance;
  var PredefinedStrokeIdentity_ThickDashed_instance;
  function Companion_24() {
  }
  protoOf(Companion_24).u2n = function (id) {
    var tmp0 = values_2();
    var tmp$ret$0;
    $l$block: {
      // Inline function 'kotlin.collections.first' call
      var inductionVariable = 0;
      var last = tmp0.length;
      while (inductionVariable < last) {
        var element = tmp0[inductionVariable];
        inductionVariable = inductionVariable + 1 | 0;
        if (element.y2n_1 === id) {
          tmp$ret$0 = element;
          break $l$block;
        }
      }
      throw NoSuchElementException_init_$Create$('Array contains no element matching the predicate.');
    }
    return tmp$ret$0;
  };
  var Companion_instance_28;
  function Companion_getInstance_26() {
    return Companion_instance_28;
  }
  function values_2() {
    return [PredefinedStrokeIdentity_ThinDotted_getInstance(), PredefinedStrokeIdentity_ThinSolid_getInstance(), PredefinedStrokeIdentity_ThinDashed_getInstance(), PredefinedStrokeIdentity_NormalDotted_getInstance(), PredefinedStrokeIdentity_NormalSolid_getInstance(), PredefinedStrokeIdentity_NormalDashed_getInstance(), PredefinedStrokeIdentity_ThickDotted_getInstance(), PredefinedStrokeIdentity_ThickSolid_getInstance(), PredefinedStrokeIdentity_ThickDashed_getInstance()];
  }
  var PredefinedStrokeIdentity_entriesInitialized;
  function PredefinedStrokeIdentity_initEntries() {
    if (PredefinedStrokeIdentity_entriesInitialized)
      return Unit_instance;
    PredefinedStrokeIdentity_entriesInitialized = true;
    PredefinedStrokeIdentity_ThinDotted_instance = new PredefinedStrokeIdentity('ThinDotted', 0, 'thin-dotted');
    PredefinedStrokeIdentity_ThinSolid_instance = new PredefinedStrokeIdentity('ThinSolid', 1, 'thin-solid');
    PredefinedStrokeIdentity_ThinDashed_instance = new PredefinedStrokeIdentity('ThinDashed', 2, 'thin-dashed');
    PredefinedStrokeIdentity_NormalDotted_instance = new PredefinedStrokeIdentity('NormalDotted', 3, 'normal-dotted');
    PredefinedStrokeIdentity_NormalSolid_instance = new PredefinedStrokeIdentity('NormalSolid', 4, 'normal-solid');
    PredefinedStrokeIdentity_NormalDashed_instance = new PredefinedStrokeIdentity('NormalDashed', 5, 'normal-dashed');
    PredefinedStrokeIdentity_ThickDotted_instance = new PredefinedStrokeIdentity('ThickDotted', 6, 'thick-dotted');
    PredefinedStrokeIdentity_ThickSolid_instance = new PredefinedStrokeIdentity('ThickSolid', 7, 'thick-solid');
    PredefinedStrokeIdentity_ThickDashed_instance = new PredefinedStrokeIdentity('ThickDashed', 8, 'thick-dashed');
  }
  function PredefinedStrokeIdentity(name, ordinal, id) {
    Enum.call(this, name, ordinal);
    this.y2n_1 = id;
  }
  function PredefinedStrokeIdentity_ThinDotted_getInstance() {
    PredefinedStrokeIdentity_initEntries();
    return PredefinedStrokeIdentity_ThinDotted_instance;
  }
  function PredefinedStrokeIdentity_ThinSolid_getInstance() {
    PredefinedStrokeIdentity_initEntries();
    return PredefinedStrokeIdentity_ThinSolid_instance;
  }
  function PredefinedStrokeIdentity_ThinDashed_getInstance() {
    PredefinedStrokeIdentity_initEntries();
    return PredefinedStrokeIdentity_ThinDashed_instance;
  }
  function PredefinedStrokeIdentity_NormalDotted_getInstance() {
    PredefinedStrokeIdentity_initEntries();
    return PredefinedStrokeIdentity_NormalDotted_instance;
  }
  function PredefinedStrokeIdentity_NormalSolid_getInstance() {
    PredefinedStrokeIdentity_initEntries();
    return PredefinedStrokeIdentity_NormalSolid_instance;
  }
  function PredefinedStrokeIdentity_NormalDashed_getInstance() {
    PredefinedStrokeIdentity_initEntries();
    return PredefinedStrokeIdentity_NormalDashed_instance;
  }
  function PredefinedStrokeIdentity_ThickDotted_getInstance() {
    PredefinedStrokeIdentity_initEntries();
    return PredefinedStrokeIdentity_ThickDotted_instance;
  }
  function PredefinedStrokeIdentity_ThickSolid_getInstance() {
    PredefinedStrokeIdentity_initEntries();
    return PredefinedStrokeIdentity_ThickSolid_instance;
  }
  function PredefinedStrokeIdentity_ThickDashed_getInstance() {
    PredefinedStrokeIdentity_initEntries();
    return PredefinedStrokeIdentity_ThickDashed_instance;
  }
  function RadialColorGradient(center, radius, centerColor, perimeterColor) {
    this.h1s_1 = center;
    this.i1s_1 = radius;
    this.j1s_1 = centerColor;
    this.k1s_1 = perimeterColor;
  }
  protoOf(RadialColorGradient).toString = function () {
    return 'RadialColorGradient(center=' + this.h1s_1.toString() + ', radius=' + this.i1s_1 + ', centerColor=' + this.j1s_1.toString() + ', perimeterColor=' + this.k1s_1.toString() + ')';
  };
  protoOf(RadialColorGradient).hashCode = function () {
    var result = this.h1s_1.hashCode();
    result = imul(result, 31) + this.i1s_1 | 0;
    result = imul(result, 31) + this.j1s_1.hashCode() | 0;
    result = imul(result, 31) + this.k1s_1.hashCode() | 0;
    return result;
  };
  protoOf(RadialColorGradient).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof RadialColorGradient))
      return false;
    if (!this.h1s_1.equals(other.h1s_1))
      return false;
    if (!(this.i1s_1 === other.i1s_1))
      return false;
    if (!this.j1s_1.equals(other.j1s_1))
      return false;
    if (!this.k1s_1.equals(other.k1s_1))
      return false;
    return true;
  };
  function RadialColorGradientCache(center, radius, backgroundColor) {
    this.z2n_1 = center;
    this.a2o_1 = radius;
    this.b2o_1 = backgroundColor;
    var tmp = this;
    // Inline function 'kotlin.collections.mutableMapOf' call
    tmp.c2o_1 = LinkedHashMap_init_$Create$();
    this.d2o_1 = this.b2o_1.b2f(0);
    var tmp_0 = this;
    // Inline function 'kotlin.also' call
    var this_0 = new Float32Array(3);
    this_0[0] = 0.0;
    this_0[1] = 0.6;
    this_0[2] = 1.0;
    tmp_0.e2o_1 = this_0;
  }
  protoOf(RadialColorGradientCache).f2o = function (gradient, factor) {
    var factorInt = numberToInt(factor * 100);
    var alpha1 = numberToInt(factor * 255);
    // Inline function 'kotlin.collections.getOrPut' call
    var this_0 = this.c2o_1;
    var value = this_0.g2(factorInt);
    var tmp;
    if (value == null) {
      var centerColor = gradient.p2k(1.0);
      var answer = new RadialColorGradient(this.z2n_1, this.a2o_1, centerColor.b2f(alpha1), this.d2o_1);
      this_0.y1(factorInt, answer);
      tmp = answer;
    } else {
      tmp = value;
    }
    return tmp;
  };
  function _get_LOG__e5r759_6($this) {
    var tmp0 = $this.g2o_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('LOG', 1, tmp, ReferenceColorSequenceProvider$_get_LOG_$ref_gvc732(), null);
    return tmp0.j2();
  }
  function ReferenceColorSequenceProvider$_get_LOG_$ref_gvc732() {
    return function (p0) {
      return _get_LOG__e5r759_6(p0);
    };
  }
  function ReferenceColorSequenceProvider() {
    ReferenceColorSequenceProvider_instance = this;
    this.g2o_1 = logger(getKClass(ReferenceColorSequenceProvider));
    var tmp = this;
    // Inline function 'kotlin.collections.mutableListOf' call
    tmp.h2o_1 = ArrayList_init_$Create$();
  }
  protoOf(ReferenceColorSequenceProvider).i2o = function () {
    return new FlexibleReferenceColorSequenceImpl();
  };
  protoOf(ReferenceColorSequenceProvider).j2o = function (colors) {
    if (this.k2o() > 0 && !(this.k2o() === colors.o())) {
      _get_LOG__e5r759_6(this).kl('inconsistent replacement color count old=' + this.k2o() + ', new=' + colors.o());
      throw IllegalArgumentException_init_$Create$('inconsistent color count');
    }
    // Inline function 'kotlin.collections.filter' call
    var tmp0 = get_indices(colors);
    // Inline function 'kotlin.collections.filterTo' call
    var destination = ArrayList_init_$Create$();
    var inductionVariable = tmp0.y_1;
    var last = tmp0.z_1;
    if (inductionVariable <= last)
      do {
        var element = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        if (element < ReferenceColorSequenceProvider_getInstance().k2o()) {
          destination.h(element);
        }
      }
       while (!(element === last));
    // Inline function 'kotlin.collections.map' call
    // Inline function 'kotlin.collections.mapTo' call
    var destination_0 = ArrayList_init_$Create$_0(collectionSizeOrDefault(destination, 10));
    var _iterator__ex2g4s = destination.i();
    while (_iterator__ex2g4s.j()) {
      var item = _iterator__ex2g4s.k();
      var tmp$ret$5 = new ReferenceColorReplacement(ReferenceColorSequenceProvider_getInstance().h2o_1.l(item), colors.l(item));
      destination_0.h(tmp$ret$5);
    }
    var replacements = destination_0;
    this.h2o_1.a2();
    this.h2o_1.f1(colors);
    BaseModule_getInstance().zo_1.eu(new ReferenceColorEvent(replacements));
  };
  protoOf(ReferenceColorSequenceProvider).k2o = function () {
    return this.h2o_1.o();
  };
  protoOf(ReferenceColorSequenceProvider).l2o = function (index) {
    return this.h2o_1.l(index);
  };
  protoOf(ReferenceColorSequenceProvider).m2o = function (color) {
    return this.h2o_1.p(color);
  };
  var ReferenceColorSequenceProvider_instance;
  function ReferenceColorSequenceProvider_getInstance() {
    if (ReferenceColorSequenceProvider_instance == null)
      new ReferenceColorSequenceProvider();
    return ReferenceColorSequenceProvider_instance;
  }
  function ReferenceColor(onBackground, onDark) {
    onDark = onDark === VOID ? onBackground : onDark;
    this.n2o_1 = onBackground;
    this.o2o_1 = onDark;
  }
  protoOf(ReferenceColor).toString = function () {
    return 'ReferenceColor(onBackground=' + this.n2o_1.toString() + ', onDark=' + this.o2o_1.toString() + ')';
  };
  protoOf(ReferenceColor).hashCode = function () {
    var result = this.n2o_1.hashCode();
    result = imul(result, 31) + this.o2o_1.hashCode() | 0;
    return result;
  };
  protoOf(ReferenceColor).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof ReferenceColor))
      return false;
    if (!this.n2o_1.equals(other.n2o_1))
      return false;
    if (!this.o2o_1.equals(other.o2o_1))
      return false;
    return true;
  };
  function Usage($outer, index, count) {
    this.r2o_1 = $outer;
    this.p2o_1 = index;
    this.q2o_1 = count;
  }
  protoOf(Usage).s2o = function (other) {
    if (!(this.q2o_1 === other.q2o_1)) {
      return compareTo(this.q2o_1, other.q2o_1);
    }
    return compareTo(this.p2o_1, other.p2o_1);
  };
  protoOf(Usage).d = function (other) {
    return this.s2o(other instanceof Usage ? other : THROW_CCE());
  };
  function FlexibleReferenceColorSequenceImpl() {
    var tmp = this;
    // Inline function 'kotlin.collections.map' call
    var this_0 = until(0, ReferenceColorSequenceProvider_getInstance().k2o());
    // Inline function 'kotlin.collections.mapTo' call
    var destination = ArrayList_init_$Create$_0(collectionSizeOrDefault(this_0, 10));
    var inductionVariable = this_0.y_1;
    var last = this_0.z_1;
    if (inductionVariable <= last)
      do {
        var item = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        var it = item;
        var tmp$ret$2 = new Usage(this, it, 0);
        destination.h(tmp$ret$2);
      }
       while (!(item === last));
    tmp.t2o_1 = destination;
  }
  protoOf(FlexibleReferenceColorSequenceImpl).k = function () {
    var usage = ensureNotNull(minOrNull(this.t2o_1));
    usage.q2o_1 = usage.q2o_1 + 1 | 0;
    return ReferenceColorSequenceProvider_getInstance().l2o(usage.p2o_1);
  };
  protoOf(FlexibleReferenceColorSequenceImpl).u2o = function (color) {
    var index = ReferenceColorSequenceProvider_getInstance().m2o(color);
    // Inline function 'kotlin.collections.find' call
    var tmp0 = this.t2o_1;
    var tmp$ret$1;
    $l$block: {
      // Inline function 'kotlin.collections.firstOrNull' call
      var _iterator__ex2g4s = tmp0.i();
      while (_iterator__ex2g4s.j()) {
        var element = _iterator__ex2g4s.k();
        if (element.p2o_1 === index && element.q2o_1 > 0) {
          tmp$ret$1 = element;
          break $l$block;
        }
      }
      tmp$ret$1 = null;
    }
    var tmp0_elvis_lhs = tmp$ret$1;
    var tmp;
    if (tmp0_elvis_lhs == null) {
      throw IllegalStateException_init_$Create$('nothing to free');
    } else {
      tmp = tmp0_elvis_lhs;
    }
    var usage = tmp;
    usage.q2o_1 = usage.q2o_1 - 1 | 0;
  };
  function ReferenceColorReplacement(oldColor, newColor) {
    this.v2o_1 = oldColor;
    this.w2o_1 = newColor;
  }
  protoOf(ReferenceColorReplacement).toString = function () {
    return 'ReferenceColorReplacement(oldColor=' + this.v2o_1.toString() + ', newColor=' + this.w2o_1.toString() + ')';
  };
  protoOf(ReferenceColorReplacement).hashCode = function () {
    var result = this.v2o_1.hashCode();
    result = imul(result, 31) + this.w2o_1.hashCode() | 0;
    return result;
  };
  protoOf(ReferenceColorReplacement).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof ReferenceColorReplacement))
      return false;
    if (!this.v2o_1.equals(other.v2o_1))
      return false;
    if (!this.w2o_1.equals(other.w2o_1))
      return false;
    return true;
  };
  function ReferenceColorEvent(replacements) {
    this.x2o_1 = replacements;
  }
  protoOf(ReferenceColorEvent).toString = function () {
    return 'ReferenceColorEvent(replacements=' + toString(this.x2o_1) + ')';
  };
  protoOf(ReferenceColorEvent).hashCode = function () {
    return hashCode(this.x2o_1);
  };
  protoOf(ReferenceColorEvent).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof ReferenceColorEvent))
      return false;
    if (!equals(this.x2o_1, other.x2o_1))
      return false;
    return true;
  };
  function Stroke(width, cap, join, miterLimit, dash, dashPhase) {
    width = width === VOID ? 1.0 : width;
    cap = cap === VOID ? LineCap_SQUARE_getInstance() : cap;
    join = join === VOID ? LineJoin_MITER_getInstance() : join;
    miterLimit = miterLimit === VOID ? 10.0 : miterLimit;
    dash = dash === VOID ? null : dash;
    dashPhase = dashPhase === VOID ? null : dashPhase;
    this.p1t_1 = width;
    this.q1t_1 = cap;
    this.r1t_1 = join;
    this.s1t_1 = miterLimit;
    this.t1t_1 = dash;
    this.u1t_1 = dashPhase;
    if (this.p1t_1 < 0.0) {
      throw IllegalArgumentException_init_$Create$('negative width');
    }
    if (this.r1t_1.equals(LineJoin_MITER_getInstance()) && this.s1t_1 < 1.0) {
      throw IllegalArgumentException_init_$Create$('miterlimit < 1');
    }
    if (!(this.t1t_1 == null)) {
      if (!(this.u1t_1 == null) && this.u1t_1 < 0.0) {
        throw IllegalArgumentException_init_$Create$('negative dash phase');
      }
      var allZero = false;
      var indexedObject = this.t1t_1;
      var inductionVariable = 0;
      var last = indexedObject.length;
      while (inductionVariable < last) {
        var value = indexedObject[inductionVariable];
        inductionVariable = inductionVariable + 1 | 0;
        if (value > 0.0) {
          allZero = false;
        } else if (value < 0.0) {
          throw IllegalArgumentException_init_$Create$('negative dash length');
        }
      }
      if (allZero) {
        throw IllegalArgumentException_init_$Create$('dash lengths all zero');
      }
    }
  }
  protoOf(Stroke).y2o = function () {
    return this.z2o(this.p1t_1 * 0.7);
  };
  protoOf(Stroke).equals = function (other) {
    if (this === other)
      return true;
    if (other == null || !getKClassFromExpression(this).equals(getKClassFromExpression(other)))
      return false;
    if (!(other instanceof Stroke))
      THROW_CCE();
    if (!(this.p1t_1 === other.p1t_1))
      return false;
    if (!this.q1t_1.equals(other.q1t_1))
      return false;
    if (!this.r1t_1.equals(other.r1t_1))
      return false;
    if (!(this.s1t_1 === other.s1t_1))
      return false;
    if (!(this.t1t_1 == null)) {
      if (other.t1t_1 == null)
        return false;
      if (!contentEquals(this.t1t_1, other.t1t_1))
        return false;
    } else if (!(other.t1t_1 == null))
      return false;
    if (!(this.u1t_1 == other.u1t_1))
      return false;
    return true;
  };
  protoOf(Stroke).hashCode = function () {
    var result = getNumberHashCode(this.p1t_1);
    result = imul(31, result) + this.q1t_1.hashCode() | 0;
    result = imul(31, result) + this.r1t_1.hashCode() | 0;
    result = imul(31, result) + getNumberHashCode(this.s1t_1) | 0;
    var tmp = imul(31, result);
    var tmp0_safe_receiver = this.t1t_1;
    var tmp1_elvis_lhs = tmp0_safe_receiver == null ? null : contentHashCode(tmp0_safe_receiver);
    result = tmp + (tmp1_elvis_lhs == null ? 0 : tmp1_elvis_lhs) | 0;
    var tmp_0 = imul(31, result);
    var tmp2_safe_receiver = this.u1t_1;
    var tmp3_elvis_lhs = tmp2_safe_receiver == null ? null : getNumberHashCode(tmp2_safe_receiver);
    result = tmp_0 + (tmp3_elvis_lhs == null ? 0 : tmp3_elvis_lhs) | 0;
    return result;
  };
  protoOf(Stroke).a2p = function (width, cap, join, miterLimit, dash, dashPhase) {
    return new Stroke(width, cap, join, miterLimit, dash, dashPhase);
  };
  protoOf(Stroke).z2o = function (width, cap, join, miterLimit, dash, dashPhase, $super) {
    width = width === VOID ? this.p1t_1 : width;
    cap = cap === VOID ? this.q1t_1 : cap;
    join = join === VOID ? this.r1t_1 : join;
    miterLimit = miterLimit === VOID ? this.s1t_1 : miterLimit;
    dash = dash === VOID ? this.t1t_1 : dash;
    dashPhase = dashPhase === VOID ? this.u1t_1 : dashPhase;
    return $super === VOID ? this.a2p(width, cap, join, miterLimit, dash, dashPhase) : $super.a2p.call(this, width, cap, join, miterLimit, dash, dashPhase);
  };
  protoOf(Stroke).toString = function () {
    return 'Stroke(width=' + this.p1t_1 + ', cap=' + this.q1t_1.toString() + ', join=' + this.r1t_1.toString() + ', miterLimit=' + this.s1t_1 + ', dash=' + toString(this.t1t_1) + ', dashPhase=' + this.u1t_1 + ')';
  };
  var LineCap_BUTT_instance;
  var LineCap_ROUND_instance;
  var LineCap_SQUARE_instance;
  var LineCap_entriesInitialized;
  function LineCap_initEntries() {
    if (LineCap_entriesInitialized)
      return Unit_instance;
    LineCap_entriesInitialized = true;
    LineCap_BUTT_instance = new LineCap('BUTT', 0);
    LineCap_ROUND_instance = new LineCap('ROUND', 1);
    LineCap_SQUARE_instance = new LineCap('SQUARE', 2);
  }
  function LineCap(name, ordinal) {
    Enum.call(this, name, ordinal);
  }
  var LineJoin_MITER_instance;
  var LineJoin_ROUND_instance;
  var LineJoin_BEVEL_instance;
  var LineJoin_entriesInitialized;
  function LineJoin_initEntries() {
    if (LineJoin_entriesInitialized)
      return Unit_instance;
    LineJoin_entriesInitialized = true;
    LineJoin_MITER_instance = new LineJoin('MITER', 0);
    LineJoin_ROUND_instance = new LineJoin('ROUND', 1);
    LineJoin_BEVEL_instance = new LineJoin('BEVEL', 2);
  }
  function LineJoin(name, ordinal) {
    Enum.call(this, name, ordinal);
  }
  function LineCap_BUTT_getInstance() {
    LineCap_initEntries();
    return LineCap_BUTT_instance;
  }
  function LineCap_ROUND_getInstance() {
    LineCap_initEntries();
    return LineCap_ROUND_instance;
  }
  function LineCap_SQUARE_getInstance() {
    LineCap_initEntries();
    return LineCap_SQUARE_instance;
  }
  function LineJoin_MITER_getInstance() {
    LineJoin_initEntries();
    return LineJoin_MITER_instance;
  }
  function LineJoin_ROUND_getInstance() {
    LineJoin_initEntries();
    return LineJoin_ROUND_instance;
  }
  function LineJoin_BEVEL_getInstance() {
    LineJoin_initEntries();
    return LineJoin_BEVEL_instance;
  }
  function TextRenderInfoFactory() {
  }
  protoOf(TextRenderInfoFactory).q2i = function (text, font) {
    return TextRenderInfoFactoryImpl_getInstance().p1v(text, font);
  };
  var TextRenderInfoFactory_instance;
  function TextRenderInfoFactory_getInstance() {
    return TextRenderInfoFactory_instance;
  }
  function TextRenderInfo(textBounds, ascent) {
    this.r2i_1 = textBounds;
    this.s2i_1 = ascent;
  }
  protoOf(TextRenderInfo).toString = function () {
    return 'TextRenderInfo(textBounds=' + this.r2i_1.toString() + ', ascent=' + this.s2i_1 + ')';
  };
  protoOf(TextRenderInfo).hashCode = function () {
    var result = this.r2i_1.hashCode();
    result = imul(result, 31) + getNumberHashCode(this.s2i_1) | 0;
    return result;
  };
  protoOf(TextRenderInfo).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof TextRenderInfo))
      return false;
    if (!this.r2i_1.equals(other.r2i_1))
      return false;
    if (!equals(this.s2i_1, other.s2i_1))
      return false;
    return true;
  };
  function fillProperties_1($this, properties) {
    properties.ct('view.command.zoom.step', 1.5);
    properties.ct('draw.panMethod', PanMethod_MiddleMouseButton_getInstance().e2p());
  }
  function DrawModule$rasterImageFactory$lambda(_unused_var__etf5q3, _unused_var__etf5q3_0) {
    throw UnsupportedOperationException_init_$Create$_0();
  }
  function DrawModule$imageLoader$1() {
  }
  protoOf(DrawModule$imageLoader$1).f2p = function (path, type) {
    throw UnsupportedOperationException_init_$Create$_0();
  };
  function DrawModule$drawContextFactory$lambda(g, mc, appContext) {
    return new DrawContext(g, mc, appContext);
  }
  function DrawModule() {
    DrawModule_instance = this;
    AbstractModule.call(this);
    this.q29_1 = false;
    this.r29_1 = Companion_getInstance_20().p1s_1;
    this.s29_1 = Companion_getInstance_20().v1s_1;
    this.t29_1 = Companion_getInstance_20().u1s_1;
    this.u29_1 = new Stroke(0.5);
    this.v29_1 = new DrawProperties(BaseModule_getInstance().xo_1);
    var tmp = this;
    tmp.w29_1 = DrawModule$rasterImageFactory$lambda;
    var tmp_0 = this;
    tmp_0.x29_1 = new DrawModule$imageLoader$1();
    var tmp_1 = this;
    tmp_1.y29_1 = DrawModule$drawContextFactory$lambda;
    this.z29_1 = Companion_instance.e18_1;
  }
  protoOf(DrawModule).ro = function () {
    BaseModule_getInstance().to();
    Translations_getInstance().um('jabbah-draw');
    DrawGraphicsModule_getInstance().to();
    DrawStyleModule_getInstance().to();
    DrawViewModule_getInstance().to();
    AnimationModule_getInstance().to();
    fillProperties_1(this, this.v29_1);
  };
  protoOf(DrawModule).g2p = function (drawable, g, color) {
    if (this.q29_1) {
      g.l1t(color);
      g.o1t(this.u29_1);
      g.t1u(drawable.do());
    }
  };
  protoOf(DrawModule).a2a = function (drawable, g, color, $super) {
    color = color === VOID ? this.r29_1 : color;
    var tmp;
    if ($super === VOID) {
      this.g2p(drawable, g, color);
      tmp = Unit_instance;
    } else {
      tmp = $super.g2p.call(this, drawable, g, color);
    }
    return tmp;
  };
  protoOf(DrawModule).h2p = function (locatable, context, color) {
    if (this.q29_1) {
      this.g2p(locatable, context.t1y_1, color);
      this.i2p(locatable.hw(), context, color);
    }
  };
  protoOf(DrawModule).j2p = function (locatable, context, color, $super) {
    color = color === VOID ? this.r29_1 : color;
    var tmp;
    if ($super === VOID) {
      this.h2p(locatable, context, color);
      tmp = Unit_instance;
    } else {
      tmp = $super.h2p.call(this, locatable, context, color);
    }
    return tmp;
  };
  protoOf(DrawModule).i2p = function (location, context, color) {
    if (this.q29_1) {
      context.t1y_1.l1t(color);
      context.t1y_1.q1u(numberToInt(location.in_1 - 2), numberToInt(location.jn_1 - 2), 4, 4);
    }
  };
  protoOf(DrawModule).b2a = function (location, context, color, $super) {
    color = color === VOID ? this.r29_1 : color;
    var tmp;
    if ($super === VOID) {
      this.i2p(location, context, color);
      tmp = Unit_instance;
    } else {
      tmp = $super.i2p.call(this, location, context, color);
    }
    return tmp;
  };
  var DrawModule_instance;
  function DrawModule_getInstance() {
    if (DrawModule_instance == null)
      new DrawModule();
    return DrawModule_instance;
  }
  function Companion_25() {
    Companion_instance_29 = this;
    this.k2p_1 = 4;
    this.l2p_1 = 10;
    this.m2p_1 = 1.0;
    this.n2p_1 = true;
    this.o2p_1 = false;
    this.p2p_1 = 4;
    this.q2p_1 = System_getInstance().zl();
    this.r2p_1 = new Stroke(1.0);
  }
  protoOf(Companion_25).s2p = function () {
    return new ArrowHead();
  };
  protoOf(Companion_25).t2p = function () {
    return new ArrowHead(VOID, VOID, VOID, VOID, true);
  };
  var Companion_instance_29;
  function Companion_getInstance_27() {
    if (Companion_instance_29 == null)
      new Companion_25();
    return Companion_instance_29;
  }
  function setLocationImpl($this, x, y) {
    Companion_getInstance_27().q2p_1.c1d(x - $this.z2p_1.in_1, y - $this.z2p_1.jn_1);
    $this.z2p_1 = new Point2D(x, y);
    $this.c2q_1.kn(Companion_getInstance_27().q2p_1);
    $this.b2q_1 = Companion_getInstance_27().q2p_1.ln($this.b2q_1);
  }
  function createUnidirectionalShape($this, width, length, compactness) {
    var path = System_getInstance().am();
    path.un(0, 0);
    path.xn(-length | 0, -width | 0);
    var tmp = $this;
    var tmp_0;
    if (compactness === 1.0) {
      path.xn(-length | 0, width);
      tmp_0 = Point2D_init_$Create$(-length | 0, 0);
    } else {
      var innerLength = length * compactness;
      path.yn(-innerLength, 0.0);
      path.xn(-length | 0, width);
      tmp_0 = new Point2D(-innerLength, 0.0);
    }
    tmp.b2q_1 = tmp_0;
    path.bo();
    return path;
  }
  function createBidirectionalShape($this, width, length, compactness) {
    var path = System_getInstance().am();
    var innerLength = length * compactness;
    path.un(0, 0);
    path.xn(-length | 0, -width | 0);
    if (compactness === 1.0) {
      path.xn(-length | 0, 0);
      path.xn((-length | 0) - 4 | 0, 0);
    } else {
      path.yn(-innerLength, 0.0);
      path.yn(((-length | 0) - 4 | 0) - (length - innerLength), 0.0);
    }
    path.xn((-length | 0) - 4 | 0, -width | 0);
    path.xn(((-length | 0) - 4 | 0) - length | 0, 0);
    path.xn((-length | 0) - 4 | 0, width);
    if (compactness === 1.0) {
      path.xn((-length | 0) - 4 | 0, 0);
      path.xn(-length | 0, 0);
    } else {
      path.yn(((-length | 0) - 4 | 0) - (length - innerLength), 0.0);
      path.yn(-innerLength, 0.0);
    }
    path.xn(-length | 0, width);
    $this.b2q_1 = Point2D_init_$Create$(imul(-2, length) - 4 | 0, 0);
    path.bo();
    return path;
  }
  function ArrowHead(width, length, compactness, filled, bidirectional) {
    Companion_getInstance_27();
    width = width === VOID ? 4 : width;
    length = length === VOID ? 10 : length;
    compactness = compactness === VOID ? 1.0 : compactness;
    filled = filled === VOID ? true : filled;
    bidirectional = bidirectional === VOID ? false : bidirectional;
    AbstractDrawable.call(this);
    this.x2p_1 = length;
    this.y2p_1 = filled;
    this.z2p_1 = Companion_getInstance().g1a_1;
    this.a2q_1 = 0.0;
    this.b2q_1 = Companion_getInstance().g1a_1;
    var tmp = this;
    var tmp_0;
    if (bidirectional) {
      tmp_0 = createBidirectionalShape(this, width, this.x2p_1, compactness);
    } else {
      tmp_0 = createUnidirectionalShape(this, width, this.x2p_1, compactness);
    }
    tmp.c2q_1 = tmp_0;
  }
  protoOf(ArrowHead).do = function () {
    return Rectangle2D_init_$Create$(this.c2q_1.do()).z1b(Companion_getInstance_27().r2p_1.p1t_1);
  };
  protoOf(ArrowHead).r1z = function (context) {
    var oldStroke = context.t1y_1.v1t();
    context.t1y_1.o1t(Companion_getInstance_27().r2p_1);
    context.t1y_1.t1u(this.c2q_1);
    if (this.y2p_1) {
      context.t1y_1.u1u(this.c2q_1);
    }
    context.t1y_1.o1t(oldStroke);
    DrawModule_getInstance().a2a(this, context.t1y_1);
  };
  protoOf(ArrowHead).eo = function (x, y) {
    return this.c2q_1.eo(x, y);
  };
  protoOf(ArrowHead).o = function () {
    return this.x2p_1;
  };
  protoOf(ArrowHead).d2q = function (location, orientation) {
    this.s1z();
    setLocationImpl(this, location.in_1, location.jn_1);
    Companion_getInstance_27().q2p_1.b1d();
    var rot = Geometry_instance.a1g(orientation, location);
    Companion_getInstance_27().q2p_1.d1d(this.a2q_1 - rot, location.in_1, location.jn_1);
    this.b2q_1 = Companion_getInstance_27().q2p_1.ln(this.b2q_1);
    this.c2q_1.kn(Companion_getInstance_27().q2p_1);
    this.a2q_1 = rot;
    this.s1z();
    this.v1z();
  };
  function Polyline() {
  }
  function Companion_26() {
    Companion_instance_30 = this;
    this.c2r_1 = new PolylineInterference(0, 0);
  }
  var Companion_instance_30;
  function Companion_getInstance_28() {
    if (Companion_instance_30 == null)
      new Companion_26();
    return Companion_instance_30;
  }
  function PolylineInterference(intersectionCount, overlappingCount) {
    Companion_getInstance_28();
    this.d2r_1 = intersectionCount;
    this.e2r_1 = overlappingCount;
  }
  protoOf(PolylineInterference).toString = function () {
    return 'PolylineInterference(intersectionCount=' + this.d2r_1 + ', overlappingCount=' + this.e2r_1 + ')';
  };
  protoOf(PolylineInterference).hashCode = function () {
    var result = this.d2r_1;
    result = imul(result, 31) + this.e2r_1 | 0;
    return result;
  };
  protoOf(PolylineInterference).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof PolylineInterference))
      return false;
    if (!(this.d2r_1 === other.d2r_1))
      return false;
    if (!(this.e2r_1 === other.e2r_1))
      return false;
    return true;
  };
  function drawImpl($this, context, lineColor, fillColor) {
    var oldColor = context.t1y_1.m1t();
    if ($this.s2c() && !(fillColor == null)) {
      var tmp = DropShadow_instance;
      var tmp_0 = $this.n2h();
      tmp.v2m(context, tmp_0, PolylineDrawable$drawImpl$lambda(context, $this));
    }
    if (!(fillColor == null)) {
      context.t1y_1.l1t(fillColor);
      context.t1y_1.u1u($this.j2r_1);
    }
    context.t1y_1.l1t(lineColor);
    context.t1y_1.o1t($this.v1t());
    context.t1y_1.t1u($this.j2r_1);
    var tmp0_safe_receiver = $this.j2r_1.f2q();
    if (tmp0_safe_receiver == null)
      null;
    else {
      tmp0_safe_receiver.r1z(context);
    }
    var tmp1_safe_receiver = $this.j2r_1.h2q();
    if (tmp1_safe_receiver == null)
      null;
    else {
      tmp1_safe_receiver.r1z(context);
    }
    context.t1y_1.l1t(oldColor);
  }
  function PolylineDrawable$drawImpl$lambda($context, this$0) {
    return function (it) {
      $context.t1y_1.u1u(this$0.j2r_1);
      return Unit_instance;
    };
  }
  function PolylineDrawable(shape, styleType, styleProvider) {
    shape = shape === VOID ? PolylineShapeFactory_instance.q1v(null) : shape;
    styleType = styleType === VOID ? Companion_getInstance_33().l1x_1 : styleType;
    styleProvider = styleProvider === VOID ? DrawStyleModule_getInstance().g1x_1 : styleProvider;
    AbstractStyledDrawable_init_$Init$(styleType, styleProvider, this);
    this.j2r_1 = shape;
    this.k2r_1 = new TransparentImpl(this);
  }
  protoOf(PolylineDrawable).toString = function () {
    return Translations_getInstance().zm('edit.component.polyline', []);
  };
  protoOf(PolylineDrawable).f20 = function (value) {
    this.s1z();
    this.j2r_1.p2q(value.in_1, value.jn_1);
    this.s1z();
    this.v1z();
  };
  protoOf(PolylineDrawable).hw = function () {
    return this.j2r_1.e2k(0);
  };
  protoOf(PolylineDrawable).f21 = function (dx, dy) {
    this.s1z();
    this.j2r_1.p2q(this.hw().in_1 + dx, this.hw().jn_1 + dy);
    this.s1z();
    this.v1z();
  };
  protoOf(PolylineDrawable).k2h = function (value) {
    this.k2r_1.k2h(value);
  };
  protoOf(PolylineDrawable).n2h = function () {
    return this.k2r_1.m2h_1;
  };
  protoOf(PolylineDrawable).do = function () {
    var bbox = Rectangle2D_init_$Create$(this.j2r_1.do());
    var lw = this.l2r();
    bbox.s1b(bbox.e1h_1 - lw, bbox.f1h_1 - lw, bbox.g1h_1 + 2 * lw, bbox.h1h_1 + 2 * lw);
    return bbox;
  };
  protoOf(PolylineDrawable).r1z = function (context) {
    if (context.w1y_1) {
      drawImpl(this, context, ensureNotNull(context.x1y_1).h1x_1, this.p2c() ? ensureNotNull(context.x1y_1).i1x_1 : null);
    } else {
      drawImpl(this, context, this.k2r_1.v2g(this.i2c()), this.p2c() ? this.k2r_1.v2g(this.j2c()) : null);
    }
  };
  protoOf(PolylineDrawable).eo = function (x, y) {
    return this.j2r_1.eo(x, y);
  };
  protoOf(PolylineDrawable).a = function () {
    return this.j2r_1.a();
  };
  protoOf(PolylineDrawable).d2k = function () {
    return this.j2r_1.d2k();
  };
  protoOf(PolylineDrawable).i2q = function () {
    return this.j2r_1.i2q();
  };
  protoOf(PolylineDrawable).e2q = function (value) {
    this.s1z();
    this.j2r_1.e2q(value);
    this.s1z();
    this.v1z();
  };
  protoOf(PolylineDrawable).f2q = function () {
    return this.j2r_1.f2q();
  };
  protoOf(PolylineDrawable).g2q = function (value) {
    this.s1z();
    this.j2r_1.g2q(value);
    this.s1z();
    this.v1z();
  };
  protoOf(PolylineDrawable).h2q = function () {
    return this.j2r_1.h2q();
  };
  protoOf(PolylineDrawable).a2 = function () {
    this.j2r_1.a2();
  };
  protoOf(PolylineDrawable).m2r = function (x, y) {
    return this.j2q(this.d2k(), x, y);
  };
  protoOf(PolylineDrawable).j2q = function (index, x, y) {
    this.s1z();
    this.j2r_1.j2q(index, x, y);
    this.s1z();
    this.v1z();
    return this;
  };
  protoOf(PolylineDrawable).k2q = function (index) {
    this.s1z();
    this.j2r_1.k2q(index);
    this.s1z();
    this.v1z();
    return this;
  };
  protoOf(PolylineDrawable).e2k = function (index) {
    return this.j2r_1.e2k(index);
  };
  protoOf(PolylineDrawable).n2q = function (index, x, y) {
    this.s1z();
    this.j2r_1.n2q(index, x, y);
    this.s1z();
    this.v1z();
    return this;
  };
  protoOf(PolylineDrawable).o2q = function (points) {
    this.s1z();
    this.j2r_1.o2q(points);
    this.s1z();
    this.v1z();
    return this;
  };
  protoOf(PolylineDrawable).p2q = function (x, y) {
    this.s1z();
    this.j2r_1.p2q(x, y);
    this.s1z();
    this.v1z();
    return this;
  };
  protoOf(PolylineDrawable).l2r = function () {
    return this.v1t().p1t_1;
  };
  protoOf(PolylineDrawable).q2q = function (x, y, area) {
    return this.j2r_1.q2q(x, y, area);
  };
  protoOf(PolylineDrawable).s2q = function (x, y, area) {
    return this.j2r_1.s2q(x, y, area);
  };
  protoOf(PolylineDrawable).t2q = function (index) {
    return this.j2r_1.t2q(index);
  };
  protoOf(PolylineDrawable).u2q = function () {
    this.s1z();
    if (this.j2r_1.u2q()) {
      this.s1z();
      this.v1z();
      return true;
    }
    return false;
  };
  protoOf(PolylineDrawable).v2q = function (index) {
    return this.j2r_1.v2q(index);
  };
  protoOf(PolylineDrawable).w2q = function (startIndex, endIndex) {
    return this.j2r_1.w2q(startIndex, endIndex);
  };
  protoOf(PolylineDrawable).x2q = function (index) {
    return this.j2r_1.x2q(index);
  };
  protoOf(PolylineDrawable).y2q = function (index) {
    return this.j2r_1.y2q(index);
  };
  protoOf(PolylineDrawable).z2q = function (index) {
    return this.j2r_1.z2q(index);
  };
  protoOf(PolylineDrawable).p2h = function (x) {
    this.j2r_1.p2h(x);
  };
  protoOf(PolylineDrawable).q2h = function (y) {
    this.j2r_1.q2h(y);
  };
  protoOf(PolylineDrawable).b2r = function (otherIndex, other) {
    return this.j2r_1.b2r(otherIndex, other);
  };
  protoOf(PolylineDrawable).a2r = function (index, otherIndex, other) {
    return this.j2r_1.a2r(index, otherIndex, other);
  };
  function calculateIntersectionCount($this, points, other) {
    // Inline function 'kotlin.collections.sumOf' call
    var sum = 0;
    var progression = until(0, points.o() - 1 | 0);
    var inductionVariable = progression.y_1;
    var last = progression.z_1;
    if (inductionVariable <= last)
      do {
        var element = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        var tmp = sum;
        var it = element;
        sum = tmp + calculateIntersectionCount_0(Companion_instance_31, it, points, other) | 0;
      }
       while (!(element === last));
    return sum;
  }
  function calculateIntersectionCount_0($this, index, points, other) {
    var tmp0 = until(0, other.o() - 1 | 0);
    var tmp$ret$0;
    $l$block: {
      // Inline function 'kotlin.collections.count' call
      var tmp;
      if (isInterface(tmp0, Collection)) {
        tmp = tmp0.m();
      } else {
        tmp = false;
      }
      if (tmp) {
        tmp$ret$0 = 0;
        break $l$block;
      }
      var count = 0;
      var inductionVariable = tmp0.y_1;
      var last = tmp0.z_1;
      if (inductionVariable <= last)
        do {
          var element = inductionVariable;
          inductionVariable = inductionVariable + 1 | 0;
          var it = element;
          if (doSegmentsIntersect(Companion_instance_31, index, points, it, other)) {
            count = count + 1 | 0;
            checkCountOverflow(count);
          }
        }
         while (!(element === last));
      tmp$ret$0 = count;
    }
    return tmp$ret$0;
  }
  function doSegmentsIntersect($this, index, points, otherIndex, other) {
    var tmp;
    if ($this.o2r(index, points) && $this.n2r(otherIndex, other)) {
      tmp = (Companion_getInstance().k1g(points.l(index), points.l(index + 1 | 0)).c1(other.l(otherIndex).in_1) && Companion_getInstance().l1g(other.l(otherIndex), other.l(otherIndex + 1 | 0)).c1(points.l(index).jn_1));
    } else if ($this.n2r(index, points) && $this.o2r(otherIndex, other)) {
      tmp = (Companion_getInstance().l1g(points.l(index), points.l(index + 1 | 0)).c1(other.l(otherIndex).jn_1) && Companion_getInstance().k1g(other.l(otherIndex), other.l(otherIndex + 1 | 0)).c1(points.l(index).in_1));
    } else {
      tmp = false;
    }
    return tmp;
  }
  function calculateOverlappingCount($this, points, other) {
    // Inline function 'kotlin.collections.sumOf' call
    var sum = 0;
    var progression = until(0, points.o() - 1 | 0);
    var inductionVariable = progression.y_1;
    var last = progression.z_1;
    if (inductionVariable <= last)
      do {
        var element = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        var tmp = sum;
        var it = element;
        sum = tmp + calculateOverlappingCount_0(Companion_instance_31, points, it, other) | 0;
      }
       while (!(element === last));
    return sum;
  }
  function calculateOverlappingCount_0($this, points, index, other) {
    var tmp0 = until(0, other.o() - 1 | 0);
    var tmp$ret$0;
    $l$block: {
      // Inline function 'kotlin.collections.count' call
      var tmp;
      if (isInterface(tmp0, Collection)) {
        tmp = tmp0.m();
      } else {
        tmp = false;
      }
      if (tmp) {
        tmp$ret$0 = 0;
        break $l$block;
      }
      var count = 0;
      var inductionVariable = tmp0.y_1;
      var last = tmp0.z_1;
      if (inductionVariable <= last)
        do {
          var element = inductionVariable;
          inductionVariable = inductionVariable + 1 | 0;
          var it = element;
          if (Companion_instance_31.p2r(index, points, other, it)) {
            count = count + 1 | 0;
            checkCountOverflow(count);
          }
        }
         while (!(element === last));
      tmp$ret$0 = count;
    }
    return tmp$ret$0;
  }
  function overlapHorizontally($this, index, points, other, otherIndex) {
    var tmp;
    // Inline function 'kotlin.math.abs' call
    var x = points.l(index).jn_1 - other.l(otherIndex).jn_1;
    if (Math.abs(x) <= 2) {
      tmp = points.l(index).in_1 >= other.l(otherIndex).in_1 && points.l(index).in_1 <= other.l(otherIndex + 1 | 0).in_1 || (points.l(index + 1 | 0).in_1 >= other.l(otherIndex).in_1 && points.l(index + 1 | 0).in_1 <= other.l(otherIndex + 1 | 0).in_1);
    } else {
      tmp = false;
    }
    return tmp;
  }
  function overlapVertically($this, points, index, other, otherIndex) {
    // Inline function 'kotlin.math.abs' call
    var x = points.l(index).in_1 - other.l(otherIndex).in_1;
    if (Math.abs(x) > 2) {
      return false;
    }
    var tmp0 = points.l(index).jn_1;
    // Inline function 'kotlin.math.min' call
    var b = points.l(index + 1 | 0).jn_1;
    var tmp = Math.min(tmp0, b);
    var tmp0_0 = points.l(index).jn_1;
    // Inline function 'kotlin.math.max' call
    var b_0 = points.l(index + 1 | 0).jn_1;
    var tmp$ret$2 = Math.max(tmp0_0, b_0);
    var range = rangeTo_0(tmp, tmp$ret$2);
    return range.c1(other.l(otherIndex).jn_1) || range.c1(other.l(otherIndex + 1 | 0).jn_1);
  }
  function Companion_27() {
  }
  protoOf(Companion_27).o2r = function (index, points) {
    return Geometry_instance.x1f(points.l(index).jn_1, points.l(index + 1 | 0).jn_1);
  };
  protoOf(Companion_27).n2r = function (index, points) {
    return Geometry_instance.x1f(points.l(index).in_1, points.l(index + 1 | 0).in_1);
  };
  protoOf(Companion_27).q2r = function (points, others) {
    // Inline function 'kotlin.collections.sumOf' call
    var sum = 0;
    var _iterator__ex2g4s = others.i();
    while (_iterator__ex2g4s.j()) {
      var element = _iterator__ex2g4s.k();
      var tmp = sum;
      sum = tmp + calculateIntersectionCount(Companion_instance_31, points, element) | 0;
    }
    var tmp_0 = sum;
    // Inline function 'kotlin.collections.sumOf' call
    var sum_0 = 0;
    var _iterator__ex2g4s_0 = others.i();
    while (_iterator__ex2g4s_0.j()) {
      var element_0 = _iterator__ex2g4s_0.k();
      var tmp_1 = sum_0;
      sum_0 = tmp_1 + calculateOverlappingCount(Companion_instance_31, points, element_0) | 0;
    }
    var tmp$ret$2 = sum_0;
    return new PolylineInterference(tmp_0, tmp$ret$2);
  };
  protoOf(Companion_27).p2r = function (index, points, other, otherIndex) {
    var tmp;
    if (this.o2r(index, points) && this.o2r(otherIndex, other)) {
      tmp = overlapHorizontally(this, index, points, other, otherIndex);
    } else if (this.n2r(index, points) && this.n2r(otherIndex, other)) {
      tmp = overlapVertically(this, points, index, other, otherIndex);
    } else {
      tmp = false;
    }
    return tmp;
  };
  var Companion_instance_31;
  function Companion_getInstance_29() {
    return Companion_instance_31;
  }
  function PolylineShape() {
  }
  function Companion_28() {
    this.r2r_1 = 2.0;
  }
  var Companion_instance_32;
  function Companion_getInstance_30() {
    return Companion_instance_32;
  }
  function _get_segmentIndices__vithg7($this) {
    return until(0, $this.d2k() - 1 | 0);
  }
  function updateBoundingBox($this) {
    var bbox = new Rectangle2D();
    if ($this.d2k() === 0) {
      $this.t2r_1 = bbox;
      return Unit_instance;
    }
    bbox.s1b($this.s2r_1.l(0).in_1, $this.s2r_1.l(0).jn_1, 0.0, 0.0);
    var inductionVariable = 1;
    var last = $this.d2k();
    if (inductionVariable < last)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        bbox.co($this.s2r_1.l(i));
      }
       while (inductionVariable < last);
    if (!($this.u2r_1 == null)) {
      bbox.x1b(ensureNotNull($this.u2r_1).do());
    }
    if (!($this.v2r_1 == null)) {
      bbox.x1b(ensureNotNull($this.v2r_1).do());
    }
    $this.t2r_1 = bbox;
  }
  function updateLineTerminatorLocations($this) {
    if (!($this.u2r_1 == null) && $this.d2k() >= 2) {
      ensureNotNull($this.u2r_1).d2q($this.s2r_1.l(0), $this.s2r_1.l(1));
    }
    if (!($this.v2r_1 == null) && $this.d2k() >= 2) {
      ensureNotNull($this.v2r_1).d2q(last($this.s2r_1), $this.s2r_1.l($this.d2k() - 2 | 0));
    }
  }
  function intersects_1($this, r) {
    var tmp0 = _get_segmentIndices__vithg7($this);
    var tmp$ret$0;
    $l$block_0: {
      // Inline function 'kotlin.collections.any' call
      var tmp;
      if (isInterface(tmp0, Collection)) {
        tmp = tmp0.m();
      } else {
        tmp = false;
      }
      if (tmp) {
        tmp$ret$0 = false;
        break $l$block_0;
      }
      var inductionVariable = tmp0.y_1;
      var last = tmp0.z_1;
      if (inductionVariable <= last)
        do {
          var element = inductionVariable;
          inductionVariable = inductionVariable + 1 | 0;
          var it = element;
          if (intersectsSegment($this, it, r)) {
            tmp$ret$0 = true;
            break $l$block_0;
          }
        }
         while (!(element === last));
      tmp$ret$0 = false;
    }
    return tmp$ret$0;
  }
  function intersectsSegment($this, index, r) {
    if ($this.d2k() < 2) {
      return false;
    }
    var start = $this.s2r_1.l(index);
    var end = $this.s2r_1.l(index + 1 | 0);
    return r.u1b(start.in_1, start.jn_1, end.in_1, end.jn_1);
  }
  function canCompactPoint($this, index) {
    if ($this.s2r_1.l(index).equals($this.s2r_1.l(index - 1 | 0))) {
      return true;
    }
    if (index > ($this.d2k() - 2 | 0)) {
      return false;
    }
    return isCoparallelX($this, index) || isCoparallelY($this, index);
  }
  function isCoparallelX($this, index) {
    return Geometry_instance.x1f($this.s2r_1.l(index).in_1, $this.s2r_1.l(index - 1 | 0).in_1) && Geometry_instance.x1f($this.s2r_1.l(index).in_1, $this.s2r_1.l(index + 1 | 0).in_1);
  }
  function isCoparallelY($this, index) {
    return Geometry_instance.x1f($this.s2r_1.l(index).jn_1, $this.s2r_1.l(index - 1 | 0).jn_1) && Geometry_instance.x1f($this.s2r_1.l(index).jn_1, $this.s2r_1.l(index + 1 | 0).jn_1);
  }
  function containsInArea($this, x, y) {
    if ($this.s2r_1.o() <= 2 || !$this.do().eo(x, y)) {
      return false;
    }
    var hits = 0;
    var lastX;
    var lastY;
    var curX = last($this.s2r_1).in_1;
    var curY = last($this.s2r_1).jn_1;
    var i = -1;
    $l$loop_5: while (i < ($this.s2r_1.o() - 1 | 0)) {
      i = i + 1 | 0;
      lastX = curX;
      lastY = curY;
      curX = $this.s2r_1.l(i).in_1;
      curY = $this.s2r_1.l(i).jn_1;
      if (curY === lastY) {
        continue $l$loop_5;
      }
      var tmp;
      if (curX < lastX) {
        if (x >= lastX) {
          continue $l$loop_5;
        }
        tmp = numberToInt(curX);
      } else {
        if (x >= curX) {
          continue $l$loop_5;
        }
        tmp = numberToInt(lastX);
      }
      var leftX = tmp;
      var test1;
      var test2;
      if (curY < lastY) {
        if (y < curY || y >= lastY) {
          continue $l$loop_5;
        }
        if (x < leftX) {
          hits = hits + 1 | 0;
          continue $l$loop_5;
        }
        test1 = x - curX;
        test2 = y - curY;
      } else {
        if (y < lastY || y >= curY) {
          continue $l$loop_5;
        }
        if (x < leftX) {
          hits = hits + 1 | 0;
          continue $l$loop_5;
        }
        test1 = x - lastX;
        test2 = y - lastY;
      }
      if (test1 < test2 / (lastY - curY) * (lastX - curX)) {
        hits = hits + 1 | 0;
      }
    }
    return !((hits & 1) === 0);
  }
  function PolylineShapeImpl(pts) {
    var tmp;
    if (pts === VOID) {
      // Inline function 'kotlin.collections.mutableListOf' call
      tmp = ArrayList_init_$Create$();
    } else {
      tmp = pts;
    }
    pts = tmp;
    var tmp_0 = this;
    // Inline function 'kotlin.collections.mutableListOf' call
    tmp_0.s2r_1 = ArrayList_init_$Create$();
    this.t2r_1 = new Rectangle2D();
    if (!(pts == null)) {
      this.s2r_1.f1(pts);
    }
    updateBoundingBox(this);
    this.u2r_1 = null;
    this.v2r_1 = null;
  }
  protoOf(PolylineShapeImpl).i2q = function () {
    return this.s2r_1;
  };
  protoOf(PolylineShapeImpl).do = function () {
    return this.t2r_1;
  };
  protoOf(PolylineShapeImpl).eo = function (x, y) {
    return containsInArea(this, x, y) || this.go(x - 2.0, y - 2.0, 2 * 2.0, 2 * 2.0);
  };
  protoOf(PolylineShapeImpl).fo = function (x, y, width, height) {
    return false;
  };
  protoOf(PolylineShapeImpl).go = function (x, y, w, h) {
    return intersects_1(this, new Rectangle2D(x, y, w, h));
  };
  protoOf(PolylineShapeImpl).a = function () {
    var l = 0.0;
    if (this.d2k() > 1) {
      var progression = _get_segmentIndices__vithg7(this);
      var inductionVariable = progression.y_1;
      var last = progression.z_1;
      if (inductionVariable <= last)
        do {
          var i = inductionVariable;
          inductionVariable = inductionVariable + 1 | 0;
          l = l + this.v2q(i);
        }
         while (!(i === last));
    }
    return l;
  };
  protoOf(PolylineShapeImpl).d2k = function () {
    return this.s2r_1.o();
  };
  protoOf(PolylineShapeImpl).e2q = function (value) {
    this.u2r_1 = value;
    updateLineTerminatorLocations(this);
    updateBoundingBox(this);
  };
  protoOf(PolylineShapeImpl).f2q = function () {
    return this.u2r_1;
  };
  protoOf(PolylineShapeImpl).g2q = function (value) {
    this.v2r_1 = value;
    updateLineTerminatorLocations(this);
    updateBoundingBox(this);
  };
  protoOf(PolylineShapeImpl).h2q = function () {
    return this.v2r_1;
  };
  protoOf(PolylineShapeImpl).a2 = function () {
    this.s2r_1.a2();
    updateBoundingBox(this);
  };
  protoOf(PolylineShapeImpl).j2q = function (index, x, y) {
    this.s2r_1.t3(index, new Point2D(x, y));
    updateLineTerminatorLocations(this);
    updateBoundingBox(this);
    return this;
  };
  protoOf(PolylineShapeImpl).k2q = function (index) {
    this.s2r_1.h3(index);
    updateLineTerminatorLocations(this);
    updateBoundingBox(this);
    return this;
  };
  protoOf(PolylineShapeImpl).e2k = function (index) {
    return this.s2r_1.l(index);
  };
  protoOf(PolylineShapeImpl).n2q = function (index, x, y) {
    this.s2r_1.u2(index, new Point2D(x, y));
    updateLineTerminatorLocations(this);
    updateBoundingBox(this);
    return this;
  };
  protoOf(PolylineShapeImpl).o2q = function (points) {
    this.s2r_1.a2();
    var _iterator__ex2g4s = points.i();
    while (_iterator__ex2g4s.j()) {
      var p = _iterator__ex2g4s.k();
      this.s2r_1.h(Point2D_init_$Create$_0(p));
    }
    updateLineTerminatorLocations(this);
    updateBoundingBox(this);
    return this;
  };
  protoOf(PolylineShapeImpl).p2q = function (x, y) {
    if (this.d2k() === 0) {
      return this;
    }
    var dx = x - this.s2r_1.l(0).in_1;
    var dy = y - this.s2r_1.l(0).jn_1;
    // Inline function 'kotlin.collections.forEachIndexed' call
    var index = 0;
    var _iterator__ex2g4s = toList(this.s2r_1).i();
    while (_iterator__ex2g4s.j()) {
      var item = _iterator__ex2g4s.k();
      var _unary__edvuaz = index;
      index = _unary__edvuaz + 1 | 0;
      var index_0 = checkIndexOverflow(_unary__edvuaz);
      this.s2r_1.u2(index_0, new Point2D(item.in_1 + dx, item.jn_1 + dy));
    }
    updateLineTerminatorLocations(this);
    updateBoundingBox(this);
    return this;
  };
  protoOf(PolylineShapeImpl).q2q = function (x, y, area) {
    var rect = new Rectangle2D(x - area, y - area, 2 * area, 2 * area);
    var tmp0 = _get_segmentIndices__vithg7(this);
    var tmp$ret$0;
    $l$block: {
      // Inline function 'kotlin.collections.firstOrNull' call
      var inductionVariable = tmp0.y_1;
      var last = tmp0.z_1;
      if (inductionVariable <= last)
        do {
          var element = inductionVariable;
          inductionVariable = inductionVariable + 1 | 0;
          var it = element;
          if (intersectsSegment(this, it, rect)) {
            tmp$ret$0 = element;
            break $l$block;
          }
        }
         while (!(element === last));
      tmp$ret$0 = null;
    }
    return tmp$ret$0;
  };
  protoOf(PolylineShapeImpl).s2q = function (x, y, area) {
    // Inline function 'io.antarescircuit.jabbah.base.collection.indexOfFirstOrNull' call
    var tmp0 = this.s2r_1;
    var tmp$ret$1;
    $l$block: {
      // Inline function 'kotlin.collections.indexOfFirst' call
      var index = 0;
      var _iterator__ex2g4s = tmp0.i();
      while (_iterator__ex2g4s.j()) {
        var item = _iterator__ex2g4s.k();
        if (item.s1g(x, y, area)) {
          tmp$ret$1 = index;
          break $l$block;
        }
        index = index + 1 | 0;
      }
      tmp$ret$1 = -1;
    }
    var index_0 = tmp$ret$1;
    return index_0 >= 0 ? index_0 : null;
  };
  protoOf(PolylineShapeImpl).t2q = function (index) {
    return new Point2D(this.s2r_1.l(index).in_1 + (this.s2r_1.l(index + 1 | 0).in_1 - this.s2r_1.l(index).in_1) / 2, this.s2r_1.l(index).jn_1 + (this.s2r_1.l(index + 1 | 0).jn_1 - this.s2r_1.l(index).jn_1) / 2);
  };
  protoOf(PolylineShapeImpl).u2q = function () {
    if (this.d2k() <= 2) {
      return false;
    }
    var i = 1;
    var changed = false;
    while (i < this.d2k()) {
      if (canCompactPoint(this, i)) {
        changed = true;
        this.s2r_1.h3(i);
        if (i > 1) {
          i = i - 1 | 0;
        }
      } else {
        i = i + 1 | 0;
      }
    }
    if (changed) {
      updateBoundingBox(this);
    }
    return changed;
  };
  protoOf(PolylineShapeImpl).v2q = function (index) {
    return this.s2r_1.l(index).p1g(this.s2r_1.l(index + 1 | 0));
  };
  protoOf(PolylineShapeImpl).w2q = function (startIndex, endIndex) {
    return this.s2r_1.w1(startIndex, endIndex);
  };
  protoOf(PolylineShapeImpl).x2q = function (index) {
    return Companion_instance_31.o2r(index, this.s2r_1);
  };
  protoOf(PolylineShapeImpl).y2q = function (index) {
    return Companion_instance_31.n2r(index, this.s2r_1);
  };
  protoOf(PolylineShapeImpl).a2r = function (index, otherIndex, other) {
    return Companion_instance_31.o2r(index, this.s2r_1) && Companion_instance_31.n2r(otherIndex, other) || (Companion_instance_31.n2r(index, this.s2r_1) && Companion_instance_31.o2r(otherIndex, other));
  };
  protoOf(PolylineShapeImpl).p2h = function (x) {
    // Inline function 'kotlin.collections.map' call
    var this_0 = this.s2r_1;
    // Inline function 'kotlin.collections.mapTo' call
    var destination = ArrayList_init_$Create$_0(collectionSizeOrDefault(this_0, 10));
    var _iterator__ex2g4s = this_0.i();
    while (_iterator__ex2g4s.j()) {
      var item = _iterator__ex2g4s.k();
      var tmp$ret$2 = item.q1g(x);
      destination.h(tmp$ret$2);
    }
    this.o2q(destination);
  };
  protoOf(PolylineShapeImpl).q2h = function (y) {
    // Inline function 'kotlin.collections.map' call
    var this_0 = this.s2r_1;
    // Inline function 'kotlin.collections.mapTo' call
    var destination = ArrayList_init_$Create$_0(collectionSizeOrDefault(this_0, 10));
    var _iterator__ex2g4s = this_0.i();
    while (_iterator__ex2g4s.j()) {
      var item = _iterator__ex2g4s.k();
      var tmp$ret$2 = item.r1g(y);
      destination.h(tmp$ret$2);
    }
    this.o2q(destination);
  };
  protoOf(PolylineShapeImpl).b2r = function (otherIndex, other) {
    var tmp0 = _get_segmentIndices__vithg7(this);
    var tmp$ret$0;
    $l$block_0: {
      // Inline function 'kotlin.collections.any' call
      var tmp;
      if (isInterface(tmp0, Collection)) {
        tmp = tmp0.m();
      } else {
        tmp = false;
      }
      if (tmp) {
        tmp$ret$0 = false;
        break $l$block_0;
      }
      var inductionVariable = tmp0.y_1;
      var last = tmp0.z_1;
      if (inductionVariable <= last)
        do {
          var element = inductionVariable;
          inductionVariable = inductionVariable + 1 | 0;
          var it = element;
          if (Companion_instance_31.p2r(it, this.s2r_1, other, otherIndex)) {
            tmp$ret$0 = true;
            break $l$block_0;
          }
        }
         while (!(element === last));
      tmp$ret$0 = false;
    }
    return tmp$ret$0;
  };
  function fillProperties_2($this, properties) {
    properties.ct('draw.style.foregroundColor', Companion_getInstance_20().n1s_1);
    properties.ct('draw.style.backgroundColor', Companion_getInstance_20().o1s_1);
    properties.ct('draw.style.textColor', Companion_getInstance_20().n1s_1);
    properties.ct('draw.style.stroke', new Stroke());
    properties.ct('draw.style.font', new FontImpl());
  }
  function configureStyleRepository($this, repository) {
    repository.w2r(Companion_getInstance_33().n1x_1, new BasicStyle());
    repository.w2r(Companion_getInstance_33().l1x_1, new BasicStyle());
    repository.w2r(Companion_getInstance_33().m1x_1, new BasicStyle());
    repository.w2r(Companion_getInstance_33().o1x_1, new BasicStyle());
  }
  function DrawStyleModule() {
    DrawStyleModule_instance = this;
    AbstractModule.call(this);
    this.g1x_1 = Companion_getInstance_32().x2r_1;
  }
  protoOf(DrawStyleModule).ro = function () {
    DrawGraphicsModule_getInstance().to();
    fillProperties_2(this, BaseModule_getInstance().xo_1);
    configureStyleRepository(this, Companion_getInstance_32().x2r_1);
  };
  var DrawStyleModule_instance;
  function DrawStyleModule_getInstance() {
    if (DrawStyleModule_instance == null)
      new DrawStyleModule();
    return DrawStyleModule_instance;
  }
  function Companion_29() {
    Companion_instance_33 = this;
    this.z2r_1 = 'default';
    this.a2s_1 = false;
    this.b2s_1 = new BasicStyle(new CompositeColor(Color_init_$Create$(240, 240, 240), Companion_getInstance_20().o1s_1, Companion_getInstance_20().n1s_1));
    this.c2s_1 = new BasicStyle();
    this.d2s_1 = new BasicStyle();
    this.e2s_1 = new BasicStyle(VOID, this.d2s_1.v1t().y2o());
    this.f2s_1 = new BasicStyle(new CompositeColor(Color_init_$Create$(249, 214, 54), Color_init_$Create$(255, 253, 219), Companion_getInstance_20().n1s_1));
    this.g2s_1 = new CompositeColor(Companion_getInstance_20().s1s_1, Companion_getInstance_20().s1s_1, Companion_getInstance_20().s1s_1);
    this.h2s_1 = new CompositeColor(Companion_getInstance_20().q1s_1, Companion_getInstance_20().o1s_1);
    this.i2s_1 = listOf([new ReferenceColor(DrawGraphicsModule_getInstance().k2l_1, DrawGraphicsModule_getInstance().l2l_1), new ReferenceColor(DrawGraphicsModule_getInstance().e2l_1, DrawGraphicsModule_getInstance().f2l_1), new ReferenceColor(DrawGraphicsModule_getInstance().g2l_1, DrawGraphicsModule_getInstance().h2l_1), new ReferenceColor(DrawGraphicsModule_getInstance().i2l_1, DrawGraphicsModule_getInstance().j2l_1), new ReferenceColor(DrawGraphicsModule_getInstance().o2l_1, DrawGraphicsModule_getInstance().p2l_1), new ReferenceColor(DrawGraphicsModule_getInstance().m2l_1, DrawGraphicsModule_getInstance().n2l_1), new ReferenceColor(DrawGraphicsModule_getInstance().w2l_1, DrawGraphicsModule_getInstance().w2l_1.f2k()), new ReferenceColor(DrawGraphicsModule_getInstance().u2l_1, DrawGraphicsModule_getInstance().u2l_1.f2k()), new ReferenceColor(DrawGraphicsModule_getInstance().v2l_1, DrawGraphicsModule_getInstance().v2l_1.f2k())]);
    this.j2s_1 = listOf([new PredefinedColor(PredefinedColorIdentity_White_getInstance(), DrawGraphicsModule_getInstance().u2l_1), new PredefinedColor(PredefinedColorIdentity_Black_getInstance(), DrawGraphicsModule_getInstance().v2l_1), new PredefinedColor(PredefinedColorIdentity_Gray_getInstance(), DrawGraphicsModule_getInstance().w2l_1), new PredefinedColor(PredefinedColorIdentity_Yellow_getInstance(), DrawGraphicsModule_getInstance().k2l_1), new PredefinedColor(PredefinedColorIdentity_Brown_getInstance(), DrawGraphicsModule_getInstance().q2l_1), new PredefinedColor(PredefinedColorIdentity_Red_getInstance(), DrawGraphicsModule_getInstance().e2l_1), new PredefinedColor(PredefinedColorIdentity_Violet_getInstance(), DrawGraphicsModule_getInstance().m2l_1), new PredefinedColor(PredefinedColorIdentity_Blue_getInstance(), DrawGraphicsModule_getInstance().g2l_1), new PredefinedColor(PredefinedColorIdentity_Turquoise_getInstance(), DrawGraphicsModule_getInstance().s2l_1), new PredefinedColor(PredefinedColorIdentity_Green_getInstance(), DrawGraphicsModule_getInstance().i2l_1)]);
  }
  var Companion_instance_33;
  function Companion_getInstance_31() {
    if (Companion_instance_33 == null)
      new Companion_29();
    return Companion_instance_33;
  }
  function DrawTheme(name, dark, referenceColorSequenceProvider, referenceColors, predefinedColors, background, text, figure, annotation, tooltip, shadow, hover) {
    Companion_getInstance_31();
    name = name === VOID ? 'default' : name;
    dark = dark === VOID ? false : dark;
    referenceColorSequenceProvider = referenceColorSequenceProvider === VOID ? ReferenceColorSequenceProvider_getInstance() : referenceColorSequenceProvider;
    referenceColors = referenceColors === VOID ? Companion_getInstance_31().i2s_1 : referenceColors;
    predefinedColors = predefinedColors === VOID ? Companion_getInstance_31().j2s_1 : predefinedColors;
    background = background === VOID ? Companion_getInstance_31().b2s_1 : background;
    text = text === VOID ? Companion_getInstance_31().c2s_1 : text;
    figure = figure === VOID ? Companion_getInstance_31().d2s_1 : figure;
    annotation = annotation === VOID ? Companion_getInstance_31().e2s_1 : annotation;
    tooltip = tooltip === VOID ? Companion_getInstance_31().f2s_1 : tooltip;
    shadow = shadow === VOID ? Companion_getInstance_31().g2s_1 : shadow;
    hover = hover === VOID ? Companion_getInstance_31().h2s_1 : hover;
    this.c2f_1 = name;
    this.d2f_1 = dark;
    this.e2f_1 = referenceColorSequenceProvider;
    this.f2f_1 = referenceColors;
    this.g2f_1 = predefinedColors;
    this.h2f_1 = background;
    this.i2f_1 = text;
    this.j2f_1 = figure;
    this.k2f_1 = annotation;
    this.l2f_1 = tooltip;
    this.m2f_1 = shadow;
    this.n2f_1 = hover;
  }
  protoOf(DrawTheme).m2 = function () {
    return this.c2f_1;
  };
  protoOf(DrawTheme).o2s = function () {
    return this.d2f_1;
  };
  protoOf(DrawTheme).toString = function () {
    return this.m2();
  };
  protoOf(DrawTheme).p2s = function (styleRepository, styleOnly) {
    if (!styleOnly) {
      this.e2f_1.j2o(this.f2f_1);
      // Inline function 'kotlin.collections.forEach' call
      var _iterator__ex2g4s = this.g2f_1.i();
      while (_iterator__ex2g4s.j()) {
        var element = _iterator__ex2g4s.k();
        PredefinedColorRepository_getInstance().l2m(element);
      }
    }
    styleRepository.w2r(Companion_getInstance_33().k1x_1, this.i2f_1);
    styleRepository.w2r(Companion_getInstance_33().n1x_1, this.h2f_1);
    styleRepository.w2r(Companion_getInstance_33().l1x_1, this.j2f_1);
    styleRepository.w2r(Companion_getInstance_33().m1x_1, this.k2f_1);
    styleRepository.w2r(Companion_getInstance_33().o1x_1, this.l2f_1);
  };
  function Stylable() {
  }
  function StylableImpl$_color$lambda(this$0) {
    return function () {
      return new CompositeColor(this$0.i2c(), this$0.j2c(), this$0.k2c());
    };
  }
  function StylableImpl(invalidator, styleType, styleProvider, filled, stroked, customColor, customStroke, customFont, customShadow) {
    invalidator = invalidator === VOID ? null : invalidator;
    filled = filled === VOID ? true : filled;
    stroked = stroked === VOID ? true : stroked;
    customColor = customColor === VOID ? null : customColor;
    customStroke = customStroke === VOID ? null : customStroke;
    customFont = customFont === VOID ? null : customFont;
    customShadow = customShadow === VOID ? null : customShadow;
    this.q2s_1 = invalidator;
    this.r2s_1 = styleProvider;
    this.s2s_1 = styleType;
    this.t2s_1 = filled;
    this.u2s_1 = stroked;
    var tmp = this;
    tmp.v2s_1 = customColor == null ? null : customColor.j2n_1;
    var tmp_0 = this;
    tmp_0.w2s_1 = customStroke == null ? null : customStroke.s2n_1;
    this.x2s_1 = customFont;
    this.y2s_1 = customShadow;
    var tmp_1 = this;
    tmp_1.z2s_1 = resettableLazy(StylableImpl$_color$lambda(this));
  }
  protoOf(StylableImpl).g2c = function (_set____db54di) {
    this.q2s_1 = _set____db54di;
  };
  protoOf(StylableImpl).h2c = function () {
    return this.r2s_1;
  };
  protoOf(StylableImpl).m2c = function (value) {
    if (!equals(this.s2s_1, value)) {
      var tmp0_safe_receiver = this.q2s_1;
      if (tmp0_safe_receiver == null)
        null;
      else
        tmp0_safe_receiver();
      this.s2s_1 = value;
      var tmp1_safe_receiver = this.q2s_1;
      if (tmp1_safe_receiver == null)
        null;
      else
        tmp1_safe_receiver();
      this.z2s_1.bu();
    }
  };
  protoOf(StylableImpl).r28 = function () {
    return this.s2s_1;
  };
  protoOf(StylableImpl).n2c = function () {
    return this.r2s_1.p1x(this.s2s_1);
  };
  protoOf(StylableImpl).o2c = function (value) {
    if (!(this.t2s_1 === value)) {
      var tmp0_safe_receiver = this.q2s_1;
      if (tmp0_safe_receiver == null)
        null;
      else
        tmp0_safe_receiver();
      this.t2s_1 = value;
      var tmp1_safe_receiver = this.q2s_1;
      if (tmp1_safe_receiver == null)
        null;
      else
        tmp1_safe_receiver();
    }
  };
  protoOf(StylableImpl).p2c = function () {
    return this.t2s_1;
  };
  protoOf(StylableImpl).q2c = function (value) {
    if (!(this.u2s_1 === value)) {
      var tmp0_safe_receiver = this.q2s_1;
      if (tmp0_safe_receiver == null)
        null;
      else
        tmp0_safe_receiver();
      this.u2s_1 = value;
      var tmp1_safe_receiver = this.q2s_1;
      if (tmp1_safe_receiver == null)
        null;
      else
        tmp1_safe_receiver();
    }
  };
  protoOf(StylableImpl).r2c = function () {
    return this.u2s_1;
  };
  protoOf(StylableImpl).t2c = function (value) {
    var tmp = this.v2s_1;
    if (!equals(tmp, value == null ? null : value.j2n_1)) {
      var tmp0_safe_receiver = this.q2s_1;
      if (tmp0_safe_receiver == null)
        null;
      else
        tmp0_safe_receiver();
      var tmp_0 = this;
      tmp_0.v2s_1 = value == null ? null : value.j2n_1;
      var tmp2_safe_receiver = this.q2s_1;
      if (tmp2_safe_receiver == null)
        null;
      else
        tmp2_safe_receiver();
      this.z2s_1.bu();
    }
  };
  protoOf(StylableImpl).u2c = function () {
    return !(this.v2s_1 == null) ? PredefinedColorRepository_getInstance().r2n(ensureNotNull(this.v2s_1)) : null;
  };
  protoOf(StylableImpl).v2c = function (value) {
    var tmp = this.w2s_1;
    if (!equals(tmp, value == null ? null : value.s2n_1)) {
      var tmp0_safe_receiver = this.q2s_1;
      if (tmp0_safe_receiver == null)
        null;
      else
        tmp0_safe_receiver();
      var tmp_0 = this;
      tmp_0.w2s_1 = value == null ? null : value.s2n_1;
      var tmp2_safe_receiver = this.q2s_1;
      if (tmp2_safe_receiver == null)
        null;
      else
        tmp2_safe_receiver();
    }
  };
  protoOf(StylableImpl).w2c = function () {
    return !(this.w2s_1 == null) ? PredefinedStrokeRepository_getInstance().v2n(ensureNotNull(this.w2s_1)) : null;
  };
  protoOf(StylableImpl).x2c = function (value) {
    if (!equals(this.x2s_1, value)) {
      var tmp0_safe_receiver = this.q2s_1;
      if (tmp0_safe_receiver == null)
        null;
      else
        tmp0_safe_receiver();
      this.x2s_1 = value;
      var tmp1_safe_receiver = this.q2s_1;
      if (tmp1_safe_receiver == null)
        null;
      else
        tmp1_safe_receiver();
    }
  };
  protoOf(StylableImpl).y2c = function (value) {
    if (!(this.y2s_1 == value)) {
      var effectiveValue = value === this.s2c() ? null : value;
      var tmp0_safe_receiver = this.q2s_1;
      if (tmp0_safe_receiver == null)
        null;
      else
        tmp0_safe_receiver();
      this.y2s_1 = effectiveValue;
      var tmp1_safe_receiver = this.q2s_1;
      if (tmp1_safe_receiver == null)
        null;
      else
        tmp1_safe_receiver();
    }
  };
  protoOf(StylableImpl).z2c = function () {
    return this.y2s_1;
  };
  protoOf(StylableImpl).m1t = function () {
    return this.z2s_1.j2();
  };
  protoOf(StylableImpl).i2c = function () {
    var tmp0_safe_receiver = this.u2c();
    var tmp1_safe_receiver = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.k2n_1;
    var tmp2_elvis_lhs = tmp1_safe_receiver == null ? null : tmp1_safe_receiver.h1x_1;
    return tmp2_elvis_lhs == null ? this.n2c().m1t().h1x_1 : tmp2_elvis_lhs;
  };
  protoOf(StylableImpl).j2c = function () {
    var tmp0_safe_receiver = this.u2c();
    var tmp1_safe_receiver = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.k2n_1;
    var tmp2_elvis_lhs = tmp1_safe_receiver == null ? null : tmp1_safe_receiver.i1x_1;
    return tmp2_elvis_lhs == null ? this.n2c().m1t().i1x_1 : tmp2_elvis_lhs;
  };
  protoOf(StylableImpl).k2c = function () {
    var tmp0_safe_receiver = this.u2c();
    var tmp1_safe_receiver = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.k2n_1;
    var tmp2_elvis_lhs = tmp1_safe_receiver == null ? null : tmp1_safe_receiver.j1x_1;
    return tmp2_elvis_lhs == null ? this.n2c().m1t().j1x_1 : tmp2_elvis_lhs;
  };
  protoOf(StylableImpl).l2c = function () {
    var tmp0_elvis_lhs = this.x2s_1;
    return tmp0_elvis_lhs == null ? this.n2c().l2c() : tmp0_elvis_lhs;
  };
  protoOf(StylableImpl).v1t = function () {
    var tmp0_safe_receiver = this.w2c();
    var tmp1_elvis_lhs = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.t2n_1;
    return tmp1_elvis_lhs == null ? this.n2c().v1t() : tmp1_elvis_lhs;
  };
  protoOf(StylableImpl).s2c = function () {
    var tmp0_elvis_lhs = this.y2s_1;
    return tmp0_elvis_lhs == null ? this.n2c().s2c() : tmp0_elvis_lhs;
  };
  function BasicStyle(color, stroke, font, shadow) {
    color = color === VOID ? new CompositeColor(DrawModule_getInstance().v29_1.j1z('draw.style.foregroundColor'), DrawModule_getInstance().v29_1.j1z('draw.style.backgroundColor'), DrawModule_getInstance().v29_1.j1z('draw.style.textColor')) : color;
    stroke = stroke === VOID ? DrawModule_getInstance().v29_1.k1z('draw.style.stroke') : stroke;
    font = font === VOID ? DrawModule_getInstance().v29_1.i1z('draw.style.font') : font;
    shadow = shadow === VOID ? false : shadow;
    this.k2s_1 = color;
    this.l2s_1 = stroke;
    this.m2s_1 = font;
    this.n2s_1 = shadow;
  }
  protoOf(BasicStyle).m1t = function () {
    return this.k2s_1;
  };
  protoOf(BasicStyle).v1t = function () {
    return this.l2s_1;
  };
  protoOf(BasicStyle).l2c = function () {
    return this.m2s_1;
  };
  protoOf(BasicStyle).s2c = function () {
    return this.n2s_1;
  };
  function _get_LOG__e5r759_7($this) {
    var tmp0 = $this.y2r_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('LOG', 1, tmp, StyleRepository$Companion$_get_LOG_$ref_ip7vej(), null);
    return tmp0.j2();
  }
  function StyleRepository$Companion$_get_LOG_$ref_ip7vej() {
    return function (p0) {
      return _get_LOG__e5r759_7(p0);
    };
  }
  function Companion_30() {
    Companion_instance_34 = this;
    this.x2r_1 = new StyleRepository();
    this.y2r_1 = logger(getKClass(StyleRepository));
  }
  var Companion_instance_34;
  function Companion_getInstance_32() {
    if (Companion_instance_34 == null)
      new Companion_30();
    return Companion_instance_34;
  }
  function _get_typeMap__nyz98v($this) {
    var tmp0 = $this.x25_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('typeMap', 1, tmp, StyleRepository$_get_typeMap_$ref_u7jtez(), null);
    return tmp0.j2();
  }
  function _get_typeList__wsttqr($this) {
    var tmp0 = $this.y25_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('typeList', 1, tmp, StyleRepository$_get_typeList_$ref_x7lj9n(), null);
    return tmp0.j2();
  }
  function _get_styleMap__go6280($this) {
    var tmp0 = $this.z25_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('styleMap', 1, tmp, StyleRepository$_get_styleMap_$ref_nd1008(), null);
    return tmp0.j2();
  }
  function StyleRepository$typeMap$delegate$lambda() {
    // Inline function 'kotlin.collections.mutableMapOf' call
    return LinkedHashMap_init_$Create$();
  }
  function StyleRepository$_get_typeMap_$ref_u7jtez() {
    return function (p0) {
      return _get_typeMap__nyz98v(p0);
    };
  }
  function StyleRepository$typeList$delegate$lambda() {
    // Inline function 'kotlin.collections.mutableListOf' call
    return ArrayList_init_$Create$();
  }
  function StyleRepository$_get_typeList_$ref_x7lj9n() {
    return function (p0) {
      return _get_typeList__wsttqr(p0);
    };
  }
  function StyleRepository$styleMap$delegate$lambda() {
    // Inline function 'kotlin.collections.mutableMapOf' call
    return LinkedHashMap_init_$Create$();
  }
  function StyleRepository$_get_styleMap_$ref_nd1008() {
    return function (p0) {
      return _get_styleMap__go6280(p0);
    };
  }
  function StyleRepository(predefinedColorProvider, predefinedStrokeProvider) {
    Companion_getInstance_32();
    predefinedColorProvider = predefinedColorProvider === VOID ? PredefinedColorRepository_getInstance() : predefinedColorProvider;
    predefinedStrokeProvider = predefinedStrokeProvider === VOID ? PredefinedStrokeRepository_getInstance() : predefinedStrokeProvider;
    this.v25_1 = predefinedColorProvider;
    this.w25_1 = predefinedStrokeProvider;
    var tmp = this;
    tmp.x25_1 = lazy(StyleRepository$typeMap$delegate$lambda);
    var tmp_0 = this;
    tmp_0.y25_1 = lazy(StyleRepository$typeList$delegate$lambda);
    var tmp_1 = this;
    tmp_1.z25_1 = lazy(StyleRepository$styleMap$delegate$lambda);
  }
  protoOf(StyleRepository).a2t = function () {
    return this.v25_1;
  };
  protoOf(StyleRepository).b2t = function () {
    return this.w25_1;
  };
  protoOf(StyleRepository).p1x = function (styleType) {
    var style = _get_styleMap__go6280(this).g2(styleType);
    if (style == null) {
      _get_LOG__e5r759_7(Companion_getInstance_32()).kl("No registered Style for StyleType '" + styleType.n28_1 + "'");
      throw NoSuchElementException_init_$Create$('getStyle');
    }
    return style;
  };
  protoOf(StyleRepository).c2t = function (name) {
    var styleType = _get_typeMap__nyz98v(this).g2(name);
    if (styleType == null) {
      _get_LOG__e5r759_7(Companion_getInstance_32()).kl("No registered StyleType '" + name + "'");
      throw NoSuchElementException_init_$Create$('getStyleType');
    }
    return styleType;
  };
  protoOf(StyleRepository).d2t = function (styleType) {
    var tmp0 = _get_typeMap__nyz98v(this);
    // Inline function 'kotlin.collections.set' call
    var key = styleType.n28_1;
    tmp0.y1(key, styleType);
    _get_typeList__wsttqr(this).h(styleType);
    return this;
  };
  protoOf(StyleRepository).w2r = function (styleType, style) {
    if (!_get_typeMap__nyz98v(this).e2(styleType.n28_1)) {
      this.d2t(styleType);
    }
    // Inline function 'kotlin.collections.set' call
    _get_styleMap__go6280(this).y1(styleType, style);
    return this;
  };
  function Companion_31() {
    Companion_instance_35 = this;
    this.k1x_1 = new StyleType('text', 'draw.styleType.text.name');
    this.l1x_1 = new StyleType('figure', 'draw.styleType.figure.name');
    this.m1x_1 = new StyleType('annotation', 'draw.styleType.annotation.name');
    this.n1x_1 = new StyleType('background', 'draw.styleType.background.name', true);
    this.o1x_1 = new StyleType('tooltip', 'draw.styleType.tooltipView.name', true);
  }
  var Companion_instance_35;
  function Companion_getInstance_33() {
    if (Companion_instance_35 == null)
      new Companion_31();
    return Companion_instance_35;
  }
  function StyleType(name, descriptionKey, isSystem, isBackdrop) {
    Companion_getInstance_33();
    isSystem = isSystem === VOID ? false : isSystem;
    isBackdrop = isBackdrop === VOID ? false : isBackdrop;
    this.n28_1 = name;
    this.o28_1 = descriptionKey;
    this.p28_1 = isSystem;
    this.q28_1 = isBackdrop;
  }
  protoOf(StyleType).kq = function () {
    return Translations_getInstance().zm(this.o28_1, []);
  };
  protoOf(StyleType).toString = function () {
    return this.kq();
  };
  function _set_current__qj3kk($this, value) {
    if (!($this.q2f_1 === value)) {
      $this.q2f_1 = value;
      $this.q2f_1.p2s(DrawStyleModule_getInstance().g1x_1, false);
      BaseModule_getInstance().zo_1.eu(new ThemeEvent($this.q2f_1));
    }
  }
  function Themes() {
    Themes_instance = this;
    this.o2f_1 = 'draw.style.Theme.name';
    this.p2f_1 = mutableListOf([new DrawTheme()]);
    this.q2f_1 = this.p2f_1.l(0);
  }
  protoOf(Themes).r2f = function () {
    var tmp = this.q2f_1;
    return isInterface(tmp, Theme) ? tmp : THROW_CCE();
  };
  protoOf(Themes).nb = function (name) {
    var tmp0 = this.p2f_1;
    var tmp$ret$0;
    $l$block: {
      // Inline function 'kotlin.collections.firstOrNull' call
      var _iterator__ex2g4s = tmp0.i();
      while (_iterator__ex2g4s.j()) {
        var element = _iterator__ex2g4s.k();
        if (element.m2() === name) {
          tmp$ret$0 = element;
          break $l$block;
        }
      }
      tmp$ret$0 = null;
    }
    return tmp$ret$0;
  };
  protoOf(Themes).e2t = function (themes) {
    // Inline function 'kotlin.collections.isNotEmpty' call
    // Inline function 'kotlin.collections.isEmpty' call
    if (!(themes.length === 0)) {
      this.p2f_1.a2();
      addAll_0(this.p2f_1, themes);
      var tmp;
      if (BaseModule_getInstance().xo_1.bt('draw.style.Theme.name')) {
        tmp = BaseModule_getInstance().xo_1.ht('draw.style.Theme.name');
      } else {
        tmp = null;
      }
      var storedThemeName = tmp;
      // Inline function 'kotlin.collections.map' call
      var this_0 = this.p2f_1;
      // Inline function 'kotlin.collections.mapTo' call
      var destination = ArrayList_init_$Create$_0(collectionSizeOrDefault(this_0, 10));
      var _iterator__ex2g4s = this_0.i();
      while (_iterator__ex2g4s.j()) {
        var item = _iterator__ex2g4s.k();
        var tmp$ret$4 = item.m2();
        destination.h(tmp$ret$4);
      }
      if (contains(destination, storedThemeName)) {
        _set_current__qj3kk(this, ensureNotNull(this.nb(ensureNotNull(storedThemeName))));
      } else {
        _set_current__qj3kk(this, ensureNotNull(this.nb(first(this.p2f_1).m2())));
        this.f2t(this.q2f_1.m2());
      }
    }
  };
  protoOf(Themes).f2t = function (themeName) {
    BaseModule_getInstance().xo_1.ct('draw.style.Theme.name', themeName);
  };
  var Themes_instance;
  function Themes_getInstance() {
    if (Themes_instance == null)
      new Themes();
    return Themes_instance;
  }
  function Theme() {
  }
  function ThemeEvent(currentTheme) {
    this.g2t_1 = currentTheme;
  }
  protoOf(ThemeEvent).toString = function () {
    return 'ThemeEvent(currentTheme=' + toString(this.g2t_1) + ')';
  };
  protoOf(ThemeEvent).hashCode = function () {
    return hashCode(this.g2t_1);
  };
  protoOf(ThemeEvent).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof ThemeEvent))
      return false;
    if (!equals(this.g2t_1, other.g2t_1))
      return false;
    return true;
  };
  function ViewPropertyListener($outer) {
    this.h2t_1 = $outer;
  }
  protoOf(ViewPropertyListener).propertyChanged = function (e) {
    this.h2t_1.u2t(e);
  };
  function activeViewChanged($this, oldView, newView) {
    var tmp1_safe_receiver = oldView == null ? null : oldView.f1o();
    if (tmp1_safe_receiver == null)
      null;
    else {
      tmp1_safe_receiver.m1y($this.t2t_1);
    }
    $this.updateEnabled();
    var tmp3_safe_receiver = newView == null ? null : newView.f1o();
    if (tmp3_safe_receiver == null)
      null;
    else {
      tmp3_safe_receiver.l1y($this.t2t_1);
    }
    $this.v2t();
  }
  function AbstractContentViewAction$activeViewHandler$lambda(this$0) {
    return function (it) {
      activeViewChanged(this$0, it.x2t_1, it.y2t_1);
      return Unit_instance;
    };
  }
  function AbstractContentViewAction(baseName, eventBus, viewManager) {
    eventBus = eventBus === VOID ? BaseModule_getInstance().zo_1 : eventBus;
    viewManager = viewManager === VOID ? DrawViewModule_getInstance().a2u_1 : viewManager;
    AbstractAction_init_$Init$(baseName, VOID, VOID, this);
    this.q2t_1 = eventBus;
    this.r2t_1 = viewManager;
    var tmp = this;
    tmp.s2t_1 = AbstractContentViewAction$activeViewHandler$lambda(this);
    this.t2t_1 = new ViewPropertyListener(this);
    this.q2t_1.j17(getKClass(ActiveContentViewChangedEvent), this.s2t_1);
    var tmp0_safe_receiver = this.f1o();
    if (tmp0_safe_receiver == null)
      null;
    else {
      tmp0_safe_receiver.l1y(this.t2t_1);
    }
    this.nq(false);
  }
  protoOf(AbstractContentViewAction).f1o = function () {
    var tmp0_safe_receiver = this.r2t_1.b2u();
    return tmp0_safe_receiver == null ? null : tmp0_safe_receiver.f1o();
  };
  protoOf(AbstractContentViewAction).dispose = function () {
    protoOf(AbstractAction).dispose.call(this);
    this.q2t_1.l17(this.s2t_1);
  };
  protoOf(AbstractContentViewAction).u2t = function (e) {
  };
  protoOf(AbstractContentViewAction).wr = function () {
    return !(this.r2t_1.b2u() == null);
  };
  protoOf(AbstractContentViewAction).v2t = function () {
  };
  function AbstractViewAction(baseName, eventBus, viewManager) {
    eventBus = eventBus === VOID ? BaseModule_getInstance().zo_1 : eventBus;
    viewManager = viewManager === VOID ? DrawViewModule_getInstance().a2u_1 : viewManager;
    AbstractContentViewAction.call(this, baseName, eventBus, viewManager);
  }
  protoOf(AbstractViewAction).wr = function () {
    return this.o2u();
  };
  protoOf(AbstractViewAction).o2u = function () {
    return !(this.r2t_1.b2u() == null) && !(ensureNotNull(this.r2t_1.b2u()).f1o() == null);
  };
  function Companion_32() {
    this.p2u_1 = 50;
    this.q2u_1 = 10;
    this.r2u_1 = 50;
  }
  var Companion_instance_36;
  function Companion_getInstance_34() {
    return Companion_instance_36;
  }
  function start($this) {
    $this.t2u_1.vp();
  }
  function stop($this) {
    $this.t2u_1.wp();
  }
  function pan($this) {
    var dir = $this.u2u_1.e1a() ? 1 : -1;
    var panDirection_0 = panDirection($this, $this.u2u_1.hw()).i1f(dir * 10);
    $this.s2u_1.x23().m26(numberToInt(panDirection_0.h1i_1), numberToInt(panDirection_0.i1i_1));
    $this.s2u_1.j1y($this.u2u_1);
  }
  function isInsideSensitiveRegion($this, p) {
    return p.in_1 <= 50 || p.in_1 > ($this.s2u_1.p1b() - 50 | 0) || p.jn_1 <= 50 || p.jn_1 > ($this.s2u_1.r1b() - 50 | 0);
  }
  function panDirection($this, p) {
    return (new Vector2D(($this.s2u_1.p1b() / 2 | 0) - p.in_1, ($this.s2u_1.r1b() / 2 | 0) - p.jn_1)).l1i();
  }
  function AutoPanning$lambda(this$0) {
    return function (it) {
      pan(this$0);
      return Unit_instance;
    };
  }
  function AutoPanning(view) {
    MouseAdapter.call(this);
    this.s2u_1 = view;
    this.t2u_1 = System_getInstance().ul();
    this.u2u_1 = new MouseEventImpl();
    this.v2u_1 = true;
    this.t2u_1.up(50, VOID, AutoPanning$lambda(this));
  }
  protoOf(AutoPanning).u1a = function (e) {
    this.u2u_1 = e;
    if (isInsideSensitiveRegion(this, e.hw())) {
      if (!this.t2u_1.xp()) {
        start(this);
      }
    } else {
      if (this.t2u_1.xp()) {
        stop(this);
      }
    }
  };
  protoOf(AutoPanning).w2u = function () {
    if (this.v2u_1) {
      this.s2u_1.d1y(this);
    }
  };
  protoOf(AutoPanning).x2u = function () {
    this.s2u_1.e1y(this);
    stop(this);
  };
  function ActiveContentViewChangedEvent(viewManager, oldView, newView) {
    this.w2t_1 = viewManager;
    this.x2t_1 = oldView;
    this.y2t_1 = newView;
  }
  protoOf(ActiveContentViewChangedEvent).toString = function () {
    return 'ActiveContentViewChangedEvent(viewManager=' + toString(this.w2t_1) + ', oldView=' + toString_0(this.x2t_1) + ', newView=' + toString_0(this.y2t_1) + ')';
  };
  protoOf(ActiveContentViewChangedEvent).hashCode = function () {
    var result = hashCode(this.w2t_1);
    result = imul(result, 31) + (this.x2t_1 == null ? 0 : hashCode(this.x2t_1)) | 0;
    result = imul(result, 31) + (this.y2t_1 == null ? 0 : hashCode(this.y2t_1)) | 0;
    return result;
  };
  protoOf(ActiveContentViewChangedEvent).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof ActiveContentViewChangedEvent))
      return false;
    if (!equals(this.w2t_1, other.w2t_1))
      return false;
    if (!equals(this.x2t_1, other.x2t_1))
      return false;
    if (!equals(this.y2t_1, other.y2t_1))
      return false;
    return true;
  };
  function ContentViewManagerImpl_init_$Init$($this) {
    ContentViewManagerImpl.call($this, BaseModule_getInstance().zo_1);
    return $this;
  }
  function ContentViewManagerImpl_init_$Create$() {
    return ContentViewManagerImpl_init_$Init$(objectCreate(protoOf(ContentViewManagerImpl)));
  }
  function ContentViewManagerImpl(eventBus) {
    this.y2u_1 = eventBus;
    this.z2u_1 = null;
  }
  protoOf(ContentViewManagerImpl).a2v = function (value) {
    var oldView = this.z2u_1;
    this.z2u_1 = value;
    this.y2u_1.eu(new ActiveContentViewChangedEvent(this, oldView, this.z2u_1));
  };
  protoOf(ContentViewManagerImpl).b2u = function () {
    return this.z2u_1;
  };
  function fillProperties_3($this, properties) {
    properties.ct('draw.view.minZoomFactor', 0.05);
    properties.ct('draw.view.maxZoomFactor', 20.0);
    properties.ct('draw.view.defaultZoomFactor', 1.0);
    properties.ct('view.ZoomPanController.wheelZoomStep', 1.1);
    properties.ct('view.ZoomPanController.wheelZoomRequiredMeta', false);
    properties.ct('view.ZoomPanController.wheelPanStep', 5);
    properties.ct('draw.view.tooltipsEnabled', true);
    properties.ct('draw.view.TooltipManager.delay', 1500);
  }
  function DrawViewModule() {
    DrawViewModule_instance = this;
    AbstractModule.call(this);
    this.a2u_1 = new ContentViewManagerImpl(BaseModule_getInstance().zo_1);
  }
  protoOf(DrawViewModule).ro = function () {
    BaseModule_getInstance().to();
    fillProperties_3(this, BaseModule_getInstance().xo_1);
    TooltipManager_getInstance().p2v(BaseModule_getInstance().zo_1);
  };
  var DrawViewModule_instance;
  function DrawViewModule_getInstance() {
    if (DrawViewModule_instance == null)
      new DrawViewModule();
    return DrawViewModule_instance;
  }
  function Companion_33() {
    this.q2v_1 = 40;
  }
  var Companion_instance_37;
  function Companion_getInstance_35() {
    return Companion_instance_37;
  }
  function repaintDirtyRegion($this) {
    if ($this.t2v_1) {
      $this.r2v_1.w1x(0, 0, $this.r2v_1.p1b(), $this.r2v_1.r1b());
    } else {
      var p1 = !($this.s2v_1 == null) ? $this.r2v_1.q24(new Point2D(ensureNotNull($this.s2v_1).j1c(), ensureNotNull($this.s2v_1).k1c())) : Companion_getInstance().g1a_1;
      var p2 = !($this.s2v_1 == null) ? $this.r2v_1.q24(new Point2D(ensureNotNull($this.s2v_1).l1c(), ensureNotNull($this.s2v_1).m1c())) : $this.v2v_1;
      // Inline function 'kotlin.math.floor' call
      var x = p1.in_1;
      var tmp$ret$0 = Math.floor(x);
      var x1 = numberToInt(tmp$ret$0);
      // Inline function 'kotlin.math.floor' call
      var x_0 = p1.jn_1;
      var tmp$ret$1 = Math.floor(x_0);
      var y1 = numberToInt(tmp$ret$1);
      // Inline function 'kotlin.math.ceil' call
      var x_1 = p2.in_1;
      var tmp$ret$2 = Math.ceil(x_1);
      var x2 = numberToInt(tmp$ret$2);
      // Inline function 'kotlin.math.ceil' call
      var x_2 = p2.jn_1;
      var tmp$ret$3 = Math.ceil(x_2);
      var y2 = numberToInt(tmp$ret$3);
      $this.r2v_1.w1x(x1 - 1 | 0, y1 - 1 | 0, (x2 - x1 | 0) + 2 | 0, (y2 - y1 | 0) + 2 | 0);
    }
    $this.s2v_1 = null;
    $this.t2v_1 = false;
  }
  function startTimerIfNeeded($this) {
    if (!$this.u2v_1.xp()) {
      $this.u2v_1.vp();
    }
  }
  function sam$io_antarescircuit_jabbah_base_event_PropertyChangeListener$0_0(function_0) {
    this.y2v_1 = function_0;
  }
  protoOf(sam$io_antarescircuit_jabbah_base_event_PropertyChangeListener$0_0).propertyChanged = function (e) {
    return this.y2v_1(e);
  };
  protoOf(sam$io_antarescircuit_jabbah_base_event_PropertyChangeListener$0_0).p2 = function () {
    return this.y2v_1;
  };
  protoOf(sam$io_antarescircuit_jabbah_base_event_PropertyChangeListener$0_0).equals = function (other) {
    var tmp;
    if (!(other == null) ? isInterface(other, PropertyChangeListener) : false) {
      var tmp_0;
      if (!(other == null) ? isInterface(other, FunctionAdapter) : false) {
        tmp_0 = equals(this.p2(), other.p2());
      } else {
        tmp_0 = false;
      }
      tmp = tmp_0;
    } else {
      tmp = false;
    }
    return tmp;
  };
  protoOf(sam$io_antarescircuit_jabbah_base_event_PropertyChangeListener$0_0).hashCode = function () {
    return hashCode(this.p2());
  };
  function sam$io_antarescircuit_jabbah_base_event_PropertyChangeListener$0_1(function_0) {
    this.z2v_1 = function_0;
  }
  protoOf(sam$io_antarescircuit_jabbah_base_event_PropertyChangeListener$0_1).propertyChanged = function (e) {
    return this.z2v_1(e);
  };
  protoOf(sam$io_antarescircuit_jabbah_base_event_PropertyChangeListener$0_1).p2 = function () {
    return this.z2v_1;
  };
  protoOf(sam$io_antarescircuit_jabbah_base_event_PropertyChangeListener$0_1).equals = function (other) {
    var tmp;
    if (!(other == null) ? isInterface(other, PropertyChangeListener) : false) {
      var tmp_0;
      if (!(other == null) ? isInterface(other, FunctionAdapter) : false) {
        tmp_0 = equals(this.p2(), other.p2());
      } else {
        tmp_0 = false;
      }
      tmp = tmp_0;
    } else {
      tmp = false;
    }
    return tmp;
  };
  protoOf(sam$io_antarescircuit_jabbah_base_event_PropertyChangeListener$0_1).hashCode = function () {
    return hashCode(this.p2());
  };
  function InvalidatableViewPainter$viewDimensionListener$lambda(this$0) {
    return function (it) {
      var tmp;
      if (it.name === 'PROP_DIMENSION') {
        this$0.v2v_1 = Point2D_init_$Create$(this$0.r2v_1.p1b(), this$0.r2v_1.r1b());
        tmp = Unit_instance;
      }
      return Unit_instance;
    };
  }
  function InvalidatableViewPainter$viewListener$lambda(this$0) {
    return function (it) {
      var tmp;
      if (it.name === 'PROP_CANVAS') {
        this$0.r2v_1.c23().e1b(this$0.w2v_1);
        tmp = Unit_instance;
      }
      return Unit_instance;
    };
  }
  function InvalidatableViewPainter$lambda$lambda(this$0) {
    return function () {
      repaintDirtyRegion(this$0);
      return Unit_instance;
    };
  }
  function InvalidatableViewPainter$lambda(this$0) {
    return function (it) {
      this$0.u2v_1.wp();
      var tmp = System_getInstance();
      tmp.dm(InvalidatableViewPainter$lambda$lambda(this$0));
      return Unit_instance;
    };
  }
  function InvalidatableViewPainter(view) {
    this.r2v_1 = view;
    this.s2v_1 = null;
    this.t2v_1 = false;
    this.u2v_1 = System_getInstance().ul();
    this.v2v_1 = Point2D_init_$Create$(this.r2v_1.p1b(), this.r2v_1.r1b());
    var tmp = this;
    var tmp_0 = InvalidatableViewPainter$viewDimensionListener$lambda(this);
    tmp.w2v_1 = new sam$io_antarescircuit_jabbah_base_event_PropertyChangeListener$0_0(tmp_0);
    var tmp_1 = this;
    var tmp_2 = InvalidatableViewPainter$viewListener$lambda(this);
    tmp_1.x2v_1 = new sam$io_antarescircuit_jabbah_base_event_PropertyChangeListener$0_1(tmp_2);
    this.r2v_1.l1y(this.x2v_1);
    this.u2v_1.tp(25, false, InvalidatableViewPainter$lambda(this));
  }
  protoOf(InvalidatableViewPainter).es = function () {
    this.r2v_1.m1y(this.x2v_1);
    this.r2v_1.c23().f1b(this.w2v_1);
  };
  protoOf(InvalidatableViewPainter).a2w = function () {
    startTimerIfNeeded(this);
  };
  protoOf(InvalidatableViewPainter).b2w = function (context) {
    this.r2v_1.r1z(context);
  };
  protoOf(InvalidatableViewPainter).c2w = function (region) {
    if (region == null) {
      this.t2v_1 = true;
    } else {
      if (!this.t2v_1) {
        var tmp = this;
        var tmp0_safe_receiver = this.s2v_1;
        var tmp_0 = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.x1b(region);
        var tmp1_elvis_lhs = (tmp_0 == null ? true : tmp_0 instanceof Rectangle2D) ? tmp_0 : THROW_CCE();
        tmp.s2v_1 = tmp1_elvis_lhs == null ? Rectangle2D_init_$Create$(region) : tmp1_elvis_lhs;
      }
    }
  };
  function Companion_34() {
    this.d2w_1 = 200;
  }
  var Companion_instance_38;
  function Companion_getInstance_36() {
    return Companion_instance_38;
  }
  function MouseWheelModeController() {
    KeyAdapter.call(this);
    this.e2w_1 = 0n;
    this.f2w_1 = 0n;
    this.g2w_1 = false;
    this.h2w_1 = true;
    this.i2w_1 = null;
  }
  protoOf(MouseWheelModeController).bu = function () {
    this.g2w_1 = false;
    this.h2w_1 = true;
    this.f2w_1 = 0n;
    this.f2w_1 = 0n;
  };
  protoOf(MouseWheelModeController).j2w = function () {
    var now = System_getInstance().tl();
    var switchMode = this.h2w_1 && this.g2w_1 && subtract(now, this.e2w_1) > 200n || (!this.h2w_1 && !this.g2w_1 && subtract(now, this.f2w_1) > 200n);
    this.h2w_1 = this.h2w_1 && !switchMode || (!this.h2w_1 && switchMode);
    return this.h2w_1;
  };
  protoOf(MouseWheelModeController).k2w = function () {
    this.e2w_1 = System_getInstance().tl();
  };
  protoOf(MouseWheelModeController).l2w = function () {
    this.f2w_1 = System_getInstance().tl();
  };
  protoOf(MouseWheelModeController).x19 = function (e) {
    this.i2w_1 = e.i2();
    if (e.i2() === DrawModule_getInstance().z29_1) {
      this.g2w_1 = true;
    }
  };
  protoOf(MouseWheelModeController).y19 = function (e) {
    this.i2w_1 = null;
    if (e.i2() === DrawModule_getInstance().z29_1) {
      this.g2w_1 = false;
    }
  };
  function PanMethod$MiddleMouseButton() {
    PanMethod.call(this, 'MiddleMouseButton', 0, 'middleMouseButton');
    PanMethod_MiddleMouseButton_instance = this;
  }
  protoOf(PanMethod$MiddleMouseButton).kq = function () {
    return Translations_getInstance().zm('draw.panMethod.middleMouseButton.desc', []);
  };
  protoOf(PanMethod$MiddleMouseButton).p2w = function (event, pressedKeyCode) {
    return event.f1a();
  };
  var PanMethod_MiddleMouseButton_instance;
  function PanMethod$AltLeftMouseButton() {
    PanMethod.call(this, 'AltLeftMouseButton', 1, 'altLeftMouseButton');
    PanMethod_AltLeftMouseButton_instance = this;
  }
  protoOf(PanMethod$AltLeftMouseButton).kq = function () {
    return Translations_getInstance().zm('draw.panMethod.altLeftMouseButton.desc', []);
  };
  protoOf(PanMethod$AltLeftMouseButton).p2w = function (event, pressedKeyCode) {
    return event.e1a() && event.isAltDown;
  };
  var PanMethod_AltLeftMouseButton_instance;
  function PanMethod$SpaceLeftMouseButton() {
    PanMethod.call(this, 'SpaceLeftMouseButton', 2, 'spaceLeftMouseButton');
    PanMethod_SpaceLeftMouseButton_instance = this;
  }
  protoOf(PanMethod$SpaceLeftMouseButton).kq = function () {
    return Translations_getInstance().zm('draw.panMethod.spaceLeftMouseButton.desc', []);
  };
  protoOf(PanMethod$SpaceLeftMouseButton).p2w = function (event, pressedKeyCode) {
    return event.e1a() && pressedKeyCode === Companion_instance.g18_1;
  };
  var PanMethod_SpaceLeftMouseButton_instance;
  function Companion_35() {
    this.x2w_1 = 'draw.panMethod';
  }
  protoOf(Companion_35).r1e = function (customName) {
    var tmp0 = get_entries_1();
    var tmp$ret$0;
    $l$block: {
      // Inline function 'kotlin.collections.firstOrNull' call
      var _iterator__ex2g4s = tmp0.i();
      while (_iterator__ex2g4s.j()) {
        var element = _iterator__ex2g4s.k();
        if (element.e2p() === customName) {
          tmp$ret$0 = element;
          break $l$block;
        }
      }
      tmp$ret$0 = null;
    }
    var tmp0_elvis_lhs = tmp$ret$0;
    var tmp;
    if (tmp0_elvis_lhs == null) {
      throw IllegalArgumentException_init_$Create$("unknown PanMethod '" + customName + "'");
    } else {
      tmp = tmp0_elvis_lhs;
    }
    return tmp;
  };
  var Companion_instance_39;
  function Companion_getInstance_37() {
    return Companion_instance_39;
  }
  function values_3() {
    return [PanMethod_MiddleMouseButton_getInstance(), PanMethod_AltLeftMouseButton_getInstance(), PanMethod_SpaceLeftMouseButton_getInstance()];
  }
  function get_entries_1() {
    if ($ENTRIES_1 == null)
      $ENTRIES_1 = enumEntries(values_3());
    return $ENTRIES_1;
  }
  var PanMethod_entriesInitialized;
  function PanMethod_initEntries() {
    if (PanMethod_entriesInitialized)
      return Unit_instance;
    PanMethod_entriesInitialized = true;
    PanMethod_MiddleMouseButton_instance = new PanMethod$MiddleMouseButton();
    PanMethod_AltLeftMouseButton_instance = new PanMethod$AltLeftMouseButton();
    PanMethod_SpaceLeftMouseButton_instance = new PanMethod$SpaceLeftMouseButton();
  }
  var $ENTRIES_1;
  function PanMethod(name, ordinal, customName) {
    Enum.call(this, name, ordinal);
    this.d2p_1 = customName;
  }
  protoOf(PanMethod).e2p = function () {
    return this.d2p_1;
  };
  protoOf(PanMethod).q2w = function (event, pressedKeyCode, $super) {
    pressedKeyCode = pressedKeyCode === VOID ? null : pressedKeyCode;
    return $super === VOID ? this.p2w(event, pressedKeyCode) : $super.p2w.call(this, event, pressedKeyCode);
  };
  protoOf(PanMethod).toString = function () {
    var tmp;
    switch (this.l2_1) {
      case 0:
        tmp = Translations_getInstance().zm('draw.panMethod.middleMouseButton.name', []);
        break;
      case 1:
        tmp = Translations_getInstance().zm('draw.panMethod.altLeftMouseButton.name', []);
        break;
      case 2:
        tmp = Translations_getInstance().zm('draw.panMethod.spaceLeftMouseButton.name', []);
        break;
      default:
        noWhenBranchMatchedException();
        break;
    }
    return tmp;
  };
  function _get_panMethodFromProperties__kl0kfq($this) {
    return Companion_instance_39.r1e(BaseModule_getInstance().xo_1.ht('draw.panMethod'));
  }
  function CurrentPanMethod$lambda(this$0) {
    return function (it) {
      this$0.z2w_1 = _get_panMethodFromProperties__kl0kfq(this$0);
      return Unit_instance;
    };
  }
  function CurrentPanMethod() {
    CurrentPanMethod_instance = this;
    this.y2w_1 = BaseModule_getInstance().zo_1;
    this.z2w_1 = _get_panMethodFromProperties__kl0kfq(this);
    var tmp = getKClass(PreferencesChangedEvent);
    this.y2w_1.j17(tmp, CurrentPanMethod$lambda(this));
  }
  var CurrentPanMethod_instance;
  function CurrentPanMethod_getInstance() {
    if (CurrentPanMethod_instance == null)
      new CurrentPanMethod();
    return CurrentPanMethod_instance;
  }
  function PanMethod_MiddleMouseButton_getInstance() {
    PanMethod_initEntries();
    return PanMethod_MiddleMouseButton_instance;
  }
  function PanMethod_AltLeftMouseButton_getInstance() {
    PanMethod_initEntries();
    return PanMethod_AltLeftMouseButton_instance;
  }
  function PanMethod_SpaceLeftMouseButton_getInstance() {
    PanMethod_initEntries();
    return PanMethod_SpaceLeftMouseButton_instance;
  }
  function buildToolTipText(title, text, subText, endWithPeriod) {
    endWithPeriod = endWithPeriod === VOID ? false : endWithPeriod;
    var builder = StringBuilder_init_$Create$();
    var hasText = StringUtils_getInstance().ju(text);
    var hasSubText = StringUtils_getInstance().ju(subText);
    if (StringUtils_getInstance().ku(title)) {
      var titleText = ensureNotNull(title);
      if (hasText && !startsWith(ensureNotNull(text), _Char___init__impl__6a9atx(10))) {
        titleText = titleText + ':';
      }
      builder.h7(Companion_instance_2.s1j(titleText));
    }
    if (hasText) {
      builder.h7(' ').h7(ensureNotNull(text));
      if (endWithPeriod && !endsWith(text, '.')) {
        builder.i7(_Char___init__impl__6a9atx(46));
      }
    }
    if (hasSubText) {
      // Inline function 'kotlin.text.isNotEmpty' call
      if (charSequenceLength(builder) > 0) {
        // Inline function 'kotlin.text.appendLine' call
        // Inline function 'kotlin.text.appendLine' call
        builder.i7(_Char___init__impl__6a9atx(10)).i7(_Char___init__impl__6a9atx(10));
      }
      builder.h7(ensureNotNull(subText));
      if (endWithPeriod && !endsWith(subText, '.')) {
        builder.i7(_Char___init__impl__6a9atx(46));
      }
    }
    var tmp;
    // Inline function 'kotlin.text.isEmpty' call
    if (charSequenceLength(builder) === 0) {
      tmp = null;
    } else {
      tmp = builder.toString();
    }
    return tmp;
  }
  function _get_LOG__e5r759_8($this) {
    var tmp0 = $this.b2v_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('LOG', 1, tmp, TooltipManager$_get_LOG_$ref_lph8qm(), null);
    return tmp0.j2();
  }
  function _get_timer__axs3pw($this) {
    if ($this.l2v_1 == null) {
      initTimer($this);
    }
    return ensureNotNull($this.l2v_1);
  }
  function initTimer($this) {
    $this.l2v_1 = System_getInstance().ul();
    var tmp = _get_timer__axs3pw($this);
    var tmp_0 = BaseModule_getInstance().xo_1.it('draw.view.TooltipManager.delay');
    tmp.tp(tmp_0, false, TooltipManager$initTimer$lambda);
  }
  function handle($this, event) {
    if (event.a2x_1 == null || event.c2x_1 == null) {
      tooltipDismissed($this);
    } else {
      tooltipRequested($this, event);
    }
  }
  function tooltipRequested($this, event) {
    if (!($this.i2v_1 == null) || !($this.j2v_1 == null)) {
      disposeTooltip($this);
    }
    $this.k2v_1 = new TooltipRequest(ensureNotNull(event.a2x_1), event.b2x_1, event.c2x_1, event.d2x_1);
    _get_timer__axs3pw($this).vp();
  }
  function tooltipDismissed($this) {
    if (!($this.i2v_1 == null) || !($this.j2v_1 == null)) {
      _get_LOG__e5r759_8($this).ol('tooltipDismissed()');
      disposeTooltip($this);
    }
    if (_get_timer__axs3pw($this).xp()) {
      _get_timer__axs3pw($this).wp();
    }
  }
  function displayImpl($this) {
    _get_timer__axs3pw($this).wp();
    var tmp0_safe_receiver = $this.k2v_1;
    if (tmp0_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      disposeTooltip(TooltipManager_getInstance());
      if (!(tmp0_safe_receiver.g2x_1 == null)) {
        TooltipManager_getInstance().i2v_1 = new TooltipView(createTextArrowBubble(TooltipManager_getInstance(), tmp0_safe_receiver.g2x_1, tmp0_safe_receiver.f2x_1), tmp0_safe_receiver.f2x_1);
        tmp0_safe_receiver.f2x_1.l23().l20(ensureNotNull(TooltipManager_getInstance().i2v_1).i2x_1);
      }
      if (!(tmp0_safe_receiver.h2x_1 == null)) {
        TooltipManager_getInstance().j2v_1 = new TooltipView(createExplanationArrowBubble(TooltipManager_getInstance(), tmp0_safe_receiver.h2x_1, tmp0_safe_receiver.f2x_1), tmp0_safe_receiver.f2x_1);
        if (TooltipManager_getInstance().i2v_1 == null || !(ensureNotNull(TooltipManager_getInstance().i2v_1).i2x_1.l2d_1.o2d_1 === ensureNotNull(TooltipManager_getInstance().j2v_1).i2x_1.l2d_1.o2d_1)) {
          tmp0_safe_receiver.f2x_1.l23().l20(ensureNotNull(TooltipManager_getInstance().j2v_1).i2x_1);
        }
      }
      tmp0_safe_receiver.f2x_1.l23().u1z();
      var tmp = TooltipManager_getInstance();
      tmp.m2v_1 = tmp0_safe_receiver.f2x_1.o23(TooltipManager$displayImpl$lambda);
      TooltipManager_getInstance().k2v_1 = null;
    }
  }
  function disposeTooltip($this) {
    var tmp0_safe_receiver = $this.i2v_1;
    if (tmp0_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      tmp0_safe_receiver.j2x_1.l23().m20(tmp0_safe_receiver.i2x_1);
      tmp0_safe_receiver.j2x_1.l23().u1z();
      var tmp0_safe_receiver_0 = TooltipManager_getInstance().m2v_1;
      if (tmp0_safe_receiver_0 == null)
        null;
      else {
        // Inline function 'kotlin.let' call
        tmp0_safe_receiver.j2x_1.m1y(tmp0_safe_receiver_0);
      }
      TooltipManager_getInstance().i2v_1 = null;
    }
    var tmp1_safe_receiver = $this.j2v_1;
    if (tmp1_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      tmp1_safe_receiver.j2x_1.l23().m20(tmp1_safe_receiver.i2x_1);
      tmp1_safe_receiver.j2x_1.l23().u1z();
      var tmp0_safe_receiver_1 = TooltipManager_getInstance().m2v_1;
      if (tmp0_safe_receiver_1 == null)
        null;
      else {
        // Inline function 'kotlin.let' call
        tmp1_safe_receiver.j2x_1.m1y(tmp0_safe_receiver_1);
      }
      TooltipManager_getInstance().j2v_1 = null;
    }
    $this.i2v_1 = null;
    $this.j2v_1 = null;
  }
  function createTextArrowBubble($this, tooltip, view) {
    var font = $this.o2v_1.p1x(Companion_getInstance_33().o1x_1).l2c();
    var multilineText = Companion_getInstance_15().t2g(tooltip.vu_1, font, 300);
    return new ArrowBubble(multilineText, ArrowBubblePositioner_instance.u2d(multilineText, tooltip.wu_1, view, true), Companion_getInstance_33().o1x_1, $this.o2v_1);
  }
  function createExplanationArrowBubble($this, explanation, view) {
    return new ArrowBubble(explanation.a20_1, ArrowBubblePositioner_instance.u2d(explanation.a20_1, explanation.b20_1, view, false), Companion_getInstance_33().o1x_1, $this.o2v_1);
  }
  function TooltipManager$_get_LOG_$ref_lph8qm() {
    return function (p0) {
      return _get_LOG__e5r759_8(p0);
    };
  }
  function TooltipManager$tooltipEventHandler$lambda(it) {
    handle(TooltipManager_getInstance(), it);
    return Unit_instance;
  }
  function TooltipManager$preferencesChangeHandler$lambda(it) {
    initTimer(TooltipManager_getInstance());
    return Unit_instance;
  }
  function TooltipManager$initTimer$lambda(it) {
    displayImpl(TooltipManager_getInstance());
    return Unit_instance;
  }
  function TooltipManager$displayImpl$lambda(event) {
    var tmp0_safe_receiver = TooltipManager_getInstance().i2v_1;
    if (equals(event.source, tmp0_safe_receiver == null ? null : tmp0_safe_receiver.j2x_1)) {
      disposeTooltip(TooltipManager_getInstance());
    }
    return Unit_instance;
  }
  function TooltipManager() {
    TooltipManager_instance = this;
    this.b2v_1 = logger(getKClass(TooltipManager));
    this.c2v_1 = 'draw.view.TooltipManager.delay';
    this.d2v_1 = 300;
    this.e2v_1 = 50;
    this.f2v_1 = 10;
    var tmp = this;
    tmp.g2v_1 = TooltipManager$tooltipEventHandler$lambda;
    var tmp_0 = this;
    tmp_0.h2v_1 = TooltipManager$preferencesChangeHandler$lambda;
    this.i2v_1 = null;
    this.j2v_1 = null;
    this.k2v_1 = null;
    this.l2v_1 = null;
    this.m2v_1 = null;
    this.n2v_1 = BaseModule_getInstance().zo_1;
    this.o2v_1 = DrawStyleModule_getInstance().g1x_1;
    this.n2v_1.j17(getKClass(TooltipEvent), this.g2v_1);
    this.n2v_1.j17(getKClass(PreferencesChangedEvent), this.h2v_1);
  }
  protoOf(TooltipManager).p2v = function (value) {
    if (!equals(this.n2v_1, value)) {
      this.n2v_1.k17(getKClass(TooltipEvent), this.g2v_1);
      this.n2v_1.k17(getKClass(PreferencesChangedEvent), this.h2v_1);
      this.n2v_1 = value;
      this.n2v_1.j17(getKClass(TooltipEvent), this.g2v_1);
      this.n2v_1.j17(getKClass(PreferencesChangedEvent), this.h2v_1);
    }
  };
  var TooltipManager_instance;
  function TooltipManager_getInstance() {
    if (TooltipManager_instance == null)
      new TooltipManager();
    return TooltipManager_instance;
  }
  function TooltipEvent(origin, view, tooltip, explanation) {
    this.a2x_1 = origin;
    this.b2x_1 = view;
    this.c2x_1 = tooltip;
    this.d2x_1 = explanation;
  }
  protoOf(TooltipEvent).toString = function () {
    return 'TooltipEvent(origin=' + toString_0(this.a2x_1) + ', view=' + toString(this.b2x_1) + ', tooltip=' + toString_0(this.c2x_1) + ', explanation=' + toString_0(this.d2x_1) + ')';
  };
  protoOf(TooltipEvent).hashCode = function () {
    var result = this.a2x_1 == null ? 0 : hashCode(this.a2x_1);
    result = imul(result, 31) + hashCode(this.b2x_1) | 0;
    result = imul(result, 31) + (this.c2x_1 == null ? 0 : this.c2x_1.hashCode()) | 0;
    result = imul(result, 31) + (this.d2x_1 == null ? 0 : this.d2x_1.hashCode()) | 0;
    return result;
  };
  protoOf(TooltipEvent).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof TooltipEvent))
      return false;
    if (!equals(this.a2x_1, other.a2x_1))
      return false;
    if (!equals(this.b2x_1, other.b2x_1))
      return false;
    if (!equals(this.c2x_1, other.c2x_1))
      return false;
    if (!equals(this.d2x_1, other.d2x_1))
      return false;
    return true;
  };
  function TooltipView(arrowBubble, view) {
    this.i2x_1 = arrowBubble;
    this.j2x_1 = view;
  }
  protoOf(TooltipView).toString = function () {
    return 'TooltipView(arrowBubble=' + toString(this.i2x_1) + ', view=' + toString(this.j2x_1) + ')';
  };
  protoOf(TooltipView).hashCode = function () {
    var result = hashCode(this.i2x_1);
    result = imul(result, 31) + hashCode(this.j2x_1) | 0;
    return result;
  };
  protoOf(TooltipView).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof TooltipView))
      return false;
    if (!equals(this.i2x_1, other.i2x_1))
      return false;
    if (!equals(this.j2x_1, other.j2x_1))
      return false;
    return true;
  };
  function TooltipRequest(origin, view, tooltip, explanation) {
    this.e2x_1 = origin;
    this.f2x_1 = view;
    this.g2x_1 = tooltip;
    this.h2x_1 = explanation;
  }
  protoOf(TooltipRequest).toString = function () {
    return 'TooltipRequest(origin=' + toString(this.e2x_1) + ', view=' + toString(this.f2x_1) + ', tooltip=' + toString_0(this.g2x_1) + ', explanation=' + toString_0(this.h2x_1) + ')';
  };
  protoOf(TooltipRequest).hashCode = function () {
    var result = hashCode(this.e2x_1);
    result = imul(result, 31) + hashCode(this.f2x_1) | 0;
    result = imul(result, 31) + (this.g2x_1 == null ? 0 : this.g2x_1.hashCode()) | 0;
    result = imul(result, 31) + (this.h2x_1 == null ? 0 : this.h2x_1.hashCode()) | 0;
    return result;
  };
  protoOf(TooltipRequest).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof TooltipRequest))
      return false;
    if (!equals(this.e2x_1, other.e2x_1))
      return false;
    if (!equals(this.f2x_1, other.f2x_1))
      return false;
    if (!equals(this.g2x_1, other.g2x_1))
      return false;
    if (!equals(this.h2x_1, other.h2x_1))
      return false;
    return true;
  };
  function Companion_36() {
    this.k2x_1 = 'draw.view.tooltipsEnabled';
  }
  var Companion_instance_40;
  function Companion_getInstance_38() {
    return Companion_instance_40;
  }
  function getTooltip($this, drawable, context) {
    var tmp;
    if ($this.t2x_1) {
      tmp = $this.n2x_1(drawable, context);
    } else {
      tmp = null;
    }
    return tmp;
  }
  function getExplanation($this, drawable, x, y) {
    var tmp;
    if ($this.t2x_1 && $this.u2x_1) {
      tmp = $this.o2x_1(drawable, x, y);
    } else {
      tmp = null;
    }
    return tmp;
  }
  function clearLastTargets($this) {
    $this.p2x_1 = null;
    $this.q2x_1 = null;
    $this.r2x_1 = null;
    $this.s2x_1 = null;
  }
  function setLastTargets($this, drawable, tooltipText, explanation, sourceRect) {
    $this.p2x_1 = drawable;
    $this.q2x_1 = tooltipText;
    $this.r2x_1 = explanation;
    $this.s2x_1 = sourceRect;
  }
  function TooltipHandler$_init_$lambda_4n6k04(c, x, y) {
    return c.s20(x, y);
  }
  function TooltipHandler$_init_$lambda_4n6k04_0(d, context) {
    return d.y1z(context);
  }
  function TooltipHandler$_init_$lambda_4n6k04_1(d, x, y) {
    return d.z1z(x, y);
  }
  function TooltipHandler$popupMenuHandler$lambda(this$0) {
    return function (it) {
      this$0.w2x(it.s1y_1.f1o());
      return Unit_instance;
    };
  }
  function TooltipHandler(eventBus, drawableRetriever, tooltipAccessor, explanationAccessor) {
    var tmp;
    if (drawableRetriever === VOID) {
      tmp = TooltipHandler$_init_$lambda_4n6k04;
    } else {
      tmp = drawableRetriever;
    }
    drawableRetriever = tmp;
    var tmp_0;
    if (tooltipAccessor === VOID) {
      tmp_0 = TooltipHandler$_init_$lambda_4n6k04_0;
    } else {
      tmp_0 = tooltipAccessor;
    }
    tooltipAccessor = tmp_0;
    var tmp_1;
    if (explanationAccessor === VOID) {
      tmp_1 = TooltipHandler$_init_$lambda_4n6k04_1;
    } else {
      tmp_1 = explanationAccessor;
    }
    explanationAccessor = tmp_1;
    this.l2x_1 = eventBus;
    this.m2x_1 = drawableRetriever;
    this.n2x_1 = tooltipAccessor;
    this.o2x_1 = explanationAccessor;
    this.p2x_1 = null;
    this.q2x_1 = null;
    this.r2x_1 = null;
    this.s2x_1 = null;
    this.t2x_1 = BaseModule_getInstance().xo_1.ft('draw.view.tooltipsEnabled');
    this.u2x_1 = BaseModule_getInstance().xo_1.ft('base.beginnerHelpTooltip');
    var tmp_2 = this;
    tmp_2.v2x_1 = TooltipHandler$popupMenuHandler$lambda(this);
    this.l2x_1.j17(getKClass(PopupMenuEvent), this.v2x_1);
  }
  protoOf(TooltipHandler).x2x = function (view, container, context) {
    var drawable = this.m2x_1(container, context.a22_1, context.b22_1);
    if (drawable == null) {
      if (!(this.p2x_1 == null)) {
        this.l2x_1.eu(new TooltipEvent(null, view, null, null));
        clearLastTargets(this);
      }
      return Unit_instance;
    }
    var tooltip = getTooltip(this, drawable, context);
    var explanation = getExplanation(this, drawable, context.a22_1, context.b22_1);
    var tmp;
    var tmp_0 = StringUtils_getInstance();
    if (tmp_0.iu(tooltip == null ? null : tooltip.vu_1)) {
      tmp = explanation == null;
    } else {
      tmp = false;
    }
    if (tmp) {
      if (!(this.p2x_1 == null) || !(this.r2x_1 == null)) {
        clearLastTargets(this);
        this.l2x_1.eu(new TooltipEvent(null, view, null, null));
      }
      return Unit_instance;
    }
    var tmp_1;
    var tmp_2;
    var tmp_3;
    if (!(drawable === this.p2x_1)) {
      tmp_3 = true;
    } else {
      tmp_3 = !((tooltip == null ? null : tooltip.vu_1) == this.q2x_1);
    }
    if (tmp_3) {
      tmp_2 = true;
    } else {
      var tmp_4 = explanation == null ? null : explanation.a20_1;
      var tmp5_safe_receiver = this.r2x_1;
      tmp_2 = !(tmp_4 === (tmp5_safe_receiver == null ? null : tmp5_safe_receiver.a20_1));
    }
    if (tmp_2) {
      tmp_1 = true;
    } else {
      var tmp_5 = this.s2x_1;
      tmp_1 = !equals(tmp_5, tooltip == null ? null : tooltip.wu_1);
    }
    if (tmp_1) {
      var tmp_6 = tooltip == null ? null : tooltip.vu_1;
      setLastTargets(this, drawable, tmp_6, explanation, tooltip == null ? null : tooltip.wu_1);
      this.l2x_1.eu(new TooltipEvent(drawable, view, tooltip, explanation));
    }
  };
  protoOf(TooltipHandler).w2x = function (view) {
    this.l2x_1.eu(new TooltipEvent(null, view, null, null));
  };
  function calculateCombinedBoundingBox($this) {
    var bbox = new Rectangle2D();
    // Inline function 'kotlin.collections.filter' call
    var tmp0 = $this.c2y_1;
    // Inline function 'kotlin.collections.filterTo' call
    var destination = ArrayList_init_$Create$();
    var _iterator__ex2g4s = tmp0.i();
    while (_iterator__ex2g4s.j()) {
      var element = _iterator__ex2g4s.k();
      if (element.n1z()) {
        destination.h(element);
      }
    }
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s_0 = destination.i();
    while (_iterator__ex2g4s_0.j()) {
      var element_0 = _iterator__ex2g4s_0.k();
      bbox.x1b(element_0.do());
    }
    return bbox;
  }
  function ChildListener($outer) {
    this.z2y_1 = $outer;
  }
  protoOf(ChildListener).m21 = function (event) {
    this.z2y_1.p2y_1.c2w(event.l21_1);
  };
  protoOf(ChildListener).n21 = function (event) {
    this.z2y_1.p2y_1.a2w();
  };
  protoOf(ChildListener).o21 = function (event) {
  };
  function OverlayListener($outer) {
    this.a2z_1 = $outer;
  }
  protoOf(OverlayListener).m21 = function (event) {
    this.a2z_1.p2y_1.c2w(null);
  };
  protoOf(OverlayListener).n21 = function (event) {
    this.a2z_1.p2y_1.a2w();
  };
  protoOf(OverlayListener).o21 = function (event) {
  };
  function PropertyChangeHandler($outer) {
    this.b2z_1 = $outer;
  }
  protoOf(PropertyChangeHandler).propertyChanged = function (e) {
    switch (e.name) {
      case 'PROP_DIMENSION':
        this.b2z_1.e23().g2z(this.b2z_1.c23().c1x());
        this.b2z_1.j2y_1 = (this.b2z_1.e23().e2z_1.g1e_1 > 0 && this.b2z_1.e23().e2z_1.h1e_1 > 0);
        this.b2z_1.h2z();
        break;
      case 'PROP_DEVICE_PIXEL_RATIO':
        this.b2z_1.h2z();
        break;
      case 'ViewSpace.area':
        this.b2z_1.h2z();
        break;
      case 'PROP_APPLICATION_CONTEXT':
        this.b2z_1.i2z();
        this.b2z_1.d1x();
        break;
      case 'ViewContentBounds.total':
        this.b2z_1.h2z();
        break;
    }
  };
  function EventHandler($outer) {
    this.l2z_1 = $outer;
    InputEventHandlerAdapter.call(this);
    this.k2z_1 = null;
  }
  protoOf(EventHandler).j22 = function (context) {
    var destination = null;
    var tmp0 = this.l2z_1.c2y_1;
    $l$block: {
      // Inline function 'kotlin.collections.firstOrNull' call
      var _iterator__ex2g4s = tmp0.i();
      while (_iterator__ex2g4s.j()) {
        var element = _iterator__ex2g4s.k();
        destination = element.o1z(context).j22(context);
        if (!(destination == null)) {
          break $l$block;
        }
      }
    }
    return destination;
  };
  protoOf(EventHandler).i22 = function (context) {
    var destination = null;
    var tmp0 = this.l2z_1.c2y_1;
    $l$block: {
      // Inline function 'kotlin.collections.firstOrNull' call
      var _iterator__ex2g4s = tmp0.i();
      while (_iterator__ex2g4s.j()) {
        var element = _iterator__ex2g4s.k();
        destination = element.o1z(context).i22(context);
        if (!(destination == null)) {
          break $l$block;
        }
      }
    }
    this.k2z_1 = destination;
    return destination;
  };
  protoOf(EventHandler).k22 = function (context) {
    var destination = null;
    var tmp0 = this.l2z_1.c2y_1;
    $l$block: {
      // Inline function 'kotlin.collections.firstOrNull' call
      var _iterator__ex2g4s = tmp0.i();
      while (_iterator__ex2g4s.j()) {
        var element = _iterator__ex2g4s.k();
        destination = element.o1z(context).k22(context);
        if (!(destination == null)) {
          break $l$block;
        }
      }
    }
    this.k2z_1 = destination;
    return destination;
  };
  protoOf(EventHandler).l22 = function (context) {
    var tmp0_safe_receiver = this.k2z_1;
    return tmp0_safe_receiver == null ? null : tmp0_safe_receiver.l22(context);
  };
  protoOf(EventHandler).m22 = function (context) {
    var tmp0_safe_receiver = this.k2z_1;
    return tmp0_safe_receiver == null ? null : tmp0_safe_receiver.m22(context);
  };
  protoOf(EventHandler).n22 = function (context) {
    var tmp = this;
    var tmp0_safe_receiver = this.k2z_1;
    tmp.k2z_1 = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.n22(context);
    return this.k2z_1;
  };
  protoOf(EventHandler).o22 = function (context) {
    var tmp = this;
    var tmp0_safe_receiver = this.k2z_1;
    tmp.k2z_1 = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.o22(context);
    return this.k2z_1;
  };
  function ViewImpl$_init_$lambda_aablwm(it) {
    return new InvalidatableViewPainter(it);
  }
  function ViewImpl$themeListener$lambda(this$0) {
    return function (it) {
      this$0.i2z();
      this$0.d1x();
      return Unit_instance;
    };
  }
  function ViewImpl$calculateCombinedBoundingBox$ref(p0) {
    var l = function () {
      var tmp0 = p0;
      return calculateCombinedBoundingBox(tmp0);
    };
    l.callableName = 'calculateCombinedBoundingBox';
    return l;
  }
  function ViewImpl(affineTransformFactory, applicationContextHolder, eventBus, name, viewPainterFactory) {
    eventBus = eventBus === VOID ? BaseModule_getInstance().zo_1 : eventBus;
    name = name === VOID ? '' : name;
    var tmp;
    if (viewPainterFactory === VOID) {
      tmp = ViewImpl$_init_$lambda_aablwm;
    } else {
      tmp = viewPainterFactory;
    }
    viewPainterFactory = tmp;
    this.y2x_1 = affineTransformFactory;
    this.z2x_1 = eventBus;
    this.a2y_1 = name;
    this.b2y_1 = new ZoomPanController(this);
    var tmp_0 = this;
    // Inline function 'kotlin.collections.mutableListOf' call
    tmp_0.c2y_1 = ArrayList_init_$Create$();
    this.d2y_1 = new PropertyChangeSupport(this);
    var tmp_1 = this;
    tmp_1.e2y_1 = ViewImpl$themeListener$lambda(this);
    this.f2y_1 = new PropertyChangeHandler(this);
    this.g2y_1 = new ViewSpace(Dimension2D_init_$Create$(0, 0));
    this.h2y_1 = this.m2z();
    this.i2y_1 = null;
    this.j2y_1 = false;
    this.z2x_1.j17(getKClass(ThemeEvent), this.e2y_1);
    if (applicationContextHolder == null)
      null;
    else {
      applicationContextHolder.l1y(this.f2y_1);
    }
    this.h23().l25(this.f2y_1);
    this.e23().n2z(this.f2y_1);
    this.k2y_1 = applicationContextHolder;
    this.l2y_1 = new EventHandler(this);
    this.m2y_1 = null;
    this.n2y_1 = new DrawableContainerImpl(VOID, VOID, VOID, true);
    this.o2y_1 = new ViewDecorator(this);
    this.p2y_1 = viewPainterFactory(this);
    this.q2y_1 = new Rectangle2D();
    this.r2y_1 = new ChildListener(this);
    this.s2y_1 = new OverlayListener(this);
    this.t2y_1 = true;
    this.u2y_1 = new ViewNavigatorImpl(this, this.y2x_1);
    this.v2y_1 = new ZoomStrategy(ZoomStrategyType_FIT_MAX_NORMAL_getInstance());
    this.w2y_1 = this.z23();
    this.x2y_1 = Companion_instance_8.w24();
    this.y2y_1 = true;
    this.n2y_1.p1z(this.s2y_1);
  }
  protoOf(ViewImpl).e23 = function () {
    return this.g2y_1;
  };
  protoOf(ViewImpl).h23 = function () {
    return this.h2y_1;
  };
  protoOf(ViewImpl).d23 = function () {
    return !(this.i2y_1 == null);
  };
  protoOf(ViewImpl).q1x = function (value) {
    if (!(this.i2y_1 == null)) {
      ensureNotNull(this.i2y_1).f1b(this.f2y_1);
    }
    this.i2y_1 = value;
    this.c23().e1b(this.f2y_1);
    this.e23().g2z(this.c23().c1x());
    this.e23().o2z(this.f2y_1);
    this.j2y_1 = this.c23().s1x();
    this.p2z('PROP_CANVAS', null, this.i2y_1);
  };
  protoOf(ViewImpl).c23 = function () {
    return ensureNotNull(this.i2y_1);
  };
  protoOf(ViewImpl).f1o = function () {
    return this;
  };
  protoOf(ViewImpl).ro = function () {
    this.f24();
    this.b2y_1.nq(true);
  };
  protoOf(ViewImpl).es = function () {
    this.z2x_1.k17(getKClass(ThemeEvent), this.e2y_1);
    var tmp0_safe_receiver = this.i2y_1;
    if (tmp0_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      tmp0_safe_receiver.f1b(this.f2y_1);
      this.p2y_1.es();
    }
    this.e23().n2z(this.f2y_1);
    this.h23().m25(this.f2y_1);
    this.b2y_1.es();
  };
  protoOf(ViewImpl).f23 = function () {
    return this.k2y_1;
  };
  protoOf(ViewImpl).g23 = function () {
    var tmp0_safe_receiver = this.f23();
    return tmp0_safe_receiver == null ? null : tmp0_safe_receiver.q1y_1;
  };
  protoOf(ViewImpl).g24 = function () {
    return this.c2y_1.o();
  };
  protoOf(ViewImpl).a30 = function (drawable) {
    return this.h24(drawable, this.g24());
  };
  protoOf(ViewImpl).h24 = function (drawable, index) {
    // Inline function 'kotlin.check' call
    if (!!this.c2y_1.n(drawable)) {
      var message = 'drawable already contained';
      throw IllegalStateException_init_$Create$(toString(message));
    }
    if (isInterface(drawable, Unzoomable)) {
      drawable.y2a(this.r23());
    }
    this.c2y_1.t3(index, drawable);
    drawable.p1z(this.r2y_1);
    drawable.s1z();
    drawable.u1z();
  };
  protoOf(ViewImpl).b30 = function (drawable) {
    drawable.s1z();
    this.c2y_1.h2(drawable);
    drawable.u1z();
    drawable.q1z(this.r2y_1);
  };
  protoOf(ViewImpl).i24 = function (drawable) {
    return this.c2y_1.n(drawable);
  };
  protoOf(ViewImpl).j24 = function (oldDrawable, newDrawable) {
    oldDrawable.s1z();
    oldDrawable.q1z(this.r2y_1);
    this.c2y_1.u2(this.c2y_1.p(oldDrawable), newDrawable);
    newDrawable.p1z(this.r2y_1);
  };
  protoOf(ViewImpl).k24 = function (x, y, condition) {
    var _iterator__ex2g4s = this.c2y_1.i();
    while (_iterator__ex2g4s.j()) {
      var drawable = _iterator__ex2g4s.k();
      if (isInterface(drawable, DrawableContainer)) {
        var innerDrawable = drawable.s20(x, y);
        if (!(innerDrawable == null) && condition(innerDrawable)) {
          return innerDrawable;
        }
      }
    }
    return null;
  };
  protoOf(ViewImpl).p1b = function () {
    var tmp0_safe_receiver = this.i2y_1;
    var tmp1_safe_receiver = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.c1x();
    var tmp2_safe_receiver = tmp1_safe_receiver == null ? null : tmp1_safe_receiver.e1e_1;
    var tmp3_elvis_lhs = tmp2_safe_receiver == null ? null : numberToInt(tmp2_safe_receiver);
    return tmp3_elvis_lhs == null ? 0 : tmp3_elvis_lhs;
  };
  protoOf(ViewImpl).r1b = function () {
    var tmp0_safe_receiver = this.i2y_1;
    var tmp1_safe_receiver = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.c1x();
    var tmp2_safe_receiver = tmp1_safe_receiver == null ? null : tmp1_safe_receiver.f1e_1;
    var tmp3_elvis_lhs = tmp2_safe_receiver == null ? null : numberToInt(tmp2_safe_receiver);
    return tmp3_elvis_lhs == null ? 0 : tmp3_elvis_lhs;
  };
  protoOf(ViewImpl).m2z = function () {
    return new ViewContentBounds(VOID, ViewImpl$calculateCombinedBoundingBox$ref(this));
  };
  protoOf(ViewImpl).j1y = function (e) {
    var tmp0_safe_receiver = this.i2y_1;
    if (tmp0_safe_receiver == null)
      null;
    else {
      tmp0_safe_receiver.j1y(e);
    }
  };
  protoOf(ViewImpl).n23 = function (e) {
    return this.l2y_1;
  };
  protoOf(ViewImpl).b1y = function (l) {
    var tmp0_safe_receiver = this.i2y_1;
    if (tmp0_safe_receiver == null)
      null;
    else {
      tmp0_safe_receiver.b1y(l);
    }
  };
  protoOf(ViewImpl).c1y = function (l) {
    var tmp0_safe_receiver = this.i2y_1;
    if (tmp0_safe_receiver == null)
      null;
    else {
      tmp0_safe_receiver.c1y(l);
    }
  };
  protoOf(ViewImpl).d1y = function (l) {
    var tmp0_safe_receiver = this.i2y_1;
    if (tmp0_safe_receiver == null)
      null;
    else {
      tmp0_safe_receiver.d1y(l);
    }
  };
  protoOf(ViewImpl).e1y = function (l) {
    var tmp0_safe_receiver = this.i2y_1;
    if (tmp0_safe_receiver == null)
      null;
    else {
      tmp0_safe_receiver.e1y(l);
    }
  };
  protoOf(ViewImpl).f1y = function (l) {
    var tmp0_safe_receiver = this.i2y_1;
    if (tmp0_safe_receiver == null)
      null;
    else {
      tmp0_safe_receiver.f1y(l);
    }
  };
  protoOf(ViewImpl).g1y = function (l) {
    var tmp0_safe_receiver = this.i2y_1;
    if (tmp0_safe_receiver == null)
      null;
    else {
      tmp0_safe_receiver.g1y(l);
    }
  };
  protoOf(ViewImpl).h1y = function (l) {
    var tmp0_safe_receiver = this.i2y_1;
    if (tmp0_safe_receiver == null)
      null;
    else {
      tmp0_safe_receiver.h1y(l);
    }
  };
  protoOf(ViewImpl).i1y = function (l) {
    var tmp0_safe_receiver = this.i2y_1;
    if (tmp0_safe_receiver == null)
      null;
    else {
      tmp0_safe_receiver.i1y(l);
    }
  };
  protoOf(ViewImpl).l1y = function (l) {
    this.d2y_1.xr(l);
  };
  protoOf(ViewImpl).o23 = function (l) {
    return this.d2y_1.h1b(l);
  };
  protoOf(ViewImpl).m1y = function (l) {
    this.d2y_1.yr(l);
  };
  protoOf(ViewImpl).p2z = function (name, oldValue, newValue) {
    this.d2y_1.lr(name, oldValue, newValue);
  };
  protoOf(ViewImpl).i23 = function (value) {
    if (!equals(this.m2y_1, value)) {
      this.i2z();
      this.m2y_1 = value;
      this.d1x();
    }
  };
  protoOf(ViewImpl).j23 = function () {
    return this.m2y_1;
  };
  protoOf(ViewImpl).l23 = function () {
    return this.n2y_1;
  };
  protoOf(ViewImpl).m23 = function () {
    return this.o2y_1;
  };
  protoOf(ViewImpl).k23 = function () {
    return this.t2y_1;
  };
  protoOf(ViewImpl).v1x = function (cursor) {
    this.c23().v1x(cursor);
  };
  protoOf(ViewImpl).e1x = function (g) {
    var tmp;
    if (g.g1t()) {
      g.w1u(this.q2y_1);
      this.q2y_1.e1h_1 = this.l24(this.q2y_1.e1h_1);
      this.q2y_1.f1h_1 = this.m24(this.q2y_1.f1h_1);
      this.q2y_1.g1h_1 = this.p24(this.q2y_1.g1h_1);
      this.q2y_1.h1h_1 = this.p24(this.q2y_1.h1h_1);
      tmp = this.q2y_1;
    } else {
      tmp = null;
    }
    var modelClip = tmp;
    this.p2y_1.b2w(DrawModule_getInstance().y29_1(g, modelClip, this.g23()));
  };
  protoOf(ViewImpl).r1z = function (context) {
    if (!this.j2y_1) {
      return Unit_instance;
    }
    context.t1y_1.x1t();
    var oldTransform = context.t1y_1.l1s();
    var zoomedTransform = context.t1y_1.l1s();
    zoomedTransform.a1d(this.q23().y24_1);
    context.t1y_1.h1t(this.k23());
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = asReversed(this.c2y_1).i();
    while (_iterator__ex2g4s.j()) {
      var element = _iterator__ex2g4s.k();
      if (isInterface(element, Unzoomable)) {
        context.t1y_1.k1t(oldTransform);
        // Inline function 'kotlin.also' call
        var this_0 = this.c23().b1x();
        context.t1y_1.x1c(this_0, this_0);
        element.r1z(context);
        context.t1y_1.x1c(1 / this_0, 1 / this_0);
      } else {
        context.t1y_1.k1t(zoomedTransform);
        element.r1z(context);
      }
    }
    if (!(this.j23() == null)) {
      context.t1y_1.l1t(ensureNotNull(this.j23()));
      context.t1y_1.j1u(0.0, 0.0, this.c23().c1x().e1e_1, this.c23().c1x().f1e_1);
    }
    if (DrawModule_getInstance().q29_1) {
      context.t1y_1.l1t(DrawModule_getInstance().t29_1);
      var originView = this.q24(Companion_getInstance().g1a_1);
      context.t1y_1.d1u(originView.in_1, 0.0, originView.in_1, this.r1b());
      context.t1y_1.d1u(0.0, originView.jn_1, this.p1b(), originView.jn_1);
    }
    context.t1y_1.k1t(oldTransform);
    // Inline function 'kotlin.also' call
    var this_1 = this.c23().b1x();
    context.t1y_1.x1c(this_1, this_1);
    this.n2y_1.r1z(context);
    context.t1y_1.x1c(1 / this_1, 1 / this_1);
    context.t1y_1.y1t();
  };
  protoOf(ViewImpl).d1x = function () {
    var tmp0_safe_receiver = this.i2y_1;
    if (tmp0_safe_receiver == null)
      null;
    else {
      tmp0_safe_receiver.d1x();
    }
  };
  protoOf(ViewImpl).w1x = function (x, y, w, h) {
    var tmp0_safe_receiver = this.i2y_1;
    if (tmp0_safe_receiver == null)
      null;
    else {
      tmp0_safe_receiver.w1x(x, y, w, h);
    }
  };
  protoOf(ViewImpl).c30 = function (region) {
    if (this.i2y_1 == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      this.p2y_1.c2w(region);
    }
  };
  protoOf(ViewImpl).i2z = function (region, $super) {
    region = region === VOID ? null : region;
    var tmp;
    if ($super === VOID) {
      this.c30(region);
      tmp = Unit_instance;
    } else {
      tmp = $super.c30.call(this, region);
    }
    return tmp;
  };
  protoOf(ViewImpl).x23 = function () {
    return this.u2y_1;
  };
  protoOf(ViewImpl).y23 = function (_set____db54di) {
    this.v2y_1 = _set____db54di;
  };
  protoOf(ViewImpl).z23 = function () {
    return this.v2y_1;
  };
  protoOf(ViewImpl).a24 = function (value) {
    if (!this.w2y_1.equals(value)) {
      var oldValue = this.w2y_1;
      this.w2y_1 = value;
      this.p2z('draw.view.zoomStrategy', oldValue, this.w2y_1);
    }
    this.w2y_1.c27(this.x23());
  };
  protoOf(ViewImpl).b24 = function () {
    return this.w2y_1;
  };
  protoOf(ViewImpl).p23 = function (value) {
    var oldValue = this.x2y_1;
    this.x2y_1 = value;
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = this.c2y_1.i();
    while (_iterator__ex2g4s.j()) {
      var element = _iterator__ex2g4s.k();
      if (isInterface(element, Unzoomable)) {
        element.y2a(this.r23());
      }
    }
    this.i2z();
    this.d1x();
    this.p2z('PROP_TRANSFORMATION', oldValue, this.x2y_1);
  };
  protoOf(ViewImpl).q23 = function () {
    return this.x2y_1;
  };
  protoOf(ViewImpl).r23 = function () {
    return this.q23().x24_1;
  };
  protoOf(ViewImpl).c24 = function (value) {
    if (!(this.y2y_1 === value)) {
      this.y2y_1 = value;
      this.p2z('PROP_USER_ZOOM_ENABLED', !this.y2y_1, this.y2y_1);
    }
  };
  protoOf(ViewImpl).d24 = function () {
    return this.y2y_1;
  };
  protoOf(ViewImpl).e24 = function (value) {
    this.b2y_1.e24(value);
  };
  protoOf(ViewImpl).f24 = function () {
    this.a24(this.z23());
    this.h2z();
  };
  protoOf(ViewImpl).h2z = function () {
    this.b24().c27(this.x23());
  };
  protoOf(ViewImpl).l24 = function (x) {
    return this.q23().y24_1.z1c(new Point2D(x, 0.0)).in_1;
  };
  protoOf(ViewImpl).m24 = function (y) {
    return this.q23().y24_1.z1c(new Point2D(0.0, y)).jn_1;
  };
  protoOf(ViewImpl).n24 = function (p) {
    return this.q23().y24_1.z1c(p);
  };
  protoOf(ViewImpl).o24 = function (p, zoomFactor) {
    var tmp;
    if (zoomFactor === this.s23()) {
      tmp = this.n24(p);
    } else {
      tmp = this.x23().i26(zoomFactor).y24_1.z1c(p);
    }
    return tmp;
  };
  protoOf(ViewImpl).p24 = function (length) {
    return length / this.s23();
  };
  protoOf(ViewImpl).q24 = function (p) {
    return this.q23().y24_1.ln(p);
  };
  protoOf(ViewImpl).s24 = function (x) {
    return this.q24(new Point2D(x, 0.0)).in_1;
  };
  protoOf(ViewImpl).t24 = function (y) {
    return this.q24(new Point2D(0.0, y)).jn_1;
  };
  protoOf(ViewImpl).r24 = function (p, zoomFactor) {
    var tmp;
    if (zoomFactor === this.s23()) {
      tmp = this.q24(p);
    } else {
      tmp = this.x23().i26(zoomFactor).y24_1.ln(p);
    }
    return tmp;
  };
  protoOf(ViewImpl).u24 = function (length) {
    return length * this.s23();
  };
  protoOf(ViewImpl).v24 = function (p) {
    return this.q24(p).i1f(1 / this.c23().b1x());
  };
  function ViewNavigatorImpl$Companion$_get_LOG_$ref_gshcq6() {
    return function (p0) {
      return p0.y1p();
    };
  }
  function Companion_37() {
    Companion_instance_41 = this;
    this.d30_1 = logger(getKClass(ViewNavigatorImpl));
    this.e30_1 = 20;
  }
  protoOf(Companion_37).y1p = function () {
    var tmp0 = this.d30_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('LOG', 1, tmp, ViewNavigatorImpl$Companion$_get_LOG_$ref_gshcq6(), null);
    return tmp0.j2();
  };
  var Companion_instance_41;
  function Companion_getInstance_39() {
    if (Companion_instance_41 == null)
      new Companion_37();
    return Companion_instance_41;
  }
  function _get_defaultZoomFactor__r0sdji($this) {
    return $this.h30_1.jt('draw.view.defaultZoomFactor');
  }
  function _get_minZoomFactor__ocim3h($this) {
    return BaseModule_getInstance().xo_1.jt('draw.view.minZoomFactor');
  }
  function _get_maxZoomFactor__dhemff($this) {
    return BaseModule_getInstance().xo_1.jt('draw.view.maxZoomFactor');
  }
  function _get_effDefaultZoomFactor__j7gypf($this) {
    return _get_defaultZoomFactor__r0sdji($this) * $this.f30_1.c23().b1x();
  }
  function createTransformation($this, zoomPan) {
    // Inline function 'kotlin.apply' call
    var this_0 = $this.g30_1();
    this_0.x1c(zoomPan.u23_1, zoomPan.u23_1);
    this_0.w1c(zoomPan.v23_1.m1g());
    return new ViewTransformation(zoomPan, this_0);
  }
  function setZoomPan($this, zoomPan) {
    $this.f30_1.p23(createTransformation($this, zoomPan));
  }
  function calculateContentCenterPan($this, zoomFactor, fixMaxNormal) {
    fixMaxNormal = fixMaxNormal === VOID ? false : fixMaxNormal;
    var bounds = $this.f30_1.h23();
    var newCenter = $this.f30_1.r24(new Point2D(bounds.g25().h1c(), bounds.g25().i1c()), zoomFactor);
    if (fixMaxNormal) {
      var overlapY = $this.f30_1.e23().f2z_1.k1c() + 20 - $this.f30_1.r24(new Point2D(0.0, bounds.g25().k1c()), zoomFactor).jn_1;
      if (overlapY > 0) {
        newCenter = newCenter.t1g(new Point2D(0.0, overlapY));
      }
    }
    var result = new Point2D($this.f30_1.r23().v23_1.in_1 + (newCenter.in_1 - $this.f30_1.e23().e2z_1.e1e_1 / 2.0) / zoomFactor, $this.f30_1.r23().v23_1.jn_1 + (newCenter.jn_1 - $this.f30_1.e23().e2z_1.f1e_1 / 2.0) / zoomFactor);
    Companion_getInstance_39().y1p().ol('center Pan for content ' + toString(bounds) + ' in view ' + $this.f30_1.c23().c1x().toString() + ' is ' + result.toString());
    return result;
  }
  function calculateFitZoomFactor($this) {
    var bounds = $this.f30_1.h23().h25();
    if (bounds.p1b() === 0.0 || bounds.r1b() === 0.0) {
      return _get_effDefaultZoomFactor__j7gypf($this);
    }
    if ($this.f30_1.e23().f2z_1.e1c() === 0 || $this.f30_1.e23().f2z_1.f1c() === 0) {
      return _get_effDefaultZoomFactor__j7gypf($this);
    }
    var tmp0 = ($this.f30_1.e23().f2z_1.e1c() - 40 | 0) / bounds.p1b();
    // Inline function 'kotlin.math.min' call
    var b = ($this.f30_1.e23().f2z_1.f1c() - 40 | 0) / bounds.r1b();
    return Math.min(tmp0, b);
  }
  function View$_get_devicePixelRatio_$ref_aprbr2(p0) {
    return function () {
      return p0.b1x();
    };
  }
  function View$_get_devicePixelRatio_$ref_aprbr2_0(p0) {
    return function () {
      return p0.b1x();
    };
  }
  function View$_get_devicePixelRatio_$ref_aprbr2_1(p0) {
    return function () {
      return p0.b1x();
    };
  }
  function View$_get_devicePixelRatio_$ref_aprbr2_2(p0) {
    return function () {
      return p0.b1x();
    };
  }
  function View$_get_devicePixelRatio_$ref_aprbr2_3(p0) {
    return function () {
      return p0.b1x();
    };
  }
  function View$_get_devicePixelRatio_$ref_aprbr2_4(p0) {
    return function () {
      return p0.b1x();
    };
  }
  function View$_get_devicePixelRatio_$ref_aprbr2_5(p0) {
    return function () {
      return p0.b1x();
    };
  }
  function ViewNavigatorImpl(view, affineTransformFactory, properties) {
    Companion_getInstance_39();
    properties = properties === VOID ? BaseModule_getInstance().xo_1 : properties;
    this.f30_1 = view;
    this.g30_1 = affineTransformFactory;
    this.h30_1 = properties;
  }
  protoOf(ViewNavigatorImpl).i26 = function (zoomFactor) {
    var tmp = this.f30_1.r23().v23_1;
    var tmp_0 = KProperty0;
    return createTransformation(this, new ZoomPan(this.f30_1, zoomFactor, tmp, getPropertyCallableRef('devicePixelRatio', 0, tmp_0, View$_get_devicePixelRatio_$ref_aprbr2(this.f30_1), null)));
  };
  protoOf(ViewNavigatorImpl).i30 = function (zoomFactor, zoomLocation) {
    var effZoomLocation = zoomLocation == null ? this.f30_1.n1c() : zoomLocation;
    if (!this.t26(zoomFactor)) {
      return Unit_instance;
    }
    var zoomLocationBeforeM = this.f30_1.n24(effZoomLocation);
    var zoomLocationAfterM = this.f30_1.o24(effZoomLocation, zoomFactor);
    var offset = zoomLocationBeforeM.t1g(zoomLocationAfterM);
    var tmp = this.f30_1.r23().v23_1.co(offset);
    var tmp_0 = KProperty0;
    var zoomPan = new ZoomPan(this.f30_1, zoomFactor, tmp, getPropertyCallableRef('devicePixelRatio', 0, tmp_0, View$_get_devicePixelRatio_$ref_aprbr2_0(this.f30_1), null));
    this.f30_1.p23(createTransformation(this, zoomPan));
  };
  protoOf(ViewNavigatorImpl).j26 = function (translation) {
    var locationAfterZoomV = translation.j30_1.i1f(translation.l30_1);
    var offsetV = translation.k30_1.t1g(locationAfterZoomV);
    var offsetM = offsetV.i1f(1 / translation.l30_1).m1g();
    var tmp = KProperty0;
    var zoomPan = new ZoomPan(this.f30_1, translation.l30_1, offsetM, getPropertyCallableRef('devicePixelRatio', 0, tmp, View$_get_devicePixelRatio_$ref_aprbr2_1(this.f30_1), null));
    this.f30_1.p23(createTransformation(this, zoomPan));
  };
  protoOf(ViewNavigatorImpl).k26 = function (factor, zoomLocation) {
    var zoomFactor = this.f30_1.s23() * factor;
    if (this.t26(zoomFactor)) {
      this.i30(zoomFactor, zoomLocation);
    }
  };
  protoOf(ViewNavigatorImpl).m26 = function (dx, dy) {
    var tmp = this.f30_1.s23();
    var tmp_0 = new Point2D(this.f30_1.r23().v23_1.in_1 - dx / this.f30_1.s23(), this.f30_1.r23().v23_1.jn_1 - dy / this.f30_1.s23());
    var tmp_1 = KProperty0;
    setZoomPan(this, new ZoomPan(this.f30_1, tmp, tmp_0, getPropertyCallableRef('devicePixelRatio', 0, tmp_1, View$_get_devicePixelRatio_$ref_aprbr2_2(this.f30_1), null)));
  };
  protoOf(ViewNavigatorImpl).n26 = function () {
    this.p26(this.f30_1.s23());
  };
  protoOf(ViewNavigatorImpl).o26 = function () {
    this.p26(_get_effDefaultZoomFactor__j7gypf(this));
  };
  protoOf(ViewNavigatorImpl).p26 = function (zoomFactor) {
    if (this.t26(zoomFactor)) {
      var tmp = calculateContentCenterPan(this, zoomFactor);
      var tmp_0 = KProperty0;
      setZoomPan(this, new ZoomPan(this.f30_1, zoomFactor, tmp, getPropertyCallableRef('devicePixelRatio', 0, tmp_0, View$_get_devicePixelRatio_$ref_aprbr2_3(this.f30_1), null)));
    }
  };
  protoOf(ViewNavigatorImpl).q26 = function () {
    var zoomFactor = calculateFitZoomFactor(this);
    if (this.t26(zoomFactor)) {
      var tmp = calculateContentCenterPan(this, zoomFactor);
      var tmp_0 = KProperty0;
      setZoomPan(this, new ZoomPan(this.f30_1, zoomFactor, tmp, getPropertyCallableRef('devicePixelRatio', 0, tmp_0, View$_get_devicePixelRatio_$ref_aprbr2_4(this.f30_1), null)));
    }
  };
  protoOf(ViewNavigatorImpl).r26 = function () {
    var zoomFactor = this.s26();
    if (this.t26(zoomFactor)) {
      var tmp = calculateContentCenterPan(this, zoomFactor, true);
      var tmp_0 = KProperty0;
      setZoomPan(this, new ZoomPan(this.f30_1, zoomFactor, tmp, getPropertyCallableRef('devicePixelRatio', 0, tmp_0, View$_get_devicePixelRatio_$ref_aprbr2_5(this.f30_1), null)));
    }
  };
  protoOf(ViewNavigatorImpl).s26 = function () {
    var tmp0 = _get_effDefaultZoomFactor__j7gypf(this);
    // Inline function 'kotlin.math.min' call
    var b = calculateFitZoomFactor(this);
    return Math.min(tmp0, b);
  };
  protoOf(ViewNavigatorImpl).t26 = function (zoomFactor) {
    var containsLower = _get_minZoomFactor__ocim3h(this);
    return zoomFactor <= _get_maxZoomFactor__dhemff(this) ? containsLower <= zoomFactor : false;
  };
  function Companion_38() {
    this.m30_1 = 'ViewSpace.area';
  }
  var Companion_instance_42;
  function Companion_getInstance_40() {
    return Companion_instance_42;
  }
  function updateArea($this) {
    var oldValue = $this.f2z_1;
    var tmp0_elvis_lhs = maxOrNull($this.d2z_1);
    var topReduction = tmp0_elvis_lhs == null ? 0 : tmp0_elvis_lhs;
    $this.f2z_1 = Rectangle2D_init_$Create$_1(0, topReduction, $this.e2z_1.g1e_1, $this.e2z_1.h1e_1 - topReduction | 0);
    $this.n30('ViewSpace.area', oldValue, $this.f2z_1);
  }
  function ViewSpace(viewDimension, propertyOwner) {
    propertyOwner = propertyOwner === VOID ? new PropertyOwnerImpl() : propertyOwner;
    this.c2z_1 = propertyOwner;
    var tmp = this;
    // Inline function 'kotlin.collections.mutableListOf' call
    tmp.d2z_1 = ArrayList_init_$Create$();
    this.e2z_1 = viewDimension;
    this.f2z_1 = Rectangle2D_init_$Create$_1(0, 0, viewDimension.g1e_1, viewDimension.h1e_1);
    this.c2z_1.d1b(this);
    updateArea(this);
  }
  protoOf(ViewSpace).g2z = function (value) {
    if (!this.e2z_1.equals(value)) {
      this.e2z_1 = value;
      updateArea(this);
    }
  };
  protoOf(ViewSpace).o2z = function (l) {
    this.c2z_1.e1b(l);
  };
  protoOf(ViewSpace).e1b = function (l) {
    return this.o2z(l);
  };
  protoOf(ViewSpace).n2z = function (l) {
    this.c2z_1.f1b(l);
  };
  protoOf(ViewSpace).f1b = function (l) {
    return this.n2z(l);
  };
  protoOf(ViewSpace).n30 = function (name, oldValue, newValue) {
    this.c2z_1.lr(name, oldValue, newValue);
  };
  protoOf(ViewSpace).lr = function (name, oldValue, newValue) {
    var tmp = (oldValue == null ? true : oldValue instanceof Rectangle2D) ? oldValue : THROW_CCE();
    return this.n30(name, tmp, (newValue == null ? true : newValue instanceof Rectangle2D) ? newValue : THROW_CCE());
  };
  protoOf(ViewSpace).d1b = function (_set____db54di) {
    this.c2z_1.d1b(_set____db54di);
  };
  function get_zoomInAction() {
    _init_properties_ZoomPanAction_kt__uhg82a();
    var tmp0 = zoomInAction$delegate;
    var tmp = KProperty0;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('zoomInAction', 0, tmp, _get_zoomInAction_$ref_cghp70(), null);
    return tmp0.j2();
  }
  var zoomInAction$delegate;
  function get_zoomNormalAction() {
    _init_properties_ZoomPanAction_kt__uhg82a();
    var tmp0 = zoomNormalAction$delegate;
    var tmp = KProperty0;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('zoomNormalAction', 0, tmp, _get_zoomNormalAction_$ref_vqlqnq(), null);
    return tmp0.j2();
  }
  var zoomNormalAction$delegate;
  function get_zoomOutAction() {
    _init_properties_ZoomPanAction_kt__uhg82a();
    var tmp0 = zoomOutAction$delegate;
    var tmp = KProperty0;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('zoomOutAction', 0, tmp, _get_zoomOutAction_$ref_i71pvz(), null);
    return tmp0.j2();
  }
  var zoomOutAction$delegate;
  function get_zoomFitAction() {
    _init_properties_ZoomPanAction_kt__uhg82a();
    var tmp0 = zoomFitAction$delegate;
    var tmp = KProperty0;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('zoomFitAction', 0, tmp, _get_zoomFitAction_$ref_9m088c(), null);
    return tmp0.j2();
  }
  var zoomFitAction$delegate;
  function get_zoomFitMaxNormalAction() {
    _init_properties_ZoomPanAction_kt__uhg82a();
    var tmp0 = zoomFitMaxNormalAction$delegate;
    var tmp = KProperty0;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('zoomFitMaxNormalAction', 0, tmp, _get_zoomFitMaxNormalAction_$ref_g7olbr(), null);
    return tmp0.j2();
  }
  var zoomFitMaxNormalAction$delegate;
  function get_zoomCenterAction() {
    _init_properties_ZoomPanAction_kt__uhg82a();
    var tmp0 = zoomCenterAction$delegate;
    var tmp = KProperty0;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('zoomCenterAction', 0, tmp, _get_zoomCenterAction_$ref_379gtg(), null);
    return tmp0.j2();
  }
  var zoomCenterAction$delegate;
  function ZoomPanActions() {
  }
  protoOf(ZoomPanActions).o30 = function () {
    return get_zoomNormalAction();
  };
  protoOf(ZoomPanActions).p30 = function () {
    return get_zoomInAction();
  };
  protoOf(ZoomPanActions).q30 = function () {
    return get_zoomOutAction();
  };
  protoOf(ZoomPanActions).r30 = function () {
    return get_zoomFitAction();
  };
  protoOf(ZoomPanActions).s30 = function () {
    return get_zoomFitMaxNormalAction();
  };
  protoOf(ZoomPanActions).t30 = function () {
    return get_zoomCenterAction();
  };
  var ZoomPanActions_instance;
  function ZoomPanActions_getInstance() {
    return ZoomPanActions_instance;
  }
  function ZoomInAction(viewManager, eventBus) {
    viewManager = viewManager === VOID ? DrawViewModule_getInstance().a2u_1 : viewManager;
    eventBus = eventBus === VOID ? BaseModule_getInstance().zo_1 : eventBus;
    AbstractZoomPanAction.call(this, Companion_getInstance_10().v26_1, 'view.action.zoomIn', eventBus, viewManager);
  }
  protoOf(ZoomInAction).wr = function () {
    return protoOf(AbstractZoomPanAction).wr.call(this) && !(this.f1o() == null) && ensureNotNull(this.f1o()).x23().t26(ensureNotNull(this.f1o()).s23() * this.v31_1);
  };
  protoOf(ZoomInAction).execute = function (event) {
    var view = ensureNotNull(ensureNotNull(this.r2t_1.b2u()).f1o());
    view.x23().l26(this.v31_1);
    view.a24(Companion_getInstance_10().v26_1);
  };
  function ZoomNormalAction(viewManager, eventBus) {
    viewManager = viewManager === VOID ? DrawViewModule_getInstance().a2u_1 : viewManager;
    eventBus = eventBus === VOID ? BaseModule_getInstance().zo_1 : eventBus;
    AbstractZoomPanAction.call(this, Companion_getInstance_10().w26_1, 'view.action.zoomNormal', eventBus, viewManager);
  }
  function ZoomOutAction(viewManager, eventBus) {
    viewManager = viewManager === VOID ? DrawViewModule_getInstance().a2u_1 : viewManager;
    eventBus = eventBus === VOID ? BaseModule_getInstance().zo_1 : eventBus;
    AbstractZoomPanAction.call(this, Companion_getInstance_10().v26_1, 'view.action.zoomOut', eventBus, viewManager);
  }
  protoOf(ZoomOutAction).wr = function () {
    return protoOf(AbstractZoomPanAction).wr.call(this) && !(this.f1o() == null) && ensureNotNull(this.f1o()).x23().t26(1 / ensureNotNull(this.f1o()).s23() * this.v31_1);
  };
  protoOf(ZoomOutAction).execute = function (event) {
    var view = ensureNotNull(ensureNotNull(this.r2t_1.b2u()).f1o());
    view.x23().l26(1 / this.v31_1);
    view.a24(Companion_getInstance_10().v26_1);
  };
  function ZoomFitAction(viewManager, eventBus) {
    viewManager = viewManager === VOID ? DrawViewModule_getInstance().a2u_1 : viewManager;
    eventBus = eventBus === VOID ? BaseModule_getInstance().zo_1 : eventBus;
    AbstractZoomPanAction.call(this, Companion_getInstance_10().x26_1, 'view.action.zoomFit', eventBus, viewManager);
  }
  function ZoomFitMaxNormalAction(viewManager, eventBus) {
    viewManager = viewManager === VOID ? DrawViewModule_getInstance().a2u_1 : viewManager;
    eventBus = eventBus === VOID ? BaseModule_getInstance().zo_1 : eventBus;
    AbstractZoomPanAction.call(this, Companion_getInstance_10().y26_1, 'view.action.zoomFitMaxNormal', eventBus, viewManager);
  }
  function ZoomCenterAction(viewManager, eventBus) {
    viewManager = viewManager === VOID ? DrawViewModule_getInstance().a2u_1 : viewManager;
    eventBus = eventBus === VOID ? BaseModule_getInstance().zo_1 : eventBus;
    AbstractZoomPanAction.call(this, Companion_getInstance_10().z26_1, 'view.action.zoomCenter', eventBus, viewManager);
  }
  function Companion_39() {
    this.p34_1 = 'view.command.zoom.step';
  }
  var Companion_instance_43;
  function Companion_getInstance_41() {
    return Companion_instance_43;
  }
  function updateSelected($this) {
    $this.pq($this.w31());
  }
  function AbstractZoomPanAction(zoomStrategy, baseName, eventBus, viewManager) {
    eventBus = eventBus === VOID ? BaseModule_getInstance().zo_1 : eventBus;
    viewManager = viewManager === VOID ? DrawViewModule_getInstance().a2u_1 : viewManager;
    AbstractViewAction.call(this, baseName, eventBus, viewManager);
    this.u31_1 = zoomStrategy;
    this.v31_1 = BaseModule_getInstance().xo_1.jt('view.command.zoom.step');
  }
  protoOf(AbstractZoomPanAction).execute = function (event) {
    ensureNotNull(ensureNotNull(this.r2t_1.b2u()).f1o()).a24(this.u31_1);
  };
  protoOf(AbstractZoomPanAction).wr = function () {
    var tmp;
    if (protoOf(AbstractViewAction).wr.call(this)) {
      var tmp0_safe_receiver = this.r2t_1.b2u();
      var tmp1_safe_receiver = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.f1o();
      tmp = (tmp1_safe_receiver == null ? null : tmp1_safe_receiver.d24()) === true;
    } else {
      tmp = false;
    }
    return tmp;
  };
  protoOf(AbstractZoomPanAction).u2t = function (e) {
    protoOf(AbstractViewAction).u2t.call(this, e);
    switch (e.name) {
      case 'PROP_USER_ZOOM_ENABLED':
        this.updateEnabled();
        break;
      case 'draw.view.zoomStrategy':
        updateSelected(this);
        break;
      case 'PROP_TRANSFORMATION':
        this.updateEnabled();
        break;
    }
  };
  protoOf(AbstractZoomPanAction).v2t = function () {
    updateSelected(this);
    this.updateEnabled();
  };
  protoOf(AbstractZoomPanAction).w31 = function () {
    var tmp0_safe_receiver = this.r2t_1.b2u();
    var tmp1_safe_receiver = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.f1o();
    return equals(tmp1_safe_receiver == null ? null : tmp1_safe_receiver.b24(), this.u31_1);
  };
  function zoomInAction$delegate$lambda() {
    _init_properties_ZoomPanAction_kt__uhg82a();
    return new ZoomInAction();
  }
  function _get_zoomInAction_$ref_cghp70() {
    return function () {
      return get_zoomInAction();
    };
  }
  function zoomNormalAction$delegate$lambda() {
    _init_properties_ZoomPanAction_kt__uhg82a();
    return new ZoomNormalAction();
  }
  function _get_zoomNormalAction_$ref_vqlqnq() {
    return function () {
      return get_zoomNormalAction();
    };
  }
  function zoomOutAction$delegate$lambda() {
    _init_properties_ZoomPanAction_kt__uhg82a();
    return new ZoomOutAction();
  }
  function _get_zoomOutAction_$ref_i71pvz() {
    return function () {
      return get_zoomOutAction();
    };
  }
  function zoomFitAction$delegate$lambda() {
    _init_properties_ZoomPanAction_kt__uhg82a();
    return new ZoomFitAction();
  }
  function _get_zoomFitAction_$ref_9m088c() {
    return function () {
      return get_zoomFitAction();
    };
  }
  function zoomFitMaxNormalAction$delegate$lambda() {
    _init_properties_ZoomPanAction_kt__uhg82a();
    return new ZoomFitMaxNormalAction();
  }
  function _get_zoomFitMaxNormalAction_$ref_g7olbr() {
    return function () {
      return get_zoomFitMaxNormalAction();
    };
  }
  function zoomCenterAction$delegate$lambda() {
    _init_properties_ZoomPanAction_kt__uhg82a();
    return new ZoomCenterAction();
  }
  function _get_zoomCenterAction_$ref_379gtg() {
    return function () {
      return get_zoomCenterAction();
    };
  }
  var properties_initialized_ZoomPanAction_kt_3igp1s;
  function _init_properties_ZoomPanAction_kt__uhg82a() {
    if (!properties_initialized_ZoomPanAction_kt_3igp1s) {
      properties_initialized_ZoomPanAction_kt_3igp1s = true;
      zoomInAction$delegate = lazy(zoomInAction$delegate$lambda);
      zoomNormalAction$delegate = lazy(zoomNormalAction$delegate$lambda);
      zoomOutAction$delegate = lazy(zoomOutAction$delegate$lambda);
      zoomFitAction$delegate = lazy(zoomFitAction$delegate$lambda);
      zoomFitMaxNormalAction$delegate = lazy(zoomFitMaxNormalAction$delegate$lambda);
      zoomCenterAction$delegate = lazy(zoomCenterAction$delegate$lambda);
    }
  }
  function _get_LOG__e5r759_9($this) {
    var tmp0 = $this.q34_1;
    var tmp = KProperty1;
    // Inline function 'kotlin.getValue' call
    getPropertyCallableRef('LOG', 1, tmp, ZoomPanController$Companion$_get_LOG_$ref_qix2e(), null);
    return tmp0.j2();
  }
  function ZoomPanController$Companion$_get_LOG_$ref_qix2e() {
    return function (p0) {
      return _get_LOG__e5r759_9(p0);
    };
  }
  function isZoomOutWheelRotation($this, e) {
    return e.d1a().jn_1 < 0.0;
  }
  function isZoomWithMetaIfRequired($this, e) {
    return e.isMetaDown || !_get_wheelZoomRequiresMeta__yweuk0($this.u34_1);
  }
  function getZoomChangeFactorFromWheelRotation($this, e) {
    if (!near(e.d1a().jn_1, 0.0)) {
      return isZoomOutWheelRotation($this, e) ? 1 / _get_wheelZoomStep__lkqvft($this.u34_1) : _get_wheelZoomStep__lkqvft($this.u34_1);
    }
    return 1.0;
  }
  function getPanVectorFromWheelRotation($this, e) {
    return e.d1a().i1f(_get_wheelPanStep__9i9m3n($this.u34_1));
  }
  function panByWheel($this, e) {
    $this.u34_1.y2z_1 = Companion_getInstance().g1a_1;
    pan_0($this.u34_1, getPanVectorFromWheelRotation($this, e));
    $this.u34_1.u2z_1.l2w();
  }
  function zoomByWheel($this, e) {
    $this.u34_1.q2z_1.x23().k26(getZoomChangeFactorFromWheelRotation($this, e), e.hw());
    $this.u34_1.u2z_1.k2w();
  }
  function Companion_40() {
    Companion_instance_44 = this;
    this.q34_1 = logger(getKClass(ZoomPanController));
    this.r34_1 = 'view.ZoomPanController.wheelZoomStep';
    this.s34_1 = 'view.ZoomPanController.wheelZoomRequiredMeta';
    this.t34_1 = 'view.ZoomPanController.wheelPanStep';
  }
  var Companion_instance_44;
  function Companion_getInstance_42() {
    if (Companion_instance_44 == null)
      new Companion_40();
    return Companion_instance_44;
  }
  function _get_wheelZoomStep__lkqvft($this) {
    return BaseModule_getInstance().xo_1.jt('view.ZoomPanController.wheelZoomStep');
  }
  function _get_wheelPanStep__9i9m3n($this) {
    return BaseModule_getInstance().xo_1.it('view.ZoomPanController.wheelPanStep');
  }
  function _get_wheelZoomRequiresMeta__yweuk0($this) {
    return BaseModule_getInstance().xo_1.ft('view.ZoomPanController.wheelZoomRequiredMeta');
  }
  function startPan($this, pos) {
    $this.y2z_1 = pos;
    $this.x2z_1 = true;
  }
  function pan_0($this, pos) {
    var delta = pos.t1g($this.y2z_1);
    $this.q2z_1.x23().m26(numberToInt(delta.in_1), numberToInt(delta.jn_1));
    $this.y2z_1 = pos;
  }
  function MouseController($outer) {
    this.u34_1 = $outer;
    MouseAdapter.call(this);
  }
  protoOf(MouseController).s1a = function (e) {
    this.u34_1.w2z_1 = true;
    if (!CurrentPanMethod_getInstance().z2w_1.p2w(e, this.u34_1.u2z_1.i2w_1)) {
      return Unit_instance;
    }
    startPan(this.u34_1, e.hw());
  };
  protoOf(MouseController).u1a = function (e) {
    if (e.e1a() || e.f1a()) {
      this.u34_1.v2z_1.w2u();
    }
    if (this.u34_1.x2z_1) {
      pan_0(this.u34_1, e.hw());
    }
  };
  protoOf(MouseController).t1a = function (e) {
    this.u34_1.w2z_1 = false;
    this.u34_1.x2z_1 = false;
    if (!e.b1a().equals(Button_BUTTON3_getInstance())) {
      this.u34_1.v2z_1.x2u();
    }
    if (CurrentPanMethod_getInstance().z2w_1.p2w(e, this.u34_1.u2z_1.i2w_1)) {
      this.u34_1.q2z_1.a24(Companion_getInstance_10().v26_1);
    }
  };
  protoOf(MouseController).w1a = function (e) {
    if (this.u34_1.w2z_1) {
      return Unit_instance;
    }
    if (!isZoomWithMetaIfRequired(this, e)) {
      return Unit_instance;
    }
    this.u34_1.q2z_1.a24(Companion_getInstance_10().v26_1);
    if (this.u34_1.u2z_1.j2w()) {
      zoomByWheel(this, e);
    } else {
      panByWheel(this, e);
    }
    e.consumeEvent();
  };
  function ZoomPanController$activeViewChangeHandler$lambda(this$0) {
    return function (it) {
      _get_LOG__e5r759_9(Companion_getInstance_42()).ol('activeContentViewChanged, resetting mouseWheelModeController');
      this$0.u2z_1.bu();
      return Unit_instance;
    };
  }
  function ZoomPanController(view, eventBus) {
    Companion_getInstance_42();
    eventBus = eventBus === VOID ? BaseModule_getInstance().zo_1 : eventBus;
    this.q2z_1 = view;
    this.r2z_1 = eventBus;
    this.s2z_1 = false;
    this.t2z_1 = new MouseController(this);
    this.u2z_1 = new MouseWheelModeController();
    this.v2z_1 = new AutoPanning(this.q2z_1);
    this.w2z_1 = false;
    this.x2z_1 = false;
    this.y2z_1 = Companion_getInstance().g1a_1;
    var tmp = this;
    tmp.z2z_1 = ZoomPanController$activeViewChangeHandler$lambda(this);
    this.r2z_1.j17(getKClass(ActiveContentViewChangedEvent), this.z2z_1);
  }
  protoOf(ZoomPanController).nq = function (value) {
    if (value) {
      this.q2z_1.b1y(this.t2z_1);
      this.q2z_1.d1y(this.t2z_1);
      this.q2z_1.f1y(this.t2z_1);
      this.q2z_1.h1y(this.u2z_1);
    } else {
      this.q2z_1.c1y(this.t2z_1);
      this.q2z_1.e1y(this.t2z_1);
      this.q2z_1.g1y(this.t2z_1);
      this.q2z_1.i1y(this.u2z_1);
    }
    this.s2z_1 = value;
  };
  protoOf(ZoomPanController).e24 = function (value) {
    this.v2z_1.v2u_1 = value;
  };
  protoOf(ZoomPanController).es = function () {
    this.r2z_1.l17(this.z2z_1);
  };
  function ZoomedPointTranslation(modelPoint, viewPoint, zoomFactor) {
    this.j30_1 = modelPoint;
    this.k30_1 = viewPoint;
    this.l30_1 = zoomFactor;
  }
  protoOf(ZoomedPointTranslation).toString = function () {
    return 'ZoomedPointTranslation(modelPoint=' + this.j30_1.toString() + ', viewPoint=' + this.k30_1.toString() + ', zoomFactor=' + this.l30_1 + ')';
  };
  protoOf(ZoomedPointTranslation).hashCode = function () {
    var result = this.j30_1.hashCode();
    result = imul(result, 31) + this.k30_1.hashCode() | 0;
    result = imul(result, 31) + getNumberHashCode(this.l30_1) | 0;
    return result;
  };
  protoOf(ZoomedPointTranslation).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof ZoomedPointTranslation))
      return false;
    if (!this.j30_1.equals(other.j30_1))
      return false;
    if (!this.k30_1.equals(other.k30_1))
      return false;
    if (!equals(this.l30_1, other.l30_1))
      return false;
    return true;
  };
  function ZoomedPointVoyageAnimation$_init_$lambda_of1by4($view) {
    return function (it) {
      $view.x23().j26(it);
      return Unit_instance;
    };
  }
  function ZoomedPointVoyageAnimation(view, duration, destination) {
    AbstractAnimationTask.call(this, view, ZoomedPointVoyageAnimation$_init_$lambda_of1by4(view), new ZoomedPointVoyage(view, destination), duration);
  }
  function calculateNext($this, distance) {
    if (distance === 0.0) {
      return ensureNotNull($this.y34_1);
    }
    var tmp;
    if ($this.x34_1) {
      tmp = distance / $this.v34_1.o();
    } else {
      tmp = distance / $this.w34_1.q1q_1;
    }
    var fraction = tmp;
    var viewLocationDistance = fraction * $this.v34_1.o();
    var zoomFactorDistance = fraction * $this.w34_1.q1q_1;
    var nextViewLocation = $this.v34_1.d1p(viewLocationDistance);
    var nextZoomFactor = $this.w34_1.d1p(zoomFactorDistance);
    if (nextViewLocation == null && nextZoomFactor == null) {
      return null;
    }
    var viewLocation = nextViewLocation == null ? ensureNotNull($this.y34_1).k30_1 : nextViewLocation;
    var zoomFactor = nextZoomFactor == null ? ensureNotNull($this.y34_1).l30_1 : nextZoomFactor;
    return new ZoomedPointTranslation(ensureNotNull($this.y34_1).j30_1, viewLocation, zoomFactor);
  }
  function ZoomedPointVoyage(view, destination) {
    this.v34_1 = new PointRange(view.q24(destination.j30_1), destination.k30_1);
    this.w34_1 = new DoubleRange(view.s23(), destination.l30_1);
    var tmp = this;
    // Inline function 'kotlin.math.abs' call
    var x = this.v34_1.o();
    var tmp_0 = Math.abs(x);
    // Inline function 'kotlin.math.abs' call
    var x_0 = this.w34_1.q1q_1;
    tmp.x34_1 = tmp_0 >= Math.abs(x_0);
    this.y34_1 = new ZoomedPointTranslation(destination.j30_1, view.q24(destination.j30_1), view.s23());
    this.z34_1 = this.x34_1 ? this.v34_1.o() : this.w34_1.q1q_1;
  }
  protoOf(ZoomedPointVoyage).o = function () {
    return this.z34_1;
  };
  protoOf(ZoomedPointVoyage).d1p = function (distance) {
    if (this.z34_1 <= 0 || this.y34_1 == null) {
      return null;
    }
    this.y34_1 = calculateNext(this, distance);
    return this.y34_1;
  };
  //region block: post-declaration
  protoOf(AbstractGraphics2D).w1c = translate;
  protoOf(AbstractGraphics2D).l1v = drawLine;
  protoOf(AbstractGraphics2D).m1v = drawCircle;
  protoOf(AbstractGraphics2D).n1v = fillCircle;
  protoOf(MouseEventJs).d17 = get_isAltDown;
  protoOf(MouseEventJs).e17 = get_isControlDown;
  protoOf(MouseEventJs).f17 = get_isShiftDown;
  protoOf(MouseEventJs).g17 = get_isCtrlDown;
  protoOf(MouseEventJs).h17 = get_isAltGraphDown;
  protoOf(MouseEventJs).i17 = get_isMetaDown;
  protoOf(MouseEventJs).hasModifier = hasModifier;
  defineProp(protoOf(MouseEventJs), 'event', function () {
    return this.y16();
  });
  defineProp(protoOf(MouseEventJs), 'source', function () {
    return this.z16();
  });
  defineProp(protoOf(MouseEventJs), 'modifiers', function () {
    return this.a17();
  });
  defineProp(protoOf(MouseEventJs), 'isAltDown', function () {
    return this.d17();
  });
  defineProp(protoOf(MouseEventJs), 'isControlDown', function () {
    return this.e17();
  });
  defineProp(protoOf(MouseEventJs), 'isShiftDown', function () {
    return this.f17();
  });
  defineProp(protoOf(MouseEventJs), 'isCtrlDown', function () {
    return this.g17();
  });
  defineProp(protoOf(MouseEventJs), 'isAltGraphDown', function () {
    return this.h17();
  });
  defineProp(protoOf(MouseEventJs), 'isMetaDown', function () {
    return this.i17();
  });
  protoOf(KeyEventJs).d17 = get_isAltDown;
  protoOf(KeyEventJs).e17 = get_isControlDown;
  protoOf(KeyEventJs).f17 = get_isShiftDown;
  protoOf(KeyEventJs).g17 = get_isCtrlDown;
  protoOf(KeyEventJs).h17 = get_isAltGraphDown;
  protoOf(KeyEventJs).i17 = get_isMetaDown;
  protoOf(KeyEventJs).hasModifier = hasModifier;
  defineProp(protoOf(KeyEventJs), 'event', function () {
    return this.y16();
  });
  defineProp(protoOf(KeyEventJs), 'source', function () {
    return this.z16();
  });
  defineProp(protoOf(KeyEventJs), 'modifiers', function () {
    return this.a17();
  });
  defineProp(protoOf(KeyEventJs), 'isAltDown', function () {
    return this.d17();
  });
  defineProp(protoOf(KeyEventJs), 'isControlDown', function () {
    return this.e17();
  });
  defineProp(protoOf(KeyEventJs), 'isShiftDown', function () {
    return this.f17();
  });
  defineProp(protoOf(KeyEventJs), 'isCtrlDown', function () {
    return this.g17();
  });
  defineProp(protoOf(KeyEventJs), 'isAltGraphDown', function () {
    return this.h17();
  });
  defineProp(protoOf(KeyEventJs), 'isMetaDown', function () {
    return this.i17();
  });
  protoOf(DrawableBagImpl).l20 = add$default;
  protoOf(DrawableBagImpl).h20 = contains_3;
  protoOf(DrawableBagImpl).eo = contains_4;
  protoOf(DrawableBagImpl).n20 = frontToBackIterator;
  protoOf(DrawableBagImpl).p20 = getDrawableAt;
  protoOf(DrawableBagImpl).q20 = getDrawableAt_0;
  protoOf(DrawableBagImpl).s20 = getDrawableAt_1;
  protoOf(DrawableBagImpl).t20 = getDrawableAt_2;
  protoOf(DrawableBagImpl).u20 = getDrawables;
  protoOf(DrawableBagImpl).v20 = getDrawableIntersection;
  protoOf(DrawableBagImpl).w20 = getDrawableIntersection$default;
  protoOf(DrawableBagImpl).x20 = getDrawable;
  protoOf(DrawableBagImpl).i20 = rotateBack;
  protoOf(DrawableBagImpl).y20 = rotateBack_0;
  protoOf(DrawableBagImpl).r20 = rotateBack_1;
  protoOf(AbstractDrawable).no = contains_2;
  protoOf(AbstractDrawable).po = intersects_0;
  protoOf(DrawableContainerImpl).l20 = add$default;
  protoOf(DrawableContainerImpl).eo = contains_5;
  protoOf(DrawableContainerImpl).h20 = contains_3;
  protoOf(DrawableContainerImpl).f21 = moveBy;
  protoOf(DrawableContainerImpl).n20 = frontToBackIterator;
  protoOf(DrawableContainerImpl).o20 = backToFrontIterator;
  protoOf(DrawableContainerImpl).p20 = getDrawableAt;
  protoOf(DrawableContainerImpl).q20 = getDrawableAt_0;
  protoOf(DrawableContainerImpl).s20 = getDrawableAt_1;
  protoOf(DrawableContainerImpl).t20 = getDrawableAt_2;
  protoOf(DrawableContainerImpl).u20 = getDrawables;
  protoOf(DrawableContainerImpl).v20 = getDrawableIntersection;
  protoOf(DrawableContainerImpl).w20 = getDrawableIntersection$default;
  protoOf(DrawableContainerImpl).x20 = getDrawable;
  protoOf(DrawableContainerImpl).i20 = rotateBack;
  protoOf(DrawableContainerImpl).y20 = rotateBack_0;
  protoOf(DrawableContainerImpl).r20 = rotateBack_1;
  protoOf(AbstractRectangle).e1c = get_widthInt;
  protoOf(AbstractRectangle).f1c = get_heightInt;
  protoOf(AbstractRectangle).z19 = get_x;
  protoOf(AbstractRectangle).a1a = get_y;
  protoOf(AbstractRectangle).c1c = get_xInt;
  protoOf(AbstractRectangle).d1c = get_yInt;
  protoOf(AbstractRectangle).q2b = setBounds;
  protoOf(AbstractRectangle).r2b = setBounds_0;
  protoOf(AbstractRectangle).f21 = moveBy;
  protoOf(FlexibleTextView).v2g = applyTo;
  protoOf(FlexibleTextView).f21 = moveBy;
  protoOf(TransparentImpl).v2g = applyTo;
  protoOf(PolylineDrawable).r2q = findSegment$default;
  protoOf(PolylineDrawable).l2q = getFirstPoint;
  protoOf(PolylineDrawable).m2q = getLastPoint;
  protoOf(PolylineDrawable).v2g = applyTo;
  protoOf(PolylineShapeImpl).r2q = findSegment$default;
  protoOf(PolylineShapeImpl).l2q = getFirstPoint;
  protoOf(PolylineShapeImpl).m2q = getLastPoint;
  protoOf(PolylineShapeImpl).z2q = isSegmentOrthogonal;
  protoOf(PolylineShapeImpl).no = contains_0;
  protoOf(PolylineShapeImpl).oo = contains_1;
  protoOf(PolylineShapeImpl).po = intersects;
  defineProp(protoOf(AbstractContentViewAction), 'requestFocusOnClick', function () {
    return this.uq();
  });
  defineProp(protoOf(AbstractViewAction), 'requestFocusOnClick', function () {
    return this.uq();
  });
  protoOf(ViewImpl).b1x = get_devicePixelRatio;
  protoOf(ViewImpl).n1c = get_center;
  protoOf(ViewImpl).s23 = get_zoomFactor;
  protoOf(ViewNavigatorImpl).l26 = multiplyZoomFactor$default;
  defineProp(protoOf(ZoomPanActions), 'zoomNormalAction', protoOf(ZoomPanActions).o30);
  defineProp(protoOf(ZoomPanActions), 'zoomInAction', protoOf(ZoomPanActions).p30);
  defineProp(protoOf(ZoomPanActions), 'zoomOutAction', protoOf(ZoomPanActions).q30);
  defineProp(protoOf(ZoomPanActions), 'zoomFitAction', protoOf(ZoomPanActions).r30);
  defineProp(protoOf(ZoomPanActions), 'zoomFitMaxNormalAction', protoOf(ZoomPanActions).s30);
  defineProp(protoOf(ZoomPanActions), 'zoomCenterAction', protoOf(ZoomPanActions).t30);
  defineProp(protoOf(AbstractZoomPanAction), 'requestFocusOnClick', function () {
    return this.uq();
  });
  defineProp(protoOf(ZoomInAction), 'requestFocusOnClick', function () {
    return this.uq();
  });
  defineProp(protoOf(ZoomNormalAction), 'requestFocusOnClick', function () {
    return this.uq();
  });
  defineProp(protoOf(ZoomOutAction), 'requestFocusOnClick', function () {
    return this.uq();
  });
  defineProp(protoOf(ZoomFitAction), 'requestFocusOnClick', function () {
    return this.uq();
  });
  defineProp(protoOf(ZoomFitMaxNormalAction), 'requestFocusOnClick', function () {
    return this.uq();
  });
  defineProp(protoOf(ZoomCenterAction), 'requestFocusOnClick', function () {
    return this.uq();
  });
  //endregion
  //region block: init
  Companion_instance_3 = new Companion();
  PolylineShapeFactory_instance = new PolylineShapeFactory();
  Companion_instance_5 = new Companion_1();
  FocusManager_instance = new FocusManager();
  Companion_instance_8 = new Companion_4();
  Companion_instance_9 = new Companion_5();
  IdentityViewToModelTransform_instance = new IdentityViewToModelTransform();
  Companion_instance_11 = new Companion_7();
  Companion_instance_13 = new Companion_9();
  ArrowBubblePositioner_instance = new ArrowBubblePositioner();
  DrawableAttendantPositioner_instance = new DrawableAttendantPositioner();
  Companion_instance_15 = new Companion_11();
  Companion_instance_16 = new Companion_12();
  Companion_instance_18 = new Companion_14();
  Companion_instance_19 = new Companion_15();
  Companion_instance_23 = new Companion_19();
  Companion_instance_24 = new Companion_20();
  DropShadow_instance = new DropShadow();
  Companion_instance_25 = new Companion_21();
  Companion_instance_26 = new Companion_22();
  Companion_instance_27 = new Companion_23();
  Companion_instance_28 = new Companion_24();
  TextRenderInfoFactory_instance = new TextRenderInfoFactory();
  Companion_instance_31 = new Companion_27();
  Companion_instance_32 = new Companion_28();
  Companion_instance_36 = new Companion_32();
  Companion_instance_37 = new Companion_33();
  Companion_instance_38 = new Companion_34();
  Companion_instance_39 = new Companion_35();
  Companion_instance_40 = new Companion_36();
  Companion_instance_42 = new Companion_38();
  ZoomPanActions_instance = new ZoomPanActions();
  Companion_instance_43 = new Companion_39();
  //endregion
  //region block: exports
  function $jsExportAll$(_) {
    var io = _.io || (_.io = {});
    var antarescircuit = io.antarescircuit || (io.antarescircuit = {});
    var jabbah = antarescircuit.jabbah || (antarescircuit.jabbah = {});
    var draw = jabbah.draw || (jabbah.draw = {});
    var view = draw.view || (draw.view = {});
    defineProp(view, 'ZoomPanActions', ZoomPanActions_getInstance, VOID, true);
  }
  $jsExportAll$(_);
  _.$jsExportAll$ = $jsExportAll$;
  _.$_$ = _.$_$ || {};
  _.$_$.a = DrawableAttendantPositioner_instance;
  _.$_$.b = Companion_instance_16;
  _.$_$.c = Companion_getInstance_15;
  _.$_$.d = SynchronizedGlowAnimation_getInstance;
  _.$_$.e = Companion_instance_19;
  _.$_$.f = Companion_getInstance_18;
  _.$_$.g = Companion_getInstance_20;
  _.$_$.h = Companion_instance_23;
  _.$_$.i = DrawGraphicsModule_getInstance;
  _.$_$.j = DropShadow_instance;
  _.$_$.k = Companion_instance_26;
  _.$_$.l = ReferenceColorSequenceProvider_getInstance;
  _.$_$.m = TextRenderInfoFactory_instance;
  _.$_$.n = DrawModule_getInstance;
  _.$_$.o = Companion_getInstance_27;
  _.$_$.p = Companion_getInstance_28;
  _.$_$.q = Companion_instance_31;
  _.$_$.r = PolylineShapeFactory_instance;
  _.$_$.s = DrawStyleModule_getInstance;
  _.$_$.t = Companion_getInstance_31;
  _.$_$.u = Companion_getInstance_32;
  _.$_$.v = Companion_getInstance_33;
  _.$_$.w = Themes_getInstance;
  _.$_$.x = CurrentPanMethod_getInstance;
  _.$_$.y = DrawViewModule_getInstance;
  _.$_$.z = FocusManager_instance;
  _.$_$.a1 = Companion_getInstance_5;
  _.$_$.b1 = Companion_getInstance_8;
  _.$_$.c1 = DrawModuleJs_getInstance;
  _.$_$.d1 = Cursor_CLICK_getInstance;
  _.$_$.e1 = Cursor_CROSSHAIR_getInstance;
  _.$_$.f1 = Cursor_DEFAULT_getInstance;
  _.$_$.g1 = Cursor_E_RESIZE_getInstance;
  _.$_$.h1 = Cursor_MOVE_getInstance;
  _.$_$.i1 = Cursor_NE_RESIZE_getInstance;
  _.$_$.j1 = Cursor_NW_RESIZE_getInstance;
  _.$_$.k1 = Cursor_N_RESIZE_getInstance;
  _.$_$.l1 = Cursor_SE_RESIZE_getInstance;
  _.$_$.m1 = Cursor_SW_RESIZE_getInstance;
  _.$_$.n1 = Cursor_S_RESIZE_getInstance;
  _.$_$.o1 = Cursor_W_RESIZE_getInstance;
  _.$_$.p1 = FontStyle_PLAIN_getInstance;
  _.$_$.q1 = ImageType_SVG_getInstance;
  _.$_$.r1 = LineCap_BUTT_getInstance;
  _.$_$.s1 = LineCap_ROUND_getInstance;
  _.$_$.t1 = LineCap_SQUARE_getInstance;
  _.$_$.u1 = LineJoin_MITER_getInstance;
  _.$_$.v1 = LineJoin_ROUND_getInstance;
  _.$_$.w1 = LogicalFontFamily_DIALOG_getInstance;
  _.$_$.x1 = LogicalFontFamily_MONOSPACED_getInstance;
  _.$_$.y1 = LogicalFontFamily_SANS_SERIF_getInstance;
  _.$_$.z1 = PredefinedColorIdentity_Black_getInstance;
  _.$_$.a2 = PredefinedColorIdentity_Blue_getInstance;
  _.$_$.b2 = PredefinedColorIdentity_Brown_getInstance;
  _.$_$.c2 = PredefinedColorIdentity_Gray_getInstance;
  _.$_$.d2 = PredefinedColorIdentity_Green_getInstance;
  _.$_$.e2 = PredefinedColorIdentity_Red_getInstance;
  _.$_$.f2 = PredefinedColorIdentity_Turquoise_getInstance;
  _.$_$.g2 = PredefinedColorIdentity_Violet_getInstance;
  _.$_$.h2 = PredefinedColorIdentity_White_getInstance;
  _.$_$.i2 = PredefinedColorIdentity_Yellow_getInstance;
  _.$_$.j2 = ZoomStrategyType_VALUE_getInstance;
  _.$_$.k2 = findSegment$default;
  _.$_$.l2 = AbstractRectangle_init_$Init$;
  _.$_$.m2 = AbstractRectangle_init_$Init$_0;
  _.$_$.n2 = AbstractStyledDrawable_init_$Init$;
  _.$_$.o2 = DrawableButton_init_$Create$;
  _.$_$.p2 = Color_init_$Create$;
  _.$_$.q2 = DrawableBagImpl;
  _.$_$.r2 = DrawableBagInputEventHandler;
  _.$_$.s2 = DrawableContainerAdapter;
  _.$_$.t2 = DrawableContainerDrawer;
  _.$_$.u2 = DrawableContainerImpl;
  _.$_$.v2 = DrawableGeometryProperty;
  _.$_$.w2 = DrawableProperty;
  _.$_$.x2 = UnzoomableContainer;
  _.$_$.y2 = DrawableOwner;
  _.$_$.z2 = AbstractDrawableButtonRenderer;
  _.$_$.a3 = AbstractDrawableDrawer;
  _.$_$.b3 = AbstractDrawable;
  _.$_$.c3 = AbstractRectangle;
  _.$_$.d3 = AbstractRectangularUnzoomable;
  _.$_$.e3 = AbstractStyledDrawable;
  _.$_$.f3 = ButtonAction;
  _.$_$.g3 = Colorable;
  _.$_$.h3 = EditInteractionHandler;
  _.$_$.i3 = DrawableButton;
  _.$_$.j3 = DrawableDrawer;
  _.$_$.k3 = FlexibleTextView;
  _.$_$.l3 = IconDrawableButtonRenderer;
  _.$_$.m3 = moveBy;
  _.$_$.n3 = Locatable;
  _.$_$.o3 = get_canMirror;
  _.$_$.p3 = Mirrorable;
  _.$_$.q3 = completeMoveBy;
  _.$_$.r3 = prepareMoveBy;
  _.$_$.s3 = Movable;
  _.$_$.t3 = MoveLocatableAnimation;
  _.$_$.u3 = get_orientation;
  _.$_$.v3 = set_orientation;
  _.$_$.w3 = Orientable;
  _.$_$.x3 = get_heightInt;
  _.$_$.y3 = setBounds;
  _.$_$.z3 = setBounds_0;
  _.$_$.a4 = get_widthInt;
  _.$_$.b4 = get_x;
  _.$_$.c4 = get_xInt;
  _.$_$.d4 = get_y;
  _.$_$.e4 = get_yInt;
  _.$_$.f4 = RectangularDrawable;
  _.$_$.g4 = ShakeLocatableAnimation;
  _.$_$.h4 = applyTo;
  _.$_$.i4 = TransparentImpl;
  _.$_$.j4 = Transparent;
  _.$_$.k4 = Unzoomable;
  _.$_$.l4 = AddIcon;
  _.$_$.m4 = ColorGradient;
  _.$_$.n4 = Color;
  _.$_$.o4 = CompositeColorGradient;
  _.$_$.p4 = CompositeColor;
  _.$_$.q4 = DeleteIcon;
  _.$_$.r4 = EmbeddedImageJs;
  _.$_$.s4 = FontImpl;
  _.$_$.t4 = draw;
  _.$_$.u4 = Icon;
  _.$_$.v4 = KnobIcon;
  _.$_$.w4 = LinearColorGradient;
  _.$_$.x4 = PredefinedColor;
  _.$_$.y4 = RadialColorGradientCache;
  _.$_$.z4 = ReferenceColor;
  _.$_$.a5 = RemoveIcon;
  _.$_$.b5 = Stroke;
  _.$_$.c5 = ArrowHead;
  _.$_$.d5 = PolylineDrawable;
  _.$_$.e5 = Polyline;
  _.$_$.f5 = BasicStyle;
  _.$_$.g5 = DrawTheme;
  _.$_$.h5 = StylableImpl;
  _.$_$.i5 = Stylable;
  _.$_$.j5 = StyleType;
  _.$_$.k5 = CanvasJs;
  _.$_$.l5 = InvalidatableViewPainter;
  _.$_$.m5 = TooltipHandler;
  _.$_$.n5 = ViewImpl;
  _.$_$.o5 = ZoomedPointTranslation;
  _.$_$.p5 = ZoomedPointVoyageAnimation;
  _.$_$.q5 = buildToolTipText;
  _.$_$.r5 = ApplicationContextHolder;
  _.$_$.s5 = CloseViewRequest;
  _.$_$.t5 = DrawContext;
  _.$_$.u5 = DrawableAdapter;
  _.$_$.v5 = DrawableContainerListener;
  _.$_$.w5 = DrawableContainer;
  _.$_$.x5 = DrawableExplanation;
  _.$_$.y5 = Drawable;
  _.$_$.z5 = focusGained;
  _.$_$.a6 = focusLost;
  _.$_$.b6 = get_isFocusOwner;
  _.$_$.c6 = requestFocus;
  _.$_$.d6 = Focusable;
  _.$_$.e6 = InputEventContext;
  _.$_$.f6 = InputEventHandlerAdapter;
  _.$_$.g6 = InputEventHandler;
  _.$_$.h6 = StateMachineInputEventHandler;
  _.$_$.i6 = ViewContentBounds;
  _.$_$.j6 = ViewTransformation;
  _.$_$.k6 = View;
  _.$_$.l6 = ZoomStrategy;
  //endregion
  return _;
}));

//# sourceMappingURL=jabbah-draw.js.map
